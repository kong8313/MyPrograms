dotnet new install Confirmit.Template.IIS-Application
Push-Location $PSScriptRoot
dotnet new iis-app -n cati -A "Confirmit.CATI.MonitoringConsole" -N MonitoringConsoleKube -B ConfirmitCati_FeatureBranch_4CatiBuildInstallations -S download/cati/monitoringconsole -H cati-monitoringconsole -D false -o . --force --allow-scripts yes
Pop-Location