param (
    [Parameter(mandatory=$true)]
    [string]$version
)
docker stop cati-monitoringconsole
docker rm cati-monitoringconsole
docker run --rm --name cati-monitoringconsole -it `
-p 8080:80 `
-e Confirmit__Site__Url__CatiMonitoringConsoleDownload=https://rnd.aks.firmglobal.net/download/cati/monitoringconsole `
--entrypoint powershell `
confirmithorizonsdev.azurecr.io/confirmit/cati-monitoringconsole:$version