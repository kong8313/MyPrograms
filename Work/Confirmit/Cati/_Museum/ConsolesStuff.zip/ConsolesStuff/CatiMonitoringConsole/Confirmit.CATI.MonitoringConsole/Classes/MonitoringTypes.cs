﻿namespace Confirmit.CATI.MonitoringConsole.Classes
{
    /// <summary>
    /// Represents enumeration of monitoring types.
    /// </summary>
    internal enum MonitoringTypes
    {
        /// <summary>
        /// Live monitoring.
        /// </summary>
        Live = 1,

        /// <summary>
        /// Deferred monitoring.
        /// </summary>
        Deferred = 2
    }
}
