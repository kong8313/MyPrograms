using System;
using System.Windows.Forms;
using Confirmit.CATI.MonitoringConsole.Presenters;
using Microsoft.VisualBasic.ApplicationServices;

namespace Confirmit.CATI.MonitoringConsole
{
    public class SingleInstanceApplication : WindowsFormsApplicationBase
    {
        private static PresenterMainForm _presenterMainForm;

        private SingleInstanceApplication()
        {
            IsSingleInstance = true;
        }

        public static void SwitchToNewIdentity(string encryptedData)
        {
            _presenterMainForm.SwitchToNewIdentity(encryptedData);
        }

        internal static void Run(Form form, PresenterMainForm presenterMainForm)
        {
            _presenterMainForm = presenterMainForm;

            var app = new SingleInstanceApplication();
            app.MainForm = form;
            app.StartupNextInstance += NewInstanceHandler;
            app.Run(AppDomain.CurrentDomain.SetupInformation.ActivationArguments.ActivationData);
        }

        public static void NewInstanceHandler(object sender, StartupNextInstanceEventArgs e)
        {
            e.BringToForeground = true;
            SwitchToNewIdentity(e.CommandLine[0]);
        }
    }
}