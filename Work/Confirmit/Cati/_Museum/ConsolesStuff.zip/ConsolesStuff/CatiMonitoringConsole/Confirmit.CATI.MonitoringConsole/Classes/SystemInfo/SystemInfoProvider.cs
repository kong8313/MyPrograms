﻿using System;

namespace Confirmit.CATI.MonitoringConsole.Classes.SystemInfo
{
    /// <summary>
    /// Provides information about current operation system.
    /// </summary>
    /// <remarks>
    /// For details see: 
    /// http://www.sharparena.com/index.php?option=com_content&view=article&id=43:article-csharp-windows-version-edition&catid=15:category-csharp-general&Itemid=12    
    /// </remarks>
    public static class SystemInfoProvider
    {
        private const string ProcessorArchitectureVariable = "PROCESSOR_ARCHITECTURE";

        /// <summary>
        /// Returns platform type of current operation system
        /// </summary>
        /// <remarks>
        /// The environment variable “PROCESSOR_ARCHITECTURE” is either set to “x86″ or 
        /// doesn’t exist on 32-bit versions of Windows. 
        /// It’s always set to something other than “x86″ on 64-bit versions of Windows.
        /// </remarks>
        public static PlatformType GetPlatform()
        {
            string pa = Environment.GetEnvironmentVariable(ProcessorArchitectureVariable);

            if (String.IsNullOrEmpty(pa))
            {
                return PlatformType.Bit32;
            }

            return (String.Compare(pa, "x86", true) == 0) ? PlatformType.Bit32 : PlatformType.Bit64;
        }

        /// <summary>
        /// Returns version of current operation system
        /// </summary>
        /// <returns></returns>
        public static WindowsVersion GetVersion()
        {
            if (Environment.OSVersion.Platform != PlatformID.Win32NT)
            {
                return WindowsVersion.Unknown;
            }

            int majorVersion = Environment.OSVersion.Version.Major;
            int minorVersion = Environment.OSVersion.Version.Minor;

            var info = SystemProvider.GetSystemInfo();                       

            switch (majorVersion)
            {                
                case 5:
                    {

                        switch (minorVersion)
                        {
                            case 0: return WindowsVersion.Windows2000;
                            case 1: return WindowsVersion.WindowsXP;
                            case 2:
                                {
                                    if (info.ProductType == ProductType.VerNtWorkstation &&
                                        info.ProcessorArchitecture == ProcessorArchitecture.ProcessorArchitectureAmd64)
                                    {
                                        return WindowsVersion.WindowsXPProfessionalx64;
                                    }

                                    return WindowsVersion.WindowsServer2003;
                                }
                        }

                    }
                    break;

                case 6:
                    {
                        switch (minorVersion)
                        {
                            case 0:
                                {
                                    return info.ProductType == ProductType.VerNtWorkstation ? 
                                        WindowsVersion.WindowsVista :WindowsVersion.WindowsServer2008;
                                }
                            case 1:
                                {
                                    return info.ProductType == ProductType.VerNtWorkstation ?
                                           WindowsVersion.Windows7 : WindowsVersion.WindowsServer2008R2;

                                }
                        }
                    }
                    break;
            }

            return WindowsVersion.Unknown;
        }
    }
}
