﻿namespace Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback
{
    public interface IInterviewRecordEventsProcessor<in T>
    {
        void Process(T arg);
    }
}
