﻿using System;
using System.Threading.Tasks;
using Confirmit.CATI.Monitoring.Common.Contracts;

namespace Confirmit.CATI.MonitoringConsole.Classes.EvenSources
{
    /// <summary>
    /// Represents base class for monitoring event sources.
    /// </summary>
    public abstract class EventSource
    {
        /// <summary>
        /// Event occurs when event source recieves new potion of events.
        /// </summary>
        public event EventHandler<GetEventsEventArgs> GetEvents;
        
        public event EventHandler<NotifyMilestonePositionEventArgs> NotifyPosition;

        /// <summary>
        /// Event occurs when video is on the required position after jump
        /// </summary>
        public event EventHandler JumpCompleted;
        
        public event EventHandler Paused;

        /// <summary>
        /// Starts process of getting monitoring events.
        /// </summary>
        public abstract Task Start();

        public abstract void Pause();

        public abstract void Resume();

        public abstract void JumpToMilestone(int pageCompletedEventIndex, int questionSelectedEventIndex);
        public abstract void JumpToPositionInsideMilestone(TimeSpan newPosition);

        public abstract void UpdateAudioEventPosition(TimeSpan clientAudioShift);

        /// <summary>
        /// Fires GetEvents event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        protected void OnGetEvents(GetEventsEventArgs e)
        {
            if (GetEvents != null)
            {
                GetEvents(this, e);
            }
        }

        protected void OnNotifyMilestonePosition(TimeSpan elapsedSeconds)
        {
            NotifyPosition?.Invoke(this, new NotifyMilestonePositionEventArgs(elapsedSeconds));
        }

        protected void OnJumpCompleted()
        {
            if (JumpCompleted != null)
            {
                JumpCompleted(this, null);
            }
        }

        protected void OnPaused()
        {
            if (Paused != null)
            {
                Paused(this, null);
            }
        }

        public abstract void Stop();

        /// <summary>
        /// Notify that audio has been opened and duration of audio calculated
        /// </summary>
        /// <param name="currentAudioRecordId">Index of audio event</param>
        /// <param name="duration">Audio duration</param>
        public abstract void NotifyAudioDuration(AudioIdentityObject currentAudioRecordId, TimeSpan duration);

        /// <summary>
        /// Notify about audio playback has been finished
        /// </summary>
        public abstract void NotifyAudioFinished();
    }

    public class NotifyMilestonePositionEventArgs : EventArgs
    {
        public TimeSpan Elapsed { get; }

        public NotifyMilestonePositionEventArgs(TimeSpan elapsed)
        {
            Elapsed = elapsed;
        }
    }
}
