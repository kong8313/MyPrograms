﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Media;
using System.Xml;
using System.Xml.Linq;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.Monitoring;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Common.WcfTools;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Resources;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Views.Classes.StatusBar;
using Confirmit.CATI.Console.Views.Forms;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.Monitoring.Common.StateData;
using Confirmit.CATI.Monitoring.Common.Tools;
using Confirmit.CATI.MonitoringConsole.Classes;
using Confirmit.CATI.MonitoringConsole.Classes.Download;
using Confirmit.CATI.MonitoringConsole.Classes.EvenSources;
using Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion;
using Confirmit.CATI.MonitoringConsole.Classes.Launch;
using Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback;
using Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback.Writers;
using Confirmit.CATI.MonitoringConsole.Classes.Playback;
using Confirmit.CATI.MonitoringConsole.Classes.Utilities;
using Confirmit.CATI.MonitoringConsole.Interfaces;
using Confirmit.CATI.MonitoringConsole.Properties;
using Confirmit.CATI.MonitoringConsole.Resources;
using Confirmit.CATI.MonitoringConsole.Services.ErrorReportingService;
using Confirmit.CATI.MonitoringConsole.Services.MonitoringService;
using Color = System.Drawing.Color;
using EventInfo = Confirmit.CATI.MonitoringConsole.Classes.EventInfo;

namespace Confirmit.CATI.MonitoringConsole.Presenters
{
    internal class PresenterMainForm
    {
        private const int InformationShowInterval = 20;
        private const string MmsProtocolScheme = "mms";

        private readonly ManualResetEvent _waitGuiThreadResetEvent = new ManualResetEvent(true);
        private DateTime _interviewStartEventTimeStamp;
        private InterviewInitialEventsProvider _interviewInitialEventManager;
        private OfflineMonitoringLaunchInfo _offlineMonitoringLaunchInfo;

        private bool _returnToInitialQuestionDone;
        private string _initialQuestion;
        private TimeSpan _initialQuestionOffset;
        private int _pageCompletedEventIndex; // for our InitialQuestion if it is defined
        private int _questionSelectedEventIndex; // for our InitialQuestion if it is defined
        private MonitoringIdentityInfo _monitoringIdentityInfo;
        private List<AnsweredQuestionsComboBoxItem> _questionsComboBoxItems;
        private bool _firstFakeEventSkipped;
        private readonly bool _fromUri;
        private IAlerter _alerter;
        private DeferredEventSource _eventSource;
        private AudioStartStateData _currentAudioRecordData;
        private bool _audioPlayFailed;

        /// <summary>
        /// Initializes new instance of PresenterMainForm class
        /// and fills it with the given data.
        /// </summary>
        /// <param name="presenterInterview">Interview page control presenter.</param>
        /// <param name="presenterAppointment"></param>
        /// <param name="presenterRedial"></param>
        /// <param name="monitoringModeProvider"></param>
        /// <param name="monitoringIdentityInfoProvider"></param>
        /// <param name="frmMain">Main form view interface.</param>
        /// <param name="statusBar"></param>
        /// <param name="onABreakControl"></param>
        /// <param name="environmentValidator">OS and net framework validator</param>
        /// <param name="fromUri"></param>
        /// <exception cref="ArgumentNullException">presenterInterview, frmMain,
        /// frmLogin or ctlSurveyList are null.</exception>
        public PresenterMainForm(
            PresenterInterview presenterInterview,
            PresenterAppointment presenterAppointment,
            PresenterRedial presenterRedial,
            IMonitoringModeProvider monitoringModeProvider,
            IMonitoringIdentityInfoProvider monitoringIdentityInfoProvider,
            IViewMainPlayerForm frmMain,
            IViewStatusBar statusBar,
            IViewOnABreakControl onABreakControl,
            IEnvironmentValidator environmentValidator,
            bool fromUri)
        {
            MainForm = frmMain ?? throw new ArgumentNullException("frmMain");
            StatusBar = statusBar ?? throw new ArgumentNullException("statusBar");
            OnABreakControl = onABreakControl ?? throw new ArgumentNullException("onABreakControl");
            EnvironmentValidator = environmentValidator ?? throw new ArgumentNullException("environmentValidator");

            PresenterInterview = presenterInterview ?? throw new ArgumentNullException("presenterInterview");
            PresenterAppointment = presenterAppointment ?? throw new ArgumentNullException("presenterAppointment");
            PresenterRedial = presenterRedial ?? throw new ArgumentNullException("presenterRedial");
            _monitoringModeProvider = monitoringModeProvider ?? throw new ArgumentNullException("monitoringModeProvider");
            _monitoringIdentityInfoProvider = monitoringIdentityInfoProvider ?? throw new ArgumentNullException("monitoringIdentityInfoProvider");

            _fromUri = fromUri;
            _alerter = ServiceLocator.Resolve<IAlerter>();

            StatusBar.HideAndNeverShowConnectionIndicator();

            InitEventHandlers();
        }

        protected IViewMainPlayerForm MainForm
        {
            get;
            set;
        }

        protected IViewStatusBar StatusBar
        {
            get;
            set;
        }

        protected IViewOnABreakControl OnABreakControl
        {
            get;
            set;
        }

        protected PresenterInterview PresenterInterview
        {
            get;
            set;
        }

        protected PresenterAppointment PresenterAppointment
        {
            get;
            set;
        }

        protected IEnvironmentValidator EnvironmentValidator
        {
            get;
            set;
        }

        protected PresenterRedial PresenterRedial { get; set; }

        private IMonitoringModeProvider _monitoringModeProvider { get; set; }

        private IMonitoringIdentityInfoProvider _monitoringIdentityInfoProvider { get; set; }

        private bool IsRecordPaused { get; set; }

        /// <summary>
        /// Gets/sets Player object.
        /// </summary>
        protected Player Player
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets worker object which processes downloading files needed for deferred monitoring session.
        /// </summary>
        protected BackgroundWorker DownloadWorker
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets the result of downloading files for deferred monitoring.
        /// This property is null for live monitoring.
        /// </summary>
        private DownloadResult DownloadResult
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets instance of media player which is used for audio files playback.
        /// This property is null for live monitoring.
        /// </summary>
        private MediaPlayer MediaPlayer
        {
            get;
            set;
        }

        public void PlayEvent(EventInfo eventInfo)
        {
            SendOrPostCallback callback = null;
            var messageType = eventInfo.MessageType;
            switch (messageType)
            {
                case MonitoringMessageTypes.GettingInterviewStartMessage:
                    callback = PlayInterviewGettingStartStart;
                    break;
                case MonitoringMessageTypes.InterviewSelectingStartMessage:
                    callback = PlayInterviewSelectingStart;
                    break;
                case MonitoringMessageTypes.PendingBreakMessage:
                    callback = PlayPendingBreak;
                    break;
                case MonitoringMessageTypes.PendingLogoutMessage:
                    callback = PlayPendingLogout;
                    break;
                case MonitoringMessageTypes.PendingLogoutStartMessage:
                    callback = PlayPendingLogoutStart;
                    break;
                case MonitoringMessageTypes.ShowInformationMessage:
                    callback = PlayShowInformation;
                    break;
                case MonitoringMessageTypes.InterviewInitialMessage:
                    callback = PlayInterviewInitial;
                    break;
                case MonitoringMessageTypes.InterviewerLoggedOutMessage:
                    callback = PlayInterviewerLoggedOut;
                    break;
                case MonitoringMessageTypes.ReturnToInitialQuestion:
                    callback = PlayReturnToInitialQuestion;
                    break;
                case MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage:
                    callback = PlayInterviewPageBrowserQuestionSelected;
                    break;
                case MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage:
                    callback = PlayInterviewPageBrowserPageCompleted;
                    break;
                case MonitoringMessageTypes.MonitoringEndMessage:
                case MonitoringMessageTypes.MonitoringEndBySecurityExceptionMessage:
                    callback = PlayMonitoringEnd;
                    break;
                case MonitoringMessageTypes.MonitoringEndBySecurityExceptionOnFirstRequestMessage:
                    callback = PlayMonitoringEndBySecurityExceptionOnFirstRequest;
                    break;
                case MonitoringMessageTypes.RedoDropDownListOpenMessage:
                    callback = PlayRedoDropDownListOpen;
                    break;
                case MonitoringMessageTypes.RedoDropDownListCloseMessage:
                    callback = PlayRedoDropDownListClose;
                    break;
                case MonitoringMessageTypes.RedoQuestionMessage:
                    callback = PlayRedoQuestion;
                    break;
                case MonitoringMessageTypes.InterviewTerminateDialogShownMessage:
                    callback = PlayInterviewTerminateDialogShown;
                    break;
                case MonitoringMessageTypes.InterviewTerminateDialogCloseMessage:
                    callback = PlayInterviewTerminateDialogClose;
                    break;
                case MonitoringMessageTypes.SelectedSurveyLanguageChangedMessage:
                    callback = PlaySelectedSurveyLanguageChanged;
                    break;
                case MonitoringMessageTypes.DialStartMessage:
                    callback = PlayDial;
                    break;
                case MonitoringMessageTypes.TelephonyCompleteMessage:
                    callback = PlayTelephonyComplete;
                    break;
                case MonitoringMessageTypes.HangupMessage:
                    callback = PlayHangup;
                    break;
                case MonitoringMessageTypes.InterviewFinishMessage:
                    callback = PlayInterviewFinish;
                    break;
                case MonitoringMessageTypes.InterviewReviewStartMessage:
                    callback = PlayInterviewReviewStart;
                    break;
                case MonitoringMessageTypes.AudioStartMessage:
                    callback = PlayAudioStart;
                    break;
                case MonitoringMessageTypes.AudioStopMessage:
                    callback = PlayAudioStop;
                    break;
                case MonitoringMessageTypes.AppointmentsListFormShownMessage:
                    callback = PlayAppointmentsListFormShown;
                    break;
                case MonitoringMessageTypes.AppointmentsListFormClosedMessage:
                    callback = PlayAppointmentsListFormClosed;
                    break;
                case MonitoringMessageTypes.CheckSpellingFormShownMessage:
                    callback = PlayCheckSpellingFormShown;
                    break;
                case MonitoringMessageTypes.CheckSpellingFormClosedMessage:
                    callback = PlayCheckSpellingFormClosed;
                    break;
                case MonitoringMessageTypes.OnABreakDialogShownMessage:
                    callback = PlayOnABreakDialogShown;
                    break;
                case MonitoringMessageTypes.OnABreakDialogClosedMessage:
                    callback = PlayOnABreakDialogClosed;
                    break;
                case MonitoringMessageTypes.StartPlaybackMessage:
                    callback = PlayStartPlayback;
                    break;
                case MonitoringMessageTypes.PauseOrResumePlaybackMessage:
                    callback = PlayPauseOrResumePlayback;
                    break;
                case MonitoringMessageTypes.StopPlaybackMessage:
                    callback = PlayStopPlayback;
                    break;
                case MonitoringMessageTypes.ToggleInterviewerListensToPlaybackOrRespondentMessage:
                    callback = PlayToggleInterviewerListensToPlaybackOrRespondent;
                    break;
                case MonitoringMessageTypes.BlankControlShownMessage:
                    callback = PlayBlankControlShownMessage;
                    break;
                case MonitoringMessageTypes.InterviewPageBrowserShownMessage:
                    callback = PlayInterviewPageBrowserShownMessage;
                    break;
                case MonitoringMessageTypes.InterviewStartMessage:
                    callback = PlayInterviewStartMessage;
                    break;
                case MonitoringMessageTypes.InternalCallTransferFormShownMessage:
                    callback = PlayInternalCallTransferFormShownMessage;
                    break;
                case MonitoringMessageTypes.InternalCallTransferFormClosedMessage:
                    callback = PlayInternalCallTransferFormClosedMessage;
                    break;
                case MonitoringMessageTypes.ExternalCallTransferFormShownMessage:
                    callback = PlayExternalCallTransferFormShownMessage;
                    break;
                case MonitoringMessageTypes.ExternalCallTransferFormClosedMessage:
                    callback = PlayExternalCallTransferFormClosedMessage;
                    break;
                case MonitoringMessageTypes.MonitoringNotPermittedMessage:
                    callback = PlayMonitoringNotPermittedMessage;
                    break;
                default:
                    Logger.Write(
                         Strings.ResourceManager.GetString("Warning_UnsupportedEvent", messageType),
                         MessageTypes.Warning);
                    break;
            }
            if (callback == null)
            {
                return;
            }
            if (messageType != MonitoringMessageTypes.MonitoringEndBySecurityExceptionOnFirstRequestMessage)
            {
                MainForm.SynchronizationContext.Post(callback, eventInfo);
            }
            else
            {
                _waitGuiThreadResetEvent.Reset();
                MainForm.SynchronizationContext.Post(callback, eventInfo);
                _waitGuiThreadResetEvent.WaitOne();
            }
        }

        private void PlayMonitoringNotPermittedMessage(object state)
        {
            StatusBar.SetCurrentState("Monitoring not permitted", Color.Red);
        }

        private void PlayInterviewPageBrowserPageCompleted(object eventInfo)
        {
            PresenterAppointment.CloseAppointmentForm();
            PresenterRedial.CloseRedialForm();

            if (_interviewInitialEventManager != null)
            {
                var interviewInitialEvent =
                    _interviewInitialEventManager.GetNearestLeft(((EventInfo)eventInfo).TimeStamp);
                UpdateStatusBarInformation((InterviewingInitialStateData)interviewInitialEvent.State);
            }

            if (MainForm.IsProcessControlVisible())
            {
                MainForm.ShowInterviewPageControl();
            }
        }

        private void PlayInterviewPageBrowserQuestionSelected(object eventInfo)
        {
            var info = (EventInfo)eventInfo;
            var eventData = (QuestionSelectedStateData)info.State;

            if (_initialQuestion != null && _initialQuestion.Equals(eventData.QuestionId) && _returnToInitialQuestionDone)
            {
                IsRecordPaused = true;
                Player.Pause();

                MainForm.UpdatePausePlayButtonState(IsRecordPaused);

                _initialQuestion = null; // pause only once after jump, later no pause or jumping

                return;
            }

            MainForm.ShowInterviewPageControl();

            if (AnsweredQuestionsProvider.IsQuestionSupported(eventData) == false) return;

            StatusBar.CurrentPosition =
                new AnsweredQuestionFormatter().GetPositionForStatusBar(eventData.QuestionId,
                    _eventSource?.CurrentMilestone?.Offset);
        }

        private void PlayReturnToInitialQuestion(object eventInfo)
        {
            // We skip first fake event because we need to play question until its end
            if (_firstFakeEventSkipped == false)
            {
                _firstFakeEventSkipped = true;
                return;
            }

            if (string.IsNullOrWhiteSpace(_initialQuestion))
            {
                return;
            }

            JumpToInitialQuestion();
            _returnToInitialQuestionDone = true;
        }

        private void JumpToInitialQuestion()
        {
            StatusBar.CurrentPosition = new AnsweredQuestionFormatter().GetPositionForStatusBar(_initialQuestion, _initialQuestionOffset);

            MainFormDeferredRecordJumpToMilestone(this, new JumpToQuestionEventArgs()
            {
                PageCompletedEventIndex = _pageCompletedEventIndex,
                QuestionSelectedEventIndex = _questionSelectedEventIndex
            });
        }

        /// <summary>
        /// Plays Monitroring end event
        /// Close MainForm
        /// </summary>
        private void PlayMonitoringEnd(object eventInfo)
        {
            MainForm.CloseForm();
        }

        /// <summary>
        /// Plays MonitoringEndBySecurityExceptionOnFirstRequestMessage event        
        /// </summary>
        private void PlayMonitoringEndBySecurityExceptionOnFirstRequest(object eventInfo)
        {
            _alerter.Alert(Strings.Error_CommunicationError, Strings.Caption_Error, MessageTypes.Error);
            MainForm.CloseForm();
            _waitGuiThreadResetEvent.Set();
        }

        /// <summary>
        /// Plays InterviewerLoggedOut event. Shows message in status bar.
        /// </summary>
        /// <param name="eventInfo">Event info.</param>
        private void PlayInterviewerLoggedOut(object eventInfo)
        {
            /*ega Add resources*/
            StatusBar.InterviewName = String.Empty;
            StatusBar.SurveyName = String.Empty;
            StatusBar.SetCurrentState("Interviewer is logged out");
        }

        /// <summary>
        /// Plays AppointmentFormInitial event
        /// Fills controls on form with passed values and shows form
        /// </summary>
        private void PlayRedoQuestion(object eventInfo)
        {
            /*ega Add resources*/
            var eventData = (RedoQuestionStateData)(((EventInfo)eventInfo).State);
            StatusBar.ShowInformation(string.Format("Redo for question {0}", eventData.QuestionId), InformationShowInterval);
        }

        /// <summary>
        /// Plays InterviewTerminateDialogShown event        
        /// </summary>
        private void PlayInterviewTerminateDialogShown(object eventInfo)
        {
            /*ega Add resources*/
            StatusBar.ShowInformation("Termination dialog is shown");
        }

        /// <summary>
        /// Plays InterviewTerminateDialogClose event        
        /// </summary>
        private void PlayInterviewTerminateDialogClose(object eventInfo)
        {
            StatusBar.ClearInformation();
        }


        /// <summary>
        /// Plays AppointmentFormInitial event
        /// Fills controls on form with passed values and shows form
        /// </summary>
        private void PlayRedoDropDownListOpen(object eventInfo)
        {
            /*ega Add resources*/
            StatusBar.ShowInformation("Redo list is opened");
        }

        /// <summary>
        /// Plays ShowInformation event
        /// </summary>
        private void PlayShowInformation(object eventInfo)
        {
            var data = ((EventInfo)eventInfo).State as ShowInformationStateData;

            StatusBar.ShowInformation(data.Message);
        }

        /// <summary>
        /// Plays AppointmentFormInitial event
        /// Fills controls on form with passed values and shows form
        /// </summary>
        private void PlayRedoDropDownListClose(object eventInfo)
        {
            StatusBar.ClearInformation();
        }

        /// <summary>
        /// Plays SelectedSurveyLanguageChanged event
        /// </summary>
        private void PlaySelectedSurveyLanguageChanged(object eventInfo)
        {
            /*ega Add resources*/
            var data = ((EventInfo)eventInfo).State as SelectedSurveyLanguageChangedStateData;

            if (data != null)
            {
                var message = string.Format("Language changed from {0} to {1}",
                                            data.PreviousLanguageName,
                                            data.NewLanguageName);

                StatusBar.ShowInformation(message, InformationShowInterval);
            }
        }

        /// <summary>
        /// Plays DialStartMessage event. Shows message in status bar.
        /// </summary>
        /// <param name="eventInfo"></param>
        private void PlayDial(object eventInfo)
        {
            StatusBar.SetCurrentState("Dialing");
            /*ega Add resources*/
            StatusBar.ShowInformation("Dial process has been started", InformationShowInterval);
            var data = ((EventInfo)eventInfo).State as DialStartData;

            if (data != null)
            {
                MainForm.ShowProcessControl(data.Message);
            }
        }

        /// <summary>
        /// Plays TelephonyCompleteMessage event.
        /// Shows message with telephony result status in status bar.
        /// </summary>
        private void PlayTelephonyComplete(object eventInfo)
        {
            DisplayConsoleState(ConsoleState.Interviewing);

            /* ega Add resources */
            var data = ((EventInfo)eventInfo).State as TelephonyResultData;

            if (data != null)
            {
                StatusBar.ShowInformation(
                    string.Format("Command completed with status {0}", data.Status),
                    InformationShowInterval);
            }

            MainForm.ShowInterviewPageControl();
        }

        /// <summary>
        /// Plays HangupMessage event. Shows message in status bar.
        /// </summary>
        /// <param name="eventInfo">Event info.</param>
        private void PlayHangup(object eventInfo)
        {
            /* ega Add resources */
            StatusBar.ShowInformation("Connection is hanged up", InformationShowInterval);
        }

        private void PlayStartPlayback(object eventInfo)
        {
            var data = ((EventInfo)eventInfo).State as StartPlaybackData;

            if (data != null)
            {
                StatusBar.ShowInformation(
                    string.Format("Playback of voice fragment {0} is started", data.FileName),
                    InformationShowInterval);
            }
        }

        private void PlayPauseOrResumePlayback(object eventInfo)
        {
            StatusBar.ShowInformation("Voice fragment playback paused or resumed", InformationShowInterval);
        }

        private void PlayStopPlayback(object eventInfo)
        {
            StatusBar.ShowInformation("Voice fragment playback stopped", InformationShowInterval);
        }

        private void PlayToggleInterviewerListensToPlaybackOrRespondent(object eventInfo)
        {
            StatusBar.ShowInformation("Voice source toggled", InformationShowInterval);
        }

        private string GetDefaultTitle()
        {
            return "Monitoring Console";
        }

        /// <summary>
        /// Plays InterviewInitialMessage event. Shows data in status bar.
        /// </summary>
        /// <param name="eventInfo">Event info.</param>
        private void PlayInterviewInitial(object eventInfo)
        {
            /* ega Add resources */
            var s = ((EventInfo)eventInfo).State as InterviewingInitialStateData;
            UpdateStatusBarInformation(s);

            var title = GetDefaultTitle();
            var color = MainForm.DefaultControlColor;

            if (s.IsInboundCall)
            {
                color = System.Drawing.Color.YellowGreen;
            }

            if (s.IsTestMode)
            {
                title = "Monitoring Console - TEST MODE";
                color = System.Drawing.Color.Gold;
            }

            MainForm.SpecifyMainFormStyle(title, color, s.IsInboundCall, s.IsTestMode);
            PresenterInterview.HighlightEnterZone(color);

            PresenterAppointment.CloseAppointmentForm();
            PresenterRedial.CloseRedialForm();

            Logger.Write(Strings.ResourceManager.GetString(
                "Info_InterviewInitialMessage",
                UserPassport.Instance.CurrentIdentityInfo?.InterviewerName, SurveyNameFormatter.FormatSurveyName(s.SurveyId, s.SurveyName),
                s.InterviewId),
                MessageTypes.Information);
        }

        /// <summary>
        /// Plays InterviewGettingStartStart event. Shows data in status bar.
        /// </summary>
        private void PlayInterviewGettingStartStart(object eventInfo)
        {
            /* ega Add resources */
            StatusBar.SetCurrentState("Getting new interview");
        }

        /// <summary>
        /// Plays InterviewSelectingStart event. Shows data in status bar.
        /// </summary>
        private void PlayInterviewSelectingStart(object eventInfo)
        {
            /* ega Add resources */
            DisplayConsoleState(ConsoleState.Selecting);
        }

        /// <summary>
        /// Plays PendingBreak event. Shows information in the status bar.
        /// </summary>
        private void PlayPendingBreak(object eventInfo)
        {
            /* ega Add resources */
            var s = ((EventInfo)eventInfo).State as PendingBreakStateData;
            StatusBar.PendingBreakState = s.Enabled ? "Enabled" : String.Empty;
        }

        /// <summary>
        /// Plays PendingLogoutStart event. Shows data in status bar.
        /// </summary>
        private void PlayPendingLogout(object eventInfo)
        {
            /* ega Add resources */
            var s = ((EventInfo)eventInfo).State as PendingLogoutStateData;

            if (s.Enabled)
            {
                StatusBar.PendingLogoutState = "Enabled";
            }
            else
            {
                StatusBar.PendingLogoutState = String.Empty;
            }
        }

        /// <summary>
        /// Plays PendingLogoutStart event. Shows data in status bar.
        /// </summary>
        private void PlayPendingLogoutStart(object eventInfo)
        {
            /* ega Add resources */
            StatusBar.SetCurrentState("Pending logout");
        }

        /// <summary>
        /// Plays InteviewFinishMessage event. Clears data in status bar.
        /// </summary>
        /// <param name="eventInfo">Event info.</param>
        private void PlayInterviewFinish(object eventInfo)
        {
            StatusBar.SurveyName = String.Empty;
            StatusBar.InterviewName = String.Empty;
            StatusBar.ClearInformation();

            MainForm.SpecifyMainFormStyle("", MainForm.DefaultControlColor, false, false);
            PresenterInterview.HighlightEnterZone(MainForm.DefaultControlColor);

            //if play deferred events then stop at the end with pause and need additional state
            if (_eventSource != null)
            {
                StatusBar.SetCurrentState("Finished");
            }
        }

        /// <summary>
        /// Plays InteviewReviewStartMessage event. Clears data in status bar.
        /// </summary>
        /// <param name="eventInfo">Event info.</param>
        private void PlayInterviewReviewStart(object eventInfo)
        {
            /* ega Add resources */
            //When openend review is started 'InterviewInitialMessage'event is occured
            // StatusBar.InterviewMode = "Openend review";
        }

        public void NotifyMilestonePosition(TimeSpan elapsed)
        {
            MainForm.UpdateCurrentMilestonePosition(elapsed);
        }

        public void NotifyPaused()
        {
            PauseRecord();
        }

        /// <summary>
        /// Plays AudioStartMessage event. Starts playing audio record.
        /// </summary>
        /// <param name="eventInfo">Event info.</param>
        private void PlayAudioStart(object eventInfo)
        {
            var data = ((EventInfo)eventInfo).State as AudioStartStateData;
            _currentAudioRecordData = data;

            if (data == null || data.AudioRecordID == null)
            {
                Logger.Write(
                    Strings.ResourceManager.GetString("Error_AudioStartStateError"),
                    MessageTypes.Error);

                return;
            }

            if (DownloadResult == null || !DownloadResult.AudioFiles.ContainsKey(data.AudioRecordID))
            {
                Logger.Write(
                    Strings.ResourceManager.GetString("Error_AudioNotFound", data.AudioRecordID.ToString()),
                    MessageTypes.Error);
            }
            else
            {
                var url = new Uri(DownloadResult.AudioFiles[data.AudioRecordID]);

                // stop playing in a case that playing is in progress
                MediaPlayer.Stop();

                //TODO: we can download each audio beforehand but we need several MediaPlayer in this case.
                if (MediaPlayer.Source != url)
                {
                    MediaPlayer.Open(url);
                }
                else
                {
                    if (!_audioPlayFailed)
                        SetMediaPlayerPosition();
                    else
                        ShowPlayFailedInfo();
                }
            }

            if (_returnToInitialQuestionDone)
            {
                _returnToInitialQuestionDone = false;
                MediaPlayer.Pause();
                IsRecordPaused = true;
                MainForm.EnableAudioToolbar(false);
            }
        }

        private void MediaPlayer_MediaFailed(object sender, ExceptionEventArgs e)
        {
            _audioPlayFailed = true;
            var failedException = new InvalidOperationException("Player cannot play the file. Possible incorrect audio format", e.ErrorException);
            Logger.Write(failedException);
            ShowPlayFailedInfo();
        }

        private void ShowPlayFailedInfo()
        {
            StatusBar.ShowInformation("Player cannot play the audio", Color.Red);
        }

        private void MediaPlayer_MediaOpened(object sender, EventArgs e)
        {
            _audioPlayFailed = false;
            StatusBar.ClearInformation();
            SetMediaPlayerPosition();
        }

        /// <summary>
        /// Handles media player MediaEnded event.
        /// </summary>
        /// <param name="sender">Event sender.</param>
        /// <param name="e">Event arguments.</param>
        void MediaPlayer_MediaEnded(object sender, EventArgs e)
        {
            MainForm.EnableAudioToolbar(false);
            Player?.NotifyAudioFinished();
        }

        private void SetMediaPlayerPosition()
        {
            if (_currentAudioRecordData?.AudioRecordID == null) return;

            NotifyAudioDuration();

            var isRecordFinished = false;
            if (MediaPlayer.NaturalDuration.HasTimeSpan)
            {
                if (_currentAudioRecordData.StartAudioOffset < MediaPlayer.NaturalDuration.TimeSpan)
                {
                    MediaPlayer.Position = _currentAudioRecordData.StartAudioOffset;
                }
                else
                {
                    MediaPlayer.Stop();
                    MediaPlayer_MediaEnded(this, new EventArgs());
                    isRecordFinished = true;
                }
            }
            else
            {
                MediaPlayer.Position = _currentAudioRecordData.StartAudioOffset;
            }

            if (!_returnToInitialQuestionDone && !IsRecordPaused && !isRecordFinished)
            {
                MediaPlayer.Play();
                MainForm.EnableAudioToolbar(true);
            }
        }

        private void NotifyAudioDuration()
        {
            if (MediaPlayer != null && MediaPlayer.NaturalDuration.HasTimeSpan && _currentAudioRecordData != null && !_currentAudioRecordData.HasDuration)
            {
                Player?.NotifyAudioDuration(_currentAudioRecordData.AudioRecordID, MediaPlayer.NaturalDuration.TimeSpan);
            }
        }

        private void PlayAudioStop(object eventInfo)
        {
            MediaPlayer.Stop();
            MainForm.EnableAudioToolbar(false);
        }

        private void PlayAppointmentsListFormShown(object eventInfo)
        {
            /* ega Add resources */
            StatusBar.SetCurrentState("Appointments list is shown");
        }

        private void PlayAppointmentsListFormClosed(object eventInfo)
        {
            /* ega Add resources */
            var s = ((EventInfo)eventInfo).State as AppointmentListFormClosedStateData;

            DisplayConsoleState(s.ConsoleState);
        }

        private void PlayCheckSpellingFormShown(object eventInfo)
        {
            /* ega Add resources */
            StatusBar.SetCurrentState("Check spelling form is shown");
        }

        private void PlayCheckSpellingFormClosed(object eventInfo)
        {
            /* ega Add resources */
            var s = ((EventInfo)eventInfo).State as CheckSpellingFormClosedStateData;

            DisplayConsoleState(s.ConsoleState);
        }

        private void PlayInternalCallTransferFormShownMessage(object eventInfo)
        {
            // Move to resources
            StatusBar.SetCurrentState("Internal call transfer form is shown");
        }

        private void PlayInternalCallTransferFormClosedMessage(object eventInfo)
        {
            var s = ((EventInfo)eventInfo).State as InternalCallTransferFormClosedStateData;

            DisplayConsoleState(s.ConsoleState);
        }

        private void PlayExternalCallTransferFormShownMessage(object eventInfo)
        {
            // Move to resources
            StatusBar.SetCurrentState("External call transfer form is shown");
        }

        private void PlayExternalCallTransferFormClosedMessage(object eventInfo)
        {
            var s = ((EventInfo)eventInfo).State as ExternalCallTransferFormClosedStateData;

            DisplayConsoleState(s.ConsoleState);
        }

        private void PlayOnABreakDialogShown(object eventInfo)
        {
            var s = ((EventInfo)eventInfo).State as OnABreakDialogShownInitialStateData;

            OnABreakControl.StartTime = s.StartTime;
            MainForm.ShowOnABreakControl(s.DisplayBreakType, s.BreakInfo);

            StatusBar.PendingBreakState = String.Empty;
            DisplayConsoleState(ConsoleState.InterviewerOnABreak);
        }

        private void PlayOnABreakDialogClosed(object eventInfo)
        {
            MainForm.ShowInterviewPageControl();

            DisplayConsoleState(ConsoleState.Selecting);
        }

        private void PlayBlankControlShownMessage(object eventInfo)
        {
            MainForm.ShowBlankControl();
        }

        private void PlayInterviewPageBrowserShownMessage(object eventInfo)
        {
            MainForm.ShowInterviewPageControl();
        }

        private void PlayInterviewStartMessage(object eventInfo)
        {
            PresenterAppointment.CloseAppointmentForm();
            PresenterRedial.CloseRedialForm();

            StatusBar.CurrentPosition = string.Empty;
            StatusBar.SetCurrentState("Waiting for the first page");

            var stateData = ((EventInfo)eventInfo).State as InterviewStartStateData;
            MainForm.EnableAnsweredQuestionCombobox(stateData.IsJumpingSupported);
        }

        private void CurrentMilestoneUpdated(object sender, MilestoneEvent e)
        {
            MainForm.ChangeMilestone(_eventSource?.CurrentMilestone?.Duration);
        }

        private void DisplayConsoleState(ConsoleState s)
        {
            switch (s)
            {
                case ConsoleState.Selecting:
                    StatusBar.SetCurrentState("Selecting interview");
                    break;
                case ConsoleState.Interviewing:
                    StatusBar.SetCurrentState("Interviewing");
                    break;
                case ConsoleState.Reviewing:
                    StatusBar.SetCurrentState("Openend review");
                    break;
                case ConsoleState.InterviewerOnABreak:
                    StatusBar.SetCurrentState("Interviewer on a break");
                    break;
            }
        }

        /// <summary>
        /// Initializes event handlers.
        /// </summary>
        private void InitEventHandlers()
        {
            MainForm.FormLoad += MainForm_FormLoad;
            MainForm.FormClose += MainForm_FormClose;
            MainForm.AudioForwardRewind += MainForm_AudioForwardRewind;
            MainForm.AudioBackwardRewind += MainForm_AudioBackwardRewind;
            MainForm.DefferedRecordPausePlay += MainForm_DeferredRecordPausePlay;
            MainForm.DeferredRecordJumpToMilestone += MainFormDeferredRecordJumpToMilestone;
            MainForm.DeferredRecordJumpToNextMilestone += MainFormDeferredRecordJumpToNextMilestone;
            MainForm.DeferredRecordJumpToPrevMilestone += MainFormDeferredRecordJumpToPrevMilestone;
            MainForm.DeferredRecordJumpToPosition += MainFormDeferredRecordJumpToPosition;
            MainForm.SaveOfflinePlaybackRecord += SaveOfflinePlaybackFile;
            MainForm.SetListeningMode += MainForm_SetListeningMode;
            MainForm.SetCoachingMode += MainForm_SetCoachingMode;
            MainForm.SetBargingMode += MainForm_SetBargingMode;
        }

        private void MainForm_FormLoad(object sender, EventArgs e)
        {
            InitApplication();

            RemoveShortCutFolder();

            if (!EnvironmentValidator.IsEnvironmentSupported())
            {
                _alerter.Alert(
                    EnvironmentValidator.GetWarning(
                        Strings.ApplicationNotSupportedMessageTextTemplate,
                        Strings.ApplicationNotSupportedOSVersionMessageTextTemplate,
                        Strings.ApplicationNotSupportedNetVersionMessageTextTemplate),
                    Strings.ApplicationNotSupportedMessageCaption,
                    MessageTypes.Warning);
            }

            if (!EnvironmentValidator.IsIeVersionSupported())
            {
                _alerter.Alert(
                    Strings.ApplicationNotSupportedIEVersionMessageTextTemplate,
                    Strings.ApplicationNotSupportedMessageCaption,
                    MessageTypes.Warning);
            }

            if (CheckLicenseAgreements() == false)
            {
                MainForm.CloseForm();
                return;
            }

            StatusBar.Version = ApplicationManager.AssemblyVersion;

            var argumentsManager = ApplicationManager.ActivationArgumentsManager;

            if (argumentsManager.HaveActivationArguments() == false)
            {
                MainForm.CloseForm();
                return;
            }

            _monitoringIdentityInfo = _fromUri
                ? _monitoringIdentityInfoProvider.GetFromParameters(argumentsManager.GetActivationDataParams())
                : _monitoringIdentityInfoProvider.GetFromFile(argumentsManager.GetActivationDataPath());

            UserPassport.Instance.CurrentIdentityInfo = _monitoringIdentityInfo;

            InitServerLogging();

            switch (_monitoringIdentityInfo.LaunchType)
            {
                case LaunchFileType.OfflineMonitoring:
                    {
                        var launchManager = new LaunchManager(argumentsManager.GetActivationDataPath());
                        _offlineMonitoringLaunchInfo = launchManager.ReadOfflineLaunchInfo();
                        StartOfflineSession(_offlineMonitoringLaunchInfo);
                        break;
                    }
                case LaunchFileType.LiveMonitoring:
                    StartLiveSession(_monitoringIdentityInfo);
                    break;
                case LaunchFileType.DeferredMonitoring:
                    StartDeferredSession(_monitoringIdentityInfo);
                    break;
                default:
                    Logger.Write(Strings.ResourceManager.GetString("Error_UnsupportedStartFile", _monitoringIdentityInfo.LaunchType), MessageTypes.Error);
                    break;
            }
        }


        /// <summary>
        /// Initializes listener which sends log to Backend service.
        /// </summary>
        private static void InitServerLogging()
        {
            if (Settings.Default.EnableServerLog)
            {
                Logger.InitWsListener(
                    UserPassport.Instance.CurrentIdentityInfo == null ? string.Empty : UserPassport.Instance.CurrentIdentityInfo.CompanyAlias,
                    Constants.HashKey,
                    ClientErrorSource.MonitorError,
                    new MonitoringConsoleInfoProvider(),
                    new ErrorReportingServiceAuthenticationDataProvider(),
                    new MessageHeaderAccessor(),
                    new MonitoringErrorSender());
            }
        }

        private void RemoveShortCutFolder()
        {
            try
            {
                string productName;
                string publisher = GetPublisherAndProduct(out productName);
                string programsFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), publisher);

                if (Directory.Exists(programsFolder))
                {
                    string fileName = Path.Combine(programsFolder, productName + ".appref-ms");

                    if (File.Exists(fileName))
                    {
                        var destFileName = Path.Combine(
                            Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location),
                            LiteralConstants.LauncherName);

                        if (File.Exists(destFileName))
                        {
                            File.Delete(fileName);
                        }
                        else
                        {
                            File.Move(fileName, destFileName);
                        }
                    }

                    if (Directory.GetDirectories(programsFolder).Length == 0 &&
                       Directory.GetFiles(programsFolder).Length == 0)
                    {
                        Directory.Delete(programsFolder);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Write("A minor error occured during removing a menu shortcut:\r\n" + ex, MessageTypes.Warning);
            }
        }

        private string GetPublisherAndProduct(out string productName)
        {
            XDocument xDocument;

            using (var memoryStream = new MemoryStream(AppDomain.CurrentDomain.ActivationContext.DeploymentManifestBytes))
            using (var xmlTextReader = new XmlTextReader(memoryStream))
            {
                xDocument = XDocument.Load(xmlTextReader);
            }

            var description = xDocument.Root.Elements().First(x => x.Name.LocalName == "description");
            string publisher = description.Attributes().First(x => x.Name.LocalName == "publisher").Value;
            string product = description.Attributes().First(x => x.Name.LocalName == "product").Value;

            productName = product;

            return publisher;
        }

        /// <summary>
        /// Handles FormClose event of main from.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        private void MainForm_FormClose(object sender, EventArgs e)
        {
            StopMonitoringSession(UserPassport.Instance.CurrentIdentityInfo);
            try
            {
                Logger.Write(Strings.ResourceManager.GetString("Info_MonitoringClosed", _monitoringIdentityInfo.LaunchType), MessageTypes.Information);

            }
            catch { };

            ClearResources();
        }

        private void StopMonitoringSession(MonitoringIdentityInfo identityInfo)
        {
            if (identityInfo != null && identityInfo.LaunchType == LaunchFileType.LiveMonitoring)
            {
                MonitoringServiceManager.StopSession(
                    identityInfo.SupervisorName,
                    identityInfo.InterviewerId,
                    identityInfo.MonitoringSessionId
                    );
            }
        }

        /// <summary>
        /// Handles main form AudioForwardRewind event.
        /// </summary>
        /// <param name="sender">Event sender.</param>
        /// <param name="e">Event arguments.</param>
        void MainForm_AudioForwardRewind(object sender, EventArgs e)
        {
            /*Rewinds media player position forward */

            if (MediaPlayer != null)
            {
                var shift = TimeSpan.FromSeconds(Settings.Default.AudioRewindInterval);

                MediaPlayer.Position += shift;

                Player.UpdateAudioEventPosition(shift);
            }
        }

        /// <summary>
        /// Handles main form AudioBackwardRewind event.
        /// </summary>
        /// <param name="sender">Event sender.</param>
        /// <param name="e">Event arguments.</param>
        void MainForm_AudioBackwardRewind(object sender, EventArgs e)
        {
            if (MediaPlayer != null)
            {
                var shift = TimeSpan.FromSeconds(Settings.Default.AudioRewindInterval);

                MediaPlayer.Position -= shift;

                Player.UpdateAudioEventPosition(TimeSpan.FromSeconds(shift.Seconds * -1));
            }
        }

        void MainForm_DeferredRecordPausePlay(object sender, EventArgs e)
        {
            PlayPauseRecord();
        }

        void MainFormDeferredRecordJumpToMilestone(object sender, JumpToQuestionEventArgs e)
        {
            if (Player == null) return;

            if (MediaPlayer != null)
            {
                _currentAudioRecordData = null;
                MediaPlayer.Stop();
                MainForm.EnableAudioToolbar(false);
            }

            Player.JumpToQuestion(e.PageCompletedEventIndex, e.QuestionSelectedEventIndex);

            // we should reset InitialQuestion if we jump manually from combobox
            if (sender.GetType() == typeof(MainForm))
            {
                _initialQuestion = null;
            }
        }

        private void MainFormDeferredRecordJumpToPrevMilestone(object sender, EventArgs e)
        {
            var prevMilestone = _eventSource?.MilestoneProvider?.GetPrevMilestone();
            if (prevMilestone == null) return;

            MainFormDeferredRecordJumpToMilestone(sender, new JumpToQuestionEventArgs()
            {
                QuestionSelectedEventIndex = prevMilestone.IndexOfEvent,
                PageCompletedEventIndex = prevMilestone.IndexOfEventContentLoad
            });
        }

        private void MainFormDeferredRecordJumpToNextMilestone(object sender, EventArgs e)
        {
            var nextMilestone = _eventSource?.MilestoneProvider?.GetNextMilestone();
            if (nextMilestone == null) return;

            MainFormDeferredRecordJumpToMilestone(sender, new JumpToQuestionEventArgs()
            {
                QuestionSelectedEventIndex = nextMilestone.IndexOfEvent,
                PageCompletedEventIndex = nextMilestone.IndexOfEventContentLoad
            });
        }

        private void MainFormDeferredRecordJumpToPosition(object sender, TimeSpan newPosition)
        {
            Player?.JumpToPosition(newPosition);
        }

        private void MainForm_SetListeningMode(object sender, EventArgs e)
        {
            MainForm.SetListeningToolbarMode(MonitoringMode.Listening);
            _monitoringModeProvider.SetLiveMonitoringMode(MonitoringMode.Listening);
        }

        private void MainForm_SetCoachingMode(object sender, EventArgs e)
        {
            MainForm.SetListeningToolbarMode(MonitoringMode.Coaching);
            _monitoringModeProvider.SetLiveMonitoringMode(MonitoringMode.Coaching);
        }

        private void MainForm_SetBargingMode(object sender, EventArgs e)
        {
            if (MessageBox.Show(Strings.Question_SetBargingMode, Strings.Caption_Warning, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
            {
                return;
            }

            MainForm.SetListeningToolbarMode(MonitoringMode.Barging);
            _monitoringModeProvider.SetLiveMonitoringMode(MonitoringMode.Barging);
        }

        private void PlayPauseRecord()
        {
            if (IsRecordPaused)
                PlayRecord();
            else
                PauseRecord();
        }

        private void PlayRecord()
        {
            if (Player == null) return;

            if (MediaPlayer != null
                && MediaPlayer.NaturalDuration != Duration.Automatic
                && MediaPlayer.Position < MediaPlayer.NaturalDuration.TimeSpan
                && _currentAudioRecordData?.AudioRecordID != null)
            {
                MainForm.EnableAudioToolbar(true);
                MediaPlayer.Play();
            }

            IsRecordPaused = false;
            Player.Resume();

            MainForm.UpdatePausePlayButtonState(IsRecordPaused);
        }

        private void PauseRecord()
        {
            if (Player == null) return;

            if (MediaPlayer != null)
            {
                if (MediaPlayer.Dispatcher != null && !MediaPlayer.Dispatcher.CheckAccess())
                    MediaPlayer.Dispatcher.Invoke(() => MediaPlayer.Pause());
                else
                    MediaPlayer.Pause();

                MainForm.EnableAudioToolbar(false);
            }

            IsRecordPaused = true;
            Player.Pause();

            MainForm.UpdatePausePlayButtonState(IsRecordPaused);
        }

        private void SaveOfflinePlaybackFile(object sender, EventArgs e)
        {
            if (!IsRecordPaused)
            {
                PlayPauseRecord();
            }

            var fileName = GetOfflinePlaybackFileName();

            if (string.IsNullOrWhiteSpace(fileName))
            {
                return;
            }

            var interviewRecordCreator = CreateInterviewRecordCreator();

            var downloadRecordDialog = new CreateInterviewRecordProgressDialog();

            downloadRecordDialog.SetCreator(interviewRecordCreator);
            downloadRecordDialog.Load += (o, args) => interviewRecordCreator.StartInterviewRecordCreation(
                fileName,
                UserPassport.Instance.CurrentIdentityInfo,
                UserPassport.Instance.InterviewInfo.ProjectId,
                UserPassport.Instance.InterviewInfo.InterviewId);

            if (downloadRecordDialog.ShowDialog() != DialogResult.OK)
            {
                interviewRecordCreator.CancelRecordCreation();
            }
        }

        private InterviewRecordCreator CreateInterviewRecordCreator()
        {
            return new InterviewRecordCreator(
                new MonitoringService(),
                new AudioService(),
                new InterviewRecordPackageWriter(),
                new Logger());
        }

        private string GetOfflinePlaybackFileName()
        {
            var currentIdentityInfo = UserPassport.Instance.CurrentIdentityInfo;
            var interviewInfo = UserPassport.Instance.InterviewInfo;

            var saveFileDialog = new SaveFileDialog
            {
                Filter = string.Format(Strings.OfflineRecordFilterString, "cspo"),
                FileName = string.Format(
                    Strings.OfflineRecordFileName,
                    interviewInfo.ProjectId,
                    interviewInfo.InterviewId,
                    currentIdentityInfo.TimeStamp,
                    currentIdentityInfo.InterviewerId),
                FilterIndex = 0,
                RestoreDirectory = true
            };

            if (saveFileDialog.ShowDialog() != DialogResult.OK)
            {
                return null;
            }

            return saveFileDialog.FileName;
        }

        private void StartLiveSession(MonitoringIdentityInfo identityInfo)
        {
            Logger.Write(Strings.ResourceManager.GetString("Info_LiveMonitoringSessionStarted"), MessageTypes.Information);

            var monitoringOptions = _monitoringIdentityInfoProvider.GetMonitoringOptions();

            Player = new Player(
                this,
                PresenterInterview,
                PresenterAppointment,
                PresenterRedial,
                new LiveEventSource()
            );

            _interviewInitialEventManager = null;

            Player.Start();
            StatusBar.Mode = StatusBarModes.MainViewPlayer;
            StatusBar.UserName = identityInfo.InterviewerName;
            StatusBar.CurrentPosition = string.Empty;
            MainForm.ShowDeferredToolbar(false);
            MainForm.ShowAudioToolbar(false);

            if (monitoringOptions.IsCoachingModeAllowed || monitoringOptions.IsBargingModeAllowed)
            {
                MainForm.ShowLiveToolbar(true);

                MainForm.ShowCoachingToolbarButton(monitoringOptions.IsCoachingModeAllowed);
                MainForm.ShowBargingToolbarButton(monitoringOptions.IsBargingModeAllowed);

                MainForm.SetListeningToolbarMode(MonitoringMode.Listening);
            }
            else
            {
                MainForm.ShowLiveToolbar(false);
            }
        }

        private void StartDeferredSession(MonitoringIdentityInfo identityInfo)
        {
            Logger.Write(Strings.ResourceManager.GetString("Info_DeferredMonitoringSessionStarted"), MessageTypes.Information);

            StatusBar.Mode = StatusBarModes.LoginView;
            MainForm.ShowAudioToolbar(true);
            MainForm.EnableAudioToolbar(false);
            MainForm.ShowDeferredToolbar(true);
            MainForm.EnableDeferredToolbar(false);
            MainForm.ShowLiveToolbar(false);
            MainForm.UpdatePausePlayButtonState(IsRecordPaused);
            MainForm.ShowProcessControl(Strings.Message_DownloadInProgress);

            DownloadWorker = new BackgroundWorker();
            DownloadWorker.DoWork += DownloadWorker_DoWork;
            DownloadWorker.RunWorkerCompleted += DownloadWorker_RunWorkerCompleted;

            DownloadWorker.RunWorkerAsync();
        }

        private void StartOfflineSession(OfflineMonitoringLaunchInfo launchInfo)
        {
            Logger.Write(Strings.ResourceManager.GetString("Info_OfflineMonitoringSessionStarted"), MessageTypes.Information);

            StatusBar.Mode = StatusBarModes.LoginView;
            MainForm.ShowAudioToolbar(true);
            MainForm.EnableAudioToolbar(false);
            MainForm.ShowDeferredToolbar(true);
            MainForm.EnableDeferredToolbar(false);
            MainForm.ShowLiveToolbar(false);
            MainForm.ShowProcessControl(Strings.Message_DownloadInProgress);

            var monitoringManager = new OfflineMonitoringManager(launchInfo);
            var events = monitoringManager.GetEvents();

            var stateEventInfos = events as IList<StateEventInfo> ?? events.ToList();
            var audioEvents = stateEventInfos.Where(x => x.MessageType == MonitoringMessageTypes.AudioStartMessage).ToArray();

            UpdateAudioEventFilePath(audioEvents, launchInfo);

            _interviewInitialEventManager = new InterviewInitialEventsProvider(stateEventInfos);
            _interviewStartEventTimeStamp = stateEventInfos.First(x => x.MessageType == MonitoringMessageTypes.InterviewStartMessage).TimeStamp;

            var audioFiles = monitoringManager.GetAudioFiles();
            var eventSource = new DeferredEventSource(stateEventInfos);

            DownloadResult = new DownloadResult { AudioFiles = audioFiles, EventSource = eventSource };

            StartMonitoringSessionPlay(audioFiles, eventSource);
        }

        private void UpdateAudioEventFilePath(StateEventInfo[] audioEvents,
            OfflineMonitoringLaunchInfo launchInfo)
        {
            if (!audioEvents.Any() || !launchInfo.AudioFilesPaths.Any())
            {
                return;
            }

            var newAudioIdentity = launchInfo.AudioFilesPaths.Select(x => new AudioIdentityObject { ID = x });
            StateEventInfoTools.UpdateAudioEventsWithAudioIdentities(audioEvents, newAudioIdentity);
        }

        /// <summary>
        /// Start playing of deferred record.
        /// </summary>
        /// <param name="downloadResult"></param>
        private void StartDeferredSessionPlay(DownloadResult downloadResult)
        {
            DownloadResult = downloadResult;

            StartMonitoringSessionPlay(downloadResult.AudioFiles, downloadResult.EventSource, true);
        }

        /// <summary>
        /// Start playing of record.
        /// </summary>
        /// <param name="audioFiles"></param>
        /// <param name="eventSource"></param>
        /// <param name="isDefferedSession"></param>
        private void StartMonitoringSessionPlay(Dictionary<AudioIdentityObject, string> audioFiles, DeferredEventSource eventSource, bool isDefferedSession = false)
        {
            MediaPlayer = new MediaPlayer();
            MediaPlayer.MediaFailed += MediaPlayer_MediaFailed;
            MediaPlayer.MediaEnded += MediaPlayer_MediaEnded;

            var audioFile = audioFiles.FirstOrDefault();

            if (audioFile.Value != null)
            {
                MediaPlayer.Open(new Uri(audioFile.Value));
                MediaPlayer.Stop();
            }
            MediaPlayer.MediaOpened += MediaPlayer_MediaOpened;

            _eventSource = eventSource;

            if (_eventSource != null && _eventSource.MilestoneProvider != null)
                _eventSource.MilestoneProvider.CurrentMilestoneUpdated += CurrentMilestoneUpdated;

            Player = new Player(
                this,
                PresenterInterview,
                PresenterAppointment,
                PresenterRedial,
                eventSource);

            StatusBar.Mode = StatusBarModes.MainViewPlayer;

            UpdateInterviewInfoAndStatusBarByEvents(eventSource);

            if (isDefferedSession)
            {
                StatusBar.UserName = UserPassport.Instance.CurrentIdentityInfo.InterviewerName;
                MainForm.EnableSaveOfflineRecordButton(true);
            }

            MainForm.ShowInterviewPageControl();
            MainForm.EnableDeferredToolbar(true);

            InitJumpToQuestionCombobox(eventSource);

            FillJumpDataAndEvents(eventSource);

            Player.Start();

            // lets check if we are have question to jump
            if (!string.IsNullOrWhiteSpace(_initialQuestion))
            {
                JumpToInitialQuestion();
            }
        }

        private void UpdateInterviewInfoAndStatusBarByEvents(DeferredEventSource eventSource)
        {
            var initialStateData = eventSource.GetInterviewingInitialStateData();

            if (initialStateData != null)
            {
                UserPassport.Instance.InterviewInfo.Set(initialStateData.SurveyId, initialStateData.InterviewId);
                UpdateStatusBarInformation(initialStateData);
            }
        }

        private void InitJumpToQuestionCombobox(DeferredEventSource eventSource)
        {
            var questionsProvider = new AnsweredQuestionsProvider(eventSource.Events);
            var answeredQuestions = questionsProvider.GetAllQuestions();

            _questionsComboBoxItems = new AnsweredQuestionsComboBoxItemsProvider(answeredQuestions).GetItems().ToList();

            MainForm.InitJumpToQuestionCombobox(_questionsComboBoxItems);
        }

        private void FillJumpDataAndEvents(DeferredEventSource eventSource)
        {
            _initialQuestion = UserPassport.Instance.CurrentIdentityInfo.InitialQuestion;

            var questionsProvider = new AnsweredQuestionsProvider(eventSource.Events);
            var currentList = questionsProvider.GetAllQuestions().ToList();

            // later we check not for InitialQuestion not null, but if indexes is not null because if wrong or not exist InitialQuestion 
            // it is not null  but indexes were not found and so they are zero
            if (string.IsNullOrWhiteSpace(_initialQuestion))
            {
                return;
            }

            var match = currentList.FirstOrDefault(stringToCheck => stringToCheck.Id.Equals(_initialQuestion));

            if (match != null)
            {
                _pageCompletedEventIndex = match.IndexOfEventContentLoad;
                _questionSelectedEventIndex = match.IndexOfEvent;
                _initialQuestionOffset = match.Offset;
            }
            else
            {
                _alerter.Alert(
                            Strings.ResourceManager.GetString("Warning_QuestionNotFound", _initialQuestion),
                            Strings.ResourceManager.GetString("Caption_Warning"),
                            MessageTypes.Warning);

                MainForm.CloseForm();
            }
        }

        /// <summary>
        /// Handles DownloadWorker.DoWork event. Downloads needed files from 
        /// Monitoring service and places them into temporary directory.
        /// </summary>
        /// <param name="sender">BackgroundWorker object.</param>
        /// <param name="e">Arguments.</param>
        private void DownloadWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            var result = new DownloadResult();

            var recordId = UserPassport.Instance.CurrentIdentityInfo.RecordId;

            StateEventInfo[] events;

            using (var stream = MonitoringServiceManager.GetDeferredRecord(recordId))
            {
                events = StateEventInfoDepacker.GetAllEvents(stream);
            }

            _interviewInitialEventManager = new InterviewInitialEventsProvider(events);

            _interviewStartEventTimeStamp = events.First(x => x.MessageType == MonitoringMessageTypes.InterviewStartMessage).TimeStamp;

            var audioEvents = events.Where(x => x.MessageType == MonitoringMessageTypes.AudioStartMessage).ToArray();

            if (audioEvents.Any())
            {
                try
                {
                    var newAudioIdentities = MonitoringServiceManager.GetAudioIdentities(recordId).ToArray();

                    if (!newAudioIdentities.Any())
                    {
                        _alerter.Alert(
                            Strings.ResourceManager.GetString("Warning_UnableDownloadAudio"),
                            Strings.ResourceManager.GetString("Caption_Warning"),
                            MessageTypes.Warning);

                        throw new InvalidOperationException("Unable to download audio for this call.");
                    }

                    if (audioEvents.Length != newAudioIdentities.Length)
                    {
                        _alerter.Alert(
                            Strings.ResourceManager.GetString("Warning_UnableDownloadAudio"),
                            Strings.ResourceManager.GetString("Caption_Warning"),
                            MessageTypes.Warning);

                        throw new InvalidOperationException("Not all audios for this call are available for downloading.");
                    }

                    StateEventInfoTools.UpdateAudioEventsWithAudioIdentities(audioEvents, newAudioIdentities);

                    foreach (var audioIdentityObject in newAudioIdentities)
                    {
                        var uri = new Uri(audioIdentityObject.ID);

                        if (Settings.Default.LocalAudioDownload == false ||
                            uri.Scheme.ToLowerInvariant() == MmsProtocolScheme)
                        {
                            // in a case of mms:// protocol or if download audio files locally flag is false
                            // we do not download file but adding it for streaming playback

                            result.AudioFiles.Add(audioIdentityObject, audioIdentityObject.ID);

                            Logger.Write(
                                Strings.ResourceManager.GetString("Info_UrlAdd", audioIdentityObject.ID),
                                MessageTypes.Information);
                        }
                        else
                        {
                            var fileName = Path.GetTempFileName() + Path.GetExtension(audioIdentityObject.Name);
                            var tool = new WebClient();

                            tool.DownloadFile(audioIdentityObject.ID, fileName);
                            result.AudioFiles.Add(audioIdentityObject, fileName);

                            Logger.Write(
                                Strings.ResourceManager.GetString("Info_FileStored", audioIdentityObject.Name, fileName),
                                MessageTypes.Information);
                        }
                    }
                }
                catch (Exception ex)
                {
                    // unable to download audio file
                    Logger.Write(ex);
                }
            }

            _initialQuestion = UserPassport.Instance.CurrentIdentityInfo.InitialQuestion;

            if (!string.IsNullOrWhiteSpace(_initialQuestion))
            {
                IEnumerable<StateEventInfo> eventsModified = InsertEndQuestionEvent(events);
                result.EventSource = new DeferredEventSource(eventsModified);
            }
            else
            {
                result.EventSource = new DeferredEventSource(events);
            }

            e.Result = result;
        }

        private IEnumerable<StateEventInfo> InsertEndQuestionEvent(IEnumerable<StateEventInfo> events)
        {
            var initialStateEventInfos = new List<StateEventInfo>(events); // we need this because of we need next question data
            var resultStateEventInfos = new List<StateEventInfo>();
            const int fakeEventTimeDifference = 100;

            foreach (var entry in initialStateEventInfos)
            {

                if (entry.MessageType == MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage)
                {
                    var eventInfo = new EventInfo(entry);
                    var state = eventInfo.State as QuestionSelectedStateData;

                    resultStateEventInfos.Add(entry);

                    if (state != null && (state.IsSubQuestion || state.SubQuestionIndex > 0))
                    {
                        continue;
                    }

                    var returnEventInfo = new StateEventInfo
                    {
                        MessageType = MonitoringMessageTypes.ReturnToInitialQuestion,
                        TimeStamp = entry.TimeStamp.AddMilliseconds(fakeEventTimeDifference),
                        State = null
                    };

                    resultStateEventInfos.Add(returnEventInfo); // This is fake event we will use to know we need to jump
                    continue;
                }

                if (entry.MessageType == MonitoringMessageTypes.InterviewFinishMessage)
                {
                    var returnEventInfo = new StateEventInfo
                    {
                        MessageType = MonitoringMessageTypes.ReturnToInitialQuestion,
                        TimeStamp = entry.TimeStamp - TimeSpan.FromMilliseconds(fakeEventTimeDifference),
                        State = null
                    };

                    resultStateEventInfos.Add(returnEventInfo); // This is fake event we will use to know we need to jump
                    resultStateEventInfos.Add(entry); // this is missed InterviewFinishMessage
                    continue;
                }

                resultStateEventInfos.Add(entry);

            }

            return resultStateEventInfos.ToArray();
        }

        /// <summary>
        /// Handles DownloadWorker.RunWorkerCompleted event. Clears DownloadWorker resources 
        /// and starts playing.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DownloadWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            DownloadWorker.DoWork -= DownloadWorker_DoWork;
            DownloadWorker.RunWorkerCompleted -= DownloadWorker_RunWorkerCompleted;

            DownloadWorker.Dispose();
            DownloadWorker = null;

            if (e.Error != null)
            {
                // exception occured during download. Warn user and close application.
                Logger.Write(e.Error);
                _alerter.Alert(Strings.Error_DownloadError, Strings.Caption_Error, MessageTypes.Error);
                MainForm.CloseForm();
            }
            else if (e.Cancelled)
            {
                // download is cancelled. Warn user and close application.
                Logger.Write(e.Error);
                _alerter.Alert(Strings.Error_DownloadCancelled, Strings.Caption_Error, MessageTypes.Error);
                MainForm.CloseForm();
            }
            else if (((DownloadResult)e.Result).EventSource == null)
            {
                // download deferred file failed for some reason. Warn user and close application.
                _alerter.Alert(Strings.Error_DownloadError, Strings.Caption_Error, MessageTypes.Error);
                MainForm.CloseForm();
            }
            else
            {
                StartDeferredSessionPlay((DownloadResult)e.Result);
            }
        }

        /// <summary>
        /// Initializes application.
        /// </summary>
        private void InitApplication()
        {
            try
            {
                if (Directory.Exists(ApplicationManager.ApplicationPath) == false)
                {
                    Directory.CreateDirectory(ApplicationManager.ApplicationPath);
                }

                StatusBar.Version = ApplicationManager.AssemblyVersion;

                new CustomUriRegistration().Register();
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        private void UpdateStatusBarInformation(InterviewingInitialStateData s)
        {
            StatusBar.SurveyName = SurveyNameFormatter.FormatSurveyName(s.SurveyId, s.SurveyName);
            StatusBar.InterviewName = s.InterviewId.ToString(CultureInfo.InvariantCulture);
            StatusBar.ClearInformation();
            DisplayConsoleState(s.ConsoleState);

            StatusBar.HighlightSurvey(s.IsNewSurvey);
        }

        /// <summary>
        /// Checks if user accepted license agreements.
        /// </summary>
        /// <returns>true, if user accepted; otherwise false.</returns>
        private bool CheckLicenseAgreements()
        {
            bool result = true;
            if (!ApplicationManager.HasLicenseAgreementBeenShown)
            {
                using (IViewLicenseForm licenseForm = (IViewLicenseForm)ViewFactory.GetView(FormViews.LincenseView))
                {
                    licenseForm.DocumentText = CommonResources.license;
                    if (DialogResult.OK == licenseForm.Show())
                    {
                        try
                        {
                            ApplicationManager.SaveLicenseAgreement();
                        }
                        catch (Exception ex)
                        {
                            Logger.Write(ex);
                            result = false;
                        }
                    }
                    else
                    {
                        result = false;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Clears used resources.
        /// </summary>
        private void ClearResources()
        {
            ClearDeferredMonitoringResources();

            ClearOfflinePlaybackResources();

            MonitoringServiceManager.Release();
            Logger.Release();
        }

        private void ClearDeferredMonitoringResources()
        {
            if (MediaPlayer != null)
            {
                MediaPlayer.Stop();
                MediaPlayer.Close();
            }

            if (DownloadResult != null)
            {
                // we have downloaded files, so we should remove it
                foreach (var audioFile in DownloadResult.AudioFiles)
                {
                    if (audioFile.Key.ID != audioFile.Value)
                    {
                        FileManager.DeleteFile(audioFile.Value);
                    }
                }
            }
        }

        private void ClearOfflinePlaybackResources()
        {
            if (_offlineMonitoringLaunchInfo == null)
            {
                return;
            }

            var fileManager = new FileOperationsManager();
            fileManager.DeleteFiles(_offlineMonitoringLaunchInfo.GetFileNames());
        }

        public void SwitchToNewIdentity(string encryptedData)
        {
            var currentIdentityInfo = UserPassport.Instance.CurrentIdentityInfo;

            if (!encryptedData.Contains(LiteralConstants.EncryptedData))
            {
                _alerter.Alert(
                            Strings.ResourceManager.GetString("Error_ReadLaunchInfoError"),
                            Strings.ResourceManager.GetString("Caption_Error"),
                            MessageTypes.Error);

                throw new InvalidOperationException("Monitoring protocol link contains wrong encrypted data.");
            }

            var newIdentityInfo = _monitoringIdentityInfoProvider.GetFromParameters(encryptedData);

            if (newIdentityInfo.IsTheSameDeferredRecord(UserPassport.Instance.CurrentIdentityInfo))
            {
                JumpToQuestionWithinTheSameRecording(newIdentityInfo);
            }
            else
            {
                SwitchToNewMonitoringSource(newIdentityInfo);
            }

            var currentLiveSessionShouldBeStopped = currentIdentityInfo.LaunchType == LaunchFileType.LiveMonitoring
                                                    && (newIdentityInfo.LaunchType == LaunchFileType.DeferredMonitoring
                                                        || currentIdentityInfo.MonitoringSessionId != newIdentityInfo.MonitoringSessionId);
            if (currentLiveSessionShouldBeStopped)
            {
                StopMonitoringSession(currentIdentityInfo);
            }
        }

        private void SwitchToNewMonitoringSource(MonitoringIdentityInfo newIdentityInfo)
        {
            Player.Stop();

            PresenterInterview.PlayEvent(MonitoringMessageTypes.InterviewFinishMessage, null);
            PlayInterviewFinish(null);
            PresenterAppointment.CloseAppointmentForm();
            PresenterRedial.CloseRedialForm();
            ClearDeferredMonitoringResources();

            ResetInitialQuestionProcess(newIdentityInfo);

            UserPassport.Instance.CurrentIdentityInfo = newIdentityInfo;

            IsRecordPaused = false;

            switch (newIdentityInfo.LaunchType)
            {
                case LaunchFileType.DeferredMonitoring:
                    StartDeferredSession(UserPassport.Instance.CurrentIdentityInfo);
                    break;
                case LaunchFileType.LiveMonitoring:
                    StartLiveSession(UserPassport.Instance.CurrentIdentityInfo);
                    break;
                default:
                    {
                        _alerter.Alert(
                            Strings.ResourceManager.GetString("Error_ReadLaunchInfoError"),
                            Strings.ResourceManager.GetString("Caption_Error"),
                            MessageTypes.Error);

                        throw new InvalidOperationException("Unsupported LaunchFileType to open from link.");
                    }
            }
        }

        private void JumpToQuestionWithinTheSameRecording(MonitoringIdentityInfo monitoringIdentityInfo)
        {
            if (monitoringIdentityInfo.InitialQuestion == UserPassport.Instance.CurrentIdentityInfo.InitialQuestion)
            {
                return;
            }

            UserPassport.Instance.CurrentIdentityInfo = monitoringIdentityInfo;

            var question =
                _questionsComboBoxItems.FirstOrDefault(
                    x =>
                        x.ItemText.Substring(0, x.BoldTextLenght)
                            .Equals(monitoringIdentityInfo.InitialQuestion));
            if (question == null)
            {
                _alerter.Alert(
                    Strings.ResourceManager.GetString("Warning_QuestionNotFound", monitoringIdentityInfo.InitialQuestion),
                    Strings.ResourceManager.GetString("Caption_Warning"),
                    MessageTypes.Warning);
                return;
            }

            ResetInitialQuestionProcess(monitoringIdentityInfo);

            _pageCompletedEventIndex = question.PageCompletedEventIndex;
            _questionSelectedEventIndex = question.QuestionSelectedEventIndex;

            MainFormDeferredRecordJumpToMilestone(this, new JumpToQuestionEventArgs()
            {
                QuestionSelectedEventIndex = question.QuestionSelectedEventIndex,
                PageCompletedEventIndex = question.PageCompletedEventIndex
            });
        }

        private void ResetInitialQuestionProcess(MonitoringIdentityInfo monitoringIdentityInfo)
        {
            _returnToInitialQuestionDone = false;
            _firstFakeEventSkipped = false;
            _initialQuestion = monitoringIdentityInfo.InitialQuestion;
        }
    }
}
