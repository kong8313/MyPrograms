﻿using System;
using System.Collections.Generic;
using System.IO;
using System.ServiceModel;
using Confirmit.CATI.Common.Monitoring;
using Confirmit.CATI.Common.WcfTools;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Resources;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.Resources;
using Confirmit.CATI.MonitoringConsole.Properties;

namespace Confirmit.CATI.MonitoringConsole.Services.MonitoringService
{
    /// <summary>
    /// Represents intermediate level between application and Monitoring Web Service.
    /// </summary>
    internal class MonitoringServiceManager
    {
        private static ChannelFactoryWrapper<ISupervisorContract> _monitoringServiceChannelFactory;

        public static void ConfigureChannelFactory(int companyId, string serverName, string encryptedData)
        {
            Release();

            _monitoringServiceChannelFactory = new ChannelFactoryWrapper<ISupervisorContract>(
                new SupervisorMonitoringServiceChannelFactoryWrapperConfiguration(companyId, serverName, encryptedData), new Logger());
        }

        public static void Release()
        {
            if (_monitoringServiceChannelFactory != null)
            {
                _monitoringServiceChannelFactory.Release();
            }
        }

        public static StateEventInfo[] GetInterviewerEvents()
        {
            return GetInterviewerEvents(true);
        }

        /// <summary>
        /// Gets deferred record by record identifier.
        /// </summary>
        /// <param name="recordId">Monitoring session identifier.</param>
        /// <returns>Deferred record bytes.</returns>
        public static Stream GetDeferredRecord(long recordId)
        {
            var stream = new MemoryStream();
            var resp = new FileResponse { Total = Settings.Default.MaxMonitoringEventsSize };
            var log = true;

            while (stream.Length < resp.Total)
            {
                var packageSize = (resp.Total - (int)stream.Length) > Settings.Default.MaxMonitoringEventsSize ?
                    Settings.Default.MaxMonitoringEventsSize :
                    (resp.Total - (int)stream.Length);

                resp = _monitoringServiceChannelFactory.Execute(service => service.GetVideoFile(recordId, (int)stream.Length, packageSize));
                stream.Write(resp.Data, 0, resp.Data.Length);

                if (log)
                {
                    //TODO: Move this outside of the loop?
                    Logger.Write(
                        Strings.ResourceManager.GetString("Info_DeferredFileDownloadStarted", resp.Total),
                        MessageTypes.Information);

                    log = false;
                }
            }

            Logger.Write(Strings.Info_FileDownloadFinished, MessageTypes.Information);

            stream.Seek(0, SeekOrigin.Begin);

            return stream;
        }

        public static MonitoringIdentityInfo GetMonitoringIdentityInfo()
        {
            return GetMonitoringIdentityInfo(true);            
        }

        private static MonitoringIdentityInfo GetMonitoringIdentityInfo(bool retryAfterFault)
        {
            try
            {
                return _monitoringServiceChannelFactory.Execute(service => service.GetMonitoringIdentityInfo());                
            }
            catch (FaultException /*ex*/)
            {
                if (retryAfterFault)
                {
                    return GetMonitoringIdentityInfo(false);
                }

                throw;
            }
        }

        public static void StopSession(string supervisorName, int interviewerId, long monitoringSessionId)
        {
            try
            {
                _monitoringServiceChannelFactory.Execute(
                    service => service.StopSession(supervisorName, interviewerId, monitoringSessionId));
            }
            catch (FaultException ex)
            {
                Logger.Write(ex);
            }
        }

        public static IEnumerable<AudioIdentityObject> GetAudioIdentities(long recordId)
        {
            return GetAudioIdentities(recordId, true);
        }

        private static IEnumerable<AudioIdentityObject> GetAudioIdentities(long recordId, bool retryAfterFault)
        {
            try
            {
                return _monitoringServiceChannelFactory.Execute(service => service.GetAudioIdentities(recordId));
            }
            catch (FaultException /*ex*/)
            {
                if (retryAfterFault)
                {
                    return GetAudioIdentities(recordId, false);
                }

                throw;
            }
        }

        /// <summary>
        /// Receives monitoring events from Monitoring service. If general fault exception occurs and 
        /// retryAfterFault flag is true, method releases client object and tries to repeat call.
        /// </summary>        
        /// <param name="retryAfterFault">if true we repeat method call on fault exception; otherwise
        /// do nothing.</param>
        /// <returns>Array of events. If method fails, returns empty array.</returns>
        private static StateEventInfo[] GetInterviewerEvents(bool retryAfterFault)
        {
            try
            {
                byte[] res = _monitoringServiceChannelFactory.Execute(service => service.GetInterviewerEvents());

                if (res != null)
                {
                    return StateEventInfoDepacker.GetAllEvents(res);
                }
            }
            catch (FaultException /*ex*/)
            {
                if (retryAfterFault)
                {
                    return GetInterviewerEvents(false);
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }

            return new StateEventInfo[0];
        }

        public static MonitoringOptions GetMonitoringOptions(string supervisorName, int interviewerId, bool retryAfterFault = true)
        {
            try
            {
                return _monitoringServiceChannelFactory.Execute(service => service.GetMonitoringOptions(supervisorName, interviewerId));
            }
            catch (FaultException)
            {
                if (retryAfterFault)
                {
                    return GetMonitoringOptions(supervisorName, interviewerId, false);
                }

                throw;
            }
        }

        public static void SetLiveMonitoringMode(string supervisorName, int interviewerId, MonitoringMode mode, bool retryAfterFault = true)
        {
            try
            {
                _monitoringServiceChannelFactory.Execute(service => service.SetLiveMonitoringMode(supervisorName, interviewerId, mode));
            }
            catch (FaultException)
            {
                if (retryAfterFault)
                {
                    SetLiveMonitoringMode(supervisorName, interviewerId, mode, false);
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }
    }
}
