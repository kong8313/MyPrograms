﻿namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    public class AnsweredQuestionsComboBoxItem
    {
        public string ItemText { get; set; }

        public int PageCompletedEventIndex { get; set; }

        public int QuestionSelectedEventIndex { get; set; }

        public int BoldTextLenght { get; set; }
    }
}