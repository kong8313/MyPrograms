﻿namespace Confirmit.CATI.MonitoringConsole.Classes.SystemInfo
{
    public enum ProductType
    {
        VerNtWorkstation = 1,
        VerNtDomainController = 2,
        VerNtServer = 3
    }
}