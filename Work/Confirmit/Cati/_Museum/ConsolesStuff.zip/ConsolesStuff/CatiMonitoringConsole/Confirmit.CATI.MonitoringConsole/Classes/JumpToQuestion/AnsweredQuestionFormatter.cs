﻿using System;

namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    public class AnsweredQuestionFormatter
    {
        public string GetOffset(TimeSpan offset)
        {
            var offsetFormat = "mm\\:ss";
            if (offset.Hours > 0)
            {
                offsetFormat = "hh\\:mm\\:ss";
            }

            return offset.ToString(offsetFormat);
        }

        public string GetText(AnsweredQuestion question)
        {
            string text;

            if (String.IsNullOrEmpty(question.QuestionTitle) == false)
            {
                text = question.QuestionTitle;
            }
            else
            {
                text = question.QuestionText;
            }

            text = text.CropWholeWords(50);

            return String.Format(string.IsNullOrEmpty(text) ? "{0} ({1})" : "{0} ({1}) {2}",
                question.Id,
                GetOffset(question.Offset),
                text);
        }

        public string GetPositionForStatusBar(string questionId, TimeSpan? offset)
        {
            return string.Format("{0} ({1})",
                questionId,
                offset.HasValue ? GetOffset(offset.Value) : "");
        }
    }
}
