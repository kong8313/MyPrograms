﻿namespace Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback
{
    public enum InterviewRecordCreateAction
    {
        Starting,

        GetEvents,

        GetAudioEvent,

        GetAudioIdentity,

        GetAudioData,

        CreateRecord,

        Completing
    }
}
