﻿using System;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.Monitoring.Common.Serialization;
using Confirmit.CATI.Monitoring.Common.StateData;

namespace Confirmit.CATI.MonitoringConsole.Classes
{
    /// <summary>
    /// Represents class which contains information about event for playing.
    /// </summary>
    public class EventInfo
    {
        #region Constructors

        /// <summary>
        /// Initializes new instance of EventInfo class.
        /// </summary>
        public EventInfo()
        {
        }

        /// <summary>
        /// Initialiazes new instance of EventInfo class and fills it with given data.
        /// </summary>
        /// <param name="stateEvent">State event info object.</param>
        public EventInfo(StateEventInfo stateEvent)
        {
            TimeStamp = stateEvent.TimeStamp;
            MessageType = stateEvent.MessageType;
            State = SerializationManager.Deserialize(stateEvent.MessageType, stateEvent.State);
        }

        public EventInfo(StateEventInfo stateEvent, int eventIndex)
        {
            TimeStamp = stateEvent.TimeStamp;
            MessageType = stateEvent.MessageType;
            State = SerializationManager.Deserialize(stateEvent.MessageType, stateEvent.State);
            Index = eventIndex;
        }

		#endregion

		#region Properties

        /// <summary>
        /// Time of state event in UTC.
        /// </summary>
        public DateTime TimeStamp
        {
            get;
            set;
        }

        /// <summary>
		/// Gets/sets message type of event.
		/// </summary>
		public MonitoringMessageTypes MessageType
		{
			get;
			set;
		}

		/// <summary>
		/// Gets/sets data which contains state of the control which causes
		/// StateChanged event.
		/// </summary>
		public BaseStateData State
		{
			get;
			set;
		}

        /// <summary>
        /// Event index.
        /// </summary>
        public int? Index { get; set; }

		#endregion

        public override string ToString()
        {
            return $"{Index} - {TimeStamp:o}: {MessageType}";
        }
    }
}
