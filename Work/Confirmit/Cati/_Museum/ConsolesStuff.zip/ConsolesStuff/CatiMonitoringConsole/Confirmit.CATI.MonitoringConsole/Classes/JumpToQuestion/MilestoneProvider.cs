﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.Classes.EvenSources;

namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    public class MilestoneProvider
    {
        public static TimeSpan MinimalMilestoneSignificantDuration = TimeSpan.FromMilliseconds(200);

        public MilestoneEvent CurrentMilestone
        {
            get => _currentMilestone;
            private set
            {
                if (_currentMilestone != value)
                {
                    _currentMilestone = value;
                    OnCurrentMilestoneUpdated(_currentMilestone);
                }
            }
        }

        public EventHandler<MilestoneEvent> CurrentMilestoneUpdated;

        private void OnCurrentMilestoneUpdated(MilestoneEvent currentMilestone)
        {
            CurrentMilestoneUpdated?.Invoke(this, currentMilestone);
        }

        private readonly StateEventInfo[] _events;
        private readonly MilestoneEvent[] _milestoneEvents;
        private MilestoneEvent _currentMilestone;

        public MilestoneProvider(StateEventInfo[] events)
        {
            _events = events;

            var milestoneEvents = GetMilestoneEvents();

            if (milestoneEvents != null)
                _milestoneEvents = milestoneEvents.ToArray();
        }

        private List<MilestoneEvent> GetMilestoneEvents()
        {
            if (_events == null) return null;

            var milestoneEvents = new List<MilestoneEvent>();
            for (int i = 0; i < _events.Length; i++)
            {
                var eventInfo = new EventInfo(_events[i], i);

                var milestone = GetMilestone(eventInfo, i);
                if (milestone == null) continue;

                milestoneEvents.Add(milestone);
                i = milestone.IndexOfFinishEvent - 1;
            }

            return milestoneEvents;
        }

        public void UpdateCurrentMilestone(int eventIndex)
        {
            CurrentMilestone = _milestoneEvents.LastOrDefault(x => x.IndexOfEvent <= eventIndex && eventIndex < x.IndexOfFinishEvent);
        }

        public bool EventInCurrentMilestone(int eventIndex)
        {
            if (CurrentMilestone == null) return false;

            return CurrentMilestone.IndexOfEvent <= eventIndex && eventIndex <= CurrentMilestone.IndexOfFinishEvent;
        }

        private MilestoneEvent GetMilestone(EventInfo eventInfo, int eventIndex)
        {
            if (eventInfo == null || !eventInfo.MessageType.IsMilestoneStartMessage()) return null;

            var finish = DeferredEventHelper.GetMilestoneFinishEventIndex(_events, eventIndex);
            var duration = DeferredEventHelper.GetMilestoneDuration(_events, eventIndex, finish);

            //skip milestone if it's duration less than 200 milliseconds
            if (duration < MinimalMilestoneSignificantDuration) return null;

            var interviewStartEvent = DeferredEventHelper.GetInterviewStartEvent(_events);
            var interviewStartTime = interviewStartEvent.TimeStamp;

            var loadContentEventIndex = DeferredEventHelper.GetMilestoneLoadContentEventIndex(_events, eventIndex);
            return new MilestoneEvent(eventInfo)
            {
                Time = eventInfo.TimeStamp,
                Offset = eventInfo.TimeStamp - interviewStartTime,
                IndexOfEvent = eventIndex,
                Duration = duration,
                IndexOfEventContentLoad = loadContentEventIndex,
                IndexOfFinishEvent = finish
            };
        }

        public MilestoneEvent GetPrevMilestone()
        {
            if (_milestoneEvents == null || CurrentMilestone == null) return null;

            var currentMilestoneIndex = Array.IndexOf((Array)_milestoneEvents, CurrentMilestone);

            if (0 < currentMilestoneIndex && currentMilestoneIndex <= _milestoneEvents.Length - 1)
                return _milestoneEvents[currentMilestoneIndex - 1];

            return null;
        }

        public MilestoneEvent GetNextMilestone()
        {
            if (_milestoneEvents == null || CurrentMilestone == null) return null;

            var currentMilestoneIndex = Array.IndexOf((Array)_milestoneEvents, CurrentMilestone);

            if (0 <= currentMilestoneIndex && currentMilestoneIndex < _milestoneEvents.Length - 1)
                return _milestoneEvents[currentMilestoneIndex + 1];

            return null;
        }
    }
}