﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    public class AnsweredQuestionsComboBoxItemsProvider
    {
        private readonly IEnumerable<AnsweredQuestion> _answeredQuestions;

        public AnsweredQuestionsComboBoxItemsProvider(IEnumerable<AnsweredQuestion> answeredQuestions)
        {
            _answeredQuestions = answeredQuestions;
        }

        public IEnumerable<AnsweredQuestionsComboBoxItem> GetItems()
        {
            var formatter = new AnsweredQuestionFormatter();
            return _answeredQuestions.Select(x => new AnsweredQuestionsComboBoxItem()
            {
                ItemText = formatter.GetText(x),
                PageCompletedEventIndex = x.IndexOfEventContentLoad,
                QuestionSelectedEventIndex = x.IndexOfEvent,
                BoldTextLenght = string.IsNullOrEmpty(x.Id) ? 0 : x.Id.Length
            });
        }
    }
}
