﻿using Confirmit.CATI.Common.WcfTools.ErrorServiceMessageHeader;

namespace Confirmit.CATI.MonitoringConsole.Services.ErrorReportingService
{
    internal class ErrorReportingServiceAuthenticationDataProvider : ILoginPasswordAuthenticationDataProvider
    {
        public string Login
        {
            get { return string.Empty; }
        }

        public string Password
        {
            get { return string.Empty; }
        }

        public int CompanyId
        {
            get { return 0; }
        }
    }
}
