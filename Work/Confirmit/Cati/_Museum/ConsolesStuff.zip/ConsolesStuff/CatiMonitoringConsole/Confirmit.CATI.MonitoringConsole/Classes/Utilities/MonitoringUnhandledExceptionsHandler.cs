﻿using System;
using System.Windows.Forms;
using Confirmit.CATI.Console.Shared.Utilities;

namespace Confirmit.CATI.MonitoringConsole.Classes.Utilities
{
    public static class MonitoringUnhandledExceptionsHandler
    {
        public static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            UnhandledExceptionsHandler.CurrentDomain_UnhandledException(sender, e);
            if (!e.IsTerminating) return;

            var appName = UnhandledExceptionsHandler.GetAppNameAndVersion();
            var errorText = string.Format(Properties.Resources.UnhandledExceptionMessage, (e.ExceptionObject as Exception)?.Message);
            MessageBox.Show(errorText, appName, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
