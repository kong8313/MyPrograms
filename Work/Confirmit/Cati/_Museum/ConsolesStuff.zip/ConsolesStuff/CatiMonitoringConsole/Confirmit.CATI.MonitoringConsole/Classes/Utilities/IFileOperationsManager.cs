﻿using System.Collections.Generic;
using System.IO;

namespace Confirmit.CATI.MonitoringConsole.Classes.Utilities
{
    public interface IFileOperationsManager
    {
        bool FileExists(string path);
        Stream OpenFile(string path);
        IEnumerable<string> UnpackPackagePartsToFiles(string path);
        void DeleteFiles(IEnumerable<string> files);
    }
}
