using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;

namespace Confirmit.CATI.MonitoringConsole.Classes.Utilities
{
    public class FileOperationsManager : IFileOperationsManager
    {
        public bool FileExists(string path)
        {
            return File.Exists(path);
        }

        public Stream OpenFile(string path)
        {
            return File.OpenRead(path);
        }

        public IEnumerable<string> UnpackPackagePartsToFiles(string path)
        {
            var unpackedPartsPaths = new List<string>();

            using (var package = Package.Open(path, FileMode.Open))
            {
                var parts = package.GetParts();

                foreach (var part in parts)
                {
                    var uri = part.Uri.ToString();
                    var fileName = FileManager.CreateNewFileName(uri);

                    var content = part.GetStream();

                    using (var fileStream = File.Create(fileName))
                    {
                        content.CopyTo(fileStream);
                    }

                    unpackedPartsPaths.Add(fileName);
                }
            }

            return unpackedPartsPaths;
        }

        public void DeleteFiles(IEnumerable<string> files)
        {
            foreach (var file in files)
            {
                if (!FileExists(file))
                {
                    continue;
                }

                File.Delete(file);
            }
        }
    }
}
