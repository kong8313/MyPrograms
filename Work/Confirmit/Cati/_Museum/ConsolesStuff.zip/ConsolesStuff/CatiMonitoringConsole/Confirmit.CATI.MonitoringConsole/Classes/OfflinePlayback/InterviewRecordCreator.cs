﻿using Confirmit.CATI.Common;
using Confirmit.CATI.Common.Monitoring;
using Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback.Writers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using Confirmit.CATI.MonitoringConsole.Classes.Playback;

namespace Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback
{
    public class InterviewRecordCreator
    {
        private readonly IInterviewRecordWriter _recordWriter;
        private readonly IAudioService _audioService;
        private readonly IMonitoringService _monitoringService;
        private readonly ILogger _logger;

        private readonly BackgroundWorker _backgroundCreator;

        private IInterviewRecordEventsProcessor<InterviewRecordCreateAction> _actionProcessor;
        private IInterviewRecordEventsProcessor<InterviewRecordCreateError> _errorProcessor;

        private MonitoringIdentityInfo _identityInfo;
        private string _fileName;

        private InterviewRecordData _recordData;

        public bool IsStarted { get; private set; }

        public bool IsCanceled { get; private set; }

        public InterviewRecordCreator(
            IMonitoringService monitoringService,
            IAudioService audioService,
            IInterviewRecordWriter recordWriter,
            ILogger logger)
        {
            _monitoringService= monitoringService;
            _audioService = audioService;
            _recordWriter = recordWriter;
            _logger = logger;

            _backgroundCreator = new BackgroundWorker();
            _backgroundCreator.DoWork += CreatorDoWork;
            _backgroundCreator.RunWorkerCompleted += CreatorRunWorkerCompleted;
        }

        public void SetAcionProcessor(IInterviewRecordEventsProcessor<InterviewRecordCreateAction> processor)
        {
            _actionProcessor = processor;
        }

        public void SetErrorProcessor(IInterviewRecordEventsProcessor<InterviewRecordCreateError> processor)
        {
            _errorProcessor = processor;
        }

        public void StartInterviewRecordCreation(
            string fileName,
            MonitoringIdentityInfo identityInfo,
            string projectId,
            int interviewId,
            bool sync = false)
        {
            if (IsStarted)
            {
                return;
            }

            _fileName = fileName;
            _identityInfo = identityInfo;

            _recordData = new InterviewRecordData
            {
                Metadata = new InterviewRecordMetadata(identityInfo, projectId, interviewId, new List<string>())
            };

            IsStarted = true;

            if (!sync)
            {
                _backgroundCreator.RunWorkerAsync();
            }
            else
            {
                StartWork();
                CompleteWork();
            }
        }

        public void CancelRecordCreation()
        {
            IsCanceled = true;
        }

        private void CreatorDoWork(object sender, DoWorkEventArgs e)
        {
            StartWork();
        }

        private void CreatorRunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            CompleteWork();
        }

        private void StartWork()
        {
            OnActionChanged(InterviewRecordCreateAction.Starting);

            InvokeAction(InterviewRecordCreateAction.GetEvents, GetEventsStreamAction);
        }

        private void CompleteWork()
        {
            OnActionChanged(InterviewRecordCreateAction.Completing);

            IsStarted = false;
            IsCanceled = false;
        }

        private void InvokeAction(InterviewRecordCreateAction createAction, Action action)
        {
            if (action == null || IsCanceled)
            {
                return;
            }

            OnActionChanged(createAction);

            try
            {
                action.Invoke();
            }
            catch (Exception error)
            {
                OnError(
                    new InterviewRecordCreateError
                    {
                        Error = error,
                        ErrorAction = createAction
                    }
                    );
            }

        }

        private void GetEventsStreamAction()
        {
            _recordData.EventsStream = _monitoringService.GetDeferredRecord(_identityInfo.RecordId);

            InvokeAction(InterviewRecordCreateAction.GetAudioEvent, GetAudioEventInfoAction);
        }

        private void GetAudioEventInfoAction()
        {
            if (_recordData.AudioEventsInfo != null)
            {
                InvokeAction(InterviewRecordCreateAction.GetAudioIdentity, GetAudioIdentityAction);
            }
            else
            {
                InvokeAction(InterviewRecordCreateAction.CreateRecord, CreateRecordFileAction);
            }
        }

        private void GetAudioIdentityAction()
        {
            var recordDataAudioIdentity = _monitoringService.GetAudioIdentity(_identityInfo.RecordId);
            foreach (var audioIdentityObject in recordDataAudioIdentity)
            {
                _recordData.AudioIdentities.Add(audioIdentityObject);
            }

            InvokeAction(InterviewRecordCreateAction.GetAudioData, GetAudioDataAction);
        }

        private void GetAudioDataAction()
        {
            try
            {
                if (_recordData.AudioIdentities == null)
                {
                    throw new InvalidOperationException("Unable to download audio for this call.");
                }

                foreach (var recordDataAudioIdentity in _recordData.AudioIdentities)
                {
                    _recordData.Metadata.AudioUris.Add(recordDataAudioIdentity.ID);
                    _recordData.AudioStreams.Add(_audioService.GetAudioStreamByIdentityId(recordDataAudioIdentity.ID));
                }

                InvokeAction(InterviewRecordCreateAction.CreateRecord, CreateRecordFileAction);
            }
            catch (Exception error)
            {
                OnError(
                    new InterviewRecordCreateError
                    {
                        Error = error,
                        ErrorAction = InterviewRecordCreateAction.GetAudioData
                    });

                if (_logger != null)
                {
                    _logger.Log(error.ToString(), TraceEventType.Error);
                }

                InvokeAction(InterviewRecordCreateAction.CreateRecord, CreateRecordFileAction);
            }
        }

        private void CreateRecordFileAction()
        {
            _recordWriter.WriteRecord(_recordData, _fileName);
        }

        private void OnActionChanged(InterviewRecordCreateAction action)
        {
            if (_actionProcessor != null)
            {
                _actionProcessor.Process(action);
            }
        }

        private void OnError(InterviewRecordCreateError error)
        {
            if (_errorProcessor != null)
            {
                _errorProcessor.Process(error);
            }
        }

    }
}
