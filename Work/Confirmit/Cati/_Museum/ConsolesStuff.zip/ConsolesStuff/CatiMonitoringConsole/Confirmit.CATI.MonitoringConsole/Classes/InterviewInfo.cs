﻿namespace Confirmit.CATI.MonitoringConsole.Classes
{
    internal class InterviewInfo
    {
        private readonly object _lockObject = new object();

        public InterviewInfo()
        {
            Reset();
        }

        public string ProjectId { get; private set; }
        public int InterviewId { get; private set; }

        public void Set(string projectId, int interviewId)
        {
            lock (_lockObject)
            {
                ProjectId = projectId;
                InterviewId = interviewId;
            }
        }

        public void Reset()
        {
            Set(string.Empty, 0);
        }
    }
}
