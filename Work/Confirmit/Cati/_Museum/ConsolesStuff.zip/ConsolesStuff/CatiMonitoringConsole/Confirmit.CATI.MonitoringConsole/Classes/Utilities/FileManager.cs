﻿using System;
using System.IO;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.MonitoringConsole.Classes.Utilities
{
    /// <summary>
    /// Represents manager class for files, used in application.
    /// </summary>
    internal static class FileManager
    {
        /// <summary>
        /// Deletes file with given path.
        /// </summary>
        /// <param name="path">Path.</param>
        public static void DeleteFile(string path)
        {
            try
            {
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        public static string CreateNewFileName(string path)
        {
            var name = Path.GetFileName(path);
            var tempFileName = Path.GetTempFileName();
            var tempFileNameWithoutExtension = tempFileName.Replace(".tmp", string.Empty);
            var fileName = string.Format("{0}_{1}", tempFileNameWithoutExtension, name);

            DeleteFile(tempFileName);

            return fileName;
        }
    }
}
