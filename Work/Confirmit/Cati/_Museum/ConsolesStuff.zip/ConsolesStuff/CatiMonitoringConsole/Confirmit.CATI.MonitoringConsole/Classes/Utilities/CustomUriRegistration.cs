﻿using System;
using System.Reflection;
using Microsoft.Win32;

namespace Confirmit.CATI.MonitoringConsole.Classes.Utilities
{
    public class CustomUriRegistration : ICustomUriRegistration
    {
        private readonly string _uriRegistrationKey = string.Format("Software\\Classes\\{0}", LiteralConstants.UrlProtocol);

        public void Register()
        {
            using (var uriKey = Registry.CurrentUser.CreateSubKey(_uriRegistrationKey))
            {
                if (uriKey == null)
                {
                    throw new InvalidOperationException(string.Format("Unable to create {0} subkey in HKEY_CURRENT_USER", _uriRegistrationKey));
                }

                uriKey.SetValue(null, "URL:Cati Monitoring Console protocol", RegistryValueKind.String);
                uriKey.SetValue("URL Protocol", "", RegistryValueKind.String);

                using (var defaultIconKey = uriKey.CreateSubKey("DefaultIcon"))
                {
                    if (defaultIconKey == null)
                    {
                        throw new InvalidOperationException("Unable to create DefaultIcon subkey");
                    }

                    defaultIconKey.SetValue(null, string.Format("{0},0", Assembly.GetExecutingAssembly().Location));
                }

                using (var commandKey = uriKey.CreateSubKey("shell\\open\\command"))
                {
                    if (commandKey == null)
                    {
                        throw new InvalidOperationException("Unable to create shell\\open\\command subkey");
                    }

                    var launchCommand = GetApplicationLaunchCommand();

                    commandKey.SetValue(null, launchCommand, RegistryValueKind.String);
                }
            }
        }

        private string GetApplicationLaunchCommand()
        {
            return string.Format("\"{0}\" \"%1\"", Assembly.GetExecutingAssembly().Location);
        }
    }
}
