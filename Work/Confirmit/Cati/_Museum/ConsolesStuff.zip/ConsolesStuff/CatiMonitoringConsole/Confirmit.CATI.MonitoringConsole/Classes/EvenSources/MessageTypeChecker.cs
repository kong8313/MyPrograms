﻿using System.Collections.Generic;
using Confirmit.CATI.Monitoring.Common;

namespace Confirmit.CATI.MonitoringConsole.Classes.EvenSources
{
    public static class MessageTypeChecker
    {
        public static bool IsMilestoneLoadContentMessage(this MonitoringMessageTypes messageType)
        {
            return messageType == MonitoringMessageTypes.InterviewStartMessage ||
                   messageType == MonitoringMessageTypes.InterviewInitialMessage ||
                   messageType == MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage;
        }

        public static bool IsMilestoneStartMessage(this MonitoringMessageTypes messageType)
        {
            return messageType == MonitoringMessageTypes.InterviewStartMessage ||
                   messageType == MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage;
        }

        public static bool IsPageCompleteMessage(this MonitoringMessageTypes messageType)
        {
            return messageType == MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage;
        }

        public static bool IsMilestoneFinishMessage(this MonitoringMessageTypes messageType)
        {
            return messageType == MonitoringMessageTypes.InterviewFinishMessage ||
                   messageType == MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage;
        }

        public static bool IsInterviewStartMessage(this MonitoringMessageTypes messageType)
        {
            return messageType == MonitoringMessageTypes.InterviewStartMessage;
        }

        public static bool IsInterviewFinishMessage(this MonitoringMessageTypes messageType)
        {
            return messageType == MonitoringMessageTypes.InterviewFinishMessage ||
                   messageType == MonitoringMessageTypes.MonitoringEndMessage;
        }

        public static bool IsQuestionStartMessage(this MonitoringMessageTypes messageType)
        {
            return messageType == MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage;
        }

        public static bool IsQuestionLoadContentMessage(this MonitoringMessageTypes messageType)
        {
            return messageType == MonitoringMessageTypes.InterviewInitialMessage ||
                   messageType == MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage;
        }
    }
}