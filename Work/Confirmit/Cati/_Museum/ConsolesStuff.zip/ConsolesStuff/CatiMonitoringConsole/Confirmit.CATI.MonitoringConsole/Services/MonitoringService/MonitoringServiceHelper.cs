﻿using System;
using System.ServiceModel.Security;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;

namespace Confirmit.CATI.MonitoringConsole.Services.MonitoringService
{
    /// <summary>
    /// Represents additional level between application and MonitoringServiceManager
    /// </summary>
    /// <remarks>
    /// Web service method GetInterviewerEvents can be finished by MessageSecurityException exception.
    /// That can be occured when authorization for called method fails. 
    /// In current Monitoring service implementation it can be occured when monitoring is finished 
    /// and on each request new service session is created (when load balancer is used)    
    /// </remarks>
    internal class MonitoringServiceHelper 
    {        
        private static bool m_SuccessEventReceived;

        /// <summary>
        /// Receives monitoring events from Monitoring service. 
        /// If MessageSecurityException exception occurs 
        /// MonitoringEndBySecurityExceptionMessage will be raised if any events have been recieved before 
        /// otherwise MonitoringEndBySecurityExceptionOnFirstRequestMessage.
        /// </summary>
        public static StateEventInfo[] GetInterviewerEvents()
        {
            StateEventInfo[] events;

            try
            {
                events = MonitoringServiceManager.GetInterviewerEvents();
                m_SuccessEventReceived = true;
            }
            catch (MessageSecurityException)
            {
                var endEvent = new StateEventInfo
                    {
                        TimeStamp = DateTime.Now,
                        State = new byte[0],
                        MessageType = m_SuccessEventReceived ?
                                      MonitoringMessageTypes.MonitoringEndBySecurityExceptionMessage :
                                      MonitoringMessageTypes.MonitoringEndBySecurityExceptionOnFirstRequestMessage
                    };

                events = new[] { endEvent };
            }
                        
            return events;
        }
     
    }
}
