﻿using Confirmit.CATI.Console.Views.Controls; 
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion;
using Confirmit.CATI.MonitoringConsole.Interfaces;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.MonitoringConsole.Classes;
using Confirmit.CATI.MonitoringConsole.Properties;

namespace Confirmit.CATI.MonitoringConsole
{
    public partial class MainForm : Form, IViewMainPlayerForm
    {
        private readonly SynchronizationContext _synchronizationContext;
        private readonly ToolTip _playPositionToolTip;
        private TimeSpan _currentMilestoneDuration = TimeSpan.Zero;
        private const int MaximumDurationInSecondsDisplayedWithFractions = 1;

        public InterviewPageBrowser InterviewPageBrowser
        {
            get
            {
                return interviewPageBrowser;
            }
        }

        public MainForm()
        {
            InitializeComponent();
            _synchronizationContext = SynchronizationContext.Current;
            _playPositionToolTip = new ToolTip { ShowAlways = true, UseAnimation = false, AutoPopDelay = 0, InitialDelay = 0, ReshowDelay = 0, AutomaticDelay = 0 };
            tsPositionBar.Value = 0;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            tsPositionContainer.SizeChanged += PositionContainer_SizeChanged;
            tsPositionBar.Cursor = Cursors.Hand;
            OnFormLoad(e);
        }

        public StatusBarControl StatusBarControl
        {
            get
            {
                return statusBar;
            }
        }

        public OnABreakControl OnABreakControl
        {
            get
            {
                return onABreakControl;
            }
        }

        public bool IsProcessControlVisible()
        {
            return processControl.Visible;
        }

        /// <summary>
        /// Shows interview page browser control and hides all other controls.
        /// </summary>
        public void ShowInterviewPageControl()
        {
            processControl.Enabled = false;
            processControl.Visible = false;

            onABreakControl.Visible = false;
            onABreakControl.Enabled = false;

            blankControl.Visible = false;
            blankControl.Enabled = false;

            interviewPageBrowser.Visible = true;
            interviewPageBrowser.Enabled = true;
        }

        /// <summary>
        /// Shows process control.
        /// </summary>        
        public void ShowProcessControl(string processMessage)
        {
            onABreakControl.Visible = false;
            onABreakControl.Enabled = false;

            interviewPageBrowser.Visible = false;
            interviewPageBrowser.Enabled = false;

            blankControl.Visible = false;
            blankControl.Enabled = false;

            processControl.ProcessMessage = processMessage;
            processControl.Enabled = true;
            processControl.Visible = true;
        }

        public void ShowOnABreakControl(bool displayBreakType, string breakInfo)
        {
            DisableControls();

            onABreakControl.Visible = true;
            onABreakControl.Enabled = true;
            onABreakControl.ButtonsEnabled = false;

            onABreakControl.SetBreakType(displayBreakType, breakInfo);
        }

        private void PositionContainer_SizeChanged(object sender, EventArgs e)
        {
            tsPositionBar.Width = tsPositionContainer.Width - 5 -
                                  (ItemsWidth(tsPositionContainer.Items) - tsPositionBar.Width);
        }

        private int ItemsWidth(ToolStripItemCollection items)
        {
            return items.Cast<ToolStripItem>().Sum(x => x.Width);
        }

        public void ChangeMilestone(TimeSpan? milestoneDuration)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker) delegate { ChangeMilestone(milestoneDuration); });
                return;
            }

            if (milestoneDuration == null)
            {
                if (_currentMilestoneDuration == TimeSpan.Zero) return;

                _currentMilestoneDuration = TimeSpan.Zero;
                tsPositionBar.Disabled = true;
                tsPositionBar.Value = 0;
                tsPositionBar.Maximum = 1;
            }
            else
            {
                if (_currentMilestoneDuration == milestoneDuration.Value) return;

                _currentMilestoneDuration = milestoneDuration.Value;
                var durationInUnits = GetDiscreteTime(_currentMilestoneDuration);
                tsPositionBar.Value = 0;
                tsPositionBar.Maximum = durationInUnits;
                tsPositionBar.Disabled = false;
            }

            var withFraction = _currentMilestoneDuration < TimeSpan.FromSeconds(MaximumDurationInSecondsDisplayedWithFractions) && _currentMilestoneDuration > TimeSpan.Zero;
            var newText = _currentMilestoneDuration.ToString(GetTimeFormat(_currentMilestoneDuration, withFraction));
            if (newText.Length == lbTotal.Text.Length)
            {
                lbTotal.Text = newText;
            }
            else
            {
                lbTotal.Text = newText;
                PositionContainer_SizeChanged(this, EventArgs.Empty);
            }

            lbTotal.ToolTipText = _currentMilestoneDuration.ToString(GetTimeFormat(_currentMilestoneDuration, true));
        }

        public void UpdateCurrentMilestonePosition(TimeSpan elapsed)
        {
            if (InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate { UpdateCurrentMilestonePosition(elapsed); });
                return;
            }

            var positionInUnits = GetDiscreteTime(elapsed);

            if (0 <= positionInUnits && positionInUnits <= tsPositionBar.Maximum)
                tsPositionBar.Value = positionInUnits;
            else
            {
                var message = $"Invalid new position {elapsed}. Duration: {_currentMilestoneDuration}";
                Logger.Write(message, MessageTypes.Warning);

                if (ApplicationManager.IsDebugMode) throw new InvalidOperationException(message);
            }

            var withFraction = _currentMilestoneDuration < TimeSpan.FromSeconds(MaximumDurationInSecondsDisplayedWithFractions) && _currentMilestoneDuration > TimeSpan.Zero;
            var newText = elapsed.ToString(GetTimeFormat(elapsed, withFraction));
            if (newText.Length == lbPosition.Text.Length)
            {
                lbPosition.Text = newText;
            }
            else
            {
                lbPosition.Text = newText;
                PositionContainer_SizeChanged(this, EventArgs.Empty);
            }

            lbPosition.ToolTipText = elapsed.ToString(GetTimeFormat(elapsed, true));
        }

        public void ShowBlankControl()
        {
            DisableControls();

            blankControl.Enabled = true;
            blankControl.Visible = true;
        }

        private void DisableControls()
        {
            processControl.Enabled = false;
            processControl.Visible = false;

            onABreakControl.Visible = false;
            onABreakControl.Enabled = false;

            interviewPageBrowser.Visible = false;
            interviewPageBrowser.Enabled = false;

            blankControl.Visible = false;
            blankControl.Enabled = false;
        }

        /// <summary>
        /// Close current form 
        /// </summary>
        public void CloseForm()
        {
            Close();
        }

        public Color DefaultControlColor { get; set; }

        /// <summary>
        /// Shows/hides audio toolbar;
        /// </summary>
        /// <param name="show">If true, shows toolbar; otherwise hides.</param>
        public void ShowAudioToolbar(bool show)
        {
            tsAudio.Visible = show;
            EnableAudioToolbar(show);
        }

        public void ShowDeferredToolbar(bool show)
        {
            tsDeffered.Visible = show;
            tsPositionContainer.Visible = show;
        }

        public void ShowLiveToolbar(bool show)
        {
            tsLive.Visible = show;
        }

        public void ShowCoachingToolbarButton(bool show)
        {
            tsbCoaching.Visible = show;
        }

        public void ShowBargingToolbarButton(bool show)
        {
            tsbBarging.Visible = show;
        }

        public void SetListeningToolbarMode(MonitoringMode mode)
        {
            switch (mode)
            {
                case MonitoringMode.Listening:
                    tsbListening.Image = Properties.Resources.listen_selected;
                    tsbCoaching.Image = Properties.Resources.coach_unselected;
                    tsbBarging.Image = Properties.Resources.barge_unselected;
                    break;
                case MonitoringMode.Coaching:
                    tsbListening.Image = Properties.Resources.listen_unselected;
                    tsbCoaching.Image = Properties.Resources.coach_selected;
                    tsbBarging.Image = Properties.Resources.barge_unselected;
                    break;
                case MonitoringMode.Barging:
                    tsbListening.Image = Properties.Resources.listen_unselected;
                    tsbCoaching.Image = Properties.Resources.coach_unselected;
                    tsbBarging.Image = Properties.Resources.barge_selected;
                    break;
            }
        }

        /// <summary>
        /// Enables/disables audio toolbar.
        /// </summary>
        /// <param name="enable">If true, enables audio toolbar; otherwise false.</param>
        public void EnableAudioToolbar(bool enable)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker) delegate { EnableAudioToolbar(enable); });
                return;
            }

            tsAudio.Enabled = enable;
        }

        public void EnableSaveOfflineRecordButton(bool enable)
        {
            tsbSave.Enabled = enable;
        }

        public void EnableDeferredToolbar(bool enable)
        {
            tsbPlayStop.Enabled = enable;
            cbJumpTo.Enabled = enable;
        }

        public void EnableAnsweredQuestionCombobox(bool enable)
        {
            cbJumpTo.Enabled = enable;
        }

        public void UpdatePausePlayButtonState(bool isRecordPaused)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker) delegate { UpdatePausePlayButtonState(isRecordPaused); });
                return;
            }

            tsbPlayStop.Image = isRecordPaused ?
                                Properties.Resources.media_play_green :
                                Properties.Resources.media_pause;
        }

        public void InitJumpToQuestionCombobox(IEnumerable<AnsweredQuestionsComboBoxItem> comboboxItems)
        {
            cbJumpTo.Fill(comboboxItems.ToArray());
        }

        public void SpecifyMainFormStyle(string title, Color color, bool isInboundCall, bool isTestMode)
        {
            Text = title;

            tsMode.Visible = isTestMode || isInboundCall;

            tssMode.Visible = isTestMode && isInboundCall;

            tsbInboundCall.Visible = isInboundCall;
            tsbTestMode.Visible = isTestMode;

            tsContainer.TopToolStripPanel.BackColor = color;
            tsMode.BackColor = color;
            tsDeffered.BackColor = color;
            tsAudio.BackColor = color;
        }

        public event EventHandler FormLoad;

        /// <summary>
        /// Occurs when the form is closed.
        /// </summary>
        public event EventHandler<EventArgs> FormClose;

        /// <summary>
        /// Occurs when user clicks audio forward rewind button.
        /// </summary>
        public event EventHandler AudioForwardRewind;

        /// <summary>
        /// Occurs when user clicks audio backward rewind button.
        /// </summary>
        public event EventHandler AudioBackwardRewind;

        public event EventHandler DefferedRecordPausePlay;

        public event EventHandler SetListeningMode;

        public event EventHandler SetCoachingMode;

        public event EventHandler SetBargingMode;

        public event EventHandler SaveOfflinePlaybackRecord;

        public event EventHandler<JumpToQuestionEventArgs> DeferredRecordJumpToMilestone;

        public event EventHandler<TimeSpan> DeferredRecordJumpToPosition;

        public event EventHandler DeferredRecordJumpToNextMilestone;
        public event EventHandler DeferredRecordJumpToPrevMilestone;

        public SynchronizationContext SynchronizationContext
        {
            get { return _synchronizationContext; }
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            OnFormClose(EventArgs.Empty);
        }

        private void tsbAudioForward_Click(object sender, EventArgs e)
        {
            OnAudioForwardRewind(EventArgs.Empty);
        }

        private void tsbAudioBackward_Click(object sender, EventArgs e)
        {
            OnAudioBackwardRewind(EventArgs.Empty);
        }

        private void tsbPlayStop_Click(object sender, EventArgs e)
        {
            OnDeferredRecordPausePlay(EventArgs.Empty);
        }

        private void tsbListening_Click(object sender, EventArgs e)
        {
            OnSetListeningMode(EventArgs.Empty);
        }

        private void tsbCoaching_Click(object sender, EventArgs e)
        {
            OnSetCoachingMode(EventArgs.Empty);
        }

        private void tsbBarging_Click(object sender, EventArgs e)
        {
            OnSetBargingMode(EventArgs.Empty);
        }

        private void tsbSave_Click(object sender, EventArgs e)
        {
            OnSaveOfflinePlaybackFile(EventArgs.Empty);
        }

        private void OnSaveOfflinePlaybackFile(EventArgs e)
        {
            SaveOfflinePlaybackRecord?.Invoke(this, e);
        }

        private void OnFormLoad(EventArgs e)
        {
            FormLoad?.Invoke(this, e);
        }

        private void OnFormClose(EventArgs e)
        {
            FormClose?.Invoke(this, e);
        }

        private void OnAudioForwardRewind(EventArgs e)
        {
            AudioForwardRewind?.Invoke(this, e);
        }

        private void OnAudioBackwardRewind(EventArgs e)
        {
            AudioBackwardRewind?.Invoke(this, e);
        }

        private void OnDeferredRecordPausePlay(EventArgs e)
        {
            DefferedRecordPausePlay?.Invoke(this, e);
        }

        private void OnSetListeningMode(EventArgs e)
        {
            SetListeningMode?.Invoke(this, e);
        }

        private void OnSetCoachingMode(EventArgs e)
        {
            SetCoachingMode?.Invoke(this, e);
        }
        private void OnSetBargingMode(EventArgs e)
        {
            SetBargingMode?.Invoke(this, e);
        }

        private void cbJumpTo_ItemSelected(object sender, EventArgs e)
        {
            if (DeferredRecordJumpToMilestone != null)
            {
                DeferredRecordJumpToMilestone(this, new JumpToQuestionEventArgs
                {
                    PageCompletedEventIndex = ((AnsweredQuestionsComboBoxItem)cbJumpTo.SelectedItem).PageCompletedEventIndex,
                    QuestionSelectedEventIndex = ((AnsweredQuestionsComboBoxItem)cbJumpTo.SelectedItem).QuestionSelectedEventIndex,
                });
                interviewPageBrowser.Focus();
            }
        }

        private void tsbRewind_Click(object sender, EventArgs e)
        {
            if (_currentMilestoneDuration <= TimeSpan.Zero) return;
            if (DeferredRecordJumpToPosition == null) return;
            var pos = GetFlowingTime(tsPositionBar.Value) - TimeSpan.FromSeconds(Settings.Default.RewindIntervalSec);
            DeferredRecordJumpToPosition(this, pos);
            interviewPageBrowser.Focus();
        }

        private void tsbForward_Click(object sender, EventArgs e)
        {
            if (_currentMilestoneDuration <= TimeSpan.Zero) return;
            if (DeferredRecordJumpToPosition == null) return;
            var pos = GetFlowingTime(tsPositionBar.Value) + TimeSpan.FromSeconds(Settings.Default.RewindIntervalSec);
            DeferredRecordJumpToPosition(this, pos);
            interviewPageBrowser.Focus();
        }

        private int? _playPositionCursorX;
        private void tsPositionBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.X == _playPositionCursorX) return;

            var pos = Convert.ToInt32(Math.Round(
                (double) e.X * tsPositionBar.Maximum / tsPositionBar.Width));
            var timeSpan = GetFlowingTime(pos);
            var timeText = timeSpan.ToString(GetTimeFormat(timeSpan, true));

            var control = tsPositionBar.Control;
            var loc = PointToScreen(LocationOnForm(control));
            loc.Offset(-Left + e.X - 19, -Top - 20); //19 - half of width and 20 - height of tooltip
            _playPositionToolTip.Show(timeText, this, loc);
            _playPositionCursorX = e.X;
        }

        private Point LocationOnForm(Control c)
        {
            var result = new Point(0, 0);
            for (; c.Parent != null; c = c.Parent) result.Offset(c.Location);
            return result;
        }

        private void tsPositionBar_MouseLeave(object sender, EventArgs e)
        {
            _playPositionToolTip.Hide(this);
        }

        private void tsPositionBar_Click(object sender, EventArgs e)
        {
            if (_playPositionCursorX == null) return;
            if (DeferredRecordJumpToPosition == null) return;

            var pos = Convert.ToInt32(Math.Round(
                (double) _playPositionCursorX.Value * tsPositionBar.Maximum / tsPositionBar.Width));
            var time = GetFlowingTime(pos);
            DeferredRecordJumpToPosition(this, time);
            interviewPageBrowser.Focus();
        }

        private static string GetTimeFormat(TimeSpan timeSpan, bool withFraction)
        {
            var minuteFormat = withFraction ? @"mm\:ss\.f" : @"mm\:ss";
            return timeSpan < new TimeSpan(1, 0, 0) ? minuteFormat : @"h\:mm\:ss";
        }

        private static int GetDiscreteTime(TimeSpan span)
        {
            return Convert.ToInt32(Math.Round(span.TotalMilliseconds / Settings.Default.SamplingFrequencyMillisec));
        }

        private static TimeSpan GetFlowingTime(int units)
        {
            return new TimeSpan(0, 0, 0, 0, units * Settings.Default.SamplingFrequencyMillisec);
        }

        private void tsbRewindPrev_Click(object sender, EventArgs e)
        {
            if (DeferredRecordJumpToPrevMilestone == null) return;
            DeferredRecordJumpToPrevMilestone(this, e);
            interviewPageBrowser.Focus();
        }

        private void tsbForwardNext_Click(object sender, EventArgs e)
        {
            if (DeferredRecordJumpToNextMilestone == null) return;
            DeferredRecordJumpToNextMilestone(this, e);
            interviewPageBrowser.Focus();
        }
    }
}
