﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Resources;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;
using Confirmit.CATI.MonitoringConsole.Classes;
using Confirmit.CATI.MonitoringConsole.Resources;

namespace Confirmit.CATI.MonitoringConsole.Presenters
{
    public class PresenterRedial
    {
        private readonly IContext _context;

        public PresenterRedial(IViewRedialForm redialForm, IWin32Window parentForm, IContext context)
        {
            if (redialForm == null)
            {
                throw new ArgumentNullException("redialForm");
            }
            if (parentForm == null)
            {
                throw new ArgumentNullException("parentForm");
            }

            ParentForm = parentForm;
            RedialForm = redialForm;
            _context = context;
        }

        internal IViewRedialForm RedialForm { get; set; }

        internal IWin32Window ParentForm { get; set; }

        public void PlayEvent(MonitoringMessageTypes messageType, BaseStateData stateData)
        {
            SendOrPostCallback callback = null;
            switch (messageType)
            {
                case MonitoringMessageTypes.RedialFormCloseMessage:
                    callback = PlayRedialFormCloseMessage;
                    break;
                case MonitoringMessageTypes.RedialFormInitialMessage:
                    callback = PlayRedialFormInitialMessage;
                    break;
                case MonitoringMessageTypes.RedialFormDialCalledMessage:
                    callback = PlayRedialFormDialCalledMessage;
                    break;
                case MonitoringMessageTypes.RedialFormHangupDialCalledMessage:
                    callback = PlayRedialFormHangupDialCalledMessage;
                    break;
                case MonitoringMessageTypes.RedialFormRedialTypeChangedMessage:
                    callback = PlayRedialFormRedialTypeChangedMessage;
                    break;
                case MonitoringMessageTypes.RedialFormDialNumberChangedMessage:
                    callback = PlayRedialFormDialNumberChangedMessage;
                    break;
                case MonitoringMessageTypes.RedialFormTelephonyResultMessage:
                    callback = PlayRedialFormTelephonyResultMessage;
                    break;
                default:
                    Logger.Write(
                         Strings.ResourceManager.GetString("Warning_UnsupportedEvent", messageType),
                         MessageTypes.Warning
                     );
                    break;
            }

            if (callback != null)
            {
                _context.Post(callback, stateData);
            }
        }

        private void PlayRedialFormTelephonyResultMessage(object state)
        {
            var eventData = (RedialTelephonyResultStateData)state;

            RedialForm.SetDialingInProgressVisibility(false);
            RedialForm.NotifyLastCallOutcome(eventData.CallOutcome);
        }

        private void PlayRedialFormDialNumberChangedMessage(object state)
        {
            var eventData = (RedialNumberChangedStateData)state;

            RedialForm.DialNumber = eventData.DialNumber;
        }

        private void PlayRedialFormRedialTypeChangedMessage(object state)
        {
            var eventData = (RedialTypeChangedStateData)state;

            RedialForm.RedialNewNumber = eventData.IsNewNumberDialChecked;
            RedialForm.EnableInputControls(false);
        }

        private void PlayRedialFormDialCalledMessage(object state)
        {
            var eventData = (RedialDialCalledStateData)state;

            RedialForm.SetProcessMessage(eventData.Message);
            RedialForm.SetDialCanellationButtonVisibility(eventData.IsDialCanellationButtonVisible);
            RedialForm.IsDialCanellationButtonEnabled = false;
            RedialForm.SetDialingInProgressVisibility(true);
        }

        private void PlayRedialFormHangupDialCalledMessage(object state)
        {
            var eventData = (RedialHangupDialCalledStateData)state;

            RedialForm.SetProcessMessage(eventData.Message);
        }

        private void PlayRedialFormCloseMessage(object stateData)
        {
            RedialForm.HideForm();
        }

        private void PlayRedialFormInitialMessage(object stateData)
        {
            RedialForm.ShowNonModal(ParentForm);
            RedialForm.EnableInputControls(false);
        }

        public void CloseRedialForm()
        {
            if (RedialForm.IsVisible == false)
            {
                return;
            }

            RedialForm.HideForm();
        }
    }
}
