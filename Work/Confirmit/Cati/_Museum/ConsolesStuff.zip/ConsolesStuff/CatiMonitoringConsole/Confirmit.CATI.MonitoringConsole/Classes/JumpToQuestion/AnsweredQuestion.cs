﻿using Confirmit.CATI.Monitoring.Common.Contracts;

namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    public class AnsweredQuestion : MilestoneEvent
    {
        public AnsweredQuestion(StateEventInfo stateEventInfo) : base(new EventInfo(stateEventInfo))
        {
        }

        public AnsweredQuestion() : base()
        {
        }

        public string Id { get; set; }

        public string QuestionTitle { get; set; }

        public string QuestionText { get; set; }
    }
}
