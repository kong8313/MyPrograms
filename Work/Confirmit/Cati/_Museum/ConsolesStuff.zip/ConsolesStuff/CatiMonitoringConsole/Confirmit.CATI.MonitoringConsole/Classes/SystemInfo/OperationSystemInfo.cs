﻿namespace Confirmit.CATI.MonitoringConsole.Classes.SystemInfo
{
    /// <summary>
    /// Represents information about operation system
    /// </summary>
    public class OperationSystemInfo
    {        
        /// <summary>
        /// Gets/sets product type
        /// </summary>
        public ProductType ProductType
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets processor architecture
        /// </summary>
        public ProcessorArchitecture ProcessorArchitecture
        {
            get;
            set;
        }
    }
}