﻿using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.Interfaces;
using Confirmit.CATI.MonitoringConsole.Services.MonitoringService;

namespace Confirmit.CATI.MonitoringConsole.Classes
{
    public class MonitoringModeProvider : IMonitoringModeProvider
    {
        public void SetLiveMonitoringMode(MonitoringMode mode)
        {
            MonitoringServiceManager.SetLiveMonitoringMode(
                UserPassport.Instance.CurrentIdentityInfo.SupervisorName,
                UserPassport.Instance.CurrentIdentityInfo.InterviewerId, 
                mode);
        }
    }
}
