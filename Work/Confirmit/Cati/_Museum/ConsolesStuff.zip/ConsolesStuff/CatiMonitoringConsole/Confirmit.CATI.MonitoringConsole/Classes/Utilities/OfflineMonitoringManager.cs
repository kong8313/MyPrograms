using System.Collections.Generic;
using System.IO;
using System.Linq;
using Confirmit.CATI.Common.Monitoring;
using Confirmit.CATI.Monitoring.Common.Contracts;

namespace Confirmit.CATI.MonitoringConsole.Classes.Utilities
{
    public class OfflineMonitoringManager
    {
        private readonly OfflineMonitoringLaunchInfo _launchInfo;

        public OfflineMonitoringManager(OfflineMonitoringLaunchInfo launchInfo)
        {
            _launchInfo = launchInfo;
        }

        public Dictionary<AudioIdentityObject, string> GetAudioFiles()
        {
            var audioFiles = new Dictionary<AudioIdentityObject, string>();

            if (!_launchInfo.AudioFilesPaths.Any()) 
                return audioFiles;

            foreach (var launchInfoAudioFilesPath in _launchInfo.AudioFilesPaths)
            {
                var newAudioIdentity = new AudioIdentityObject
                {
                    ID = launchInfoAudioFilesPath,
                    Name = Path.GetFileName(launchInfoAudioFilesPath)
                };

                audioFiles.Add(newAudioIdentity, newAudioIdentity.ID);
            }

            return audioFiles;
        }

        public IEnumerable<StateEventInfo> GetEvents()
        {
            var events = Enumerable.Empty<StateEventInfo>();

            if (string.IsNullOrEmpty(_launchInfo.VideoFilePath))
                return events;

            using (var stream = File.Open(_launchInfo.VideoFilePath, FileMode.Open))
            {
                events = StateEventInfoDepacker.GetAllEvents(stream);
            }

            return events;
        }

        public OfflineMonitoringLaunchInfo UpdateLaunchInfo(
            string fileName,
            string videoFileExtension,
            string audioFileExtension,
            string metadataFileExtension
            )
        {
            var extension = Path.GetExtension(fileName);

            if (extension == videoFileExtension)
            {
                _launchInfo.VideoFilePath = fileName;
            }

            if (extension == audioFileExtension)
            {
                _launchInfo.AudioFilesPaths.Add(fileName);
            }

            if (extension == metadataFileExtension)
            {
                _launchInfo.MetadataFilePath = fileName;
            }

            return _launchInfo;
        }
    }
}