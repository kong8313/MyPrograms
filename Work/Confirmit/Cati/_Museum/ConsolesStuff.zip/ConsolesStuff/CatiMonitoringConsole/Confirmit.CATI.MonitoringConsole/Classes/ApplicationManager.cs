﻿using System;
using System.Deployment.Application;
using System.IO;
using System.Linq;
using System.Reflection;
using Confirmit.CATI.MonitoringConsole.Classes.Utilities;

namespace Confirmit.CATI.MonitoringConsole.Classes
{
    /// <summary>
    /// Represents application manager.
    /// </summary>
    internal static class ApplicationManager
    {
        /// <summary>
        /// Gets version of execution assembly
        /// </summary>
        public static string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        /// <summary>
        /// Gets path to folder where client settings file is stored
        /// </summary>
        public static string ApplicationPath
        {
            get
            {
                return string.Format("{0}\\Confirmit\\CATI\\Monitoring", Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData));
            }
        }

        /// <summary>
        /// Gets path to lisence agreement file. If file exists, we consider that user accepted license.
        /// </summary>
        public static string LicenseAgreementFilePath
        {
            get
            {
                return ApplicationPath + Path.DirectorySeparatorChar + "License Agreement.txt";
            }
        }

        /// <summary>
        /// Gets value indicating that license already has been shown.
        /// </summary>
        public static bool HasLicenseAgreementBeenShown
        {
            get
            {
                return File.Exists(LicenseAgreementFilePath);
            }
        }

        /// <summary>
        /// Saves license agreement.
        /// </summary>
        public static void SaveLicenseAgreement()
        {
            if (!File.Exists(LicenseAgreementFilePath))
            {
                using (File.Create(LicenseAgreementFilePath))
                {
                }
            }
        }

        public static bool IsClickOnce => ApplicationDeployment.IsNetworkDeployed;

        private static ActivationArgumentsManager _activationArgumentsManager;

        public static ActivationArgumentsManager ActivationArgumentsManager =>
            _activationArgumentsManager ??
            (_activationArgumentsManager = IsClickOnce ? 
                new ActivationArgumentsManager(AppDomain.CurrentDomain.SetupInformation.ActivationArguments) :
                new ActivationArgumentsManager(Environment.GetCommandLineArgs()));

        public static bool IsDebugMode => ActivationArgumentsManager.HasDebugArgument;

        public static bool IsFromUri => IsClickOnce && ActivationArgumentsManager.DataPathContainsEncryptedData();
    }
}
