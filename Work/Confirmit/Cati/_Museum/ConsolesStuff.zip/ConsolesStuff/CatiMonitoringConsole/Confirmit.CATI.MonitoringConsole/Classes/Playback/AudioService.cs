﻿using System.IO;
using System.Net;

namespace Confirmit.CATI.MonitoringConsole.Classes.Playback
{
    public class AudioService : IAudioService
    {
        public Stream GetAudioStreamByIdentityId(string identityId)
        {
            return DownloadAudioFileDataAction(identityId);
        }

        private Stream DownloadAudioFileDataAction(string identityId)
        {
            using (var webClient = new WebClient())
            {
                byte[] data = webClient.DownloadData(identityId);
                return new MemoryStream(data);
            }
        }

    }
}
