﻿namespace Confirmit.CATI.MonitoringConsole.Classes.SystemInfo
{
    public enum PlatformType
    {
        Bit32,
        Bit64
    }
}
