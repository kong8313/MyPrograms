﻿namespace Confirmit.CATI.MonitoringConsole.Classes
{
    public class LiteralConstants
    {
        public const string LauncherName = "Launcher.appref-ms";
        public const string UrlProtocol = "cati-monitoring";
        public const string EncryptedData = "EncryptedData";
        public const string CompanyId = "CompanyId";
        public const string ServerName = "ServerName";
    }
}
