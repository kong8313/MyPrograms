﻿using Confirmit.CATI.Console.Views.Classes.StatusBar;
using Confirmit.CATI.Console.Views.Controls;
using Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion;
using Confirmit.CATI.MonitoringConsole.Classes.Playback;

namespace Confirmit.CATI.MonitoringConsole
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.pnlMain = new System.Windows.Forms.Panel();
            this.tsContainer = new System.Windows.Forms.ToolStripContainer();
            this.pnlControls = new System.Windows.Forms.Panel();
            this.blankControl = new System.Windows.Forms.Panel();
            this.processControl = new Confirmit.CATI.Console.Views.Controls.ProcessControl();
            this.interviewPageBrowser = new Confirmit.CATI.Console.Views.Controls.InterviewPageBrowser();
            this.onABreakControl = new Confirmit.CATI.Console.Views.Controls.OnABreakControl();
            this.tsDeffered = new System.Windows.Forms.ToolStrip();
            this.tsbPlayStop = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.cbJumpTo = new Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion.AnsweredQuestionsComboBox();
            this.tsbSave = new System.Windows.Forms.ToolStripButton();
            this.tsLive = new System.Windows.Forms.ToolStrip();
            this.tsbListening = new System.Windows.Forms.ToolStripButton();
            this.tsbCoaching = new System.Windows.Forms.ToolStripButton();
            this.tsbBarging = new System.Windows.Forms.ToolStripButton();
            this.tsMode = new System.Windows.Forms.ToolStrip();
            this.tsbTestMode = new System.Windows.Forms.ToolStripButton();
            this.tssMode = new System.Windows.Forms.ToolStripSeparator();
            this.tsbInboundCall = new System.Windows.Forms.ToolStripButton();
            this.tsAudio = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbAudioBackward = new System.Windows.Forms.ToolStripButton();
            this.tsbAudioForward = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.menuStripHotkeys = new System.Windows.Forms.MenuStrip();
            this.tsmiRewind = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiForward = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiPause = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiRewindPrev = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiForwardNext = new System.Windows.Forms.ToolStripMenuItem();
            this.tsPositionContainer = new System.Windows.Forms.ToolStrip();
            this.tsbRewindPrev = new System.Windows.Forms.ToolStripButton();
            this.tsbRewind = new System.Windows.Forms.ToolStripButton();
            this.lbPosition = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsPositionBar = new Confirmit.CATI.MonitoringConsole.Classes.Playback.ToolStripSpringProgressBar();
            this.lbTotal = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsbForward = new System.Windows.Forms.ToolStripButton();
            this.tsbForwardNext = new System.Windows.Forms.ToolStripButton();
            this.pnlStatusBar = new System.Windows.Forms.Panel();
            this.statusBar = new Confirmit.CATI.Console.Views.Controls.StatusBarControl();
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.pnlMain.SuspendLayout();
            this.tsContainer.ContentPanel.SuspendLayout();
            this.tsContainer.TopToolStripPanel.SuspendLayout();
            this.tsContainer.SuspendLayout();
            this.pnlControls.SuspendLayout();
            this.tsDeffered.SuspendLayout();
            this.tsLive.SuspendLayout();
            this.tsMode.SuspendLayout();
            this.tsAudio.SuspendLayout();
            this.menuStripHotkeys.SuspendLayout();
            this.tsPositionContainer.SuspendLayout();
            this.pnlStatusBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.tsContainer);
            this.pnlMain.Controls.Add(this.pnlStatusBar);
            this.pnlMain.Controls.Add(this.pnlMenu);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1225, 961);
            this.pnlMain.TabIndex = 0;
            // 
            // tsContainer
            // 
            // 
            // tsContainer.ContentPanel
            // 
            this.tsContainer.ContentPanel.Controls.Add(this.pnlControls);
            this.tsContainer.ContentPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tsContainer.ContentPanel.Size = new System.Drawing.Size(1225, 863);
            this.tsContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tsContainer.Location = new System.Drawing.Point(0, 0);
            this.tsContainer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tsContainer.Name = "tsContainer";
            this.tsContainer.Size = new System.Drawing.Size(1225, 928);
            this.tsContainer.TabIndex = 3;
            this.tsContainer.Text = "toolStripContainer1";
            // 
            // tsContainer.TopToolStripPanel
            // 
            this.tsContainer.TopToolStripPanel.Controls.Add(this.tsDeffered);
            this.tsContainer.TopToolStripPanel.Controls.Add(this.tsLive);
            this.tsContainer.TopToolStripPanel.Controls.Add(this.tsMode);
            this.tsContainer.TopToolStripPanel.Controls.Add(this.tsAudio);
            this.tsContainer.TopToolStripPanel.Controls.Add(this.menuStripHotkeys);
            this.tsContainer.TopToolStripPanel.Controls.Add(this.tsPositionContainer);
            this.tsContainer.TopToolStripPanel.MaximumSize = new System.Drawing.Size(0, 123);
            // 
            // pnlControls
            // 
            this.pnlControls.Controls.Add(this.blankControl);
            this.pnlControls.Controls.Add(this.processControl);
            this.pnlControls.Controls.Add(this.interviewPageBrowser);
            this.pnlControls.Controls.Add(this.onABreakControl);
            this.pnlControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlControls.Location = new System.Drawing.Point(0, 0);
            this.pnlControls.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(1225, 863);
            this.pnlControls.TabIndex = 2;
            // 
            // blankControl
            // 
            this.blankControl.BackColor = System.Drawing.SystemColors.Window;
            this.blankControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.blankControl.Enabled = false;
            this.blankControl.Location = new System.Drawing.Point(0, 0);
            this.blankControl.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.blankControl.Name = "blankControl";
            this.blankControl.Size = new System.Drawing.Size(1225, 863);
            this.blankControl.TabIndex = 7;
            this.blankControl.Visible = false;
            // 
            // processControl
            // 
            this.processControl.BackColor = System.Drawing.SystemColors.Window;
            this.processControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.processControl.Location = new System.Drawing.Point(0, 0);
            this.processControl.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.processControl.Name = "processControl";
            this.processControl.Size = new System.Drawing.Size(1225, 863);
            this.processControl.TabIndex = 5;
            this.processControl.Visible = false;
            // 
            // interviewPageBrowser
            // 
            this.interviewPageBrowser.CurrentQuestionIndex = 0;
            this.interviewPageBrowser.DialStatus = null;
            this.interviewPageBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.interviewPageBrowser.ExtendedLoggingEnabled = true;
            this.interviewPageBrowser.Location = new System.Drawing.Point(0, 0);
            this.interviewPageBrowser.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.interviewPageBrowser.MouseClickAnswerMonitoringDelay = 0;
            this.interviewPageBrowser.Name = "interviewPageBrowser";
            this.interviewPageBrowser.PageUpdateMonitoringDelay = 0;
            this.interviewPageBrowser.ReadOnly = true;
            this.interviewPageBrowser.Size = new System.Drawing.Size(1225, 863);
            this.interviewPageBrowser.Status = "";
            this.interviewPageBrowser.TabIndex = 4;
            // 
            // onABreakControl
            // 
            this.onABreakControl.BackColor = System.Drawing.SystemColors.Window;
            this.onABreakControl.BreakTypeInfo = null;
            this.onABreakControl.ButtonsEnabled = true;
            this.onABreakControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.onABreakControl.Location = new System.Drawing.Point(0, 0);
            this.onABreakControl.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.onABreakControl.Name = "onABreakControl";
            this.onABreakControl.Size = new System.Drawing.Size(1225, 863);
            this.onABreakControl.StartTime = new System.DateTime(((long)(0)));
            this.onABreakControl.TabIndex = 6;
            // 
            // tsDeffered
            // 
            this.tsDeffered.Dock = System.Windows.Forms.DockStyle.None;
            this.tsDeffered.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsDeffered.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tsDeffered.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbPlayStop,
            this.toolStripSeparator1,
            this.cbJumpTo,
            this.tsbSave});
            this.tsDeffered.Location = new System.Drawing.Point(368, 0);
            this.tsDeffered.Name = "tsDeffered";
            this.tsDeffered.Size = new System.Drawing.Size(323, 39);
            this.tsDeffered.TabIndex = 1;
            // 
            // tsbPlayStop
            // 
            this.tsbPlayStop.AutoSize = false;
            this.tsbPlayStop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPlayStop.Image = global::Confirmit.CATI.MonitoringConsole.Properties.Resources.media_pause;
            this.tsbPlayStop.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsbPlayStop.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbPlayStop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPlayStop.Name = "tsbPlayStop";
            this.tsbPlayStop.Size = new System.Drawing.Size(36, 36);
            this.tsbPlayStop.Text = "PauseOrResume";
            this.tsbPlayStop.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.tsbPlayStop.ToolTipText = "Pause or Resume (Ctrl + Space)";
            this.tsbPlayStop.Click += new System.EventHandler(this.tsbPlayStop_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // cbJumpTo
            // 
            this.cbJumpTo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbJumpTo.DropDownWidth = 240;
            this.cbJumpTo.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.cbJumpTo.MaxDropDownItems = 20;
            this.cbJumpTo.Name = "cbJumpTo";
            this.cbJumpTo.Size = new System.Drawing.Size(240, 39);
            this.cbJumpTo.Text = "Please select a question";
            this.cbJumpTo.ItemSelected += new System.EventHandler<System.EventArgs>(this.cbJumpTo_ItemSelected);
            // 
            // tsbSave
            // 
            this.tsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSave.Enabled = false;
            this.tsbSave.Image = global::Confirmit.CATI.MonitoringConsole.Properties.Resources.save;
            this.tsbSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSave.Name = "tsbSave";
            this.tsbSave.Size = new System.Drawing.Size(36, 36);
            this.tsbSave.Text = "Save recording";
            this.tsbSave.Click += new System.EventHandler(this.tsbSave_Click);
            // 
            // tsLive
            // 
            this.tsLive.Dock = System.Windows.Forms.DockStyle.None;
            this.tsLive.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsLive.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tsLive.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbListening,
            this.tsbCoaching,
            this.tsbBarging});
            this.tsLive.Location = new System.Drawing.Point(4, 0);
            this.tsLive.Name = "tsLive";
            this.tsLive.Size = new System.Drawing.Size(277, 35);
            this.tsLive.TabIndex = 2;
            // 
            // tsbListening
            // 
            this.tsbListening.AutoSize = false;
            this.tsbListening.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbListening.Image = global::Confirmit.CATI.MonitoringConsole.Properties.Resources.listen_unselected;
            this.tsbListening.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsbListening.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbListening.ImageTransparentColor = System.Drawing.Color.White;
            this.tsbListening.Name = "tsbListening";
            this.tsbListening.Size = new System.Drawing.Size(84, 32);
            this.tsbListening.Text = "ListeningMode";
            this.tsbListening.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.tsbListening.ToolTipText = "Listen to the interview";
            this.tsbListening.Click += new System.EventHandler(this.tsbListening_Click);
            // 
            // tsbCoaching
            // 
            this.tsbCoaching.AutoSize = false;
            this.tsbCoaching.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCoaching.Image = global::Confirmit.CATI.MonitoringConsole.Properties.Resources.coach_unselected;
            this.tsbCoaching.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsbCoaching.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbCoaching.ImageTransparentColor = System.Drawing.Color.White;
            this.tsbCoaching.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.tsbCoaching.Name = "tsbCoaching";
            this.tsbCoaching.Size = new System.Drawing.Size(87, 32);
            this.tsbCoaching.Text = "CoachingMode";
            this.tsbCoaching.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.tsbCoaching.ToolTipText = "Listen to and speak to the interviewer";
            this.tsbCoaching.Click += new System.EventHandler(this.tsbCoaching_Click);
            // 
            // tsbBarging
            // 
            this.tsbBarging.AutoSize = false;
            this.tsbBarging.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbBarging.Image = global::Confirmit.CATI.MonitoringConsole.Properties.Resources.barge_unselected;
            this.tsbBarging.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsbBarging.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbBarging.ImageTransparentColor = System.Drawing.Color.White;
            this.tsbBarging.Name = "tsbBarging";
            this.tsbBarging.Size = new System.Drawing.Size(83, 32);
            this.tsbBarging.Text = "BargingMode";
            this.tsbBarging.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.tsbBarging.ToolTipText = "Listen to and speak with the interviewer AND respondent";
            this.tsbBarging.Click += new System.EventHandler(this.tsbBarging_Click);
            // 
            // tsMode
            // 
            this.tsMode.Dock = System.Windows.Forms.DockStyle.None;
            this.tsMode.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsMode.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tsMode.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbTestMode,
            this.tssMode,
            this.tsbInboundCall});
            this.tsMode.Location = new System.Drawing.Point(414, 0);
            this.tsMode.Name = "tsMode";
            this.tsMode.Size = new System.Drawing.Size(281, 39);
            this.tsMode.TabIndex = 2;
            this.tsMode.Visible = false;
            // 
            // tsbTestMode
            // 
            this.tsbTestMode.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tsbTestMode.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tsbTestMode.Image = global::Confirmit.CATI.MonitoringConsole.Properties.Resources.test_mode;
            this.tsbTestMode.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbTestMode.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTestMode.Name = "tsbTestMode";
            this.tsbTestMode.Size = new System.Drawing.Size(127, 36);
            this.tsbTestMode.Text = "TEST MODE";
            // 
            // tssMode
            // 
            this.tssMode.Name = "tssMode";
            this.tssMode.Size = new System.Drawing.Size(6, 39);
            // 
            // tsbInboundCall
            // 
            this.tsbInboundCall.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tsbInboundCall.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tsbInboundCall.Image = global::Confirmit.CATI.MonitoringConsole.Properties.Resources.inbound_call;
            this.tsbInboundCall.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbInboundCall.Name = "tsbInboundCall";
            this.tsbInboundCall.Size = new System.Drawing.Size(145, 36);
            this.tsbInboundCall.Text = "INBOUND CALL";
            // 
            // tsAudio
            // 
            this.tsAudio.Dock = System.Windows.Forms.DockStyle.None;
            this.tsAudio.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsAudio.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tsAudio.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator2,
            this.tsbAudioBackward,
            this.tsbAudioForward,
            this.toolStripSeparator3});
            this.tsAudio.Location = new System.Drawing.Point(281, 0);
            this.tsAudio.Name = "tsAudio";
            this.tsAudio.Size = new System.Drawing.Size(87, 39);
            this.tsAudio.TabIndex = 0;
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // tsbAudioBackward
            // 
            this.tsbAudioBackward.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAudioBackward.Image = global::Confirmit.CATI.MonitoringConsole.Properties.Resources.media_step_back;
            this.tsbAudioBackward.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbAudioBackward.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAudioBackward.Name = "tsbAudioBackward";
            this.tsbAudioBackward.Size = new System.Drawing.Size(36, 36);
            this.tsbAudioBackward.Text = "Backward";
            this.tsbAudioBackward.ToolTipText = "Nudge audio sync backwards";
            this.tsbAudioBackward.Click += new System.EventHandler(this.tsbAudioBackward_Click);
            // 
            // tsbAudioForward
            // 
            this.tsbAudioForward.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAudioForward.Image = global::Confirmit.CATI.MonitoringConsole.Properties.Resources.media_step_forward;
            this.tsbAudioForward.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbAudioForward.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAudioForward.Name = "tsbAudioForward";
            this.tsbAudioForward.Size = new System.Drawing.Size(36, 36);
            this.tsbAudioForward.Text = "Forward";
            this.tsbAudioForward.ToolTipText = "Nudge audio sync forwards";
            this.tsbAudioForward.Click += new System.EventHandler(this.tsbAudioForward_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // menuStripHotkeys
            // 
            this.menuStripHotkeys.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStripHotkeys.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStripHotkeys.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiRewind,
            this.tsmiForward,
            this.tsmiPause,
            this.tsmiRewindPrev,
            this.tsmiForwardNext});
            this.menuStripHotkeys.Location = new System.Drawing.Point(0, 39);
            this.menuStripHotkeys.Name = "menuStripHotkeys";
            this.menuStripHotkeys.Size = new System.Drawing.Size(425, 28);
            this.menuStripHotkeys.TabIndex = 4;
            this.menuStripHotkeys.Text = "menuStrip1";
            this.menuStripHotkeys.Visible = false;
            // 
            // tsmiRewind
            // 
            this.tsmiRewind.Name = "tsmiRewind";
            this.tsmiRewind.ShortcutKeyDisplayString = "Ctrl + Left Arrow";
            this.tsmiRewind.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Left)));
            this.tsmiRewind.Size = new System.Drawing.Size(72, 24);
            this.tsmiRewind.Text = "Rewind";
            this.tsmiRewind.Click += new System.EventHandler(this.tsbRewind_Click);
            // 
            // tsmiForward
            // 
            this.tsmiForward.Name = "tsmiForward";
            this.tsmiForward.ShortcutKeyDisplayString = "Ctrl + Right Arrow";
            this.tsmiForward.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Right)));
            this.tsmiForward.Size = new System.Drawing.Size(77, 24);
            this.tsmiForward.Text = "Forward";
            this.tsmiForward.Click += new System.EventHandler(this.tsbForward_Click);
            // 
            // tsmiPause
            // 
            this.tsmiPause.Name = "tsmiPause";
            this.tsmiPause.ShortcutKeyDisplayString = "Ctrl + Space";
            this.tsmiPause.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Space)));
            this.tsmiPause.Size = new System.Drawing.Size(60, 24);
            this.tsmiPause.Text = "Pause";
            this.tsmiPause.Click += new System.EventHandler(this.tsbPlayStop_Click);
            // 
            // tsmiRewindPrev
            // 
            this.tsmiRewindPrev.Name = "tsmiRewindPrev";
            this.tsmiRewindPrev.ShortcutKeyDisplayString = "Ctrl + Shift + Left Arrow";
            this.tsmiRewindPrev.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.Left)));
            this.tsmiRewindPrev.Size = new System.Drawing.Size(100, 24);
            this.tsmiRewindPrev.Text = "RewindPrev";
            this.tsmiRewindPrev.Click += new System.EventHandler(this.tsbRewindPrev_Click);
            // 
            // tsmiForwardNext
            // 
            this.tsmiForwardNext.Name = "tsmiForwardNext";
            this.tsmiForwardNext.ShortcutKeyDisplayString = "Ctrl + Shift + Right Arrow";
            this.tsmiForwardNext.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.Right)));
            this.tsmiForwardNext.Size = new System.Drawing.Size(108, 24);
            this.tsmiForwardNext.Text = "ForwardNext";
            this.tsmiForwardNext.Click += new System.EventHandler(this.tsbForwardNext_Click);
            // 
            // tsPositionContainer
            // 
            this.tsPositionContainer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tsPositionContainer.AutoSize = false;
            this.tsPositionContainer.Dock = System.Windows.Forms.DockStyle.None;
            this.tsPositionContainer.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsPositionContainer.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tsPositionContainer.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbRewindPrev,
            this.tsbRewind,
            this.lbPosition,
            this.tsPositionBar,
            this.lbTotal,
            this.tsbForward,
            this.tsbForwardNext});
            this.tsPositionContainer.Location = new System.Drawing.Point(0, 39);
            this.tsPositionContainer.Name = "tsPositionContainer";
            this.tsPositionContainer.Size = new System.Drawing.Size(1225, 26);
            this.tsPositionContainer.Stretch = true;
            this.tsPositionContainer.TabIndex = 5;
            // 
            // tsbRewindPrev
            // 
            this.tsbRewindPrev.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRewindPrev.Image = ((System.Drawing.Image)(resources.GetObject("tsbRewindPrev.Image")));
            this.tsbRewindPrev.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbRewindPrev.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbRewindPrev.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRewindPrev.Name = "tsbRewindPrev";
            this.tsbRewindPrev.Size = new System.Drawing.Size(29, 23);
            this.tsbRewindPrev.Text = "Rewind";
            this.tsbRewindPrev.ToolTipText = "Rewind to previous question (Ctrl + Shift + Left Arrow)";
            this.tsbRewindPrev.Click += new System.EventHandler(this.tsbRewindPrev_Click);
            // 
            // tsbRewind
            // 
            this.tsbRewind.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRewind.Image = ((System.Drawing.Image)(resources.GetObject("tsbRewind.Image")));
            this.tsbRewind.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbRewind.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbRewind.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRewind.Name = "tsbRewind";
            this.tsbRewind.Size = new System.Drawing.Size(29, 23);
            this.tsbRewind.Text = "Rewind";
            this.tsbRewind.ToolTipText = "Rewind (Ctrl + Left Arrow)";
            this.tsbRewind.Click += new System.EventHandler(this.tsbRewind_Click);
            // 
            // lbPosition
            // 
            this.lbPosition.Name = "lbPosition";
            this.lbPosition.Size = new System.Drawing.Size(44, 20);
            this.lbPosition.Text = "00:00";
            // 
            // tsPositionBar
            // 
            this.tsPositionBar.AutoSize = false;
            this.tsPositionBar.BackColor = System.Drawing.SystemColors.Control;
            this.tsPositionBar.Color = System.Drawing.Color.DodgerBlue;
            this.tsPositionBar.Cursor = System.Windows.Forms.Cursors.Default;
            this.tsPositionBar.Disabled = false;
            this.tsPositionBar.MarqueeAnimationSpeed = 10;
            this.tsPositionBar.Maximum = 1;
            this.tsPositionBar.Name = "tsPositionBar";
            this.tsPositionBar.Size = new System.Drawing.Size(752, 16);
            this.tsPositionBar.Step = 1;
            this.tsPositionBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.tsPositionBar.Value = 1;
            this.tsPositionBar.Click += new System.EventHandler(this.tsPositionBar_Click);
            this.tsPositionBar.MouseLeave += new System.EventHandler(this.tsPositionBar_MouseLeave);
            this.tsPositionBar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.tsPositionBar_MouseMove);
            // 
            // lbTotal
            // 
            this.lbTotal.Name = "lbTotal";
            this.lbTotal.Size = new System.Drawing.Size(44, 20);
            this.lbTotal.Text = "00:00";
            // 
            // tsbForward
            // 
            this.tsbForward.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbForward.Image = ((System.Drawing.Image)(resources.GetObject("tsbForward.Image")));
            this.tsbForward.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbForward.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbForward.Name = "tsbForward";
            this.tsbForward.Size = new System.Drawing.Size(29, 23);
            this.tsbForward.Text = "Forward";
            this.tsbForward.ToolTipText = "Forward (Ctrl + Right Arrow)";
            this.tsbForward.Click += new System.EventHandler(this.tsbForward_Click);
            // 
            // tsbForwardNext
            // 
            this.tsbForwardNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbForwardNext.Image = ((System.Drawing.Image)(resources.GetObject("tsbForwardNext.Image")));
            this.tsbForwardNext.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbForwardNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbForwardNext.Name = "tsbForwardNext";
            this.tsbForwardNext.Size = new System.Drawing.Size(29, 23);
            this.tsbForwardNext.Text = "Forward";
            this.tsbForwardNext.ToolTipText = "Forward to next question (Ctrl + Shift + Right Arrow)";
            this.tsbForwardNext.Click += new System.EventHandler(this.tsbForwardNext_Click);
            // 
            // pnlStatusBar
            // 
            this.pnlStatusBar.Controls.Add(this.statusBar);
            this.pnlStatusBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlStatusBar.Location = new System.Drawing.Point(0, 928);
            this.pnlStatusBar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlStatusBar.Name = "pnlStatusBar";
            this.pnlStatusBar.Size = new System.Drawing.Size(1225, 33);
            this.pnlStatusBar.TabIndex = 1;
            // 
            // statusBar
            // 
            this.statusBar.CurrentPosition = "";
            this.statusBar.CurrentState = "";
            this.statusBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statusBar.InterviewerTime = "";
            this.statusBar.InterviewName = "";
            this.statusBar.Location = new System.Drawing.Point(0, 0);
            this.statusBar.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.statusBar.Mode = Confirmit.CATI.Console.Views.Classes.StatusBar.StatusBarModes.MainViewPlayer;
            this.statusBar.Name = "statusBar";
            this.statusBar.QuestionName = "";
            this.statusBar.RespondentTime = "";
            this.statusBar.Size = new System.Drawing.Size(1225, 33);
            this.statusBar.SurveyName = "";
            this.statusBar.TabIndex = 0;
            this.statusBar.UserName = "";
            this.statusBar.Version = "";
            // 
            // pnlMenu
            // 
            this.pnlMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlMenu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(1225, 0);
            this.pnlMenu.TabIndex = 0;
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1225, 961);
            this.Controls.Add(this.pnlMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStripHotkeys;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MainForm";
            this.Text = "Monitoring Console";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.pnlMain.ResumeLayout(false);
            this.tsContainer.ContentPanel.ResumeLayout(false);
            this.tsContainer.TopToolStripPanel.ResumeLayout(false);
            this.tsContainer.TopToolStripPanel.PerformLayout();
            this.tsContainer.ResumeLayout(false);
            this.tsContainer.PerformLayout();
            this.pnlControls.ResumeLayout(false);
            this.tsDeffered.ResumeLayout(false);
            this.tsDeffered.PerformLayout();
            this.tsLive.ResumeLayout(false);
            this.tsLive.PerformLayout();
            this.tsMode.ResumeLayout(false);
            this.tsMode.PerformLayout();
            this.tsAudio.ResumeLayout(false);
            this.tsAudio.PerformLayout();
            this.menuStripHotkeys.ResumeLayout(false);
            this.menuStripHotkeys.PerformLayout();
            this.tsPositionContainer.ResumeLayout(false);
            this.tsPositionContainer.PerformLayout();
            this.pnlStatusBar.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.Panel pnlStatusBar;
        private System.Windows.Forms.Panel pnlMenu;
        private InterviewPageBrowser interviewPageBrowser;
        private StatusBarControl statusBar;
        private ProcessControl processControl;
        private System.Windows.Forms.ToolStripContainer tsContainer;
        private System.Windows.Forms.ToolStrip tsAudio;
        private System.Windows.Forms.ToolStripButton tsbAudioBackward;
        private System.Windows.Forms.ToolStripButton tsbAudioForward;
        private OnABreakControl onABreakControl;
        private System.Windows.Forms.Panel blankControl;
        private System.Windows.Forms.ToolStrip tsDeffered;
        private System.Windows.Forms.ToolStrip tsLive;
        private System.Windows.Forms.ToolStripButton tsbPlayStop;
        private System.Windows.Forms.ToolStripButton tsbListening;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private AnsweredQuestionsComboBox cbJumpTo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator tssMode;
        private System.Windows.Forms.ToolStripButton tsbSave;
        private System.Windows.Forms.ToolStrip tsMode;
        private System.Windows.Forms.ToolStripButton tsbTestMode;
        private System.Windows.Forms.ToolStripButton tsbInboundCall;
        private System.Windows.Forms.ToolStripButton tsbCoaching;
        private System.Windows.Forms.ToolStripButton tsbBarging;
        private System.Windows.Forms.ToolStripMenuItem tsmiForward;
        private System.Windows.Forms.ToolStripMenuItem tsmiRewind;
        private System.Windows.Forms.MenuStrip menuStripHotkeys;
        private System.Windows.Forms.ToolStrip tsPositionContainer;
        private System.Windows.Forms.ToolStripStatusLabel lbTotal;
        private System.Windows.Forms.ToolStripButton tsbForward;
        private System.Windows.Forms.ToolStripButton tsbRewind;
        private System.Windows.Forms.ToolStripStatusLabel lbPosition;
        private System.Windows.Forms.ToolStripButton tsbRewindPrev;
        private System.Windows.Forms.ToolStripButton tsbForwardNext;
        private System.Windows.Forms.ToolStripMenuItem tsmiPause;
        private ToolStripSpringProgressBar tsPositionBar;
        private System.Windows.Forms.ToolStripMenuItem tsmiRewindPrev;
        private System.Windows.Forms.ToolStripMenuItem tsmiForwardNext;
    }
}