namespace Confirmit.CATI.MonitoringConsole.Classes.Utilities
{
    public interface ICustomUriRegistration
    {
        void Register();
    }
}