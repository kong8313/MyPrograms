﻿using Confirmit.CATI.Common.Monitoring;

namespace Confirmit.CATI.MonitoringConsole.Classes
{
    /// <summary>
    /// Contains user specific data. For instance, identity information which was sent by monitirong start file.
    /// </summary>
    internal class UserPassport
    {
        private static UserPassport m_Instance = null;
        private readonly InterviewInfo _interviewInfo = new InterviewInfo();

        /// <summary>
        /// Gets instance of this class.
        /// </summary>
        public static UserPassport Instance
        {
            get { return m_Instance ?? (m_Instance = new UserPassport()); }
        }

        /// <summary>
        /// Gets/sets identity information which was sent in monitoring start file.
        /// </summary>
        public MonitoringIdentityInfo CurrentIdentityInfo { get; set; }

        public InterviewInfo InterviewInfo { get { return _interviewInfo; } }
    }
}
