﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;

namespace Confirmit.CATI.MonitoringConsole.Classes
{
    public class InterviewInitialEventsProvider
    {
        private EventInfo[] _events;

        public InterviewInitialEventsProvider(IEnumerable<StateEventInfo> events)
        {
            _events = events.Where(x => x.MessageType == MonitoringMessageTypes.InterviewInitialMessage)
                .Select(x => new EventInfo(x)).ToArray();
        }

        public EventInfo[] GetAll()
        {
            return _events;
        }

        public EventInfo GetNearestLeft(DateTime timeStamp)
        {
            return _events.OrderByDescending(x => x.TimeStamp).First(x => x.TimeStamp <= timeStamp);
        }
    }
}
