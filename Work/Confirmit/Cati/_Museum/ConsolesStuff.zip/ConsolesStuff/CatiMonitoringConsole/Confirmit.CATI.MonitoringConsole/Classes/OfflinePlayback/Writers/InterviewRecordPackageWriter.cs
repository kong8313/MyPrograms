﻿using System;
using System.IO;
using System.IO.Packaging;
using System.Xml.Serialization;

namespace Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback.Writers
{
    public class InterviewRecordPackageWriter : IInterviewRecordWriter
    {
        // TODO: Need to move file extensions in common place.
        private const string EventsPartName = "events.cce";
        private const string AudioPartName = "audio_.wav";
        private const string MetadataPartName = "metadata.xml";

        public void WriteRecord(InterviewRecordData writeData, string fileName)
        {
            using (Package package = Package.Open(fileName, FileMode.Create))
            {
                WriteEvents(package, writeData);
                WriteAudio(package, writeData);
                WriteMetadata(package, writeData);
            }
        }

        private void WriteEvents(Package package, InterviewRecordData writeData)
        {
            PackagePart eventsPart = CreatePackagePart(package, EventsPartName);
            using (writeData.EventsStream)
            {
                writeData.EventsStream.Seek(0, SeekOrigin.Begin);
                using (Stream eventsPartStream = eventsPart.GetStream())
                {
                    writeData.EventsStream.CopyTo(eventsPartStream);
                }
            }
        }

        private void WriteAudio(Package package, InterviewRecordData writeData)
        {
            if (!writeData.HasAudio() || writeData.AudioStreams == null)
            {
                return;
            }

            var index = 0;
            foreach (var audioStream in writeData.AudioStreams)
            {
                var audioPart = CreatePackagePart(package, AudioPartName.Replace("_", index.ToString()));
                using (var audioPartStream = audioPart.GetStream())
                {
                    audioStream.CopyTo(audioPartStream);
                }

                index++;
            }
        }

        private void WriteMetadata(Package package, InterviewRecordData writeData)
        {
            PackagePart metadataPart = CreatePackagePart(
                package,
                MetadataPartName,
                System.Net.Mime.MediaTypeNames.Text.Xml
                );
            using (Stream metadataPartStream = metadataPart.GetStream())
            {
                var serializer = new XmlSerializer(writeData.Metadata.GetType());
                serializer.Serialize(metadataPartStream, writeData.Metadata);
            }
        }

        private static PackagePart CreatePackagePart(
            Package package,
            string fileName,
            string contentType = System.Net.Mime.MediaTypeNames.Application.Octet
            )
        {
            var packageUri = PackUriHelper.CreatePartUri(new Uri(fileName, UriKind.Relative));
            var packagePart = package.CreatePart(
                packageUri,
                contentType,
                CompressionOption.NotCompressed
                );

            return packagePart;
        }

    }
}
