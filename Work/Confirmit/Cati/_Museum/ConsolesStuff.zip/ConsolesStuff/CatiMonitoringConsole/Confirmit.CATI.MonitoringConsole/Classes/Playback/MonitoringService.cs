﻿using System.Collections.Generic;
using System.IO;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.Services.MonitoringService;

namespace Confirmit.CATI.MonitoringConsole.Classes.Playback
{
    public class MonitoringService : IMonitoringService
    {
        public Stream GetDeferredRecord(long recordId)
        {
            return MonitoringServiceManager.GetDeferredRecord(recordId);
        }

        public IEnumerable<AudioIdentityObject> GetAudioIdentity(long recordId)
        {
            return MonitoringServiceManager.GetAudioIdentities(recordId);
        }

    }
}
