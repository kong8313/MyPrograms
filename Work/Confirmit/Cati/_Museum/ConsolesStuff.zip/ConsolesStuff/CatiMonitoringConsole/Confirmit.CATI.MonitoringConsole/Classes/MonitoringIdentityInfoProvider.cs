﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Confirmit.CATI.Common.Monitoring;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.Classes.Launch;
using Confirmit.CATI.MonitoringConsole.Interfaces;
using Confirmit.CATI.MonitoringConsole.Resources;
using Confirmit.CATI.MonitoringConsole.Services.MonitoringService;

namespace Confirmit.CATI.MonitoringConsole.Classes
{
    public class MonitoringIdentityInfoProvider : IMonitoringIdentityInfoProvider
    {
        public MonitoringIdentityInfo GetFromFile(string activationDataPath)
        {
            var launchManager = new LaunchManager(activationDataPath);

            if (launchManager.GetLaunchFileType() == LaunchFileType.OfflineMonitoring)
            {
                return new MonitoringIdentityInfo { LaunchType = LaunchFileType.OfflineMonitoring };
            }

            var launchInfo = launchManager.GetMonitoringLaunchInfo();

            MonitoringIdentityInfo monitoringIdentityInfo = null;

            try
            {
                MonitoringServiceManager.ConfigureChannelFactory(launchInfo.CompanyId, launchInfo.ServerName, launchInfo.EncryptedData);

                monitoringIdentityInfo = MonitoringServiceManager.GetMonitoringIdentityInfo();
            }
            catch (Exception ex)
            {
                Logger.Write(ex, MessageTypes.Error);
                ServiceLocator.Resolve<IAlerter>().Alert(Strings.Error_CommunicationError, Strings.Caption_Error, MessageTypes.Error);
                Application.Exit();
            }

            return monitoringIdentityInfo;
        }

        public MonitoringIdentityInfo GetFromParameters(string input)
        {
            MonitoringIdentityInfo monitoringIdentityInfo = null;
            var arguments = input.Split(new[] { ";", "," }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim())
                .Where(y => !String.IsNullOrEmpty(y))
                .ToArray();

            var argumentsParsed = GetArgumentsDictionary(arguments);

            try
            {
                MonitoringServiceManager.ConfigureChannelFactory(
                    int.Parse(argumentsParsed[LiteralConstants.CompanyId]), 
                    argumentsParsed[LiteralConstants.ServerName], 
                    argumentsParsed[LiteralConstants.EncryptedData]);

                monitoringIdentityInfo = MonitoringServiceManager.GetMonitoringIdentityInfo();
            }
            catch (Exception ex)
            {
                Logger.Write(ex, MessageTypes.Error);
                ServiceLocator.Resolve<IAlerter>().Alert(Strings.Error_CommunicationError, Strings.Caption_Error, MessageTypes.Error);
                Application.Exit();
            }

            return monitoringIdentityInfo;
        }

        private Dictionary<string, string> GetArgumentsDictionary(IEnumerable<string> arguments)
        {
            var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var argument in arguments)
            {
                var splittedArguments = argument.Split('=');

                if (splittedArguments.Length == 2)
                {
                    result[splittedArguments[0].Trim()] = splittedArguments[1].Trim();
                }
            }

            return result;
        }

        public MonitoringOptions GetMonitoringOptions()
        {
            return MonitoringServiceManager.GetMonitoringOptions(
                UserPassport.Instance.CurrentIdentityInfo.SupervisorName, 
                UserPassport.Instance.CurrentIdentityInfo.InterviewerId);
        }
    }
}
