﻿using System;
using System.Threading;
using System.Collections.Generic;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.Monitoring.Common.Serialization;
using Confirmit.CATI.MonitoringConsole.Properties;
using Confirmit.CATI.MonitoringConsole.Services.MonitoringService;

namespace Confirmit.CATI.MonitoringConsole.Classes
{
    /// <summary>
    /// Represents class which is responsible for getting monitoring messages 
    /// from monitoring service.
    /// </summary>
    internal class EventReceiver : IDisposable
    {
        private Thread m_ReceiveThread = null;
        private ManualResetEvent m_ObjectEnqueued = null;        
        private Queue<EventInfo> m_EventsQueue = null;
        private bool m_TerminateThread;

        #region Constructors

        /// <summary>
        /// Initializes new instance of EventSender class.
        /// </summary>
        public EventReceiver()
        {            
            m_EventsQueue = new Queue<EventInfo>();
            m_TerminateThread = false;
            InitReceiverThread();
        }

        #endregion

        #region Properties
        
        /// <summary>
        /// Represent received events queue
        /// </summary>
        public Queue<EventInfo> EventsQueue
        {
            get { return m_EventsQueue; }
        }

        /// <summary>
        /// Can be used for processes synchronization
        /// </summary>
        public ManualResetEvent ObjectEnqueued
        {
            get { return m_ObjectEnqueued; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Initialiazes thread which will be used for getting monitoring messages 
        /// from Monitoring service.
        /// </summary>
        internal void InitReceiverThread()
        {
            m_ObjectEnqueued = new ManualResetEvent(false);
            m_ReceiveThread = new Thread(new ThreadStart(GetEvents));
            m_ReceiveThread.IsBackground = true;
            m_ReceiveThread.Start();
        }

        #endregion

        /// <summary>
        /// Function is responsible for getting events from Monitoring service. It gets events from 
        /// service and puts them to queue.
        /// </summary>
        private void GetEvents()
        {
            EventInfo element;
            StateEventInfo[] events;
            
            while (true)
            {
                Thread.Sleep(Settings.Default.GetEventsSleepTime);
                if (m_TerminateThread)
                {
                    break;
                }

                events = MonitoringServiceHelper.GetInterviewerEvents();

                if (events.Length > 0)
                {
                    foreach (StateEventInfo stateEvent in events)
                    {
                        element = new EventInfo
                        {
                            TimeStamp = stateEvent.TimeStamp,
                            MessageType = stateEvent.MessageType,
                            State = SerializationManager.Deserialize(stateEvent.MessageType, stateEvent.State)
                        };

                        lock (m_EventsQueue)
                        {
                            m_EventsQueue.Enqueue(element);
                        }
                    }

                    lock (m_ObjectEnqueued)
                    {
                        m_ObjectEnqueued.Set();
                    }
                }
            }
        }

        #region IDisposable Members

        /// <summary>
        /// Releaze resources
        /// </summary>
        public void Dispose()
        {
            StopReceiverThread();
        }
        /// <summary>
        /// Stops receiver thread. 
        /// </summary>
        private void StopReceiverThread()
        {
            m_TerminateThread = true;
            m_ObjectEnqueued.Set();
        }

        #endregion
    }
}
