﻿using Confirmit.CATI.Common.Monitoring;
using Confirmit.CATI.Monitoring.Common.Contracts;

namespace Confirmit.CATI.MonitoringConsole.Interfaces
{
    public interface IMonitoringIdentityInfoProvider
    {
        MonitoringIdentityInfo GetFromFile(string activationDataPath);

        MonitoringIdentityInfo GetFromParameters(string input);

        MonitoringOptions GetMonitoringOptions();
    }
}
