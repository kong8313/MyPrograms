﻿using System;

namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    public class MilestoneEvent
    {
        private readonly EventInfo _eventInfo;

        public MilestoneEvent(EventInfo eventInfo)
        {
            _eventInfo = eventInfo;
        }

        protected MilestoneEvent()
        {
        }

        public DateTime Time { get; set; }
        public TimeSpan Offset { get; set; }
        public int IndexOfEvent { get; set; }
        public int IndexOfEventContentLoad { get; set; }
        public TimeSpan Duration { get; set; }
        public int IndexOfFinishEvent { get; set; }

        public override string ToString()
        {
            return $"{IndexOfEvent} - {IndexOfFinishEvent} ({IndexOfEventContentLoad}): {Duration}, {_eventInfo}";
        }
    }
}