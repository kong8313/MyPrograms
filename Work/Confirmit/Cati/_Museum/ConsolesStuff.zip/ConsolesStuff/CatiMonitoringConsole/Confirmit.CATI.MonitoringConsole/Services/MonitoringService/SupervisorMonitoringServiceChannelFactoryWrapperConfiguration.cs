﻿using System.Collections.Generic;
using System.ServiceModel.Description;
using Confirmit.CATI.Common.SideBySide;
using Confirmit.CATI.Common.WcfTools;
using Confirmit.CATI.Common.WcfTools.MonitoringMessageHeader;

namespace Confirmit.CATI.MonitoringConsole.Services.MonitoringService
{
    public class SupervisorMonitoringServiceChannelFactoryWrapperConfiguration : IChannelFactoryWrapperConfiguration
    {
        private readonly int _companyId;
        private readonly string _serverName;
        private readonly string _encryptedData;

        public SupervisorMonitoringServiceChannelFactoryWrapperConfiguration(int companyId, string serverName, string encryptedData)
        {
            _companyId = companyId;
            _serverName = serverName;
            _encryptedData = encryptedData;
        }

        public string EndpointConfigurationName 
        { 
            get { return "MonitoringServiceEndpoint"; }
        }

        public string AdjustEndpointUri(string originalUrl)
        {
            var changedUrl = originalUrl.Replace("//localhost/", $"//{_serverName}/");
            return new SideBySideManager().AddSideBySideNameToBackendWCFServiceUrl(changedUrl) + _companyId;
        }

        public bool UseLogicalAddressReplacementForHttps()
        {
            return true;
        }

        public IEnumerable<IEndpointBehavior> EndpointBehaviors
        {
            get
            {
                return new[]
                           {
                               new SupervisorMonitoringAuthorizationMessageHeaderBehavior(_encryptedData)
                           };
            }
        }
        
        public CachingStrategy CachingStrategy 
        { 
            get
            {
                return CachingStrategy.FactoryAndChannels;
            }
        }

        public bool LogAllCalls
        {
            get { return false; }
        }
        
        public bool LogExceptions
        {
            get { return true; }
        }
        
        public bool KeepAliveEnabled => false;

        public void InitializeClientCredentials(ClientCredentials credentials)
        {
        }
    }
}
