﻿using System.Collections.Generic;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.Classes.EvenSources;

namespace Confirmit.CATI.MonitoringConsole.Classes.Download
{
    /// <summary>
    /// Represents result of downloading deferred recordings.
    /// </summary>
    internal class DownloadResult
    {
        /// <summary>
        /// Initializes new instance of DownloadResult class.
        /// </summary>
        public DownloadResult()
        {
            AudioFiles = new Dictionary<AudioIdentityObject, string>();
        }

        /// <summary>
        /// Gets/sets an event source containing deferred video records.
        /// </summary>
        public DeferredEventSource EventSource { get; set; }

        /// <summary>
        /// Gets/sets collection of audio files.
        /// </summary>
        public Dictionary<AudioIdentityObject, string> AudioFiles { get; set; }
    }
}
