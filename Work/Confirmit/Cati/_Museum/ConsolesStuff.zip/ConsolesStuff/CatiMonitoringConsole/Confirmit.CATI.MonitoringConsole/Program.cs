﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using Confirmit.CATI.Common.Monitoring;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Views.Forms;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.MonitoringConsole.Classes;
using Confirmit.CATI.MonitoringConsole.Classes.Utilities;
using Confirmit.CATI.MonitoringConsole.Presenters;
using Confirmit.CATI.MonitoringConsole.Classes.Launch;
using Confirmit.CATI.MonitoringConsole.Resources;

namespace Confirmit.CATI.MonitoringConsole
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            AppDomain.CurrentDomain.UnhandledException += MonitoringUnhandledExceptionsHandler.CurrentDomain_UnhandledException;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (!ApplicationManager.IsClickOnce && !ApplicationManager.IsDebugMode)
            {
                RestartInClickOnceMode();
                Application.Exit();
                return;
            }

            if (ApplicationManager.IsDebugMode && !ApplicationManager.ActivationArgumentsManager.HasExistingLocalDataPath)
            {
                try
                {
                    ApplicationManager.ActivationArgumentsManager.SetPathArgumentData(OpenLocalRecordFile());
                }
                catch (FileNotFoundException e)
                {
                    MessageBox.Show(e.Message, Properties.Resources.Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    System.Console.WriteLine(e);
                    Application.Exit();
                    return;
                }
            }

            InitializeServiceLocator();

            var fromUri = ApplicationManager.IsFromUri;

            if (ApplicationManager.IsClickOnce && !ApplicationManager.IsDebugMode &&
                !ApplicationManager.ActivationArgumentsManager.HaveActivationArguments())
            {
                MessageBox.Show(Strings.FinishInstallationMessage, Strings.Caption_Information, MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }

            BrowserRenderingModeConfigurator.Setup(Properties.Settings.Default.BrowserEmulation);

            Logger.Write($"Monitoring console started. Version: {ApplicationManager.AssemblyVersion}", MessageTypes.Information);

            var frmMain = new MainForm();
            using (var redialForm = (IViewRedialForm)ViewFactory.GetView(FormViews.RedialView))
            using (var appointmentForm = (IViewAppointmentForm)ViewFactory.GetView(FormViews.AppointmentView))
            {
                var presenterInterview = new PresenterInterview(frmMain.InterviewPageBrowser);
                var presenterAppointment = new PresenterAppointment(appointmentForm, frmMain);
                IEnvironmentValidator environmentValidator = new EnvironmentValidator(
                    new OsVersionProvider(), new LocalMachineRegistryKeyProvider());

                var contextRedial = new SynchronizationContextAdapter(redialForm.SynchronizationContext);
                var presenterRedial = new PresenterRedial(redialForm, frmMain, contextRedial);
                var monitoringModeProvider = new MonitoringModeProvider();
                var monitoringIdentityInfoProvider = new MonitoringIdentityInfoProvider();
                var presenterMainForm = new PresenterMainForm(
                    presenterInterview,
                    presenterAppointment,
                    presenterRedial,
                    monitoringModeProvider,
                    monitoringIdentityInfoProvider,
                    frmMain,
                    frmMain.StatusBarControl,
                    frmMain.OnABreakControl,
                    environmentValidator,
                    fromUri);

                // We use the same application if InitialQuestion exists
                // to prevent excessive downloading
                if (fromUri || OpenInTheSameApplication())
                {
                    SingleInstanceApplication.Run(frmMain, presenterMainForm);
                }
                else
                {
                    Application.Run(frmMain);
                }
            }
        }

        private static string OpenLocalRecordFile()
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                var ext = LaunchManager.OfflineMonitoringFileExtension;
                openFileDialog.Filter = $@"Offline Monitoring File (*{ext})|*{ext}|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 0;
                openFileDialog.RestoreDirectory = true;
                openFileDialog.Title = @"Open offline monitoring record file or Cancel for exit application.";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    return openFileDialog.FileName;
                }
            }

            return null;
        }

        private static void RestartInClickOnceMode()
        {
            var args = Environment.GetCommandLineArgs();
            if (args.Length <= 1)
            {
                return;
            }

            var arguments = args[1].Replace(string.Format("{0}://", LiteralConstants.UrlProtocol), "").Split('/');
            var data = arguments[0];
            var company = arguments[1];
            var serverName = arguments[2];

            Process.Start(
            Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), LiteralConstants.LauncherName),
            $"{LiteralConstants.EncryptedData}={data},{LiteralConstants.CompanyId}={company},{LiteralConstants.ServerName}={serverName}");
        }

        private static bool OpenInTheSameApplication()
        {
            var argumentsManager = ApplicationManager.ActivationArgumentsManager;

            if (argumentsManager.HaveActivationArguments() == false)
            {
                return false;
            }

            var activationDataPath = argumentsManager.GetActivationDataPath();

            var launchManager = new LaunchManager(activationDataPath);

            var launchFileType = launchManager.GetLaunchFileType();
            if (launchFileType == LaunchFileType.OfflineMonitoring)
            {
                return false;
            }

            var launchInfo = launchManager.GetMonitoringLaunchInfo();

            return launchInfo.PreventSeparateInstance;
        }

        private static void InitializeServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            var registrator = new ServiceLocatorRegistry();
            registrator.RegisterTypes(serviceLocator);
        }
    }
}