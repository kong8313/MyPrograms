﻿using System;
using System.Text.RegularExpressions;

namespace Confirmit.CATI.MonitoringConsole.Classes
{
    public static class StringExtensions
    {
        public static string CropWholeWords(this string value, int length, bool useEllipsis = true)
        {
            if (value == null)
            {
                return string.Empty;
            }

            if (length <= 0)
            {
                throw new ArgumentException("length");
            }

            value = Regex.Replace(value, @"[\t|\n|\r]+", " ");

            if (length >= value.Length)
            {
                return value;
            }
            int end = length;

            for (int i = end; i > 0; i--)
            {
                if (Char.IsSeparator(value[i]) || Char.IsPunctuation(value[i]))
                {
                    break;
                }
                end--;
            }

            if (end == 0)
            {
                end = length;
            }

            return string.Format("{0}{1}", value.Substring(0, end).TrimEnd(), useEllipsis ? "..." : string.Empty);
        }
    }
}
