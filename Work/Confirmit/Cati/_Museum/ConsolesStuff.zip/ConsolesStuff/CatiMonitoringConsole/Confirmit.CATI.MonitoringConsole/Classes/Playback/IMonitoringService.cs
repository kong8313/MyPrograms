﻿using System.Collections.Generic;
using System.IO;
using Confirmit.CATI.Monitoring.Common.Contracts;

namespace Confirmit.CATI.MonitoringConsole.Classes.Playback
{
    public interface IMonitoringService
    {
        Stream GetDeferredRecord(long recordId);

        IEnumerable<AudioIdentityObject> GetAudioIdentity(long recordId);
    }
}
