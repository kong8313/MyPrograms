using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Hosting;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.MonitoringConsole.Classes.Utilities
{
    public class ActivationArgumentsManager
    {
        private const string DebugParam = "/debug";
        private readonly List<string> _arguments;

        public ActivationArgumentsManager(ActivationArguments activationArguments)
        {
            _arguments = activationArguments?.ActivationData?.ToList();
            LogArguments(_arguments, "ActivationArguments");
        }

        public ActivationArgumentsManager(string[] commandLineArguments)
        {
            //skip first argument because it's the program file name
            _arguments = commandLineArguments.Skip(1).ToList();
            HasDebugArgument = _arguments.Any(x => x.ToLower() == DebugParam);
            if (HasDebugArgument && _arguments.IndexOf(DebugParam) == 0)
                _arguments.Insert(0, null);
            LogArguments(commandLineArguments, "CommandLine");
        }

        private void LogArguments(IEnumerable<string> arguments, string source)
        {
            var args = arguments != null ? string.Join(", ", arguments) : "";
            Logger.Write($"Arguments from {source}: [{args}]", MessageTypes.Information);
        }

        public bool HasDebugArgument { get; }

        public bool HaveActivationArguments()
        {
            return _arguments != null && _arguments.Count > 0;
        }

        public bool DataPathContainsEncryptedData()
        {
            return _arguments != null && _arguments.Count >= 1 &&
                   _arguments[0].Contains(LiteralConstants.EncryptedData);
        }

        public string GetActivationDataPath()
        {
            Uri uri;
            if (Uri.IsWellFormedUriString(_arguments[0], UriKind.Absolute))
            {
                uri = new Uri(_arguments[0]);
            }
            else
            {
                var path = Path.GetFullPath(_arguments[0]);
                uri = new Uri(path);
            }

            return uri.LocalPath;
        }

        public void SetPathArgumentData(string path)
        {
            if (!File.Exists(path)) throw new FileNotFoundException($"File to open [{path}] is not exist.");
            _arguments[0] = path;
        }

        public bool HasExistingLocalDataPath =>
            _arguments != null && _arguments.Count > 0 && File.Exists(_arguments[0]);

        public string GetActivationDataParams() => _arguments[0];
    }
}