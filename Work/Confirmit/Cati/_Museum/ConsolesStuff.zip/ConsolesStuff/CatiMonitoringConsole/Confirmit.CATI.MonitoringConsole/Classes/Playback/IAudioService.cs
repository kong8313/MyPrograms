﻿using System.IO;

namespace Confirmit.CATI.MonitoringConsole.Classes.Playback
{
    public interface IAudioService
    {
        Stream GetAudioStreamByIdentityId(string identityId);
    }
}
