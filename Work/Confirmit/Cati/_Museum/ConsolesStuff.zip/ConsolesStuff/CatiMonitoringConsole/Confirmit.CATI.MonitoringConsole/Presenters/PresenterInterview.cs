﻿using System;
using System.Drawing;
using System.Threading;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Resources;
using Confirmit.CATI.Console.Views.Controls;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;
using Confirmit.CATI.MonitoringConsole.Classes;
using Confirmit.CATI.MonitoringConsole.Resources;
using Confirmit.CATI.MonitoringConsole.Properties;

namespace Confirmit.CATI.MonitoringConsole.Presenters
{
    internal class PresenterInterview
    {
        private IViewInterviewPageBrowser m_ViewInterviewPageBrowser;
        private ManualResetEvent pageCompletedResetEvent = new ManualResetEvent(true);

        public PresenterInterview(
            IViewInterviewPageBrowser viewInterviewPageBrowser)
        {
            if (viewInterviewPageBrowser == null)
            {
                throw new ArgumentNullException("viewInterviewPage");
            }

            m_ViewInterviewPageBrowser = viewInterviewPageBrowser;

            InitialActiveQuestionIndex = -1;
            // we do not need page update delay in player, so we set delay value to 0 (it means no delay)
            m_ViewInterviewPageBrowser.PageUpdateMonitoringDelay = 0;
            m_ViewInterviewPageBrowser.DocumentCompleted += new EventHandler<EventArgs>(Browser_DocumentCompleted);
        }

        /// <summary>
        /// Gets/sets index of active question. We use this property
        /// only for assigning proper active question at monitoring startup.
        /// </summary>
        private int InitialActiveQuestionIndex
        {
            get;
            set;
        }

        /// <summary>
        /// Handles interview page browser DocumentCompleted event. 
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        private void Browser_DocumentCompleted(object sender, EventArgs e)
        {
            if (InitialActiveQuestionIndex >= 0)
            {
                /* During monitoring initialization we should activate proper question on interview page.
                 * We can't do it in PlayInteviewInitial method because of our multithreading model.
                 * Even if we fill browser with the data in PlayInteviewInitial method, all processing 
                 * in browser occurs after this method. So we have to handle DocumentCompleted event
                 * outside of PlayInteviewInitial method and set active question index once at monitoring start.
                 */
                m_ViewInterviewPageBrowser.CurrentQuestionIndex = InitialActiveQuestionIndex;
                InitialActiveQuestionIndex = -1;                
            }
            pageCompletedResetEvent.Set();
        }

        /// <summary>
        /// Plays event that occurs when interview is shown for first time.
        /// </summary>
        private delegate void VoidDelegate(BaseStateData stateData);

        public void PlayEvent(MonitoringMessageTypes messageType, BaseStateData stateData)
        {
            SendOrPostCallback callback = null;
            switch (messageType)
            {
                case MonitoringMessageTypes.InterviewInitialMessage:
                    callback = new SendOrPostCallback(PlayInteviewInitial);
                    break;
                case MonitoringMessageTypes.InterviewerLoggedOutMessage:
                    callback = new SendOrPostCallback(PlayInterviewerLoggedOut);
                    break;
                case MonitoringMessageTypes.InterviewFinishMessage:
                    callback = new SendOrPostCallback(PlayInterviewFinish);
                    break;
                case MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage:
                    callback = new SendOrPostCallback(PlayInterviewPageBrowserPageCompleted);
                    break;
                case MonitoringMessageTypes.InterviewPageBrowserPagePartiallyChangedMessage:
                    callback = new SendOrPostCallback(PlayInterviewPageBrowserPagePagePartiallyChanged);
                    break;
                case MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage:
                    callback = new SendOrPostCallback(PlayInterviewPageBrowserQuestionSelected);
                    break;
                case MonitoringMessageTypes.InterviewPageBrowserAnswerValueChangedMessage:
                    callback = new SendOrPostCallback(PlayInterviewPageBrowserAnswerValueChanged);
                    break;
                case MonitoringMessageTypes.InterviewPageBrowserKeyboardInputControlValueChangedMessage:
                    callback = new SendOrPostCallback(PlayInterviewPageBrowserKeyboardInputControlValueChanged);
                    break;
                case MonitoringMessageTypes.SetDefaultAnswerMessage:
                    callback = new SendOrPostCallback(PlaySetDefaultAnswer);
                    break;
                case MonitoringMessageTypes.SetRefusedAnswerMessage:
                    callback = new SendOrPostCallback(PlaySetRefusedAnswer);
                    break;                                
                case MonitoringMessageTypes.InterviewPageBrowserProcessKeyboardInputMessage:
                    callback = new SendOrPostCallback(PlayInterviewPageBrowserProcessKeyboardInput);
                    break;
                case MonitoringMessageTypes.InterviewStartMessage:
                    callback = new SendOrPostCallback(PlayInterviewStartMessage);
                    break;
                case MonitoringMessageTypes.InterviewPageBrowserResponsiveQuestionChangedMessage:
                    callback = PlayInterviewPageBrowserResponsiveQuestionChangedMessage;
                    break;
                case MonitoringMessageTypes.MonitoringNotPermittedMessage:
                    callback = PlayInterviewMonitoringNotPermittedMessage;
                    break;
                default:
                    Logger.Write(
                         Strings.ResourceManager.GetString("Warning_UnsupportedEvent", messageType),
                         MessageTypes.Warning
                     );
                    break;
            }

            if (callback != null)
            {
                if (messageType != MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage &&
                    messageType != MonitoringMessageTypes.InterviewInitialMessage)
                {
                    m_ViewInterviewPageBrowser.SynchronizationContext.Post(callback, stateData);
                }
                else
                {
                    pageCompletedResetEvent.Reset();
                    m_ViewInterviewPageBrowser.SynchronizationContext.Post(callback, stateData);
                    pageCompletedResetEvent.WaitOne(Settings.Default.PageCompletedWaitTime);                
                }                                                
            }
        }

        private void PlayInterviewMonitoringNotPermittedMessage(object state)
        {
            CleanBrowser();
        }

        private void CleanBrowser()
        {
            try
            {
                m_ViewInterviewPageBrowser.LoadContent(String.Empty);
                m_ViewInterviewPageBrowser.ViewKeyboardInput.Clear();
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        private void PlayInterviewPageBrowserResponsiveQuestionChangedMessage(object stateData)
        {
            try
            {
                var eventData = (AnswerEnteredStateData)(stateData);
                m_ViewInterviewPageBrowser.SetAnswerForResponsive(eventData.ElementId, eventData.ElementValue);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        private void PlayInterviewStartMessage(object stateData)
        {
            if (stateData == null)
            {
                return;
            }

            try
            {
                m_ViewInterviewPageBrowser.PrepareBrowser();
                m_ViewInterviewPageBrowser.LoadContent(String.Empty);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        private void PlayInteviewInitial(object stateData)
        {
            if (stateData == null)
            {
                return;
            }
            
            try
            {
                InterviewingInitialStateData eventData = (InterviewingInitialStateData)(stateData);
                m_ViewInterviewPageBrowser.LoadContent(eventData.PageContent);
                m_ViewInterviewPageBrowser.ViewKeyboardInput.InputValue = eventData.KeyboardInputValue;
                InitialActiveQuestionIndex = eventData.ActiveQuestionIndex;
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        /// <summary>
        /// Plays interview finish message
        /// </summary>
        /// <remarks>
        /// Loads empty page to browser
        /// </remarks>
        private void PlayInterviewFinish(object stateData)
        {
            CleanBrowser();
        }

        /// <summary>
        /// Plays interviewer logged out message
        /// </summary>
        /// <remarks>
        /// If user is logged out we should loads empty page to browser
        /// </remarks>
        private void PlayInterviewerLoggedOut(object stateData)
        {
            CleanBrowser();
        }

        /// <summary>
        /// Plays event that occurs when new page is loaded or page is changed via ajax
        /// </summary>
        private void PlayInterviewPageBrowserPageCompleted(object stateData)
        {
            if (stateData == null)
            {
                return;
            }

            try
            {
                DocumentCompletedStateData eventData = (DocumentCompletedStateData)(stateData);                
                m_ViewInterviewPageBrowser.LoadContent(eventData.PageContent);                
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        private void PlayInterviewPageBrowserPagePagePartiallyChanged(object stateData)
        {
            if (stateData == null)
            {
                return;
            }

            try
            {
                var eventData = (PagePartiallyChangedStateData)(stateData);
                m_ViewInterviewPageBrowser.UpdatePagePartially(eventData.ElementId, eventData.ElementOuterHtml, eventData.ActiveElementId);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        /// <summary>
        /// Plays event that occures when new question is selected
        /// </summary>
        private void PlayInterviewPageBrowserQuestionSelected(object stateData)
        {
            if (stateData == null)
            {
                return;
            }
            
            try
            {
                QuestionSelectedStateData eventData = (QuestionSelectedStateData)(stateData);
                m_ViewInterviewPageBrowser.DoQuestion(eventData.QuestionIndex);
                m_ViewInterviewPageBrowser.DoSubQuestion(eventData.SubQuestionIndex);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        /// <summary>
        /// Plays event that occurs when user enteres or changes answer for question 
        /// </summary>
        private void PlayInterviewPageBrowserAnswerValueChanged(object stateData)
        {            
            if (stateData == null)
            {
                return;
            }
            
            try
            {
                var eventData = (AnswerEnteredStateData)(stateData);
                m_ViewInterviewPageBrowser.SetAnswer(eventData.ElementId,  eventData.ElementValue);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }
       
        /// <summary>
        /// Plays event that occurs when value in KeyboardInputControl is chanded
        /// </summary>
        private void PlaySetDefaultAnswer(object stateData)
        {
            try
            {
                m_ViewInterviewPageBrowser.SetDefaultAnswer();
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        /// <summary>
        /// Plays event that occurs when value in KeyboardInputControl is chanded
        /// </summary>
        private void PlaySetRefusedAnswer(object stateData)
        {
            try
            {
                m_ViewInterviewPageBrowser.SetRefusedAnswer();
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        /// <summary>
        /// Plays event that occurs when value in KeyboardInputControl is chanded
        /// </summary>
        private void PlayInterviewPageBrowserKeyboardInputControlValueChanged(object stateData)
        {
            if (stateData == null)
            {
                return;
            }
            
            try
            {
                TextControlStateData eventData = (TextControlStateData)(stateData);
                m_ViewInterviewPageBrowser.ViewKeyboardInput.InputValue = eventData.Text;
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        /// <summary>
        /// Plays event that occurs when user press 'Enter' button and entered data should be applied to active question
        /// </summary>
        private void PlayInterviewPageBrowserProcessKeyboardInput(object stateData)
        {
            if (stateData == null)
            {
                return;
            }
            
            try
            {
                ProcessKeyboardInputStateData eventData = (ProcessKeyboardInputStateData)(stateData);
                m_ViewInterviewPageBrowser.ProcessEnterData(eventData.InputValue);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        public void HighlightEnterZone(Color color)
        {
            m_ViewInterviewPageBrowser.HighlightEnterZone(color);
        }
    }
}
