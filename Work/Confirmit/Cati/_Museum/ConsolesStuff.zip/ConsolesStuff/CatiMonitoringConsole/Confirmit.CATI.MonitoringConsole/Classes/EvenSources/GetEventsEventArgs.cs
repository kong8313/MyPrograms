﻿using System;

namespace Confirmit.CATI.MonitoringConsole.Classes.EvenSources
{
    public class GetEventsEventArgs : EventArgs
    {
        #region Properties

        /// <summary>
        /// Gets/sets collection of events.
        /// </summary>
        public EventInfo[] Events { get; set; }

        #endregion
    }
}
