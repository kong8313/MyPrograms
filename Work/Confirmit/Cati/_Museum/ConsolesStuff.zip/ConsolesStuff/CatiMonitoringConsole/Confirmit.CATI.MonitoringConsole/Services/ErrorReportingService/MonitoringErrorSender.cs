﻿using Confirmit.CATI.Common;
using Confirmit.CATI.Common.Contracts.ErrorReportingService;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.MonitoringConsole.Services.ErrorReportingService
{
    public class MonitoringErrorSender : IErrorSender
    {
        public void SendErrorMessage(IErrorReportingService serviceInstance, string companyAlias, ClientErrorSource source, string errorMessage, byte[] hash)
        {
            serviceInstance.SendMonitoringErrorMessage(companyAlias, source, errorMessage, hash);
        }
    }
}
