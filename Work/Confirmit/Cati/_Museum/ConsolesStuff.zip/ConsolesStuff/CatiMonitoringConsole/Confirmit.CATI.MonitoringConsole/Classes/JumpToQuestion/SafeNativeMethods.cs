﻿using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;

namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    public class SafeNativeMethods
    {
        public const string User32 = "user32.dll";

        [SuppressUnmanagedCodeSecurity]
        [DllImport(User32, ExactSpelling = true, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        [ResourceExposure(ResourceScope.None)]
        public static extern bool SetWindowPos(HandleRef hWnd, HandleRef hWndInsertAfter,
                                               int x, int y, int cx, int cy, int flags);

        [DllImport(User32, ExactSpelling = true, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        [ResourceExposure(ResourceScope.None)]
        public static extern bool ValidateRect(HandleRef hWnd, [In, Out] ref RECT rect);
    }
}
