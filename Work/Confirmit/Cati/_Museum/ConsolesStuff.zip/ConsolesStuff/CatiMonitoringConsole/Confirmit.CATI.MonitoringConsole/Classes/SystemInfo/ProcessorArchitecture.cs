﻿namespace Confirmit.CATI.MonitoringConsole.Classes.SystemInfo
{
    public enum ProcessorArchitecture
    {
        ProcessorArchitectureIntel = 0,
        ProcessorArchitectureIa64 = 6,
        ProcessorArchitectureAmd64 = 9,
        ProcessorArchitectureUnknown = 0xFFFF,
    }
}