using System;

namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    public class JumpToQuestionEventArgs : EventArgs
    {
        public int PageCompletedEventIndex { get; set; }

        public int QuestionSelectedEventIndex { get; set; }
    }
}
