﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion;

namespace Confirmit.CATI.MonitoringConsole.Interfaces
{
    /// <summary>
    /// Represents view entity for MainForm form.
    /// </summary>
    public interface IViewMainPlayerForm : IWin32Window, IPlayableView
    {
        Color DefaultControlColor { get; set; }

        /// <summary>
        /// Shows/hides audio toolbar;
        /// </summary>
        /// <param name="show">If true, shows toolbar; otherwise hides.</param>
        void ShowAudioToolbar(bool show);

        void ShowDeferredToolbar(bool show);

        void ShowLiveToolbar(bool show);

        void ShowCoachingToolbarButton(bool show);

        void ShowBargingToolbarButton(bool show);

        /// <summary>
        /// Enables/disables audio toolbar.
        /// </summary>
        /// <param name="enable">If true, enables audio toolbar; otherwise false.</param>
        void EnableAudioToolbar(bool enable);

        void EnableSaveOfflineRecordButton(bool enable);

        void EnableDeferredToolbar(bool enable);

        void EnableAnsweredQuestionCombobox(bool enable);

        void SetListeningToolbarMode(MonitoringMode mode);

        /// <summary>
        /// Shows interview page browser control and hides all other controls.
        /// </summary>
        void ShowInterviewPageControl();

        /// <summary>
        /// Shows process control and hides all other controls.
        /// </summary>
        /// <param name="processMessage">This message will be shown while processing.</param>
        void ShowProcessControl(string processMessage);

        void ShowBlankControl();

        /// <summary>
        /// Close current form 
        /// </summary>
        void CloseForm();
        
        /// <summary>
        /// Occurs when form is loaded.
        /// </summary>
        event EventHandler FormLoad;

        /// <summary>
        /// Occurs when the form is closed.
        /// </summary>
        event EventHandler<EventArgs> FormClose;

        /// <summary>
        /// Occurs when user clicks audio forward rewind button.
        /// </summary>
        event EventHandler AudioForwardRewind;

        /// <summary>
        /// Occurs when user clicks audio backward rewind button.
        /// </summary>
        event EventHandler AudioBackwardRewind;

        event EventHandler DefferedRecordPausePlay;

        event EventHandler SaveOfflinePlaybackRecord;

        event EventHandler SetListeningMode;

        event EventHandler SetCoachingMode;

        event EventHandler SetBargingMode;

        event EventHandler<JumpToQuestionEventArgs> DeferredRecordJumpToMilestone;

        event EventHandler<TimeSpan> DeferredRecordJumpToPosition;

        event EventHandler DeferredRecordJumpToNextMilestone;

        event EventHandler DeferredRecordJumpToPrevMilestone;

        void UpdatePausePlayButtonState(bool isRecordPaused);

        void InitJumpToQuestionCombobox(IEnumerable<AnsweredQuestionsComboBoxItem> comboboxItems);

        void SpecifyMainFormStyle(string title, Color color, bool isInboundCall, bool isTestMode);

        void ShowOnABreakControl(bool displayBreakType, string breakInfo);

        bool IsProcessControlVisible();

        void ChangeMilestone(TimeSpan? milestoneDuration);

        void UpdateCurrentMilestonePosition(TimeSpan elapsed);
    }
}