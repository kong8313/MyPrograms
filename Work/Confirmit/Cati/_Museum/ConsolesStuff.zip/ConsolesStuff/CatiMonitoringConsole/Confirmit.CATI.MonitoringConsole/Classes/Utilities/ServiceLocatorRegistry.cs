﻿using Confirmit.CATI.Common;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.MonitoringConsole.Classes.Utilities
{
    public class ServiceLocatorRegistry : IServiceLocatorRegistry
    {
        public void RegisterTypes(IServiceRegistrator serviceRegistrator)
        {
            serviceRegistrator.Register<IAlerter, Alerter>();
            serviceRegistrator.Register<ILogger, Logger>();
        }
    }
}
