﻿using Confirmit.CATI.Monitoring.Common.Contracts;

namespace Confirmit.CATI.MonitoringConsole.Interfaces
{
    public interface IMonitoringModeProvider
    {
        void SetLiveMonitoringMode(MonitoringMode mode);
    }
}
