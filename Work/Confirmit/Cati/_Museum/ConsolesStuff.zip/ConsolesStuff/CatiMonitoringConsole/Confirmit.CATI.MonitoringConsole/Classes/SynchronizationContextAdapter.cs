using System;
using System.Threading;

namespace Confirmit.CATI.MonitoringConsole.Classes
{
    public interface IContext
    {
        void Post(SendOrPostCallback d, Object state);
    }

    public class SynchronizationContextAdapter : IContext
    {
        private readonly SynchronizationContext _context;

        public SynchronizationContextAdapter(SynchronizationContext context)
        {
            _context = context;
        }

        public virtual void Post(SendOrPostCallback d, Object state)
        {
            _context.Post(d, state);
        }
    }
}