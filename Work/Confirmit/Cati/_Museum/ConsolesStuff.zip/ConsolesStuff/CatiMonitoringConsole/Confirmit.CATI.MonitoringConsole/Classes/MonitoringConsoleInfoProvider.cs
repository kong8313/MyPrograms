﻿using System.Reflection;
using System.Text;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.MonitoringConsole.Resources;

namespace Confirmit.CATI.MonitoringConsole.Classes
{
    internal class MonitoringConsoleInfoProvider : ILogInfoProvider
    {
        public string GetInfo()
        {
            var result = new StringBuilder();
            var monitoringIdentityInfo = UserPassport.Instance.CurrentIdentityInfo;

            result.AppendFormat(
                Strings.ServerLoggingDetails,
                monitoringIdentityInfo == null ? string.Empty : monitoringIdentityInfo.SupervisorName,
                Assembly.GetExecutingAssembly().GetName().Version);
            result.AppendLine("\nMonitoring type: " + monitoringIdentityInfo.LaunchType);
            result.AppendLine("Time stamp: " + monitoringIdentityInfo.TimeStamp);
            result.AppendLine("Interviewer Name: " + monitoringIdentityInfo.InterviewerName);

            var interviewInfo = UserPassport.Instance.InterviewInfo;
            result.AppendLine("Project ID: " + interviewInfo.ProjectId);
            result.Append("Interview ID: " + interviewInfo.InterviewId);

            return result.ToString();
        }
    }
}
