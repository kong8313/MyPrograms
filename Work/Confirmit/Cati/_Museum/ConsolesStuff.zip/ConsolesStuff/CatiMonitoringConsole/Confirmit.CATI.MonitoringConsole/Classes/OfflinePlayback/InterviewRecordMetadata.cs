﻿using Confirmit.CATI.Common.Monitoring;
using System;
using System.Collections.Generic;

namespace Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback
{
    [Serializable]
    public class InterviewRecordMetadata
    {
        public LaunchFileType LaunchType { get; set; }

        public string InterviewerName { get; set; }

        public string SupervisorName { get; set; }

        public string CompanyAlias { get; set; }

        public string SurveyId { get; set; }

        public string ProjectId { get; set; }

        public List<string> AudioUris { get; set; }

        public int CompanyId { get; set; }

        public int InterviewerId { get; set; }

        public int InterviewId { get; set; }

        public DateTime CreationUtcTime { get; set; }

        public InterviewRecordMetadata()
        {
            AudioUris = new List<string>();
        }

        public InterviewRecordMetadata(
            MonitoringIdentityInfo identityInfo,
            string projectId,
            int interviewId,
            List<string> audioUris
            )
        {
            LaunchType = identityInfo.LaunchType;
            InterviewerName = identityInfo.InterviewerName;
            SupervisorName = identityInfo.SupervisorName;
            CompanyAlias = identityInfo.CompanyAlias;
            SurveyId = identityInfo.SurveyId;
            ProjectId = projectId;
            AudioUris = audioUris;
            CompanyId = identityInfo.CompanyId;
            InterviewerId = identityInfo.InterviewerId;
            InterviewId = interviewId;
            CreationUtcTime = identityInfo.CreationUtcTime;
        }

    }
}
