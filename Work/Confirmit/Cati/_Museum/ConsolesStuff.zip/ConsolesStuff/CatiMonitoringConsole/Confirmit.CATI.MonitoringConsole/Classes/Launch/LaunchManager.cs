﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Serialization;
using Confirmit.CATI.Common.Monitoring;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.MonitoringConsole.Classes.Utilities;
using Confirmit.CATI.MonitoringConsole.Resources;

namespace Confirmit.CATI.MonitoringConsole.Classes.Launch
{
    /// <summary>
    /// Class responsible for start parameters processing
    /// </summary>
    public class LaunchManager
    {
        #region Fields

        public const string LiveMonitoringFileExtension = ".cspx";
        public const string DeferredMonitoringFileExtension = ".cspd";
        public const string OfflineMonitoringFileExtension = ".cspo";
        public const string AudioFileExtension = ".wav";
        public const string VideoFileExtension = ".cce";
        public const string MetadataFileExtension = ".xml";

        private readonly string _activationDataFile;
        private readonly IFileOperationsManager _fileOperationsManager;
        private IAlerter _alerter;

        #endregion

        public LaunchManager(string activationDataFile) : this(activationDataFile, new FileOperationsManager())
        {
        }

        public LaunchManager(string activationDataFile, IFileOperationsManager fileOperationsManager)
        {
            _fileOperationsManager = fileOperationsManager;
            _activationDataFile = activationDataFile;

            _alerter = ServiceLocator.Resolve<IAlerter>();

            if (!_fileOperationsManager.FileExists(_activationDataFile))
                throw new ArgumentException(string.Format("Activation file {0} doesn't exist!", _activationDataFile));
        }

        /// <summary>
        /// Retruns the type of file which was used for starting application.
        /// </summary>
        /// <returns>Starting file type.</returns>
        public LaunchFileType GetLaunchFileType()
        {
            LaunchFileType result;

            var extension = Path.GetExtension(_activationDataFile).ToLower();

            switch (extension)
            {
                case LiveMonitoringFileExtension:
                    result = LaunchFileType.LiveMonitoring;
                    break;
                case DeferredMonitoringFileExtension:
                    result = LaunchFileType.DeferredMonitoring;
                    break;
                case OfflineMonitoringFileExtension:
                    result = LaunchFileType.OfflineMonitoring;
                    break;
                default:
                    throw new ArgumentException("File with activation data " + _activationDataFile + " have unknown extension. Unable to define type of monitoring session.");
            }

            return result;
        }

        public MonitoringLaunchInfo ReadLaunchInfo()
        {
            using (var stream = _fileOperationsManager.OpenFile(_activationDataFile))
            {
                var ser = new XmlSerializer(typeof(MonitoringLaunchInfo));

                return (MonitoringLaunchInfo)ser.Deserialize(stream);
            }
        }

        public MonitoringLaunchInfo GetMonitoringLaunchInfo()
        {
            MonitoringLaunchInfo launchInfo = null;

            try
            {
                if (GetLaunchFileType() == LaunchFileType.OfflineMonitoring)
                {
                    launchInfo = new MonitoringLaunchInfo();
                }

                launchInfo = ReadLaunchInfo();
            }
            catch (Exception ex)
            {
                Logger.Write(ex, MessageTypes.Error);
                _alerter.Alert(Strings.Error_ReadLaunchInfoError, Strings.Caption_Error, MessageTypes.Error);
                Application.Exit();
            }

            return launchInfo;
        }

        public OfflineMonitoringLaunchInfo ReadOfflineLaunchInfo()
        {
            var packageParts = _fileOperationsManager.UnpackPackagePartsToFiles(_activationDataFile);
            var launchInfo = new OfflineMonitoringLaunchInfo();
            var offlineMonitoringManager = new OfflineMonitoringManager(launchInfo);

            foreach (var file in packageParts)
            {
                launchInfo = offlineMonitoringManager.UpdateLaunchInfo(
                    file,
                    VideoFileExtension,
                    AudioFileExtension,
                    MetadataFileExtension
                    );
            }

            if (string.IsNullOrEmpty(launchInfo.VideoFilePath) && !launchInfo.AudioFilesPaths.Any())
            {
                throw new FileFormatException(string.Format("The file {0} doesn't contain video or audio data! Nothing to play.", _activationDataFile));
            }

            return launchInfo;
        }
  
    }
}