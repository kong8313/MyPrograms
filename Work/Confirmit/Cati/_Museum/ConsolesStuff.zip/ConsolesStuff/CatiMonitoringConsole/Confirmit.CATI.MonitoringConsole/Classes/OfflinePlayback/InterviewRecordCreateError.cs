﻿using System;

namespace Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback
{
    public class InterviewRecordCreateError
    {
        public InterviewRecordCreateAction ErrorAction { get; set; }

        public Exception Error { get; set; }
    }
}
