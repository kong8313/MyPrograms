﻿using System;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback;
using Confirmit.CATI.MonitoringConsole.Resources;
using System.Windows.Forms;
using Confirmit.CATI.Common.ServiceLocation;

namespace Confirmit.CATI.MonitoringConsole
{
    public partial class CreateInterviewRecordProgressDialog :
        Form,
        IInterviewRecordEventsProcessor<InterviewRecordCreateAction>,
        IInterviewRecordEventsProcessor<InterviewRecordCreateError>
    {
        private InterviewRecordCreator _creator;
        private IAlerter _alerter;

        private delegate void SetText(string text);
        private delegate void SetProgress(int progressValue);

        public CreateInterviewRecordProgressDialog()
        {
            InitializeComponent();
            createProgress.Minimum = (int)InterviewRecordCreateAction.Starting;
            createProgress.Maximum = (int)InterviewRecordCreateAction.Completing;

            _alerter = ServiceLocator.Resolve<IAlerter>();
        }

        public void SetCreator(InterviewRecordCreator creator)
        {
            if (_creator != null)
            {
                creator.SetAcionProcessor(null);
                creator.SetErrorProcessor(null);
            }

            creator.SetAcionProcessor(this);
            creator.SetErrorProcessor(this);

            _creator = creator;
        }

        private void SetActionLabelText(InterviewRecordCreateAction action)
        {
            var text = Strings.ResourceManager.GetString(
                  string.Format(
                      "CreateInterviewRecordAction_{0}",
                      action
                      )
                  );

            if (ActionLabel.InvokeRequired)
            {
                Invoke(new SetText(SetActionLabelText), text);
            }
            else
            {
                SetActionLabelText(text);
            }
        }

        private void SetProgressValue(int value)
        {
            createProgress.Value = value;
        }

        private void SetActionLabelText(string text)
        {
            ActionLabel.Text = text;
        }

        private void CancelButtonClick(object sender, EventArgs e)
        {
            Close();
        }

        public void Process(InterviewRecordCreateAction action)
        {
            if (createProgress.InvokeRequired)
            {
                Invoke(new SetProgress(SetProgressValue), (int)action);
            }
            else
            {
                SetProgressValue((int)action);
            }

            SetActionLabelText(action);

            if (action == InterviewRecordCreateAction.Completing)
            {
                DialogResult = DialogResult.OK;
                Close();
            }
        }

        public void Process(InterviewRecordCreateError createError)
        {
            if (createError.ErrorAction == InterviewRecordCreateAction.GetAudioData)
            {
                _alerter.Alert(createError.Error.Message, Strings.Caption_Warning, MessageTypes.Warning);
                return;
            }

            _alerter.Alert(createError.Error.Message, Strings.Caption_Error, MessageTypes.Error);
            Close();
        }

        private void CreateRecordProgressDialogFormClosing(object sender, FormClosingEventArgs e)
        {
            if (_creator != null)
            {
                _creator.SetAcionProcessor(null);
                _creator.SetErrorProcessor(null);
            }
        }

    }
}
