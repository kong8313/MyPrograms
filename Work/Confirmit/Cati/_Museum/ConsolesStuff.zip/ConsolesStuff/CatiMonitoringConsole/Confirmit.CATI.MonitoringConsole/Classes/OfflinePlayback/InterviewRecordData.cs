﻿using System.Collections.Generic;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;
using System.IO;
using System.Linq;

namespace Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback
{
    public class InterviewRecordData
    {
        private List<StateEventInfo> _audioEventsInfo;
        private Stream _eventsStream;

        public InterviewRecordData()
        {
            AudioIdentities = new List<AudioIdentityObject>();
            AudioStreams = new List<Stream>();
        }

        public Stream EventsStream
        {
            get { return _eventsStream; }
            set
            {
                _audioEventsInfo = null;
                _eventsStream = value;
            }
        }

        public List<Stream> AudioStreams { get; set; }

        public List<StateEventInfo> AudioEventsInfo
        {
            get
            {
                if (_audioEventsInfo == null)
                {
                    StateEventInfo[] events = StateEventInfoDepacker.GetAllEvents(EventsStream);
                    _audioEventsInfo = events.Where(
                        x => x.MessageType == MonitoringMessageTypes.AudioStartMessage
                        ).ToList();
                }

                return _audioEventsInfo;
            }
        }

        public List<AudioIdentityObject> AudioIdentities { get; set; }

        public InterviewRecordMetadata Metadata { get; set; }

        public bool HasAudio()
        {
            return AudioStreams != null;
        }

    }
}
