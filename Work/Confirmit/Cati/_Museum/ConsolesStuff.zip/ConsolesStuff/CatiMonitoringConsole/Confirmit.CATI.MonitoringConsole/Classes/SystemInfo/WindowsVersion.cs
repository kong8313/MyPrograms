﻿namespace Confirmit.CATI.MonitoringConsole.Classes.SystemInfo
{
    public enum WindowsVersion
    {
        Unknown,        
        Windows2000,
        WindowsXP,
        WindowsXPProfessionalx64,
        WindowsHomeServer,
        WindowsServer2003,
        WindowsServer2003R2,
        WindowsVista,
        WindowsServer2008,
        WindowsServer2008R2,
        Windows7,
    }
}