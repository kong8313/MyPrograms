﻿using System.Collections.Generic;
using System.Text;

namespace Confirmit.CATI.MonitoringConsole.Classes
{
    internal class WarningMessageMarkdownGenerator
    {
        public string GenerateMarkdown(List<string> messages)
        {
            var result = new StringBuilder();

            foreach (var message in messages)
            {
                result.AppendFormat("<div style=\"background-color:#ffffcc; padding:5px;\">{0}</div>", message);
            }

            return result.ToString();
        }
    }
}