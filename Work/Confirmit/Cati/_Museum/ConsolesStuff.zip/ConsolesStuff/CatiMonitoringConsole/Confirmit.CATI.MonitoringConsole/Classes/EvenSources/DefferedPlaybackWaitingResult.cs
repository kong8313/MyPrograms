﻿namespace Confirmit.CATI.MonitoringConsole.Classes.EvenSources
{
    public enum DefferedPlaybackWaitingResult
    {
        StartAudio,
        Pause,
        JumpToQuestion,
        JumpInsideQuestion,
        WaitCompleted,
        Stop,
        Continue,
        AudioPlaybackFinished
    }
}
