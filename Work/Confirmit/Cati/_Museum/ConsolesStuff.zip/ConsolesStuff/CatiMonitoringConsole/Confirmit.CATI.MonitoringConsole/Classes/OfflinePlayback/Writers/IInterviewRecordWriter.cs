﻿namespace Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback.Writers
{
    public interface IInterviewRecordWriter
    {
        void WriteRecord(InterviewRecordData writeInfo, string fileName);
    }
}
