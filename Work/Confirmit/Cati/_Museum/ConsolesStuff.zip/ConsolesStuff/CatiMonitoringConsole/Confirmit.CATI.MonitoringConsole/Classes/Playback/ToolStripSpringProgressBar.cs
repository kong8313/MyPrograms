﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Confirmit.CATI.MonitoringConsole.Classes.Playback
{
    public partial class ToolStripSpringProgressBar : ToolStripProgressBar
    {
        public bool Disabled { get; set; }

        public Color Color { get; set; }

        public Cursor Cursor
        {
            get { return ProgressBar?.Cursor; }
            set { if (ProgressBar != null) ProgressBar.Cursor = value; }
        }

        public ToolStripSpringProgressBar()
        {
            typeof(Control).GetMethod("SetStyle",
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
                ?.Invoke(ProgressBar,
                    new object[] { ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true });
            if (ProgressBar != null) ProgressBar.Paint += progressBar_Paint;
        }

        protected override void OnClick(EventArgs e)
        {
            if (!Disabled) base.OnClick(e);
        }

        private void progressBar_Paint(object sender, PaintEventArgs e)
        {
            Rectangle rec = e.ClipRectangle;

            rec.Width = (int)(rec.Width * ((double)Value / Maximum)) - 2;
            if (ProgressBarRenderer.IsSupported)
                ProgressBarRenderer.DrawHorizontalBar(e.Graphics, e.ClipRectangle);
            rec.Height = rec.Height - 2;
            var brush = new SolidBrush(Color);
            e.Graphics.FillRectangle(brush, 1, 1, rec.Width, rec.Height);
        }

        public override Size GetPreferredSize(Size constrainingSize)
        {
            // Use the default size if the box is on the overflow menu
            // or is on a vertical ToolStrip.
            if (IsOnOverflow || Owner.Orientation == Orientation.Vertical)
            {
                return DefaultSize;
            }

            var width = Owner.DisplayRectangle.Width;

            // Subtract the width of the overflow button if it is displayed. 
            if (Owner.OverflowButton.Visible)
            {
                width = width - Owner.OverflowButton.Width -
                    Owner.OverflowButton.Margin.Horizontal;
            }

            // Count of ToolStripSpringProgressBar items currently displayed in the owning ToolStrip. 
            var springBoxCount = 0;

            foreach (ToolStripItem item in Owner.Items)
            {
                // Ignore items on the overflow menu.
                if (item.IsOnOverflow) continue;

                if (item is ToolStripSpringProgressBar)
                {
                    // For ToolStripSpringProgressBar items, increment the count and 
                    // subtract the margin width from the total available width.
                    springBoxCount++;
                    width -= item.Margin.Horizontal;
                }
                else
                {
                    // For all other items, subtract the full width from the total
                    // available width.
                    width = width - item.Width - item.Margin.Horizontal;
                }
            }

            // If there are multiple ToolStripSpringProgressBar items in the owning
            // ToolStrip, divide the total available width between them. 
            if (springBoxCount > 1) width /= springBoxCount;

            // If the available width is less than the default width, use the
            // default width, forcing one or more items onto the overflow menu.
            if (width < DefaultSize.Width) width = DefaultSize.Width;

            var size = base.GetPreferredSize(constrainingSize);
            size.Width = width;
            return size;
        }
    }
}
