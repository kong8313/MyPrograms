﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Confirmit.CATI.MonitoringConsole.Resources;

namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    public class AnsweredQuestionsComboBox : CustomToolStripComboBox
    {
        private AnsweredQuestionsComboBoxItem[] _items = new AnsweredQuestionsComboBoxItem[0];
        private string _previouslySelectedItemText = String.Empty;

        public AnsweredQuestionsComboBox()
        {
            InitializeProperties();
            InitializeBehviour();
        }

        public void InitializeProperties()
        {
            AutoCompleteMode = AutoCompleteMode.None;
            AutoCompleteSource = AutoCompleteSource.ListItems;
            ComboBox.DrawMode = DrawMode.OwnerDrawVariable;
            ComboBox.Text = Strings.SelectAnsweredQuestion;
            ComboBox.MaxDropDownItems = 20;
        }

        public void InitializeBehviour()
        {
            TextChanged += OnTextChanged;
            KeyDown += AnsweredQuestionsComboBox_KeyDown;

            ComboBox.DrawItem += ComboBoxOnDrawItem;
            ComboBox.SelectionChangeCommitted += ComboBox_SelectionChangeCommitted;
            ComboBox.DropDown += ComboBoxOnDropDown;
        }

        private void ComboBoxOnDrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            var senderComboBox = (ComboBox)sender;
            e.DrawBackground();

            var element = ((AnsweredQuestionsComboBoxItem)senderComboBox.Items[e.Index]);
            var boldFontStyle = new Font(e.Font, FontStyle.Bold);
            var regularFontStyle = new Font(e.Font, FontStyle.Regular);

            var questionIdWidth = (int)e.Graphics.MeasureString(element.ItemText.Substring(0, element.BoldTextLenght), boldFontStyle).Width + 1;
            var rectangleLeft = new Rectangle(e.Bounds.Left, e.Bounds.Top, questionIdWidth, e.Bounds.Height);
            var rectangleRight = new Rectangle(rectangleLeft.Right, e.Bounds.Top, senderComboBox.DropDownWidth - questionIdWidth, e.Bounds.Height);

            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
            {
                e.Graphics.DrawString(element.ItemText.Substring(0, element.BoldTextLenght), boldFontStyle, GetSelectedItemBrush(), rectangleLeft);
                e.Graphics.DrawString(element.ItemText.Substring(element.BoldTextLenght + 1), regularFontStyle, GetSelectedItemBrush(), rectangleRight);
            }
            else
            {
                e.Graphics.DrawString(element.ItemText.Substring(0, element.BoldTextLenght), boldFontStyle, GetRegularItemBrush(), rectangleLeft);
                e.Graphics.DrawString(element.ItemText.Substring(element.BoldTextLenght + 1), regularFontStyle, GetRegularItemBrush(), rectangleRight);
            }
        }

        private Brush GetRegularItemBrush()
        {
            return Brushes.Black;
        }

        private Brush GetSelectedItemBrush()
        {
            return Brushes.Beige;
        }

        private void ComboBoxOnDropDown(object sender, EventArgs eventArgs)
        {
            var senderComboBox = (ComboBox)sender;

            int width = senderComboBox.DropDownWidth;

            Graphics g = senderComboBox.CreateGraphics();

            var boldFontStyle = new Font(senderComboBox.Font, FontStyle.Bold);
            var regularFontStyle = new Font(senderComboBox.Font, FontStyle.Regular);

            int verticalScrollBarWidth = (senderComboBox.Items.Count > senderComboBox.MaxDropDownItems) ? SystemInformation.VerticalScrollBarWidth : 0;

            foreach (AnsweredQuestionsComboBoxItem s in senderComboBox.Items)
            {
                var questionIdWidth = (int)g.MeasureString(s.ItemText.Substring(0, s.BoldTextLenght), boldFontStyle).Width;
                int textWidth = (int)g.MeasureString(s.ItemText.Substring(s.BoldTextLenght), regularFontStyle).Width + verticalScrollBarWidth;

                if (width < textWidth + questionIdWidth)
                {
                    width = textWidth + questionIdWidth;
                }
            }

            senderComboBox.DropDownWidth = width;

            _previouslySelectedItemText = String.Empty;
        }

        void ComboBox_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (CheckSelection())
            {
                OnItemSelected(EventArgs.Empty);
            }
        }

        public event EventHandler<EventArgs> ItemSelected;

        void AnsweredQuestionsComboBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (CheckSelection())
                {
                    OnItemSelected(EventArgs.Empty);
                }

            }
            else if ((e.KeyCode == Keys.Down || e.KeyCode == Keys.Up || e.KeyCode == Keys.PageUp || e.KeyCode == Keys.PageDown) && DroppedDown == false)
            {
                DroppedDown = true;
                e.Handled = true;
                e.SuppressKeyPress = false;
            }
        }

        private bool CheckSelection()
        {
            if (Items.Count > 0 && SelectedItem != null)
            {
                var itemText = ((AnsweredQuestionsComboBoxItem)SelectedItem).ItemText;

                if (_previouslySelectedItemText != itemText)
                {
                    _previouslySelectedItemText = ((AnsweredQuestionsComboBoxItem)SelectedItem).ItemText;
                    return true;
                }
            }
            return false;
        }

        private void OnItemSelected(EventArgs eventArgs)
        {
            if (ItemSelected != null)
            {
                ItemSelected(this, eventArgs);
            }
        }

        public void Fill(AnsweredQuestionsComboBoxItem[] items)
        {
            _items = items;
            Items.Clear();
            Items.AddRange(_items);

            ComboBox.DisplayMember = "ItemText";
        }

        private void OnTextChanged(object sender, EventArgs eventArgs)
        {
            AnsweredQuestionsComboBoxItem[] values;

            values = Text.Length == 0
                ? _items
                : _items.Where(x => x.ItemText
                                            .IndexOf(Text, StringComparison.InvariantCultureIgnoreCase) >= 0)
                                            .ToArray();

            // We need this to avoid System.ArgumentOutOfRangeException 
            // when we click dropdown button after search has performed without results
            if (!values.Any() && Items.Count != 0)
                DroppedDown = false;

            Items.Clear();
            Items.AddRange(values);
            ComboBox.SelectionStart = Text.Length;
            UpdateDropDownHeight();
            ComboBox.DroppedDown = true;
        }
    }
}
