﻿using System.Runtime.InteropServices;

namespace Confirmit.CATI.MonitoringConsole.Classes.SystemInfo
{
    /// <summary>
    /// Provides information about operation system by calling low-level system functions
    /// </summary>
    public static class SystemProvider
    {      
        [StructLayout(LayoutKind.Sequential)]
        private struct OSVERSIONINFOEX
        {
            public uint dwOSVersionInfoSize;
            public uint dwMajorVersion;
            public uint dwMinorVersion;
            public uint dwBuildNumber;
            public uint dwPlatformId;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string szCSDVersion;
            public ushort wServicePackMajor;
            public ushort wServicePackMinor;
            public ushort wSuiteMask;
            public byte wProductType;
            public byte wReserved;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct SYSTEM_INFO
        {
            public uint wProcessorArchitecture;
            public uint wReserved;
            public uint dwPageSize;
            public uint lpMinimumApplicationAddress;
            public uint lpMaximumApplicationAddress;
            public uint dwActiveProcessorMask;
            public uint dwNumberOfProcessors;
            public uint dwProcessorType;
            public uint dwAllocationGranularity;
            public uint dwProcessorLevel;
            public uint dwProcessorRevision;
        }        

        [DllImport("kernel32.dll")]
        private static extern bool GetVersionEx(ref OSVERSIONINFOEX osVersionInfo);

        [DllImport("kernel32.dll")]
        private static extern void GetSystemInfo(ref SYSTEM_INFO pSi);
        
        public static OperationSystemInfo GetSystemInfo()
        {
            var osInfo = new OperationSystemInfo();                             
          
            var systemInfo = new SYSTEM_INFO();
            GetSystemInfo(ref systemInfo);

            osInfo.ProcessorArchitecture = (ProcessorArchitecture)systemInfo.wProcessorArchitecture;

            var osVersionInfo = new OSVERSIONINFOEX
            {
                dwOSVersionInfoSize = (uint)Marshal.SizeOf(typeof(OSVERSIONINFOEX))
            };            

            if (GetVersionEx(ref osVersionInfo))
            {
                osInfo.ProductType = (ProductType) osVersionInfo.wProductType;
            }
            
            return osInfo;
        }
    }
}
