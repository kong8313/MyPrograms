﻿using System;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Resources;
using Confirmit.CATI.Console.Views.Forms;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;
using Confirmit.CATI.MonitoringConsole.Resources;
using Timer = System.Windows.Forms.Timer;

namespace Confirmit.CATI.MonitoringConsole.Presenters
{
    /// <summary>
    /// It is responsible for paying events on Appointment view
    /// </summary>
    internal class PresenterAppointment
    {
        #region Fields

        private Timer m_Timer = null;
        private DateTime m_InterviewerTime;
        private DateTime m_RespondentTime;

        #endregion

        #region Properties

        #region Constructors

        /// <summary>
        /// Initializes new instance of PresenterAppointmentForm class and fills it with
        /// given data.
        /// </summary>
        public PresenterAppointment(IViewAppointmentForm appointmentForm, IWin32Window parentForm)
        {
            if (appointmentForm == null)
            {
                throw new ArgumentNullException("appointmentForm");
            }
            if (parentForm == null)
            {
                throw new ArgumentNullException("parentForm");
            }

            ParentForm = parentForm;
            AppointmentForm = appointmentForm;
            AppointmentForm.EnableInputControls(false);
        }

        #endregion

        /// <summary>
        /// Retruns instance of IViewAppointmentForm interface.
        /// </summary>
        internal IViewAppointmentForm AppointmentForm
        {
            get;
            set;
        }

        /// <summary>
        /// Retruns instance of IViewAppointmentForm interface.
        /// </summary>
        internal IWin32Window ParentForm
        {
            get;
            set;
        }

        #endregion

        #region Play methods

        private delegate void VoidDelegate(BaseStateData stateData);

        public void PlayEvent(MonitoringMessageTypes messageType, BaseStateData stateData)
        {
            if (stateData == null) return;

            SendOrPostCallback callback = null; 
            switch (messageType)
            {
                case MonitoringMessageTypes.AppointmentFormInitialMessage:
                    callback = new SendOrPostCallback(PlayAppointmentFormInitial);
                    break;
                case MonitoringMessageTypes.AppointmentFormAppointmentDateChangedMessage:                 
                    callback = new SendOrPostCallback(PlayAppointmentFormAppointmentDateChanged);
                    break;
                case MonitoringMessageTypes.AppointmentFormAppointmentTimeChangedMessage:                
                    callback = new SendOrPostCallback(PlayAppointmentFormAppointmentTimeChanged);
                    break;
                case MonitoringMessageTypes.AppointmentFormExpirationDateChangedMessage:                    
                    callback = new SendOrPostCallback(PlayAppointmentFormExpirationDateChanged);
                    break;
                case MonitoringMessageTypes.AppointmentFormExpirationTimeChangedMessage:                    
                    callback = new SendOrPostCallback(PlayAppointmentFormExpirationTimeChanged);
                    break;
                case MonitoringMessageTypes.AppointmentFormExpireChangedMessage:                   
                    callback = new SendOrPostCallback(PlayAppointmentFormExpireChanged);
                    break;
                case MonitoringMessageTypes.AppointmentFormLogoutChangedMessage:
                    callback = new SendOrPostCallback(PlayAppointmentFormLogoutChanged);
                    break;
                case MonitoringMessageTypes.AppointmentFormCloseMessage:
                    callback = new SendOrPostCallback(PlayAppointmentFormCloseMessage);
                    break;
                case MonitoringMessageTypes.AppointmentFormAllowAppointmentsOutsideShiftChangedMessage:
                    callback = new SendOrPostCallback(PlayAppointmentFormAppointmentFormAllowAppointmentsOutsideShiftChanged);
                    break;
                default:
                    Logger.Write(
                         Strings.ResourceManager.GetString("Warning_UnsupportedEvent", messageType),
                         MessageTypes.Warning
                     );
                    break;
            }
            
            if (callback != null)
            {
                AppointmentForm.SynchronizationContext.Post(callback,  stateData );
            }
        }

        /// <summary>
        /// Plays AppointmentFormInitial event
        /// Fills controls on form with passed values and shows form
        /// </summary>
        private void PlayAppointmentFormInitial(object stateData)
        {
            AppointmentInitialStateData eventData = (AppointmentInitialStateData)(stateData);

            AppointmentForm = (IViewAppointmentForm)ViewFactory.GetView(FormViews.AppointmentView);

            AppointmentForm.ShowAppointmentsOutsidePermittedShiftTime = eventData.ShowAppointmentsOutsidePermittedShiftTime;
            AppointmentForm.AppointmentDate = eventData.AppointmentDate;
            AppointmentForm.AppointmentTime = eventData.AppointmentTime;
            AppointmentForm.ExpirationDate = eventData.ExpirationDate;
            AppointmentForm.ExpirationTime = eventData.ExpirationTime;
            AppointmentForm.Logout = eventData.Logout;
            AppointmentForm.NeverExpire = eventData.NeverExpire;
            AppointmentForm.EnableExpirationTimeControls(!AppointmentForm.NeverExpire);
            m_InterviewerTime = eventData.CurrentInterviewerTime;
            m_RespondentTime = eventData.CurrentRespondentTime;

            InitTimer();
            SetTimeInCaption();

            AppointmentForm.ShowNonModal(ParentForm);
        }

        private void PlayAppointmentFormAppointmentDateChanged(object stateData)
        {
            DateControlStateData eventData = (DateControlStateData)(stateData);
            AppointmentForm.AppointmentDate = eventData.Date;

        }

        private void PlayAppointmentFormAppointmentTimeChanged(object stateData)
        {
            TextControlStateData eventData = (TextControlStateData)(stateData);
            AppointmentForm.AppointmentTime = eventData.Text;
        }

        private void PlayAppointmentFormExpirationDateChanged(object stateData)
        {
            DateControlStateData eventData = (DateControlStateData)(stateData);
            AppointmentForm.ExpirationDate = eventData.Date;

        }

        private void PlayAppointmentFormExpirationTimeChanged(object stateData)
        {
            TextControlStateData eventData = (TextControlStateData)(stateData);
            AppointmentForm.ExpirationTime = eventData.Text;
        }

        private void PlayAppointmentFormExpireChanged(object stateData)
        {
            CheckControlStateData eventData = (CheckControlStateData)(stateData);
            AppointmentForm.NeverExpire = eventData.Checked;
        }

        private void PlayAppointmentFormLogoutChanged(object stateData)
        {
            CheckControlStateData eventData = (CheckControlStateData)(stateData);
            AppointmentForm.Logout = eventData.Checked;
        }

        private void PlayAppointmentFormAppointmentFormAllowAppointmentsOutsideShiftChanged(object stateData)
        {
            CheckControlStateData eventData = (CheckControlStateData)(stateData);
            AppointmentForm.AllowAppointmentsOutsideShifts = eventData.Checked;
        }

        private void PlayAppointmentFormCloseMessage(object stateData)
        {
            AppointmentCloseStateData eventData = (AppointmentCloseStateData)(stateData);
            StopTimer();
            AppointmentForm.HideForm();
        }

        #endregion

        #region Methods

        public void CloseAppointmentForm()
        {
            if (AppointmentForm.IsVisible == false) return;
            
            StopTimer();
            AppointmentForm.HideForm();
        }

        /// <summary>
        /// Initialiazes timer object which is used for respondent and interviewer showing.
        /// </summary>
        private void InitTimer()
        {
            m_Timer = new Timer();
            m_Timer.Interval = 1000;
            m_Timer.Tick += new EventHandler(Timer_Tick);
            m_Timer.Start();
        }

        /// <summary>
        /// Stops and releases timer.
        /// </summary>
        private void StopTimer()
        {
            if (m_Timer != null)
            {
                m_Timer.Stop();
                m_Timer = null;
            }
        }

        /// <summary>
        /// Handles time Tick event. Sets respondent and interviewer local time.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        private void Timer_Tick(object sender, EventArgs e)
        {
            m_InterviewerTime = m_InterviewerTime.AddSeconds(1);
            m_RespondentTime = m_RespondentTime.AddSeconds(1);

            SetTimeInCaption();
        }

        /// <summary>
        /// Sets respondent and interviewer local time.
        /// </summary>
        private void SetTimeInCaption()
        {
            AppointmentForm.InterviewerTime = m_InterviewerTime.ToLongTimeString();
            AppointmentForm.RespondentTime = m_RespondentTime.ToLongTimeString();
        }

        #endregion
    }
}
