﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows.Forms;

namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int left;
        public int top;
        public int right;
        public int bottom;

        public RECT(int left, int top, int right, int bottom)
        {
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
        }

        public RECT(System.Drawing.Rectangle r)
        {
            this.left = r.Left;
            this.top = r.Top;
            this.right = r.Right;
            this.bottom = r.Bottom;
        }

        public static RECT FromXYWH(int x, int y, int width, int height)
        {
            return new RECT(x, y, x + width, y + height);
        }

        public System.Drawing.Size Size
        {
            get
            {
                return new System.Drawing.Size(this.right - this.left, this.bottom - this.top);
            }
        }
    }

    public class CustomComboBoxDrawingFunctions
    {
        private static readonly object internalSyncObject = new object();
        private static Font defaultFont;

        [ThreadStatic]
        private static ProfessionalColorTable professionalColorTable = null;

        [ResourceExposure(ResourceScope.Process)]
        [ResourceConsumption(ResourceScope.Process)]
        internal static Font FontInPoints(Font font)
        {
            return new Font(font.FontFamily, font.SizeInPoints, font.Style, GraphicsUnit.Point, font.GdiCharSet,
                font.GdiVerticalFont);
        }

        internal static ProfessionalColorTable ColorTable
        {
            get
            {
                if (professionalColorTable == null)
                {
                    professionalColorTable = new ProfessionalColorTable();
                }
                return professionalColorTable;
            }
        }

        internal static Font DefaultFont
        {
            get
            {
                Font sysFont = null;
                Font retFont = defaultFont; // threadsafe local reference

                if (retFont == null)
                {
                    lock (internalSyncObject)
                    {
                        // double check the defaultFont after the lock.
                        retFont = defaultFont;

                        if (retFont == null)
                        {
                            // default to menu font
                            sysFont = SystemFonts.MenuFont;
                            if (sysFont == null)
                            {
                                // ...or to control font if menu font unavailable
                                sysFont = Control.DefaultFont;
                            }
                            if (sysFont != null)
                            {
                                // ensure font is in pixels so it displays properly in the property grid at design time.
                                if (sysFont.Unit != GraphicsUnit.Point)
                                {
                                    defaultFont = FontInPoints(sysFont);
                                    retFont = defaultFont;
                                    sysFont.Dispose();
                                }
                                else
                                {
                                    defaultFont = sysFont;
                                    retFont = defaultFont;
                                }
                            }
                            return retFont;
                        }
                    }
                }
                return retFont;
            }
        }
    }
}
