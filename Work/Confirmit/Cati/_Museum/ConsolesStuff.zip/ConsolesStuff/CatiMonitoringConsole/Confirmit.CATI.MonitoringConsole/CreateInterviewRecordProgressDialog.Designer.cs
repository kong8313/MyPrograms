﻿namespace Confirmit.CATI.MonitoringConsole
{
    partial class CreateInterviewRecordProgressDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateInterviewRecordProgressDialog));
            this.BackGroundPanel = new System.Windows.Forms.Panel();
            this.ActionLabel = new System.Windows.Forms.Label();
            this.createProgress = new System.Windows.Forms.ProgressBar();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.BackGroundPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // BackGroundPanel
            // 
            this.BackGroundPanel.BackColor = System.Drawing.SystemColors.Window;
            this.BackGroundPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BackGroundPanel.Controls.Add(this.ActionLabel);
            this.BackGroundPanel.Controls.Add(this.createProgress);
            this.BackGroundPanel.Location = new System.Drawing.Point(-3, -1);
            this.BackGroundPanel.Name = "BackGroundPanel";
            this.BackGroundPanel.Size = new System.Drawing.Size(397, 74);
            this.BackGroundPanel.TabIndex = 1;
            // 
            // ActionLabel
            // 
            this.ActionLabel.AutoSize = true;
            this.ActionLabel.Location = new System.Drawing.Point(11, 12);
            this.ActionLabel.Name = "ActionLabel";
            this.ActionLabel.Size = new System.Drawing.Size(0, 13);
            this.ActionLabel.TabIndex = 1;
            // 
            // createProgress
            // 
            this.createProgress.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.createProgress.Location = new System.Drawing.Point(14, 28);
            this.createProgress.Name = "createProgress";
            this.createProgress.Size = new System.Drawing.Size(368, 23);
            this.createProgress.TabIndex = 0;
            // 
            // CancelBtn
            // 
            this.CancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CancelBtn.Location = new System.Drawing.Point(305, 79);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(75, 23);
            this.CancelBtn.TabIndex = 2;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelButtonClick);
            // 
            // CreateRecordProgressDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 109);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.BackGroundPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CreateRecordProgressDialog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Creating record...";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CreateRecordProgressDialogFormClosing);
            this.BackGroundPanel.ResumeLayout(false);
            this.BackGroundPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel BackGroundPanel;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.Label ActionLabel;
        private System.Windows.Forms.ProgressBar createProgress;

    }
}