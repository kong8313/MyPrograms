﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Confirmit.CATI.Console.Shared.Exceptions;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.Monitoring.Common.StateData;
using Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion;
using Confirmit.CATI.MonitoringConsole.Properties;

namespace Confirmit.CATI.MonitoringConsole.Classes.EvenSources
{
    /// <summary>
    /// Represents deferred monitoring events source.
    /// </summary>
    public class DeferredEventSource : EventSource
    {
        private readonly bool _pauseAtTheEnd;
        private readonly AutoResetEvent _jumpToMilestoneEvent = new AutoResetEvent(false);
        private readonly AutoResetEvent _jumpToPositionEvent = new AutoResetEvent(false);
        private readonly AutoResetEvent _audioFinishedEvent = new AutoResetEvent(false);
        private readonly ManualResetEvent _manualResetPauseEvent = new ManualResetEvent(false);
        private readonly ManualResetEvent _manualResetPlayEvent = new ManualResetEvent(true);
        private readonly ManualResetEvent _shutdownEvent = new ManualResetEvent(false);
        public StateEventInfo[] Events { get; }
        private Task _playTask;

        private readonly EventInfo[] _audioEvents;
        private bool _isAudioStarted;

        private volatile int _replayEventsStartIndex;
        private volatile int _replayEventsFinishIndex;
        private volatile bool _replayEventsNeed;

        private TimeSpan _jumpSpan = TimeSpan.Zero;
        private TimeSpan _currentMilestoneElapsed = TimeSpan.Zero;
        private TimeSpan? _playOffset;

        public MilestoneProvider MilestoneProvider { get; private set; }
        public MilestoneEvent CurrentMilestone => MilestoneProvider?.CurrentMilestone;

        public DeferredEventSource(IEnumerable<StateEventInfo> events, bool pauseAtTheEnd = true)
        {
            _pauseAtTheEnd = pauseAtTheEnd;
            var stateEventInfos = events as StateEventInfo[] ?? events.ToArray();
            _audioEvents = stateEventInfos.Where(x => x.MessageType == MonitoringMessageTypes.AudioStartMessage).OrderBy(x => x.TimeStamp)
                .Select(x =>
                {
                    var audioEvent = new EventInfo(x);
                    ((AudioStartStateData)audioEvent.State).HasDuration = false;
                    return audioEvent;
                })
                .ToArray();
            //skip MonitoringInitialMessage in deferred mode playing
            Events = stateEventInfos.Where(x =>
                x.MessageType != MonitoringMessageTypes.AudioStartMessage &&
                x.MessageType != MonitoringMessageTypes.MonitoringInitialMessage).ToArray();

            MilestoneProvider = new MilestoneProvider(Events);
            MilestoneProvider.CurrentMilestoneUpdated += CurrentMilestoneUpdated;
        }

        public InterviewingInitialStateData GetInterviewingInitialStateData()
        {
            if (Events == null)
            {
                return null;
            }

            foreach (var playbackEvent in Events)
            {
                if (playbackEvent.MessageType != MonitoringMessageTypes.MonitoringInitialMessage &&
                    playbackEvent.MessageType != MonitoringMessageTypes.InterviewInitialMessage)
                {
                    continue;
                }

                var eventInfo = new EventInfo(playbackEvent);
                var state = eventInfo.State as InterviewingInitialStateData;
                if (state != null)
                {
                    return state;
                }
            }

            return null;
        }

        /// <summary>
        /// Starts process of getting monitoring events.
        /// </summary>
        public override async Task Start()
        {
            try
            {
                _playTask = Task.Factory.StartNew(ProcessEvents);
                await _playTask;
            }
            catch (Exception ex)
            {
                Logger.Write(ex, MessageTypes.Error);
                throw;
            }
        }

        public override void Pause()
        {
            _manualResetPlayEvent.Reset();
            _manualResetPauseEvent.Set();
        }

        public override void Stop()
        {
            _shutdownEvent.Set();
            _playTask.Wait();
        }

        public override void Resume()
        {
            _manualResetPauseEvent.Reset();
            _manualResetPlayEvent.Set();
        }

        public override void NotifyAudioDuration(AudioIdentityObject currentAudioRecordId, TimeSpan duration)
        {
            var audioEvent =
                _audioEvents.First(x => ((AudioStartStateData)x.State).AudioRecordID.Equals(currentAudioRecordId));
            ((AudioStartStateData)audioEvent.State).HasDuration = true;
            ((AudioStartStateData)audioEvent.State).Duration = duration;
        }

        public override void NotifyAudioFinished()
        {
            _isAudioStarted = false;
            _audioFinishedEvent.Set();
        }

        /// <summary>
        /// Sets the AutoResetEvent to signaled and changes the event index.
        /// This allows to jump to PageCompletedEventIndex and without delays to QuestionSelectedEventIndex.
        /// </summary>
        /// <param name="pageCompletedEventIndex">PageCompletedEventIndex</param>
        /// <param name="questionSelectedEventIndex">QuestionSelectedEventIndex</param>
        public override void JumpToMilestone(int pageCompletedEventIndex, int questionSelectedEventIndex)
        {
            _replayEventsStartIndex = pageCompletedEventIndex;
            _replayEventsFinishIndex = questionSelectedEventIndex;

            _jumpToMilestoneEvent.Set();
        }

        private void JumpToMilestoneAfterwards(out int currentEventIndex)
        {
            StopAudioEvent();
            ProcessEventsWithoutDelay(_replayEventsStartIndex, _replayEventsFinishIndex);
            _playOffset = null;
            currentEventIndex = _replayEventsFinishIndex;
            OnJumpCompleted();
        }

        public override void JumpToPositionInsideMilestone(TimeSpan newPosition)
        {
            if (CurrentMilestone == null) return;

            if (newPosition < TimeSpan.Zero) newPosition = TimeSpan.Zero;
            if (newPosition > CurrentMilestone.Duration) newPosition = CurrentMilestone.Duration;

            var timestampNewPos = CurrentMilestone.Time.Add(newPosition);
            var timestampCurPos = CurrentMilestone.Time.Add(_currentMilestoneElapsed);

            _jumpSpan = timestampNewPos - timestampCurPos;
            if (timestampNewPos < timestampCurPos) //Jump back
            {
                _replayEventsNeed = Events.Any(x => timestampNewPos < x.TimeStamp && x.TimeStamp <= timestampCurPos);
                if (_replayEventsNeed)
                {
                    _replayEventsStartIndex = CurrentMilestone.IndexOfEventContentLoad;

                    var lastCompletedEvent = Events.Last(x => x.TimeStamp <= timestampNewPos);
                    _replayEventsFinishIndex = Array.IndexOf(Events, lastCompletedEvent);

                    _jumpSpan = timestampNewPos - lastCompletedEvent.TimeStamp;
                }
            }
            else //Jump forward
            {
                _replayEventsNeed = Events.Any(x => timestampCurPos < x.TimeStamp && x.TimeStamp <= timestampNewPos);
                if (_replayEventsNeed)
                {
                    var firstUncompletedEvent = Events.FirstOrDefault(x => timestampCurPos < x.TimeStamp);
                    _replayEventsStartIndex = Array.IndexOf(Events, firstUncompletedEvent);

                    var lastUncompletedEvent = Events.Last(x => x.TimeStamp <= timestampNewPos);
                    _replayEventsFinishIndex = Array.IndexOf(Events, lastUncompletedEvent);

                    _jumpSpan = timestampNewPos - lastUncompletedEvent.TimeStamp;
                }
            }

            _jumpToPositionEvent.Set();
        }

        private DefferedPlaybackWaitingResult JumpToPositionInsideMilestoneAfterwards(ref int currentEventIndex)
        {
            DefferedPlaybackWaitingResult result;
            if (_replayEventsNeed)
            {
                StopAudioEvent();
                ProcessEventsWithoutDelay(_replayEventsStartIndex, _replayEventsFinishIndex);
                _currentMilestoneElapsed += _jumpSpan;
                OnNotifyMilestonePosition(_currentMilestoneElapsed);
                _playOffset = null;
                currentEventIndex = _replayEventsFinishIndex;
                result = DefferedPlaybackWaitingResult.JumpInsideQuestion;
            }
            else
            {
                _currentMilestoneElapsed += _jumpSpan;
                OnNotifyMilestonePosition(_currentMilestoneElapsed);
                _playOffset -= _jumpSpan;

                var absolutePosition = GetCurrentPlayPosition();
                var audioEvent = GetAudioAtPosition(absolutePosition);
                if (audioEvent != null)
                {
                    PlayAudioEventOffsetToPosition(audioEvent, absolutePosition);
                }
                else
                {
                    StopAudioEvent();
                }

                _jumpSpan = TimeSpan.Zero;
                result = DefferedPlaybackWaitingResult.Continue;
            }

            OnJumpCompleted();
            return result;
        }

        public override void UpdateAudioEventPosition(TimeSpan clientAudioShift)
        {
            var absolutePosition = GetCurrentPlayPosition();
            var audioEvent = GetAudioAtPosition(absolutePosition);
            if (audioEvent != null)
            {
                audioEvent.TimeStamp -= clientAudioShift;
                PlayAudioEventOffsetToPosition(audioEvent, absolutePosition);
            }
        }

        private void ProcessEvents()
        {
            _playOffset = null;
            for (int i = 0; i < Events.Length; i++)
            {
                PlayEvent(i);

                if (IsNextAudioExpected(i)) _isAudioStarted = false;

                DefferedPlaybackWaitingResult result = DefferedPlaybackWaitingResult.Continue;
                do
                {
                    if (_playOffset == null)
                    {
                        _playOffset = DateTime.UtcNow - Events[i].TimeStamp - _jumpSpan;
                        _jumpSpan = TimeSpan.Zero;
                    }

                    EventInfo nextAudio = null;
                    if (result != DefferedPlaybackWaitingResult.Pause && i < Events.Length - 1)
                    {
                        var absolutePosition = GetCurrentPlayPosition();
                        nextAudio = GetAudioAtPosition(absolutePosition) ??
                                    GetAudioBetweenPositions(absolutePosition, Events[i + 1].TimeStamp, i == 0);
                        result = WaitToNextEvent(Events[i + 1], nextAudio);
                    }

                    if (i == Events.Length - 1)
                    {
                        if (_pauseAtTheEnd)
                        {
                            result = DefferedPlaybackWaitingResult.Pause;
                            OnPaused();
                        }
                        else
                        {
                            result = DefferedPlaybackWaitingResult.WaitCompleted;
                        }
                    }

                    switch (result)
                    {
                        case DefferedPlaybackWaitingResult.JumpToQuestion:
                            JumpToMilestoneAfterwards(out i);

                            break;

                        case DefferedPlaybackWaitingResult.JumpInsideQuestion:
                            result = JumpToPositionInsideMilestoneAfterwards(ref i);

                            break;

                        case DefferedPlaybackWaitingResult.StartAudio:
                            if (nextAudio != null)
                            {
                                var absolutePosition = GetCurrentPlayPosition();
                                PlayAudioEventOffsetToPosition(nextAudio, absolutePosition);
                            }

                            break;

                        case DefferedPlaybackWaitingResult.Pause:
                            var pauseWatch = Stopwatch.StartNew();

                            var pauseResult = WaitHandle.WaitAny(
                                new WaitHandle[]
                                    {_manualResetPlayEvent, _shutdownEvent, _jumpToMilestoneEvent, _jumpToPositionEvent},
                                Timeout.Infinite);
                            _playOffset += pauseWatch.Elapsed;

                            if (pauseResult == 0) result = DefferedPlaybackWaitingResult.Continue;
                            if (pauseResult == 1) return;
                            if (pauseResult == 2) JumpToMilestoneAfterwards(out i);
                            if (pauseResult == 3) JumpToPositionInsideMilestoneAfterwards(ref i);

                            break;

                        case DefferedPlaybackWaitingResult.WaitCompleted:
                            break;
                        case DefferedPlaybackWaitingResult.Stop:
                            return;
                    }
                }
                /* StartAudio or Pause can happen while waiting for play time of next event. 
                   If it happens we should do one more iteration to complete waiting.  */
                while (result != DefferedPlaybackWaitingResult.WaitCompleted &&
                       result != DefferedPlaybackWaitingResult.Stop);
            }

            OnGetEvents(
                new GetEventsEventArgs
                {
                    Events = new[]
                    {
                        new EventInfo()
                        {
                            MessageType = MonitoringMessageTypes.MonitoringEndMessage,
                            State = null,
                            TimeStamp = DateTime.UtcNow
                        }
                    }
                }
            );
        }

        private DateTime GetCurrentPlayPosition()
        {
            if (_playOffset.HasValue)
                return DateTime.UtcNow - _playOffset.Value;

            if (CurrentMilestone != null)
                return CurrentMilestone.Time + _currentMilestoneElapsed;

            throw new CATIConsoleException("Unknown current play position");
        }

        private EventInfo GetAudioAtPosition(DateTime position)
        {
            var closestAudio = _audioEvents.LastOrDefault(x => x.TimeStamp <= position);

            if (closestAudio == null) return null;

            var closestAudioState = ((AudioStartStateData)closestAudio.State);
            if (!closestAudioState.HasDuration) return closestAudio;

            var audioEndPosition = closestAudio.TimeStamp + closestAudioState.Duration;
            if (position < audioEndPosition)
                return closestAudio;

            return null;
        }

        private EventInfo GetAudioBetweenPositions(DateTime startPosition, DateTime finishPosition, bool isFirstEvent)
        {
            if (isFirstEvent)
                return _audioEvents.FirstOrDefault(x => x.TimeStamp <= finishPosition);

            return _audioEvents.FirstOrDefault(x => startPosition <= x.TimeStamp && x.TimeStamp <= finishPosition);
        }

        private void PlayAudioEventOffsetToPosition(EventInfo audioEvent, DateTime position)
        {
            var audioOffset = position - audioEvent.TimeStamp;

            var state = (AudioStartStateData)audioEvent.State;
            state.StartAudioOffset = audioOffset;

            OnGetEvents(new GetEventsEventArgs { Events = new[] { audioEvent } });
            _isAudioStarted = true;
        }

        private void StopAudioEvent()
        {
            OnGetEvents(new GetEventsEventArgs
            {
                Events = new[]
                {
                    new EventInfo
                    {
                        MessageType = MonitoringMessageTypes.AudioStopMessage,
                        TimeStamp = GetCurrentPlayPosition()
                    }
                }
            });
            _isAudioStarted = false;
        }

        private void ProcessEventsWithoutDelay(int startIndex, int endIndex)
        {
            for (int j = startIndex; j <= endIndex; j++)
            {
                PlayEvent(j);
            }
        }

        private void PlayEvent(int eventIndex)
        {
            var eventInfo = new EventInfo(Events[eventIndex], eventIndex);

            if (eventInfo.MessageType == MonitoringMessageTypes.MonitoringEndMessage) return;

            if (MilestoneProvider.EventInCurrentMilestone(eventIndex))
            {
                _currentMilestoneElapsed = eventInfo.TimeStamp - CurrentMilestone.Time;
                OnNotifyMilestonePosition(_currentMilestoneElapsed);
            }

            //if it the last event and need to pause at the end do not close current milestone
            if (!_pauseAtTheEnd || eventIndex != Events.Length - 1)
                MilestoneProvider.UpdateCurrentMilestone(eventIndex);

            OnGetEvents(new GetEventsEventArgs { Events = new[] { eventInfo } });
        }

        private void CurrentMilestoneUpdated(object sender, MilestoneEvent e)
        {
            _currentMilestoneElapsed = TimeSpan.Zero;
            if (CurrentMilestone != null)
            {
                OnNotifyMilestonePosition(_currentMilestoneElapsed);
            }
        }

        private bool IsNextAudioExpected(int i)
        {
            return Events[i].MessageType == MonitoringMessageTypes.RedialFormTelephonyResultMessage ||
                   Events[i].MessageType == MonitoringMessageTypes.DialStartMessage ||
                   Events[i].MessageType == MonitoringMessageTypes.RedialFormHangupDialCalledMessage;
        }

        private DefferedPlaybackWaitingResult WaitToNextEvent(StateEventInfo nextEvent, EventInfo nextAudioEvent)
        {
            var absolutePosition = GetCurrentPlayPosition();
            var waitTime = nextEvent.TimeStamp - absolutePosition;

            var result = DefferedPlaybackWaitingResult.WaitCompleted;

            if (!_isAudioStarted && nextAudioEvent != null)
            {
                if (nextAudioEvent.TimeStamp < nextEvent.TimeStamp)
                {
                    var audioOffset = absolutePosition - nextAudioEvent.TimeStamp;
                    var state = (AudioStartStateData)nextAudioEvent.State;
                    //if audio playing left less than 200 milliseconds won't start playing
                    if (!(state.HasDuration && audioOffset + MilestoneProvider.MinimalMilestoneSignificantDuration > state.Duration))
                    {
                        waitTime = nextAudioEvent.TimeStamp - absolutePosition;
                        result = DefferedPlaybackWaitingResult.StartAudio;
                    }
                }
            }

            if (waitTime <= TimeSpan.Zero) return result;

            if (CurrentMilestone != null)
            {
                _currentMilestoneElapsed = absolutePosition - CurrentMilestone.Time;
                OnNotifyMilestonePosition(_currentMilestoneElapsed);
            }

            while (waitTime > TimeSpan.Zero)
            {
                var timeoutEvent = new ManualResetEvent(false);

                Task.Run(() =>
                {
                    Thread.Sleep(Settings.Default.SamplingFrequencyMillisec);
                    timeoutEvent.Set();
                });

                switch (WaitHandle.WaitAny(new WaitHandle[] { _jumpToMilestoneEvent, _manualResetPauseEvent, _shutdownEvent, _jumpToPositionEvent, timeoutEvent, _audioFinishedEvent }, waitTime))
                {
                    case 0:
                        return DefferedPlaybackWaitingResult.JumpToQuestion;
                    case 1:
                        return DefferedPlaybackWaitingResult.Pause;
                    case 2:
                        return DefferedPlaybackWaitingResult.Stop;
                    case 3:
                        return DefferedPlaybackWaitingResult.JumpInsideQuestion;
                    case 4:
                        waitTime -= TimeSpan.FromMilliseconds(Settings.Default.SamplingFrequencyMillisec);
                        if (CurrentMilestone != null)
                        {
                            _currentMilestoneElapsed += TimeSpan.FromMilliseconds(Settings.Default.SamplingFrequencyMillisec);
                            OnNotifyMilestonePosition(_currentMilestoneElapsed);
                        }
                        break;
                    case 5:
                        return DefferedPlaybackWaitingResult.AudioPlaybackFinished;
                    default:
                        return result;
                }
            }

            return result;
        }
    }
}
