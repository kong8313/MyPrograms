﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    public class CustomComboBox : ComboBox
    {
        public const int WM_PARENTNOTIFY = 0x0210;
        public const int WM_CREATE = 0x0001;
        private const int DefaultDropDownHeight = 106;
        public const int SWP_NOZORDER = 0x0004;
        public const int SWP_NOMOVE = 0x0002;
        private static HandleRef _nullHandleRef = new HandleRef(null, IntPtr.Zero);
        private IntPtr _dropDownHandle = IntPtr.Zero;
        private bool mouseOver;

        internal bool MouseIsOver
        {
            get { return mouseOver; }
            set
            {
                if (mouseOver != value)
                {
                    mouseOver = value;
                    // Nothing to see here... Just keep on walking... VSWhidbey 504477.
                    // Turns out that with Theming off, we don't get quite the same messages as with theming on, so
                    // our drawing gets a little messed up. So in case theming is off, force a draw here.
                    if ((!ContainsFocus || !Application.RenderWithVisualStyles) && this.FlatStyle == FlatStyle.Popup)
                    {
                        Invalidate();
                        Update();
                    }
                }
            }
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (m.Msg == WM_PARENTNOTIFY)
            {
                if (unchecked((int)(long)m.WParam) == (WM_CREATE | 1000 << 16))
                {
                    _dropDownHandle = m.LParam;
                }
            }
        }
        
        public void UpdateDropDownHeight()
        {
            if (_dropDownHandle != IntPtr.Zero)
            {
                int height = DropDownHeight;
                if (height == DefaultDropDownHeight)
                {
                    int itemCount = (Items == null) ? 0 : Items.Count;
                    int count = Math.Min(Math.Max(itemCount, 1), MaxDropDownItems);
                    height = (ItemHeight * count + 2);
                }

                SafeNativeMethods.SetWindowPos(new HandleRef(this, _dropDownHandle), _nullHandleRef, 0, 0, DropDownWidth, height, SWP_NOMOVE | SWP_NOZORDER);
            }
        }

        internal virtual FlatComboAdapter CreateFlatComboAdapterInstance()
        {
            return new FlatComboAdapter(this,/*smallButton=*/false);
        }

        internal class FlatComboAdapter
        {
            Rectangle outerBorder;
            Rectangle innerBorder;
            Rectangle innerInnerBorder;
            internal Rectangle dropDownRect;
            Rectangle whiteFillRect;
            Rectangle clientRect;

            RightToLeft origRightToLeft; // The combo box's RTL value when we were created

            private const int WhiteFillRectWidth = 5; // used for making the button look smaller than it is

            public FlatComboAdapter(CustomComboBox comboBox, bool smallButton)
            {
                clientRect = comboBox.ClientRectangle;
                int dropDownButtonWidth = System.Windows.Forms.SystemInformation.HorizontalScrollBarArrowWidth;
                outerBorder = new Rectangle(clientRect.Location, new Size(clientRect.Width - 1, clientRect.Height - 1));
                innerBorder = new Rectangle(outerBorder.X + 1, outerBorder.Y + 1, outerBorder.Width - dropDownButtonWidth - 2, outerBorder.Height - 2);
                innerInnerBorder = new Rectangle(innerBorder.X + 1, innerBorder.Y + 1, innerBorder.Width - 2, innerBorder.Height - 2);
                dropDownRect = new Rectangle(innerBorder.Right + 1, innerBorder.Y, dropDownButtonWidth, innerBorder.Height + 1);

                // fill in several pixels of the dropdown rect with white so that it looks like the combo button is thinner.
                if (smallButton)
                {
                    whiteFillRect = dropDownRect;
                    whiteFillRect.Width = WhiteFillRectWidth;
                    dropDownRect.X += WhiteFillRectWidth;
                    dropDownRect.Width -= WhiteFillRectWidth;
                }

                origRightToLeft = comboBox.RightToLeft;

                if (origRightToLeft == RightToLeft.Yes)
                {
                    innerBorder.X = clientRect.Width - innerBorder.Right;
                    innerInnerBorder.X = clientRect.Width - innerInnerBorder.Right;
                    dropDownRect.X = clientRect.Width - dropDownRect.Right;
                    whiteFillRect.X = clientRect.Width - whiteFillRect.Right + 1;  // since we're filling, we need to move over to the next px.
                }
            }

            public bool IsValid(CustomComboBox combo)
            {
                return (combo.ClientRectangle == clientRect && combo.RightToLeft == origRightToLeft);
            }

            public static bool IsZeroWidthOrHeight(Rectangle rectangle)
            {
                return (rectangle.Width == 0 || rectangle.Height == 0);
            }

            public static bool IsZeroWidthOrHeight(Size size)
            {
                return (size.Width == 0 || size.Height == 0);
            }

            /// <devdoc>
            ///     Paints over the edges of the combo box to make it appear flat.
            /// </devdoc>
            public virtual void DrawFlatCombo(CustomComboBox comboBox, Graphics g)
            {
                if (comboBox.DropDownStyle == ComboBoxStyle.Simple)
                {
                    return;
                }

                Color outerBorderColor = GetOuterBorderColor(comboBox);
                Color innerBorderColor = GetInnerBorderColor(comboBox);
                bool rightToLeft = comboBox.RightToLeft == RightToLeft.Yes;

                // draw the drop down
                DrawFlatComboDropDown(comboBox, g, dropDownRect);

                // when we are disabled there is one line of color that seems to eek through if backcolor is set
                // so lets erase it.
                if (!IsZeroWidthOrHeight(whiteFillRect))
                {
                    // fill in two more pixels with white so it looks smaller.
                    using (Brush b = new SolidBrush(innerBorderColor))
                    {
                        g.FillRectangle(b, whiteFillRect);
                    }
                }

                // Draw the outer border
                if (outerBorderColor.IsSystemColor)
                {
                    Pen outerBorderPen = SystemPens.FromSystemColor(outerBorderColor);
                    g.DrawRectangle(outerBorderPen, outerBorder);
                    if (rightToLeft)
                    {
                        g.DrawRectangle(outerBorderPen, new Rectangle(outerBorder.X, outerBorder.Y, dropDownRect.Width + 1, outerBorder.Height));
                    }
                    else
                    {
                        g.DrawRectangle(outerBorderPen, new Rectangle(dropDownRect.X, outerBorder.Y, outerBorder.Right - dropDownRect.X, outerBorder.Height));
                    }
                }
                else
                {
                    using (Pen outerBorderPen = new Pen(outerBorderColor))
                    {
                        g.DrawRectangle(outerBorderPen, outerBorder);
                        if (rightToLeft)
                        {
                            g.DrawRectangle(outerBorderPen, new Rectangle(outerBorder.X, outerBorder.Y, dropDownRect.Width + 1, outerBorder.Height));
                        }
                        else
                        {
                            g.DrawRectangle(outerBorderPen, new Rectangle(dropDownRect.X, outerBorder.Y, outerBorder.Right - dropDownRect.X, outerBorder.Height));
                        }
                    }
                }

                // Draw the inner border
                if (innerBorderColor.IsSystemColor)
                {
                    Pen innerBorderPen = SystemPens.FromSystemColor(innerBorderColor);
                    g.DrawRectangle(innerBorderPen, innerBorder);
                    g.DrawRectangle(innerBorderPen, innerInnerBorder);
                }
                else
                {
                    using (Pen innerBorderPen = new Pen(innerBorderColor))
                    {
                        g.DrawRectangle(innerBorderPen, innerBorder);
                        g.DrawRectangle(innerBorderPen, innerInnerBorder);
                    }
                }

                // Draw a dark border around everything if we're in popup mode
                if ((!comboBox.Enabled) || (comboBox.FlatStyle == FlatStyle.Popup))
                {
                    bool focused = comboBox.ContainsFocus;// || comboBox.MouseIsOver;
                    Color borderPenColor = GetPopupOuterBorderColor(comboBox, focused);

                    using (Pen borderPen = new Pen(borderPenColor))
                    {

                        Pen innerPen = (comboBox.Enabled) ? borderPen : SystemPens.Control;

                        // around the dropdown
                        if (rightToLeft)
                        {
                            g.DrawRectangle(innerPen, new Rectangle(outerBorder.X, outerBorder.Y, dropDownRect.Width + 1, outerBorder.Height));
                        }
                        else
                        {
                            g.DrawRectangle(innerPen, new Rectangle(dropDownRect.X, outerBorder.Y, outerBorder.Right - dropDownRect.X, outerBorder.Height));
                        }

                        // around the whole combobox.
                        g.DrawRectangle(borderPen, outerBorder);

                    }
                }

            }

            protected virtual void DrawFlatComboDropDown(CustomComboBox comboBox, Graphics g, Rectangle dropDownRect)
            {
                g.FillRectangle(SystemBrushes.Control, dropDownRect);

                Brush brush = (comboBox.Enabled) ? SystemBrushes.ControlText : SystemBrushes.ControlDark;

                Point middle = new Point(dropDownRect.Left + dropDownRect.Width / 2, dropDownRect.Top + dropDownRect.Height / 2);
                if (origRightToLeft == RightToLeft.Yes)
                {
                    // if the width is odd - favor pushing it over one pixel left.
                    middle.X -= (dropDownRect.Width % 2);
                }
                else
                {
                    // if the width is odd - favor pushing it over one pixel right.
                    middle.X += (dropDownRect.Width % 2);
                }

                g.FillPolygon(brush, new Point[] {
                     new Point(middle.X - 2, middle.Y - 1),
                     new Point(middle.X + 3, middle.Y - 1),
                     new Point(middle.X, middle.Y + 2)
                 });
            }

            protected virtual Color GetOuterBorderColor(CustomComboBox comboBox)
            {
                return (comboBox.Enabled) ? SystemColors.Window : SystemColors.ControlDark;
            }

            protected virtual Color GetPopupOuterBorderColor(CustomComboBox comboBox, bool focused)
            {
                if (!comboBox.Enabled)
                {
                    return SystemColors.ControlDark;
                }
                return (focused) ? SystemColors.ControlDark : SystemColors.Window;
            }

            protected virtual Color GetInnerBorderColor(CustomComboBox comboBox)
            {
                return (comboBox.Enabled) ? comboBox.BackColor : SystemColors.Control;
            }

            // this eliminates flicker by removing the pieces we're going to paint ourselves from 
            // the update region.  Note the UpdateRegionBox is the bounding box of the actual update region.
            // this is just here so we can quickly eliminate rectangles that arent in the update region.
            public void ValidateOwnerDrawRegions(CustomComboBox comboBox, Rectangle updateRegionBox)
            {
                RECT validRect;
                if (comboBox != null) { return; }
                Rectangle topOwnerDrawArea = new Rectangle(0, 0, comboBox.Width, innerBorder.Top);
                Rectangle bottomOwnerDrawArea = new Rectangle(0, innerBorder.Bottom, comboBox.Width, comboBox.Height - innerBorder.Bottom);
                Rectangle leftOwnerDrawArea = new Rectangle(0, 0, innerBorder.Left, comboBox.Height);
                Rectangle rightOwnerDrawArea = new Rectangle(innerBorder.Right, 0, comboBox.Width - innerBorder.Right, comboBox.Height);

                if (topOwnerDrawArea.IntersectsWith(updateRegionBox))
                {
                    validRect = new RECT(topOwnerDrawArea);
                    SafeNativeMethods.ValidateRect(new HandleRef(comboBox, comboBox.Handle), ref validRect);
                }

                if (bottomOwnerDrawArea.IntersectsWith(updateRegionBox))
                {
                    validRect = new RECT(bottomOwnerDrawArea);
                    SafeNativeMethods.ValidateRect(new HandleRef(comboBox, comboBox.Handle), ref validRect);
                }

                if (leftOwnerDrawArea.IntersectsWith(updateRegionBox))
                {
                    validRect = new RECT(leftOwnerDrawArea);
                    SafeNativeMethods.ValidateRect(new HandleRef(comboBox, comboBox.Handle), ref validRect);
                }

                if (rightOwnerDrawArea.IntersectsWith(updateRegionBox))
                {
                    validRect = new RECT(rightOwnerDrawArea);
                    SafeNativeMethods.ValidateRect(new HandleRef(comboBox, comboBox.Handle), ref validRect);
                }
            }
        }
    }
}
