﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.Monitoring.Common.StateData;
using Confirmit.CATI.MonitoringConsole.Classes.EvenSources;

namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    public class AnsweredQuestionsProvider
    {
        private readonly StateEventInfo[] _events;

        public AnsweredQuestionsProvider(StateEventInfo[] events)
        {
            _events = events;
        }

        public IEnumerable<AnsweredQuestion> GetAllQuestions()
        {
            CheckEvents();

            var result = new List<AnsweredQuestion>();

            var interviewStartEvent = DeferredEventHelper.GetInterviewStartEvent(_events);
            var interviewStartTime = interviewStartEvent.TimeStamp;

            result.Add(new AnsweredQuestion(interviewStartEvent)
            {
                Id = "start",
                Time = interviewStartTime,
                Offset = TimeSpan.Zero,
                QuestionTitle = string.Empty,
                QuestionText = string.Empty,
                IndexOfEvent = Array.IndexOf(_events, interviewStartEvent)
            });

            var questionSelectedEvents = DeferredEventHelper.GetQuestionStartEvents(_events);

            foreach (var monitoringEvent in questionSelectedEvents)
            {
                var stateData = (QuestionSelectedStateData)(new EventInfo(monitoringEvent)).State;

                if (IsQuestionSupported(stateData) == false) continue;

                var answeredQuestion = new AnsweredQuestion(interviewStartEvent)
                {
                    Id = stateData.QuestionId,
                    Time = monitoringEvent.TimeStamp,
                    Offset = monitoringEvent.TimeStamp - interviewStartTime,
                    QuestionTitle = stateData.QuestionTitle,
                    QuestionText = stateData.QuestionText,
                    IndexOfEvent = Array.IndexOf(_events, monitoringEvent)
                };

                answeredQuestion.IndexOfEventContentLoad = DeferredEventHelper.GetQuestionLoadContentEventIndex(_events, answeredQuestion.IndexOfEvent);

                result.Add(answeredQuestion);
            }

            return result;
        }

        public static bool IsQuestionSupported(QuestionSelectedStateData stateData)
        {
            if (stateData.IsSubQuestion) return false;
            if (stateData.QuestionType == (int)QuestionType.Info) return false;

            return true;
        }

        private void CheckEvents()
        {
            if (_events.All(x => x.MessageType != MonitoringMessageTypes.InterviewStartMessage))
            {
                throw new InvalidOperationException("Deffered record doesn't contain InterviewStartMessage event");
            }
        }
    }
}
