﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.Versioning;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion
{
    [ToolStripItemDesignerAvailability(
        ToolStripItemDesignerAvailability.MenuStrip | ToolStripItemDesignerAvailability.ToolStrip |
        ToolStripItemDesignerAvailability.ContextMenuStrip)]
    [DefaultProperty("Items")]
    public class CustomToolStripComboBox : ToolStripControlHost
    {
        internal static readonly object EventDropDown = new object();
        internal static readonly object EventDropDownClosed = new object();
        internal static readonly object EventDropDownStyleChanged = new object();
        internal static readonly object EventSelectedIndexChanged = new object();
        internal static readonly object EventSelectionChangeCommitted = new object();
        internal static readonly object EventTextUpdate = new object();

        public CustomToolStripComboBox()
            : base(CreateControlInstance())
        {
            var combo = Control as ToolStripComboBoxControl;
            combo.Owner = this;
        }

        public CustomToolStripComboBox(string name)
            : this()
        {
            Name = name;
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        public CustomToolStripComboBox(Control c)
            : base(c)
        {
        }

        internal ToolStripRenderer Renderer
        {
            get
            {
                if (Owner != null)
                {
                    return Owner.Renderer;
                }
                return (Parent != null) ? Parent.Renderer : null;
            }
        }

        [
            DesignerSerializationVisibility(DesignerSerializationVisibility.Content),
            Localizable(true),
            Browsable(true), EditorBrowsable(EditorBrowsableState.Always)
        ]
        public AutoCompleteStringCollection AutoCompleteCustomSource
        {
            get { return ComboBox.AutoCompleteCustomSource; }
            set { ComboBox.AutoCompleteCustomSource = value; }
        }

        [DefaultValue(AutoCompleteMode.None), Browsable(true), EditorBrowsable(EditorBrowsableState.Always)]
        public AutoCompleteMode AutoCompleteMode
        {
            get { return ComboBox.AutoCompleteMode; }
            set { ComboBox.AutoCompleteMode = value; }
        }

        [
            DefaultValue(AutoCompleteSource.None),
            Browsable(true), EditorBrowsable(EditorBrowsableState.Always)
        ]
        public AutoCompleteSource AutoCompleteSource
        {
            get { return ComboBox.AutoCompleteSource; }
            set { ComboBox.AutoCompleteSource = value; }
        }

        [
            Browsable(false),
            EditorBrowsable(EditorBrowsableState.Never),
            DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        ]
        public override Image BackgroundImage
        {
            get { return base.BackgroundImage; }
            set { base.BackgroundImage = value; }
        }

        [
            Browsable(false),
            EditorBrowsable(EditorBrowsableState.Never),
            DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)
        ]
        public override ImageLayout BackgroundImageLayout
        {
            get { return base.BackgroundImageLayout; }
            set { base.BackgroundImageLayout = value; }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ComboBox ComboBox
        {
            get { return Control as ComboBox; }
        }

        protected override Size DefaultSize
        {
            get { return new Size(100, 22); }
        }

        protected override Padding DefaultMargin
        {
            get
            {
                if (IsOnDropDown)
                {
                    return new Padding(2);
                }
                return new Padding(1, 0, 1, 0);
            }
        }

        [
            Browsable(true), EditorBrowsable(EditorBrowsableState.Always),
            DefaultValue(106)
        ]
        public int DropDownHeight
        {
            get { return ComboBox.DropDownHeight; }
            set { ComboBox.DropDownHeight = value; }
        }

        [
            DefaultValue(ComboBoxStyle.DropDown),
            RefreshProperties(RefreshProperties.Repaint)
        ]
        public ComboBoxStyle DropDownStyle
        {
            get { return ComboBox.DropDownStyle; }
            set { ComboBox.DropDownStyle = value; }
        }

        public int DropDownWidth
        {
            get { return ComboBox.DropDownWidth; }
            set { ComboBox.DropDownWidth = value; }
        }

        [
            Browsable(false),
            DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        ]
        public bool DroppedDown
        {
            get { return ComboBox.DroppedDown; }
            set { ComboBox.DroppedDown = value; }
        }

        [
            DefaultValue(FlatStyle.Popup),
            Localizable(true),
        ]
        public FlatStyle FlatStyle
        {
            get { return ComboBox.FlatStyle; }
            set { ComboBox.FlatStyle = value; }
        }

        [
            DefaultValue(true),
            Localizable(true),
        ]
        public bool IntegralHeight
        {
            get { return ComboBox.IntegralHeight; }
            set { ComboBox.IntegralHeight = value; }
        }

        /// Collection of the items contained in this ComboBox.
        [
            DesignerSerializationVisibility(DesignerSerializationVisibility.Content),
            Localizable(true),
        ]
        public ComboBox.ObjectCollection Items
        {
            get { return ComboBox.Items; }
        }

        [
            DefaultValue(8),
            Localizable(true),
        ]
        public int MaxDropDownItems
        {
            get { return ComboBox.MaxDropDownItems; }
            set { ComboBox.MaxDropDownItems = value; }
        }

        [
            DefaultValue(0),
            Localizable(true),
        ]
        public int MaxLength
        {
            get { return ComboBox.MaxLength; }
            set { ComboBox.MaxLength = value; }
        }

        [
            Browsable(false),
            DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        ]
        public int SelectedIndex
        {
            get { return ComboBox.SelectedIndex; }
            set { ComboBox.SelectedIndex = value; }
        }

        [
            Browsable(false),
            Bindable(true),
            DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        ]
        public object SelectedItem
        {
            get { return ComboBox.SelectedItem; }
            set { ComboBox.SelectedItem = value; }
        }

        [
            Browsable(false),
            DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        ]
        public string SelectedText
        {
            get { return ComboBox.SelectedText; }
            set { ComboBox.SelectedText = value; }
        }

        [
            Browsable(false),
            DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        ]
        public int SelectionLength
        {
            get { return ComboBox.SelectionLength; }
            set { ComboBox.SelectionLength = value; }
        }

        [
            Browsable(false),
            DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        ]
        public int SelectionStart
        {
            get { return ComboBox.SelectionStart; }
            set { ComboBox.SelectionStart = value; }
        }

        [DefaultValue(false)]
        public bool Sorted
        {
            get { return ComboBox.Sorted; }
            set { ComboBox.Sorted = value; }
        }

        private static Control CreateControlInstance()
        {
            var comboBox = new ToolStripComboBoxControl();
            comboBox.FlatStyle = FlatStyle.Popup;
            comboBox.Font = CustomComboBoxDrawingFunctions.DefaultFont;
            return comboBox;
        }

        [
            Browsable(false),
            EditorBrowsable(EditorBrowsableState.Never)
        ]
        public new event EventHandler DoubleClick
        {
            add { base.DoubleClick += value; }
            remove { base.DoubleClick -= value; }
        }

        public event EventHandler DropDown
        {
            add { Events.AddHandler(EventDropDown, value); }
            remove { Events.RemoveHandler(EventDropDown, value); }
        }

        public event EventHandler DropDownClosed
        {
            add { Events.AddHandler(EventDropDownClosed, value); }
            remove { Events.RemoveHandler(EventDropDownClosed, value); }
        }

        public event EventHandler DropDownStyleChanged
        {
            add { Events.AddHandler(EventDropDownStyleChanged, value); }
            remove { Events.RemoveHandler(EventDropDownStyleChanged, value); }
        }

        public event EventHandler SelectedIndexChanged
        {
            add { Events.AddHandler(EventSelectedIndexChanged, value); }
            remove { Events.RemoveHandler(EventSelectedIndexChanged, value); }
        }

        public event EventHandler TextUpdate
        {
            add { Events.AddHandler(EventTextUpdate, value); }
            remove { Events.RemoveHandler(EventTextUpdate, value); }
        }

        public override Size GetPreferredSize(Size constrainingSize)
        {
            Size preferredSize = base.GetPreferredSize(constrainingSize);
            preferredSize.Width = Math.Max(preferredSize.Width, 75);

            return preferredSize;
        }

        private void HandleDropDown(object sender, EventArgs e)
        {
            OnDropDown(e);
        }

        private void HandleDropDownClosed(object sender, EventArgs e)
        {
            OnDropDownClosed(e);
        }

        private void HandleDropDownStyleChanged(object sender, EventArgs e)
        {
            OnDropDownStyleChanged(e);
        }

        private void HandleSelectedIndexChanged(object sender, EventArgs e)
        {
            OnSelectedIndexChanged(e);
        }

        private void HandleSelectionChangeCommitted(object sender, EventArgs e)
        {
            OnSelectionChangeCommitted(e);
        }

        private void HandleTextUpdate(object sender, EventArgs e)
        {
            OnTextUpdate(e);
        }

        protected virtual void OnDropDown(EventArgs e)
        {
            RaiseEvent(EventDropDown, e);
        }

        protected virtual void OnDropDownClosed(EventArgs e)
        {
            RaiseEvent(EventDropDownClosed, e);
        }

        internal void RaiseEvent(object key, EventArgs e)
        {
            var handler = (EventHandler)Events[key];
            if (handler != null) handler(this, e);
        }

        protected virtual void OnDropDownStyleChanged(EventArgs e)
        {
            RaiseEvent(EventDropDownStyleChanged, e);
        }

        protected virtual void OnSelectedIndexChanged(EventArgs e)
        {
            RaiseEvent(EventSelectedIndexChanged, e);
        }

        protected virtual void OnSelectionChangeCommitted(EventArgs e)
        {
            RaiseEvent(EventSelectionChangeCommitted, e);
        }

        /// 
        protected virtual void OnTextUpdate(EventArgs e)
        {
            RaiseEvent(EventTextUpdate, e);
        }

        protected override void OnSubscribeControlEvents(Control control)
        {
            var comboBox = control as ComboBox;
            if (comboBox != null)
            {
                // Please keep this alphabetized and in [....] with Unsubscribe
                // 
                comboBox.DropDown += HandleDropDown;
                comboBox.DropDownClosed += HandleDropDownClosed;
                comboBox.DropDownStyleChanged += HandleDropDownStyleChanged;
                comboBox.SelectedIndexChanged += HandleSelectedIndexChanged;
                comboBox.SelectionChangeCommitted += HandleSelectionChangeCommitted;
                comboBox.TextUpdate += HandleTextUpdate;
            }

            base.OnSubscribeControlEvents(control);
        }

        protected override void OnUnsubscribeControlEvents(Control control)
        {
            var comboBox = control as ComboBox;
            if (comboBox != null)
            {
                // Please keep this alphabetized and in [....] with Unsubscribe
                // 
                comboBox.DropDown -= HandleDropDown;
                comboBox.DropDownClosed -= HandleDropDownClosed;
                comboBox.DropDownStyleChanged -= HandleDropDownStyleChanged;
                comboBox.SelectedIndexChanged -= HandleSelectedIndexChanged;
                comboBox.SelectionChangeCommitted -= HandleSelectionChangeCommitted;
                comboBox.TextUpdate -= HandleTextUpdate;
            }
            base.OnUnsubscribeControlEvents(control);
        }

        public override string ToString()
        {
            return base.ToString() + ", Items.Count: " + Items.Count.ToString(CultureInfo.CurrentCulture);
        }

        public void UpdateDropDownHeight()
        {
            var toolStripComboBox = Control as ToolStripComboBoxControl;
            toolStripComboBox.UpdateDropDownHeight();
        }

        #region WrappedMethods

        public void BeginUpdate()
        {
            ComboBox.BeginUpdate();
        }

        public void EndUpdate()
        {
            ComboBox.EndUpdate();
        }

        public int FindString(string s)
        {
            return ComboBox.FindString(s);
        }

        public int FindString(string s, int startIndex)
        {
            return ComboBox.FindString(s, startIndex);
        }

        public int FindStringExact(string s)
        {
            return ComboBox.FindStringExact(s);
        }

        public int FindStringExact(string s, int startIndex)
        {
            return ComboBox.FindStringExact(s, startIndex);
        }

        public int GetItemHeight(int index)
        {
            return ComboBox.GetItemHeight(index);
        }

        public void Select(int start, int length)
        {
            ComboBox.Select(start, length);
        }

        public void SelectAll()
        {
            ComboBox.SelectAll();
        }

        #endregion WrappedMethods

        internal class ToolStripComboBoxControl : CustomComboBox
        {
            public ToolStripComboBoxControl()
            {
                Owner = null;
                FlatStyle = FlatStyle.Popup;
                SetStyle(ControlStyles.ResizeRedraw | ControlStyles.OptimizedDoubleBuffer, true);
            }

            public CustomToolStripComboBox Owner { get; set; }

            private ProfessionalColorTable ColorTable
            {
                get
                {
                    if (Owner != null)
                    {
                        var renderer = Owner.Renderer as ToolStripProfessionalRenderer;
                        if (renderer != null)
                        {
                            return renderer.ColorTable;
                        }
                    }
                    return CustomComboBoxDrawingFunctions.ColorTable;
                }
            }

            internal override FlatComboAdapter CreateFlatComboAdapterInstance()
            {
                return new ToolStripComboBoxFlatComboAdapter(this);
            }

            protected override bool IsInputKey(Keys keyData)
            {
                if ((keyData & Keys.Alt) == Keys.Alt)
                {
                    if ((keyData & Keys.Down) == Keys.Down || (keyData & Keys.Up) == Keys.Up)
                    {
                        return true;
                    }
                }
                return base.IsInputKey(keyData);
            }


            protected override void OnDropDownClosed(EventArgs e)
            {
                base.OnDropDownClosed(e);
                Invalidate();
                Update();
            }

            internal class ToolStripComboBoxFlatComboAdapter : FlatComboAdapter
            {
                public ToolStripComboBoxFlatComboAdapter(CustomComboBox comboBox)
                    : base(comboBox, /*smallButton=*/true)
                {
                }

                private static bool UseBaseAdapter(CustomComboBox comboBox)
                {
                    var toolStripComboBox = comboBox as ToolStripComboBoxControl;
                    if (toolStripComboBox == null ||
                        !(toolStripComboBox.Owner.Renderer is ToolStripProfessionalRenderer))
                    {
                        Debug.Assert(toolStripComboBox != null, "Why are we here and not a toolstrip combo?");
                        return true;
                    }
                    return false;
                }

                private static ProfessionalColorTable GetColorTable(ToolStripComboBoxControl toolStripComboBoxControl)
                {
                    if (toolStripComboBoxControl != null)
                    {
                        return toolStripComboBoxControl.ColorTable;
                    }
                    return CustomComboBoxDrawingFunctions.ColorTable;
                }

                protected override Color GetOuterBorderColor(CustomComboBox comboBox)
                {
                    if (UseBaseAdapter(comboBox))
                    {
                        return base.GetOuterBorderColor(comboBox);
                    }
                    return (comboBox.Enabled)
                        ? SystemColors.Window
                        : GetColorTable(comboBox as ToolStripComboBoxControl).ButtonSelectedHighlightBorder;
                }

                protected override Color GetPopupOuterBorderColor(CustomComboBox comboBox, bool focused)
                {
                    if (UseBaseAdapter(comboBox))
                    {
                        return base.GetPopupOuterBorderColor(comboBox, focused);
                    }
                    if (!comboBox.Enabled)
                    {
                        return SystemColors.ControlDark;
                    }
                    return (focused)
                        ? GetColorTable(comboBox as ToolStripComboBoxControl).ButtonSelectedHighlightBorder
                        : SystemColors.Window;
                }

                protected override void DrawFlatComboDropDown(CustomComboBox comboBox, Graphics g, Rectangle dropDownRect)
                {
                    if (UseBaseAdapter(comboBox))
                    {
                        base.DrawFlatComboDropDown(comboBox, g, dropDownRect);
                        return;
                    }

                    if (!comboBox.Enabled || !ToolStripManager.VisualStylesEnabled)
                    {
                        g.FillRectangle(SystemBrushes.Control, dropDownRect);
                    }
                    else
                    {
                        var toolStripComboBox = comboBox as ToolStripComboBoxControl;
                        ProfessionalColorTable colorTable = GetColorTable(toolStripComboBox);

                        if (!comboBox.DroppedDown)
                        {
                            bool focused = comboBox.ContainsFocus || comboBox.MouseIsOver;
                            if (focused)
                            {
                                using (
                                    Brush b = new LinearGradientBrush(dropDownRect,
                                        colorTable.MenuItemSelectedGradientBegin, colorTable.MenuItemSelectedGradientEnd,
                                        LinearGradientMode.Vertical))
                                {
                                    g.FillRectangle(b, dropDownRect);
                                }
                            }
                            else if (toolStripComboBox.Owner.IsOnOverflow)
                            {
                                using (Brush b = new SolidBrush(colorTable.ToolStripDropDownBackground))
                                {
                                    g.FillRectangle(b, dropDownRect);
                                }
                            }
                            else
                            {
                                using (
                                    Brush b = new LinearGradientBrush(dropDownRect,
                                        colorTable.MenuItemPressedGradientBegin,
                                        colorTable.MenuItemPressedGradientEnd, LinearGradientMode.Vertical))
                                {
                                    g.FillRectangle(b, dropDownRect);
                                }
                            }
                        }
                        else
                        {
                            using (
                                Brush b = new LinearGradientBrush(dropDownRect,
                                    colorTable.ButtonPressedGradientBegin,
                                    colorTable.ButtonPressedGradientEnd, LinearGradientMode.Vertical))
                            {
                                g.FillRectangle(b, dropDownRect);
                            }
                        }
                    }

                    Brush brush = (comboBox.Enabled) ? SystemBrushes.ControlText : SystemBrushes.GrayText;
                    var middle = new Point(dropDownRect.Left + dropDownRect.Width / 2,
                        dropDownRect.Top + dropDownRect.Height / 2);

                    // if the width is odd - favor pushing it over one pixel right.
                    middle.X += (dropDownRect.Width % 2);
                    g.FillPolygon(brush, new[]
                    {
                        new Point(middle.X - 2, middle.Y - 1), new Point(middle.X + 3, middle.Y - 1),
                        new Point(middle.X, middle.Y + 2)
                    });
                }
            }
        }
    }
}