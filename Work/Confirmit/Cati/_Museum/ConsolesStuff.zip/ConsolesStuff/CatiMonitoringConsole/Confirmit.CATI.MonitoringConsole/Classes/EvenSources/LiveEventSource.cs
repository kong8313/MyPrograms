﻿using System;
using System.Linq;
using System.Threading;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.Resources;
using System.Collections.Generic;
using System.Threading.Tasks;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.MonitoringConsole.Classes.EvenSources
{
    /// <summary>
    /// Represents live monitoring events source. 
    /// </summary>
    public class LiveEventSource : EventSource
    {
        private readonly EventReceiver m_EventReceiver = null;
        private Thread m_PlayThread = null;
        private readonly ManualResetEvent _shutdownEvent = new ManualResetEvent(false);

        public LiveEventSource()
        {
            m_EventReceiver = new EventReceiver();
        }

        /// <summary>
        /// Starts process of getting monitoring events.
        /// </summary>
        public override Task Start()
        {
            if (m_EventReceiver == null)
            {
                throw new InvalidOperationException(Strings.Error_ReceiverInvalidState);
            }

            InitPlayerThread();

            return Task.CompletedTask;
        }

        public override void Pause()
        {
            throw new NotSupportedException("Pause is not supported in Live monitoring");
        }

        public override void Resume()
        {
            throw new NotSupportedException("Resume is not supported in Live monitoring");
        }

        public override void JumpToMilestone(int pageCompletedEventIndex, int questionSelectedEventIndex)
        {
            throw new NotSupportedException("JumpToMilestone is not supported in Live monitoring");
        }

        public override void JumpToPositionInsideMilestone(TimeSpan newPosition)
        {
            throw new NotSupportedException("JumpToSecond is not supported in Live monitoring");
        }

        public override void UpdateAudioEventPosition(TimeSpan clientAudioShift)
        {
            throw new NotSupportedException("UpdateAudioEventPosition is not supported in Live monitoring");
        }

        public override void Stop()
        {
            _shutdownEvent.Set();
            m_PlayThread.Join();
        }

        public override void NotifyAudioDuration(AudioIdentityObject currentAudioRecordId, TimeSpan duration)
        {
            //do nothing
        }

        public override void NotifyAudioFinished()
        {
            //do nothing
        }

        /// <summary>
        /// Initialiazes thread which will be used for playing events gotten
        /// from Monitoring service.
        /// </summary>
        private void InitPlayerThread()
        {
            m_PlayThread = new Thread(() =>
            {
                try
                {
                    PlayEvents();
                }
                catch (Exception ex)
                {
                    Logger.Write(ex, MessageTypes.Error);
                }
            });

            m_PlayThread.IsBackground = true;
            m_PlayThread.Start();
        }

        /// <summary>
        /// Method continually tryes get events from EventReceiver queue. 
        /// If there are events in queue it copy them into local EventInfo array.
        /// After it generates GetEvents event with given monitoring events.
        /// </summary>
        private void PlayEvents()
        {
            List<EventInfo> events;

            while (true)
            {
                var waitResult = WaitHandle.WaitAny(
                                new WaitHandle[] { m_EventReceiver.ObjectEnqueued, _shutdownEvent },
                                Timeout.Infinite);

                if (waitResult == 1)
                {
                    m_EventReceiver.Dispose();
                    return;
                }

                lock (m_EventReceiver.EventsQueue)
                {
                    events = m_EventReceiver.EventsQueue.ToList<EventInfo>();
                    m_EventReceiver.EventsQueue.Clear();
                }
                lock (m_EventReceiver.ObjectEnqueued)
                {
                    m_EventReceiver.ObjectEnqueued.Reset();
                }

                OnGetEvents(new GetEventsEventArgs() { Events = events.ToArray() });
            }
        }
    }
}
