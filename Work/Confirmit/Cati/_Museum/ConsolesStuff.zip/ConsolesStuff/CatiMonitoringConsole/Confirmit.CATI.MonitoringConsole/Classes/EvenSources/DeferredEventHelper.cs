﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Monitoring.Common.Contracts;

namespace Confirmit.CATI.MonitoringConsole.Classes.EvenSources
{
    public static class DeferredEventHelper
    {
        public static int GetMilestoneFinishEventIndex(StateEventInfo[] events, int milestoneEventIndex)
        {
            var eventInfo = events[milestoneEventIndex];

            if (!eventInfo.MessageType.IsMilestoneStartMessage())
                throw new Exception($"Wrong milestone message type: {eventInfo.MessageType}");

            var nextMilestoneIndex = GetNextMilestoneEventIndex(events, milestoneEventIndex);
            nextMilestoneIndex = nextMilestoneIndex < 0 ? int.MaxValue : nextMilestoneIndex;

            var interviewFinishIndex = GetInterviewFinishEventIndex(events, milestoneEventIndex);
            interviewFinishIndex = interviewFinishIndex < 0 ? int.MaxValue : interviewFinishIndex;

            var lastPageCompleteBeforeNext =
                GetLastPageCompleteBeforeNextEventIndex(events, milestoneEventIndex,
                    Math.Min(nextMilestoneIndex, interviewFinishIndex));

            if (lastPageCompleteBeforeNext >= 0)
                return Math.Min(lastPageCompleteBeforeNext,
                    Math.Min(nextMilestoneIndex, interviewFinishIndex));

            int milestoneFinishEventIndex;
            if (eventInfo.MessageType.IsInterviewStartMessage())
            {
                milestoneFinishEventIndex = Math.Min(nextMilestoneIndex, interviewFinishIndex);
            }
            else if (eventInfo.MessageType.IsQuestionStartMessage())
            {
                var nextPageComplete = GetNextPageCompleteEventIndex(events, milestoneEventIndex);
                nextPageComplete = nextPageComplete < 0 ? int.MaxValue : nextPageComplete;
                milestoneFinishEventIndex = Math.Min(nextPageComplete, interviewFinishIndex);
            }
            else
            {
                throw new Exception($"Unknown milestone start message type: {eventInfo.MessageType}");
            }

            return milestoneFinishEventIndex;
        }

        public static TimeSpan GetMilestoneDuration(StateEventInfo[] events, int milestoneEventIndex, int milestoneFinishEventIndex)
        {
            var eventInfo = events[milestoneEventIndex];

            var finishEvent =
                milestoneFinishEventIndex >= milestoneEventIndex && milestoneFinishEventIndex < events.Length
                    ? events[milestoneFinishEventIndex]
                    : null;

            if (finishEvent == null)
                throw new Exception($"Can't found milestone finish event: {eventInfo}");

            return finishEvent.TimeStamp - eventInfo.TimeStamp;
        }

        private static int GetLastPageCompleteBeforeNextEventIndex(StateEventInfo[] events, int milestoneEventIndex, int nextMilestoneIndex)
        {
            for (var i = nextMilestoneIndex - 1; i > milestoneEventIndex; i--)
                if (events[i].MessageType.IsPageCompleteMessage())
                    return i;

            return -1;
        }

        public static int GetNextPageCompleteEventIndex(StateEventInfo[] events, int milestoneEventIndex)
        {
            for (var i = milestoneEventIndex + 1; i < events.Length; i++)
                if (events[i].MessageType.IsPageCompleteMessage())
                    return i;

            return -1;
        }

        public static int GetPrevMilestoneEventIndex(StateEventInfo[] events, int milestoneEventIndex)
        {
            for (var i = milestoneEventIndex - 1; i >= 0; i--)
                if (events[i].MessageType.IsMilestoneStartMessage())
                    return i;

            return -1;
        }

        public static int GetNextMilestoneEventIndex(StateEventInfo[] events, int milestoneEventIndex)
        {
            for (var i = milestoneEventIndex + 1; i < events.Length; i++)
                if (events[i].MessageType.IsMilestoneStartMessage())
                    return i;

            return -1;
        }

        public static int GetInterviewFinishEventIndex(StateEventInfo[] events, int milestoneEventIndex)
        {
            for (var i = milestoneEventIndex + 1; i < events.Length; i++)
                if (events[i].MessageType.IsInterviewFinishMessage())
                    return i;

            return events.Length - 1;
        }

        public static int GetMilestoneLoadContentEventIndex(StateEventInfo[] events, int milestoneEventIndex)
        {
            for (var i = milestoneEventIndex; i >= 0; i--)
                if (events[i].MessageType.IsMilestoneLoadContentMessage())
                    return i;

            return -1;
        }

        public static StateEventInfo GetInterviewStartEvent(StateEventInfo[] events)
        {
            return events.First(x => x.MessageType.IsInterviewStartMessage());
        }

        public static IEnumerable<StateEventInfo> GetQuestionStartEvents(StateEventInfo[] events)
        {
            return events.Where(x => x.MessageType.IsQuestionStartMessage());
        }

        public static int GetQuestionLoadContentEventIndex(StateEventInfo[] events, int questionEventIndex)
        {
            for (var i = questionEventIndex; i >= 0; i--)
                if (events[i].MessageType.IsQuestionLoadContentMessage())
                    return i;

            return -1;
        }

    }
}