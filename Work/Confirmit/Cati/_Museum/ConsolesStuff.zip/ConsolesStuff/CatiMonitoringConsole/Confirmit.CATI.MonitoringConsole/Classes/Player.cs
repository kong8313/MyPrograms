﻿using System;
using System.Collections.Generic;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Resources;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.Monitoring.Common.StateData;
using Confirmit.CATI.MonitoringConsole.Classes.EvenSources;
using Confirmit.CATI.MonitoringConsole.Presenters;
using Confirmit.CATI.MonitoringConsole.Resources;

namespace Confirmit.CATI.MonitoringConsole.Classes
{
    /// <summary>
    /// Class is responsible for playing events
    /// </summary>
    internal class Player
    {
        #region Constructors

        /// <summary>
        /// Player constructor
        /// </summary>
        /// <param name="presenterMainForm"></param>
        /// <param name="presenterInterview">It is responsible for playing events on InteviewPageBrowser view</param>
        /// <param name="presenterAppointment">It is responsible for playing events on AppointmentForm view</param>
        /// <param name="presenterRedial"></param>
        /// <param name="eventSource">Monitoring events source object.</param>
        public Player(
            PresenterMainForm presenterMainForm, 
            PresenterInterview presenterInterview, 
            PresenterAppointment presenterAppointment,
            PresenterRedial presenterRedial,
            EventSource eventSource)
        {
            PresenterMainForm = presenterMainForm;
            PresenterInterview = presenterInterview;
            PresenterAppointment = presenterAppointment;
            PresenterRedial = presenterRedial;
            EventSource = eventSource;
            EventSource.GetEvents += EventSource_GetEvents;
            EventSource.NotifyPosition += EventSource_NotifyQuestionPosition;
            EventSource.Paused += EventSource_Paused;
        }

        private void EventSource_NotifyQuestionPosition(object sender, NotifyMilestonePositionEventArgs e)
        {
            PresenterMainForm.NotifyMilestonePosition(e.Elapsed);
        }

        private void EventSource_Paused(object sender, EventArgs e)
        {
            PresenterMainForm.NotifyPaused();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets/sets MainForm presenter.
        /// </summary>
        protected PresenterMainForm PresenterMainForm
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets/sets InterviewPageBrowser presenter.
        /// </summary>
        protected PresenterInterview PresenterInterview
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets/sets AppointementForm presenter.
        /// </summary>
        protected PresenterAppointment PresenterAppointment
        {
            get;
            private set;
        }

        protected PresenterRedial PresenterRedial
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets/sets monitoring events source.
        /// </summary>
        protected EventSource EventSource
        {
            get;
            private set;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Begin event receiving and event playing
        /// </summary>
        public void Start()
        {
            EventSource.Start();
        }

        public void Pause()
        {
            EventSource.Pause();
        }

        public void Stop()
        {
            EventSource.Stop();
        }

        public void Resume()
        {
            EventSource.Resume();
        }

        public void UpdateAudioEventPosition(TimeSpan clientAudioShift)
        {
            EventSource.UpdateAudioEventPosition(clientAudioShift);
        }

        public void JumpToQuestion(int eventIndex, int questionSelectedEventIndex)
        {
            EventSource.JumpToMilestone(eventIndex, questionSelectedEventIndex);
        }

        public void JumpToPosition(TimeSpan newPosition)
        {   
            EventSource.JumpToPositionInsideMilestone(newPosition);
        }

        /// <summary>
        /// Handles EventSource.GetEvents event.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        void EventSource_GetEvents(object sender, GetEventsEventArgs e)
        {
            PlayBackEvents(e.Events);
        }

        /// <summary>
        /// Method plays passed events on views
        /// </summary>
        private void PlayBackEvents(IEnumerable<EventInfo> events)
        {
            foreach (EventInfo ev in events)
            {
                PlayBackEvent(ev);
            }
        }

        /// <summary>
        /// Plays specific event
        /// </summary>
        /// <param name="ev"></param>
        private void PlayBackEvent(EventInfo ev)
        {
            switch (ev.MessageType)
            {
                case MonitoringMessageTypes.MonitoringInitialMessage:
                    var state = (MonitoringInitialStateData)ev.State;

                    if (state.ConsoleState == ConsoleState.InterviewerOnABreak)
                    {
                        PresenterMainForm.PlayEvent(CreateMonitoringInitialEvent(MonitoringMessageTypes.OnABreakDialogShownMessage, state.OnABreakControlState, ev.TimeStamp));
                    }
                    else
                    {
                        InitInterviewInfo(state.InterviewBrowserState);

                        PresenterMainForm.PlayEvent(CreateMonitoringInitialEvent(MonitoringMessageTypes.InterviewInitialMessage, state.InterviewBrowserState, ev.TimeStamp));
                        PresenterInterview.PlayEvent(MonitoringMessageTypes.InterviewInitialMessage, state.InterviewBrowserState);
                        PresenterAppointment.PlayEvent(MonitoringMessageTypes.AppointmentFormInitialMessage, state.AppointmentFormState);
                    }

                    break;
                case MonitoringMessageTypes.InterviewInitialMessage:
                    InitInterviewInfo(ev.State);
                    PresenterMainForm.PlayEvent(ev);
                    PresenterInterview.PlayEvent(ev.MessageType, ev.State);
                    break;
                case MonitoringMessageTypes.InterviewFinishMessage:
                    ResetInterviewInfo();
                    PresenterMainForm.PlayEvent(ev);
                    PresenterInterview.PlayEvent(ev.MessageType, ev.State);
                    break;
                case MonitoringMessageTypes.InterviewerLoggedOutMessage:
                    PresenterMainForm.PlayEvent(ev);
                    PresenterInterview.PlayEvent(ev.MessageType, ev.State);
                    break;
                case MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage:
                    PresenterMainForm.PlayEvent(ev);
                    PresenterInterview.PlayEvent(ev.MessageType, ev.State);
                    break;
                case MonitoringMessageTypes.InterviewPageBrowserAnswerValueChangedMessage:
                case MonitoringMessageTypes.InterviewPageBrowserProcessKeyboardInputMessage:
                case MonitoringMessageTypes.InterviewPageBrowserKeyboardInputControlValueChangedMessage:
                case MonitoringMessageTypes.InterviewPageBrowserPagePartiallyChangedMessage:
                case MonitoringMessageTypes.SetDefaultAnswerMessage:
                case MonitoringMessageTypes.SetRefusedAnswerMessage:
                case MonitoringMessageTypes.InterviewPageBrowserResponsiveQuestionChangedMessage:
                    PresenterInterview.PlayEvent(ev.MessageType, ev.State);
                    break;
                case MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage:
                    PresenterInterview.PlayEvent(ev.MessageType, ev.State);
                    // Needs refactoring!
                    if (EventSource is DeferredEventSource)
                    {
                        PresenterMainForm.PlayEvent(ev);
                    }
                    break;
                case MonitoringMessageTypes.AppointmentFormInitialMessage:
                case MonitoringMessageTypes.AppointmentFormNameChangedMessage:
                case MonitoringMessageTypes.AppointmentFormAppointmentDateChangedMessage:
                case MonitoringMessageTypes.AppointmentFormAppointmentTimeChangedMessage:
                case MonitoringMessageTypes.AppointmentFormExpirationDateChangedMessage:
                case MonitoringMessageTypes.AppointmentFormExpirationTimeChangedMessage:
                case MonitoringMessageTypes.AppointmentFormExpireChangedMessage:
                case MonitoringMessageTypes.AppointmentFormLogoutChangedMessage:
                case MonitoringMessageTypes.AppointmentFormAllowAppointmentsOutsideShiftChangedMessage:
                case MonitoringMessageTypes.AppointmentFormCloseMessage:
                    PresenterAppointment.PlayEvent(ev.MessageType, ev.State);
                    break;
                case MonitoringMessageTypes.DialStartMessage:
                case MonitoringMessageTypes.HangupMessage:
                case MonitoringMessageTypes.TelephonyCompleteMessage:
                case MonitoringMessageTypes.SelectedSurveyLanguageChangedMessage:
                case MonitoringMessageTypes.RedoDropDownListOpenMessage:
                case MonitoringMessageTypes.RedoDropDownListCloseMessage:
                case MonitoringMessageTypes.InterviewTerminateDialogShownMessage:
                case MonitoringMessageTypes.InterviewTerminateDialogCloseMessage:
                case MonitoringMessageTypes.RedoQuestionMessage:
                case MonitoringMessageTypes.MonitoringEndMessage:
                case MonitoringMessageTypes.InterviewReviewStartMessage:
                case MonitoringMessageTypes.InterviewSelectingStartMessage:
                case MonitoringMessageTypes.GettingInterviewStartMessage:
                case MonitoringMessageTypes.PendingBreakMessage:
                case MonitoringMessageTypes.PendingLogoutMessage:
                case MonitoringMessageTypes.PendingLogoutStartMessage:
                case MonitoringMessageTypes.ShowInformationMessage:
                case MonitoringMessageTypes.MonitoringEndBySecurityExceptionMessage:
                case MonitoringMessageTypes.MonitoringEndBySecurityExceptionOnFirstRequestMessage:
                case MonitoringMessageTypes.AudioStartMessage:
                case MonitoringMessageTypes.AudioStopMessage:
                case MonitoringMessageTypes.AppointmentsListFormShownMessage:
                case MonitoringMessageTypes.AppointmentsListFormClosedMessage:
                case MonitoringMessageTypes.CheckSpellingFormShownMessage:
                case MonitoringMessageTypes.CheckSpellingFormClosedMessage:
                case MonitoringMessageTypes.OnABreakDialogShownMessage:
                case MonitoringMessageTypes.OnABreakDialogClosedMessage:
                case MonitoringMessageTypes.StartPlaybackMessage:
                case MonitoringMessageTypes.PauseOrResumePlaybackMessage:
                case MonitoringMessageTypes.StopPlaybackMessage:
                case MonitoringMessageTypes.ToggleInterviewerListensToPlaybackOrRespondentMessage:
                case MonitoringMessageTypes.BlankControlShownMessage:
                case MonitoringMessageTypes.InterviewPageBrowserShownMessage:
                case MonitoringMessageTypes.InternalCallTransferFormShownMessage:
                case MonitoringMessageTypes.InternalCallTransferFormClosedMessage:
                case MonitoringMessageTypes.ExternalCallTransferFormShownMessage:
                case MonitoringMessageTypes.ExternalCallTransferFormClosedMessage:                
                    PresenterMainForm.PlayEvent(ev);
                    break;
                case MonitoringMessageTypes.InterviewStartMessage:
                case MonitoringMessageTypes.MonitoringNotPermittedMessage:
                    /* It is sended on defered monitoring start only.*/
                    PresenterMainForm.PlayEvent(ev);
                    PresenterInterview.PlayEvent(ev.MessageType, ev.State);
                    break;
                case MonitoringMessageTypes.RedialFormInitialMessage:
                case MonitoringMessageTypes.RedialFormCloseMessage:
                case MonitoringMessageTypes.RedialFormDialCalledMessage:
                case MonitoringMessageTypes.RedialFormHangupDialCalledMessage:
                case MonitoringMessageTypes.RedialFormRedialTypeChangedMessage:
                case MonitoringMessageTypes.RedialFormDialNumberChangedMessage:
                case MonitoringMessageTypes.RedialFormTelephonyResultMessage:
                    PresenterRedial.PlayEvent(ev.MessageType, ev.State);
                    break;
                case MonitoringMessageTypes.ReturnToInitialQuestion:
                    PresenterMainForm.PlayEvent(ev);
                    break;
                default:
                    Logger.Write(
                        Strings.ResourceManager.GetString("Warning_UnsupportedEvent", ev.MessageType),
                        MessageTypes.Warning
                    );
                    break;
            }
        }

        private void InitInterviewInfo(BaseStateData stateData)
        {
            var interviewData = stateData as InterviewingInitialStateData;
            if (interviewData == null)
            {
                return;
            }
            UserPassport.Instance.InterviewInfo.Set(interviewData.SurveyId, interviewData.InterviewId);
        }

        private void ResetInterviewInfo()
        {
            UserPassport.Instance.InterviewInfo.Reset();
        }

        private EventInfo CreateMonitoringInitialEvent(MonitoringMessageTypes messageType, BaseStateData stateData, DateTime timeStamp)
        {
            return new EventInfo()
            {
                MessageType = messageType,
                State = stateData,
                TimeStamp = timeStamp
            };
        }

        /// <summary>
        /// Notify that audio has been opened and duration of audio calculated
        /// </summary>
        /// <param name="currentAudioRecordId">Index of audio event</param>
        /// <param name="duration">Audio duration</param>
        public void NotifyAudioDuration(AudioIdentityObject currentAudioRecordId, TimeSpan duration)
        {
            EventSource.NotifyAudioDuration(currentAudioRecordId, duration);
        }

        /// <summary>
        /// Notify about audio playback has been finished
        /// </summary>
        public void NotifyAudioFinished()
        {
            EventSource.NotifyAudioFinished();
        }

        #endregion
    }
}
