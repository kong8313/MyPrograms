﻿using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Common.Monitoring;
using Confirmit.CATI.MonitoringConsole.Classes.Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.MonitoringConsole.UnitTests
{
    [TestClass]
    public class OfflineMonitoringManagerTests
    {
        [TestMethod]
        public void UpdateLaunchInfo_HaveVideoFile_ReturnsLaunchInfoWithUpdatedVideoPath()
        {
            var launchInfo = new OfflineMonitoringLaunchInfo();
            var expectedLaunchInfo = new OfflineMonitoringLaunchInfo {VideoFilePath = @"c:\test.cce"};

            var manager = new OfflineMonitoringManager(launchInfo);
            var actualLaunchInfo = manager.UpdateLaunchInfo(@"c:\test.cce", ".cce", ".wav", ".xml");

            Assert.AreEqual(expectedLaunchInfo.VideoFilePath, actualLaunchInfo.VideoFilePath);
        }        

        [TestMethod]
        public void UpdateLaunchInfo_HaveAudioFile_ReturnsLaunchInfoWithUpdatedAudioPath()
        {
            var launchInfo = new OfflineMonitoringLaunchInfo();
            var expectedLaunchInfo = new OfflineMonitoringLaunchInfo { AudioFilesPaths = new List<string> { @"c:\test.wav" } };

            var manager = new OfflineMonitoringManager(launchInfo);
            var actualLaunchInfo = manager.UpdateLaunchInfo(@"c:\test.wav", ".cce", ".wav", ".xml");

            CollectionAssert.AreEqual(expectedLaunchInfo.AudioFilesPaths, actualLaunchInfo.AudioFilesPaths);
        }

        [TestMethod]
        public void GetAudioFiles_NoAudioFile_ReturnsEmptyCollection()
        {
            var launchInfo = new OfflineMonitoringLaunchInfo { VideoFilePath = @"c:\test.cce" };
            var manager = new OfflineMonitoringManager(launchInfo);

            Assert.IsFalse(manager.GetAudioFiles().Any());
        }

        [TestMethod]
        public void GetEvents_NoVideoFile_ReturnsEmptyCollection()
        {
            var launchInfo = new OfflineMonitoringLaunchInfo { AudioFilesPaths = new List<string> { @"c:\test.cca" } };
            var manager = new OfflineMonitoringManager(launchInfo);

            Assert.IsFalse(manager.GetEvents().Any());
        }
    }
}