using System;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.Monitoring.Common.Serialization;
using Confirmit.CATI.Monitoring.Common.StateData;

namespace Confirmit.CATI.MonitoringConsole.UnitTests
{
    public class TestEventsFactory
    {
        public static StateEventInfo CreateQuestionSelectedEvent(string questionId)
        {
            return CreateQuestionSelectedEvent(questionId, DateTime.Now);
        }

        public static StateEventInfo CreateQuestionSelectedEvent(string questionId, DateTime timeStamp)
        {
            return new StateEventInfo()
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage,
                TimeStamp = timeStamp,
                State =
                    SerializationManager.Serialize(
                        MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage,
                        new QuestionSelectedStateData()
                        {
                            QuestionId = questionId,
                            QuestionType = 2
                        })
            };
        }

        public static StateEventInfo CreateInterviewInitialEvent()
        {
            return new StateEventInfo()
            {
                MessageType = MonitoringMessageTypes.InterviewInitialMessage,
                TimeStamp = DateTime.Now,
                State =
                    SerializationManager.Serialize(
                        MonitoringMessageTypes.InterviewInitialMessage,
                        new InterviewingInitialStateData())
            };
        }

        public static StateEventInfo CreateInterviewInitialEvent(DateTime timeStamp)
        {
            return new StateEventInfo()
            {
                MessageType = MonitoringMessageTypes.InterviewInitialMessage,
                TimeStamp = timeStamp,
                State =
                    SerializationManager.Serialize(
                        MonitoringMessageTypes.InterviewInitialMessage,
                        new InterviewingInitialStateData())
            };
        }

        public static StateEventInfo CreateInterviewPageBrowserPageCompletedEvent()
        {
            return CreateInterviewPageBrowserPageCompletedEvent(DateTime.Now);
        }

        public static StateEventInfo CreateInterviewPageBrowserPageCompletedEvent(DateTime timeStamp)
        {
            return new StateEventInfo()
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage,
                TimeStamp = timeStamp,
                State =
                    SerializationManager.Serialize(
                        MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage,
                        new DocumentCompletedStateData())
            };
        }

        public static StateEventInfo CreateInterviewStartEvent()
        {
            return CreateInterviewStartEvent(DateTime.Now);
        }

        public static StateEventInfo CreateInterviewStartEvent(DateTime timeStamp)
        {
            return new StateEventInfo()
            {
                MessageType = MonitoringMessageTypes.InterviewStartMessage,
                TimeStamp = timeStamp,
                State =
                    SerializationManager.Serialize(
                        MonitoringMessageTypes.InterviewStartMessage,
                        new InterviewStartStateData())
            };
        }

        public static StateEventInfo CreateInterviewFinishEvent(DateTime timeStamp)
        {
            return new StateEventInfo
            {
                MessageType = MonitoringMessageTypes.InterviewFinishMessage,
                TimeStamp = timeStamp,
                State =
                    SerializationManager.Serialize(
                        MonitoringMessageTypes.InterviewFinishMessage,null)
            };
        }

        public static StateEventInfo CreateMonitoringEndEvent(DateTime timeStamp)
        {
            return new StateEventInfo
            {
                MessageType = MonitoringMessageTypes.MonitoringEndMessage,
                TimeStamp = timeStamp,
                State =
                    SerializationManager.Serialize(
                        MonitoringMessageTypes.MonitoringEndMessage, null)
            };
        }
    }
}