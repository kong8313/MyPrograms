﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Confirmit.CATI.MonitoringConsole.Classes.EvenSources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.UnitTests;

namespace Confirmit.CATI.MonitoringConsole.Classes.EvenSources.Tests
{
    [TestClass()]
    public class DeferredEventHelperTests
    {
        private StateEventInfo[] GetSampleEventInfos()
        {
            var date = new DateTime(2019, 10, 10, 12, 30, 00);
            var data = new List<StateEventInfo>
            {
                //InterviewStart
                TestEventsFactory.CreateInterviewStartEvent(date += TimeSpan.Zero), //0

                TestEventsFactory.CreateInterviewInitialEvent(date += TimeSpan.FromMilliseconds(2)), //1
                
                //simple Question with one start and one end
                TestEventsFactory.CreateQuestionSelectedEvent("q1", date += TimeSpan.FromMilliseconds(3)), //2
                TestEventsFactory.CreateInterviewPageBrowserPageCompletedEvent(date += TimeSpan.FromMilliseconds(11)), //3

                //searchable multi Question
                TestEventsFactory.CreateQuestionSelectedEvent("q2",  date += TimeSpan.FromMilliseconds(4)), //4
                TestEventsFactory.CreateInterviewPageBrowserPageCompletedEvent(date += TimeSpan.FromMilliseconds(12)), //5
                TestEventsFactory.CreateInterviewPageBrowserPageCompletedEvent(date += TimeSpan.FromMilliseconds(12)), //6
                TestEventsFactory.CreateInterviewPageBrowserPageCompletedEvent(date += TimeSpan.FromMilliseconds(12)), //7

                //multi grid Question
                TestEventsFactory.CreateQuestionSelectedEvent("q3", date += TimeSpan.FromMilliseconds(5)), //8
                TestEventsFactory.CreateQuestionSelectedEvent("q4", date += TimeSpan.FromMilliseconds(5)), //9
                TestEventsFactory.CreateQuestionSelectedEvent("q5", date += TimeSpan.FromMilliseconds(5)), //10
                TestEventsFactory.CreateInterviewPageBrowserPageCompletedEvent(date += TimeSpan.FromMilliseconds(13)), //11
                
                //Question without usual end
                TestEventsFactory.CreateQuestionSelectedEvent("q6", date += TimeSpan.FromMilliseconds(5)), //12
                TestEventsFactory.CreateInterviewFinishEvent(date += TimeSpan.FromMilliseconds(13)), //13
                TestEventsFactory.CreateMonitoringEndEvent(date += TimeSpan.FromMilliseconds(13)), //14

            }.ToArray();
            return data;
        }

        [TestMethod()]
        public void GetMilestoneFinishEventIndexTest()
        {
            var events = GetSampleEventInfos();

            //InterviewStart
            var target = DeferredEventHelper.GetMilestoneFinishEventIndex(events, 0);
            Assert.AreEqual(2, target);

            //simple Question with one start and one end
            target = DeferredEventHelper.GetMilestoneFinishEventIndex(events, 2);
            Assert.AreEqual(3, target);

            //searchable multi Question
            target = DeferredEventHelper.GetMilestoneFinishEventIndex(events, 4);
            Assert.AreEqual(7, target);

            //multi grid Question
            target = DeferredEventHelper.GetMilestoneFinishEventIndex(events, 8);
            Assert.AreEqual(11, target);

            //Question without usual end
            target = DeferredEventHelper.GetMilestoneFinishEventIndex(events, 12);
            Assert.AreEqual(13, target);
        }
    }
}