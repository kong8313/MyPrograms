﻿using System;
using System.Collections.Generic;
using System.Threading;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.Monitoring.Common.Serialization;
using Confirmit.CATI.Monitoring.Common.StateData;
using Confirmit.CATI.MonitoringConsole.Classes;
using Confirmit.CATI.MonitoringConsole.Classes.EvenSources;
using Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.MonitoringConsole.UnitTests
{
    [TestClass]
    public class DeferredEventSourceTests
    {
        private const int ActiveQuestionIndex = 1;
        private const ConsoleState ConsoleState = Monitoring.Common.StateData.ConsoleState.Interviewing;
        private const string ControlName = "controlName";
        private const int InterviewId = 12345;
        private const string KeyboardInputValue = "keyboardInputValue";
        private const string PageContent = "pageContent";
        private const string SurveyId = "surveyid";
        private const string SurveyName = "surveyname";

        [TestInitialize]
        public void TestInitialize()
        {
            MilestoneProvider.MinimalMilestoneSignificantDuration = TimeSpan.FromMilliseconds(1);
        }

        [TestMethod, Owner(@"firm\vyacheslavb")]
        public void GetInterviewingInitialStateData_StateEventInfos_InterviewingInitialStateDataSuccess()
        {
            var deferredEventSource = new DeferredEventSource(new[] { GetInitialStateEventInfo() });
            InterviewingInitialStateData interviewingInitialStateData =
                deferredEventSource.GetInterviewingInitialStateData();

            Assert.IsNotNull(interviewingInitialStateData);

            Assert.AreEqual(interviewingInitialStateData.ActiveQuestionIndex, ActiveQuestionIndex);
            Assert.AreEqual(interviewingInitialStateData.ConsoleState, ConsoleState);
            Assert.AreEqual(interviewingInitialStateData.ControlName, ControlName);
            Assert.AreEqual(interviewingInitialStateData.InterviewId, InterviewId);
            Assert.AreEqual(interviewingInitialStateData.KeyboardInputValue, KeyboardInputValue);
            Assert.AreEqual(interviewingInitialStateData.PageContent, PageContent);
            Assert.AreEqual(interviewingInitialStateData.SurveyId, SurveyId);
            Assert.AreEqual(interviewingInitialStateData.SurveyName, SurveyName);
        }

        private StateEventInfo GetInitialStateEventInfo()
        {
            var initialStateData = new InterviewingInitialStateData
            {
                ActiveQuestionIndex = ActiveQuestionIndex,
                ConsoleState = ConsoleState,
                ControlName = ControlName,
                InterviewId = InterviewId,
                KeyboardInputValue = KeyboardInputValue,
                PageContent = PageContent,
                SurveyId = SurveyId,
                SurveyName = SurveyName
            };

            return new StateEventInfo
            {
                MessageType = MonitoringMessageTypes.InterviewInitialMessage,
                TimeStamp = DateTime.Now,
                State = SerializationManager.Serialize(
                    MonitoringMessageTypes.InterviewInitialMessage,
                    initialStateData
                    )
            };
        }

        private StateEventInfo[] GetSampleEventInfos()
        {
            var date = new DateTime(2019, 10, 10, 12, 30, 00);
            var data = new List<StateEventInfo>
            {
                TestEventsFactory.CreateInterviewStartEvent(date += TimeSpan.Zero), //0

                TestEventsFactory.CreateInterviewInitialEvent(date += TimeSpan.FromMilliseconds(2)), //1
                
                TestEventsFactory.CreateQuestionSelectedEvent("q1", date += TimeSpan.FromMilliseconds(3)), //2
                TestEventsFactory.CreateInterviewPageBrowserPageCompletedEvent(date += TimeSpan.FromMilliseconds(11)), //3

                TestEventsFactory.CreateQuestionSelectedEvent("q2",  date += TimeSpan.FromMilliseconds(4)), //4
                TestEventsFactory.CreateInterviewPageBrowserPageCompletedEvent(date += TimeSpan.FromMilliseconds(12)), //5

                TestEventsFactory.CreateQuestionSelectedEvent("q3", date += TimeSpan.FromMilliseconds(5)), //6
                TestEventsFactory.CreateInterviewPageBrowserPageCompletedEvent(date += TimeSpan.FromMilliseconds(13)), //7

            }.ToArray();
            return data;
        }

        [TestMethod, Owner(@"firm\olegz")]
        public void PlayInterview_EventsRaised_NotifyReceivedSuccess()
        {
            var deferredEventSource = new DeferredEventSource(GetSampleEventInfos(), false);

            var countInterviewStartMessage = 0;
            var countInterviewInitialMessage = 0;
            var countInterviewPageBrowserQuestionSelectedMessage = 0;
            var countInterviewPageBrowserPageCompletedMessage = 0;
            var countMonitoringEndMessage = 0;
            deferredEventSource.GetEvents += (sender, e) =>
            {
                foreach (EventInfo ev in e.Events)
                {
                    switch (ev.MessageType)
                    {
                        case MonitoringMessageTypes.InterviewStartMessage: countInterviewStartMessage++; break;
                        case MonitoringMessageTypes.InterviewInitialMessage: countInterviewInitialMessage++; break;
                        case MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage: countInterviewPageBrowserQuestionSelectedMessage++; break;
                        case MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage: countInterviewPageBrowserPageCompletedMessage++; break;
                        case MonitoringMessageTypes.MonitoringEndMessage: countMonitoringEndMessage++; break;
                        default: Assert.Fail($"Unexpected event MessageType {ev.MessageType}"); break;
                    }
                }
            };
            var task = deferredEventSource.Start();

            task.GetAwaiter().GetResult();

            Assert.AreEqual(1, countInterviewStartMessage);
            Assert.AreEqual(1, countInterviewInitialMessage);
            Assert.AreEqual(3, countInterviewPageBrowserQuestionSelectedMessage);
            Assert.AreEqual(3, countInterviewPageBrowserPageCompletedMessage);
            Assert.AreEqual(1, countMonitoringEndMessage);
        }

        [TestMethod, Owner(@"firm\olegz")]
        public void PlayInterview_PositionRaised_NotifyReceivedSuccess()
        {
            var deferredEventSource = new DeferredEventSource(GetSampleEventInfos(), false);

            deferredEventSource.GetEvents += (sender, e) =>
            {
                foreach (EventInfo ev in e.Events)
                {
                    switch (ev.MessageType)
                    {
                        case MonitoringMessageTypes.InterviewStartMessage: break;
                        case MonitoringMessageTypes.InterviewInitialMessage: break;
                        case MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage: break;
                        case MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage: break;
                        case MonitoringMessageTypes.MonitoringEndMessage: break;
                        case MonitoringMessageTypes.AudioStopMessage: break;
                        default: Assert.Fail($"Unexpected event MessageType {ev.MessageType}"); break;
                    }
                }
            };
            var raisedNotifyPosition = false;
            deferredEventSource.NotifyPosition += (sender, args) => { raisedNotifyPosition = true; };

            var task = deferredEventSource.Start();

            task.GetAwaiter().GetResult();
            Assert.IsTrue(raisedNotifyPosition);
        }

        [TestMethod, Owner(@"firm\olegz")]
        public void PlayInterview_JumpToLastMilestone_SecondQuestionMissed()
        {
            var deferredEventSource = new DeferredEventSource(GetSampleEventInfos(), false);

            var contextPreparedEvent = new AutoResetEvent(false);
            var q2Raised = false;
            deferredEventSource.GetEvents += (sender, e) =>
            {
                foreach (EventInfo ev in e.Events)
                {
                    switch (ev.MessageType)
                    {
                        case MonitoringMessageTypes.InterviewStartMessage: break;
                        case MonitoringMessageTypes.InterviewInitialMessage: contextPreparedEvent.Set(); break;
                        case MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage:
                            if (((QuestionSelectedStateData)ev.State).QuestionId == "q2") q2Raised = true;
                            break;
                        case MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage: break;
                        case MonitoringMessageTypes.MonitoringEndMessage: break;
                        case MonitoringMessageTypes.AudioStopMessage: break;
                        default: Assert.Fail($"Unexpected event MessageType {ev.MessageType}"); break;
                    }
                }
            };
            var task = deferredEventSource.Start();
            Assert.IsTrue(contextPreparedEvent.WaitOne(2000));

            deferredEventSource.JumpToMilestone(6, 7);

            task.GetAwaiter().GetResult();
            Assert.IsFalse(q2Raised);
        }

        [TestMethod, Owner(@"firm\olegz")]
        public void PlayInterview_JumpToPositionTwice_NotifyReceivedSuccessTwice()
        {
            var deferredEventSource = new DeferredEventSource(GetSampleEventInfos(), false);

            var contextPreparedEvent = new AutoResetEvent(false);
            deferredEventSource.GetEvents += (sender, e) =>
            {
                foreach (EventInfo ev in e.Events)
                {
                    switch (ev.MessageType)
                    {
                        case MonitoringMessageTypes.InterviewStartMessage: break;
                        case MonitoringMessageTypes.InterviewInitialMessage: break;
                        case MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage:
                            if (((QuestionSelectedStateData)ev.State).QuestionId == "q3") contextPreparedEvent.Set();
                            break;
                        case MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage: break;
                        case MonitoringMessageTypes.MonitoringEndMessage: break;
                        case MonitoringMessageTypes.AudioStopMessage: break;
                        default: Assert.Fail($"Unexpected event MessageType {ev.MessageType}"); break;
                    }
                }
            };

            var jumpCount = 0;
            var jumpCompletedEvent = new AutoResetEvent(false);
            deferredEventSource.JumpCompleted += (sender, args) =>
            {
                jumpCompletedEvent.Set();
                jumpCount++;
            };

            var task = deferredEventSource.Start();
            Assert.IsTrue(contextPreparedEvent.WaitOne(2000));

            deferredEventSource.JumpToPositionInsideMilestone(TimeSpan.FromMilliseconds(5));
            Assert.IsTrue(jumpCompletedEvent.WaitOne(2000));

            deferredEventSource.JumpToPositionInsideMilestone(TimeSpan.FromMilliseconds(1));

            task.GetAwaiter().GetResult();
            Assert.AreEqual(2, jumpCount);
        }

    }
}
