﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using Confirmit.CATI.Common.Monitoring;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.MonitoringConsole.Classes.Launch;
using Confirmit.CATI.MonitoringConsole.Classes.Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Confirmit.CATI.Console.Shared.Log.Fakes;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.MonitoringConsole.UnitTests
{
    [TestClass]
    public class LaunchManagerTests
    {
        private static TestFileOperationsManager _fileOperationsManager;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            _fileOperationsManager = new TestFileOperationsManager();

            InitServiceLocator();
        }

        [ClassCleanup]
        public static void Cleanup()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Cleanup();
        }

        private static void InitServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            var registrator = (IServiceRegistrator)serviceLocator;

            registrator.RegisterInstance<IAlerter>(new StubIAlerter());
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void LaunchManagerConstructor_ActivationFileDoesntExist_ReturnsLiveMonitoring()
        {
            _fileOperationsManager.IsFileExists = false;
            new LaunchManager(@"C:\FileDoesntExist", _fileOperationsManager);
        }

        [TestMethod]
        public void GetLaunchFileType_ActivationFileExists_ReturnsActualLaunchFileType()
        {
            _fileOperationsManager.IsFileExists = true;

            var launchManager = new LaunchManager(@"C:\file.cspx", _fileOperationsManager);
            Assert.AreEqual(LaunchFileType.LiveMonitoring, launchManager.GetLaunchFileType());

            launchManager = new LaunchManager(@"C:\file.cspd", _fileOperationsManager);
            Assert.AreEqual(LaunchFileType.DeferredMonitoring, launchManager.GetLaunchFileType());

            launchManager = new LaunchManager(@"C:\file.cspo", _fileOperationsManager);
            Assert.AreEqual(LaunchFileType.OfflineMonitoring, launchManager.GetLaunchFileType());
        }

        [TestMethod]
        public void ReadLaunchInfo_ActivationFileExists_ReturnsMonitoringLaunchInfo()
        {
            _fileOperationsManager.IsFileExists = true;

            var expectedInfo = new MonitoringLaunchInfo { CompanyId = 1, ServerName = "testServer", EncryptedData = "test" };

            byte[] buffer;

            using (var stream = new MemoryStream())
            {
                var serializer = new XmlSerializer(typeof(MonitoringLaunchInfo));
                serializer.Serialize(stream, expectedInfo);

                buffer = new byte[stream.Length];
                stream.Seek(0, SeekOrigin.Begin);
                stream.Read(buffer, 0, buffer.Length);
            }

            _fileOperationsManager.FileContent = buffer;

            var launchManager = new LaunchManager(@"C:\FileDoesntExist", _fileOperationsManager);

            var actualInfo = launchManager.ReadLaunchInfo();

            Assert.AreEqual(expectedInfo.CompanyId, actualInfo.CompanyId);
            Assert.AreEqual(expectedInfo.ServerName, actualInfo.ServerName);
            Assert.AreEqual(expectedInfo.EncryptedData, actualInfo.EncryptedData);
        }

        [TestMethod]
        [ExpectedException(typeof(FileFormatException))]
        public void ReadOfflineLaunchInfo_ActivationFileDoesntContainProperContent_ThrownsException()
        {
            _fileOperationsManager.IsFileExists = true;
            _fileOperationsManager.UnpackedFiles = Enumerable.Empty<string>();

            var launchManager = new LaunchManager(@"C:\FileDoesntExist", _fileOperationsManager);

            launchManager.ReadOfflineLaunchInfo();
        }

        [TestMethod]
        public void ReadOfflineLaunchInfo_ActivationFileContainsProperContent_ReturnsLaunchInfo()
        {
            _fileOperationsManager.IsFileExists = true;
            var expectedLaunchInfo = new OfflineMonitoringLaunchInfo() { VideoFilePath = @"c:\test.cce", AudioFilesPaths = new List<string> { @"c:\test.wav" } };
            _fileOperationsManager.UnpackedFiles = new[] { expectedLaunchInfo.VideoFilePath, expectedLaunchInfo.AudioFilesPaths.ToArray()[0], @"c:\test.xml" };

            var launchManager = new LaunchManager(@"C:\FileDoesntExist", _fileOperationsManager);

            var actualLaunchInfo = launchManager.ReadOfflineLaunchInfo();

            Assert.AreEqual(expectedLaunchInfo.VideoFilePath, actualLaunchInfo.VideoFilePath);
            CollectionAssert.AreEqual(expectedLaunchInfo.AudioFilesPaths, actualLaunchInfo.AudioFilesPaths);
        }
    }

    public class TestFileOperationsManager : IFileOperationsManager
    {
        public bool IsFileExists { get; set; }
        public byte[] FileContent { get; set; }
        public IEnumerable<string> UnpackedFiles { get; set; }

        public bool FileExists(string path)
        {
            return IsFileExists;
        }

        public Stream OpenFile(string path)
        {
            return new MemoryStream(FileContent);
        }

        public IEnumerable<string> UnpackPackagePartsToFiles(string path)
        {
            return UnpackedFiles;
        }

        public void DeleteFiles(IEnumerable<string> files)
        {
        }
    }
}
