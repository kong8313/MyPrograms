﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.MonitoringConsole.UnitTests
{
    [TestClass]
    public class AnsweredQuestionsProviderTests
    {
        [TestMethod]
        [ExpectedException(exceptionType: typeof(InvalidOperationException))]
        public void GetQuestions_ForEmptyEventCollection_Exception()
        {
            var data = new StateEventInfo[0];

            (new AnsweredQuestionsProvider(data)).GetAllQuestions();
        }

        [TestMethod]
        public void GetQuestions_OneQuestionSelectedEvent_Success()
        {
            var data = new List<StateEventInfo>
            {
                TestEventsFactory.CreateInterviewStartEvent(),
                TestEventsFactory.CreateInterviewInitialEvent(), 
                TestEventsFactory.CreateQuestionSelectedEvent("q1")
            }.ToArray();

            var questions = (new AnsweredQuestionsProvider(data)).GetAllQuestions().ToList();

            Assert.AreEqual(2, questions.Count);
            Assert.AreEqual("q1", questions[1].Id);
            Assert.AreEqual(2, questions[1].IndexOfEvent);
            Assert.AreEqual(1, questions[1].IndexOfEventContentLoad);            
        }

        [TestMethod]
        public void GetQuestions_SeveralQuestionSelectedEvents_Success()
        {
            var data = new List<StateEventInfo>
            {
                TestEventsFactory.CreateInterviewStartEvent(), 

                TestEventsFactory.CreateInterviewInitialEvent(), 
                TestEventsFactory.CreateQuestionSelectedEvent("q1"), 

                TestEventsFactory.CreateInterviewPageBrowserPageCompletedEvent(), 
                TestEventsFactory.CreateQuestionSelectedEvent("q2"), 
                TestEventsFactory.CreateQuestionSelectedEvent("q3"),

            }.ToArray();

            var questions = (new AnsweredQuestionsProvider(data)).GetAllQuestions().ToList();

            Assert.AreEqual(4, questions.Count);

            Assert.AreEqual("q1", questions[1].Id);
            Assert.AreEqual(2, questions[1].IndexOfEvent);
            Assert.AreEqual(1, questions[1].IndexOfEventContentLoad);

            Assert.AreEqual("q2", questions[2].Id);
            Assert.AreEqual(4, questions[2].IndexOfEvent);
            Assert.AreEqual(3, questions[2].IndexOfEventContentLoad);

            Assert.AreEqual("q3", questions[3].Id);
            Assert.AreEqual(5, questions[3].IndexOfEvent);
            Assert.AreEqual(3, questions[3].IndexOfEventContentLoad);
        }

        [TestMethod]
        public void GetQuestions_TheSameQuestionOnOnePageSelectedSeveralTimes_Success()
        {
            var interviewStartEvent = DateTime.UtcNow;

            var data = new List<StateEventInfo>
            {
                TestEventsFactory.CreateInterviewStartEvent(interviewStartEvent ),

                TestEventsFactory.CreateInterviewInitialEvent(),
                TestEventsFactory.CreateQuestionSelectedEvent("q1", interviewStartEvent.AddSeconds(30)), 
                TestEventsFactory.CreateQuestionSelectedEvent("q2"),
                TestEventsFactory.CreateQuestionSelectedEvent("q1", interviewStartEvent.AddSeconds(40)),

            }.ToArray();

            var questions = (new AnsweredQuestionsProvider(data)).GetAllQuestions().ToList();

            Assert.AreEqual(4, questions.Count);

            Assert.AreEqual("q1", questions[1].Id);
            Assert.AreEqual(2, questions[1].IndexOfEvent);
            Assert.AreEqual(1, questions[1].IndexOfEventContentLoad);
            Assert.AreEqual(30, questions[1].Offset.Seconds);

            Assert.AreEqual("q1", questions[3].Id);
            Assert.AreEqual(4, questions[3].IndexOfEvent);
            Assert.AreEqual(1, questions[3].IndexOfEventContentLoad);
            Assert.AreEqual(40, questions[3].Offset.Seconds);
        }    

        [TestMethod]
        public void GetQuestions_TheSameQuestionSelectedSeveralTimesAfterAnotherPageLoaded_Success()
        {
            var interviewStartEvent = DateTime.UtcNow;

            var data = new List<StateEventInfo>
            {
                TestEventsFactory.CreateInterviewStartEvent(interviewStartEvent ),

                TestEventsFactory.CreateInterviewInitialEvent(),
                TestEventsFactory.CreateQuestionSelectedEvent("q1", interviewStartEvent.AddSeconds(30)), 

                TestEventsFactory.CreateInterviewPageBrowserPageCompletedEvent(), 
                TestEventsFactory.CreateQuestionSelectedEvent("q2"),

                TestEventsFactory.CreateInterviewPageBrowserPageCompletedEvent(), 
                TestEventsFactory.CreateQuestionSelectedEvent("q1", interviewStartEvent.AddSeconds(40))

            }.ToArray();

            var questions = (new AnsweredQuestionsProvider(data)).GetAllQuestions().ToList();

            Assert.AreEqual(4, questions.Count);

            Assert.AreEqual("q1", questions[1].Id);
            Assert.AreEqual(2, questions[1].IndexOfEvent);
            Assert.AreEqual(1, questions[1].IndexOfEventContentLoad);
            Assert.AreEqual(30, questions[1].Offset.Seconds);

            Assert.AreEqual("q1", questions[3].Id);
            Assert.AreEqual(6, questions[3].IndexOfEvent);
            Assert.AreEqual(5, questions[3].IndexOfEventContentLoad);
            Assert.AreEqual(40, questions[3].Offset.Seconds);
        }
    }
}
