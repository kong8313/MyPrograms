﻿using System;
using Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback;
using Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback.Writers;

namespace Confirmit.CATI.MonitoringConsole.UnitTests.OfflineMonitoringInterviewRecordCreation
{
    public class TestInterviewRecordWriter : IInterviewRecordWriter
    {
        private readonly Action<InterviewRecordData, string> _action;

        public TestInterviewRecordWriter(Action<InterviewRecordData, string> action)
        {
            _action = action;
        }

        public void WriteRecord(InterviewRecordData writeInfo, string fileName)
        {
            if (_action != null)
            {
                _action.Invoke(writeInfo, fileName);
            }
        }

    }
}
