﻿using System;
using System.IO;
using Confirmit.CATI.MonitoringConsole.Classes.Playback;

namespace Confirmit.CATI.MonitoringConsole.UnitTests.OfflineMonitoringInterviewRecordCreation
{
    public class TestAudioService : IAudioService
    {
        private readonly bool _generateError;

        public TestAudioService()
        {
        }

        public TestAudioService(bool generateError)
        {
            _generateError = generateError;
        }

        public Stream GetAudioStreamByIdentityId(string identityId)
        {
            if (_generateError)
            {
                throw new Exception();
            }

            return new MemoryStream();
        }
    }
}
