﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Common.Monitoring;
using Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.MonitoringConsole.UnitTests.OfflineMonitoringInterviewRecordCreation
{
    [TestClass]
    public class OfflineMonitoringInterviewRecordCreationTests
    {
        private const string FileName = "c:\\test.cspo";
        private const string AudioUri = "http://test.wav";
        private const string ProjectId = "p01234567";
        private const int InterviewId = 1;
        private const LaunchFileType LaunchType = LaunchFileType.DeferredMonitoring;
        private const string InterviewerName = "InterviewerName";
        private const string SupervisorName = "SupervisorName";
        private const int CompanyId = 321;
        private const string CompanyAlias = "CompanyAlias";
        private const int InterviewerId = 1;
        private const string SurveyId = "SurveyId";

        private readonly long _monitoringSessionId = DateTime.UtcNow.Ticks;
        private readonly DateTime _creationUtcTime = DateTime.UtcNow;

        [TestMethod, Owner("firm/vyacheslavb")]
        public void CreateInterviewRecord_HaveAudioAndVideo_CreationSuccess()
        {
            var recordCreator = new InterviewRecordCreator(
                new TestMonitoringService(true, AudioUri),
                new TestAudioService(),
                new TestInterviewRecordWriter((writeInfo, fileName) =>
                {
                    writeInfo.EventsStream.Dispose();
                    foreach (var writeInfoAudioStream in writeInfo.AudioStreams)
                    {
                        writeInfoAudioStream.Dispose();
                    }

                    ValidateMetadata(writeInfo.Metadata, true);
                    Assert.AreEqual(fileName, FileName);

                    Assert.IsNotNull(writeInfo);
                    Assert.IsNotNull(fileName);
                    Assert.IsNotNull(writeInfo.EventsStream);
                    Assert.IsNotNull(writeInfo.AudioStreams);
                    Assert.IsNotNull(writeInfo.Metadata);
                    Assert.IsNotNull(writeInfo.AudioIdentities);
                }),
                null
                );

            StartInterviewRecord(recordCreator);
        }

        [TestMethod, Owner("firm/vyacheslavb")]
        public void CreateInterviewRecord_HaveOnlyVideo_CreationSuccess()
        {
            var recordCreator = new InterviewRecordCreator(
                new TestMonitoringService(false),
                new TestAudioService(),
                new TestInterviewRecordWriter(
                    (writeDate, fileName) => ValidateWriteResultWithoutAudio(writeDate, fileName)
                    ),
                null
                );

            StartInterviewRecord(recordCreator);
        }

        [TestMethod, Owner("firm/vyacheslavb")]
        public void CreateInterviewRecord_HaveAudioAndVideo_AllCreationActionsPassed()
        {
            var actionsQueue = CreateInterviewRecordCreateActions(true);
            var recordCreator = new InterviewRecordCreator(
                new TestMonitoringService(true, AudioUri),
                new TestAudioService(),
                new TestInterviewRecordWriter((writeInfo, fileName) => { }),
                null
                );

            recordCreator.SetAcionProcessor(
                new TestActionAndErrorProcessor<InterviewRecordCreateAction>(
                    action =>
                    {
                        var firstQueueAction = actionsQueue.First();
                        if (firstQueueAction == action)
                        {
                            actionsQueue.Remove(action);
                        }
                    }
                    )
                );
            StartInterviewRecord(recordCreator);
            Assert.AreEqual(actionsQueue.Count, 0);
        }

        [TestMethod, Owner("firm/vyacheslavb")]
        public void CreateInterviewRecord_HaveOnlyVideo_AllCreationActionsPassed()
        {
            var actionsQueue = CreateInterviewRecordCreateActions(false);
            var recordCreator = new InterviewRecordCreator(
                new TestMonitoringService(true, AudioUri),
                new TestAudioService(),
                new TestInterviewRecordWriter((writeInfo, fileName) => { }),
                null
                );

            recordCreator.SetAcionProcessor(
                new TestActionAndErrorProcessor<InterviewRecordCreateAction>(
                    action =>
                    {
                        var firstQueueAction = actionsQueue.First();
                        if (firstQueueAction == action)
                        {
                            actionsQueue.Remove(action);
                        }
                    }
                    )
                );
            StartInterviewRecord(recordCreator);
            Assert.AreEqual(actionsQueue.Count, 0);
        }

        [TestMethod, Owner("firm/vyacheslavb")]
        public void CreateInterviewRecord_HaveAudioErrorAndVideo_CreationSuccess()
        {
            var recordCreator = new InterviewRecordCreator(
                 new TestMonitoringService(true, AudioUri),
                 new TestAudioService(true),
                 new TestInterviewRecordWriter(
                     (writeDate, fileName) => ValidateWriteResultWithoutAudio(writeDate, fileName, true)
                     ),
                 null
                 );
            var errorProcessed = false;
            recordCreator.SetErrorProcessor(
                new TestActionAndErrorProcessor<InterviewRecordCreateError>(error => { errorProcessed = true; })
                );
            StartInterviewRecord(recordCreator);
            Assert.IsTrue(errorProcessed);
        }

        private void ValidateMetadata(InterviewRecordMetadata metadata, bool hasAudio)
        {
            Assert.AreEqual(metadata.ProjectId, ProjectId);
            Assert.AreEqual(metadata.InterviewId, InterviewId);
            Assert.AreEqual(metadata.LaunchType, LaunchType);
            Assert.AreEqual(metadata.CompanyAlias, CompanyAlias);
            Assert.AreEqual(metadata.CompanyId, CompanyId);
            Assert.AreEqual(metadata.CreationUtcTime, _creationUtcTime);
            Assert.AreEqual(metadata.InterviewerId, InterviewerId);
            Assert.AreEqual(metadata.InterviewerName, InterviewerName);
            Assert.AreEqual(metadata.SupervisorName, SupervisorName);
            Assert.AreEqual(metadata.SurveyId, SurveyId);

            if (hasAudio)
            {
                Assert.AreEqual(metadata.AudioUris, AudioUri);
            }
        }

        private void ValidateWriteResultWithoutAudio(
            InterviewRecordData writeInfo,
            string fileName,
            bool hasAudioError = false
            )
        {
            writeInfo.EventsStream.Dispose();

            ValidateMetadata(writeInfo.Metadata, false);
            Assert.AreEqual(fileName, FileName);

            Assert.IsNotNull(writeInfo);
            Assert.IsNotNull(fileName);
            Assert.IsNotNull(writeInfo.EventsStream);
            Assert.IsNotNull(writeInfo.Metadata);
            Assert.IsNull(writeInfo.AudioStreams);

            if (!hasAudioError)
            {
                Assert.IsNull(writeInfo.AudioIdentities);
                // disable resharper warning.
                writeInfo.AudioIdentities = null;
            }
            else
            {
                Assert.IsNotNull(writeInfo.AudioIdentities);
            }
        }

        private void StartInterviewRecord(InterviewRecordCreator recordCreator)
        {
            recordCreator.StartInterviewRecordCreation(
                FileName,
                CreateMonitoringIdentityInfo(),
                ProjectId,
                InterviewId,
                true
                );
        }

        private MonitoringIdentityInfo CreateMonitoringIdentityInfo()
        {
            return new MonitoringIdentityInfo
            {
                LaunchType = LaunchType,
                CompanyAlias = CompanyAlias,
                CompanyId = CompanyId,
                CreationUtcTime = _creationUtcTime,
                InterviewerId = InterviewerId,
                InterviewerName = InterviewerName,
                MonitoringSessionId = _monitoringSessionId,
                SupervisorName = SupervisorName,
                SurveyId = SurveyId
            };
        }

        private List<InterviewRecordCreateAction> CreateInterviewRecordCreateActions(bool withAudio)
        {
            var actionsQueue = new List<InterviewRecordCreateAction>
            {
                InterviewRecordCreateAction.Starting,
                InterviewRecordCreateAction.GetEvents,
                InterviewRecordCreateAction.GetAudioEvent
            };
            if (withAudio)
            {
                actionsQueue.Add(InterviewRecordCreateAction.GetAudioIdentity);
                actionsQueue.Add(InterviewRecordCreateAction.GetAudioData);
            }
            actionsQueue.Add(InterviewRecordCreateAction.CreateRecord);
            actionsQueue.Add(InterviewRecordCreateAction.Completing);

            return actionsQueue;
        }

    }
}
