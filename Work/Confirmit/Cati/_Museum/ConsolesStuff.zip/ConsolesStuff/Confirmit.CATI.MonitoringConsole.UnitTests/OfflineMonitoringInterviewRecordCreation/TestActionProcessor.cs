﻿using System;
using Confirmit.CATI.MonitoringConsole.Classes.OfflinePlayback;

namespace Confirmit.CATI.MonitoringConsole.UnitTests.OfflineMonitoringInterviewRecordCreation
{
    public class TestActionAndErrorProcessor<T> : IInterviewRecordEventsProcessor<T>
    {
        private readonly Action<T> _action;

        public TestActionAndErrorProcessor(Action<T> action)
        {
            _action = action;
        }

        public void Process(T arg)
        {
            if (_action != null)
            {
                _action.Invoke(arg);
            }
        }
    }
}
