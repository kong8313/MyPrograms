﻿using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.Classes.Playback;

namespace Confirmit.CATI.MonitoringConsole.UnitTests.OfflineMonitoringInterviewRecordCreation
{
    public class TestMonitoringService : IMonitoringService
    {
        private readonly bool _returnAudio;
        private readonly string _audioUri;

        public TestMonitoringService(bool returnAudio) : this(returnAudio, null)
        {
        }

        public TestMonitoringService(bool returnAudio, string audioUri)
        {
            _returnAudio = returnAudio;
            _audioUri = audioUri;
        }

        public Stream GetDeferredRecord(long recordId)
        {
            if (!_returnAudio)
            {
                return new MemoryStream();
            }

            var audioEvents = new []
            {
                new StateEventInfo { MessageType = MonitoringMessageTypes.AudioStartMessage }
            };

            var binaryFormater = new BinaryFormatter();

            var memoryStream = new MemoryStream();
            binaryFormater.Serialize(memoryStream, audioEvents);

            memoryStream.Seek(0, SeekOrigin.Begin);
            return memoryStream;
        }

        public IEnumerable<AudioIdentityObject> GetAudioIdentity(long recordId)
        {
            return new List<AudioIdentityObject> { new AudioIdentityObject {ID = _audioUri} };
        }
    }
}
