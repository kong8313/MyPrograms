﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.MonitoringConsole.Classes;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.MonitoringConsole.UnitTests
{
    [TestClass]
    public class InterviewInitialEventsProviderTests
    {
        [TestMethod, Owner(@"FIRM\DenisM")]
        public void GetAll_ForInstantiatedProvider_ReturnsEmptyCollection()
        {
            var provider = new InterviewInitialEventsProvider(new List<StateEventInfo>());
            Assert.IsFalse(provider.GetAll().Any());
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void GetAll_ProviderInstantiatedWithOneItem_Success()
        {
            var stateEventInfos = new List<StateEventInfo> { TestEventsFactory.CreateInterviewInitialEvent() };
            var provider = new InterviewInitialEventsProvider(stateEventInfos);

            Assert.AreEqual(1, provider.GetAll().Count());
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void GetAll_GetNearestLeft_Success()
        {
            const double secondsAdd = 11;
            var stateEventInfos = new List<StateEventInfo>();

            var firstInitialEventTimeStamp = new DateTime(2001, 1, 1, 1, 0, 1, 0);
            var secondInitialEventTimeStamp = firstInitialEventTimeStamp.AddSeconds(secondsAdd);

            var testingTimeStamp = secondInitialEventTimeStamp.AddSeconds(1);

            stateEventInfos.Add(TestEventsFactory.CreateInterviewInitialEvent(firstInitialEventTimeStamp));
            stateEventInfos.Add(TestEventsFactory.CreateInterviewInitialEvent(secondInitialEventTimeStamp));
            stateEventInfos.Add(TestEventsFactory.CreateInterviewInitialEvent(secondInitialEventTimeStamp.AddSeconds(secondsAdd)));

            var provider = new InterviewInitialEventsProvider(stateEventInfos);

            Assert.AreEqual(secondInitialEventTimeStamp, provider.GetNearestLeft(testingTimeStamp).TimeStamp);
        }

        [TestMethod, Owner(@"FIRM\DmitryS")]
        public void GetAll_GetNearestLeft_SuccessOnEquelTimeStamp()
        {
            var stateEventInfos = new List<StateEventInfo>();

            var firstInitialEventTimeStamp = new DateTime(2001, 1, 1, 1, 0, 1, 0);

            var testingTimeStamp = firstInitialEventTimeStamp;

            stateEventInfos.Add(TestEventsFactory.CreateInterviewInitialEvent(firstInitialEventTimeStamp));

            var provider = new InterviewInitialEventsProvider(stateEventInfos);

            Assert.AreEqual(firstInitialEventTimeStamp, provider.GetNearestLeft(testingTimeStamp).TimeStamp);
        }
    }
}
