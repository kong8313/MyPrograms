using System;
using System.ComponentModel;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.MonitoringConsole.UnitTests.Presenters
{
    public class RedialFormStub : IViewRedialForm
    {
        public RedialFormStub()
        {
            SynchronizationContext = new SynchronizationContext();
        }

        public void Localize(ILocalizationManager manager)
        {
            throw new NotImplementedException();
        }

        public SynchronizationContext SynchronizationContext { get; private set; }
        public void Dispose()
        {
        }

        public event EventHandler<ProcessCmdKeyEventArgs> FormProcessCmdKey;
        public event EventHandler<EventArgs> OkClick;
        public event EventHandler<CancelEventArgs> ValidatingDialNumber;
        public event EventHandler<EventArgs> RedialTypeChanged;
        public event EventHandler<EventArgs> RedialNumberChanged;
        public event EventHandler<EventArgs> FormClose;
        public event EventHandler<DialCancellationEventArgs> CancelClick;
        public bool SuppressFormClosing { get; set; }
        public bool IsVisible { get; private set; }
        public bool IsInProgressIndicatorVisible { get; private set; }
        public string LastCallOutcomeName { get; private set; }
        public string DialNumber { get; set; }
        public bool RedialNewNumber { get; set; }
        public bool ShowRedialNewNumber { get; set; }
        public bool IsDialCanellationButtonEnabled { get; set; }
        public string DialingMessage { get; set; }
        public string HangupDialingMessage { get; set; }

        public void Show(IWin32Window parent)
        {
            throw new NotImplementedException();
        }

        public void ShowNonModal(IWin32Window parent)
        {
            IsVisible = true;
        }

        public void AlertValidationError(RedialValidationControls control, string message)
        {
            throw new NotImplementedException();
        }

        public void EnableInputControls(bool enable)
        {
            AreInputControlsEnabled = enable;
        }

        public void SetDialingInProgressVisibility(bool show)
        {
            IsInProgressIndicatorVisible = show;
        }

        public void HideForm()
        {
            IsVisible = false;
        }

        public void NotifyLastCallOutcome(string callOutcome)
        {
            LastCallOutcomeName = callOutcome;
        }

        public void SetDialCanellationButtonVisibility(bool isVisible)
        {

        }

        public void HangupDialing()
        {

        }

        public void SetProcessMessage(string message)
        {

        }

        public bool AreInputControlsEnabled { get; private set; }
    }
}