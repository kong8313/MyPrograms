using System;
using System.Threading;
using Confirmit.CATI.MonitoringConsole.Classes;

namespace Confirmit.CATI.MonitoringConsole.UnitTests.Presenters
{
    public class SynchronizationContextAdapterSync : IContext
    {
        private readonly SynchronizationContext _context;

        public SynchronizationContextAdapterSync(SynchronizationContext context)
        {
            _context = context;
        }

        public virtual void Post(SendOrPostCallback d, Object state)
        {
            // We use synchronous Send (not the asynchronous Post) to play events synchronously
            // to be able to check statements in unit tests.
            _context.Send(d, state);
        }
    }
}