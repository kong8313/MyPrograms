﻿using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;
using Confirmit.CATI.MonitoringConsole.Presenters;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.MonitoringConsole.UnitTests.Presenters
{
    [TestClass]
    public class PresenterRedialTests
    {
        [TestMethod]
        public void PresenterRedial_ShowRedialNewNumberProcessWithEnteringNewNumber_Success()
        {
            const string dialNumber = "1243";

            var form = new RedialFormStub();
            var mainForm = new Console.Views.Forms.MainForm();
            var redialContext = new SynchronizationContextAdapterSync(form.SynchronizationContext);
            var presenter = new PresenterRedial(form, mainForm, redialContext);

            presenter.PlayEvent(MonitoringMessageTypes.RedialFormInitialMessage, null);
            presenter.PlayEvent(MonitoringMessageTypes.RedialFormRedialTypeChangedMessage, new RedialTypeChangedStateData
            {
                IsNewNumberDialChecked = true
            });
            presenter.PlayEvent(MonitoringMessageTypes.RedialFormDialNumberChangedMessage, new RedialNumberChangedStateData
            {
                DialNumber = dialNumber
            });

            Assert.IsTrue(form.IsVisible);
            Assert.AreEqual(dialNumber, form.DialNumber);
            Assert.AreEqual(true, form.RedialNewNumber);
        }

        [TestMethod]
        public void PresenterRedial_StartRedialDefault_Success()
        {
            var form = new RedialFormStub();
            var mainForm = new Console.Views.Forms.MainForm();
            var redialContext = new SynchronizationContextAdapterSync(form.SynchronizationContext);
            var presenter = new PresenterRedial(form, mainForm, redialContext);

            presenter.PlayEvent(MonitoringMessageTypes.RedialFormInitialMessage, null);
            presenter.PlayEvent(MonitoringMessageTypes.RedialFormDialCalledMessage, new RedialDialCalledStateData
            {
                IsDialCanellationButtonVisible = false
            });

            Assert.IsTrue(form.IsVisible);
            Assert.IsTrue(form.IsInProgressIndicatorVisible);
            Assert.AreEqual(false, form.RedialNewNumber);
        }

        [TestMethod]
        public void PresenterRedial_FinishRedialToDefaultNumberWithConnectedStatus_Success()
        {
            const string lastCallOutcomeName = "Connected (1)";

            var form = new RedialFormStub();
            var mainForm = new Console.Views.Forms.MainForm();
            var redialContext = new SynchronizationContextAdapterSync(form.SynchronizationContext);
            var presenter = new PresenterRedial(form, mainForm, redialContext);

            presenter.PlayEvent(MonitoringMessageTypes.RedialFormInitialMessage, null);
            presenter.PlayEvent(MonitoringMessageTypes.RedialFormDialCalledMessage, new RedialDialCalledStateData
            {
                IsDialCanellationButtonVisible = false
            });

            Assert.IsTrue(form.IsVisible);
            Assert.IsTrue(form.IsInProgressIndicatorVisible);
            Assert.IsFalse(form.RedialNewNumber);

            presenter.PlayEvent(MonitoringMessageTypes.RedialFormTelephonyResultMessage, new RedialTelephonyResultStateData
            {
                CallOutcome = lastCallOutcomeName,
                IsConnected = true
            });

            Assert.IsFalse(form.IsInProgressIndicatorVisible);
            Assert.AreEqual(lastCallOutcomeName, form.LastCallOutcomeName);

            presenter.PlayEvent(MonitoringMessageTypes.RedialFormCloseMessage, null);

            Assert.IsFalse(form.IsVisible);
        }
    }
}
