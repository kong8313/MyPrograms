﻿using System;
using System.Linq;
using Confirmit.CATI.MonitoringConsole.Classes.JumpToQuestion;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.MonitoringConsole.UnitTests
{
    [TestClass]
    public class AnsweredQuestionsComboBoxItemsProviderTests
    {
        private AnsweredQuestionsComboBoxItemsProvider comboBoxItemsProvider;

        [TestMethod]
        public void GetItems_OneQuestionWithIdAndOffset_Success()
        {
            var answeredQuestions = new[]
            {
                new AnsweredQuestion()
                {
                    Id = "q1", 
                    Offset = new TimeSpan(0, 0, 0, 5)
                }
            };

            comboBoxItemsProvider = new AnsweredQuestionsComboBoxItemsProvider(answeredQuestions);

            var result = comboBoxItemsProvider.GetItems().ToList();

            Assert.AreEqual(1, result.Count());
            Assert.AreEqual("q1 (00:05)", result[0].ItemText);
        }


        [TestMethod]
        public void GetItems_OneQuestionWithTitleAndOffset_Success()
        {
            var answeredQuestions = new[]
            {
                new AnsweredQuestion
                {
                    Id = "q2",
                    QuestionTitle = "question title",
                    QuestionText = "question text",
                    Offset = new TimeSpan(0, 0, 10, 5)
                }
            };

            comboBoxItemsProvider = new AnsweredQuestionsComboBoxItemsProvider(answeredQuestions);

            var result = comboBoxItemsProvider.GetItems().ToList();

            Assert.AreEqual(1, result.Count());
            Assert.AreEqual("q2 (10:05) question title", result[0].ItemText);
        }

        [TestMethod]
        public void GetItems_OneQuestionWithTextAndOffset_Success()
        {
            var answeredQuestions = new[]
            {
                new AnsweredQuestion()
                {
                    Id = "q3", 
                    QuestionText = "question text", 
                    Offset = new TimeSpan(0, 1, 10, 5)
                }
            };

            comboBoxItemsProvider = new AnsweredQuestionsComboBoxItemsProvider(answeredQuestions);

            var result = comboBoxItemsProvider.GetItems().ToList();

            Assert.AreEqual(1, result.Count());
            Assert.AreEqual("q3 (01:10:05) question text", result[0].ItemText);
        }


        [TestMethod, Owner(@"FIRM\DenisM")]
        public void GetItems_QuestionWithTextOnMultipleLines_Success()
        {
            var answeredQuestions = new[]
            {
                new AnsweredQuestion()
                {
                    Id = "q1", 
                    QuestionText = "How old are you?\r\n\r\n\r\nPlease choose your age.",
                    Offset = new TimeSpan(0, 0, 0, 5)
                }
            };

            comboBoxItemsProvider = new AnsweredQuestionsComboBoxItemsProvider(answeredQuestions);

            var result = comboBoxItemsProvider.GetItems().ToList();

            Assert.AreEqual(1, result.Count());
            Assert.AreEqual("q1 (00:05) How old are you? Please choose your age.", result[0].ItemText);
        }
    }
}