﻿using System;
using Confirmit.CATI.MonitoringConsole.Classes;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.MonitoringConsole.UnitTests
{
    [TestClass]
    public class StringExtensionsTests
    {
        private const string Sentence = "Loremipsumdolor sit amet, consectetuer adipiscingningo elit";
        private const string Sentence1 = "Loremipsumdolor sit amet, consectetuer, adipiscingningo elit";

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void StringExtensions_CropWholeWords_ReturnsShortWithoutEllipsis()
        {
            Assert.AreEqual(Sentence.CropWholeWords(50, false), "Loremipsumdolor sit amet, consectetuer");
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void StringExtensions_CropWholeWords_ReturnsShortWithEllipsis()
        {
            Assert.AreEqual(Sentence.CropWholeWords(50, true), "Loremipsumdolor sit amet, consectetuer...");
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void StringExtensions_CropWholeWords_ReturnsCroppedWithoutEllipsis()
        {
            Assert.AreEqual(Sentence.CropWholeWords(10, false), "Loremipsum");
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void StringExtensions_CropWholeWords_ReturnsShortWithPunctuationWithoutEllipsis()
        {
            Assert.AreEqual(Sentence1.CropWholeWords(40, false), "Loremipsumdolor sit amet, consectetuer,");
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        [ExpectedException(typeof(ArgumentException))]
        public void StringExtensions_CropWholeWordsSetLengthZeroOrNegative_ThrowsArgumentException()
        {
            Sentence1.CropWholeWords(0, false);
            Sentence1.CropWholeWords(-1, false);
        }
    }
}
