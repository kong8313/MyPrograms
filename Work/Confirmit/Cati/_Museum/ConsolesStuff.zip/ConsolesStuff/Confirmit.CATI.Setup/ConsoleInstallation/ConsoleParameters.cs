﻿namespace ConsoleInstallation
{
    public class ConsoleParameters
    {
        public string CatiConnectionString { get; set; }

        public string InterviewerAliasName { get; set; }
        public string MonitoringAliasName { get; set; }

        public string DeploymentServerName { get; set; }
        public string CatiServerName { get; set; }
        public string EnvironmentName { get; set; }

        public string CertificatePath { get; set; }
        public string CertificatePassword { get; set; }
    }
}