﻿using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using Confirmit.CATI.Installation.Common.Interfaces;
using System.IO;
using Confirmit.CATI.Installation.Common;
using DatabaseEngine = Confirmit.CATI.Installation.Common.DatabaseEngine;

namespace ConsoleInstallation
{
    public class InstallationFacade
    {
        private readonly ClientsDeploymentSetupEngine _clientsDeploymentSetupEngine;
        private readonly ConfigsEngine _configsEngine;

        public InstallationFacade(ILogger logger)
        {
            _clientsDeploymentSetupEngine = new ClientsDeploymentSetupEngine(logger);
            _configsEngine = new ConfigsEngine(logger);
        }

        public void PutConsoleVersionToDefaultCatiDatabase(string catiConnectionString, Dictionary<string, string> settings)
        {
            var databaseEngine = new DatabaseEngine(catiConnectionString);

            databaseEngine.ConfigureBvSystemSetting(CatiSetupConstants.CatiDefaultDatabaseName, settings);
        }

        public void SetupDefaultPage(string installLocation, string productVersion, bool installConfirmitBrandedPage, bool isInterviewerConsole)
        {
            string infoHtmlFilePath;
            string publishHtmlFilePath = Path.Combine(installLocation, "publish.html");
            string defaultHtmFilePath = Path.Combine(installLocation, "default.htm");
            string brandedImagesPath = Path.Combine(installLocation, "images");
            if (installConfirmitBrandedPage)
            {
                File.Delete(publishHtmlFilePath);
                infoHtmlFilePath = defaultHtmFilePath;

                _clientsDeploymentSetupEngine.ChangeConsoleNameInDefaultFile(defaultHtmFilePath, isInterviewerConsole);
            }
            else
            {
                File.Delete(defaultHtmFilePath);
                _clientsDeploymentSetupEngine.RemoveDirectory(brandedImagesPath);

                infoHtmlFilePath = publishHtmlFilePath;
            }

            _clientsDeploymentSetupEngine.ChangeVersionInPublishFile(infoHtmlFilePath, productVersion);
        }

        public X509Certificate2 GetCertificate(string certificatePath, string certificatePassword)
        {
            return !string.IsNullOrEmpty(certificatePassword)
                ? new X509Certificate2(certificatePath, certificatePassword)
                : new X509Certificate2(certificatePath);
        }


        public string GetMageCertificateArguments(string certificatePath, string certificatePassword)
        {
            string mageCertificateArguments = $"-cf \"{certificatePath}\"";
            if (!string.IsNullOrEmpty(certificatePassword))
            {
                mageCertificateArguments += $" -pwd:{certificatePassword}";
            }

            return mageCertificateArguments + " -a sha256RSA";
        }

        public void SignClickOnceFiles(string mageFilePath, string mageCertificateArguments, string deploymentFolderPath,
            string applicationPath, string manifestPath, string productVersion, string environmentName, bool supportMultiInstallation)
        {
            _clientsDeploymentSetupEngine.SignClickOnceFiles(mageFilePath, mageCertificateArguments, deploymentFolderPath,
            applicationPath, manifestPath, productVersion, environmentName, supportMultiInstallation);
        }

        public void SignSetupExe(X509Certificate2 signingCertificate, string installLocation, string consoleDeploymentUrl)
        {
            _clientsDeploymentSetupEngine.ChangeUrlForSetupExe(signingCertificate, installLocation, consoleDeploymentUrl);
        }

        public void ConfigureVirtualDirectories(string virtualDirectoriesTree, string appPath)
        {
            var iisEngine = new IISEngine(_clientsDeploymentSetupEngine.Logger);
            const string defaultSiteName = "Default Web Site";;

            iisEngine.ConfigureVirtualDirectories(defaultSiteName, virtualDirectoriesTree, appPath);
        }

        public void ConfigureInterviewerConsoleXmlFiles(string interviewerConsoleConfigPath, string interviewerConsoleApplicationPath, string interviewerConsoleManifestPath,
            string catiServer, string interviewerConsoleDeploymentManifestUrl, string assemblyIdentityName, string environmentName)
        {
            _configsEngine.ConfigureInterviewerConsoleManifestFiles(interviewerConsoleConfigPath, interviewerConsoleApplicationPath, interviewerConsoleManifestPath, catiServer,
                interviewerConsoleDeploymentManifestUrl, assemblyIdentityName, environmentName);
        }

        public void ConfigureMonitoringConsoleXmlFiles(string monitoringConsoleConfigPath, string monitoringConsoleApplicationPath, string monitoringConsoleManifestPath,
            string catiServer, string monitoringConsoleDeploymentManifestUrl, string assemblyIdentityName, string environmentName)
        {
            _configsEngine.ConfigureMonitoringConsoleManifestFiles(monitoringConsoleConfigPath, monitoringConsoleApplicationPath, monitoringConsoleManifestPath, catiServer,
                monitoringConsoleDeploymentManifestUrl, assemblyIdentityName, environmentName);
        }
    }
}
