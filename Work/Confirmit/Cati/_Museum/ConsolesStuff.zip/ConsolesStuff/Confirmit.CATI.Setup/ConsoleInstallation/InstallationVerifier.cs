﻿using System;
using System.Data.SqlClient;
using System.Diagnostics;
using Confirmit.CATI.Installation.Common;
using Confirmit.CATI.Installation.Common.Interfaces;
using ConsoleInstallation.Properties;

namespace ConsoleInstallation
{
    public class InstallationVerifier
    {
        private readonly ILogger _logger;
        private readonly IPrereqChecker _prereqChecker;
        private readonly IConfirmitCATIValidator _confirmitCatiValidator;
        private readonly ICertificateEngine _certificateEngine;

        public InstallationVerifier(ILogger logger, IPrereqChecker prereqChecker, IConfirmitCATIValidator confirmitCatiValidator, ICertificateEngine certificateEngine)
        {
            _logger = logger;
            _prereqChecker = prereqChecker;
            _confirmitCatiValidator = confirmitCatiValidator;
            _certificateEngine = certificateEngine;
        }

        public void VerifyConsoleParameters(ConsoleParameters consoleParameters)
        {
            CheckPrerequisites();

            VerifyVirtualDirectory(consoleParameters.InterviewerAliasName);
            VerifyVirtualDirectory(consoleParameters.MonitoringAliasName);

            VerifyCatiAndDeploymentServers(consoleParameters.CatiServerName, consoleParameters.DeploymentServerName);

            _certificateEngine.VerifyCertificateFromFile(consoleParameters.CertificatePath, consoleParameters.CertificatePassword);

            _confirmitCatiValidator.ValidatePossibleFileName(consoleParameters.EnvironmentName);

            VerifyCatiConnectionString(consoleParameters.CatiConnectionString);
        }        

        private void CheckPrerequisites()
        {
            _logger.WriteLog(true, "CheckPrerequisites");

            _prereqChecker.VerifyIsFramework462Installed();
        }

        private void VerifyVirtualDirectory(string aliasName)
        {
            _logger.WriteLog(true, "VerifyVirtualDirectory");
            _logger.WriteLog(true, "aliasName={0}", aliasName);

            if (string.IsNullOrEmpty(aliasName))
            {
                throw new ValidateException(Resources.EmptyVirtualDirectory);
            }

            if (aliasName.Contains("?") || aliasName.Contains(";") || aliasName.Contains(":") || aliasName.Contains("@") || aliasName.Contains("&") ||
                aliasName.Contains("=") || aliasName.Contains("+") || aliasName.Contains("$") || aliasName.Contains(",") || aliasName.Contains("|") || 
                aliasName.Contains("\"") || aliasName.Contains("<") || aliasName.Contains(">") || aliasName.Contains("*"))
            {
                throw new ValidateException(Resources.VirtualDirectoryContainsWrongCharacters);
            }
        }

        private void VerifyCatiAndDeploymentServers(string catiServerName, string deploymentServerName)
        {
            _logger.WriteLog(true, "VerifyCatiAndDeploymentServers");
            _logger.WriteLog(true, "catiServerName={0}\r\ndeploymentServerName={1}", catiServerName, deploymentServerName);

            if (string.IsNullOrEmpty(catiServerName))
            {
                throw new ValidateException("CatiServerName property cannot be empty");
            }

            if (string.IsNullOrEmpty(deploymentServerName))
            {
                throw new ValidateException("DeploymentServerName property cannot be empty");
            }
        }

        private void VerifyCatiConnectionString(string catiConnectionString)
        {
            _logger.WriteLog(true, "VerifyCatiConnectionString");
            _logger.WriteLog(true, "catiConnectionString={0}", catiConnectionString);

            try
            {
                var sqlConnBuilder = new SqlConnectionStringBuilder(catiConnectionString);

                _confirmitCatiValidator.ValidateSqlServerConnection(sqlConnBuilder.DataSource, sqlConnBuilder.UserID, sqlConnBuilder.Password);
            }
            catch (Exception ex)
            {
                _logger.WriteLog(false, TraceEventType.Warning, "An error occured during VerifyCatiConnectionString:\r\n{0}", ex);
                throw new ValidateException("An error occured during verification of CatiConnectionString:\r\n" + ex.Message, ex);
            }
        }
    }
}
