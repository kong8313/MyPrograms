﻿using System.Diagnostics;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;
using System.Threading;
using Confirmit.CATI.Installation.Common;
using Confirmit.CATI.Installation.Common.Interfaces;

namespace ConsoleInstallation
{
    public class ClientsDeploymentSetupEngine
    {
        public ILogger Logger { get; private set; }
        private readonly IExternalInvoker _externalInvoker;
       
        public ClientsDeploymentSetupEngine(ILogger logger)
            : this(logger, new ExternalInvoker(logger))
        {

        }
        public ClientsDeploymentSetupEngine(ILogger logger, IExternalInvoker externalInvoker)            
        {
            Logger = logger;
            _externalInvoker = externalInvoker;
        }

        /// <summary>
        /// Look at publish.html file and set currect version 
        /// into $version$ placeholder
        /// </summary>        
        /// <param name="infoHtmlFilePath">Path to publish.html or default.htm file</param>
        /// <param name="version">New version</param>
        public void ChangeVersionInPublishFile(string infoHtmlFilePath, string version)
        {
            Logger.WriteLog("Begin ChangeVersionInPublishFile\r\ninfoHtmlFilePath = {0}\r\nversion = {1}", infoHtmlFilePath, version);

            try
            {
                string newSpan = "<span Id=\"AutomaticallyChangedCurrentVersion\">" + version + "</span>";
                const string pattern = "<span.*AutomaticallyChangedCurrentVersion.*</span>";

                UpdateFileContent(infoHtmlFilePath, pattern, newSpan);
            }
            finally
            {
                Logger.WriteLog("End ChangeVersionInPublishFile");
            }
        }

        /// <summary>
        /// Look at default.html file and set currect console name 
        /// into $name$ placeholder
        /// </summary>        
        /// <param name="infoHtmlFilePath">Path to default.htm file</param>
        /// <param name="isInterviewerConsole">Shows if current console is interviewer console (or monitoring console if false)</param>
        public void ChangeConsoleNameInDefaultFile(string infoHtmlFilePath, bool isInterviewerConsole)
        {
            Logger.WriteLog("Begin ChangeConsoleNameInPublishFile\r\ninfoHtmlFilePath = {0}\r\nisInterviewerConsole = {1}", infoHtmlFilePath, isInterviewerConsole);

            try
            {
                string name = isInterviewerConsole ? "Interviewer" : "Monitoring";
                string newSpan = "<span Id=\"AutomaticallyChangedConsoleName\">" + name + "</span>";
                const string pattern = "<span.*AutomaticallyChangedConsoleName.*</span>";

                UpdateFileContent(infoHtmlFilePath, pattern, newSpan);
            }
            finally
            {
                Logger.WriteLog("End ChangeConsoleNameInPublishFile");
            }
        }

        private void UpdateFileContent(string infoHtmlFilePath, string pattern, string newSpan)
        {
            if (!File.Exists(infoHtmlFilePath))
            {
                Logger.WriteLog("File is not exist");
                return;
            }

            string publishFileText = File.ReadAllText(infoHtmlFilePath);
            var regex = new Regex(pattern, RegexOptions.IgnoreCase);
            publishFileText = regex.Replace(publishFileText, newSpan);

            File.WriteAllText(infoHtmlFilePath, publishFileText);
        }


        /// <summary>
        /// Delete the file and write information in log
        /// </summary>        
        /// <param name="fileName">File path for delete</param>
        public void DeleteFileWithLogging(string fileName)
        {
            if (File.Exists(fileName))
            {
                Logger.WriteLog("Delete file {0}", fileName);
                File.Delete(fileName);
            }
        }


        /// <summary>
        /// Remove the file and write information in log
        /// </summary>        
        /// <param name="sourceFileName">Sourse file path</param>
        /// <param name="destFileName">Destination file path</param>
        public void CopyFileWithLogging(string sourceFileName, string destFileName)
        {
            Logger.WriteLog("Copy file from\r\n {0}\r\nto\r\n{1}", sourceFileName, destFileName);

            File.Copy(sourceFileName, destFileName, true);
        }

        /// <summary>
        /// Method is used from InterviewerConsoleDeploy.ps1 and MonitoringConsoleDeploy.ps1 scripts. Do not remove
        /// </summary>
        /// <param name="aliasName"></param>
        /// <returns></returns>
        public string ReturnAsUrl(string aliasName)
        {
            return aliasName.Replace(@"\", @"/");
        }

        /// <summary>
        /// Wait, while setup.exe is changing. Wait no longer than 10 sec.
        /// </summary>
        /// <param name="initCntOfProcesses"></param>
        public void WaitSetupTransforming(int initCntOfProcesses)
        {
            Logger.WriteLog("Start WaitSetupTransforming\r\ninitCntOfProcesses={0}", initCntOfProcesses);

            int i;
            for (i = 0; i < 200; i++)
            {
                Thread.Sleep(50);

                int currentCntOfProcesses = Process.GetProcessesByName("setup").Length;
                Logger.WriteLog("currentCntOfProcesses={0}", currentCntOfProcesses);

                if (currentCntOfProcesses == initCntOfProcesses)
                {
                    break;
                }
            }

            Logger.WriteLog("End WaitSetupTransforming\r\ni={0}", i);
        }

        private void UpdateManifestFile(string mageFilePath, string manifestPath)
        {
            _externalInvoker.Invoke(mageFilePath, string.Format("-u \"{0}\"", manifestPath));
        }

        private void SignManifestFile(string mageFilePath, string manifestPath, string mageCertificateArguments)
        {
            _externalInvoker.Invoke(mageFilePath, string.Format("-u \"{0}\" {1}", manifestPath, mageCertificateArguments));
        }

        private void SignApplicationFile(string mageFilePath, string applicationPath, string manifestPath, string mageCertificateArguments, string productVersion)
        {
            _externalInvoker.Invoke(
                mageFilePath, string.Format("-u \"{0}\" -appm \"{1}\" {2} -pub \"Forsta\" -mv {3}", applicationPath, manifestPath, mageCertificateArguments, productVersion));
        }        

        public void RemoveDirectory(string directoryPath)
        {
            if (Directory.Exists(directoryPath))
            {
                foreach (var filePath in Directory.GetFiles(directoryPath))
                {
                    File.Delete(filePath);
                }

                Directory.Delete(directoryPath);
            }
        }

        private void CreateCopyOfEachDeployFile(string currentDirectoryPath)
        {
            foreach (var directoryPath in Directory.GetDirectories(currentDirectoryPath))
            {
                CreateCopyOfEachDeployFile(directoryPath);
            }

            foreach (var filePath in Directory.GetFiles(currentDirectoryPath))
            {
                if (filePath.EndsWith(".deploy"))
                {
                    CopyFileWithLogging(filePath, filePath.Replace(".deploy", ""));
                }
            }
        }

        private void RemoveAllFilesWithDeployTwin(string currentDirectoryPath)
        {
            foreach (var directoryPath in Directory.GetDirectories(currentDirectoryPath))
            {
                RemoveAllFilesWithDeployTwin(directoryPath);
            }

            foreach (var filePath in Directory.GetFiles(currentDirectoryPath))
            {
                if (!filePath.EndsWith(".deploy") && File.Exists(filePath + ".deploy"))
                {
                    DeleteFileWithLogging(filePath);
                }
            }
        }

        public void SignClickOnceFiles(string mageFilePath, string mageCertificateArguments, string deploymentFolderPath, 
            string applicationPath, string manifestPath, string productVersion, string environmentName, bool supportMultiInstallation)
        {
            CreateCopyOfEachDeployFile(deploymentFolderPath);

            UpdateManifestFile(mageFilePath, manifestPath);
            SignManifestFile(mageFilePath, manifestPath, mageCertificateArguments);
            SignApplicationFile(mageFilePath, applicationPath, manifestPath, mageCertificateArguments, productVersion);

            if (supportMultiInstallation)
            {
                string envApplicationPath = applicationPath.Replace(".application", "New.application");
                string envManifestPath = manifestPath.Replace(".exe.manifest", string.Format("{0}.exe.manifest", environmentName));

                UpdateManifestFile(mageFilePath, envManifestPath);
                SignManifestFile(mageFilePath, envManifestPath, mageCertificateArguments);
                SignApplicationFile(mageFilePath, envApplicationPath, envManifestPath, mageCertificateArguments, productVersion);
            }

            RemoveAllFilesWithDeployTwin(deploymentFolderPath);
        }

        public void ChangeUrlForSetupExe(X509Certificate2 signCertificate, string installLocation, string consoleDeploymentUrl)
        {
            Thread.Sleep(1000);
            int initCountOfProcesses = Process.GetProcessesByName("setup").Length;
            string setupFilePath = Path.Combine(installLocation, "setup.exe");
            string tempSetupFilePath = Path.Combine(installLocation, "temp_setup.exe");

            File.Copy(setupFilePath, tempSetupFilePath);

            _externalInvoker.Invoke(tempSetupFilePath, string.Format("-dest=\"{0}\" -url={1}", setupFilePath, consoleDeploymentUrl));

            WaitSetupTransforming(initCountOfProcesses);

            File.Delete(tempSetupFilePath);
        }
    }
}
