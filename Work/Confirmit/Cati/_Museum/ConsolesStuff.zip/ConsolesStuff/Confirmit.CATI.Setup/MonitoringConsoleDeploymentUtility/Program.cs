﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Threading;

namespace MonitoringConsoleDeploymentUtility
{
    class Program
    {
        private const string SecretCatiMonitoringConsoleDownload = "Confirmit__Site__Url__CatiMonitoringConsoleDownload";
        private const string SigningCertificateThumbprint = "A07A0A62EF45855250B0CD5D1540BC793DE58891";

        private static IExternalInvoker _externalInvoker;
        private static IConfigsEngine _configsEngine;
        private static IClickOnceSigningTool _clickOnceSigningTool;

        private static string _startupPath;
        private static string _fileVersion;
        private static string _consoleDeploymentUrl;

        public static int Main()
        {
            try
            {
                _externalInvoker = new ExternalInvoker();
                _configsEngine = new ConfigsEngine();
                _clickOnceSigningTool = new ClickOnceSigningTool(_externalInvoker);

                Console.WriteLine("MonitoringConsoleDeploymentUtility helps to deploy Monitoring Console on docker.");
                Console.WriteLine("It doesn't require any parameters just put the folder with it near setup.exe file in publish folder and run.");
                Console.WriteLine($"But it requires a secret (or env) variable '{SecretCatiMonitoringConsoleDownload}' and signing certificate with '{SigningCertificateThumbprint}' thumbprint in personal local machine certificate storage.");
                Console.WriteLine("The utility sign manifest and application files by mage.exe utility, change url of setup.exe file and sign it.");

                new Program().Start();

                Console.WriteLine("Execution has finished successfully");

                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred during execution:\r\n" + ex);

                return 1;
            }
        }

        private void Start()
        {
            var assembly = Assembly.GetExecutingAssembly();
            _startupPath = Path.GetDirectoryName(assembly.Location) ?? string.Empty;
            _consoleDeploymentUrl = GetEnvOrSecretConfigValue(SecretCatiMonitoringConsoleDownload);

            _fileVersion = FileVersionInfo.GetVersionInfo(assembly.Location).FileVersion;

            SignClickOnceFiles();

            ChangeUrl();
        }

        private void SignClickOnceFiles()
        {
            Console.WriteLine("Signing click once files");

            var rootPath = Path.GetFullPath(Path.Combine(_startupPath, "..\\"));
            var versionFolderName = $"CatiSupervisorPlayer_{_fileVersion.Replace(".", "_")}";
            var manifestFilePath = Path.Combine(rootPath, "Application Files", versionFolderName, "CatiSupervisorPlayer.exe.manifest");
            CheckFileExist(manifestFilePath);

            var applicationFilePath = Path.Combine(rootPath, "CatiSupervisorPlayer.application");
            CheckFileExist(applicationFilePath);

            var mageFilePath = Path.Combine(_startupPath, "mage.exe");
            CheckFileExist(mageFilePath);

            var consoleDeploymentManifestUrl = _consoleDeploymentUrl.TrimEnd('/') + "/CatiSupervisorPlayer.application";
            _configsEngine.ConfigureApplicationFile(applicationFilePath, consoleDeploymentManifestUrl);

            var mageCertificateArguments = $"-ch {SigningCertificateThumbprint} -a sha256RSA";
            _clickOnceSigningTool.SignClickOnceFiles(mageFilePath, mageCertificateArguments, rootPath, applicationFilePath, manifestFilePath, _fileVersion);
        }

        private void ChangeUrl()
        {
            Console.WriteLine("Changing url of setup.exe");

            var setupExePath = Path.Combine(_startupPath, "..\\setup.exe");
            CheckFileExist(setupExePath);

            int initCountOfProcesses = Process.GetProcessesByName("setup").Length;

            string tempSetupFilePath = setupExePath + "_temp.exe";

            File.Copy(setupExePath, tempSetupFilePath);

            _externalInvoker.Invoke(tempSetupFilePath, $"-dest=\"{setupExePath}\" -url={_consoleDeploymentUrl}");

            WaitSetupTransforming(initCountOfProcesses);

            File.Delete(tempSetupFilePath);
        }

        /// <summary>
        /// Wait, while setup.exe is changing. Wait no longer than 10 sec.
        /// </summary>
        /// <param name="initCntOfProcesses"></param>
        public void WaitSetupTransforming(int initCntOfProcesses)
        {
            int i;
            for (i = 0; i < 200; i++)
            {
                Thread.Sleep(50);

                int currentCntOfProcesses = Process.GetProcessesByName("setup").Length;
                Console.WriteLine($"Wait transforming (#{currentCntOfProcesses})");

                if (currentCntOfProcesses == initCntOfProcesses)
                {
                    break;
                }
            }
        }

        private string GetEnvOrSecretConfigValue(string variableName)
        {
            var secretsPath = Path.Combine(@"c:\etc\confirmit\secrets", variableName);
            var result = File.Exists(secretsPath) ? File.ReadAllText(secretsPath) : Environment.GetEnvironmentVariable(variableName);

            if (string.IsNullOrEmpty(result))
            {
                throw new Exception($"Secret or environment variable {variableName} has not been defined.");
            }

            return result;
        }

        private void CheckFileExist(string path)
        {
            if (!File.Exists(path))
            {
                throw new Exception($"File '{path}' has not been found.");
            }
        }
    }
}
