﻿namespace MonitoringConsoleDeploymentUtility
{
    public interface IClickOnceSigningTool
    {
        void SignClickOnceFiles(string mageFilePath, string mageCertificateArguments, string rootPath, string applicationPath, string manifestPath, string productVersion);
    }
}