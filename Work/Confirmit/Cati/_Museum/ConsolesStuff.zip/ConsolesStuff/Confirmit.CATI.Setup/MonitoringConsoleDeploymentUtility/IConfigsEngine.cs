﻿namespace MonitoringConsoleDeploymentUtility
{
    public interface IConfigsEngine
    {
        void ConfigureApplicationFile(string consoleApplicationPath, string consoleDeploymentManifestUrl);
    }
}