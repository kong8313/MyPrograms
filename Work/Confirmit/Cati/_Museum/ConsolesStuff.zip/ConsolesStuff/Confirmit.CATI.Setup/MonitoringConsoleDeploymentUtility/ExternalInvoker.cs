﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace MonitoringConsoleDeploymentUtility
{
    public class ExternalInvoker : IExternalInvoker
    {
        private readonly int _successCode;

        public ExternalInvoker(int successCode = 0)
        {
            _successCode = successCode;
        }

        /// <summary>
        /// Run external script
        /// </summary>
        /// <param name="scriptNameOrPath">The name or path of the external script</param>
        /// <param name="args">Thread arguments</param>
        public string Invoke(string scriptNameOrPath, string args)
        {
            Console.WriteLine($"Call '{scriptNameOrPath} {args}'");

            using (var scriptProcess = new Process())
            {
                var pInfo = new ProcessStartInfo(scriptNameOrPath, args)
                {
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };

                scriptProcess.StartInfo = pInfo;
                scriptProcess.Start();

                var outputTask = new Task<string>(() => scriptProcess.StandardOutput.ReadToEnd());
                var errorTask = new Task<string>(() => scriptProcess.StandardError.ReadToEnd());

                outputTask.Start();
                errorTask.Start();

                scriptProcess.WaitForExit();

                PrintIfEny(outputTask.Result, "output");
                PrintIfEny(errorTask.Result, "error output");

                if (_successCode != scriptProcess.ExitCode)
                {
                    var internalErrorInfo = string.IsNullOrEmpty(errorTask.Result) ? "No information" : errorTask.Result;
                    throw new Exception($"Error executing {scriptNameOrPath}\r\nExit code {scriptProcess.ExitCode} is wrong\r\nInternal error:\r\n{internalErrorInfo}");
                }

                return outputTask.Result;
            }
        }

        private void PrintIfEny(string message, string title)
        {
            if (!string.IsNullOrWhiteSpace(message))
            {
                Console.WriteLine(title + ": " + message);
            }
        }
    }
}