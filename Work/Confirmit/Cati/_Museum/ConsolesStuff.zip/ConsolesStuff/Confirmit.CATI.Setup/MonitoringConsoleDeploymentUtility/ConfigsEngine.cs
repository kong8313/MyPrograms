﻿using System.Xml;

namespace MonitoringConsoleDeploymentUtility
{
    public class ConfigsEngine : IConfigsEngine
    {
        private void SetAttribute(
            XmlDocument xmlDocument, string xpath, string attributeName, string attributeValue,
            XmlNamespaceManager nsmgr, bool doNotLogValue = false, string attributeNamespace = null)
        {
            var selectedNode = (XmlElement) xmlDocument.SelectSingleNode(xpath, nsmgr);

            if (selectedNode != null)
            {
                if (string.IsNullOrEmpty(attributeNamespace))
                {
                    selectedNode.SetAttribute(attributeName, attributeValue);
                }
                else
                {
                    selectedNode.SetAttribute(attributeName, attributeNamespace, attributeValue);
                }
            }
        }

        /// <summary>
        /// Configure application file for consoles
        /// </summary>
        /// <param name="consoleApplicationPath">Path to application file</param>
        /// <param name="consoleDeploymentManifestUrl">Cati console deployment manifest url</param>
        public void ConfigureApplicationFile(string consoleApplicationPath, string consoleDeploymentManifestUrl)
        {
            var xmlDocument = new XmlDocument
            {
                PreserveWhitespace = true
            };
            xmlDocument.Load(consoleApplicationPath);

            var nsMgr = new XmlNamespaceManager(xmlDocument.NameTable);
            nsMgr.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
            nsMgr.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");

            SetAttribute(xmlDocument, "//asmv1:assembly/asmv2:deployment/asmv2:deploymentProvider", "codebase", consoleDeploymentManifestUrl, nsMgr);

            xmlDocument.PreserveWhitespace = false;
            xmlDocument.Save(consoleApplicationPath);
        }
    }
}