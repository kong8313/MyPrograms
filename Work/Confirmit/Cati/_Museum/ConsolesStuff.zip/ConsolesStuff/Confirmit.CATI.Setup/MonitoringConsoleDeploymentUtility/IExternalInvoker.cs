﻿namespace MonitoringConsoleDeploymentUtility
{
    public interface IExternalInvoker
    {
        /// <summary>
        /// Run external script
        /// </summary>
        /// <param name="scriptNameOrPath">The name or path of the external script</param>
        /// <param name="args">Thread arguments</param>
        string Invoke(string scriptNameOrPath, string args);
    }
}