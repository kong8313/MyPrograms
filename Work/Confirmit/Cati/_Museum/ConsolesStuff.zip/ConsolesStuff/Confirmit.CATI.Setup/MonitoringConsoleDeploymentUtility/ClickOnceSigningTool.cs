﻿using System.IO;

namespace MonitoringConsoleDeploymentUtility
{
    public class ClickOnceSigningTool : IClickOnceSigningTool
    {
        private readonly IExternalInvoker _externalInvoker;

        public ClickOnceSigningTool(IExternalInvoker externalInvoker)
        {
            _externalInvoker = externalInvoker;
        }

        private void UpdateManifestFile(string mageFilePath, string manifestPath)
        {
            _externalInvoker.Invoke(mageFilePath, $"-u \"{manifestPath}\"");
        }

        private void SignManifestFile(string mageFilePath, string manifestPath, string mageCertificateArguments)
        {
            _externalInvoker.Invoke(mageFilePath, $"-u \"{manifestPath}\" {mageCertificateArguments}");
        }

        private void SignApplicationFile(string mageFilePath, string applicationPath, string manifestPath, string mageCertificateArguments, string productVersion)
        {
            _externalInvoker.Invoke(mageFilePath, $"-u \"{applicationPath}\" -appm \"{manifestPath}\" {mageCertificateArguments} -pub \"Confirmit\" -mv {productVersion}");
        }

        private void CreateCopyOfEachDeployFile(string currentDirectoryPath)
        {
            foreach (var directoryPath in Directory.GetDirectories(currentDirectoryPath))
            {
                CreateCopyOfEachDeployFile(directoryPath);
            }

            foreach (var filePath in Directory.GetFiles(currentDirectoryPath))
            {
                if (filePath.EndsWith(".deploy"))
                {
                    File.Copy(filePath, filePath.Replace(".deploy", ""), true);
                }
            }
        }

        private void RemoveAllFilesWithDeployTwin(string currentDirectoryPath)
        {
            foreach (var directoryPath in Directory.GetDirectories(currentDirectoryPath))
            {
                RemoveAllFilesWithDeployTwin(directoryPath);
            }

            foreach (var filePath in Directory.GetFiles(currentDirectoryPath))
            {
                if (!filePath.EndsWith(".deploy") && File.Exists(filePath + ".deploy"))
                {
                    File.Delete(filePath);
                }
            }
        }

        public void SignClickOnceFiles(string mageFilePath, string mageCertificateArguments, string rootPath, string applicationPath, string manifestPath, string productVersion)
        {
            CreateCopyOfEachDeployFile(rootPath);

            UpdateManifestFile(mageFilePath, manifestPath);
            SignManifestFile(mageFilePath, manifestPath, mageCertificateArguments);
            SignApplicationFile(mageFilePath, applicationPath, manifestPath, mageCertificateArguments, productVersion);

            RemoveAllFilesWithDeployTwin(rootPath);
        }
    }
}