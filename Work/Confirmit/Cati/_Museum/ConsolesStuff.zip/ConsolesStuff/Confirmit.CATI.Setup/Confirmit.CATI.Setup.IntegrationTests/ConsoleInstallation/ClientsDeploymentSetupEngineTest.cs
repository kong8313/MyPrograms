﻿using System.IO;
using System.Reflection;
using Confirmit.CATI.Installation.Common;
using Confirmit.CATI.Installation.Common.Interfaces;
using ConsoleInstallation;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Setup.IntegrationTests.ConsoleInstallation
{
    [TestClass]
    public class ClientsDeploymentSetupEngineTest
    {
        public TestContext TestContext { get; set; }

        private ILogger _logger;
        private ClientsDeploymentSetupEngine _setupEngine;

        private const string UniqueVersion = "1.2.3.4";
        private string _testLocation;

        [TestInitialize]
        public void TestInitialize()
        {
            _logger = new TraceLogger();
            _setupEngine = new ClientsDeploymentSetupEngine(_logger);

            _testLocation = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? string.Empty;
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void ChangeVersionInPublishFile_FileNotExists_NoException()
        {
            const string notExistedFilePath = @"c:\NotExistedDirectoryForRemoveDirectoryTest.html";
            _setupEngine.ChangeVersionInPublishFile(notExistedFilePath, UniqueVersion);
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void RemoveDirectory_RemoveDirecotryWithFiles_DirectoryIsRemoved()
        {
            string testLocation = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? string.Empty;
            string testDirectory = Path.Combine(testLocation, "DirectoryForRemoveDirectoryTest");
            Directory.CreateDirectory(testDirectory);
            for (int i = 1; i < 4; i++)
            {
                File.WriteAllText(Path.Combine(testDirectory, string.Format("File{0}.txt", i)), @"File content " + i);
            }

            _setupEngine.RemoveDirectory(testDirectory);

            Assert.IsFalse(Directory.Exists(testDirectory));
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void RemoveDirectory_RemoveNotExistedDirecotry_NoException()
        {
            const string notExistedDirectory = @"c:\NotExistedDirectoryForRemoveDirectoryTest";
            _setupEngine.RemoveDirectory(notExistedDirectory);
        }

        private void TestChangeVersionInPublishFileMethod(string filepathToTest)
        {
            string testDirectoryPath = Path.Combine(_testLocation, "ChangeVersionInPublishFileTest");
            string testHtmlFilePath = Path.Combine(testDirectoryPath, "test.html");
            try
            {
                if (!Directory.Exists(testDirectoryPath))
                {
                    Directory.CreateDirectory(testDirectoryPath);
                }

                File.Copy(filepathToTest, testHtmlFilePath);

                _setupEngine.ChangeVersionInPublishFile(testHtmlFilePath, UniqueVersion);

                bool isFileContainVersion = File.ReadAllText(testHtmlFilePath).Contains(UniqueVersion);
                Assert.IsTrue(isFileContainVersion);
            }
            finally
            {
                if (File.Exists(testHtmlFilePath))
                {
                    File.Delete(testHtmlFilePath);
                }

                if (Directory.Exists(testDirectoryPath))
                {
                    Directory.Delete(testDirectoryPath);
                }
            }
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void ChangeVersionInPublishFile_ChangeVersionInDefaultHtmFile_VersionHasChangedSuccessfully()
        {
            string pathToTestedHtmlFile = Path.Combine(_testLocation, @"..\_3rdpart\ConsolesBrandedPages\default.htm");

            TestChangeVersionInPublishFileMethod(pathToTestedHtmlFile);
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void ChangeVersionInPublishFile_ChangeVersionInInterviewerConsolePublishHtmlFile_VersionHasChangedSuccessfully()
        {
            string pathToTestedHtmlFile = Path.Combine(_testLocation, @"..\_3rdpart\ConsolesDefaultPages\CatiConsolePublish.html");

            TestChangeVersionInPublishFileMethod(pathToTestedHtmlFile);
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void ChangeVersionInPublishFile_ChangeVersionInMonitoringConsolePublishHtmlFile_VersionHasChangedSuccessfully()
        {
            string pathToTestedHtmlFile = Path.Combine(_testLocation, @"..\_3rdpart\ConsolesDefaultPages\MontoringPlayerPublish.html");

            TestChangeVersionInPublishFileMethod(pathToTestedHtmlFile);
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void ChangeVersionInPublishFile_CreateTestHtmlFileWithoutVersionSpan_VersionHasNotChanged()
        {
            string testHtmlFilePath = Path.Combine(_testLocation, "_ChangeVersionInPublishFileTest.html");

            try
            {
                File.WriteAllText(testHtmlFilePath, @"
<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<head>
<title>Confirmit CATI Console Download</title>
<h1>Confirmit Console Download</h1>
<b>Installer for</b>: Confirmit CATI Console<br>

<b>Current version</b>: 17.0.1.0<br>
<br>
The following components are required:
Note: Windows XP SP2 is the minimum Windows version supported by .NET 4.0.<br><br>
Click the link below and run the setup to install the system requirements and run the console. Several reboots may be required. 
<br><br>
</body>");
                _setupEngine.ChangeVersionInPublishFile(testHtmlFilePath, UniqueVersion);

                bool isFileContainVersion = File.ReadAllText(testHtmlFilePath).Contains(UniqueVersion);
                Assert.IsFalse(isFileContainVersion);
            }
            finally
            {
                if (File.Exists(testHtmlFilePath))
                {
                    File.Delete(testHtmlFilePath);
                }
            }
        }
    }
}
