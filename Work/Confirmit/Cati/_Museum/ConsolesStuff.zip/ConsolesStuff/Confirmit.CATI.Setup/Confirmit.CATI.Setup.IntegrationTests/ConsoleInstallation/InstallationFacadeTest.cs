﻿using System.IO;
using System.Reflection;
using Confirmit.CATI.Installation.Common;
using Confirmit.CATI.Installation.Common.Interfaces;
using ConsoleInstallation;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Setup.IntegrationTests.ConsoleInstallation
{
    [TestClass]
    public class InstallationFacadeTest
    {
        private ILogger _logger;
        private InstallationFacade _installationFacade;

        private string _testDirectory;
        string _defaultHtmFilePath;
        string _publishHtmlFilePath;
        string _targetImagesDirectoryPath;

        [TestInitialize]
        public void TestInitialize()
        {
            _logger = new TraceLogger();
            _installationFacade = new InstallationFacade(_logger);

            string testLocation = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? string.Empty;
            _testDirectory = Path.Combine(testLocation, "SetupDefaultPageTest");
            _defaultHtmFilePath = Path.Combine(_testDirectory, "default.htm");
            _publishHtmlFilePath = Path.Combine(_testDirectory, "publish.html");
            _targetImagesDirectoryPath = Path.Combine(_testDirectory, "images");

        }

        private void PrepareTestDirecotry()
        {
            if(Directory.Exists(_testDirectory))
            {
                DeleteTestDirectory();
            }

            Directory.CreateDirectory(_testDirectory);

            File.Copy(
                Path.Combine(_testDirectory, @"..\..\_3rdpart\ConsolesBrandedPages\default.htm"), _defaultHtmFilePath);
            File.Copy(
                Path.Combine(_testDirectory, @"..\..\_3rdpart\ConsolesDefaultPages\CatiConsolePublish.html"), _publishHtmlFilePath);

            string sourceImagesDirectoryPath = Path.Combine(_testDirectory, @"..\..\_3rdpart\ConsolesBrandedPages\images");            
                
            Directory.CreateDirectory(_targetImagesDirectoryPath);
            foreach (var filePath in Directory.GetFiles(sourceImagesDirectoryPath))
            {
                File.Copy(filePath, Path.Combine(_targetImagesDirectoryPath, Path.GetFileName(filePath)));
            }
        }

        private void DeleteTestDirectory()
        {
            if (Directory.Exists(_targetImagesDirectoryPath))
            {
                foreach (var filePath in Directory.GetFiles(_targetImagesDirectoryPath))
                {
                    File.Delete(filePath);
                }

                Directory.Delete(_targetImagesDirectoryPath);
            }

            if(File.Exists(_defaultHtmFilePath))
            {
                File.Delete(_defaultHtmFilePath);
            }


            if (File.Exists(_publishHtmlFilePath))
            {
                File.Delete(_publishHtmlFilePath);
            }

            if (Directory.Exists(_testDirectory))
            {
                Directory.Delete(_testDirectory);
            }
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void SetupDefaultPage_InstallConfirmitBrandedPage_NoPublishHtmlFileButConfirmitBrandedPageFilesExist()
        {
            try
            {
                PrepareTestDirecotry();

                _installationFacade.SetupDefaultPage(_testDirectory, "1.2.3.4", true, true);

                Assert.IsTrue(File.Exists(_defaultHtmFilePath));
                Assert.IsTrue(Directory.Exists(_targetImagesDirectoryPath));
                Assert.IsFalse(File.Exists(_publishHtmlFilePath));
            }
            finally
            {
                DeleteTestDirectory();
            }
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void SetupDefaultPage_InstallDefaultPage_NoConfirmitBrandedPageFilesButPublishHtmlFileExist()
        {
            try
            {
                PrepareTestDirecotry();

                _installationFacade.SetupDefaultPage(_testDirectory, "1.2.3.4", false, true);

                Assert.IsFalse(File.Exists(_defaultHtmFilePath));
                Assert.IsFalse(Directory.Exists(_targetImagesDirectoryPath));
                Assert.IsTrue(File.Exists(_publishHtmlFilePath));
            }
            finally
            {
                DeleteTestDirectory();
            }
        }
    }
}
