﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Input;
using System.Windows.Forms;
using System.Diagnostics;
using System.Drawing;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.UITest.Extension;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;

using System.CodeDom.Compiler;



using Microsoft.VisualStudio.TestTools.UITesting.WinControls;

using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;


namespace Console32ControledEasySurvey
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest]
    public class CodedUITest1
    {
        public CodedUITest1()
        {
        }

        
        /*public partial class MyUI  
        {      static ApplicationUnderTest MyTest = null;   
               public void StartMyTest() 
               {   
                   if (MyTest == null)
                   {
                         
                       MyTest = ApplicationUnderTest.Launch(@"C:\dev\CatiConsole3206052014\CatiInterviewerConsole.exe");
                       MyTest.CloseOnPlaybackCleanup = false; 
                                   
                   }           
               }
        }*/

        static ApplicationUnderTest MyTest = null; //ApplicationUnderTest.Launch(@"C:\dev\CatiConsole3206052014\CatiInterviewerConsole.exe");
        static int n = 0;

        //static ApplicationUnderTest MyTest = ApplicationUnderTest.Launch(@"C:\Users\annak\AppData\Local\Apps\2.0\JE2B0RKD.691\31K4QWO8.07Z\cati..tion_6faeb474800f75ff_0012.0000_25d5d7a47654ab0c\CatiInterviewerConsole.exe");
        

        //[TestMethod]

        //[DataSource("Microsoft.VisualStudio.TestTools.DataSource.XML", "|DataDirectory|\\TestData1.xml", "interview", DataAccessMethod.Sequential), DeploymentItem("TestData1.xml"), TestMethod]
        //[DataSource("Microsoft.VisualStudio.TestTools.DataSource.CSV", "|DataDirectory|\\TestData1.csv", "data#csv", DataAccessMethod.Sequential), DeploymentItem("TestData1.csv"), TestMethod]
        [DeploymentItem("Console32ControledEasySurvey\\TestData1.xml"), DeploymentItem("TestData1.xml"), TestMethod,

        DataSource("Microsoft.VisualStudio.TestTools.DataSource.XML", "|DataDirectory|\\TestData1.xml", "interview", DataAccessMethod.Sequential)]

        


        public void CodedUITestMethod1()
        {
            // To generate code for this test, select "Generate Code for Coded UI Test" from the shortcut menu and select one of the menu items.
            // For more information on generated code, see http://go.microsoft.com/fwlink/?LinkId=179463

            /*MyUI Test1 = new MyUI();
            Test1.StartMyTest(); */

            //ApplicationUnderTest MyTest = null;

            if( n == 0 )
            MyTest = ApplicationUnderTest.Launch(TestContext.DataRow["location"].ToString());

            //MyTest.WaitForControlExist();
            //MyTest.CloseOnPlaybackCleanup = false;



            // login

            this.UIMap.LoginParams.UITbUserEditText = TestContext.DataRow["name"].ToString();
            this.UIMap.LoginParams.UITbPasswordEditSendKeys = TestContext.DataRow["password"].ToString();

            this.UIMap.UILoginWindow.UITbUserWindow.WaitForControlExist();
            this.UIMap.UILoginWindow.UITbUserWindow.WaitForControlReady();
            this.UIMap.Login();

            // click logout after finish button in toolbar
            this.UIMap.UICATIInterviewerConsoWindow.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.WaitForControlEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemWindow.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemWindow.WaitForControlEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemWindow.UIToolStripContainer1Client.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemWindow.UIToolStripContainer1Client.WaitForControlEnabled();

            this.UIMap.ConsoleToolbarEnabled();

            // answer single question
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.WaitForControlEnabled();


            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.SearchConfigurations.Add(SearchConfiguration.ExpandWhileSearching);
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.SearchConfigurations.Add(SearchConfiguration.AlwaysSearch);

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.WaitForControlEnabled();

            this.UIMap.SingleBodyEnabled();

            //this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UICtlformCustom.WaitForControlExist();
            //this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UICtlformCustom.WaitForControlEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UICtlformCustom.UIQ1textsingle1a12a23oPane.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UICtlformCustom.UIQ1textsingle1a12a23oPane.WaitForControlEnabled();

            this.UIMap.SinglePaneEnabled();

            //this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UICtlformCustom.UIItemTable.WaitForControlExist();
            //this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UICtlformCustom.UIItemTable.WaitForControlEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UICtlformCustom.UIItemTable.UIQ1textsingle1a12a23oCell.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UICtlformCustom.UIItemTable.UIQ1textsingle1a12a23oCell.WaitForControlEnabled();

            this.UIMap.SingleCellEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UICtlformCustom.UIQ1textsingle1a12a23oPane1.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UICtlformCustom.UIQ1textsingle1a12a23oPane1.WaitForControlEnabled();

            this.UIMap.SingleQuestionAreaEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UIQ1textsinglePane.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UIQ1textsinglePane.WaitForControlEnabled();

            this.UIMap.SinglelabelEnabled();            



            this.UIMap.SingleLabelTextContentExpectedValues.UIQ1textsinglePaneInnerText = TestContext.DataRow["labelSingle"].ToString();
            this.UIMap.SingleLabelTextContent();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UIOtherRadioButton.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument.UIOtherRadioButton.WaitForControlEnabled();

            this.UIMap.OtherRadioButtonEnabled();

            if (TestContext.DataRow["otherRadioButtonSelected"].ToString() == "true")
            {
                this.UIMap.AnswerSingleParams.UIOtherRadioButtonSelected = true;
                this.UIMap.AnswerSingleParams.UIOtherEditText = TestContext.DataRow["singleOtherText"].ToString();
            }
            else
                this.UIMap.AnswerSingleParams.UIOtherRadioButtonSelected = false;

            this.UIMap.UICATIInterviewerConsoWindow.UITsInterviewToolbarWindow.UIFinishandlogoutButton.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UITsInterviewToolbarWindow.UIFinishandlogoutButton.WaitForControlEnabled();

            this.UIMap.LogoutFinishButtonEnabled();

            this.UIMap.ClickLogoutAfterFinishButton();

            this.UIMap.AnswerSingle();

            // answer multi question
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.WaitForControlEnabled();

            this.UIMap.MultiBodyEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.WaitForControlEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIQ2textmulti1a12a23otPane.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIQ2textmulti1a12a23otPane.WaitForControlEnabled();

            this.UIMap.MultiPaneEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIItemTable.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIItemTable.WaitForControlEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIItemTable.UIQ2textmulti1a12a23otCell.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIItemTable.UIQ2textmulti1a12a23otCell.WaitForControlEnabled();

            this.UIMap.MultCellEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIQ2textmulti1a12a23otPane1.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIQ2textmulti1a12a23otPane1.WaitForControlEnabled();

            this.UIMap.MultiQuestionAreaEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UIQ2textmultiPane.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UIQ2textmultiPane.WaitForControlEnabled();

            this.UIMap.MultiLabelEnabled();

            this.UIMap.MultiLabelTextExpectedValues.UIQ2textmultiPaneInnerText = TestContext.DataRow["labelMulti"].ToString();
            this.UIMap.MultiLabelText();

            if (TestContext.DataRow["otherCheckBoxChecked"].ToString() == "true")
            {
                this.UIMap.AnswerMultiParams.UIOtherCheckBoxChecked = true;
                this.UIMap.AnswerMultiParams.UIOtherEditText = TestContext.DataRow["multiOtherText"].ToString();
            }
            else
                this.UIMap.AnswerMultiParams.UIOtherCheckBoxChecked = false;

            this.UIMap.AnswerMulti();

            // answer numeric question

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIQ3textnumericPane.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIQ3textnumericPane.WaitForControlEnabled();

            this.UIMap.NumericBodyEnabled();
            this.UIMap.NumericPaneEnabled();


            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIItemTable1.UIQ3textnumericCell.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIItemTable1.UIQ3textnumericCell.WaitForControlEnabled();

            this.UIMap.NumericCellEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIQ3textnumericPane1.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIQ3textnumericPane1.WaitForControlEnabled();

            this.UIMap.NumericQuestionAreaEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UIQ3textnumericPane.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UIQ3textnumericPane.WaitForControlEnabled();

            this.UIMap.NumericLabelenabled();

            this.UIMap.NumericLabelTextExpectedValues.UIQ3textnumericPaneInnerText = TestContext.DataRow["labelNum"].ToString();
            this.UIMap.NumericLabelText();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UIQ3textnumericEdit.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UIQ3textnumericEdit.WaitForControlEnabled();

            this.UIMap.NumericEditEnabled();

            this.UIMap.AnswerNumericParams.UIQ3textnumericEditText = TestContext.DataRow["numText"].ToString();
            this.UIMap.AnswerNumeric();

            // answer open question
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIQ4textopenPane.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIQ4textopenPane.WaitForControlEnabled();

            this.UIMap.OpenBodyEnabled();
            this.UIMap.OpenPaneEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIQ4textopenPane1.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UICtlformCustom.UIQ4textopenPane1.WaitForControlEnabled();

            this.UIMap.OpenQuestionAreaEnabled();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UIQ4textopenPane.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UIQ4textopenPane.WaitForControlEnabled();

            this.UIMap.OpenLabelEnabled();

            this.UIMap.OpenLabelTextExpectedValues.UIQ4textopenPaneInnerText = TestContext.DataRow["labelOpen"].ToString();
            this.UIMap.OpenLabelText();

            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UIQ4textopenEdit.WaitForControlExist();
            this.UIMap.UICATIInterviewerConsoWindow.UIItemClient.UIHttpssurveyfelixfirmDocument1.UIQ4textopenEdit.WaitForControlEnabled();

            this.UIMap.AnswerOpenParams.UIQ4textopenEditText = TestContext.DataRow["openText"].ToString();
            this.UIMap.AnswerOpen();

            //ApplicationUnderTest.WaitForControlNotExist(5000);

            /*ApplicationUnderTest appEnd = new ApplicationUnderTest();

            Process[] Myprocesses = Process.GetProcessesByName("ApplicationUnderTest");

            if (Myprocesses.Length > 0)
            {

                appEnd = ApplicationUnderTest.FromProcess(Myprocesses[0]);
                appEnd.WaitForControlNotExist();

            }
             */

            n++;

            if(TestContext.Properties.Count == 0)
                MyTest.WaitForControlNotExist();

                //Playback.Cleanup();


        }

        #region Additional test attributes

        // You can use the following additional attributes as you write your tests:

        ////Use TestInitialize to run code before running each test 
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{        
        //    // To generate code for this test, select "Generate Code for Coded UI Test" from the shortcut menu and select one of the menu items.
        //    // For more information on generated code, see http://go.microsoft.com/fwlink/?LinkId=179463
        //}

        ////Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{        
        //    // To generate code for this test, select "Generate Code for Coded UI Test" from the shortcut menu and select one of the menu items.
        //    // For more information on generated code, see http://go.microsoft.com/fwlink/?LinkId=179463
        //}

        #endregion

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        private TestContext testContextInstance;

        public UIMap UIMap
        {
            get
            {
                if ((this.map == null))
                {
                    this.map = new UIMap();
                }

                return this.map;
            }
        }

        private UIMap map;
    }
}
