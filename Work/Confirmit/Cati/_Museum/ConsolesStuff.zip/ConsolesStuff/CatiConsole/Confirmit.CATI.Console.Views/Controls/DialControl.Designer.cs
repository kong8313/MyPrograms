﻿namespace Confirmit.CATI.Console.Views.Controls
{
    partial class DialControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ltControls = new System.Windows.Forms.TableLayoutPanel();
            this.lbMessage = new System.Windows.Forms.Label();
            this.ltPhone = new System.Windows.Forms.TableLayoutPanel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lbHint = new System.Windows.Forms.Label();
            this.pbProgress = new System.Windows.Forms.PictureBox();
            this.ltControls.SuspendLayout();
            this.ltPhone.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProgress)).BeginInit();
            this.SuspendLayout();
            // 
            // ltControls
            // 
            this.ltControls.ColumnCount = 1;
            this.ltControls.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ltControls.Controls.Add(this.lbMessage, 0, 1);
            this.ltControls.Controls.Add(this.ltPhone, 0, 3);
            this.ltControls.Controls.Add(this.pbProgress, 0, 0);
            this.ltControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ltControls.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ltControls.Location = new System.Drawing.Point(0, 0);
            this.ltControls.Name = "ltControls";
            this.ltControls.RowCount = 4;
            this.ltControls.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.ltControls.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.ltControls.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.ltControls.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.ltControls.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.ltControls.Size = new System.Drawing.Size(500, 355);
            this.ltControls.TabIndex = 0;
            // 
            // lbMessage
            // 
            this.lbMessage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbMessage.AutoSize = true;
            this.lbMessage.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel, ((byte)(204)));
            this.lbMessage.Location = new System.Drawing.Point(3, 174);
            this.lbMessage.Margin = new System.Windows.Forms.Padding(3, 9, 3, 0);
            this.lbMessage.Name = "lbMessage";
            this.lbMessage.Size = new System.Drawing.Size(494, 16);
            this.lbMessage.TabIndex = 1;
            this.lbMessage.Text = "Dialing. Please wait.";
            this.lbMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ltPhone
            // 
            this.ltPhone.ColumnCount = 1;
            this.ltPhone.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ltPhone.Controls.Add(this.btnCancel, 0, 0);
            this.ltPhone.Controls.Add(this.lbHint, 0, 1);
            this.ltPhone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ltPhone.Location = new System.Drawing.Point(0, 195);
            this.ltPhone.Margin = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.ltPhone.Name = "ltPhone";
            this.ltPhone.RowCount = 2;
            this.ltPhone.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.ltPhone.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.ltPhone.Size = new System.Drawing.Size(500, 160);
            this.ltPhone.TabIndex = 2;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnCancel.Location = new System.Drawing.Point(217, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(65, 23);
            this.btnCancel.TabIndex = 0;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lbHint
            // 
            this.lbHint.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbHint.AutoSize = true;
            this.lbHint.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbHint.Location = new System.Drawing.Point(44, 38);
            this.lbHint.Margin = new System.Windows.Forms.Padding(3, 9, 3, 0);
            this.lbHint.Name = "lbHint";
            this.lbHint.Size = new System.Drawing.Size(411, 32);
            this.lbHint.TabIndex = 4;
            this.lbHint.Text = "The Cancel button will attempt to interrupt the current dialing process,\r\nhowever" +
    " there is a chance the call may still be connected.";
            this.lbHint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbProgress
            // 
            this.pbProgress.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.pbProgress.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.progress;
            this.pbProgress.Location = new System.Drawing.Point(226, 114);
            this.pbProgress.Name = "pbProgress";
            this.pbProgress.Size = new System.Drawing.Size(48, 48);
            this.pbProgress.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbProgress.TabIndex = 3;
            this.pbProgress.TabStop = false;
            // 
            // DialControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.ltControls);
            this.Name = "DialControl";
            this.Size = new System.Drawing.Size(500, 355);
            this.ltControls.ResumeLayout(false);
            this.ltControls.PerformLayout();
            this.ltPhone.ResumeLayout(false);
            this.ltPhone.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProgress)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel ltControls;
        private System.Windows.Forms.Label lbMessage;
        private System.Windows.Forms.TableLayoutPanel ltPhone;
        private System.Windows.Forms.PictureBox pbProgress;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lbHint;
    }
}
