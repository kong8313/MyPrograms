﻿namespace Confirmit.CATI.Console.Views.Controls
{
    partial class ProcessControlSmall
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ltControls = new System.Windows.Forms.TableLayoutPanel();
            this.ltProgress = new System.Windows.Forms.TableLayoutPanel();
            this.pbProgress = new System.Windows.Forms.PictureBox();
            this.lbMessage = new System.Windows.Forms.Label();
            this.ltCancel = new System.Windows.Forms.TableLayoutPanel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lbHint = new System.Windows.Forms.Label();
            this.ltControls.SuspendLayout();
            this.ltProgress.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProgress)).BeginInit();
            this.ltCancel.SuspendLayout();
            this.SuspendLayout();
            // 
            // ltControls
            // 
            this.ltControls.ColumnCount = 1;
            this.ltControls.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ltControls.Controls.Add(this.ltProgress, 0, 0);
            this.ltControls.Controls.Add(this.ltCancel, 0, 1);
            this.ltControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ltControls.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ltControls.Location = new System.Drawing.Point(0, 0);
            this.ltControls.Name = "ltControls";
            this.ltControls.RowCount = 2;
            this.ltControls.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ltControls.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.ltControls.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.ltControls.Size = new System.Drawing.Size(425, 150);
            this.ltControls.TabIndex = 0;
            // 
            // ltProgress
            // 
            this.ltProgress.ColumnCount = 1;
            this.ltProgress.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ltProgress.Controls.Add(this.pbProgress, 0, 0);
            this.ltProgress.Controls.Add(this.lbMessage, 0, 1);
            this.ltProgress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ltProgress.Location = new System.Drawing.Point(0, 5);
            this.ltProgress.Margin = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.ltProgress.Name = "ltProgress";
            this.ltProgress.RowCount = 2;
            this.ltProgress.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.ltProgress.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.ltProgress.Size = new System.Drawing.Size(425, 65);
            this.ltProgress.TabIndex = 7;
            // 
            // pbProgress
            // 
            this.pbProgress.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.pbProgress.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.progress;
            this.pbProgress.Location = new System.Drawing.Point(188, 3);
            this.pbProgress.Name = "pbProgress";
            this.pbProgress.Size = new System.Drawing.Size(48, 48);
            this.pbProgress.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbProgress.TabIndex = 4;
            this.pbProgress.TabStop = false;
            // 
            // lbMessage
            // 
            this.lbMessage.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbMessage.AutoSize = true;
            this.lbMessage.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lbMessage.Location = new System.Drawing.Point(169, 54);
            this.lbMessage.Name = "lbMessage";
            this.lbMessage.Size = new System.Drawing.Size(86, 16);
            this.lbMessage.TabIndex = 1;
            this.lbMessage.Text = "Please wait.";
            this.lbMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ltCancel
            // 
            this.ltCancel.ColumnCount = 1;
            this.ltCancel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ltCancel.Controls.Add(this.btnCancel, 0, 0);
            this.ltCancel.Controls.Add(this.lbHint, 0, 1);
            this.ltCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ltCancel.Location = new System.Drawing.Point(0, 75);
            this.ltCancel.Margin = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.ltCancel.Name = "ltCancel";
            this.ltCancel.RowCount = 2;
            this.ltCancel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.ltCancel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.ltCancel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.ltCancel.Size = new System.Drawing.Size(425, 75);
            this.ltCancel.TabIndex = 6;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnCancel.Location = new System.Drawing.Point(180, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(65, 23);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // lbHint
            // 
            this.lbHint.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbHint.AutoSize = true;
            this.lbHint.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbHint.Location = new System.Drawing.Point(7, 38);
            this.lbHint.Margin = new System.Windows.Forms.Padding(3, 9, 3, 0);
            this.lbHint.Name = "lbHint";
            this.lbHint.Size = new System.Drawing.Size(411, 32);
            this.lbHint.TabIndex = 4;
            this.lbHint.Text = "The Cancel button will attempt to interrupt the current dialing process,\r\nhowever" +
    " there is a chance the call may still be connected.";
            this.lbHint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ProcessControlSmall
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.ltControls);
            this.Name = "ProcessControlSmall";
            this.Size = new System.Drawing.Size(425, 150);
            this.ltControls.ResumeLayout(false);
            this.ltProgress.ResumeLayout(false);
            this.ltProgress.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProgress)).EndInit();
            this.ltCancel.ResumeLayout(false);
            this.ltCancel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbMessage;
        private System.Windows.Forms.PictureBox pbProgress;
        internal System.Windows.Forms.TableLayoutPanel ltControls;
        private System.Windows.Forms.TableLayoutPanel ltProgress;
        private System.Windows.Forms.TableLayoutPanel ltCancel;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lbHint;
    }
}
