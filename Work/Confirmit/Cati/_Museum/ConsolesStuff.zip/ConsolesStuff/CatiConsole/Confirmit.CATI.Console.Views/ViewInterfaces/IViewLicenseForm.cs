﻿using System;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Represents view entity for LicenseForm form.
    /// </summary>
    public interface IViewLicenseForm : IDisposable, ILocalizableView
    {
        /// <summary>
        /// Gets/sets license text.
        /// </summary>
        string DocumentText
        {
            get;
            set;
        }

        /// <summary>
        /// Shows/hides panel with buttons.
        /// </summary>
        bool ButtonsVisible
        {
            get;
            set;
        }

        /// <summary>
        /// Shows modal license form.
        /// </summary>
        /// <returns>Retruns dialog result.</returns>
        DialogResult Show();
    }
}
