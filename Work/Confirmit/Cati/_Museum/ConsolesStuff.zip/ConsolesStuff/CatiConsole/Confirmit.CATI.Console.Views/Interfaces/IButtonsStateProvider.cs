﻿namespace Confirmit.CATI.Console.Views.Interfaces
{
    public interface IButtonsStateProvider
    {
        bool IsPreviousPageEnabled { get; }

        bool IsNextPageEnabled { get; }

        bool IsFastForwardEnabled { get; }

        bool IsTerminateEnabled { get; }

        bool IsAppointmentsEnabled { get; }

        bool IsHangUpEnabled { get; }

        bool IsRefreshEnabled { get; }

        bool IsCheckSpellingEnabled { get; }

        bool IsLogoutAfterFinishingEnabled { get; }

        bool IsPendingBreakEnabled { get; }
    }
}
