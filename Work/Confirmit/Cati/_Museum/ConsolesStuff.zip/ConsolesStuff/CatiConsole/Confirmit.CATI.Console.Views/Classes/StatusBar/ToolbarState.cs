﻿using Confirmit.CATI.Console.Views.Classes.Interview;

namespace Confirmit.CATI.Console.Views.Classes.StatusBar
{
    public class ToolbarState
    {
        /// <summary>
        ///Current mode either Interviewing or Reviewing
        /// </summary>
        public InterviewModes Mode { get; set; }

        public bool IsPreviousPageEnabled { get; set; }

        public bool IsNextPageEnabled { get; set; }

        public bool IsAppointmentEnabled { get; set; }

        public bool IsRedoEnabled { get; set; }

        public bool IsFastForwardEnabled { get; set; }

        public bool IsCheckSpellingEnabled { get; set; }

        public bool IsRedialEnabled { get; set; }

        /// <summary>
        /// True if hang up is available for current dialer otherwise false
        /// </summary>
        public bool IsHangUpEnabled { get; set; }

        public bool IsInternalCallTransferEnabled { get; set; }

        public bool IsExternalCallTransferEnabled { get; set; }

        /// <summary>
        /// True if pending logout button is enabled otherwise false.
        /// </summary>
        public bool IsPendingLogoutEnabled { get; set; }

        public bool IsTerminateEnabled { get; set; }

        public bool IsTakeBreakEnabled { get; set; }

        public bool IsChangeTaskChoiceEnabled { get; set; }

        public bool IsMessageFormEnabled { get; set; }

        public bool IsAppointmensListEnabled { get; set; }

        public bool IsRefreshEnabled { get; set; }

        public bool IsLogoutEnabled { get; set; }
    }
}
