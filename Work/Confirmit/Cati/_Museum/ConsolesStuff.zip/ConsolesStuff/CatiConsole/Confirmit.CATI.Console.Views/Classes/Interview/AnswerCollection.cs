﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Console.Shared.Log;
using mshtml;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    /// <summary>
    /// Represents answer collection
    /// </summary>
    public class AnswerCollection : List<Answer>
    {        
        #region Constructor

        /// <summary>
        /// Answer collection constructor
        /// </summary>
        public AnswerCollection(IList<IHTMLElement> elementList)
        {
            for (int i = 0; i < elementList.Count; i++)
            {
                IHTMLElement element = elementList[i];
                IHTMLElement elementNext = ((i + 1) < elementList.Count) ? elementList[i + 1] : null;

                if (IsOtherElement(elementNext))
                {
                    Add(new Answer(element, elementNext));
                    i++;
                }
                else
                {
                    Add(new Answer(element));
                }                
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets/sets flag indicating that question has "single punch" answer 
        /// </summary>
        public bool HasSinglePunchAnswers
        {
            get
            {
                return this.Any(answer => answer.IsSinglePunch);
            }
        }

        /// <summary>
        /// Gets/sets flag indicating that question has answer with other field.
        /// </summary>
        public bool HasAnswersWithFocusedOtherField
        {
            get
            {
                return this.Any(answer => answer.HasOther && answer.IsOtherFocused);
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Returns true if passed element is other element
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static bool IsOtherElement(IHTMLElement element)
        {
            if (element != null &&
                (element is IHTMLInputElement || element is IHTMLTextAreaElement))
            {
                if (element.id.EndsWith("_other", StringComparison.InvariantCultureIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Unselect all answer in collection
        /// </summary>
        /// <param name="onlyExclusion">If true will be unselected only exclusive answer otherwise all answers</param>
        public  void UnselectAnswers(bool onlyExclusion)
        {                       
            try
            {
                foreach (Answer answer in this)
                {
                    if (answer.IsDisabled || answer.IsOther)
                    {
                        continue;
                    }

                    if (answer.IsSinglePunch && onlyExclusion || !onlyExclusion)
                    {
                        if (answer.TagName == TagNames.INPUT)
                        {
                            if (answer.ElementType == ElementTypes.Checkbox ||
                               answer.ElementType == ElementTypes.Radio)
                            {
                                answer.Checked = false;

                                if (answer.HasOther)
                                {
                                    answer.SetOtherValue();
                                }
                            }
                            else if (answer.ElementType == ElementTypes.TextInput)
                            {
                                answer.Value = string.Empty;
                            }
                        }
                        else if (answer.TagName == TagNames.TEXTAREA)
                        {
                            answer.Value = string.Empty;
                        }
                        else if (answer.TagName == TagNames.SELECT)
                        {
                            answer.SelectedIndex = -1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        #endregion
    }
}
