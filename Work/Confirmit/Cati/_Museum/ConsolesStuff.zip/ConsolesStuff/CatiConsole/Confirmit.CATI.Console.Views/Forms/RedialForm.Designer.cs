﻿using Confirmit.CATI.Console.Views.Controls;

namespace Confirmit.CATI.Console.Views.Forms
{
    partial class RedialForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbNote = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.rbRedialDefault = new System.Windows.Forms.RadioButton();
            this.rbRedialNew = new System.Windows.Forms.RadioButton();
            this.tbDialNumber = new System.Windows.Forms.TextBox();
            this.tlpCallOutcome = new System.Windows.Forms.TableLayoutPanel();
            this.lbLastCallOutcome = new System.Windows.Forms.Label();
            this.lbLastCallOutcomeName = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnDial = new System.Windows.Forms.Button();
            this.erpNumberValidity = new System.Windows.Forms.ErrorProvider(this.components);
            this.pclDialing = new Confirmit.CATI.Console.Views.Controls.ProcessControlSmall();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tlpCallOutcome.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.erpNumberValidity)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.030457F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 97.96954F));
            this.tableLayoutPanel1.Controls.Add(this.lbNote, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.tlpCallOutcome, 1, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 43.06299F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 56.93701F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(447, 124);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lbNote
            // 
            this.lbNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNote.Location = new System.Drawing.Point(9, 12);
            this.lbNote.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.lbNote.Name = "lbNote";
            this.lbNote.Size = new System.Drawing.Size(432, 27);
            this.lbNote.TabIndex = 0;
            this.lbNote.Text = "Click dial to redial the default number, or enter an alternative number to be dia" +
    "lled. Note: Clicking dial will cause the current call to be dropped.";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.74541F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.25459F));
            this.tableLayoutPanel3.Controls.Add(this.rbRedialDefault, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.rbRedialNew, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.tbDialNumber, 1, 1);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(12, 46);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.42857F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.57143F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(427, 47);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // rbRedialDefault
            // 
            this.rbRedialDefault.AutoSize = true;
            this.rbRedialDefault.Location = new System.Drawing.Point(10, 2);
            this.rbRedialDefault.Margin = new System.Windows.Forms.Padding(10, 2, 3, 3);
            this.rbRedialDefault.Name = "rbRedialDefault";
            this.rbRedialDefault.Size = new System.Drawing.Size(128, 16);
            this.rbRedialDefault.TabIndex = 0;
            this.rbRedialDefault.TabStop = true;
            this.rbRedialDefault.Text = "Redial default number";
            this.rbRedialDefault.UseVisualStyleBackColor = true;
            // 
            // rbRedialNew
            // 
            this.rbRedialNew.AutoSize = true;
            this.rbRedialNew.Location = new System.Drawing.Point(10, 24);
            this.rbRedialNew.Margin = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.rbRedialNew.Name = "rbRedialNew";
            this.rbRedialNew.Size = new System.Drawing.Size(104, 17);
            this.rbRedialNew.TabIndex = 1;
            this.rbRedialNew.TabStop = true;
            this.rbRedialNew.Text = "Dial new number";
            this.rbRedialNew.UseVisualStyleBackColor = true;
            this.rbRedialNew.CheckedChanged += new System.EventHandler(this.rbRedialNew_CheckedChanged);
            // 
            // tbDialNumber
            // 
            this.tbDialNumber.Enabled = false;
            this.tbDialNumber.Location = new System.Drawing.Point(159, 24);
            this.tbDialNumber.Name = "tbDialNumber";
            this.tbDialNumber.Size = new System.Drawing.Size(142, 20);
            this.tbDialNumber.TabIndex = 2;
            this.tbDialNumber.TextChanged += new System.EventHandler(this.tbDialNumber_TextChanged);
            // 
            // tlpCallOutcome
            // 
            this.tlpCallOutcome.ColumnCount = 2;
            this.tlpCallOutcome.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpCallOutcome.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpCallOutcome.Controls.Add(this.lbLastCallOutcome, 0, 0);
            this.tlpCallOutcome.Controls.Add(this.lbLastCallOutcomeName, 1, 0);
            this.tlpCallOutcome.Location = new System.Drawing.Point(12, 100);
            this.tlpCallOutcome.Name = "tlpCallOutcome";
            this.tlpCallOutcome.RowCount = 1;
            this.tlpCallOutcome.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpCallOutcome.Size = new System.Drawing.Size(427, 21);
            this.tlpCallOutcome.TabIndex = 2;
            // 
            // lbLastCallOutcome
            // 
            this.lbLastCallOutcome.AutoSize = true;
            this.lbLastCallOutcome.Location = new System.Drawing.Point(8, 3);
            this.lbLastCallOutcome.Margin = new System.Windows.Forms.Padding(8, 3, 3, 3);
            this.lbLastCallOutcome.Name = "lbLastCallOutcome";
            this.lbLastCallOutcome.Size = new System.Drawing.Size(142, 13);
            this.lbLastCallOutcome.TabIndex = 15;
            this.lbLastCallOutcome.Text = "The outcome of last call was";
            // 
            // lbLastCallOutcomeName
            // 
            this.lbLastCallOutcomeName.AutoSize = true;
            this.lbLastCallOutcomeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLastCallOutcomeName.Location = new System.Drawing.Point(156, 3);
            this.lbLastCallOutcomeName.Margin = new System.Windows.Forms.Padding(3);
            this.lbLastCallOutcomeName.Name = "lbLastCallOutcomeName";
            this.lbLastCallOutcomeName.Size = new System.Drawing.Size(0, 13);
            this.lbLastCallOutcomeName.TabIndex = 16;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 285F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.48485F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.51515F));
            this.tableLayoutPanel2.Controls.Add(this.btnCancel, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnDial, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 127);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(450, 34);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // btnCancel
            // 
            this.btnCancel.CausesValidation = false;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnCancel.Location = new System.Drawing.Point(368, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(71, 24);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnDial
            // 
            this.btnDial.CausesValidation = false;
            this.btnDial.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnDial.Location = new System.Drawing.Point(288, 3);
            this.btnDial.Name = "btnDial";
            this.btnDial.Size = new System.Drawing.Size(71, 24);
            this.btnDial.TabIndex = 14;
            this.btnDial.Text = "&Dial";
            this.btnDial.UseVisualStyleBackColor = true;
            this.btnDial.Click += new System.EventHandler(this.btnDial_Click);
            // 
            // erpNumberValidity
            // 
            this.erpNumberValidity.ContainerControl = this;
            // 
            // pclDialing
            // 
            this.pclDialing.BackColor = System.Drawing.SystemColors.Window;
            this.pclDialing.HintText = "The Cancel button will attempt to interrupt the current dialing process,\r\nhowever" +
    " there is a chance the call may still be connected.";
            this.pclDialing.Location = new System.Drawing.Point(0, 0);
            this.pclDialing.Margin = new System.Windows.Forms.Padding(0);
            this.pclDialing.Name = "pclDialing";
            this.pclDialing.ProcessMessage = "Please wait.";
            this.pclDialing.Size = new System.Drawing.Size(450, 159);
            this.pclDialing.TabIndex = 2;
            // 
            // RedialForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(450, 161);
            this.Controls.Add(this.pclDialing);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "RedialForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Redial";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tlpCallOutcome.ResumeLayout(false);
            this.tlpCallOutcome.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.erpNumberValidity)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnDial;
        private System.Windows.Forms.Label lbNote;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.RadioButton rbRedialDefault;
        private System.Windows.Forms.RadioButton rbRedialNew;
        private System.Windows.Forms.TextBox tbDialNumber;
        private System.Windows.Forms.ErrorProvider erpNumberValidity;
        private System.Windows.Forms.TableLayoutPanel tlpCallOutcome;
        private System.Windows.Forms.Label lbLastCallOutcome;
        private System.Windows.Forms.Label lbLastCallOutcomeName;
        private ProcessControlSmall pclDialing;


    }
}