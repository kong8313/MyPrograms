﻿using System;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    /// <summary>
    /// Represents PredefinedAnswerSelectedEventArgs event data.
    /// </summary>
    public class PredefinedAnswerSelectedEventArgs : EventArgs
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the PredefinedAnswerSelectedEventArgs class.
        /// Fills it with given data.
        /// </summary>
        /// <param name="navigateToNextQuestion">Flag indicating whether we should
        /// navigate to next question or not.</param>
        public PredefinedAnswerSelectedEventArgs(bool navigateToNextQuestion)
        {
            this.NavigateToNextQuestion = navigateToNextQuestion;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether we should navigate to 
        /// next question or not.
        /// </summary>
        public bool NavigateToNextQuestion { get; set; }

        #endregion
    }
}
