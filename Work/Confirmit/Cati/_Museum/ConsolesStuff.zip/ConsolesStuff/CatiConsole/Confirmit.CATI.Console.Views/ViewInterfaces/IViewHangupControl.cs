﻿namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Represents view interface for HangupControl control.
    /// </summary>
    public interface IViewHangupControl : ILocalizableView
    {
    }
}
