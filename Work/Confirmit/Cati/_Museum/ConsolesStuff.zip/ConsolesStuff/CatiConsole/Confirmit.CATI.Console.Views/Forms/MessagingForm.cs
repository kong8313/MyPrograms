﻿using System;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
    /// <summary>
    /// Represents class for messaging form
    /// </summary>
    public partial class MessagingForm : Form, IViewMessagingForm
    {
        #region Fields

        private int m_BalloonTipTimeout = 5; //balloon display time in seconds

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor for MessagingForm
        /// </summary>
        public MessagingForm()
        {
            InitializeComponent();
            Icon = Properties.Resources.AppIcon;
        }       
        
        #endregion

        #region ILocalizableView Members

        /// <summary>
        /// Localizes view according given localization information.
        /// </summary>
        /// <param name="manager">Localization manager which contains localization info.</param>
        public void Localize(ILocalizationManager manager)
        {
            Text = manager.GetString("MessagingForm_Caption");
            btnOk.Text = manager.GetString("MessagingForm_ButtonOk_Text");
            notifyIcon.Text = manager.GetString("MessagingForm_notifyIcon_BalloonTipTitle");
            notifyIcon.BalloonTipTitle = manager.GetString("MessagingForm_notifyIcon_BalloonTipTitle");            
        }

        #endregion
        
        #region IViewMessagingForm Members

        /// <summary>
        /// Occurs when button Ok is clicked.
        /// </summary>
        public event EventHandler<EventArgs> OkClick;

        /// <summary>
        /// Occurs when form is closed
        /// </summary>
        public event EventHandler<EventArgs> FormClose;

        /// <summary>
        /// Occurs when user clicks notification icon
        /// </summary>
        public event EventHandler<EventArgs> NotificationClick;

        /// <summary>
        /// Returns true if form is visible for interviewer
        /// </summary>
        public bool IsFormVisible
        { 
            get
            {
                return this.Visible;
            }
            
        }

        /// <summary>
        /// Opens MessagingForm
        /// </summary>
        /// <param name="parent"></param>
        void IViewMessagingForm.Show(IWin32Window parent)
        {            
            this.ShowDialog(parent);
        }
      
        /// <summary>
        /// Adds new record to MessageList
        /// </summary>
        public void AddMessage(string author, string time, string body)
        {
            messageList.AddMessage(author, time, body);
        }

        /// <summary>
        /// Shows notification in the task bar
        /// </summary>
        public void ShowNotification(string ballonMessage)
        {
            notifyIcon.Visible = true;
            
            if (String.IsNullOrEmpty(ballonMessage) == false)
            {
                notifyIcon.BalloonTipText = ballonMessage;
                notifyIcon.ShowBalloonTip(TimeSpan.FromSeconds(m_BalloonTipTimeout).Milliseconds);
            }
        }

        /// <summary>
        /// Hides notification in the task bar
        /// </summary>
        public void HideNotification()
        {
            notifyIcon.Visible = false;
        }

        /// <summary>
        /// Closes from.
        /// </summary>
        public void CloseForm()
        {
            Close();
        }

        /// <summary>
        /// Adds text into message list
        /// </summary>
        public void AddText(string text)
        {
            messageList.AddText(text);
        }

        /// <summary>
        /// Clears message list
        /// </summary>
        public void Clear()
        {
            messageList.Clear();
        }

        #endregion

        #region Event Handlers

        private void MessagingForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            OnFormClose(EventArgs.Empty);
        }

        private void notifyIcon_Click(object sender, EventArgs e)
        {
            OnNotificationClick(EventArgs.Empty);           
        }

        private void notifyIcon_BalloonTipClicked(object sender, EventArgs e)
        {
            OnNotificationClick(EventArgs.Empty);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            OnOkClick(EventArgs.Empty);
        }

        /// <summary>
        /// Fires FormClose event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnFormClose(EventArgs e)
        {
            if (FormClose != null)
            {
                FormClose(this, e);
            }
        }

        /// <summary>
        /// Fires OkClick event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnOkClick(EventArgs e)
        {
            if (OkClick != null)
            {
                OkClick(this, e);
            }
        }

        /// <summary>
        /// Fires NotificationClick event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnNotificationClick(EventArgs e)
        {
            if (NotificationClick != null)
            {
                NotificationClick(this, e);
            }
        }

        #endregion              
    }
}
