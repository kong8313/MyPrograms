﻿using Confirmit.CATI.Console.Views.Classes.Localization;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
	/// <summary>
	/// Implement base interface for localizable views.
	/// </summary>
	public interface ILocalizableView
	{
		/// <summary>
		/// Localizes view according given localization information.
		/// </summary>
		/// <param name="manager">Localization manager which contains localization info.</param>
		void Localize(ILocalizationManager manager);
	}
}
