﻿using System;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Represents view interface for DialControl control.
    /// </summary>
    public interface IViewDialControl : ILocalizableView
    {
        /// <summary>
        /// Gets/sets hang-up dialing message which is shown in UI.
        /// </summary>
        string HangupMessage { get; set; }

        /// <summary>
        /// Gets/sets dialing message which is shown in UI.
        /// </summary>
        string Message
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets phone number.
        /// </summary>
        string Phone
        {
            get;
            set;
        }
    }
}
