﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Controls
{
    /// <summary>
    /// Class is responsible for show proccess screen during asynchronous operation 
    /// </summary>
    public partial class ProcessControlSmall : UserControl, IViewProcessControl
    {
        public ProcessControlSmall()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Process control will show this message during asynchronous operation
        /// </summary>
        [Browsable(true)] 
        public string ProcessMessage
        {
            get { return lbMessage.Text; }
            set { lbMessage.Text = value; }
        }

        [Browsable(true)]
        public string HintText
        {
            get { return lbHint.Text; }
            set { lbHint.Text = value; }
        }

        public Button CancelButton {
            get
            {
                return btnCancel;
            }
        }

        public void SetDialCancellationButtonVisibility(bool isVisible)
        {
            ltCancel.Visible = isVisible;
        }
    }
}