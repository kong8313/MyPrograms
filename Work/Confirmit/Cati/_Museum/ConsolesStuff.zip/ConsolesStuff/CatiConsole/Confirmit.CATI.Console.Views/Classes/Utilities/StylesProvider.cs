﻿namespace Confirmit.CATI.Console.Views.Classes.Utilities
{
    internal class StylesProvider
    {
        public static string CurrentQuestionContainerClassName { get; } = "cati-current-question-container";
        public static string CurrentSubquestionContainerClassName { get; } = "cati-current-subquestion-container";
        public static string CurrentSubquestionContainerParentClassName { get; } = "cati-current-subquestion-container-parent";

        public static string GetStylesForCurrentQuestion()
        {
            var styles = $@"
.{CurrentQuestionContainerClassName}{{
    border-left: #ff6600 5px solid;
}}
.{CurrentSubquestionContainerClassName}{{
    background-color: #ff6600;
}}";

            return styles;
        }
    }
}