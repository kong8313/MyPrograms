﻿using System;
using System.Text;

namespace Confirmit.CATI.Console.Views.Classes.ExtendedWebBrowser
{   
    /// <summary>
    /// Contains information about navigation attempt
    /// </summary>
    /// <remarks>
    /// For some reasons WebBrowser adds zero (0) byte to the end of post data array.
    /// This leads to incorrect value of last request parameter: l=9\0 instead of l=9
    /// So we need to remove this last 'zero' byte
    /// </remarks>
    public class NavigationData
    {
        public NavigationData(object url, object targetFrameName, object postData, object headers, bool isFrame)
        {             
            Url = (string)url;
            TargetFrameName = (string)targetFrameName;                       

            byte[] tempPostData = (byte[])postData;
            PostData = tempPostData;
                                    
            if (tempPostData != null && tempPostData.Length > 0 &&
                tempPostData[tempPostData.Length - 1] == 0)
            {
                PostData = new byte[tempPostData.Length - 1];
                Array.Copy(tempPostData, PostData, tempPostData.Length - 1);
            }

            Headers = (string)headers;
            IsFrame = isFrame;
        }

        /// <summary>
        /// Gets/sets navigating Url
        /// </summary>
        public string Url
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets page's headers
        /// </summary>
        public string Headers
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets TargetFrameName
        /// See BeforeNavigate2 event
        /// </summary>
        public string TargetFrameName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets post data in request
        /// </summary>
        public byte[] PostData
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets flag indicating is navigation data corresponding to IFrame or main window.
        /// </summary>
        public bool IsFrame
        {
            get;
            set;
        }

        public override string ToString()
        {
            StringBuilder text = new StringBuilder();

            text.AppendFormat(
                "Navigation data: url {0}, header {1}, target frame name {2}, post data size {3}",
                string.IsNullOrEmpty(Url) ? string.Empty : Url,
                string.IsNullOrEmpty(Headers) ? string.Empty : Headers,
                string.IsNullOrEmpty(TargetFrameName) ? string.Empty : TargetFrameName,
                PostData != null ? PostData.Length : 0);

            return text.ToString();
        }
    }    
}
