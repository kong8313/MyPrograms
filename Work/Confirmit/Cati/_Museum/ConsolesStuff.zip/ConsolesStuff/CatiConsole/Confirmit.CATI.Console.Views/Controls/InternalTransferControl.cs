﻿using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Controls
{
    public partial class InternalTransferControl : UserControl, IViewGetInternalTransferControl
    {

        public InternalTransferControl()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Localizes view according given localization information.
        /// </summary>
        /// <param name="manager">Localization manager which contains localization info.</param>
        public void Localize(ILocalizationManager manager, string surveyName, string respondentName, string transferingInterviewer, string interviewId)
        {
            lbTitle.Text = manager.GetString("GetInternalTransferControl_Title");
            lbSurveyName.Text = manager.GetString("GetInternalTransferControl_SurveyName") + surveyName;
            lbRespondentName.Text = manager.GetString("GetInternalTransferControl_RespondentName") + respondentName;
            lbTransferingInterviewer.Text = manager.GetString("GetInternalTransferControl_TransferingInterviewer") + transferingInterviewer;
            lbInterviewId.Text = manager.GetString("GetInternalTransferControl_InterviewId") + interviewId;
        }

        public void Localize(ILocalizationManager manager)
        {
            Localize(manager, "", "", "", "");
        }
    }
}
