﻿using System.Runtime.Serialization;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    /// <summary>
    /// Class represents default and refused information for question
    /// </summary>
    [DataContract]
    public class DefaultAndRefusedInfo
    {
        /// <summary>
        /// Gets/sets question id
        /// </summary>
        [DataMember]
        public string QuestionId
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets precode for default answer
        /// </summary>
        [DataMember]
        public string DefaultAnswerPrecode
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets precode for refused answer
        /// </summary>
        [DataMember]
        public string RefusedAnswerPrecode
        {
            get;
            set;
        }
    }
}
