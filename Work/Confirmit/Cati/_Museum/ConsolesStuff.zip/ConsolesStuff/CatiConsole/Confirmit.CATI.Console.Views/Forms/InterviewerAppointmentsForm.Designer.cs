﻿namespace Confirmit.CATI.Console.Views.Forms
{
    partial class InterviewerAppointmentsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlBody = new System.Windows.Forms.Panel();
            this.lvInterviewerAppointmens = new System.Windows.Forms.ListView();
            this.chProjectId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chInterviewId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chProjectName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chAppointmentInterviewerTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chAppointmentTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chTimezone = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pnlBody.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBody
            // 
            this.pnlBody.Controls.Add(this.lvInterviewerAppointmens);
            this.pnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBody.Location = new System.Drawing.Point(0, 0);
            this.pnlBody.Name = "pnlBody";
            this.pnlBody.Size = new System.Drawing.Size(996, 358);
            this.pnlBody.TabIndex = 0;
            // 
            // lvInterviewerAppointmens
            // 
            this.lvInterviewerAppointmens.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chProjectId,
            this.chInterviewId,
            this.chProjectName,
            this.chAppointmentInterviewerTime,
            this.chAppointmentTime,
            this.chTimezone});
            this.lvInterviewerAppointmens.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvInterviewerAppointmens.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lvInterviewerAppointmens.FullRowSelect = true;
            this.lvInterviewerAppointmens.GridLines = true;
            this.lvInterviewerAppointmens.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvInterviewerAppointmens.Location = new System.Drawing.Point(0, 0);
            this.lvInterviewerAppointmens.MultiSelect = false;
            this.lvInterviewerAppointmens.Name = "lvInterviewerAppointmens";
            this.lvInterviewerAppointmens.Size = new System.Drawing.Size(996, 358);
            this.lvInterviewerAppointmens.TabIndex = 0;
            this.lvInterviewerAppointmens.UseCompatibleStateImageBehavior = false;
            this.lvInterviewerAppointmens.View = System.Windows.Forms.View.Details;
            this.lvInterviewerAppointmens.ColumnWidthChanged += new System.Windows.Forms.ColumnWidthChangedEventHandler(this.lvInterviewerAppointmens_ColumnWidthChanged);
            // 
            // chProjectId
            // 
            this.chProjectId.Text = "Project Id";
            this.chProjectId.Width = 105;
            // 
            // chInterviewId
            // 
            this.chInterviewId.Text = "Interview Id";
            this.chInterviewId.Width = 75;
            // 
            // chProjectName
            // 
            this.chProjectName.Text = "Project Name";
            this.chProjectName.Width = 132;
            // 
            // chAppointmentInterviewerTime
            // 
            this.chAppointmentInterviewerTime.Text = "Time due in Interviewer Timezone";
            this.chAppointmentInterviewerTime.Width = 175;
            // 
            // chAppointmentTime
            // 
            this.chAppointmentTime.Text = "Time due in Respondent Timezone";
            this.chAppointmentTime.Width = 175;
            // 
            // chTimezone
            // 
            this.chTimezone.Text = "Respondent Timezone";
            this.chTimezone.Width = 330;
            // 
            // InterviewerAppointmentsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(996, 358);
            this.Controls.Add(this.pnlBody);
            this.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "InterviewerAppointmentsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Interviewer Appointments";
            this.Resize += new System.EventHandler(this.InterviewerAppointmentsForm_Resize);
            this.pnlBody.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBody;
        private System.Windows.Forms.ListView lvInterviewerAppointmens;
        private System.Windows.Forms.ColumnHeader chProjectId;
        private System.Windows.Forms.ColumnHeader chProjectName;
        private System.Windows.Forms.ColumnHeader chAppointmentTime;
        private System.Windows.Forms.ColumnHeader chAppointmentInterviewerTime;
        private System.Windows.Forms.ColumnHeader chTimezone;
        private System.Windows.Forms.ColumnHeader chInterviewId;

    }
}