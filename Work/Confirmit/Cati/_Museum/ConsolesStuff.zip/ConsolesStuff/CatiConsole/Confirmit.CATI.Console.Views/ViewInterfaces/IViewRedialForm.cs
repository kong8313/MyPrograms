﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Interview;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    public enum RedialValidationControls
    {
        DialNumber
    }

	/// <summary>
	/// Represents view entity for RedialForm form.
	/// </summary>
    public interface IViewRedialForm : ILocalizableView, IPlayableView, IDisposable
	{
        /// <summary>
        /// Occurs when user press any key.
        /// </summary>
        event EventHandler<ProcessCmdKeyEventArgs> FormProcessCmdKey;

		/// <summary>
		/// Occurs when button Ok is clicked.
		/// </summary>
		event EventHandler<EventArgs> OkClick;

		/// <summary>
		/// Occurs when form is going to be validated. This event is fired only
		/// if children controls validation is successfull.
		/// </summary>
		event EventHandler<CancelEventArgs> ValidatingDialNumber;

        event EventHandler<EventArgs> RedialTypeChanged;

        event EventHandler<EventArgs> RedialNumberChanged;

        event EventHandler<EventArgs> FormClose;

        event EventHandler<DialCancellationEventArgs> CancelClick;

        bool SuppressFormClosing { get; set; }

	    bool IsVisible { get; }

        bool IsInProgressIndicatorVisible { get; }

        string LastCallOutcomeName { get; }

        string DialNumber { get; set; }

        bool RedialNewNumber { get; set; }
        
        bool ShowRedialNewNumber { get; set; }

	    bool IsDialCanellationButtonEnabled { get; set; }

        string DialingMessage { get; set; }

        string HangupDialingMessage { get; set; }

	    /// <summary>
		/// Shows modal redial form.
		/// </summary>
		/// <param name="parent">Parent window handle.</param>
		void Show(IWin32Window parent);

        /// <summary>
        /// Shows non-modal redial form.
        /// </summary>
        /// <param name="parent">Parent window handle.</param>
        void ShowNonModal(IWin32Window parent);

		/// <summary>
		/// Notifies user about validation error of specified control.
		/// </summary>
		/// <param name="control">Validated control.</param>
		/// <param name="message">Error message.</param>
		/// <remarks>If the message length is greater than zero, then the error icon is displayed, 
		/// and the ToolTip for the error icon is the error description text. 
		/// If the message length is zero, the error icon is hidden.
		/// </remarks>
		void AlertValidationError(RedialValidationControls control, string message);

        /// <summary>
        /// Enables/disables all input controls on form.
        /// </summary>
        /// <param name="enable">if true, enables controls; otherwise disables.</param>
        void EnableInputControls(bool enable);

	    void SetDialingInProgressVisibility(bool show);

        /// <summary>
        /// Hides form.
        /// </summary>
        void HideForm();

	    void NotifyLastCallOutcome(string callOutcome);

	    void SetDialCanellationButtonVisibility(bool isVisible);

	    void HangupDialing();

        void SetProcessMessage(string message);
	}
}
