﻿using System;

namespace Confirmit.CATI.Console.Views.Classes.ExtendedWebBrowser
{
    /// <summary>
    /// Represents argument to CustomNavigateEvent
    /// </summary>
    public class CustomBeforeNavigateEventArgs : EventArgs
    {
        /// <summary>
        /// Gets/sets NavigateData
        /// </summary>
        public NavigationData NavigateData
        {
            get;
            set;
        }
    }
}
