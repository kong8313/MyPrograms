﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Common.Encoding;
using Confirmit.CATI.Console.Shared.Exceptions;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Resources;
using Confirmit.CATI.Console.Views.Classes.ExtendedWebBrowser;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.Classes.SpellChecking;
using Confirmit.CATI.Console.Views.Classes.Utilities;
using Confirmit.CATI.Console.Views.Resources;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using mshtml;

namespace Confirmit.CATI.Console.Views.Controls
{
    /// <summary>
    /// Class represent Web browser component
    /// It is marked with ComVisible attribute to allow call .NET methods from 
    /// JavaScript methods on loaded page
    /// Don't remove public methods from this class to avoid problems with clients
    /// </summary>
    [ComVisible(true)]
    public partial class InterviewPageBrowser : UserControl, IViewInterviewPageBrowser
    {
        private NavigationData _navigateData;

        private BrowserFeaturesChecker _browserFeaturesChecker;

        private const string CallTransferConfigurationItem = "__catiCallTransferConfiguration";
        private const string ScreenRecordingEnabledItem = "__catiScreenRecordingEnabled";
        private const string EofInputValue = "EOF";
        private const string ErrorPageIdentity = "51079FD1-84E1-4057-B345-1D7DEF126480";

        private string _documentText;
        private string _operationCanNotBeCompletedTitle;
        private string _operationCanNotBeCompletedWarning;
        private string _operationCanNotBeCompletedLogMessage;
        private Stopwatch _stopWatch = null;

        public InterviewPageBrowser()
        {
            InitializeComponent();
            webBrowser.ObjectForScripting = this;
            SynchronizationContext = SynchronizationContext.Current;
            IsNavigationError = false;
            ExtendedLoggingEnabled = false;

            webBrowser.CustomBeforeNavigateEvent += WebBrowserCustomBeforeNavigateEvent;
            webBrowser.NavigateErrorEvent += WebBrowserNavigateErrorEvent;

            // We need this not in InitializeComponent to prevent stealing focus from inputs after clicking on scrollbar
            webBrowser.ScriptErrorsSuppressed = true;

            _browserFeaturesChecker = new BrowserFeaturesChecker();
        }

        public ISurveyPageInteractor SurveyPageInteractor { get; private set; }

        public IHTMLDocument3 Document
        {
            get
            {
                if (webBrowser.Document != null)
                {
                    return ((IHTMLDocument3)webBrowser.Document.DomDocument);
                }

                return null;
            }
        }

        public string DocumentText
        {
            get
            {
                if (_documentText != null)
                {
                    return _documentText;
                }

                try
                {
                    //For unknown reason WebBrowser.DocumentText property can raise exception

                    if (webBrowser.Document != null)
                    {
                        _documentText = ((IHTMLDocument3)webBrowser.Document.DomDocument).documentElement.innerHTML;
                    }
                }
                catch (Exception ex)
                {
                    _documentText = string.Empty;
                    Logger.Write(ex);
                }

                return _documentText;
            }
        }

        /// <summary>
        /// Gets telephony page type of current page.
        /// </summary>
        public TelephonyPageType TelephonyPage => SurveyPageInteractor != null ? SurveyPageInteractor.TelephonyPage : TelephonyPageType.None;

        public bool DisableCatiMarkupAndKeyboardSupport => SurveyPageInteractor != null ? SurveyPageInteractor.DisableCatiMarkupAndKeyboardSupport : false;

        /// <summary>
        /// Gets value indicating that current page is CATI Console
        /// predefined custom error page.
        /// </summary>
        public bool IsPredefinedErrorPage
        {
            get
            {
                bool isPredefined = false;
                object doc;
                if (webBrowser.Document != null &&
                    (doc = webBrowser.Document.DomDocument) != null &&
                    ((IHTMLDocument3)doc).getElementById(ErrorPageIdentity) != null)
                {
                    isPredefined = true;
                }

                return isPredefined;
            }
        }

        public bool Is500ErrorPage => SurveyPageInteractor != null ? SurveyPageInteractor.Is500ErrorPage : false;

        /// <summary>
        /// Gets value indicating that navigation error has occured.
        /// </summary>
        public bool IsNavigationError { get; private set; }

        /// <summary>
        /// Gets or sets a value indicating whether extended logging 
        /// of browser operations is needed.
        /// </summary>
        public bool ExtendedLoggingEnabled { get; set; }

        /// <summary>
        /// Gets a value indicating whether current page contains Sound file info or not.
        /// </summary>
        public bool HasSoundInfo => SurveyPageInteractor != null ? SurveyPageInteractor.HasSoundInfo : false;

        public string SoundFileName => SurveyPageInteractor != null ? SurveyPageInteractor.SoundFileName : "";

        /// <summary>
        /// Gets a value indicating whether sound file must start playback automatically
        /// </summary>
        public bool StartPlaybackAutomatically => SurveyPageInteractor != null ? SurveyPageInteractor.StartPlaybackAutomatically : false;

        public bool ContainsForcedAppointment => SurveyPageInteractor != null ? SurveyPageInteractor.ContainsForcedAppointment : false;

        public bool ShouldNavigationBeIgnored => SurveyPageInteractor != null && (SurveyPageInteractor.NavigationCanBeIgnored && !keyboardInputControl.IsFocused);

        public bool ContainsCallTransferConfiguration => !string.IsNullOrEmpty(CallTransferConfiguration);

        public bool ContainsScreenRecordingEnabledFlag => !string.IsNullOrEmpty(ScreenRecordingEnabled);


        public string CurrentQuestionId => SurveyPageInteractor != null ? SurveyPageInteractor.CurrentQuestionId : "";

        /// <summary>
        /// Gets/sets flag indicated is user interface disabled or not
        /// If ReadOnly is true it means that it is monitoring console
        /// </summary>
        public bool ReadOnly
        {
            get => !webBrowser.Enabled;
            set
            {
                bool enabled = !value;
                pnlButtons.Enabled = enabled;
                ((Control)webBrowser).Enabled = enabled;

                if (SurveyPageInteractor != null)
                    SurveyPageInteractor.ReadOnly = value;

                keyboardInputControl.InputDisabled = value;
            }
        }

        /// <summary>
        /// Returns Uri for current page loaded into WebBrowser 
        /// </summary>
        public Uri Uri
        {
            get
            {
                if (webBrowser.Document != null)
                {
                    return webBrowser.Document.Url;
                }

                return null;
            }
        }

        /// <summary>
        /// Returns true if current page has open end question or has question with "other"
        /// answer which value is not empty.
        /// </summary>
        /// <remarks>
        /// It is used during review, check this property for do fast forward
        /// </remarks>
        public bool HasOpenEndQuestion => SurveyPageInteractor != null ? SurveyPageInteractor.HasOpenEndQuestion : false;

        /// <summary>
        /// Returns true if current question has answer with "other" field otherwise false.        
        /// </summary>
        public bool HasCurrentQuestionAnswersWithFocusedOtherField => SurveyPageInteractor != null ? SurveyPageInteractor.HasCurrentQuestionAnswersWithFocusedOtherField : false;

        /// <summary>
        /// Returns true if current active question is last NON-INFO question on displayed page
        /// Otherwise return false
        /// </summary>
        public bool IsCurrentQuestionLast => SurveyPageInteractor != null ? SurveyPageInteractor.IsCurrentQuestionLast : false;


        public bool IsPageInteractorInitialized => SurveyPageInteractor != null;

        public bool IsResponsiveSurvey => SurveyPageInteractor is ResponsiveSurveyPageInteractor;

        public IViewKeyboardInput ViewKeyboardInput => keyboardInputControl;

        /// <summary>
        /// Get transfer resource, if exists on current page. Otherwise returns empty string.
        /// </summary>
        public string TransferResource => SurveyPageInteractor?.TransferResource ?? "";

        /// <summary>
        /// Gets dialing message if exists on current page. Otherwise returns empty string.
        /// </summary>
        public string DialMessage => SurveyPageInteractor != null ? SurveyPageInteractor.DialMessage : "";

        /// <summary>
        /// Gets call transfer configuration if exists on current page. Otherwise returns empty string.
        /// </summary>
        public string CallTransferConfiguration
        {
            get
            {
                string result = String.Empty;

                IHTMLDocument3 doc;
                IHTMLInputElement text;
                if (webBrowser.Document != null &&
                    (doc = (IHTMLDocument3)webBrowser.Document.DomDocument) != null
                    && (text = (IHTMLInputElement)doc.getElementById(CallTransferConfigurationItem)) != null)
                {
                    result = text.value ?? String.Empty;
                }

                return result;
            }
        }

        /// <summary>
        /// Gets screen recording enabled flag if exists on current page. Otherwise returns empty string.
        /// </summary>
        public string ScreenRecordingEnabled
        {
            get
            {
                string result = String.Empty;

                IHTMLDocument3 doc;
                IHTMLInputElement text;
                if (webBrowser.Document != null &&
                    (doc = (IHTMLDocument3)webBrowser.Document.DomDocument) != null
                    && (text = (IHTMLInputElement)doc.getElementById(ScreenRecordingEnabledItem)) != null)
                {
                    result = text.value ?? String.Empty;
                }

                return result;
            }
        }

        /// <summary>
        /// Gets dialing phone if exists on current page. Otherwise returns empty string.
        /// </summary>
        public string DialPhone => SurveyPageInteractor != null ? SurveyPageInteractor.DialPhone : "";

        /// <summary>
        /// Gets/sets dial status if exists on page. Otherwise does this property is null.
        /// </summary>
        public int? DialStatus
        {
            get => SurveyPageInteractor != null ? SurveyPageInteractor.DialStatus : null;
            set
            {
                if (SurveyPageInteractor != null)
                    SurveyPageInteractor.DialStatus = value;
            }
        }

        /// <summary>
        /// Occurs when control already loaded page is going to complete it. It is cancelable
        /// event. If you cancel this event any further page processing will be stoped and
        /// DocumentCompleted event will not be sent.
        /// </summary>
        public event CancelEventHandler DocumentCompleting;

        /// <summary>
        /// Occurs when new page is loaded into control or page is refreshed via ajax
        /// </summary>
        public event EventHandler<EventArgs> DocumentCompleted;

        /// <summary>
        /// Occurs when control is navigating to a new page.
        /// </summary>
        public event EventHandler<CustomBeforeNavigateEventArgs> BeforeNavigate;

        /// <summary>
        /// Occurs when question is selected
        /// </summary>
        public event EventHandler<QuestionSelectedEventArgs> QuestionSelected;

        /// <summary>
        /// Occurs when sub-question of current question is selected.
        /// </summary>
        public event EventHandler<QuestionSelectedEventArgs> SubQuestionSelected;

        /// <summary>
        /// Occurs when active question is changed.
        /// </summary>
        public event EventHandler<AnswerElementValueChangedEventArgs> AnswerValueChanged;

        /// <summary>
        /// Occurs when active question is changed in responsive layout.
        /// </summary>
        public event EventHandler<AnswerElementValueChangedEventArgs> ResponsiveQuestionChanged;

        /// <summary>
        /// Occurs when answer value is changed for dynamic question
        /// </summary>
        public event EventHandler<EventArgs> DynamicQuestionAnswerValueChanged;

        public event EventHandler<PagePartiallyChangedEventArgs> PagePartiallyChanged;

        /// <summary>
        /// Occurs when question is loaded via ajax
        /// </summary>
        public event EventHandler<EventArgs> AjaxQuestionLoaded;

        public event EventHandler<EventArgs> OkClick;

        public event EventHandler SubmitOtherValue;

        public event EventHandler<JavascriptEventArgs> JavascriptEvent;

        /// <summary>
        /// Occurs when default answer for question is set
        /// </summary>
        public event EventHandler<PredefinedAnswerSelectedEventArgs> DefaultAnswerSelected;

        /// <summary>
        /// Occurs when refused answer for question is set
        /// </summary>        
        public event EventHandler<PredefinedAnswerSelectedEventArgs> RefusedAnswerSelected;

        /// <summary>
        /// Occurs in a case of navigation failed. If NavigateErroreventArgs.Cancel is true,
        /// browser will be redirected to built-in system error page. Otherwise redirect is not performed.
        /// </summary>
        public event EventHandler<NavigateErrorEventArgs> NavigateError;

        /// <summary>
        /// Occurs if there are some required browser features which are unsupported.
        /// </summary>
        public event EventHandler<BrowserCheckResultEventArgs> BrowserFeaturesUnsupported;

        /// <summary>
        /// Gets name of current question
        /// </summary>
        public string CurrentQuestionTitle => SurveyPageInteractor != null ? SurveyPageInteractor.CurrentQuestionTitle : "";

        /// <summary>
        /// Gets/sets index of current active question in list of page questions.
        /// </summary>
        public int CurrentQuestionIndex
        {
            get => SurveyPageInteractor != null ? SurveyPageInteractor.CurrentQuestionIndex : 0;
            set
            {
                if(SurveyPageInteractor != null)
                    SurveyPageInteractor.CurrentQuestionIndex = value;
            }
        }

        /// <summary>
        /// Gets value indicating that current page informs us about openend review mode.
        /// </summary>
        public bool IsOpenendReviewStartPage => SurveyPageInteractor != null ? SurveyPageInteractor.IsOpenendReviewStartPage : false;

        public bool IsOkPage => SurveyPageInteractor != null ? SurveyPageInteractor.IsOkPage : false;

        /// <summary>
        /// Gets the Status returned from the Confirmit in the OK page
        /// </summary>
        public string Status
        {
            get => SurveyPageInteractor != null ? SurveyPageInteractor.Status : "";
            set
            {
                if (SurveyPageInteractor != null)
                    SurveyPageInteractor.Status = value;
            }
        }

        /// <summary>
        /// Gets the Its returned from the Confirmit in the OK page
        /// </summary>
        public string Its => SurveyPageInteractor != null ? SurveyPageInteractor.Its : "";

        /// <summary>
        /// Gets the Interview duration returned from the Confirmit in the OK page
        /// </summary>
        public int InterviewDuration => SurveyPageInteractor != null ? SurveyPageInteractor.InterviewDuration  : 0;

        /// <summary>
        /// Gets a value indicating whether current page is Confirmit
        /// internal error page. This page is returned if error occurs 
        /// in survey engine during interviewing process. For example,
        /// this page is returned if survey script error occurs in Confirmit.
        /// </summary>
        public bool IsConfirmitInternalErrorPage => SurveyPageInteractor != null ? SurveyPageInteractor.IsConfirmitInternalErrorPage : false;

        /// <summary>
        /// Gets a value indicating whether current page is Confirmit service page
        /// which is returned when survey is in maintenance mode. For example, it is
        /// returned during survey launch.
        /// </summary>
        public bool IsConfirmitServicePage => SurveyPageInteractor != null ? SurveyPageInteractor.IsConfirmitServicePage : false;

        /// <summary>
        /// Return true if current page is end interview page
        /// </summary>
        public bool IsEndInterviewPageLoaded => SurveyPageInteractor != null ? SurveyPageInteractor.IsEndInterviewPageLoaded : false;

        /// <summary>
        /// Return true if current page is service page indicated interview end
        /// </summary>
        /// <returns></returns>
        public bool IsEndInterviewServicePage
        {
            get
            {
                if (webBrowser.Document != null)
                {
                    HtmlElementCollection colls = webBrowser.Document.GetElementsByTagName("input");
                    foreach (HtmlElement e in colls)
                    {
                        if (e.GetAttribute("value") == EofInputValue)
                            return true;
                    }
                }

                return false;
            }
        }

        /// <summary>
        /// Gets/sets delay in milliseconds to update page in the monitoring player
        /// </summary>
        public int PageUpdateMonitoringDelay
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets delay in milliseconds to send event about mouse click
        /// It is needed for some question when user clicks on label
        /// </summary>
        public int MouseClickAnswerMonitoringDelay
        {
            get;
            set;
        }

        /// <summary>
        /// Navigate to uri
        /// </summary>
        public void Navigate(Uri uri)
        {
            webBrowser.Navigate(uri);
        }

        /// <summary>
        /// Refreshes current page
        /// </summary>
        public void RefreshPage()
        {
            Logger.Write(
                string.Format(Strings.Log_RefreshPage, _navigateData),
                MessageTypes.Information);

            webBrowser.Navigate(
                _navigateData.Url,
                _navigateData.TargetFrameName,
                _navigateData.PostData,
                _navigateData.Headers
                );
        }

        public void DoNextPage()
        {
            SurveyPageInteractor.DoNextPage();
        }


        /// <summary>
        /// Emulates page previous button click
        /// </summary>
        /// <remarks>
        /// Checks flag WebBrowser.IsBusy to prevent multiple requests
        /// </remarks>

        public void DoPrevPage()
        {
            SurveyPageInteractor.DoPrevPage();
        }

        /// <summary>
        /// Select question by index in collection
        /// </summary>
        /// <param name="questionIndex"></param>
        public void DoQuestion(int questionIndex)
        {
            SurveyPageInteractor.DoQuestion(questionIndex);
        }

        /// <summary>
        /// Select subQuestion of current question
        /// </summary>
        /// <param name="subQuestionIndex"></param>
        public void DoSubQuestion(int subQuestionIndex)
        {
            SurveyPageInteractor.DoSubQuestion(subQuestionIndex);
        }

        /// <summary>
        /// Select first question
        /// </summary>
        public void DoFirstQuestion()
        {
            SurveyPageInteractor.DoFirstQuestion();
        }

        /// <summary>
        /// Selects first subquestion of the first question.
        /// </summary>
        public void DoFirstQuestionFirstSubQuestion()
        {
            SurveyPageInteractor.DoFirstQuestionFirstSubQuestion();
        }

        /// <summary>
        /// Selects last question
        /// If subquestionIndex is passed select specified subquestio
        /// </summary>
        public void DoLastQuestion()
        {
            SurveyPageInteractor.DoLastQuestion();
        }

        /// <summary> 
        /// Selects last subquestion of last question
        /// </summary>
        public void DoLastQuestionLastSubQuestion()
        {
            SurveyPageInteractor.DoLastQuestionLastSubQuestion();
        }

        /// <summary>
        /// Select first subquestion of  current question
        /// </summary>
        public void DoFirstSubQuestion()
        {
            SurveyPageInteractor.DoFirstSubQuestion();
        }

        /// <summary>
        /// Selects last subquestion of current question
        /// </summary>
        public void DoLastSubQuestion()
        {
            SurveyPageInteractor.DoLastSubQuestion();
        }

        /// <summary>
        /// Select next question
        /// if current question is Grid or Grid3D select next subquestion of current question
        /// otherwise select next question
        /// </summary>
        public void DoNextQuestion()
        {
            SurveyPageInteractor.DoNextQuestion();
        }

        /// <summary>
        /// Select previous question
        /// if current question is Grid or Grid3D select previous subquestion of current question
        /// otherwise select previous question
        /// </summary>
        public void DoPreviousQuestion()
        {
            SurveyPageInteractor.DoPreviousQuestion();
        }

        /// <summary>
        /// Set focus to text control for edit purposes
        /// </summary>
        public void DoEditQuestion()
        {
            SurveyPageInteractor.DoEditQuestion();
        }

        /// <summary>
        /// This method is used by clients. Don't remove it!!!
        /// </summary>
        /// <param name="elementId"></param>
        /// <param name="activeElementId"></param>
        public void MonitorChangesFor(string elementId, string activeElementId = "")
        {
            SurveyPageInteractor.MonitorChangesFor(elementId, activeElementId);
        }

        /// <summary>
        /// Fill active input elements by passed value
        /// It is used for keyboard support
        /// </summary>
        /// <param name="inputValue">Value contains user answer</param>
        /// <remarks>
        /// If page is not completely loaded we should do nothing
        /// </remarks>
        public void ProcessEnterData(string inputValue)
        {
            SurveyPageInteractor.ProcessEnterData(inputValue);

            Redraw();
        }

        /// <summary>
        /// Finish interview 
        /// If end interview page is loaded, it is emulated 'OK' button click
        /// </summary>
        public void FinishInterview()
        {
            SurveyPageInteractor.FinishInterview();
        }

        /// <summary>
        /// Terminate current interview with specified status.
        /// </summary>
        /// <param name="status">Termination status.</param>
        public void TerminateInterview(int status)
        {
            SurveyPageInteractor.TerminateInterview(status);

            CheckIfOperationIsNotPossible($"TerminateInterview (status = {status})");
        }

        /// <summary>
        /// Do fast forward action for current interview.
        /// </summary>
        public void FastForward()
        {
            SurveyPageInteractor.FastForward();

            CheckIfOperationIsNotPossible("FastForward");
        }

        private string GetDocumentType()
        {
            if (webBrowser.Document == null)
            {
                return string.Empty;
            }

            string pageTextContainingDocType;

            try
            {
                pageTextContainingDocType = webBrowser.DocumentText;
            }
            catch (FileNotFoundException ex)
            {
                Logger.Write(ex);
                pageTextContainingDocType = webBrowser.Document.All[0].InnerHtml;
            }

            var mc = Regex.Match(pageTextContainingDocType, @"\<\!DOCTYPE.+?\>", RegexOptions.IgnoreCase);

            return mc.Success ? mc.Value : string.Empty;
        }

        /// <summary>
        /// Return html of current page loaded into WebBrowser
        /// </summary>
        /// <returns></returns>
        public string GetPageContent()
        {
            String pageContent = String.Empty;

            try
            {
                if (webBrowser.Document != null)
                {
                    //we need actual html for ajax monitoring
                    pageContent = ((IHTMLDocument3)webBrowser.Document.DomDocument).documentElement.innerHTML;

                    var docType = GetDocumentType();

                    if (String.IsNullOrEmpty(docType) == false)
                    {
                        //add doctype line to output html
                        pageContent = pageContent.Insert(0, docType);
                    }

                    return pageContent;
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }

            return pageContent;
        }

        /// <summary>
        /// Checks if current page contains information about "Allow/disallow dialing" flag
        /// set in Confirmit. If page contains such info, returns <c>true</c> and 
        /// <paramref name="allowTelephonyCommands"/> is set to value of "Allow/disallow dialing" flag.
        /// Otherwise returns <c>false</c> and <paramref name="allowTelephonyCommands"/> is always
        /// <c>true</c>.
        /// </summary>
        /// <param name="allowTelephonyCommands">Returns value of Confirmit "Allow/disallow dialing" flag.</param>
        /// <returns>Returns <c>true</c> if page contains info; otherwise <c>false</c>.</returns>
        public bool CheckAndGetTelephonyFlag(out bool allowTelephonyCommands)
        {
            return SurveyPageInteractor.CheckAndGetTelephonyFlag(out allowTelephonyCommands);
        }

        public void PrepareBrowser()
        {
            webBrowser.Navigate(new Uri("about:blank"));
            webBrowser.Document.OpenNew(true);
        }

        public void HighlightEnterZone(Color color)
        {
            pnlInputControl.BackColor = color;
            pnlBottom.BackColor = color;
            pnlButtons.BackColor = color;
        }

        /// <summary>
        /// Sets the HTML contents of the page displayed in the WebBrowser control
        /// Initially prepare line to loading
        /// </summary>
        public void LoadContent(string pageContent)
        {
            webBrowser.DocumentText = pageContent;
        }

        public void FireClickEventByElementId(string elementId)
        {
            ExecuteJavaScript(string.Format("document.getElementById('{0}').click()", elementId));
        }

        /// <summary>
        /// Sets Answer on current html page
        /// Finds html element on the page and set value of element
        /// Is being used in Autopilot for Legacy surveys
        /// </summary>
        /// <param name="elementId">html element id</param>        
        /// <param name="elementValue">value that will be set to element</param>
        public void SetAnswer(string elementId, string elementValue)
        {
            SurveyPageInteractor.SetAnswer(elementId, elementValue);
        }

        /// <summary>
        /// Continues interview by pressing button. If this is final page with
        /// "Ok" button, we press it. Otherwise we press "Next" button.
        /// </summary>
        public void ContinueInterview()
        {
            SurveyPageInteractor.ContinueInterview();
        }

        /// <summary>
        /// Changes language of current interview. Function sets given value to "l" parameter in current page DOM.
        /// </summary>
        /// <param name="languageId">Language indentifier.</param>
        public void ChangeLanguage(int languageId)
        {
            SurveyPageInteractor.ChangeLanguage(languageId);
        }

        /// <summary>
        /// Set default answer for current question on page
        /// </summary>
        public void SetDefaultAnswer()
        {
            if (webBrowser.IsBusy) return;

            if (SurveyPageInteractor.CurrentQuestionHasDefaultAnswer)
            {
                bool navigate, keepFocus;

                SurveyPageInteractor.SetDefaultAnswer(out navigate, out keepFocus);

                Redraw();
                OnDefaultAnswerSelected(new PredefinedAnswerSelectedEventArgs(navigate));

                if (keepFocus == false)
                {
                    keyboardInputControl.SetFocus();
                }
            }

        }

        /// <summary>
        /// Set refused answer for current question on page
        /// </summary>
        public void SetRefusedAnswer()
        {
            if (webBrowser.IsBusy) return;

            if (SurveyPageInteractor.CurrentQuestionHasRefusedAnswer)
            {
                bool navigate, keepFocus;

                SurveyPageInteractor.SetRefusedAnswer(out navigate, out keepFocus);
                Redraw();
                OnRefusedAnswerSelected(new PredefinedAnswerSelectedEventArgs(navigate));

                if (keepFocus == false)
                {
                    keyboardInputControl.SetFocus();
                }
            }
        }

        /// <summary>
        /// Shows error page with given message. This method constructs error page, containing
        /// message and loads it to browser.
        /// </summary>
        /// <param name="message">Error message.</param>
        public void ShowErrorPage(string message)
        {
            webBrowser.DocumentText = Strings.ResourceManager.GetString(
                "InterviewPageBrowser_ErrorPage",
                ErrorPageIdentity,
                HttpUtilitySafe.HtmlEncode(message)
            );
        }

        /// <summary>
        /// Collects all text blocks on the current page.
        /// </summary>
        /// <returns>
        /// Returns enumeration of QuestionTextBlock.
        /// </returns>
        public IEnumerable<QuestionTextBlock> GetPageTextBlocks()
        {
            return SurveyPageInteractor.GetPageTextBlocks();
        }

        /// <summary>
        /// Updates text blocks on the current page.
        /// </summary>        
        public void UpdatePageTextBlocks(IEnumerable<QuestionTextBlock> textblocks)
        {
            IHTMLDocument3 doc;

            if (webBrowser.Document != null &&
               (doc = (IHTMLDocument3)webBrowser.Document.DomDocument) != null)
            {
                try
                {
                    foreach (var textblock in textblocks)
                    {
                        var element = doc.getElementById(textblock.Id);

                        var answer = new Answer(element);
                        answer.Value = textblock.Value;

                        if (AnswerCollection.IsOtherElement(element))
                        {
                            element.setAttribute("__oldValue", textblock.Value, 0);
                        }
                        
                        if (IsResponsiveSurvey)
                        {
                            var script = $@"
                                var event = document.createEvent('Event');
                                event.initEvent('input', true, true);

                                document.getElementById('{textblock.Id}').dispatchEvent(event);";

                            ExecuteJavaScript(script);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Write(ex);
                }
            }
        }

        /// <summary>
        /// Renews container with new content
        /// </summary>
        /// <param name="elementId">Id of the element that we want to update</param>
        /// <param name="elementOuterHtml">New content for the element</param>
        /// <param name="activeElementId">Id of the element we want to focus on</param>
        public void UpdatePagePartially(string elementId, string elementOuterHtml, string activeElementId)
        {
            SurveyPageInteractor.UpdatePagePartially(elementId, elementOuterHtml, activeElementId);
        }

        public void FocusActiveElement()
        {
            if (webBrowser.Document != null && webBrowser.Document.ActiveElement != null)
            {
                webBrowser.Focus();
                webBrowser.Document.ActiveElement.Focus();
            }
        }

        public void Localize(ILocalizationManager manager)
        {
            toolTip.SetToolTip(btnOk, manager.GetString("InterviewBrowser_ButtonOk_ToolTipText"));
            toolTip.SetToolTip(btnDefault, manager.GetString("InterviewBrowser_ButtonDefault_ToolTipText"));
            toolTip.SetToolTip(btnRefuse, manager.GetString("InterviewBrowser_ButtonRefuse_ToolTipText"));

            _operationCanNotBeCompletedTitle = manager.GetString("OperationCanNotBeCompletedTitle");
            _operationCanNotBeCompletedWarning = manager.GetString("OperationCanNotBeCompletedWarning");
            _operationCanNotBeCompletedLogMessage = manager.GetString("OperationCanNotBeCompletedLogMessage");
        }

        public void EnableKeyboardSupport(bool enabled)
        {
            pnlButtons.Enabled = enabled;
            keyboardInputControl.IsEnabled = enabled;
        }

        public SynchronizationContext SynchronizationContext { get; }

        private void OnDocumentCompleting(CancelEventArgs e)
        {
            DocumentCompleting?.Invoke(this, e);
        }

        private void OnBeforeNavigate(CustomBeforeNavigateEventArgs e)
        {
            BeforeNavigate?.Invoke(this, e);
        }

        /// <summary>
        /// After page is loaded into webBrowser current control DocumentCompleted event will be raised.
        /// </summary>
        private void OnDocumentCompleted()
        {
            DocumentCompleted?.Invoke(this, null);
        }

        /// <summary>
        /// Fires NavigateError event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnNavigateError(NavigateErrorEventArgs e)
        {
            _stopWatch.Stop();
            e.PageLoadTime = _stopWatch.Elapsed;

            NavigateError?.Invoke(this, e);
        }

        /// <summary>
        /// Parse current HtmlDocument and fill Pagem_PageQuestions collection 
        /// </summary>
        ///<exception cref="InvalidPageException">Occures when we try parse invalid page</exception>
        public void ParseDocument()
        {
            SurveyPageInteractor.ParseDocument();
        }

        internal void ParseForSoundInfo()
        {
            SurveyPageInteractor.ParseForSoundInfo();
        }

        public string GetDatePickerDatePattern()
        {
            return SurveyPageInteractor.GetDatePickerDatePattern();
        }

        /// <summary>
        /// Fires DefaultAnswerSelected event.
        /// </summary>
        /// <param name="e">DefaultAnswerSelected event arguments.</param>      
        private void OnDefaultAnswerSelected(PredefinedAnswerSelectedEventArgs e)
        {
            DefaultAnswerSelected?.Invoke(this, e);
        }

        /// <summary>
        /// Fires RefusedAnswerSelected event.
        /// </summary>
        /// <param name="e">RefusedAnswerSelected event arguments.</param>                
        private void OnRefusedAnswerSelected(PredefinedAnswerSelectedEventArgs e)
        {
            RefusedAnswerSelected?.Invoke(this, e);
        }

        /// <summary>
        /// Invalidates and redraw web browser control.
        /// </summary>
        private void Redraw()
        {
            webBrowser.Invalidate(true);
            webBrowser.Update();
        }

        /// <summary>
        /// Occur when page is completely loaded into browser control
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m_WebBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (webBrowser.ReadyState != WebBrowserReadyState.Complete)
            {
                /*If page contains IFrames 'DocumentCompleted' event will occur for main page and for each frame.
                  The event should be handled only once. For iframe ReadyState equals to 'Interactive'.*/
                return;
            }

            // we should suppress further page processing if user cancels operation.
            // It may occurs when for example we recieve special pages (telephony) which
            // shouldn't be shown to user.
            var args = new CancelEventArgs();

            InitPageInteractor();

            InsertStyles();

            OnDocumentCompleting(args);

            _stopWatch.Stop();

            if (ExtendedLoggingEnabled)
            {
                LogReceivedPageInfo();
            }

            if (args.Cancel)
            {
                return;
            }

            new DelayWorkManager(FinishDocumentLoading, PageUpdateMonitoringDelay).Run();
        }

        public void OnResponsiveQuestionSelected(string id, string type, string text, string title, int index, int subQuestionIndex)
        {
            SurveyPageInteractor.OnResponsiveQuestionSelected(id, type, text, title, index, subQuestionIndex);
        }

        public void OnResponsiveSubQuestionSelected(int questionIndex, int subQuestionIndex)
        {
            SurveyPageInteractor.OnResponsiveSubQuestionSelected(questionIndex, subQuestionIndex);
        }

        public void InitPageInteractor()
        {
            if (SurveyPageInteractor != null)
            {
                SurveyPageInteractor.Unsubscribe();
            }

            if (!string.IsNullOrEmpty(webBrowser.DocumentText) && !webBrowser.DocumentText.Contains("window.Confirmit"))
            {
                SurveyPageInteractor = new LegacySurveyPageInteractor(webBrowser, PagePartiallyChanged, QuestionSelected,
                    AnswerValueChanged, DynamicQuestionAnswerValueChanged, AjaxQuestionLoaded, SubQuestionSelected, ReadOnly);
            }
            else
            {
                SurveyPageInteractor = new ResponsiveSurveyPageInteractor(webBrowser, QuestionSelected, SubQuestionSelected, ReadOnly);
            }

            if (webBrowser.DocumentText.Contains("window.wix") || webBrowser.DocumentText.Contains("window.Confirmit"))
            {
                SurveyPageInteractor.Subscribe();
            }
            SurveyPageInteractor.OnRedraw += (o, eventArgs) => Redraw();
        }

        private void LogReceivedPageInfo()
        {
            var pageContent = GetPageContent();

            Logger.Write(string.Format(Strings.Log_PageIsReceived,
                    pageContent.Length.ToString("N0"),
                    webBrowser.Url,
                    _stopWatch.Elapsed.TotalMilliseconds.ToString("N0")),
                    MessageTypes.Information);
        }

        private void FinishDocumentLoading()
        {
            ParseDocument();

            ParseForSoundInfo();

            OnDocumentCompleted();

            if (webBrowser.DocumentText.Contains("window.wix") || webBrowser.DocumentText.Contains("window.Confirmit"))
            {
                SetDefaultActiveQuestion();
                SurveyPageInteractor.DoRequiredSubscriptions();
                CheckBrowserFeatures();
            }

            if (ExtendedLoggingEnabled && !string.IsNullOrEmpty(SurveyPageInteractor.CurrentQuestionId))
            {
                Logger.Write(string.Format(Strings.Log_FirstQuestionId, SurveyPageInteractor.CurrentQuestionId), MessageTypes.Information);
            }
        }

        public void SetDefaultActiveQuestion()
        {
            SurveyPageInteractor.SetDefaultActiveQuestion();
        }

        private void InsertStyles()
        {
            SurveyPageInteractor.InsertStyles();
        }

        /// <summary>
        /// For some reason handling click event through mshtml was failed
        /// We use javascript events instead (see DoNextPage_AfterRedo_FastForwardClicked test)
        /// Currently we use it only for testing
        /// </summary>
        /// <param name="args"></param>
        public void JavascriptEventHandler(params object[] args)
        {
            if (JavascriptEvent != null)
            {
                JavascriptEvent(this, new JavascriptEventArgs(args));
            }
        }

        /// <summary>
        /// NotifyMutationObserverDisabled is being called using window.external
        /// </summary>
        public void CheckBrowserFeatures()
        {
            _browserFeaturesChecker.Reset();

            try
            {
                var script = _browserFeaturesChecker.GetScript();

                ExecuteJavaScript(script);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        public void ExecuteJavaScript(string script)
        {
            if (webBrowser.Document != null && webBrowser.Document.Window != null)
            {
                ((IHTMLWindow2)webBrowser.Document.Window.DomWindow).execScript(script, "javascript");
            }
        }

        /// <summary>
        /// Method will be executed from JavaScript 
        /// after page is loaded(each time)
        /// </summary>
        public void CheckedFeatureDisabled(string featureName)
        {
            var feature = (BrowserFeature)Enum.Parse(typeof(BrowserFeature), featureName);

            switch (feature)
            {
                case BrowserFeature.MutationObserver:
                    if (SurveyPageInteractor.IsFeatureRequired(feature))
                        _browserFeaturesChecker.CheckedFeatureDisabled(feature);
                    break;
            }
        }

        /// <summary>
        /// Method will be executed from JavaScript 
        /// after browser feature checking
        /// </summary>
        public void BrowserFeaturesCheckingIsFinished()
        {
            var disabledFeatures = _browserFeaturesChecker.GetUnsupportedBrowserFeatures();

            if (disabledFeatures.Count == 0)
            {
                return;
            }

            BrowserFeaturesUnsupported(this, new BrowserCheckResultEventArgs()
            {
                UnsupportedFeatures = _browserFeaturesChecker.GetUnsupportedBrowserFeatures()
            });
        }

        public void AddNotificationAtTopOfThePage(string content)
        {
            ((HTMLDocument)webBrowser.Document.DomDocument).body.insertAdjacentHTML("afterbegin", content);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            OkClick?.Invoke(sender, e);
        }

        /// <summary>
        /// Occurs when user clicks Default button
        /// </summary>
        /// <remarks>
        /// For current question set default answer
        /// </remarks>
        private void btnDefault_Click(object sender, EventArgs e)
        {
            SetDefaultAnswer();
        }

        /// <summary>
        /// Occurs when user clicks Refuse button
        /// </summary>
        /// <remarks>
        /// For current question set refuse answer
        /// </remarks>
        private void btnRefuse_Click(object sender, EventArgs e)
        {
            SetRefusedAnswer();
        }

        void WebBrowserCustomBeforeNavigateEvent(object sender, CustomBeforeNavigateEventArgs e)
        {
            if (e.NavigateData.IsFrame &&
                Uri != null && Uri.AbsolutePath != new Uri(e.NavigateData.Url).AbsolutePath)
            {
                /*If page contains IFrames 'DocumentCompleted' event will occur for main page and for each iframe.
                  This event should be handled only for main page, document url equals current url. Note that in first time Uri is null.*/
                Logger.Write(Strings.Log_CustomBeforeNavigateEventOccuredForIFrame, MessageTypes.Warning);
                return;
            }

            _stopWatch = Stopwatch.StartNew();

            OnBeforeNavigate(e);

            if (ExtendedLoggingEnabled)
            {
                Logger.Write(Strings.Log_PageIsSubmitted, MessageTypes.Information);
            }

            // we do not save post data for error page and in a case of navigation error
            var saveNavigateData = IsNavigationError != true && ((IsPageInteractorInitialized &&
                                                                  IsPredefinedErrorPage != true &&
                                                                  IsConfirmitServicePage != true) ||
                                                                 !IsPageInteractorInitialized);
            if (saveNavigateData)
            {
                _navigateData = e.NavigateData;
            }

            IsNavigationError = false;
        }

        private void WebBrowserNavigateErrorEvent(object sender, NavigateErrorEventArgs e)
        {
            IsNavigationError = true;
            OnNavigateError(e);
        }

        /// <summary>
        /// Sets the HTML contents of the page displayed in the WebBrowser control synchroniously
        /// </summary>
        /// <remarks>
        /// Initial navigation to blank page is needed to initialize 'document' object
        /// </remarks>
        public void LoadContentSync(string pageContent)
        {
            webBrowser.Navigate(new Uri("about:blank"));
            if (webBrowser.Document != null)
            {
                webBrowser.Document.Write(pageContent);
            }
        }

        public void DynamicQuestionAnswerChangedHandler(string elementId = "")
        {
            SurveyPageInteractor.DynamicQuestionAnswerChangedHandler(elementId);
        }

        public void AjaxQuestionLoadedHandler()
        {
            SurveyPageInteractor.AjaxQuestionLoadedHandler();
        }

        public void LogMutationError(string error)
        {
            Logger.Write(error, MessageTypes.Error);
        }

        public void ResponsiveQuestionChange(string data)
        {
            ResponsiveQuestionChanged(this, new AnswerElementValueChangedEventArgs
            {
                ElementId = null,
                ElementValue = data
            });
        }

        public void SetFocusOnKeyboardInput()
        {
            SubmitOtherValue?.Invoke(this, null);
        }

        public void SetAnswerForResponsive(string id, string value)
        {
            var escapedValue = value
                .Replace("\"", "\\\"")
                .Replace("\\n", "\\\\n")
                .Replace("\\r", "\\\\r")
                .Replace("\\t", "\\\\t");

            ExecuteJavaScript($"Confirmit.page.catiMonitoringView.setAnswer('{escapedValue}');");
        }

        public void LogSurveyLayoutType()
        {
            Logger.Write(
                SurveyPageInteractor is ResponsiveSurveyPageInteractor
                    ? Strings.Log_ResponsiveSurveyDetected
                    : Strings.Log_LegacySurveyDetected, MessageTypes.Information);
        }

        private void CheckIfOperationIsNotPossible(string operation)
        {
            ExecuteJavaScript($"if(!window.wix && !window.Confirmit) window.external.LogOperationIsNotPossible('{operation}');");
        }

        public void LogOperationIsNotPossible(string operation)
        {
            Logger.Write(string.Format(_operationCanNotBeCompletedLogMessage, operation), MessageTypes.Error);
        }
    }
}
