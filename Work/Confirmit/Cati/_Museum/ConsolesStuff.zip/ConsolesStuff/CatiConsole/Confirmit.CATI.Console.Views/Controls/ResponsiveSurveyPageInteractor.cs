﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.SpellChecking;
using Confirmit.CATI.Console.Views.Classes.Utilities;
using mshtml;

namespace Confirmit.CATI.Console.Views.Controls
{
    public class ResponsiveSurveyPageInteractor : BaseSurveyPageInteractor, ISurveyPageInteractor, IResponsiveSurveyPageInteractor
    {
        private readonly EventHandler<QuestionSelectedEventArgs> _questionSelectedHandler;
        private readonly EventHandler<QuestionSelectedEventArgs> _onSubQuestionSelected;
        private const string ItsItem = "__its";

        public ResponsiveSurveyPageInteractor(ExtendedWebBrowser webBrowser,
            EventHandler<QuestionSelectedEventArgs> onQuestionSelected,
            EventHandler<QuestionSelectedEventArgs> onSubQuestionSelected,
            bool readOnly)
        {
            _questionSelectedHandler = onQuestionSelected;
            _onSubQuestionSelected = onSubQuestionSelected;
            ReadOnly = readOnly;
            WebBrowser = webBrowser;
        }

        public bool ReadOnly { get; set; }
        public bool IsEndInterviewPageLoaded => PageContainsQuestion("Internal_Finished") || PageContainsQuestion("Internal_Stop");
        public bool IsOkPage => IsEndInterviewPageLoaded;
        public void Unsubscribe()
        {

        }

        public bool IsConfirmitServicePage => PageContainsQuestion("Internal_In_service");
        public bool IsConfirmitInternalErrorPage => PageContainsQuestion("Internal_Internal_error");
        public bool HasOpenEndQuestion => GetBoolValue("Confirmit.page.catiPageView.hasOpenEndQuestion();");

        public EventHandler<EventArgs> OnRedraw { get; set; }

        // TODO For Autopilot
        public string CurrentQuestionId => GetStringValue("Confirmit.page.catiPageView.getCurrentQuestionId();");
        public bool IsCurrentQuestionLast => GetBoolValue("Confirmit.page.catiPageView.isCurrentQuestionLast();");
        public bool HasCurrentQuestionAnswersWithFocusedOtherField => GetBoolValue("Confirmit.page.catiPageView.hasCurrentQuestionAnswersWithFocusedOtherField();");

        public string CurrentQuestionTitle => GetStringValue("Confirmit.page.catiPageView.getCurrentQuestionTitle();");

        // TODO For Monitoring
        public int CurrentQuestionIndex { get; set; }
        public bool CurrentQuestionHasDefaultAnswer => GetBoolValue("!!Confirmit.page.catiPageView.getCurrentQuestionDefaultValue();");
        public bool CurrentQuestionHasRefusedAnswer => GetBoolValue("!!Confirmit.page.catiPageView.getCurrentQuestionRefusedValue();");

        public bool NavigationCanBeIgnored => false;

        public void FinishInterview()
        {
            if (WebBrowser.Document != null && WebBrowser.IsBusy == false)
            {
                if (IsEndInterviewPageLoaded)
                {
                    DoNextPage();
                }
            }
        }

        public void TerminateInterview(int status)
        {
            HTMLDocument doc = WebBrowser.Document.DomDocument as HTMLDocument;
            if (doc == null)
            {
                return;
            }

            var el = doc.getElementById("page_form");
            el.insertAdjacentHTML("afterbegin", "<input type=\"hidden\" name=\"__btnExit\" value='' />");

            IHTMLInputElement itsField = doc.getElementById(ItsItem) as IHTMLInputElement;
            if (itsField != null)
            {
                itsField.value = status.ToString(CultureInfo.InvariantCulture);
            }

            ExecuteJavascript("Confirmit.page.next(false);");

            // TODO: Implement via Responsive API
        }

        public void UpdatePagePartially(string elementId, string elementOuterHtml, string activeElementId)
        {
            throw new NotImplementedException();
        }

        public string GetDatePickerDatePattern()
        {
            throw new NotImplementedException();
        }

        public void SetAnswer(string elementId, string elementValue)
        {
            throw new NotImplementedException();
        }

        public void ContinueInterview()
        {
            DoNextPage();
        }

        public void FastForward()
        {
            // TODO: Implement via Responsive API

            HTMLDocument doc = WebBrowser.Document.DomDocument as HTMLDocument;
            if (doc == null)
            {
                return;
            }

            var el = doc.getElementById("page_form");
            el.insertAdjacentHTML("afterbegin", "<input type=\"hidden\" name=\"__fafwd\" value='' />");

            ExecuteJavascript("Confirmit.page.next();");

            // TODO: Implement via Responsive API
        }

        public void DoNextPage()
        {
            var value = GetStringValue("typeof window.Confirmit");
            ExecuteJavascript("Confirmit.page.next();");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        private string GetStringValue(string expression)
        {
            return WebBrowser.Document.InvokeScript("eval", new object[] { $"(function(){{return {expression};}})()" }).ToString();
        }

        private bool GetBoolValue(string expression)
        {
            if (WebBrowser.Document != null)
            {
                return (bool)WebBrowser.Document.InvokeScript("eval",
                    new object[] { $"(function(){{return {expression};}})()" });
            }

            return false;
        }

        private void ExecuteJavascript(string command)
        {
            ((IHTMLWindow2)WebBrowser.Document.Window.DomWindow).execScript(command);
        }

        private bool PageContainsQuestion(string questionId)
        {
            return GetBoolValue($"!!Confirmit.page.getQuestion('{questionId}')");
        }

        public IEnumerable<QuestionTextBlock> GetPageTextBlocks()
        {
            return GetPageTextBlocks("page_form");
        }

        public void DoPrevPage()
        {
            ExecuteJavascript("Confirmit.page.back();");
        }

        public void DoQuestion(int questionIndex)
        {
            ExecuteJavascript($"Confirmit.page.catiPageView.doQuestion({questionIndex});");
        }

        public void InsertStyles()
        {
            ((IHTMLDocument2)WebBrowser.Document.DomDocument)
                .createStyleSheet("", 0)
                .cssText = GetStyles();
        }

        private static string GetStyles()
        {
            return @"
.cf-question.cf-question--current-cati{
    border-left: #ff6600 5px solid;
}
.cf-grid-layout__row--current-cati{
    background: linear-gradient(to right, white, #ff6600);
}";
        }

        private string ConvertOuterQuestionTypeToCatiQuestionType(string type)
        {
            switch (type)
            {
                case "Single":
                case "HorizontalRatingScaleSingle":
                    return "Simple";
                case "OpenText":
                case "Numeric":
                    return "Open";
                case "OpenTextList":
                case "NumericList":
                    return "MultiOpen";
                case "Date":
                    return "DatePicker";
                case "HorizontalRatingScale":
                case "StarRating":
                    return "Grid";
                case "Grid3d":
                    return "Grid3D";
                default:
                    return type;
            }
        }

        public void OnResponsiveQuestionSelected(string id, string type, string text, string title, int index, int subQuestionIndex)
        {
            if (!string.IsNullOrEmpty(id))
            {
                type = ConvertOuterQuestionTypeToCatiQuestionType(type);

                var arg = new QuestionSelectedEventArgs
                {
                    QuestionIndex = index,
                    SubQuestionIndex = subQuestionIndex,
                    QuestionId = id,
                    QuestionTitle = title,
                    QuestionText = text,
                    IsSubQuestion = false,
                    QuestionType = (QuestionType)Enum.Parse(typeof(QuestionType), type)
                };

                _questionSelectedHandler?.Invoke(this, arg);
            }
        }

        public void DynamicQuestionAnswerChangedHandler(string elementId)
        {
            throw new NotImplementedException();
        }

        public void AjaxQuestionLoadedHandler()
        {
            throw new NotImplementedException();
        }

        public void OnResponsiveSubQuestionSelected(int questionIndex, int subQuestionIndex)
        {
            var arg = new QuestionSelectedEventArgs()
            {
                QuestionIndex = questionIndex,
                SubQuestionIndex = subQuestionIndex,
            };
            _onSubQuestionSelected?.Invoke(this, arg);
        }

        public void DoSubQuestion(int subQuestionIndex)
        {
            ExecuteJavascript($"Confirmit.page.catiPageView.doSubquestion({subQuestionIndex});");
        }

        public void DoPreviousQuestion()
        {
            ExecuteJavascript(@"Confirmit.page.catiPageView.doPreviousQuestion();");
        }

        public void DoNextQuestion()
        {
            ExecuteJavascript(@"Confirmit.page.catiPageView.doNextQuestion();");
        }

        public void DoFirstQuestion()
        {
            ExecuteJavascript(@"Confirmit.page.catiPageView.doFirstQuestion();");
        }

        public void DoFirstQuestionFirstSubQuestion()
        {
            DoFirstQuestion();
            DoFirstSubQuestion();
        }

        public void DoLastQuestion()
        {
            ExecuteJavascript(@"Confirmit.page.catiPageView.doLastQuestion();");
        }

        public void DoLastQuestionLastSubQuestion()
        {
            DoLastQuestion();
            DoLastSubQuestion();
        }

        public void DoFirstSubQuestion()
        {
            ExecuteJavascript(@"Confirmit.page.catiPageView.doFirstSubquestion();");
        }

        public void DoLastSubQuestion()
        {
            ExecuteJavascript(@"Confirmit.page.catiPageView.doLastSubquestion();");
        }

        public void DoEditQuestion()
        {
            ExecuteJavascript(@"Confirmit.page.catiPageView.focusOpenText();");
        }

        public void MonitorChangesFor(string elementId, string activeElementId = "")
        {
        }

        public void SetDefaultAnswer(out bool navigate, out bool keepFocus)
        {
            keepFocus = true;
            navigate = GetBoolValue(@"Confirmit.page.catiPageView.setValue(Confirmit.page.catiPageView.getCurrentQuestionDefaultValue());");
        }

        public void SetRefusedAnswer(out bool navigate, out bool keepFocus)
        {
            keepFocus = true;
            navigate = GetBoolValue(@"Confirmit.page.catiPageView.setValue(Confirmit.page.catiPageView.getCurrentQuestionRefusedValue());");
        }

        public void ProcessEnterData(string answer)
        {
            if (!ReadOnly)
            {
                ExecuteJavascript($"Confirmit.page.catiPageView.setValues('{answer}');");
            }
        }

        public void SetStringValue(string questionId, string answer, string precode = "")
        {
            ExecuteJavascript(string.IsNullOrEmpty(precode)
                ? $"Confirmit.page.getQuestion('{questionId}').setValue('{answer}');"
                : $"Confirmit.page.getQuestion('{questionId}').setValue('{precode}','{answer}');");
        }

        public void SetBoolValue(string questionId, bool value, string precode)
        {
            ExecuteJavascript($"Confirmit.page.getQuestion('{questionId}').setValue('{precode}',{(value ? "true" : "false")});");
        }

        public void Subscribe()
        {
            ExecuteJavascript(Scripts.ResponsiveNavigation);
        }

        public void ParseDocument()
        {
            // TODO: Implement via Responsive API
        }

        public void SetDefaultActiveQuestion()
        {
            ExecuteJavascript("Confirmit.page.catiPageView.setDefaultActiveQuestion();");
        }

        public bool IsFeatureRequired(BrowserFeature feature)
        {
            throw new NotImplementedException();
        }

        public void DoRequiredSubscriptions()
        {
            ExecuteJavascript(Scripts.MutationObserver);
            ExecuteJavascript(!ReadOnly ? Scripts.ResponsiveSubscription : Scripts.Monitoring);
        }

        public void SetOtherValue(string questionId, string precode, string answer)
        {
            ExecuteJavascript($"Confirmit.page.getQuestion('{questionId}').setOtherValue('{precode}','{answer}');");
        }

        public string GetQuestionType(string questionId)
        {
            return GetStringValue($"Confirmit.page.getQuestion('{questionId}').type");
        }

        public void SetBoolValueForInnerQuestion(string questionId, string innerQuestionId, string innerPrecode, bool b)
        {
            ExecuteJavascript(
                $"Confirmit.page.getQuestion('{questionId}').getInnerQuestion('{innerQuestionId}').setValue('{innerPrecode}',{(b ? "true" : "false")} );");
        }
    }
}