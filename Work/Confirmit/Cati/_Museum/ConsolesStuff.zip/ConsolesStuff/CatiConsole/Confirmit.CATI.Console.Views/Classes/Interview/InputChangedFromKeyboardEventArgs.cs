using System;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    public class InputChangedFromKeyboardEventArgs : EventArgs
    {
        public InputChangedFromKeyboardEventArgs(string elementId)
        {
            ElementId = elementId;
        }

        public string ElementId { get; set; }
    }
}