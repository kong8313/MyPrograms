﻿using System.Data;

namespace Confirmit.CATI.Console.Views.Classes.Utilities
{
    public static class ExtensionMethods
    {
        public static DataTable WithoutColumn(this DataTable table, string columnName)
        {
            if (!table.Columns.Contains(columnName))
            {
                return table;
            }

            var dtCloned = table.Clone();
            foreach (DataRow row in table.Rows)
            {
                dtCloned.ImportRow(row);
            }
            dtCloned.Columns.Remove(columnName);

            return dtCloned;
        }
    }
}