﻿using System.Windows.Forms;
using System.ComponentModel;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    /// <summary>
    /// Class represent information of KeyPress event
    /// </summary>
    public class ProcessCmdKeyEventArgs : CancelEventArgs
    {
        /// <summary>
        /// Gets/sets pressed key information
        /// </summary>
        public Keys KeyData
        {
            get;
            set;
        }
    }
}
