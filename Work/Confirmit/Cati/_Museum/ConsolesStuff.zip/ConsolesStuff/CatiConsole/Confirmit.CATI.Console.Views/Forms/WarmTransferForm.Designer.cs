﻿namespace Confirmit.CATI.Console.Views.Forms
{
    partial class WarmTransferForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WarmTransferForm));
            this.pictureBoxRespondent = new System.Windows.Forms.PictureBox();
            this.pictureBoxTransferTarget = new System.Windows.Forms.PictureBox();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.labelRespondentInfo = new System.Windows.Forms.Label();
            this.labelTransferTargetStatus = new System.Windows.Forms.Label();
            this.labelRespondentStatus = new System.Windows.Forms.Label();
            this.labelTransferTargetInfo = new System.Windows.Forms.Label();
            this.textBoxForFocus = new System.Windows.Forms.TextBox();
            this.buttonTalkPrivatelyWithRespondent = new System.Windows.Forms.Button();
            this.panelCenter = new System.Windows.Forms.Panel();
            this.labelYou = new System.Windows.Forms.Label();
            this.pictureBoxTargetConnectionState = new System.Windows.Forms.PictureBox();
            this.pictureBoxRespondentConnectionState = new System.Windows.Forms.PictureBox();
            this.pictureBoxInitiator = new System.Windows.Forms.PictureBox();
            this.pictureBoxRespondentCalling = new System.Windows.Forms.PictureBox();
            this.pictureBoxTransferCalling = new System.Windows.Forms.PictureBox();
            this.buttonMerge = new System.Windows.Forms.Button();
            this.buttonTalkPrivatelyWithTransferTarget = new System.Windows.Forms.Button();
            this.buttonComplete = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.panelTitle = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.pictureBoxTitle = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRespondent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTransferTarget)).BeginInit();
            this.panelCenter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTargetConnectionState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRespondentConnectionState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInitiator)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRespondentCalling)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTransferCalling)).BeginInit();
            this.panelTitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxRespondent
            // 
            this.pictureBoxRespondent.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxRespondent.BackgroundImage")));
            this.pictureBoxRespondent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxRespondent.Location = new System.Drawing.Point(56, 30);
            this.pictureBoxRespondent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBoxRespondent.Name = "pictureBoxRespondent";
            this.pictureBoxRespondent.Size = new System.Drawing.Size(111, 102);
            this.pictureBoxRespondent.TabIndex = 0;
            this.pictureBoxRespondent.TabStop = false;
            // 
            // pictureBoxTransferTarget
            // 
            this.pictureBoxTransferTarget.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxTransferTarget.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTransferTarget.Image")));
            this.pictureBoxTransferTarget.Location = new System.Drawing.Point(440, 30);
            this.pictureBoxTransferTarget.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBoxTransferTarget.Name = "pictureBoxTransferTarget";
            this.pictureBoxTransferTarget.Size = new System.Drawing.Size(111, 102);
            this.pictureBoxTransferTarget.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxTransferTarget.TabIndex = 1;
            this.pictureBoxTransferTarget.TabStop = false;
            // 
            // labelRespondentInfo
            // 
            this.labelRespondentInfo.AutoEllipsis = true;
            this.labelRespondentInfo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRespondentInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(114)))), ((int)(((byte)(117)))), ((int)(((byte)(123)))));
            this.labelRespondentInfo.Location = new System.Drawing.Point(32, 161);
            this.labelRespondentInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRespondentInfo.Name = "labelRespondentInfo";
            this.labelRespondentInfo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelRespondentInfo.Size = new System.Drawing.Size(207, 25);
            this.labelRespondentInfo.TabIndex = 12;
            this.labelRespondentInfo.Text = "Jane Doe";
            this.labelRespondentInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelTransferTargetStatus
            // 
            this.labelTransferTargetStatus.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTransferTargetStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(189)))), ((int)(((byte)(65)))));
            this.labelTransferTargetStatus.Location = new System.Drawing.Point(416, 196);
            this.labelTransferTargetStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTransferTargetStatus.Name = "labelTransferTargetStatus";
            this.labelTransferTargetStatus.Size = new System.Drawing.Size(140, 27);
            this.labelTransferTargetStatus.TabIndex = 13;
            this.labelTransferTargetStatus.Text = "Calling";
            this.labelTransferTargetStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelRespondentStatus
            // 
            this.labelRespondentStatus.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRespondentStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(189)))), ((int)(((byte)(65)))));
            this.labelRespondentStatus.Location = new System.Drawing.Point(32, 196);
            this.labelRespondentStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRespondentStatus.Name = "labelRespondentStatus";
            this.labelRespondentStatus.Size = new System.Drawing.Size(193, 27);
            this.labelRespondentStatus.TabIndex = 14;
            this.labelRespondentStatus.Text = "Connected";
            this.labelRespondentStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelTransferTargetInfo
            // 
            this.labelTransferTargetInfo.AutoEllipsis = true;
            this.labelTransferTargetInfo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTransferTargetInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(114)))), ((int)(((byte)(117)))), ((int)(((byte)(123)))));
            this.labelTransferTargetInfo.Location = new System.Drawing.Point(416, 161);
            this.labelTransferTargetInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTransferTargetInfo.Name = "labelTransferTargetInfo";
            this.labelTransferTargetInfo.Size = new System.Drawing.Size(188, 25);
            this.labelTransferTargetInfo.TabIndex = 15;
            this.labelTransferTargetInfo.Text = "555-555-555-555";
            this.labelTransferTargetInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxForFocus
            // 
            this.textBoxForFocus.Location = new System.Drawing.Point(613, 283);
            this.textBoxForFocus.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxForFocus.Name = "textBoxForFocus";
            this.textBoxForFocus.Size = new System.Drawing.Size(36, 22);
            this.textBoxForFocus.TabIndex = 1;
            // 
            // buttonTalkPrivatelyWithRespondent
            // 
            this.buttonTalkPrivatelyWithRespondent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(176)))), ((int)(((byte)(255)))));
            this.buttonTalkPrivatelyWithRespondent.FlatAppearance.BorderSize = 0;
            this.buttonTalkPrivatelyWithRespondent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTalkPrivatelyWithRespondent.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTalkPrivatelyWithRespondent.ForeColor = System.Drawing.Color.White;
            this.buttonTalkPrivatelyWithRespondent.Location = new System.Drawing.Point(32, 240);
            this.buttonTalkPrivatelyWithRespondent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonTalkPrivatelyWithRespondent.Name = "buttonTalkPrivatelyWithRespondent";
            this.buttonTalkPrivatelyWithRespondent.Size = new System.Drawing.Size(160, 44);
            this.buttonTalkPrivatelyWithRespondent.TabIndex = 16;
            this.buttonTalkPrivatelyWithRespondent.Text = "PRIVATE CALL";
            this.buttonTalkPrivatelyWithRespondent.UseVisualStyleBackColor = false;
            this.buttonTalkPrivatelyWithRespondent.EnabledChanged += new System.EventHandler(this.buttonTalkPrivatelyWithRespondent_EnabledChanged);
            this.buttonTalkPrivatelyWithRespondent.Click += new System.EventHandler(this.buttonTalkPrivatelyWtihRespondent_Click);
            this.buttonTalkPrivatelyWithRespondent.MouseDown += new System.Windows.Forms.MouseEventHandler(this.buttonTalkPrivatelyWithRespondent_MouseDown);
            this.buttonTalkPrivatelyWithRespondent.MouseEnter += new System.EventHandler(this.buttonTalkPrivatelyWithRespondent_MouseEnter);
            this.buttonTalkPrivatelyWithRespondent.MouseLeave += new System.EventHandler(this.buttonTalkPrivatelyWithRespondent_MouseLeave);
            this.buttonTalkPrivatelyWithRespondent.MouseUp += new System.Windows.Forms.MouseEventHandler(this.buttonTalkPrivatelyWithRespondent_MouseUp);
            // 
            // panelCenter
            // 
            this.panelCenter.BackColor = System.Drawing.Color.White;
            this.panelCenter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelCenter.Controls.Add(this.labelYou);
            this.panelCenter.Controls.Add(this.pictureBoxTargetConnectionState);
            this.panelCenter.Controls.Add(this.pictureBoxRespondentConnectionState);
            this.panelCenter.Controls.Add(this.pictureBoxInitiator);
            this.panelCenter.Controls.Add(this.pictureBoxRespondentCalling);
            this.panelCenter.Controls.Add(this.pictureBoxTransferCalling);
            this.panelCenter.Controls.Add(this.buttonMerge);
            this.panelCenter.Controls.Add(this.buttonTalkPrivatelyWithTransferTarget);
            this.panelCenter.Controls.Add(this.labelTransferTargetInfo);
            this.panelCenter.Controls.Add(this.textBoxForFocus);
            this.panelCenter.Controls.Add(this.labelTransferTargetStatus);
            this.panelCenter.Controls.Add(this.labelRespondentStatus);
            this.panelCenter.Controls.Add(this.labelRespondentInfo);
            this.panelCenter.Controls.Add(this.pictureBoxRespondent);
            this.panelCenter.Controls.Add(this.buttonTalkPrivatelyWithRespondent);
            this.panelCenter.Controls.Add(this.pictureBoxTransferTarget);
            this.panelCenter.Location = new System.Drawing.Point(-1, 79);
            this.panelCenter.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelCenter.Name = "panelCenter";
            this.panelCenter.Size = new System.Drawing.Size(615, 311);
            this.panelCenter.TabIndex = 17;
            // 
            // labelYou
            // 
            this.labelYou.AutoEllipsis = true;
            this.labelYou.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelYou.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(114)))), ((int)(((byte)(117)))), ((int)(((byte)(123)))));
            this.labelYou.Location = new System.Drawing.Point(261, 161);
            this.labelYou.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelYou.Name = "labelYou";
            this.labelYou.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelYou.Size = new System.Drawing.Size(81, 25);
            this.labelYou.TabIndex = 24;
            this.labelYou.Text = "You";
            this.labelYou.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBoxTargetConnectionState
            // 
            this.pictureBoxTargetConnectionState.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.Connector_Green;
            this.pictureBoxTargetConnectionState.Location = new System.Drawing.Point(365, 75);
            this.pictureBoxTargetConnectionState.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBoxTargetConnectionState.Name = "pictureBoxTargetConnectionState";
            this.pictureBoxTargetConnectionState.Size = new System.Drawing.Size(67, 10);
            this.pictureBoxTargetConnectionState.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxTargetConnectionState.TabIndex = 23;
            this.pictureBoxTargetConnectionState.TabStop = false;
            // 
            // pictureBoxRespondentConnectionState
            // 
            this.pictureBoxRespondentConnectionState.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.Connector_Red;
            this.pictureBoxRespondentConnectionState.Location = new System.Drawing.Point(175, 75);
            this.pictureBoxRespondentConnectionState.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBoxRespondentConnectionState.Name = "pictureBoxRespondentConnectionState";
            this.pictureBoxRespondentConnectionState.Size = new System.Drawing.Size(64, 10);
            this.pictureBoxRespondentConnectionState.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxRespondentConnectionState.TabIndex = 22;
            this.pictureBoxRespondentConnectionState.TabStop = false;
            // 
            // pictureBoxInitiator
            // 
            this.pictureBoxInitiator.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxInitiator.BackgroundImage")));
            this.pictureBoxInitiator.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxInitiator.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.ParticipentGrey;
            this.pictureBoxInitiator.Location = new System.Drawing.Point(247, 30);
            this.pictureBoxInitiator.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBoxInitiator.Name = "pictureBoxInitiator";
            this.pictureBoxInitiator.Size = new System.Drawing.Size(111, 102);
            this.pictureBoxInitiator.TabIndex = 21;
            this.pictureBoxInitiator.TabStop = false;
            // 
            // pictureBoxRespondentCalling
            // 
            this.pictureBoxRespondentCalling.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxRespondentCalling.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxRespondentCalling.Image")));
            this.pictureBoxRespondentCalling.Location = new System.Drawing.Point(97, 202);
            this.pictureBoxRespondentCalling.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBoxRespondentCalling.Name = "pictureBoxRespondentCalling";
            this.pictureBoxRespondentCalling.Size = new System.Drawing.Size(96, 17);
            this.pictureBoxRespondentCalling.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxRespondentCalling.TabIndex = 20;
            this.pictureBoxRespondentCalling.TabStop = false;
            // 
            // pictureBoxTransferCalling
            // 
            this.pictureBoxTransferCalling.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxTransferCalling.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTransferCalling.Image")));
            this.pictureBoxTransferCalling.Location = new System.Drawing.Point(481, 203);
            this.pictureBoxTransferCalling.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBoxTransferCalling.Name = "pictureBoxTransferCalling";
            this.pictureBoxTransferCalling.Size = new System.Drawing.Size(96, 17);
            this.pictureBoxTransferCalling.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxTransferCalling.TabIndex = 19;
            this.pictureBoxTransferCalling.TabStop = false;
            // 
            // buttonMerge
            // 
            this.buttonMerge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(176)))), ((int)(((byte)(255)))));
            this.buttonMerge.FlatAppearance.BorderSize = 0;
            this.buttonMerge.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMerge.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMerge.ForeColor = System.Drawing.Color.White;
            this.buttonMerge.Location = new System.Drawing.Point(247, 240);
            this.buttonMerge.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonMerge.Name = "buttonMerge";
            this.buttonMerge.Size = new System.Drawing.Size(117, 44);
            this.buttonMerge.TabIndex = 18;
            this.buttonMerge.Text = "MERGE";
            this.buttonMerge.UseVisualStyleBackColor = false;
            this.buttonMerge.EnabledChanged += new System.EventHandler(this.buttonMerge_EnabledChanged);
            this.buttonMerge.Click += new System.EventHandler(this.buttonMerge_Click);
            this.buttonMerge.MouseDown += new System.Windows.Forms.MouseEventHandler(this.buttonMerge_MouseDown);
            this.buttonMerge.MouseEnter += new System.EventHandler(this.buttonMerge_MouseEnter);
            this.buttonMerge.MouseLeave += new System.EventHandler(this.buttonMerge_MouseLeave);
            this.buttonMerge.MouseUp += new System.Windows.Forms.MouseEventHandler(this.buttonMerge_MouseUp);
            // 
            // buttonTalkPrivatelyWithTransferTarget
            // 
            this.buttonTalkPrivatelyWithTransferTarget.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(176)))), ((int)(((byte)(255)))));
            this.buttonTalkPrivatelyWithTransferTarget.FlatAppearance.BorderSize = 0;
            this.buttonTalkPrivatelyWithTransferTarget.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTalkPrivatelyWithTransferTarget.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTalkPrivatelyWithTransferTarget.ForeColor = System.Drawing.Color.White;
            this.buttonTalkPrivatelyWithTransferTarget.Location = new System.Drawing.Point(420, 240);
            this.buttonTalkPrivatelyWithTransferTarget.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonTalkPrivatelyWithTransferTarget.Name = "buttonTalkPrivatelyWithTransferTarget";
            this.buttonTalkPrivatelyWithTransferTarget.Size = new System.Drawing.Size(160, 44);
            this.buttonTalkPrivatelyWithTransferTarget.TabIndex = 17;
            this.buttonTalkPrivatelyWithTransferTarget.Text = "PRIVATE CALL";
            this.buttonTalkPrivatelyWithTransferTarget.UseVisualStyleBackColor = false;
            this.buttonTalkPrivatelyWithTransferTarget.EnabledChanged += new System.EventHandler(this.buttonTalkPrivatelyWithTransferTarget_EnabledChanged);
            this.buttonTalkPrivatelyWithTransferTarget.Click += new System.EventHandler(this.buttonTalkPrivatelyWithTransferTarget_Click);
            this.buttonTalkPrivatelyWithTransferTarget.MouseDown += new System.Windows.Forms.MouseEventHandler(this.buttonTalkPrivatelyWithTransferTarget_MouseDown);
            this.buttonTalkPrivatelyWithTransferTarget.MouseEnter += new System.EventHandler(this.buttonTalkPrivatelyWithTransferTarget_MouseEnter);
            this.buttonTalkPrivatelyWithTransferTarget.MouseLeave += new System.EventHandler(this.buttonTalkPrivatelyWithTransferTarget_MouseLeave);
            this.buttonTalkPrivatelyWithTransferTarget.MouseUp += new System.Windows.Forms.MouseEventHandler(this.buttonTalkPrivatelyWithTransferTarget_MouseUp);
            // 
            // buttonComplete
            // 
            this.buttonComplete.Location = new System.Drawing.Point(408, 400);
            this.buttonComplete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonComplete.Name = "buttonComplete";
            this.buttonComplete.Size = new System.Drawing.Size(95, 28);
            this.buttonComplete.TabIndex = 19;
            this.buttonComplete.Text = "Complete";
            this.buttonComplete.UseVisualStyleBackColor = true;
            this.buttonComplete.Click += new System.EventHandler(this.buttonComplete_Click);
            this.buttonComplete.MouseEnter += new System.EventHandler(this.buttonComplete_MouseEnter);
            this.buttonComplete.MouseLeave += new System.EventHandler(this.buttonComplete_MouseLeave);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.buttonCancel.Location = new System.Drawing.Point(509, 400);
            this.buttonCancel.Margin = new System.Windows.Forms.Padding(3, 4, 7, 7);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(100, 28);
            this.buttonCancel.TabIndex = 21;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            this.buttonCancel.MouseEnter += new System.EventHandler(this.buttonCancel_MouseEnter);
            this.buttonCancel.MouseLeave += new System.EventHandler(this.buttonCancel_MouseLeave);
            // 
            // panelTitle
            // 
            this.panelTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelTitle.BackColor = System.Drawing.Color.White;
            this.panelTitle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelTitle.Controls.Add(this.labelTitle);
            this.panelTitle.Controls.Add(this.pictureBoxTitle);
            this.panelTitle.Location = new System.Drawing.Point(3, 2);
            this.panelTitle.Margin = new System.Windows.Forms.Padding(0);
            this.panelTitle.Name = "panelTitle";
            this.panelTitle.Size = new System.Drawing.Size(605, 78);
            this.panelTitle.TabIndex = 22;
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.labelTitle.Location = new System.Drawing.Point(16, 11);
            this.labelTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(133, 14);
            this.labelTitle.TabIndex = 1;
            this.labelTitle.Text = "Warm transfer menu";
            // 
            // pictureBoxTitle
            // 
            this.pictureBoxTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxTitle.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.InternalCallTransferTitle;
            this.pictureBoxTitle.Location = new System.Drawing.Point(465, 0);
            this.pictureBoxTitle.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBoxTitle.Name = "pictureBoxTitle";
            this.pictureBoxTitle.Size = new System.Drawing.Size(140, 75);
            this.pictureBoxTitle.TabIndex = 0;
            this.pictureBoxTitle.TabStop = false;
            // 
            // WarmTransferForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(613, 437);
            this.Controls.Add(this.panelCenter);
            this.Controls.Add(this.panelTitle);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonComplete);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "WarmTransferForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Warm Transfer";
            this.TopMost = true;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.WarmTransferForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRespondent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTransferTarget)).EndInit();
            this.panelCenter.ResumeLayout(false);
            this.panelCenter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTargetConnectionState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRespondentConnectionState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInitiator)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRespondentCalling)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTransferCalling)).EndInit();
            this.panelTitle.ResumeLayout(false);
            this.panelTitle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxRespondent;
        private System.Windows.Forms.PictureBox pictureBoxTransferTarget;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Label labelRespondentInfo;
        private System.Windows.Forms.Label labelTransferTargetStatus;
        private System.Windows.Forms.Label labelRespondentStatus;
        private System.Windows.Forms.Label labelTransferTargetInfo;
        private System.Windows.Forms.TextBox textBoxForFocus;
        private System.Windows.Forms.Button buttonTalkPrivatelyWithRespondent;
        private System.Windows.Forms.Panel panelCenter;
        private System.Windows.Forms.Button buttonMerge;
        private System.Windows.Forms.Button buttonTalkPrivatelyWithTransferTarget;
        private System.Windows.Forms.Button buttonComplete;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Panel panelTitle;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.PictureBox pictureBoxTitle;
        private System.Windows.Forms.PictureBox pictureBoxTransferCalling;
        private System.Windows.Forms.PictureBox pictureBoxRespondentCalling;
        private System.Windows.Forms.PictureBox pictureBoxInitiator;
        private System.Windows.Forms.PictureBox pictureBoxTargetConnectionState;
        private System.Windows.Forms.PictureBox pictureBoxRespondentConnectionState;
        private System.Windows.Forms.Label labelYou;
    }
}