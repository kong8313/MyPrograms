﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Timer = System.Windows.Forms.Timer;

namespace Confirmit.CATI.Console.Views.Forms
{
    public partial class NotificationForm : Form, IViewNotificationForm
    {
        private Timer _timer;

        public NotificationForm()
        {
            InitializeComponent();
            InititalizeHandlers();
        }

        private void InititalizeHandlers()
        {
            Load += NotificationForm_Load;
            Closed += NotificationForm_Closed;
        }

        void NotificationForm_Closed(object sender, EventArgs e)
        {
            _timer.Stop();
            _timer.Dispose();
        }

        void NotificationForm_Load(object sender, EventArgs e)
        {
            _timer = new Timer { Interval = DismissTimeout };
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            Close();
        }

        public string Title
        {
            get { return lbTitle.Text; }
            set { lbTitle.Text = value; }

        }

        public string Message
        {
            get { return lbText.Text; }
            set { lbText.Text = value; }
        }

        public int DismissTimeout { get; set; }

        public void Localize(ILocalizationManager manager)
        {
            Text = manager.GetString("NotificationForm_Caption");
        }

        public void AdjustLocation()
        {
            Rectangle workingArea = Screen.GetWorkingArea(this);
            Location = new Point(workingArea.Right - Size.Width,
                                      workingArea.Bottom - Size.Height);
            StartPosition = FormStartPosition.Manual;
        }

        private void pbIcon_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawIcon(SystemIcons.Warning, new Rectangle(0, 0, 32, 32));
            base.OnPaint(e);
        }

    }
}
