﻿using System;

namespace Confirmit.CATI.Console.Views.Classes.ExtendedWebBrowser
{
    public class JavascriptEventArgs : EventArgs
    {
        public JavascriptEventArgs(object[] javascriptArguments)
        {
            JavascriptArguments = javascriptArguments;
        }

        public object[] JavascriptArguments { get; private set; }
    }
}
