﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.ComponentModel;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// If interviewer has "Choice" task choice 
    /// form asks interviewer to specify task choice    
    /// </summary>
    public interface IViewSelectTaskChoiceForm : ILocalizableView
    {
        /// <summary>
        /// Occurs when user click OK button
        /// </summary>
        event EventHandler<EventArgs> OkClick;

        /// <summary>
        /// Occurs when user clicks Cancel button or manualy closes form
        /// </summary>
        event EventHandler<CancelEventArgs> CancelClicking;

        /// <summary>
        /// Represents selected task
        /// </summary>
        int SelectedTaskChoice
        {
            get;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        void BindTaskChoiceList(Dictionary<string, int> values);

        /// <summary>
        /// Shows modal Interviewer Appointments form.
        /// </summary>
        /// <returns>Retruns dialog result.</returns>
        DialogResult Show(IWin32Window parent);        
    }
}
