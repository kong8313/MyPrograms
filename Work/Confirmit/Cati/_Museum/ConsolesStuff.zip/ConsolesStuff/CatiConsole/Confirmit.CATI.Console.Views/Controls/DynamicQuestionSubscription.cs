﻿using System.Text;

namespace Confirmit.CATI.Console.Views.Controls
{
    internal class DynamicQuestionSubscription
    {
        public string GetScript()
        {
            var script = new StringBuilder();
            const int debounceTimeout = 300;

            script.Append(@"
                function debounce(f, ms) {
                    var timer = null;
                    return function () {
                        var args = arguments;
                        var onComplete = function(){
                            f.apply(this, args);
                            timer = null;
                        }
                        if (timer) {
                            clearTimeout(timer);
                        }
                        timer = setTimeout(onComplete, ms);
                    };
                }
                if(window.YUI) {
                    YUI().use(""event-custom"", function(Y) {
                        Y.Global.on(""*:inputChanged"", function(e) {
                            window.external.DynamicQuestionAnswerChangedHandler(e.input.id); });
                        Y.Global.on(""searchable-multi:selection-change"",  function(e) { window.external.DynamicQuestionAnswerChangedHandler(e.fieldsetId); });
                    });
                }");
            script.Append(@"                
                if('MutationObserver' in window){
                    var callback = function(allmutations){
                        allmutations.map(function(mr){
			                window.external.DynamicQuestionAnswerChangedHandler();
                        });
                    };
                    var debouncedCallback = debounce(callback," + debounceTimeout + @");
                    var mo = new MutationObserver(debouncedCallback),
                    options = {
                        'childList': true,
                        'subtree': true
                    }
                    mo.observe(document.body, options);
                }");
            script.Append("if(typeof(wix) !== 'undefined' && wix != null)");
            script.Append("{");
            script.Append(
                "wix.onCallbackComplete.subscribe(function(e, args) { window.external.AjaxQuestionLoadedHandler();});");
            script.Append("}");

            return script.ToString();
        }
    }
}