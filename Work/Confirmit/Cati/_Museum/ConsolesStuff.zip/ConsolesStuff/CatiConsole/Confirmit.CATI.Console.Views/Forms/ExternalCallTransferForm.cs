﻿using System;
using System.Linq;
using System.Windows.Forms;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
    public partial class ExternalCallTransferForm : Form, IViewExternalCallTransferForm
    {
        public ExternalCallTransferForm()
        {
            InitializeComponent();
        }

        void IViewCallTransferForm<ExternalTransferTarget>.Show(IWin32Window parent)
        {
            if (!Visible)
                ShowDialog(parent);
        }

        public void Localize(ILocalizationManager manager)
        {
            Localize(manager, ConsoleTransferType.InternalWarm);
        }

        public void Localize(ILocalizationManager manager, ConsoleTransferType transferType)
        {
            Text = string.Format(
                manager.GetString("ExternalCallTransferForm_Caption"),
                transferType == ConsoleTransferType.ExternalCold
                    ? manager.GetString("CallTransferForm_ColdTransferTypeName")
                    : manager.GetString("CallTransferForm_WarmTransferTypeName"));

            lbTitle.Text = manager.GetString("ExternalCallTransferForm_Title");
            lbTitleDescription.Text = manager.GetString("ExternalCallTransferForm_Description");

            buttonCancel.Text = manager.GetString("CallTransferForm_ButtonCancel_Text");
            buttonTransfer.Text = transferType == ConsoleTransferType.ExternalCold
                ? manager.GetString("CallTransferForm_ButtonTransfer_Complete")
                : manager.GetString("CallTransferForm_ButtonTransfer_Start");
        }

        public void SelectRow(string lastUsedTransferTargetPhoneNumber)
        {
            for (var i = 0; i < dataGridView.RowCount; i++)
            {
                if (((ExternalTransferTarget)dataGridView.Rows[i].Tag).TelephoneNumber == lastUsedTransferTargetPhoneNumber)
                {
                    dataGridView.CurrentCell = dataGridView.Rows[i].Cells[0];
                    dataGridView.FirstDisplayedScrollingRowIndex = i;
                    return;
                }
            }

            dataGridView.CurrentCell = dataGridView.Rows[0].Cells[0];
            dataGridView.FirstDisplayedScrollingRowIndex = 0;
        }

        public void UpdateFormData(ExternalTransferTarget[] transferTargets)
        {
            dataGridView.SuspendLayout();

            dataGridView.Rows.Clear();

            foreach (var target in transferTargets)
            {
                var index = dataGridView.Rows.Add(target.TelephoneNumber, target.Description);
                dataGridView.Rows[index].Tag = target;
            }

            dataGridView.ResumeLayout(true);
        }

        public event EventHandler<EventArgs> CallTransferStart;

        public ExternalTransferTarget Selected => (ExternalTransferTarget) dataGridView.SelectedRows.Cast<DataGridViewRow>().SingleOrDefault()?.Tag;

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonTransfer_Click(object sender, EventArgs e)
        {
            CallTransferStart?.Invoke(this, e);
        }

        private void dataGridView_DoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            CallTransferStart?.Invoke(this, e);
        }

        private void dataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            CallTransferStart?.Invoke(this, e);
        }
    }
}
