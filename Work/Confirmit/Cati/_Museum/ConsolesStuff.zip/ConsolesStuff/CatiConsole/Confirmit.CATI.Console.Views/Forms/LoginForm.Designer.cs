﻿namespace Confirmit.CATI.Console.Views.Forms
{
	partial class LoginForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.btnLogin = new System.Windows.Forms.Button();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.lblWarning = new System.Windows.Forms.Label();
            this.llChangePassword = new System.Windows.Forms.LinkLabel();
            this.cbSetAsDefaultCompany = new System.Windows.Forms.CheckBox();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.tbCompany = new System.Windows.Forms.TextBox();
            this.lbApplicationTitle = new System.Windows.Forms.Label();
            this.tbUser = new System.Windows.Forms.TextBox();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLogin
            // 
            this.btnLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.ForeColor = System.Drawing.Color.Transparent;
            this.btnLogin.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.login_button;
            this.btnLogin.Location = new System.Drawing.Point(40, 369);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(122, 37);
            this.btnLogin.TabIndex = 5;
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.Transparent;
            this.pnlMain.BackgroundImage = global::Confirmit.CATI.Console.Views.Properties.Resources.cati_login3;
            this.pnlMain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnlMain.Controls.Add(this.lblWarning);
            this.pnlMain.Controls.Add(this.llChangePassword);
            this.pnlMain.Controls.Add(this.cbSetAsDefaultCompany);
            this.pnlMain.Controls.Add(this.tbPassword);
            this.pnlMain.Controls.Add(this.tbCompany);
            this.pnlMain.Controls.Add(this.lbApplicationTitle);
            this.pnlMain.Controls.Add(this.tbUser);
            this.pnlMain.Controls.Add(this.btnLogin);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(490, 493);
            this.pnlMain.TabIndex = 6;
            // 
            // lblWarning
            // 
            this.lblWarning.AutoSize = true;
            this.lblWarning.Font = new System.Drawing.Font("Arial", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWarning.ForeColor = System.Drawing.Color.Red;
            this.lblWarning.Location = new System.Drawing.Point(36, 453);
            this.lblWarning.MaximumSize = new System.Drawing.Size(420, 500);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.Size = new System.Drawing.Size(400, 57);
            this.lblWarning.TabIndex = 8;
            this.lblWarning.Text = "Support for this interface will end on June 30, 2023. Please switch to using the " +
    "replacement browser-based interface.";
            // 
            // llChangePassword
            // 
            this.llChangePassword.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llChangePassword.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llChangePassword.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(140)))), ((int)(((byte)(215)))));
            this.llChangePassword.Location = new System.Drawing.Point(39, 412);
            this.llChangePassword.Name = "llChangePassword";
            this.llChangePassword.Size = new System.Drawing.Size(280, 22);
            this.llChangePassword.TabIndex = 7;
            this.llChangePassword.TabStop = true;
            this.llChangePassword.Text = "Change password";
            this.llChangePassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.llChangePassword.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llChangePassword_LinkClicked);
            // 
            // cbSetAsDefaultCompany
            // 
            this.cbSetAsDefaultCompany.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbSetAsDefaultCompany.AutoSize = true;
            this.cbSetAsDefaultCompany.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.cbSetAsDefaultCompany.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(153)))), ((int)(((byte)(158)))));
            this.cbSetAsDefaultCompany.Location = new System.Drawing.Point(328, 355);
            this.cbSetAsDefaultCompany.Name = "cbSetAsDefaultCompany";
            this.cbSetAsDefaultCompany.Size = new System.Drawing.Size(127, 22);
            this.cbSetAsDefaultCompany.TabIndex = 4;
            this.cbSetAsDefaultCompany.Text = "Set as default";
            this.cbSetAsDefaultCompany.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbSetAsDefaultCompany.UseVisualStyleBackColor = true;
            this.cbSetAsDefaultCompany.CheckedChanged += new System.EventHandler(this.cbSetAsDefaultCompany_CheckedChanged);
            // 
            // tbPassword
            // 
            this.tbPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbPassword.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tbPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.tbPassword.Location = new System.Drawing.Point(52, 267);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.Size = new System.Drawing.Size(385, 20);
            this.tbPassword.TabIndex = 2;
            this.tbPassword.UseSystemPasswordChar = true;
            // 
            // tbCompany
            // 
            this.tbCompany.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbCompany.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tbCompany.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.tbCompany.Location = new System.Drawing.Point(52, 316);
            this.tbCompany.Name = "tbCompany";
            this.tbCompany.Size = new System.Drawing.Size(385, 20);
            this.tbCompany.TabIndex = 3;
            // 
            // lbApplicationTitle
            // 
            this.lbApplicationTitle.AutoSize = true;
            this.lbApplicationTitle.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lbApplicationTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(153)))), ((int)(((byte)(158)))));
            this.lbApplicationTitle.Location = new System.Drawing.Point(39, 159);
            this.lbApplicationTitle.Name = "lbApplicationTitle";
            this.lbApplicationTitle.Size = new System.Drawing.Size(194, 23);
            this.lbApplicationTitle.TabIndex = 6;
            this.lbApplicationTitle.Text = "FORSTA PLUS CATI\r\n";
            // 
            // tbUser
            // 
            this.tbUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbUser.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tbUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.tbUser.Location = new System.Drawing.Point(52, 215);
            this.tbUser.Name = "tbUser";
            this.tbUser.Size = new System.Drawing.Size(385, 20);
            this.tbUser.TabIndex = 1;
            // 
            // LoginForm
            // 
            this.AcceptButton = this.btnLogin;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(490, 493);
            this.Controls.Add(this.pnlMain);
            this.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LoginForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Log in";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.LoginForm_FormClosed);
            this.Load += new System.EventHandler(this.LoginForm_Load);
            this.Shown += new System.EventHandler(this.LoginForm_Shown);
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

		}

		#endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.TextBox tbUser;
        private System.Windows.Forms.CheckBox cbSetAsDefaultCompany;
        private System.Windows.Forms.TextBox tbCompany;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label lbApplicationTitle;
        private System.Windows.Forms.LinkLabel llChangePassword;
        private System.Windows.Forms.Label lblWarning;
    }
}