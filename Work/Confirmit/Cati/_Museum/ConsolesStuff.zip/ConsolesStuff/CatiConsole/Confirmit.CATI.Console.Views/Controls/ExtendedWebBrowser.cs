using System;
using System.Windows.Forms;
using System.Security.Permissions;
using Confirmit.CATI.Console.Views.Classes.ExtendedWebBrowser;
using SHDocVw;
using WebBrowser = System.Windows.Forms.WebBrowser;

namespace Confirmit.CATI.Console.Views.Controls
{
    /// <summary>
    /// An extended version of the Webbrowser control.
    /// </summary>
    public class ExtendedWebBrowser : WebBrowser
    {
        #region Members

        private IWebBrowser2 axIWebBrowser2;
        private AxHost.ConnectionPointCookie cookie;
        private WebBrowserExtendedEvents events;

        #endregion

        #region Events

        public event EventHandler<CustomBeforeNavigateEventArgs> CustomBeforeNavigateEvent;

        /// <summary>
        /// Event is fired when error occurs during navigation.
        /// </summary>
        public event EventHandler<NavigateErrorEventArgs> NavigateErrorEvent;

        #endregion

        #region Methods

        /// <summary>
        /// This method supports the .NET Framework infrastructure and is not intended to be used directly from your code. 
        /// Called by the control when the underlying ActiveX control is created. 
        /// </summary>
        /// <param name="nativeActiveXObject"></param>
        [PermissionSet(SecurityAction.LinkDemand, Name = "FullTrust")]
        protected override void AttachInterfaces(object nativeActiveXObject)
        {
            this.axIWebBrowser2 = (SHDocVw.IWebBrowser2)nativeActiveXObject;
            base.AttachInterfaces(nativeActiveXObject);
        }

        /// <summary>
        /// This method supports the .NET Framework infrastructure and is not intended to be used directly from your code. 
        /// Called by the control when the underlying ActiveX control is discarded. 
        /// </summary>
        [PermissionSet(SecurityAction.LinkDemand, Name = "FullTrust")]
        protected override void DetachInterfaces()
        {
            this.axIWebBrowser2 = null;
            base.DetachInterfaces();
        }

        /// <summary>
        /// This method will be called to give you a chance to create your own event sink
        /// </summary>
        [PermissionSet(SecurityAction.LinkDemand, Name = "FullTrust")]
        protected override void CreateSink()
        {
            // Make sure to call the base class or the normal events won't fire
            base.CreateSink();
            events = new WebBrowserExtendedEvents();
            cookie = new AxHost.ConnectionPointCookie(this.ActiveXInstance, events, typeof(SHDocVw.DWebBrowserEvents2));
            events.CustomBeforeNavigateEvent += new EventHandler<CustomBeforeNavigateEventArgs>(events_CustomBeforeNavigateEvent);
            events.NavigateErrorEvent += new EventHandler<NavigateErrorEventArgs>(events_NavigateErrorEvent);
        }

        /// <summary>
        /// Detaches the event sink
        /// </summary>
        [PermissionSet(SecurityAction.LinkDemand, Name = "FullTrust")]
        protected override void DetachSink()
        {
            if (null != cookie)
            {
                cookie.Disconnect();
                cookie = null;
            }
        }

        private void events_CustomBeforeNavigateEvent(object sender, CustomBeforeNavigateEventArgs e)
        {
            OnCustomBeforeNavigateEvent(e);            
        }

        void events_NavigateErrorEvent(object sender, NavigateErrorEventArgs e)
        {
            OnNavigateError(e);
        }

        private void OnCustomBeforeNavigateEvent(CustomBeforeNavigateEventArgs e)
        {
            if (CustomBeforeNavigateEvent != null)
            {
                CustomBeforeNavigateEvent(this, e);
            }
        }

        private void OnNavigateError(NavigateErrorEventArgs e)
        {
            if (NavigateErrorEvent != null)
            {
                NavigateErrorEvent(this, e);
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                /*Do nothing on escape key press. 
                  Default browser behaviour clears out text entered into textarea element.*/
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        #endregion
    }
}
