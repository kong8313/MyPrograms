namespace Confirmit.CATI.Console.Views.Controls
{
    public partial class InterviewPageBrowser
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.pnlInputControl = new System.Windows.Forms.Panel();
            this.keyboardInputControl = new Confirmit.CATI.Console.Views.Controls.KeyboardInputControl();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.btnRefuse = new System.Windows.Forms.Button();
            this.btnDefault = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.webBrowser = new Confirmit.CATI.Console.Views.Controls.ExtendedWebBrowser();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.pnlBottom.SuspendLayout();
            this.pnlInputControl.SuspendLayout();
            this.pnlButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            this.pnlBottom.Controls.Add(this.pnlInputControl);
            this.pnlBottom.Controls.Add(this.pnlButtons);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 443);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(616, 37);
            this.pnlBottom.TabIndex = 0;
            // 
            // pnlInputControl
            // 
            this.pnlInputControl.BackColor = System.Drawing.SystemColors.Control;
            this.pnlInputControl.Controls.Add(this.keyboardInputControl);
            this.pnlInputControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlInputControl.Location = new System.Drawing.Point(0, 0);
            this.pnlInputControl.Name = "pnlInputControl";
            this.pnlInputControl.Size = new System.Drawing.Size(501, 37);
            this.pnlInputControl.TabIndex = 1;
            // 
            // keyboardInputControl
            // 
            this.keyboardInputControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.keyboardInputControl.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.keyboardInputControl.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.keyboardInputControl.InputDisabled = false;
            this.keyboardInputControl.InputValue = "";
            this.keyboardInputControl.IsEnabled = true;
            this.keyboardInputControl.Location = new System.Drawing.Point(3, 7);
            this.keyboardInputControl.Name = "keyboardInputControl";
            this.keyboardInputControl.Size = new System.Drawing.Size(495, 22);
            this.keyboardInputControl.TabIndex = 0;
            // 
            // pnlButtons
            // 
            this.pnlButtons.BackColor = System.Drawing.SystemColors.Control;
            this.pnlButtons.Controls.Add(this.btnRefuse);
            this.pnlButtons.Controls.Add(this.btnDefault);
            this.pnlButtons.Controls.Add(this.btnOk);
            this.pnlButtons.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlButtons.Location = new System.Drawing.Point(501, 0);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(115, 37);
            this.pnlButtons.TabIndex = 0;
            // 
            // btnRefuse
            // 
            this.btnRefuse.BackColor = System.Drawing.Color.Transparent;
            this.btnRefuse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRefuse.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnRefuse.FlatAppearance.BorderSize = 0;
            this.btnRefuse.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnRefuse.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.refuse;
            this.btnRefuse.Location = new System.Drawing.Point(76, 6);
            this.btnRefuse.Name = "btnRefuse";
            this.btnRefuse.Size = new System.Drawing.Size(32, 25);
            this.btnRefuse.TabIndex = 2;
            this.btnRefuse.TabStop = false;
            this.toolTip.SetToolTip(this.btnRefuse, "Refused answer");
            this.btnRefuse.UseVisualStyleBackColor = false;
            this.btnRefuse.Click += new System.EventHandler(this.btnRefuse_Click);
            // 
            // btnDefault
            // 
            this.btnDefault.BackColor = System.Drawing.Color.Transparent;
            this.btnDefault.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDefault.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnDefault.FlatAppearance.BorderSize = 0;
            this.btnDefault.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnDefault.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.default_answer;
            this.btnDefault.Location = new System.Drawing.Point(38, 6);
            this.btnDefault.Name = "btnDefault";
            this.btnDefault.Size = new System.Drawing.Size(32, 25);
            this.btnDefault.TabIndex = 1;
            this.btnDefault.TabStop = false;
            this.toolTip.SetToolTip(this.btnDefault, "Default answer");
            this.btnDefault.UseVisualStyleBackColor = false;
            this.btnDefault.Click += new System.EventHandler(this.btnDefault_Click);
            // 
            // btnOk
            // 
            this.btnOk.BackColor = System.Drawing.Color.Transparent;
            this.btnOk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnOk.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnOk.FlatAppearance.BorderSize = 0;
            this.btnOk.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnOk.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.Enter;
            this.btnOk.Location = new System.Drawing.Point(3, 6);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(30, 25);
            this.btnOk.TabIndex = 0;
            this.btnOk.TabStop = false;
            this.toolTip.SetToolTip(this.btnOk, "Enter");
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // webBrowser
            // 
            this.webBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser.IsWebBrowserContextMenuEnabled = false;
            this.webBrowser.Location = new System.Drawing.Point(0, 0);
            this.webBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser.Name = "webBrowser";
            this.webBrowser.Size = new System.Drawing.Size(616, 443);
            this.webBrowser.TabIndex = 0;
            this.webBrowser.TabStop = false;
            this.webBrowser.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.m_WebBrowser_DocumentCompleted);
            // 
            // InterviewPageBrowser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.webBrowser);
            this.Controls.Add(this.pnlBottom);
            this.Name = "InterviewPageBrowser";
            this.Size = new System.Drawing.Size(616, 480);
            this.pnlBottom.ResumeLayout(false);
            this.pnlInputControl.ResumeLayout(false);
            this.pnlButtons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBottom;
        private ExtendedWebBrowser webBrowser;
        private System.Windows.Forms.Panel pnlInputControl;
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnDefault;
        private System.Windows.Forms.Button btnRefuse;
        private KeyboardInputControl keyboardInputControl;
        private System.Windows.Forms.ToolTip toolTip;
    }
}
