﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Resources;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.Classes.Login;
using Confirmit.CATI.Console.Views.Resources;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
    /// <summary>
    /// Form is responsible for extension number enter
    /// </summary>
    public partial class ExtensionNumberForm : Form, IViewExtensionNumberForm
    {
        #region Constructors
        public ExtensionNumberForm()
        {
            InitializeComponent();
            ExtensionNumberInputEnabled = true;
        }
        #endregion

        #region IViewExtensionNumberForm Members

        /// <summary>
        /// Occurs when user click OK button
        /// </summary>
        public event EventHandler<EventArgs> OkClick;

        /// <summary>
        /// Occurs when user click Cancel button
        /// </summary>
        public event EventHandler<CancelEventArgs> CancelClicking;

        /// <summary>
        /// Occurs when extension number name is going to be validated.
        /// </summary>
        public event EventHandler<CancelEventArgs> ValidatingExtensionNumber;

        /// <summary>
        /// Gets value from extension number field
        /// </summary>
        public string ExtensionNumber
        {
            get { return tbExtensionNumber.Text; }
            set { tbExtensionNumber.Text = value; }
        }

        /// <summary>
        /// Gets/sets possibility to enter extension number
        /// </summary>
        /// <remarks>
        /// For TCI dialler this form is used with disabled extension number input.
        /// </remarks>
        public bool ExtensionNumberInputEnabled
        {
            get;
            set;
        }

        /// <summary>
        /// Shows the form as a modal dialog box with the specified owner.
        /// </summary>
        /// <param name="owner">Owner window.</param>
        /// <returns>LoginToDiallerResult object.</returns>
        LoginToDiallerResult IViewExtensionNumberForm.ShowDialog(IWin32Window owner)
        {
            tbExtensionNumber.Enabled = ExtensionNumberInputEnabled;

            LoginToDiallerResult result = LoginToDiallerResult.SkipLoginToDialler;

            DialogResult dialogResult = ShowDialog(owner);
            switch (dialogResult)
            {
                case DialogResult.OK:
                    result = LoginToDiallerResult.LoginToDialler;
                    break;
                case DialogResult.Cancel:
                    result = LoginToDiallerResult.SkipLoginToDialler;
                    break;
                case DialogResult.Abort:
                    result = LoginToDiallerResult.Logout;
                    break;
                default:
                    Logger.Write(Strings.ResourceManager.GetString("Log_UnsupportedLoginToDiallerResult", dialogResult), MessageTypes.Error);
                    break;
            }

            return result;
        }

        /// <summary>
        /// Validates children controls.
        /// </summary>
        /// <returns></returns>
        public override bool ValidateChildren()
        {
            ClearValidationErrors();

            bool result = base.ValidateChildren();

            CancelEventArgs eaExtensionNumber = new CancelEventArgs();

            OnValidatingExtensionNumber(eaExtensionNumber);

            result &= !eaExtensionNumber.Cancel;

            return result;
        }

        /// <summary>
        /// Notifies user about validation error 
        /// </summary>
        /// <param name="message">Error message. Message shouldn't be empty.</param>
        /// <remarks>If the message length is greater than zero, then the error icon is displayed, 
        /// and the ToolTip for the error icon is the error description text. 
        /// If the message length is zero, the error icon is hidden.
        /// </remarks>
        public void AlertValidationError(string message)
        {
            erpExtensionNumber.SetError(tbExtensionNumber, message);
        }

        /// <summary>
        /// Clears all validation errors.
        /// </summary>
        public void ClearValidationErrors()
        {
            erpExtensionNumber.SetError(tbExtensionNumber, String.Empty);
        }

        #endregion

        #region ILocalizableView Members

        /// <summary>
        /// Localizes view according given localization information.
        /// </summary>
        /// <param name="manager">Localization manager which contains localization info.</param>
        public void Localize(ILocalizationManager manager)
        {
            Text = manager.GetString("ExtensionNumberForm_Caption");
            lbTitle.Text = manager.GetString("ExtensionNumberForm_Title");
            lbTitleDescription.Text = manager.GetString("ExtensionNumberForm_TitleDescription");
            btnOk.Text = manager.GetString("ExtensionNumberForm_ButtonOk_Text");
            btnCancel.Text = manager.GetString("ExtensionNumberForm_ButtonCancel_Text");
            btnLogout.Text = manager.GetString("ExtensionNumberForm_ButtonLogout_Text");

            if (ExtensionNumberInputEnabled == false)
            {
                Text = manager.GetString("ExtensionNumberFormNumberInputDisabled_Caption");
                lbTitle.Text = manager.GetString("ExtensionNumberFormNumberInputDisabled_Title");
                lbTitleDescription.Text = manager.GetString("ExtensionNumberFormNumberInputDisabled_TitleDescription");
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Fires ValidatingContactName event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnValidatingExtensionNumber(CancelEventArgs e)
        {
            if (ValidatingExtensionNumber != null)
            {
                ValidatingExtensionNumber(this, e);
            }
        }

        private void BtnOkClick(object sender, EventArgs e)
        {
            if (ValidateChildren())
            {
                OnOkClick(e);
                DialogResult = DialogResult.OK;
                Close();
            }
        }

        /// <summary>
        /// Fires OkClick event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnOkClick(EventArgs e)
        {
            if (OkClick != null)
            {
                OkClick(this, e);
            }
        }


        /// <summary>
        /// Fires CancelClick event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">Event arguments.</param>
        private void BtnCancelClick(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Fires CancelClick event.
        /// </summary>
        /// <param name="args">Event arguments.</param>
        private void OnCancelClicking(CancelEventArgs args)
        {
            if (CancelClicking != null)
            {
                CancelClicking(this, args);
            }
        }

        #endregion

        private void ExtensionNumberFormShown(object sender, EventArgs e)
        {
            tbExtensionNumber.Focus();
        }

        private void ExtensionNumberFormFormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (DialogResult == DialogResult.Cancel)
                {
                    CancelEventArgs args = new CancelEventArgs();
                    OnCancelClicking(args);

                    if (args.Cancel)
                    {
                        e.Cancel = true;
                    }
                }
            }
        }
    }
}
