﻿using System.Collections.Generic;
using Confirmit.CATI.Console.Views.Classes.Interview;
using mshtml;

namespace Confirmit.CATI.Console.Views.Controls
{
    public interface ILegacySurveyPageInteractor
    {
        List<SubQuestion> CurrentQuestionSubQuestions { get; }
        IList<IHTMLElement> CurrentQuestionInputs { get; }
        QuestionType CurrentQuestionType { get; }
    }
}
