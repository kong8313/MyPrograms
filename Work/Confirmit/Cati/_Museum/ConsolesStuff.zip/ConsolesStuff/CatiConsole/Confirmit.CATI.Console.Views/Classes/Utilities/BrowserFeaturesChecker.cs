﻿using System.Collections.Generic;
using System.Linq;

namespace Confirmit.CATI.Console.Views.Classes.Utilities
{
    public enum BrowserFeature
    {
        MutationObserver
    }

    internal class BrowserFeaturesChecker
    {
        private readonly HashSet<BrowserFeature> _disabledFeatures;

        public BrowserFeaturesChecker()
        {
            _disabledFeatures = new HashSet<BrowserFeature>();
        }

        public void Reset()
        {
            _disabledFeatures.Clear();
        }

        public void CheckedFeatureDisabled(BrowserFeature feature)
        {
            _disabledFeatures.Add(feature);
        }

        public List<BrowserFeature> GetUnsupportedBrowserFeatures()
        {
            return _disabledFeatures.ToList();
        }

        public string GetScript()
        {
            var script = @"                
                if(!('MutationObserver' in window)){
			        window.external.CheckedFeatureDisabled('MutationObserver');
                }

                window.external.BrowserFeaturesCheckingIsFinished();";

            return script;
        }
    }
}