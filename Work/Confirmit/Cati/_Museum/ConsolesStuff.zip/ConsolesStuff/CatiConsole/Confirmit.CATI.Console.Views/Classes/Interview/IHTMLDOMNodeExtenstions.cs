﻿using System;
using mshtml;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    static class IHTMLDOMNodeExtenstions
    {
        public static object GetNextSiblingSkipComments(this object node)
        {
            return FindSiblingSkipComments(node, domNode => domNode.nextSibling);
        }

        public static object GetPreviousSiblingSkipComments(this object node)
        {
            return FindSiblingSkipComments(node, domNode => domNode.previousSibling);
        }

        private static object FindSiblingSkipComments(object node, Func<IHTMLDOMNode, object> getSibling)
        {
            var domNode = (IHTMLDOMNode)node;
            while (true)
            {
                var sibling = getSibling(domNode);

                if (sibling == null)
                {
                    return null;
                }

                if (sibling as IHTMLElement == null)
                {
                    /*It's not html element. We should skip it. */
                    return FindSiblingSkipComments(sibling, getSibling);
                }

                string tagName = ((IHTMLElement)sibling).tagName;
                
                if (tagName == "!" || tagName == "!--" )
                {
                    // It's comment. We should skip it.
                    return FindSiblingSkipComments(sibling, getSibling);
                }

                return sibling;
            }
        }
    }
}