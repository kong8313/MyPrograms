﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
	/// <summary>
	/// Represents view entity for NotificationForm.
	/// </summary>
    public interface IViewNotificationForm : ILocalizableView, IDisposable
	{
        string Title { get; set; }

        string Message { get; set; }

		/// <summary>
		/// Shows form.
		/// </summary>
		/// <param name="parent">Parent window handle.</param>
		void Show(IWin32Window parent);

	    void AdjustLocation();

	    int DismissTimeout { get; set; }
	   
        void Close();
	}
}
