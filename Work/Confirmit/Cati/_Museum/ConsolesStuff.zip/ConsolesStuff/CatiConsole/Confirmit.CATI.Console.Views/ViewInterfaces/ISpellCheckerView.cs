﻿using System;
using Confirmit.CATI.Console.Views.Classes.SpellChecking;
using System.Windows.Forms;
using System.Collections.Generic;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Represents view for SpellCheckerForm form.
    /// </summary>
    public interface ISpellCheckerView : ILocalizableView
    {
        /// <summary>
        /// Occurs when form is loaded.
        /// </summary>
        event EventHandler FormLoaded;

        /// <summary>
        /// Occurs when form is closed.
        /// </summary>
        event EventHandler<EventArgs> FormClose;

        event EventHandler IgnoreWord;
        
        event EventHandler IgnoreAllWords;

        event EventHandler DeleteWord;        

        event EventHandler<ChangeEventArgs> ChangeWord;

        event EventHandler<ChangeEventArgs> ChangeAllWords;


        /// <summary>
        /// Shows spell checking text loading sreen.
        /// </summary>
        void ShowLoadingScreen();        

        /// <summary>
        /// Shows spell checking complete sreen.
        /// </summary>
        void ShowCompletionScreen();

        /// <summary>
        /// Shows spell checking error sreen.
        /// </summary>
        /// <param name="errorMessage">Error message.</param>
        void ShowErrorScreen(string errorMessage);

        /// <summary>
        /// Initializes SpellChecker form by certain text block.
        /// </summary>
        /// <param name="questionText">Question text block.</param>
        /// <param name="misspelledWordIndex">Index of misspelled word in the text block.</param>
        /// <param name="misspelledWord">Misspelled word</param>
        /// <param name="suggestions">List of suggestions.</param>
        /// <param name="isRepeatedWord">True if error type is 'Repeated word'.</param>
        void InitTextBlock(string questionText, int misspelledWordIndex, string misspelledWord, IEnumerable<string> suggestions, bool isRepeatedWord);

        /// <summary>
        /// Gets/sets form result describing why user close form.
        /// </summary>
        FormCloseReasons FormResult
        {
            get;
            set;
        }

        /// <summary>
        /// Shows modal spell checker form.
        /// </summary>
        /// <param name="parent">Parent window handle.</param>
        void Show(IWin32Window parent);        
    }
}