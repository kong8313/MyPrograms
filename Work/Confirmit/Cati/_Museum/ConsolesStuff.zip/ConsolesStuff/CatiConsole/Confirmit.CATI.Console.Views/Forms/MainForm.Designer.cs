﻿using System.Security.AccessControl;
using Confirmit.CATI.Console.Views.Classes.StatusBar;
using Confirmit.CATI.Console.Views.Controls;

namespace Confirmit.CATI.Console.Views.Forms
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.mnMainMenu = new System.Windows.Forms.MenuStrip();
            this.pnlStatus = new System.Windows.Forms.Panel();
            this.statusBar = new Confirmit.CATI.Console.Views.Controls.StatusBarControl();
            this.pnlControls = new System.Windows.Forms.Panel();
            this.tscToolbarContainer = new System.Windows.Forms.ToolStripContainer();
            this.processControl = new Confirmit.CATI.Console.Views.Controls.ProcessControl();
            this.hangupControl = new Confirmit.CATI.Console.Views.Controls.HangupControl();
            this.dialingControl = new Confirmit.CATI.Console.Views.Controls.DialControl();
            this.interviewPageBrowser = new Confirmit.CATI.Console.Views.Controls.InterviewPageBrowser();
            this.surveyList = new Confirmit.CATI.Console.Views.Controls.SurveyListControl();
            this.onABreakControl = new Confirmit.CATI.Console.Views.Controls.OnABreakControl();
            this.internalTransferControl = new Confirmit.CATI.Console.Views.Controls.InternalTransferControl();
            this.tsInterviewToolbar = new System.Windows.Forms.ToolStrip();
            this.tsbPrevious = new System.Windows.Forms.ToolStripButton();
            this.tsbNext = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbAppointments = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tscSurveyLanguages = new System.Windows.Forms.ToolStripComboBox();
            this.tsSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbRedo = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsbFastForward = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSpellCheck = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbRedial = new System.Windows.Forms.ToolStripButton();
            this.tsbHangUp = new System.Windows.Forms.ToolStripButton();
            this.tsbInternalCallTransfer = new System.Windows.Forms.ToolStripButton();
            this.tsbExternalCallTransfer = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbLogoutAfterFinish = new System.Windows.Forms.ToolStripButton();
            this.tsbTerminate = new System.Windows.Forms.ToolStripButton();
            this.tsMessaging = new System.Windows.Forms.ToolStrip();
            this.tsbPendingBreak = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbChangeTaskChoice = new System.Windows.Forms.ToolStripButton();
            this.tsbMessageForm = new System.Windows.Forms.ToolStripButton();
            this.tsPlaybackToolbar = new System.Windows.Forms.ToolStrip();
            this.tsbStartPlayback = new System.Windows.Forms.ToolStripButton();
            this.tsbPauseOrResumePlayback = new System.Windows.Forms.ToolStripButton();
            this.tsbStopPlayback = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbToggleInterviewerListensToPlaybackOrRespondent = new System.Windows.Forms.ToolStripButton();
            this.tsToolbar = new System.Windows.Forms.ToolStrip();
            this.tsbAppointmensList = new System.Windows.Forms.ToolStripButton();
            this.tssAppointmentList = new System.Windows.Forms.ToolStripSeparator();
            this.tsbRefresh = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMainLogout = new System.Windows.Forms.ToolStripButton();
            this.tssTestMode = new System.Windows.Forms.ToolStripSeparator();
            this.btnTestMode = new System.Windows.Forms.ToolStripButton();
            this.tssInboundCall = new System.Windows.Forms.ToolStripSeparator();
            this.btnInboundCall = new System.Windows.Forms.ToolStripButton();
            this.pnlMenu.SuspendLayout();
            this.pnlStatus.SuspendLayout();
            this.pnlControls.SuspendLayout();
            this.tscToolbarContainer.ContentPanel.SuspendLayout();
            this.tscToolbarContainer.TopToolStripPanel.SuspendLayout();
            this.tscToolbarContainer.SuspendLayout();
            this.tsInterviewToolbar.SuspendLayout();
            this.tsMessaging.SuspendLayout();
            this.tsPlaybackToolbar.SuspendLayout();
            this.tsToolbar.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMenu
            // 
            this.pnlMenu.Controls.Add(this.mnMainMenu);
            this.pnlMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(951, 0);
            this.pnlMenu.TabIndex = 0;
            // 
            // mnMainMenu
            // 
            this.mnMainMenu.Location = new System.Drawing.Point(0, 0);
            this.mnMainMenu.Name = "mnMainMenu";
            this.mnMainMenu.Size = new System.Drawing.Size(951, 24);
            this.mnMainMenu.TabIndex = 0;
            this.mnMainMenu.Text = "menuStrip1";
            // 
            // pnlStatus
            // 
            this.pnlStatus.Controls.Add(this.statusBar);
            this.pnlStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlStatus.Location = new System.Drawing.Point(0, 549);
            this.pnlStatus.Name = "pnlStatus";
            this.pnlStatus.Size = new System.Drawing.Size(951, 23);
            this.pnlStatus.TabIndex = 1;
            // 
            // statusBar
            // 
            this.statusBar.CurrentPosition = "";
            this.statusBar.CurrentState = "";
            this.statusBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statusBar.InterviewerTime = "Interviewer time: ";
            this.statusBar.InterviewName = "Interview: ";
            this.statusBar.Location = new System.Drawing.Point(0, 0);
            this.statusBar.Mode = Confirmit.CATI.Console.Views.Classes.StatusBar.StatusBarModes.LoginView;
            this.statusBar.Name = "statusBar";
            this.statusBar.QuestionName = "";
            this.statusBar.RespondentTime = "";
            this.statusBar.Size = new System.Drawing.Size(951, 23);
            this.statusBar.SurveyName = "";
            this.statusBar.TabIndex = 0;
            this.statusBar.TabStop = false;
            this.statusBar.UserName = "";
            this.statusBar.Version = "";
            // 
            // pnlControls
            // 
            this.pnlControls.BackColor = System.Drawing.SystemColors.Window;
            this.pnlControls.Controls.Add(this.tscToolbarContainer);
            this.pnlControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlControls.Location = new System.Drawing.Point(0, 0);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(951, 549);
            this.pnlControls.TabIndex = 2;
            // 
            // tscToolbarContainer
            // 
            // 
            // tscToolbarContainer.ContentPanel
            // 
            this.tscToolbarContainer.ContentPanel.Controls.Add(this.processControl);
            this.tscToolbarContainer.ContentPanel.Controls.Add(this.hangupControl);
            this.tscToolbarContainer.ContentPanel.Controls.Add(this.dialingControl);
            this.tscToolbarContainer.ContentPanel.Controls.Add(this.interviewPageBrowser);
            this.tscToolbarContainer.ContentPanel.Controls.Add(this.surveyList);
            this.tscToolbarContainer.ContentPanel.Controls.Add(this.onABreakControl);
            this.tscToolbarContainer.ContentPanel.Controls.Add(this.internalTransferControl);
            this.tscToolbarContainer.ContentPanel.Size = new System.Drawing.Size(951, 508);
            this.tscToolbarContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tscToolbarContainer.Location = new System.Drawing.Point(0, 0);
            this.tscToolbarContainer.Name = "tscToolbarContainer";
            this.tscToolbarContainer.Size = new System.Drawing.Size(951, 549);
            this.tscToolbarContainer.TabIndex = 3;
            this.tscToolbarContainer.Text = "toolStripContainer1";
            // 
            // tscToolbarContainer.TopToolStripPanel
            // 
            this.tscToolbarContainer.TopToolStripPanel.Controls.Add(this.tsInterviewToolbar);
            this.tscToolbarContainer.TopToolStripPanel.Controls.Add(this.tsMessaging);
            this.tscToolbarContainer.TopToolStripPanel.Controls.Add(this.tsPlaybackToolbar);
            this.tscToolbarContainer.TopToolStripPanel.Controls.Add(this.tsToolbar);
            this.tscToolbarContainer.TopToolStripPanel.MaximumSize = new System.Drawing.Size(0, 42);
            // 
            // processControl
            // 
            this.processControl.BackColor = System.Drawing.SystemColors.Window;
            this.processControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.processControl.Location = new System.Drawing.Point(0, 0);
            this.processControl.Name = "processControl";
            this.processControl.Size = new System.Drawing.Size(951, 508);
            this.processControl.TabIndex = 6;
            // 
            // hangupControl
            // 
            this.hangupControl.BackColor = System.Drawing.SystemColors.Window;
            this.hangupControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hangupControl.Location = new System.Drawing.Point(0, 0);
            this.hangupControl.Name = "hangupControl";
            this.hangupControl.Size = new System.Drawing.Size(951, 508);
            this.hangupControl.TabIndex = 5;
            this.hangupControl.Visible = false;
            // 
            // dialingControl
            // 
            this.dialingControl.BackColor = System.Drawing.SystemColors.Window;
            this.dialingControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dialingControl.HangupMessage = null;
            this.dialingControl.IsDialCanellationButtonEnabled = true;
            this.dialingControl.Location = new System.Drawing.Point(0, 0);
            this.dialingControl.Message = "Dialing. Please wait.";
            this.dialingControl.Name = "dialingControl";
            this.dialingControl.Phone = "";
            this.dialingControl.Size = new System.Drawing.Size(951, 508);
            this.dialingControl.TabIndex = 4;
            this.dialingControl.Visible = false;
            // 
            // interviewPageBrowser
            // 
            this.interviewPageBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.interviewPageBrowser.ExtendedLoggingEnabled = false;
            this.interviewPageBrowser.Location = new System.Drawing.Point(0, 0);
            this.interviewPageBrowser.MouseClickAnswerMonitoringDelay = 0;
            this.interviewPageBrowser.Name = "interviewPageBrowser";
            this.interviewPageBrowser.PageUpdateMonitoringDelay = 0;
            this.interviewPageBrowser.ReadOnly = false;
            this.interviewPageBrowser.Size = new System.Drawing.Size(951, 508);
            this.interviewPageBrowser.TabIndex = 3;
            // 
            // surveyList
            // 
            this.surveyList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.surveyList.Location = new System.Drawing.Point(0, 0);
            this.surveyList.Name = "surveyList";
            this.surveyList.SelectedSurvey = -1;
            this.surveyList.Size = new System.Drawing.Size(951, 508);
            this.surveyList.TabIndex = 1;
            // 
            // onABreakControl
            // 
            this.onABreakControl.BackColor = System.Drawing.SystemColors.Window;
            this.onABreakControl.BreakTypeInfo = null;
            this.onABreakControl.ButtonsEnabled = true;
            this.onABreakControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.onABreakControl.Location = new System.Drawing.Point(0, 0);
            this.onABreakControl.Name = "onABreakControl";
            this.onABreakControl.Size = new System.Drawing.Size(951, 508);
            this.onABreakControl.StartTime = new System.DateTime(((long)(0)));
            this.onABreakControl.TabIndex = 7;
            // 
            // internalTransferControl
            // 
            this.internalTransferControl.BackColor = System.Drawing.SystemColors.Window;
            this.internalTransferControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.internalTransferControl.Location = new System.Drawing.Point(0, 0);
            this.internalTransferControl.Name = "internalTransferControl";
            this.internalTransferControl.Size = new System.Drawing.Size(951, 508);
            this.internalTransferControl.TabIndex = 8;
            // 
            // tsInterviewToolbar
            // 
            this.tsInterviewToolbar.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.tsInterviewToolbar.Dock = System.Windows.Forms.DockStyle.None;
            this.tsInterviewToolbar.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tsInterviewToolbar.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsInterviewToolbar.ImageScalingSize = new System.Drawing.Size(34, 34);
            this.tsInterviewToolbar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbPrevious,
            this.tsbNext,
            this.tsSeparator1,
            this.tsbAppointments,
            this.tsSeparator2,
            this.tscSurveyLanguages,
            this.tsSeparator3,
            this.tsbRedo,
            this.tsbFastForward,
            this.toolStripSeparator3,
            this.tsbSpellCheck,
            this.tsSeparator4,
            this.tsbRedial,
            this.tsbHangUp,
            this.tsbInternalCallTransfer,
            this.tsbExternalCallTransfer,
            this.toolStripSeparator2,
            this.tsbLogoutAfterFinish,
            this.tsbTerminate});
            this.tsInterviewToolbar.Location = new System.Drawing.Point(3, 0);
            this.tsInterviewToolbar.Name = "tsInterviewToolbar";
            this.tsInterviewToolbar.Size = new System.Drawing.Size(627, 41);
            this.tsInterviewToolbar.TabIndex = 0;
            // 
            // tsbPrevious
            // 
            this.tsbPrevious.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPrevious.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tsbPrevious.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.prev;
            this.tsbPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPrevious.Name = "tsbPrevious";
            this.tsbPrevious.Size = new System.Drawing.Size(38, 38);
            this.tsbPrevious.Text = "Previuos page";
            this.tsbPrevious.ToolTipText = "Previous page";
            this.tsbPrevious.Click += new System.EventHandler(this.tsbPrevious_Click);
            // 
            // tsbNext
            // 
            this.tsbNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbNext.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tsbNext.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.next;
            this.tsbNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNext.Name = "tsbNext";
            this.tsbNext.Size = new System.Drawing.Size(38, 38);
            this.tsbNext.ToolTipText = "Next page";
            this.tsbNext.Click += new System.EventHandler(this.tsbNext_Click);
            // 
            // tsSeparator1
            // 
            this.tsSeparator1.Name = "tsSeparator1";
            this.tsSeparator1.Size = new System.Drawing.Size(6, 41);
            // 
            // tsbAppointments
            // 
            this.tsbAppointments.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAppointments.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tsbAppointments.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.appointment;
            this.tsbAppointments.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAppointments.Name = "tsbAppointments";
            this.tsbAppointments.Size = new System.Drawing.Size(38, 38);
            this.tsbAppointments.ToolTipText = "Appointment";
            this.tsbAppointments.Click += new System.EventHandler(this.tsbAppointments_Click);
            // 
            // tsSeparator2
            // 
            this.tsSeparator2.Name = "tsSeparator2";
            this.tsSeparator2.Size = new System.Drawing.Size(6, 41);
            // 
            // tscSurveyLanguages
            // 
            this.tscSurveyLanguages.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tscSurveyLanguages.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tscSurveyLanguages.Name = "tscSurveyLanguages";
            this.tscSurveyLanguages.Size = new System.Drawing.Size(121, 41);
            this.tscSurveyLanguages.ToolTipText = "Survey languages";
            this.tscSurveyLanguages.SelectedIndexChanged += new System.EventHandler(this.tscSurveyLanguages_SelectedIndexChanged);
            // 
            // tsSeparator3
            // 
            this.tsSeparator3.Name = "tsSeparator3";
            this.tsSeparator3.Size = new System.Drawing.Size(6, 41);
            // 
            // tsbRedo
            // 
            this.tsbRedo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRedo.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tsbRedo.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.redo;
            this.tsbRedo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRedo.Name = "tsbRedo";
            this.tsbRedo.Size = new System.Drawing.Size(47, 38);
            this.tsbRedo.Text = "Redo";
            this.tsbRedo.DropDownClosed += new System.EventHandler(this.tsbRedo_DropDownClosed);
            this.tsbRedo.DropDownOpening += new System.EventHandler(this.tsbRedo_DropDownOpening);
            this.tsbRedo.DropDownOpened += new System.EventHandler(this.tsbRedo_DropDownOpened);
            this.tsbRedo.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.tsbRedo_DropDownItemClicked);
            // 
            // tsbFastForward
            // 
            this.tsbFastForward.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbFastForward.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tsbFastForward.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.fast_forward;
            this.tsbFastForward.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbFastForward.Name = "tsbFastForward";
            this.tsbFastForward.Size = new System.Drawing.Size(38, 38);
            this.tsbFastForward.Text = "toolStripButton1";
            this.tsbFastForward.ToolTipText = "Fast forward";
            this.tsbFastForward.Click += new System.EventHandler(this.tsbFastForward_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 41);
            // 
            // tsbSpellCheck
            // 
            this.tsbSpellCheck.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSpellCheck.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.SpellCheck;
            this.tsbSpellCheck.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSpellCheck.Name = "tsbSpellCheck";
            this.tsbSpellCheck.Size = new System.Drawing.Size(38, 38);
            this.tsbSpellCheck.Text = "toolStripButton1";
            this.tsbSpellCheck.ToolTipText = "Check spelling";
            this.tsbSpellCheck.Click += new System.EventHandler(this.tsbSpellCheck_Click);
            // 
            // tsSeparator4
            // 
            this.tsSeparator4.Name = "tsSeparator4";
            this.tsSeparator4.Size = new System.Drawing.Size(6, 41);
            // 
            // tsbRedial
            // 
            this.tsbRedial.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRedial.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.Redial;
            this.tsbRedial.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRedial.Name = "tsbRedial";
            this.tsbRedial.Size = new System.Drawing.Size(38, 38);
            this.tsbRedial.Text = "Redial";
            this.tsbRedial.Click += new System.EventHandler(this.tsbRedial_Click);
            // 
            // tsbHangUp
            // 
            this.tsbHangUp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbHangUp.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.HangUp;
            this.tsbHangUp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbHangUp.Name = "tsbHangUp";
            this.tsbHangUp.Size = new System.Drawing.Size(38, 38);
            this.tsbHangUp.Text = "Redial";
            this.tsbHangUp.Click += new System.EventHandler(this.tsbHangUp_Click);
            // 
            // tsbInternalCallTransfer
            // 
            this.tsbInternalCallTransfer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbInternalCallTransfer.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.InternalCallTransfer;
            this.tsbInternalCallTransfer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbInternalCallTransfer.Name = "tsbInternalCallTransfer";
            this.tsbInternalCallTransfer.Size = new System.Drawing.Size(38, 38);
            this.tsbInternalCallTransfer.Text = "Internal Call Transfer";
            this.tsbInternalCallTransfer.ToolTipText = "Internal Call Transfer";
            this.tsbInternalCallTransfer.Click += new System.EventHandler(this.tsbInternalCallTransfer_Click);
            // 
            // tsbExternalCallTransfer
            // 
            this.tsbExternalCallTransfer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbExternalCallTransfer.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.ExternalCallTransfer;
            this.tsbExternalCallTransfer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbExternalCallTransfer.Name = "tsbExternalCallTransfer";
            this.tsbExternalCallTransfer.Size = new System.Drawing.Size(38, 38);
            this.tsbExternalCallTransfer.Text = "External Call Transfer";
            this.tsbExternalCallTransfer.ToolTipText = "External Call Transfer";
            this.tsbExternalCallTransfer.Click += new System.EventHandler(this.tsbExternalCallTransfer_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 41);
            // 
            // tsbLogoutAfterFinish
            // 
            this.tsbLogoutAfterFinish.AutoSize = false;
            this.tsbLogoutAfterFinish.CheckOnClick = true;
            this.tsbLogoutAfterFinish.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbLogoutAfterFinish.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tsbLogoutAfterFinish.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.Logout;
            this.tsbLogoutAfterFinish.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLogoutAfterFinish.Name = "tsbLogoutAfterFinish";
            this.tsbLogoutAfterFinish.Size = new System.Drawing.Size(38, 38);
            this.tsbLogoutAfterFinish.ToolTipText = "Log out after finishing current interview";
            this.tsbLogoutAfterFinish.CheckedChanged += new System.EventHandler(this.tsbLogoutAfterFinish_CheckedChanged);
            this.tsbLogoutAfterFinish.Click += new System.EventHandler(this.tsbLogoutAfterFinish_Click);
            // 
            // tsbTerminate
            // 
            this.tsbTerminate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbTerminate.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tsbTerminate.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.terminate;
            this.tsbTerminate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTerminate.Name = "tsbTerminate";
            this.tsbTerminate.Size = new System.Drawing.Size(38, 38);
            this.tsbTerminate.ToolTipText = "Terminate current interview";
            this.tsbTerminate.Click += new System.EventHandler(this.tbsTerminate_Click);
            // 
            // tsMessaging
            // 
            this.tsMessaging.Dock = System.Windows.Forms.DockStyle.None;
            this.tsMessaging.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsMessaging.ImageScalingSize = new System.Drawing.Size(34, 34);
            this.tsMessaging.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbPendingBreak,
            this.toolStripSeparator5,
            this.tsbChangeTaskChoice,
            this.tsbMessageForm});
            this.tsMessaging.Location = new System.Drawing.Point(630, 0);
            this.tsMessaging.Name = "tsMessaging";
            this.tsMessaging.Size = new System.Drawing.Size(123, 41);
            this.tsMessaging.TabIndex = 2;
            // 
            // tsbPendingBreak
            // 
            this.tsbPendingBreak.AutoSize = false;
            this.tsbPendingBreak.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPendingBreak.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.WorkBreak;
            this.tsbPendingBreak.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPendingBreak.Name = "tsbPendingBreak";
            this.tsbPendingBreak.ShowDropDownArrow = false;
            this.tsbPendingBreak.Size = new System.Drawing.Size(38, 38);
            this.tsbPendingBreak.Text = "Take break";
            this.tsbPendingBreak.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.tsbPendingBreak_DropDownItemClicked);
            this.tsbPendingBreak.Click += new System.EventHandler(this.tsbPendingBreak_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 41);
            // 
            // tsbChangeTaskChoice
            // 
            this.tsbChangeTaskChoice.AutoSize = false;
            this.tsbChangeTaskChoice.CheckOnClick = true;
            this.tsbChangeTaskChoice.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbChangeTaskChoice.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.ChangeTaskChoice;
            this.tsbChangeTaskChoice.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbChangeTaskChoice.Name = "tsbChangeTaskChoice";
            this.tsbChangeTaskChoice.Size = new System.Drawing.Size(38, 38);
            this.tsbChangeTaskChoice.Text = "Change task choice";
            this.tsbChangeTaskChoice.CheckedChanged += new System.EventHandler(this.tsbChangeTaskChoice_CheckedChanged);
            this.tsbChangeTaskChoice.Click += new System.EventHandler(this.tsbChangeTaskChoice_Click);
            // 
            // tsbMessageForm
            // 
            this.tsbMessageForm.AutoSize = false;
            this.tsbMessageForm.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMessageForm.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.MessageBox;
            this.tsbMessageForm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMessageForm.Name = "tsbMessageForm";
            this.tsbMessageForm.Size = new System.Drawing.Size(38, 38);
            this.tsbMessageForm.Text = "toolStripButton1";
            this.tsbMessageForm.Click += new System.EventHandler(this.tsbMessageForm_Click);
            // 
            // tsPlaybackToolbar
            // 
            this.tsPlaybackToolbar.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.tsPlaybackToolbar.Dock = System.Windows.Forms.DockStyle.None;
            this.tsPlaybackToolbar.Font = new System.Drawing.Font("Tahoma", 11F);
            this.tsPlaybackToolbar.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsPlaybackToolbar.ImageScalingSize = new System.Drawing.Size(34, 34);
            this.tsPlaybackToolbar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbStartPlayback,
            this.tsbPauseOrResumePlayback,
            this.tsbStopPlayback,
            this.toolStripSeparator4,
            this.tsbToggleInterviewerListensToPlaybackOrRespondent});
            this.tsPlaybackToolbar.Location = new System.Drawing.Point(677, 0);
            this.tsPlaybackToolbar.Name = "tsPlaybackToolbar";
            this.tsPlaybackToolbar.Size = new System.Drawing.Size(161, 41);
            this.tsPlaybackToolbar.TabIndex = 3;
            this.tsPlaybackToolbar.Visible = false;
            // 
            // tsbStartPlayback
            // 
            this.tsbStartPlayback.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbStartPlayback.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.play;
            this.tsbStartPlayback.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbStartPlayback.Name = "tsbStartPlayback";
            this.tsbStartPlayback.Size = new System.Drawing.Size(38, 38);
            this.tsbStartPlayback.Text = "Play sound fragment to respondent";
            this.tsbStartPlayback.ToolTipText = "Play sound fragment to respondent";
            this.tsbStartPlayback.Click += new System.EventHandler(this.tsbStartPlayback_Click);
            // 
            // tsbPauseOrResumePlayback
            // 
            this.tsbPauseOrResumePlayback.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPauseOrResumePlayback.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.pause;
            this.tsbPauseOrResumePlayback.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPauseOrResumePlayback.Name = "tsbPauseOrResumePlayback";
            this.tsbPauseOrResumePlayback.Size = new System.Drawing.Size(38, 38);
            this.tsbPauseOrResumePlayback.Text = "Pause/Resume playing sound fragment to respondent";
            this.tsbPauseOrResumePlayback.ToolTipText = "Pause/Resume playing sound fragment to respondent";
            this.tsbPauseOrResumePlayback.Click += new System.EventHandler(this.tsbPauseOrResumePlayback_Click);
            // 
            // tsbStopPlayback
            // 
            this.tsbStopPlayback.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbStopPlayback.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.stop;
            this.tsbStopPlayback.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbStopPlayback.Name = "tsbStopPlayback";
            this.tsbStopPlayback.Size = new System.Drawing.Size(38, 38);
            this.tsbStopPlayback.Text = "Stop playing sound fragment to respondent";
            this.tsbStopPlayback.Click += new System.EventHandler(this.tsbStopPlayback_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 41);
            // 
            // tsbToggleInterviewerListensToPlaybackOrRespondent
            // 
            this.tsbToggleInterviewerListensToPlaybackOrRespondent.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbToggleInterviewerListensToPlaybackOrRespondent.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.ToggleVoiceSource;
            this.tsbToggleInterviewerListensToPlaybackOrRespondent.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbToggleInterviewerListensToPlaybackOrRespondent.Name = "tsbToggleInterviewerListensToPlaybackOrRespondent";
            this.tsbToggleInterviewerListensToPlaybackOrRespondent.Size = new System.Drawing.Size(38, 38);
            this.tsbToggleInterviewerListensToPlaybackOrRespondent.Text = "Toggle voice source between respondent and playback";
            this.tsbToggleInterviewerListensToPlaybackOrRespondent.Click += new System.EventHandler(this.tsbToggleInterviewerListensToPlaybackOrRespondent_Click);
            // 
            // tsToolbar
            // 
            this.tsToolbar.Dock = System.Windows.Forms.DockStyle.None;
            this.tsToolbar.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsToolbar.ImageScalingSize = new System.Drawing.Size(34, 34);
            this.tsToolbar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbAppointmensList,
            this.tssAppointmentList,
            this.tsbRefresh,
            this.toolStripSeparator1,
            this.tsbMainLogout,
            this.tssTestMode,
            this.btnTestMode,
            this.tssInboundCall,
            this.btnInboundCall});
            this.tsToolbar.Location = new System.Drawing.Point(753, 0);
            this.tsToolbar.Name = "tsToolbar";
            this.tsToolbar.Size = new System.Drawing.Size(198, 41);
            this.tsToolbar.TabIndex = 1;
            // 
            // tsbAppointmensList
            // 
            this.tsbAppointmensList.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAppointmensList.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.Appointmens;
            this.tsbAppointmensList.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAppointmensList.Name = "tsbAppointmensList";
            this.tsbAppointmensList.Size = new System.Drawing.Size(38, 38);
            this.tsbAppointmensList.Text = "Show my appointments";
            this.tsbAppointmensList.Click += new System.EventHandler(this.tsbAppointmensList_Click);
            // 
            // tssAppointmentList
            // 
            this.tssAppointmentList.Name = "tssAppointmentList";
            this.tssAppointmentList.Size = new System.Drawing.Size(6, 41);
            this.tssAppointmentList.Visible = false;
            // 
            // tsbRefresh
            // 
            this.tsbRefresh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRefresh.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tsbRefresh.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.refresh;
            this.tsbRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRefresh.Name = "tsbRefresh";
            this.tsbRefresh.Size = new System.Drawing.Size(38, 38);
            this.tsbRefresh.Text = "Refresh";
            this.tsbRefresh.Click += new System.EventHandler(this.tsbRefresh_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 41);
            // 
            // tsbMainLogout
            // 
            this.tsbMainLogout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMainLogout.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tsbMainLogout.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.Logout;
            this.tsbMainLogout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMainLogout.Name = "tsbMainLogout";
            this.tsbMainLogout.Size = new System.Drawing.Size(38, 38);
            this.tsbMainLogout.Text = "Log out";
            this.tsbMainLogout.Click += new System.EventHandler(this.tsbMainLogout_Click);
            // 
            // tssTestMode
            // 
            this.tssTestMode.Name = "tssTestMode";
            this.tssTestMode.Size = new System.Drawing.Size(6, 41);
            // 
            // btnTestMode
            // 
            this.btnTestMode.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnTestMode.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnTestMode.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.test_mode;
            this.btnTestMode.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnTestMode.Name = "btnTestMode";
            this.btnTestMode.Size = new System.Drawing.Size(110, 38);
            this.btnTestMode.Text = "TEST MODE";
            this.btnTestMode.Visible = false;
            // 
            // tssInboundCall
            // 
            this.tssInboundCall.Name = "tssInboundCall";
            this.tssInboundCall.Size = new System.Drawing.Size(6, 41);
            // 
            // btnInboundCall
            // 
            this.btnInboundCall.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnInboundCall.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnInboundCall.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.inbound_call;
            this.btnInboundCall.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnInboundCall.Name = "btnInboundCall";
            this.btnInboundCall.Size = new System.Drawing.Size(132, 38);
            this.btnInboundCall.Text = "INBOUND CALL";
            this.btnInboundCall.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(951, 572);
            this.Controls.Add(this.pnlControls);
            this.Controls.Add(this.pnlStatus);
            this.Controls.Add(this.pnlMenu);
            this.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.Name = "MainForm";
            this.Text = "Cati Interviewer Console";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.MainForm_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.LostFocus += new System.EventHandler(this.MainForm_LostFocus);
            this.pnlMenu.ResumeLayout(false);
            this.pnlMenu.PerformLayout();
            this.pnlStatus.ResumeLayout(false);
            this.pnlControls.ResumeLayout(false);
            this.tscToolbarContainer.ContentPanel.ResumeLayout(false);
            this.tscToolbarContainer.TopToolStripPanel.ResumeLayout(false);
            this.tscToolbarContainer.TopToolStripPanel.PerformLayout();
            this.tscToolbarContainer.ResumeLayout(false);
            this.tscToolbarContainer.PerformLayout();
            this.tsInterviewToolbar.ResumeLayout(false);
            this.tsInterviewToolbar.PerformLayout();
            this.tsMessaging.ResumeLayout(false);
            this.tsMessaging.PerformLayout();
            this.tsPlaybackToolbar.ResumeLayout(false);
            this.tsPlaybackToolbar.PerformLayout();
            this.tsToolbar.ResumeLayout(false);
            this.tsToolbar.PerformLayout();
            this.ResumeLayout(false);

		}
        
        #endregion

		private System.Windows.Forms.Panel pnlMenu;
		private System.Windows.Forms.MenuStrip mnMainMenu;
		private System.Windows.Forms.Panel pnlStatus;
        private System.Windows.Forms.Panel pnlControls;
        private InterviewPageBrowser interviewPageBrowser;
        private SurveyListControl surveyList;
		private System.Windows.Forms.ToolStripContainer tscToolbarContainer;
		private System.Windows.Forms.ToolStrip tsInterviewToolbar;
		private System.Windows.Forms.ToolStripButton tsbPrevious;
		private System.Windows.Forms.ToolStripButton tsbNext;
		private System.Windows.Forms.ToolStripSeparator tsSeparator1;
		private System.Windows.Forms.ToolStripButton tsbAppointments;
		private System.Windows.Forms.ToolStripSeparator tsSeparator2;
		private System.Windows.Forms.ToolStripButton tsbLogoutAfterFinish;
		private System.Windows.Forms.ToolStripButton tsbTerminate;
		private System.Windows.Forms.ToolStrip tsToolbar;
        private System.Windows.Forms.ToolStripButton tsbMainLogout;
        private StatusBarControl statusBar;
        private System.Windows.Forms.ToolStripDropDownButton tsbRedo;
        private System.Windows.Forms.ToolStripSeparator tsSeparator4;
        private System.Windows.Forms.ToolStripButton tsbFastForward;
        private DialControl dialingControl;
        private HangupControl hangupControl;
        private ProcessControl processControl;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbRefresh;
        private System.Windows.Forms.ToolStripComboBox tscSurveyLanguages;
        private System.Windows.Forms.ToolStripSeparator tsSeparator3;
        private System.Windows.Forms.ToolStripButton tsbAppointmensList;
        private System.Windows.Forms.ToolStripSeparator tssAppointmentList;
        private System.Windows.Forms.ToolStrip tsMessaging;
        private System.Windows.Forms.ToolStripButton tsbMessageForm;
        private System.Windows.Forms.ToolStripButton tsbHangUp;
        private System.Windows.Forms.ToolStripButton tsbRedial;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStrip tsPlaybackToolbar;
        private System.Windows.Forms.ToolStripButton tsbStartPlayback;
        private System.Windows.Forms.ToolStripButton tsbPauseOrResumePlayback;
        private System.Windows.Forms.ToolStripButton tsbStopPlayback;
        private System.Windows.Forms.ToolStripButton tsbToggleInterviewerListensToPlaybackOrRespondent;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton tsbSpellCheck;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripDropDownButton tsbPendingBreak;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private OnABreakControl onABreakControl;
        private System.Windows.Forms.ToolStripButton tsbChangeTaskChoice;
        private System.Windows.Forms.ToolStripSeparator tssTestMode;
        private System.Windows.Forms.ToolStripButton btnTestMode;
	    private System.Windows.Forms.ToolStripSeparator tssInboundCall;
        private System.Windows.Forms.ToolStripButton btnInboundCall;
        private System.Windows.Forms.ToolStripButton tsbInternalCallTransfer;
        private System.Windows.Forms.ToolStripButton tsbExternalCallTransfer;
        private InternalTransferControl internalTransferControl;
    }
}

