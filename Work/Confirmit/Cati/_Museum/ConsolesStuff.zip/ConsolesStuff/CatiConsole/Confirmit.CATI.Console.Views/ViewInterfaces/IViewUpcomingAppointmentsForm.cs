﻿using System;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Represents interface to InterviewerAppointmentsForm form
    /// </summary>
    public interface IViewInterviewerAppointmentsForm : ILocalizableView, IDisposable
    {
        /// <summary>
        /// Shows modal Interviewer Appointments form.
        /// </summary>
        /// <returns>Retruns dialog result.</returns>
        DialogResult Show();

        /// <summary>
        /// Binds appointmens list.
        /// </summary>
        /// <param name="interviews">Appointmens array.</param>
        void Bind(string[][] appointmens);
    }
}
