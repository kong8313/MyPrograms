﻿using System;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    /// <summary>
    /// Contains arguments of DialCancellation event.
    /// </summary>
    public class DialCancellationEventArgs : EventArgs
    {
        /// <summary>
        /// Gets/sets IsConfirmationDialogRequiored.
        /// </summary>
        public bool IsConfirmationDialogRequired
        {
            get;
            set;
        }
    }
}