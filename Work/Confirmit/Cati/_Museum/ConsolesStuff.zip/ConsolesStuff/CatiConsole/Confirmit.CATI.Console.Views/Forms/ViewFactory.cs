﻿using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
    /// <summary>
    /// Represents enumeration of views.
    /// </summary>
    public enum FormViews
    {
        /// <summary>
        /// Appointment form view.
        /// </summary>
        AppointmentView = 1,

        /// <summary>
        /// License form view.
        /// </summary>
        LincenseView = 2,

        /// <summary>
        /// Interviewer Appointmens form view.
        /// </summary>
        InterviewerAppointmensView = 3,

        /// <summary>
        /// Interviewer Task choice form
        /// </summary>
        TaskChoiceView = 4,

        /// <summary>
        /// StationId form
        /// </summary>
        StationIdView = 5,

        /// <summary>
        /// SpellChecker dialog form.
        /// </summary>
        SpellCheckerView = 6,

        RedialView = 7,

        NotificationView = 8,

        InternalCallTransferView = 9,
        ExternalCallTransferView = 10,
        WarmTransferView = 11
    }

    /// <summary>
    /// Factory method for creating views.
    /// </summary>
    public static class ViewFactory
    {
        public static object GetView(FormViews view)
        {
            object result = null;

            switch (view)
            {
                case FormViews.AppointmentView:
                    result = (IViewAppointmentForm)(new AppointmentForm());
                    break;
                case FormViews.LincenseView:
                    result = (IViewLicenseForm)(new LicenseForm());
                    break;
                case FormViews.InterviewerAppointmensView:
                    result = (IViewInterviewerAppointmentsForm)(new InterviewerAppointmentsForm());
                    break;
                case FormViews.TaskChoiceView:
                    result = (IViewSelectTaskChoiceForm)(new TaskChoiceForm());
                    break;
                case FormViews.StationIdView:
                    result = (IViewStationIdForm)(new StationIdForm());
                    break;
                case FormViews.SpellCheckerView:
                    result = (ISpellCheckerView)(new SpellCheckerForm());
                    break;
                case FormViews.RedialView:
                    result = (IViewRedialForm)(new RedialForm());
                    break;
                case FormViews.NotificationView:
                    result = (IViewNotificationForm)(new NotificationForm());
                    break;
                case FormViews.InternalCallTransferView:
                    result = (IViewInternalCallTransferForm)(new InternalCallTransferForm());
                    break;
                case FormViews.ExternalCallTransferView:
                    result = (IViewExternalCallTransferForm)(new ExternalCallTransferForm());
                    break;
                case FormViews.WarmTransferView:
                    result = new WarmTransferForm();
                    break;
            }

            return result;
        }
    }
}
