﻿namespace Confirmit.CATI.Console.Views.Forms
{
    partial class SpellCheckerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainPanel = new System.Windows.Forms.Panel();
            this.CenterPanel = new System.Windows.Forms.Panel();
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.tlpChangePanel = new System.Windows.Forms.TableLayoutPanel();
            this.lblSuggestions = new System.Windows.Forms.Label();
            this.tbChangeTo = new System.Windows.Forms.TextBox();
            this.lbSuggestionList = new System.Windows.Forms.ListBox();
            this.rtbText = new System.Windows.Forms.RichTextBox();
            this.lblChangeTo = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnIgnoreAll = new System.Windows.Forms.Button();
            this.btnIgnore = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pnlDeleteButtons = new System.Windows.Forms.Panel();
            this.btnDelete = new System.Windows.Forms.Button();
            this.pnlChangeButtons = new System.Windows.Forms.Panel();
            this.btnChangeAll = new System.Windows.Forms.Button();
            this.btnChange = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblStatus = new System.Windows.Forms.Label();
            this.bottomPanel = new System.Windows.Forms.Panel();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.mainPanel.SuspendLayout();
            this.CenterPanel.SuspendLayout();
            this.tableLayoutPanel.SuspendLayout();
            this.tlpChangePanel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnlDeleteButtons.SuspendLayout();
            this.pnlChangeButtons.SuspendLayout();
            this.panel1.SuspendLayout();
            this.bottomPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainPanel
            // 
            this.mainPanel.Controls.Add(this.CenterPanel);
            this.mainPanel.Controls.Add(this.panel1);
            this.mainPanel.Controls.Add(this.bottomPanel);
            this.mainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainPanel.Location = new System.Drawing.Point(0, 0);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(541, 333);
            this.mainPanel.TabIndex = 0;
            // 
            // CenterPanel
            // 
            this.CenterPanel.Controls.Add(this.tableLayoutPanel);
            this.CenterPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CenterPanel.Location = new System.Drawing.Point(0, 25);
            this.CenterPanel.Name = "CenterPanel";
            this.CenterPanel.Size = new System.Drawing.Size(541, 276);
            this.CenterPanel.TabIndex = 3;
            // 
            // tableLayoutPanel
            // 
            this.tableLayoutPanel.ColumnCount = 2;
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 133F));
            this.tableLayoutPanel.Controls.Add(this.tlpChangePanel, 0, 2);
            this.tableLayoutPanel.Controls.Add(this.rtbText, 0, 0);
            this.tableLayoutPanel.Controls.Add(this.lblChangeTo, 0, 1);
            this.tableLayoutPanel.Controls.Add(this.panel2, 1, 0);
            this.tableLayoutPanel.Controls.Add(this.panel3, 1, 2);
            this.tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel.Name = "tableLayoutPanel";
            this.tableLayoutPanel.RowCount = 3;
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.Size = new System.Drawing.Size(541, 276);
            this.tableLayoutPanel.TabIndex = 1;
            // 
            // tlpChangePanel
            // 
            this.tlpChangePanel.ColumnCount = 1;
            this.tlpChangePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpChangePanel.Controls.Add(this.lblSuggestions, 0, 1);
            this.tlpChangePanel.Controls.Add(this.tbChangeTo, 0, 0);
            this.tlpChangePanel.Controls.Add(this.lbSuggestionList, 0, 2);
            this.tlpChangePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpChangePanel.Location = new System.Drawing.Point(0, 123);
            this.tlpChangePanel.Margin = new System.Windows.Forms.Padding(0);
            this.tlpChangePanel.Name = "tlpChangePanel";
            this.tlpChangePanel.RowCount = 3;
            this.tlpChangePanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpChangePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpChangePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpChangePanel.Size = new System.Drawing.Size(408, 153);
            this.tlpChangePanel.TabIndex = 0;
            // 
            // lblSuggestions
            // 
            this.lblSuggestions.AutoSize = true;
            this.lblSuggestions.Location = new System.Drawing.Point(3, 33);
            this.lblSuggestions.Margin = new System.Windows.Forms.Padding(3);
            this.lblSuggestions.Name = "lblSuggestions";
            this.lblSuggestions.Size = new System.Drawing.Size(69, 13);
            this.lblSuggestions.TabIndex = 3;
            this.lblSuggestions.Text = "Suggestions:";
            // 
            // tbChangeTo
            // 
            this.tbChangeTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbChangeTo.Location = new System.Drawing.Point(3, 3);
            this.tbChangeTo.Margin = new System.Windows.Forms.Padding(3, 3, 3, 6);
            this.tbChangeTo.Name = "tbChangeTo";
            this.tbChangeTo.Size = new System.Drawing.Size(402, 21);
            this.tbChangeTo.TabIndex = 0;
            // 
            // lbSuggestionList
            // 
            this.lbSuggestionList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbSuggestionList.FormattingEnabled = true;
            this.lbSuggestionList.Location = new System.Drawing.Point(3, 53);
            this.lbSuggestionList.Name = "lbSuggestionList";
            this.lbSuggestionList.Size = new System.Drawing.Size(402, 97);
            this.lbSuggestionList.TabIndex = 4;
            this.lbSuggestionList.SelectedIndexChanged += new System.EventHandler(this.lbSuggestionList_SelectedIndexChanged);
            this.lbSuggestionList.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lbSuggestionList_MouseDoubleClick);
            // 
            // rtbText
            // 
            this.rtbText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtbText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbText.Location = new System.Drawing.Point(3, 3);
            this.rtbText.Name = "rtbText";
            this.rtbText.Size = new System.Drawing.Size(402, 95);
            this.rtbText.TabIndex = 0;
            this.rtbText.TabStop = false;
            this.rtbText.Text = "";
            this.rtbText.Enter += new System.EventHandler(this.rtbText_Enter);
            // 
            // lblChangeTo
            // 
            this.lblChangeTo.AutoSize = true;
            this.lblChangeTo.Location = new System.Drawing.Point(3, 104);
            this.lblChangeTo.Margin = new System.Windows.Forms.Padding(3);
            this.lblChangeTo.Name = "lblChangeTo";
            this.lblChangeTo.Size = new System.Drawing.Size(61, 13);
            this.lblChangeTo.TabIndex = 2;
            this.lblChangeTo.Text = "Change to:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnIgnoreAll);
            this.panel2.Controls.Add(this.btnIgnore);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(408, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(133, 101);
            this.panel2.TabIndex = 4;
            // 
            // btnIgnoreAll
            // 
            this.btnIgnoreAll.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIgnoreAll.Location = new System.Drawing.Point(3, 32);
            this.btnIgnoreAll.Margin = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.btnIgnoreAll.Name = "btnIgnoreAll";
            this.btnIgnoreAll.Size = new System.Drawing.Size(127, 23);
            this.btnIgnoreAll.TabIndex = 1;
            this.btnIgnoreAll.Text = "Ignore All";
            this.btnIgnoreAll.UseVisualStyleBackColor = true;
            this.btnIgnoreAll.Click += new System.EventHandler(this.btnIgnoreAll_Click);
            // 
            // btnIgnore
            // 
            this.btnIgnore.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIgnore.Location = new System.Drawing.Point(3, 3);
            this.btnIgnore.Margin = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.btnIgnore.Name = "btnIgnore";
            this.btnIgnore.Size = new System.Drawing.Size(127, 23);
            this.btnIgnore.TabIndex = 0;
            this.btnIgnore.Text = "Ignore";
            this.btnIgnore.UseVisualStyleBackColor = true;
            this.btnIgnore.Click += new System.EventHandler(this.btnIgnore_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.pnlDeleteButtons);
            this.panel3.Controls.Add(this.pnlChangeButtons);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(408, 123);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(133, 153);
            this.panel3.TabIndex = 5;
            // 
            // pnlDeleteButtons
            // 
            this.pnlDeleteButtons.Controls.Add(this.btnDelete);
            this.pnlDeleteButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDeleteButtons.Location = new System.Drawing.Point(0, 0);
            this.pnlDeleteButtons.Margin = new System.Windows.Forms.Padding(0);
            this.pnlDeleteButtons.Name = "pnlDeleteButtons";
            this.pnlDeleteButtons.Size = new System.Drawing.Size(133, 153);
            this.pnlDeleteButtons.TabIndex = 7;
            this.pnlDeleteButtons.Visible = false;
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete.Location = new System.Drawing.Point(3, 3);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(127, 23);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // pnlChangeButtons
            // 
            this.pnlChangeButtons.Controls.Add(this.btnChangeAll);
            this.pnlChangeButtons.Controls.Add(this.btnChange);
            this.pnlChangeButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlChangeButtons.Location = new System.Drawing.Point(0, 0);
            this.pnlChangeButtons.Margin = new System.Windows.Forms.Padding(0);
            this.pnlChangeButtons.Name = "pnlChangeButtons";
            this.pnlChangeButtons.Size = new System.Drawing.Size(133, 153);
            this.pnlChangeButtons.TabIndex = 6;
            // 
            // btnChangeAll
            // 
            this.btnChangeAll.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnChangeAll.Location = new System.Drawing.Point(3, 32);
            this.btnChangeAll.Margin = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.btnChangeAll.Name = "btnChangeAll";
            this.btnChangeAll.Size = new System.Drawing.Size(127, 23);
            this.btnChangeAll.TabIndex = 3;
            this.btnChangeAll.Text = "Change All";
            this.btnChangeAll.UseVisualStyleBackColor = true;
            this.btnChangeAll.Click += new System.EventHandler(this.btnChangeAll_Click);
            // 
            // btnChange
            // 
            this.btnChange.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnChange.Location = new System.Drawing.Point(3, 3);
            this.btnChange.Margin = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(127, 23);
            this.btnChange.TabIndex = 2;
            this.btnChange.Text = "Change";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblStatus);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(541, 25);
            this.panel1.TabIndex = 2;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblStatus.Location = new System.Drawing.Point(3, 6);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(3);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(89, 13);
            this.lblStatus.TabIndex = 2;
            this.lblStatus.Text = "Not in dictionary:";
            // 
            // bottomPanel
            // 
            this.bottomPanel.Controls.Add(this.btnOK);
            this.bottomPanel.Controls.Add(this.btnCancel);
            this.bottomPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bottomPanel.Location = new System.Drawing.Point(0, 301);
            this.bottomPanel.Name = "bottomPanel";
            this.bottomPanel.Size = new System.Drawing.Size(541, 32);
            this.bottomPanel.TabIndex = 1;
            // 
            // btnOK
            // 
            this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOK.Enabled = false;
            this.btnOK.Location = new System.Drawing.Point(382, 3);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(463, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 0;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // listBox2
            // 
            this.listBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(3, 49);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(94, 4);
            this.listBox2.TabIndex = 4;
            // 
            // listBox1
            // 
            this.listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(3, 49);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(326, 82);
            this.listBox1.TabIndex = 4;
            // 
            // SpellCheckerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(541, 333);
            this.Controls.Add(this.mainPanel);
            this.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.MinimumSize = new System.Drawing.Size(320, 280);
            this.Name = "SpellCheckerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Spell Check";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SpellCheckerForm_FormClosed);
            this.Load += new System.EventHandler(this.SpellCheckerForm_Load);
            this.mainPanel.ResumeLayout(false);
            this.CenterPanel.ResumeLayout(false);
            this.tableLayoutPanel.ResumeLayout(false);
            this.tableLayoutPanel.PerformLayout();
            this.tlpChangePanel.ResumeLayout(false);
            this.tlpChangePanel.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.pnlDeleteButtons.ResumeLayout(false);
            this.pnlChangeButtons.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.bottomPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Panel bottomPanel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel CenterPanel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private System.Windows.Forms.TableLayoutPanel tlpChangePanel;
        private System.Windows.Forms.Label lblSuggestions;
        private System.Windows.Forms.TextBox tbChangeTo;
        private System.Windows.Forms.ListBox lbSuggestionList;
        private System.Windows.Forms.RichTextBox rtbText;
        private System.Windows.Forms.Label lblChangeTo;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnIgnoreAll;
        private System.Windows.Forms.Button btnIgnore;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel pnlDeleteButtons;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Panel pnlChangeButtons;
        private System.Windows.Forms.Button btnChangeAll;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblStatus;
    }
}

