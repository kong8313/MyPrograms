﻿using System;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.SearchableGrid;
using System.Reflection;

namespace Confirmit.CATI.Console.Views.Controls
{
    /// <summary>
    /// Grid control. 
    /// Header of grid contains additional editable row to enter search conditions.
    /// </summary>
    public partial class SearchableGrid : UserControl
    {
        #region Constructors

        public SearchableGrid()
        {
            InitializeComponent();
            InitGridHeader();            
        }        

        #endregion      

        #region Properties

        /// <summary>
        /// Gets header grid of control
        /// </summary>
        public DataGridView GridHeader
        {
            get
            {
                return this.gridHeader;
            }
        }

        /// <summary>
        /// Gets Interviews grid of control
        /// </summary>
        public DataGridView GridInterviews
        {
            get
            {
                return this.gridInterviews;                
            }
        }
      
        /// <summary>
        /// Gets the horizontal scroll bar associated with interviews grid
        /// </summary>
        private ScrollBar HScrollBarGridInterviews
        {
            get
            {
                PropertyInfo pi = gridHeader.GetType().GetProperty("HorizontalScrollBar", BindingFlags.Instance | BindingFlags.NonPublic);

                if (pi != null)
                {
                    return pi.GetValue(gridInterviews, null) as ScrollBar;
                }

                return null;
            }
        }

        private ScrollBar VScrollBarGridInterviews
        {
            get
            {
                PropertyInfo pi = gridInterviews.GetType().GetProperty("VerticalScrollBar", BindingFlags.Instance | BindingFlags.NonPublic);

                if (pi != null)
                {
                    return pi.GetValue(gridInterviews, null) as ScrollBar;
                }

                return null;
            }
        }

        #endregion

        #region Events

        /// <summary>
        /// Occurs when user stops edit searchable header by press enter key
        /// </summary>
        public event EventHandler StopEditOnEnter;

        /// <summary>
        /// Occurs when sortable column sort order has been changed.
        /// </summary>
        public event EventHandler<ColumnSortModeChangedEventArgs> ColumnSortModeChanged;

        #endregion

        #region Methods

        /// <summary>
        /// Adds column to the grid
        /// </summary>
        /// <param name="columnName">Column name</param>
        /// <param name="columnCaption">Column caption</param>
        /// <param name="columnType">Column type</param>
        public void AddColumn(string columnName, string columnCaption, Type columnType, int columnWidth)
        {
            if (gridHeader.Columns.Contains(columnName) == false)
            {
                var column = new DataGridViewSearchTextColumn()
                {
                    MinimumWidth = 20,
                    Width = columnWidth,
                    Name = columnName,
                    HeaderText = columnCaption,
                    ValueType = columnType
                };                               
                
                gridHeader.Columns.Add(column);

                SynchronizeColumns();
            }            
        } 

        #endregion

        #region Private methods

        private void InitGridHeader()
        {
            gridHeader.AllowUserToAddRows = false;
            
            RefreshSize();

            gridHeader.CellClick += new DataGridViewCellEventHandler(gridHeader_CellClick);
            gridHeader.ColumnWidthChanged += new DataGridViewColumnEventHandler(gridHeader_ColumnWidthChanged);
            gridHeader.CellEndEdit += new DataGridViewCellEventHandler(gridHeader_CellEndEdit);
            mainPanel.Resize += new EventHandler(mainPanel_Resize);
            gridInterviews.KeyDown+=new KeyEventHandler(gridInterviews_KeyDown);

            if (VScrollBarGridInterviews != null)
            {
                VScrollBarGridInterviews.VisibleChanged += new EventHandler(VScrollBarGridInterviews_VisibleChanged);
            }

            if (HScrollBarGridInterviews != null)
            {
                HScrollBarGridInterviews.VisibleChanged += new EventHandler(HScrollBarGridInterviews_VisibleChanged);
            }            
        }

        /// <summary>
        /// Method is responsible for correct grid appearance.        
        /// </summary>
        /// <remarks>
        /// To hide horizontal scroll of header grid bottom panel is intersected with upper panel.
        /// </remarks>
        private void RefreshSize()
        {
            pnlHeaderGrid.Height = gridHeader.ColumnHeadersHeight + gridHeader.RowTemplate.Height + 40;
            pnlBodyGrid.Top = mainPanel.Top + gridHeader.Height - 40;

            pnlHeaderGrid.Top = mainPanel.Top;
            pnlHeaderGrid.Left = mainPanel.Left;            

            pnlBodyGrid.Width = mainPanel.Width;

            pnlBodyGrid.Height = mainPanel.Height - pnlBodyGrid.Top;

            ValidateHeaderGridPanelWidth();
        }                      

        /// <summary>
        /// Synchronizes columns between header grid and interviews grid
        /// </summary>
        /// <remarks>
        /// If AutoSizeMode equals Fill it can lead that this method will be called on column resizing.
        /// It will lead to 
        /// InvalidOperationException: This operation cannot be performed while an auto-filled column is being resized.
        /// </remarks>
        private void SynchronizeColumns()
        {
            if (gridHeader.Rows.Count == 0)
            {
                this.gridHeader.Rows.Add();
            }

            foreach (DataGridViewColumn column in gridHeader.Columns)
            {
                if (gridInterviews.Columns.Contains(column.Name))
                {
                    var bodyColumn = gridInterviews.Columns[column.Name];

                    if (column.AutoSizeMode != DataGridViewAutoSizeColumnMode.Fill)
                    {
                        bodyColumn.Width = column.Width;                        
                    }

                    bodyColumn.MinimumWidth = column.MinimumWidth;
                    bodyColumn.AutoSizeMode = column.AutoSizeMode;
                }
                else
                {
                    var c = (DataGridViewColumn)column.Clone();

                    // restore default style for interviews list
                    c.CellTemplate.Style = c.DefaultCellStyle;
                    gridInterviews.Columns.Add(c);
                }
            }
        }

        /// <summary>
        /// Fires ColumnSortModeChanged event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnColumnSortModeChanged(ColumnSortModeChangedEventArgs e)
        {
            if (ColumnSortModeChanged != null)
            {
                ColumnSortModeChanged(this, e);
            }
        }

        #endregion

        #region Event Handlers

        /// <summary>
        /// Occurs when user clicks on cell
        /// </summary>
        /// <remarks>
        /// Begin edit process
        /// </remarks>
        void gridHeader_CellClick(object sender, DataGridViewCellEventArgs e)
        {       
            if (e.RowIndex == 0)
            {
                this.gridHeader.BeginEdit(false);
            }
        }

        /// <summary>
        /// Occurs when user changes width of column. 
        /// Grids must be synchronized.
        /// </summary>        
        void gridHeader_ColumnWidthChanged(object sender, DataGridViewColumnEventArgs e)
        {
            SynchronizeColumns();
            RefreshSize();
        }                                     

        /// <summary>
        /// Occurs when size of control is changed
        /// </summary>        
        private void mainPanel_Resize(object sender, EventArgs e)
        {            
            RefreshSize();
        }
        
        /// <summary>
        /// Occurs when user scrolls using grid of interviews grid.
        /// Synchronizes scrolls between grids. 
        /// </summary>
        private void dataGridBody_Scroll(object sender, ScrollEventArgs e)
        {
            this.gridHeader.HorizontalScrollingOffset = gridInterviews.HorizontalScrollingOffset;
        }        

        /// <summary>
        /// Occurs when user cancels to edit row
        /// </summary>        
        private void gridHeader_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (((DataGridViewSearchTextCell)GridHeader.Rows[e.RowIndex].Cells[e.ColumnIndex]).HasEnterPressed)
            {
                StopEditOnEnter(sender, EventArgs.Empty);
            }    
        }
           
        /// <summary>
        /// Occurs when user press any key.
        /// Prevent moving to next row when 'Enter' key has been pressed
        /// </summary>        
        private void gridInterviews_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Handles ColumnHeaderMouseClick event of header grid.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        private void gridHeader_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ColumnSortModeChangedEventArgs args = new ColumnSortModeChangedEventArgs(gridHeader.SortedColumn.Index);
                OnColumnSortModeChanged(args);
            }
        }

        void HScrollBarGridInterviews_VisibleChanged(object sender, EventArgs e)
        {
            if (HScrollBarGridInterviews != null &&
                HScrollBarGridInterviews.Visible)
            {
                HScrollBarGridInterviews.Enabled = true;
            }
        }

        void VScrollBarGridInterviews_VisibleChanged(object sender, EventArgs e)
        {
            if (VScrollBarGridInterviews != null &&
                VScrollBarGridInterviews.Visible)
            {                
                VScrollBarGridInterviews.Enabled = true;            
            }

            ValidateHeaderGridPanelWidth();
        }    
    
        private  void ValidateHeaderGridPanelWidth()
        {
            if (VScrollBarGridInterviews != null &&
                VScrollBarGridInterviews.Visible)
            {
                pnlHeaderGrid.Width = mainPanel.Width - VScrollBarGridInterviews.Width;                
            }
            else
            {
                pnlHeaderGrid.Width = mainPanel.Width;
            }
        }

        #endregion
    }
}
