﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using Confirmit.CATI.Console.Views.Controls;
using SHDocVw;
using mshtml;

namespace Confirmit.CATI.Console.Views.Classes.ExtendedWebBrowser
{ 
    /// <summary>
    /// This class will capture events from the WebBrowser
    /// </summary>
    class WebBrowserExtendedEvents : DWebBrowserEvents2
    {
        #region Members
        
        IConnectionPoint pConPt;
        
        #endregion

        #region Constructors

        public WebBrowserExtendedEvents()
        { 
        }

        #endregion

        #region Events

        public event EventHandler<CustomBeforeNavigateEventArgs> CustomBeforeNavigateEvent;

        /// <summary>
        /// Event is fired when error occurs during navigation.
        /// </summary>
        public event EventHandler<NavigateErrorEventArgs> NavigateErrorEvent;
               
        #endregion

        #region Event handlers

        public void DocumentComplete(object pDisp, ref object URL)
        {
            if (pDisp == null)
                throw new ArgumentNullException(String.Empty, String.Empty);

            IHTMLDocument2 doc = (IHTMLDocument2)(((SHDocVw.IWebBrowser2)pDisp).Document);
            if (doc == null)
                return;

            int dwCookie2 = -1;
            if (dwCookie2 == -1 || doc.forms.item("ctlform", 0) != null)
            {
                IConnectionPointContainer pConPtCon = (IConnectionPointContainer)doc;
                Guid guid = typeof(mshtml.HTMLDocumentEvents2).GUID;
                pConPtCon.FindConnectionPoint(ref guid, out pConPt);

                if (dwCookie2 != -1)
                {                    
                    //It is needed to prevent multiple subscription for IEHtmlDocumentEvents.
                    //For some reason this Unadvise leads that 'F5' works incorrectly when page has focus (internal browser 'F5' refresh is invoked.). 
                    //Revert changes done in CR 53333.
                    //pConPt.Unadvise(dwCookie2);
                }

                IEHtmlDocumentEvents d = new IEHtmlDocumentEvents();
                pConPt.Advise(d, out dwCookie2);                
            }
        }

        //Occures before browser navigate to new page
        public void BeforeNavigate2(object pDisp, ref object URL, ref object flags, ref object targetFrameName, ref object postData, ref object headers, ref bool cancel)
        {
            var isFrame = false;
            var browser = pDisp as IWebBrowser2;
            if (browser != null)
            {
                isFrame = browser.Parent != null;
            }

            OnCustomBeforeNavigateEvent(                        
                new CustomBeforeNavigateEventArgs()
                {
                    NavigateData = new NavigationData(URL, targetFrameName, postData, headers, isFrame) 
                });
        }

        public void NavigateError(object pDisp, ref object URL, ref object frame, ref object statusCode, ref bool cancel)
        {
            NavigateErrorEventArgs e = new NavigateErrorEventArgs(
                URL != null ? (string)URL : String.Empty,
                frame != null ? (string)frame : String.Empty,
                statusCode != null ? (int)statusCode : 0
            );

            OnNavigateError(e);
            cancel = e.Cancel;
        }

        #endregion

        #region Methods

        private void OnCustomBeforeNavigateEvent(CustomBeforeNavigateEventArgs eventArgs)
        {
            if (CustomBeforeNavigateEvent != null)
            {
                CustomBeforeNavigateEvent(this, eventArgs);
            }
        }

        /// <summary>
        /// Fires NavigateError event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnNavigateError(NavigateErrorEventArgs e)
        {
            if (NavigateErrorEvent != null)
            {
                NavigateErrorEvent(this, e);
            }
        }

        #endregion

        #region Unused events
        
        //The NewWindow2 event, used on Windows XP SP1 and below
        public void NewWindow2(ref object pDisp, ref bool cancel)
        {

        }

        // NewWindow3 event, used on Windows XP SP2 and higher
        public void NewWindow3(ref object ppDisp, ref bool Cancel, uint dwFlags, string bstrUrlContext, string bstrUrl)
        {

        }

        // Fired when downloading begins
        public void DownloadBegin()
        {

        }

        // Fired when downloading is completed
        public void DownloadComplete()
        {

        }

        // This event doesn't fire. 
        [DispId(0x00000107)]
        public void WindowClosing(bool isChildWindow, ref bool cancel)
        {
        }

        public void OnQuit()
        {

        }

        public void StatusTextChange(string text)
        {
        }

        public void ProgressChange(int progress, int progressMax)
        {
        }

        public void TitleChange(string text)
        {
        }

        public void PropertyChange(string szProperty)
        {
        }

        public void NavigateComplete2(object pDisp, ref object URL)
        {
        }

        public void OnVisible(bool visible)
        {
        }

        public void OnToolBar(bool toolBar)
        {
        }

        public void OnMenuBar(bool menuBar)
        {
        }

        public void OnStatusBar(bool statusBar)
        {
        }

        public void OnFullScreen(bool fullScreen)
        {
        }

        public void OnTheaterMode(bool theaterMode)
        {
        }

        public void WindowSetResizable(bool resizable)
        {
        }

        public void WindowSetLeft(int left)
        {
        }

        public void WindowSetTop(int top)
        {
        }

        public void WindowSetWidth(int width)
        {
        }

        public void WindowSetHeight(int height)
        {
        }

        public void SetSecureLockIcon(int secureLockIcon)
        {
        }

        public void FileDownload(ref bool cancel)
        {
        }

        public void PrintTemplateInstantiation(object pDisp)
        {
        }

        public void PrintTemplateTeardown(object pDisp)
        {
        }

        public void UpdatePageStatus(object pDisp, ref object nPage, ref object fDone)
        {
        }

        public void PrivacyImpactedStateChange(bool bImpacted)
        {
        }

        public void CommandStateChange(int Command, bool Enable)
        {
        }

        public void ClientToHostWindow(ref int CX, ref int CY)
        {
        }
        #endregion
    }    
}
