﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
	/// <summary>
	/// Respesents enumeration of controls which could be validated on appointment form.
	/// </summary>
	public enum AppointmentValidationControls
	{
		/// <summary>
		/// Appointment date control.
		/// </summary>
		AppointmentDate = 2,

		/// <summary>
		/// Appointment time control.
		/// </summary>
		AppointmentTime = 3,

		/// <summary>
		/// Expiration date control.
		/// </summary>
		ExpirationDate = 4,

		/// <summary>
		/// Expiration time control.
		/// </summary>
		ExpirationTime = 5
	}


	/// <summary>
	/// Describes reason why user closes appointment form.
	/// </summary>
	public enum FormCloseReasons
	{
		/// <summary>
		/// Appointment dialog is still running.
		/// </summary>
		None = 0,

		/// <summary>
		/// Save appointment changes and close form.
		/// </summary>
		Ok = 1,

		/// <summary>
		/// Cancel appointment changes and close form.
		/// </summary>
		Cancel = 2,
	}

	/// <summary>
	/// Represents view entity for AppiontmentForm form.
	/// </summary>
    public interface IViewAppointmentForm : ILocalizableView, IPlayableView, IDisposable
	{
		/// <summary>
		/// Occurs when button Ok is clicked.
		/// </summary>
		event EventHandler<EventArgs> OkClick;

		/// <summary>
		/// Occurs when contact name is going to be validated.
		/// </summary>
		event EventHandler<CancelEventArgs> ValidatingContactName;

		/// <summary>
		/// Occurs when appointment date is going to be validated.
		/// </summary>
		event EventHandler<CancelEventArgs> ValidatingAppointmentDate;

		/// <summary>
		/// Occurs when appointment time is going to be validated.
		/// </summary>
		event EventHandler<CancelEventArgs> ValidatingAppointmentTime;

		/// <summary>
		/// Occurs when expiration date is going to be validated.
		/// </summary>
		event EventHandler<CancelEventArgs> ValidatingExpirationDate;

		/// <summary>
		/// Occurs when expiration time is going to be validated.
		/// </summary>
		event EventHandler<CancelEventArgs> ValidatingExpirationTime;

		/// <summary>
		/// Occurs when form is going to be validated. This event is fired only
		/// if children controls validation is successfull.
		/// </summary>
		event EventHandler<CancelEventArgs> ValidatingForm;

		/// <summary>
		/// Occurs when "Never expire" option is changed.
		/// </summary>
		event EventHandler<EventArgs> NeverExpireChanged;

		/// <summary>
		/// Occurs when form is closed.
		/// </summary>
		event EventHandler<EventArgs> FormClose;

        /// <summary>
        /// Occurs before the form is closed.
        /// </summary>
	    event FormClosingEventHandler FormClosing;

		/// <summary>
		/// Occurs when appointment date is changed.
		/// </summary>
		event EventHandler<EventArgs> AppointmentDateChanged;

		/// <summary>
		/// Occurs when appointment time is changed.
		/// </summary>
		event EventHandler<EventArgs> AppointmentTimeChanged;

		/// <summary>
		/// Occurs when appointment date is changed.
		/// </summary>
		event EventHandler<EventArgs> ExpirationDateChanged;

		/// <summary>
		/// Occurs when appointment time is changed.
		/// </summary>
		event EventHandler<EventArgs> ExpirationTimeChanged;

		/// <summary>
		/// Occurs when "Log out" flag is changed.
		/// </summary>
		event EventHandler<EventArgs> LogoutChanged;

        /// <summary>
        /// Occurs when user click Show Interviewer Appointmens button.
        /// </summary>
        event EventHandler<EventArgs> ShowInterviewerAppointmens;
        
        /// <summary>
        /// Occurs when "Allow appointments outside of permitted shift" flag is changed.
        /// </summary>
        event EventHandler<EventArgs> AllowAppointmentsOutsideShiftChanged;

		/// <summary>
		/// Appointment date.
		/// </summary>
		DateTime AppointmentDate
		{
			get;
			set;
		}

		/// <summary>
		/// Appointment time.
		/// </summary>
		string AppointmentTime
		{
			get;
			set;
		}

		/// <summary>
		/// Expiration date.
		/// </summary>
		DateTime ExpirationDate
		{
			get;
			set;
		}

		/// <summary>
		/// Expiration time.
		/// </summary>
		string ExpirationTime
		{
			get;
			set;
		}

		/// <summary>
		/// Flag indicates that appointment should or shouldn't expire.
		/// </summary>
		bool NeverExpire
		{
			get;
			set;
		}

        /// <summary>
        /// Gets or sets a value indicating whether we should check if appointment
        /// belongs to some existing shift or not.
        /// </summary>
        bool AllowAppointmentsOutsideShifts { get; set; }

		/// <summary>
		/// Flag indicates that we should log out after appointment creation.
		/// </summary>
		bool Logout
		{
			get;
			set;
		}

		/// <summary>
		/// Respondent time.
		/// </summary>
		string RespondentTime
		{
			get;
			set;
		}

		/// <summary>
		/// Interviewer time.
		/// </summary>
		string InterviewerTime
		{
			get;
			set;
		}

		/// <summary>
		/// Flag indicates that we should suppress event generation.  By default it is false.
		/// </summary>
		bool SuppressEvents
		{
			get;
			set;
		}

	    /// <summary>
        /// Gets/sets dialog description.
        /// </summary>
        string DialogDescription
        {
            get;
            set;
        }     

		/// <summary>
		/// Gets/sets form result describing why user close form.
		/// </summary>
		FormCloseReasons FormResult
		{
			get;
			set;
		}

	    bool IsVisible { get; }

	    bool ControlBox { get; set; }

        bool ShowAppointmentsOutsidePermittedShiftTime { get; set; }

        bool ShowLinkToInterviewerAppointments { get; set; }

        /// <summary>
        /// Shows modal appointment form.
        /// </summary>
        /// <param name="parent">Parent window handle.</param>
        void Show(IWin32Window parent);

        /// <summary>
        /// Shows non-modal appointment form.
        /// </summary>
        /// <param name="parent">Parent window handle.</param>
        void ShowNonModal(IWin32Window parent);

		/// <summary>
		/// Notifies user about validation error of specified control.
		/// </summary>
		/// <param name="control">Validated control.</param>
		/// <param name="message">Error message.</param>
		/// <remarks>If the message length is greater than zero, then the error icon is displayed, 
		/// and the ToolTip for the error icon is the error description text. 
		/// If the message length is zero, the error icon is hidden.
		/// </remarks>
		void AlertValidationError(AppointmentValidationControls control, string message);

		/// <summary>
		/// Enables/disables expiration date and time controls.
		/// </summary>
		/// <param name="enable">Flag indicates enable controls or disable.</param>
		void EnableExpirationTimeControls(bool enable);

		/// <summary>
		/// Binds appointment time control with the list of predefined values.
		/// </summary>
		/// <param name="items">Predefined items.</param>
		void BindAppointmentTimeList(string[] items);

		/// <summary>
		/// Binds expiration time control with the list of predefined values.
		/// </summary>
		/// <param name="items">Predefined items.</param>
		void BindExpirationTimeList(string[] items);

        /// <summary>
        /// Enables/disables all input controls on form.
        /// </summary>
        /// <param name="enable">if true, enables controls; otherwise disables.</param>
        void EnableInputControls(bool enable);

		/// <summary>
		/// Closes form.
		/// </summary>
		void CloseForm(DialogResult dialogResult);

        /// <summary>
        /// Hides form.
        /// </summary>
        void HideForm();

        void HideCancelButton();
	}
}
