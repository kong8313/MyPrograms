﻿
namespace Confirmit.CATI.Console.Views.Classes.SpellChecking
{
    /// <summary>
    /// Represents question text block on the page.
    /// </summary>
    public class QuestionTextBlock
    {
        /// <summary>
        /// Textblock constructor.
        /// </summary>
        /// <param name="id">Textblock identifier.</param>
        /// <param name="value">Text value.</param>
        public QuestionTextBlock(string id, string value)
        {
            Id = id;
            Value = value;
        }        

        /// <summary>
        /// Gets/sets textblock identifier.
        /// </summary>
        public string Id
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets/sets text value.
        /// </summary>
        public string Value
        {
            get;
            set;
        }
    }
}
