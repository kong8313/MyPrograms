using System;

namespace Confirmit.CATI.Console.Views.Controls
{
    /// <summary>
    /// For IE10/IE11 innerHmtl/outerHtml properties doesn't reflect changes in 'system' properties of elements such as 
    /// value, checked, selected attributes
    /// It's true for input and select elements
    /// This class provides script that traverses 'system' values into attributes. 
    /// This cannot be done via .NET code because setAttribute doesn't work for 'system' attributes (in emulation mode only).
    /// </summary>
    public class HtmlMonitoringAdapter
    {
        public static string GetRegisterFunctionsScript()
        {
            const string functions = @"
                function Monitor_UpdateInput(el) {
                    if (el.type == 'checkbox' || el.type == 'radio') {
                        if (el.checked) {
                            el.setAttribute('checked', 'checked');
                        } else {
                            el.removeAttribute('checked');
                        }
                    } else if (el.type.toLowerCase() == 'text') {
                        el.setAttribute('value', el.value);
                    }
                };

                function Monitor_UpdateSelect(el) {
                    for (j = 0; j < el.options.length; j++) {
                        if (j == el.selectedIndex) {
                            el.options[j].setAttribute('selected', 'selected');
                        } else {
                            el.options[j].removeAttribute('selected');
                        }
                    }
                };

                function MonitorUpdateHtml(elementId) {
                    var container = document;

                    if (elementId) {
                        container = document.getElementById(elementId);
                    }

                    if (container.tagName && container.tagName.toLowerCase() == 'input') {
                        Monitor_UpdateInput(container);
                    } else if (container.tagName && container.tagName.toLowerCase() == 'select') {
                        Monitor_UpdateSelect(container);
                    } else {
                        /* if container is used */
                        var inputElements = container.getElementsByTagName('input');
                        for (i = 0; i < inputElements.length; i++) {
                            Monitor_UpdateInput(inputElements[i]);
                        }

                        var selectElements = container.getElementsByTagName('select');

                        for (i = 0; i < selectElements.length; i++) {
                            Monitor_UpdateSelect(selectElements[i]);
                        }
                    }
                };";
  
            return functions;
        }

        public static string GetUpdateHtmlScript(string elementId)
        {
            return String.Format("if(typeof MonitorUpdateHtml === 'function') MonitorUpdateHtml('{0}');", elementId);
        }
    }
}
