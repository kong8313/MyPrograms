﻿using System;
using System.Windows.Forms;
using mshtml;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    /// <summary>
    /// Class represents certain question answer 
    /// </summary>
    public class Answer
    {
        private IHTMLElement m_Element = null;
        private IHTMLElement m_OtherElement = null;

        public Answer(IHTMLElement element)
        {
            m_Element = element;
        }

        public Answer(IHTMLElement element, IHTMLElement otherElement)
            : this(element)
        {
            m_OtherElement = otherElement;        
        }

        /// <summary>
        /// Return true if current answer is single punch answer
        /// </summary>
        public bool IsSinglePunch
        {
            get
            {
                bool isSinglePunch = false;
                object obj = m_Element.getAttribute("isSinglePunch", 0);
                if (obj != null)
                {
                    bool.TryParse(obj.ToString(), out isSinglePunch);
                }                
                return isSinglePunch;
            }
        }

        /// <summary>
        /// Returns true if current answer is disabled
        /// </summary>
        public bool IsDisabled
        {
            get
            {
                var disabled = m_Element.getAttribute("disabled", 0);
                if (disabled.ToString().Equals("disabled", StringComparison.InvariantCultureIgnoreCase))
                {
                    return true;
                }

                bool isDisabled;
                if (bool.TryParse(disabled.ToString(), out isDisabled))
                {
                    return isDisabled;
                }

                return false;
            }
        }

        /// <summary>
        /// Returns true if current answer is invisible otherwise false
        /// </summary>
        public bool IsInvisible
        {
            get
            {
                if (m_Element.style.display != null)
                {
                    return m_Element.style.display.Equals("none", StringComparison.OrdinalIgnoreCase);
                }

                return false;
            }
        }

        /// <summary>
        /// Returns true if passed element is other element
        /// </summary>
        /// <remarks>
        /// If question is Grid or 3DGrid then other answer(other element) will be present is answer collection
        /// because this other element is common for all elements in grid line.
        /// </remarks>
        /// <returns></returns>
        public bool IsOther
        {
            get
            {
                if (m_Element != null &&
                    (m_Element is IHTMLInputElement || m_Element is IHTMLTextAreaElement))
                {
                    if (m_Element.id.EndsWith("_other", StringComparison.InvariantCultureIgnoreCase))
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        /// <summary>
        /// Return true if other textbox is disabled otherwise false
        /// </summary>
        public bool IsOtherDisabled
        {
            get 
            {
                if (HasOther)
                {
                    return ((bool)((IHTMLElement)m_OtherElement).getAttribute("disabled", 0));
                }

                return false;
            }        
        }

        /// <summary>
        /// Returns true if current answer has other option
        /// </summary>
        public bool HasOther
        {
            get
            {
                return m_OtherElement != null;
            }
        }

        public bool IsOtherFocused
        {
            get
            {
                if (HasOther)
                {
                    string activeElemntId = ((IHTMLDocument2)(m_Element.document)).activeElement.id;

                    return activeElemntId == OtherElementId;
                }

                return false;
            }
        }

        /// <summary>
        /// Gets element tag for current answer
        /// </summary>
        public TagNames TagName
        {
            get
            {
                return Answer.GetTagNameByElement(m_Element);                
            }
        }

        /// <summary>
        /// Gets element type for current answer
        /// </summary>
        public ElementTypes ElementType 
        {
            get
            {
                return Answer.GetTypeByElement(m_Element);               
            }
        }

        /// <summary>
        /// Gets element id of undelying html element
        /// </summary>
        public string ElementId
        {
            get
            {
                return m_Element.id;
            }
        }

        /// <summary>
        /// Gets element id of undelying html element of other element
        /// </summary>
        public string OtherElementId
        {
            get
            {
                if (m_OtherElement != null)
                {
                    return ((IHTMLElement)m_OtherElement).id; 
                }
                return String.Empty;               
            }
        }

        /// <summary>
        /// Gets precode for current answer 
        /// </summary>
        /// <remarks>
        /// Gets precode from undelying html element id
        /// </remarks>
        public string PreCode
        {
            get
            { 
                int index = m_Element.id.LastIndexOf("_") + 1;
                if (index > 0 && index < m_Element.id.Length)
                {
                    return m_Element.id.Substring(index);
                }
                return String.Empty;
            }
        }

        /// <summary>
        /// Gets/sets value for current answer
        /// </summary>
        public string Value
        {
            get
            {
                if (TagName == TagNames.TEXTAREA)
                {
                    return ((IHTMLTextAreaElement)(m_Element)).value;
                }
                else if (TagName == TagNames.INPUT)
                {
                    return ((IHTMLInputElement)m_Element).value;
                }
                else if (TagName == TagNames.SELECT)
                {
                    return ((IHTMLSelectElement)m_Element).value;
                }
                return String.Empty;
            }
            set
            {
                if (TagName == TagNames.TEXTAREA)
                {
                    ((IHTMLTextAreaElement)(m_Element)).value = value;
                }
                else if (TagName == TagNames.INPUT)
                {
                    ((IHTMLInputElement)m_Element).value = value;
                }
                else if (TagName == TagNames.SELECT)
                {
                    ((IHTMLSelectElement)m_Element).value = value;
                }
            }
        }

        /// <summary>
        /// Gets/sets selected property for current answer
        /// </summary>        
        public bool Checked
        {
            get
            {
                if (ElementType == ElementTypes.Checkbox ||
                   ElementType == ElementTypes.Radio)
                {
                    return ((IHTMLInputElement)(m_Element)).@checked;
                }
                return false;
            }
            set
            {
                if (ElementType == ElementTypes.Checkbox ||
                   ElementType == ElementTypes.Radio)
                {
                     ((IHTMLInputElement)(m_Element)).@checked = value;
                    
                }               
            }
        }

        /// <summary>
        /// Gets/sets selected index property for current answer
        /// </summary>                
        public int SelectedIndex
        {
            get
            {
                if (TagName == TagNames.SELECT)
                {
                    return ((IHTMLSelectElement)m_Element).selectedIndex;
                }
                return int.MaxValue;
            }
            set
            {
                if (TagName == TagNames.SELECT)
                {
                    if (value > 0 && value < ((IHTMLSelectElement)m_Element).length)
                    {
                        ((IHTMLSelectElement)m_Element).selectedIndex = value;
                    }                    
                }                
            }
        }
        
        private string OtherElementValue 
        {
            get
            {
                if (m_OtherElement is IHTMLInputElement)
                    return ((IHTMLInputElement)m_OtherElement).value;

                if (m_OtherElement is IHTMLTextAreaElement)
                    return ((IHTMLTextAreaElement)m_OtherElement).value;

                return String.Empty;
            }
            set
            {
                if (m_OtherElement is IHTMLInputElement)
                    ((IHTMLInputElement)m_OtherElement).value = value;
                else if (m_OtherElement is IHTMLTextAreaElement)
                    ((IHTMLTextAreaElement)m_OtherElement).value = value;
                else                
                    throw new NotSupportedException("Not supported other element type: " + m_OtherElement.tagName);               
            }
        }

        /// <summary>
        /// Restore old text value for other textbox if current answer has other option
        /// </summary>
        public void SetOtherValue()
        {
            if (ElementType == ElementTypes.Checkbox ||
                ElementType == ElementTypes.Radio)
            {
                if (HasOther)
                {
                    string oldValue = m_OtherElement.getAttribute("__oldValue", 0) as string;

                    if (Checked)
                    {
                        if (String.IsNullOrEmpty(oldValue) == false)
                        {

                            OtherElementValue = oldValue;
                        }
                    }
                    else
                    {
                        if (String.IsNullOrEmpty(OtherElementValue) == false)
                        {
                            m_OtherElement.setAttribute("__oldValue",OtherElementValue, 0);
                        }
                        OtherElementValue = String.Empty;
                    }
                }
            }
        }

        /// <summary>
        /// Set text value for other textbox if current answer has other option
        /// </summary>
        public void SetOtherValue(string value)
        {
            if (ElementType == ElementTypes.Checkbox ||
                ElementType == ElementTypes.Radio)
            {
                if (HasOther)
                {
                    string oldValue = m_OtherElement.getAttribute("__oldValue", 0) as string;

                    if (Checked)
                    {
                        if (String.IsNullOrEmpty(value) == false)
                        {
                            OtherElementValue = oldValue;
                        }
                    }                  
                }
            }
        }      

        /// <summary>
        /// Fires keydown event for input element
        /// </summary>
        /// <remarks>
        ///  KeyCode for that event equals 0. 
        /// </remarks>
        public void FireKeyDownEvent()
        {
            if (TagName == TagNames.INPUT)
            {
                 var dummy = new object();
                ((HTMLInputElement)m_Element).FireEvent("onkeydown", ref dummy);                
           }
        }

        public void FireKeyUpEvent()
        {
            if (TagName == TagNames.INPUT)
            {
                var dummy = new object();
                ((HTMLInputElement)m_Element).FireEvent("onkeyup", ref dummy);
            }
        }

        public void FireClickEvent()
        {
            if (TagName == TagNames.INPUT)
            {
                var dummy = new object();
                ((HTMLInputElement)m_Element).FireEvent("onclick", ref dummy);
            }
        }
        /// <summary>
        /// Set focus in textarea for current answer 
        /// If unswer is not "text" answer do nothing
        /// </summary>
        public void Focus()
        {            
            if (TagName == TagNames.TEXTAREA)
            {
                if (IsDisabled == false && IsInvisible == false)
                {
                    var element = ((IHTMLTextAreaElement)m_Element);
                    ((IHTMLElement2)element).focus();
                }
            }
            else if (TagName == TagNames.INPUT)
            {
                if (ElementType == ElementTypes.TextInput)
                {
                    if (IsDisabled == false && IsInvisible == false)
                    {
                        ((IHTMLElement2)m_Element).focus();
                    }
                }
                else if (ElementType == ElementTypes.Checkbox ||
                        ElementType == ElementTypes.Radio)
                {
                    if (HasOther && (IsOtherDisabled == false))
                    {
                        FocusOtherElement();
                    }
                }
            }
            else if (TagName == TagNames.SELECT)
            {
                ((IHTMLElement2)m_Element).focus();
            }
        }

        public void FocusOtherElement()
        {
            ((IHTMLElement2) m_OtherElement).focus();
        }

        public static TagNames GetTagNameByElement(IHTMLElement element)
        {
            if (element != null)
            {
                string tagName = element.tagName;

                if (tagName.Equals("INPUT", StringComparison.InvariantCultureIgnoreCase))
                {
                    return TagNames.INPUT;
                }
                else if (tagName.Equals("TEXTAREA", StringComparison.InvariantCultureIgnoreCase))
                {
                    return TagNames.TEXTAREA;
                }
                else if (tagName.Equals("SELECT", StringComparison.InvariantCultureIgnoreCase))
                {
                    return TagNames.SELECT;
                }
                else if (tagName.Equals("LABEL", StringComparison.InvariantCultureIgnoreCase))
                {
                    return TagNames.LABEL;
                }
                else if (tagName.Equals("DIV", StringComparison.InvariantCultureIgnoreCase))
                {
                    return TagNames.DIV;
                } 
            }

            return TagNames.UNDEFINED;
        }

        public static ElementTypes GetTypeByElement(IHTMLElement element)
        {            
            var tagName = GetTagNameByElement(element);            

            if (tagName == TagNames.INPUT)
            {
                string type = ((IHTMLInputElement)(element)).type;

                if (type.Equals("checkbox", StringComparison.InvariantCultureIgnoreCase))
                {
                    return ElementTypes.Checkbox;
                }
                else if (type.Equals("radio", StringComparison.InvariantCultureIgnoreCase))
                {
                    return ElementTypes.Radio;
                }
                else if (type.Equals("text", StringComparison.InvariantCultureIgnoreCase))
                {
                    return ElementTypes.TextInput;
                }
                else if (type.Equals("password", StringComparison.InvariantCultureIgnoreCase))
                {
                    return ElementTypes.TextInput;
                } 
            }
            else if (tagName == TagNames.TEXTAREA)
            {
                return ElementTypes.TextArea;
            }
            else if (tagName == TagNames.SELECT)
            {
                return ElementTypes.Select;
            }

            return ElementTypes.Undefined;           
        }

        public void SetOtherElement(IHTMLElement otherEl)
        {
            m_OtherElement = otherEl;
        }
    }
}
