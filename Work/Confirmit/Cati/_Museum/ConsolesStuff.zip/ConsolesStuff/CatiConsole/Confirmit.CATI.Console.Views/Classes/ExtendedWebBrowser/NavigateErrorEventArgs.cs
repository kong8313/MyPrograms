﻿using System;
using System.ComponentModel;

namespace Confirmit.CATI.Console.Views.Classes.ExtendedWebBrowser
{
    /// <summary>
    /// Represents NavigateError event arguments.
    /// </summary>
    public class NavigateErrorEventArgs : CancelEventArgs
    {
        #region Constructors

        /// <summary>
        /// Initializes new instance of CustomNavigateErrorEventArgs class and 
        /// fills it with given data.
        /// </summary>
        /// <param name="url">Url for which navigation failed.</param>
        /// <param name="frameName">The name of the frame in which the resource is to be displayed. Value can be null.</param>
        /// <param name="statusCode">Error status code.</param>
        public NavigateErrorEventArgs(string url, string frameName, int statusCode)
        {
            Url = url;
            FrameName = frameName ?? String.Empty;
            Status = (NavigateErrorStatus)statusCode;
            Cancel = false;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets Url for which navigation failed.
        /// </summary>
        public string Url
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets name of the frame in which the resource is to be displayed.
        /// Contains null if no named frame is targeted for the resource.
        /// </summary>
        public string FrameName
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets status code corresponding to the error, if available.
        /// Othewise contains NavigateErrorStatus.None.
        /// </summary>
        public NavigateErrorStatus Status
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets or set page load time until error occured.
        /// </summary>
        public TimeSpan PageLoadTime
        {
            get;
            set;
        }

        #endregion
    }
}
