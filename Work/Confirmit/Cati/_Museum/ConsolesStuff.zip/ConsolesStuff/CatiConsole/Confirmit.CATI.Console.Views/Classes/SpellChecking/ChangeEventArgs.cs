﻿using System;

namespace Confirmit.CATI.Console.Views.Classes.SpellChecking
{
    public class ChangeEventArgs : EventArgs
    {
        public string SuggestedWord
        {
            get; 
            set;
        }
    }
}