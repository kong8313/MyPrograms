﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Web;

using Confirmit.CATI.Common.Encoding;

namespace Confirmit.CATI.Console.Views.Controls
{
    /// <summary>
    /// Used for display message list
    /// </summary>
    public partial class MessageList : UserControl
    {
        #region Members

        private const string m_FontStyle = "font-size:11px; font-family:Tahoma;"; 

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor of MessageList
        /// </summary>
        public MessageList()
        {
            InitializeComponent();
            webBrowser.DocumentText = String.Empty;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Adds text into message list
        /// </summary>
        public void AddText(string text)
        {
            if (webBrowser.Document == null || webBrowser.Document.Body == null)
            {
                webBrowser.DocumentText = text;
            }
            else
            {
                webBrowser.Document.Body.InnerText = text;
            }
        }

        /// <summary>
        /// Clears message list
        /// </summary>
        public void Clear()
        {            
            if (webBrowser.Document != null &&
               webBrowser.Document.Body != null)
            {
                HtmlDocument doc = webBrowser.Document;
                doc.Body.InnerText = String.Empty;
            }         
        }
        
        /// <summary>
        /// Adds new records into list
        /// </summary>
        /// <param name="author">Message author(supervisor name) </param>
        /// <param name="time">Message sent time</param>
        /// <param name="body">Message body</param>
        public void AddMessage(string author, string time, string body)
        {
            if (webBrowser.Document == null ||
                webBrowser.Document.Body == null)
            {
                return;
            }            

            author = HttpUtilitySafe.HtmlEncode(author);
            time = HttpUtilitySafe.HtmlEncode(time);
            body = HttpUtilitySafe.HtmlEncode(body);

            StringBuilder builder = new StringBuilder();

            string style = "filter: progid:DXImageTransform.Microsoft.gradient(gradienttype=0, startColorstr=#E5EEFF, endColorstr=#ffffff);";
            style += m_FontStyle;

            builder.Append("<table width='99%' style='" + style + "'>");
            builder.Append("<tr><td>");
            builder.Append(string.Format("<b>From:</u></b> {0}", author));
            builder.Append("<br>");
            builder.Append(string.Format("<b>Sent:</u></b> {0}", time));
            builder.Append("</td></tr>");
            builder.Append("</table>");
            builder.Append("<br>");
            builder.Append(body);
            builder.Append("<hr color='#B5C4DF' size='1' width='100%'>");

            HtmlDocument doc = webBrowser.Document;
            HtmlElement divEl = doc.CreateElement("DIV");
            divEl.InnerHtml = builder.ToString();
            doc.Body.AppendChild(divEl);

            divEl.ScrollIntoView(true);
        }

        #endregion                

        #region Event handlers

        private void webBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            webBrowser.Document.Body.Style = m_FontStyle;
        }

        #endregion
           
    }
}
