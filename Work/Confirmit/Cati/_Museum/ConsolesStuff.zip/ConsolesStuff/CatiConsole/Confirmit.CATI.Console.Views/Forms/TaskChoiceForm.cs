﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using System.Collections;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
    /// <summary>
    /// If interviewer has "Choice" task choice 
    /// form asks interviewer to specify task choice    
    /// </summary>
    public partial class TaskChoiceForm : Form, IViewSelectTaskChoiceForm
    {
        #region Constructors

        public TaskChoiceForm()
        {
            InitializeComponent();
            Icon = Properties.Resources.AppIcon;
        } 

        #endregion

        #region IViewSelectTaskChoiceForm Members

        /// <summary>
        /// Occurs when user click OK button
        /// </summary>
        public event EventHandler<EventArgs> OkClick;

        /// <summary>
        /// Occurs when user click Cancel button
        /// </summary>
        public event EventHandler<CancelEventArgs> CancelClicking;

        /// <summary>
        /// Gets the index of selected filter field.
        /// </summary>
        public int SelectedTaskChoice
        {
            get
            {
                return (int)((DictionaryEntry)cbTaskChoices.SelectedItem).Value;
            }
        }

        /// <summary>
        /// Binds task choices into DropDown list.
        /// </summary>        
        public void BindTaskChoiceList(Dictionary<string, int> values)
        {
            if (values == null || values.Count == 0)
            {
                throw new ArgumentNullException("values");
            }

            cbTaskChoices.DisplayMember = "Key";

            foreach (string key in values.Keys)
            {
                cbTaskChoices.Items.Add(new DictionaryEntry(key, values[key]));
            }

            cbTaskChoices.SelectedIndex = 0;
        }

        DialogResult IViewSelectTaskChoiceForm.Show(IWin32Window parent)
        {
            return ShowDialog(parent);
        }

        #endregion

        #region ILocalizableView Members

        public void Localize(ILocalizationManager manager)
        {
            Text = manager.GetString("TaskChoiceForm_Caption");
            lblTitle.Text = manager.GetString("TaskChoiceForm_Title");
            lblTitleDescription.Text = manager.GetString("TaskChoiceForm_TitleDescription");
            btnOk.Text = manager.GetString("TaskChoiceForm_ButtonOk_Text");
            btnCancel.Text = manager.GetString("TaskChoiceForm_ButtonCancel_Text");            
        }

        #endregion

        #region Methods
        
        private void btnOk_Click(object sender, EventArgs e)
        {
            OnOkClick(e);
            DialogResult = DialogResult.OK;
            Close();
        }

        /// <summary>
        /// Fires OkClick event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnOkClick(EventArgs e)
        {
            if (OkClick != null)
            {
                OkClick(this, e);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// Fires CancelClick event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnCancelClicking(CancelEventArgs args)
        {
            if (CancelClicking != null)
            {
                CancelClicking(this, args);
            }
        }

        private void TaskChoiceForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (DialogResult == DialogResult.Cancel)
                {
                    CancelEventArgs args = new CancelEventArgs();
                    OnCancelClicking(args);

                    if (args.Cancel)
                    {
                        e.Cancel = true;
                    }
                }
            }            
        }

        #endregion                           
       
    }
}
