﻿using System;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Controls
{
    /// <summary>
    /// 
    /// </summary>
    public partial class KeyboardInputControl : UserControl, IViewKeyboardInput
    {
        public KeyboardInputControl()
        {
            InitializeComponent();
            this.tbInputAnswer.TextChanged += new EventHandler(tbInputAnswer_TextChanged);
        }

        public bool InputDisabled
        {
            get;
            set;
        }

        #region Control event handlers

        void tbInputAnswer_TextChanged(object sender, EventArgs e)
        {
            if (ValueChanged != null)
            {
                ValueChanged(sender, e);
            }
        }

        #endregion

        #region IViewKeyboardInput Members

        /// <summary>
        /// Occurs when value in textbox control is changed
        /// </summary>
        public event EventHandler<EventArgs> ValueChanged;

        public bool IsEnabled
        {
            get
            {
                return tbInputAnswer.Enabled;
            }
            set
            {
                tbInputAnswer.Enabled = value;
            }
        }

        /// <summary>
        /// Get or set entered data into field
        /// </summary>
        public string InputValue
        {
            get
            {
                return tbInputAnswer.Text;
            }
            set
            {
                tbInputAnswer.Text = value;
            }
        }

        /// <summary>
        /// Indicate there is any data 
        /// </summary>
        public bool HasInputValue
        {
            get
            {
                return !String.IsNullOrEmpty(InputValue);
            }
        }

        public void SetFocus()
        {
            if (tbInputAnswer.Enabled)
            {
                tbInputAnswer.Focus();
            }
        }

        /// <summary>
        /// Indicate is current control focused
        /// </summary>
        public bool IsFocused
        {
            get
            {
                return tbInputAnswer.Focused;
            }
        }

        /// <summary>
        /// Clear input field
        /// </summary>
        public void Clear()
        {
            tbInputAnswer.Clear();
        }
        
        #endregion

        private void tbInputAnswer_KeyDown(object sender, KeyEventArgs e)
        {
            if (InputDisabled)
            {
                e.SuppressKeyPress = true;
            }

            if (e.KeyCode == Keys.Enter)
            {
                // Hack to disable beeps in single line text box when "Enter" is pressed
                // http://www.vbforums.com/showthread.php?t=394442
                e.SuppressKeyPress = true;
            }
        }
    }
}
