﻿using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.Resources;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using System;
using System.Drawing;
using System.Drawing.Text;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.Forms
{
    public partial class WarmTransferForm : Form, IViewWarmTransferForm
    {
        private bool _canFormBeClosed;

        public WarmTransferForm()
        {
            InitializeComponent();

            _canFormBeClosed = false;
        }

        public event EventHandler<EventArgs> OnCompleteClick;
        public event EventHandler<EventArgs> OnCancelClick;

        public event EventHandler<EventArgs> OnMergeClick;
        public event EventHandler<EventArgs> OnTalkPrivatelyWithRespondentClick;
        public event EventHandler<EventArgs> OnTalkPrivatelyWithTransferTargetClick;

        private Color _defaultBlueButtonColor = Color.FromArgb(0, 176, 255);     // #00B0FF
        private Color _hoverBlueButtonColor = Color.FromArgb(0, 163, 242);       // #00A3F2
        private Color _pressedBlueButtonColor = Color.FromArgb(0, 151, 230);     // #0097E6
        private Color _enabledButtonTextColor = Color.FromArgb(255, 255, 255);   // #FFFFFF

        private Color _disabledButtonColor = Color.FromArgb(227, 227, 227);      // #121821
        private Color _disabledButtonTextColor = Color.FromArgb(150, 150, 150);  // #121821

        public void ShowForm(ConsoleTransferState transferState)
        {
            if (transferState.Target.ParticipantType == ParticipantType.External)
            {
                Text = Strings.ExternalWarmTransfer;
                pictureBoxTitle.Image = Properties.Resources.ExternalCallTransferTitle;
            }
            else
            {
                Text = Strings.InternalWarmTransfer;
                pictureBoxTitle.Image = Properties.Resources.InternalCallTransferTitle;
            }

            SetTargetConstrols(transferState.Target);

            SetRespondentConstrols(transferState.Respondent);

            SetButtons(transferState.Target, transferState.Respondent);

            if (!Visible)
            {
                Show();
                textBoxForFocus.Focus();
            }
        }

        public void Localize(ILocalizationManager manager)
        {
            labelTitle.Text = manager.GetString("WarmTransferForm_Title");
            buttonMerge.Text = manager.GetString("WarmTransferForm_Мerge");
            buttonTalkPrivatelyWithTransferTarget.Text = buttonTalkPrivatelyWithRespondent.Text = manager.GetString("WarmTransferForm_PrivateCall");
        }

        private void SetTargetConstrols(TransferParticipant target)
        {
            labelTransferTargetInfo.Text = target.Resource;
            pictureBoxTransferCalling.Visible = false;

            switch (target.DialingState)
            {
                case DialingState.Connected:
                    pictureBoxTransferTarget.Image = Properties.Resources.ParticipentGreen;
                    pictureBoxTargetConnectionState.Image = Properties.Resources.Connector_Green;
                    labelTransferTargetStatus.Text = Strings.Connected;
                    break;
                case DialingState.Waiting:
                case DialingState.Dialing:
                    pictureBoxTransferTarget.Image = Properties.Resources.calling_small;
                    pictureBoxTargetConnectionState.Image = null;
                    labelTransferTargetStatus.Text = target.DialingState == DialingState.Waiting ? Strings.Waiting : Strings.Calling;
                    pictureBoxTransferCalling.Visible = true;
                    break;
                case DialingState.Hold:
                    pictureBoxTransferTarget.Image = Properties.Resources.ParticipentRed;
                    pictureBoxTargetConnectionState.Image = Properties.Resources.Connector_Red;
                    labelTransferTargetStatus.Text = Strings.Hold;
                    break;
                default:
                    pictureBoxTransferTarget.Image = Properties.Resources.ParticipentRed;
                    pictureBoxTargetConnectionState.Image = null;
                    labelTransferTargetStatus.Text = Strings.Disconnected;
                    labelTransferTargetInfo.Text = GetDisconnectReason(target.DialingStateOutcome);
                    break;
            }
        }

        private void SetRespondentConstrols(TransferParticipant respondent)
        {
            labelRespondentInfo.Text = respondent.Resource;
            pictureBoxRespondentCalling.Visible = false;

            switch (respondent.DialingState)
            {
                case DialingState.Connected:
                    pictureBoxRespondent.Image = Properties.Resources.ParticipentGreen;
                    pictureBoxRespondentConnectionState.Image = Properties.Resources.Connector_Green;
                    labelRespondentStatus.Text = Strings.Connected;
                    break;
                case DialingState.Waiting:
                case DialingState.Dialing:
                    pictureBoxRespondent.Image = Properties.Resources.calling_small;
                    pictureBoxRespondentConnectionState.Image = null;
                    labelRespondentStatus.Text = respondent.DialingState == DialingState.Waiting ? Strings.Waiting : Strings.Calling;
                    pictureBoxRespondentCalling.Visible = true;
                    break;
                case DialingState.Hold:
                    pictureBoxRespondent.Image = Properties.Resources.ParticipentRed;
                    pictureBoxRespondentConnectionState.Image = Properties.Resources.Connector_Red;
                    labelRespondentStatus.Text = Strings.Hold;
                    break;
                default:
                    pictureBoxRespondent.Image = Properties.Resources.ParticipentRed;
                    pictureBoxRespondentConnectionState.Image = null;
                    labelRespondentStatus.Text = Strings.Disconnected;
                    labelRespondentInfo.Text = GetDisconnectReason(respondent.DialingStateOutcome);
                    break;
            }
        }

        private void SetButtons(TransferParticipant target, TransferParticipant respondent)
        {
            if ((target.DialingState != DialingState.Connected && target.DialingState != DialingState.Hold) || 
                (respondent.DialingState != DialingState.Connected && respondent.DialingState != DialingState.Hold))
            {
                buttonComplete.Enabled = false;
                buttonMerge.Enabled = false;
                buttonTalkPrivatelyWithRespondent.Enabled = false;
                buttonTalkPrivatelyWithTransferTarget.Enabled = false;

                return;
            }

            buttonComplete.Enabled = true;
            buttonMerge.Enabled = target.DialingState != respondent.DialingState;
            if (buttonMerge.Enabled)
            {
                buttonTalkPrivatelyWithRespondent.Enabled = respondent.DialingState == DialingState.Hold;
                buttonTalkPrivatelyWithTransferTarget.Enabled = target.DialingState == DialingState.Hold;
            }
            else
            {
                buttonTalkPrivatelyWithRespondent.Enabled = true;
                buttonTalkPrivatelyWithTransferTarget.Enabled = true;
            }
        }

        public void CloseForm()
        {
            if (!IsDisposed)
            {
                _canFormBeClosed = true;
                Close();
            }
        }

        private string GetDisconnectReason(DialingStateOutcome dialingStateOutcome)
        {
            switch (dialingStateOutcome)
            {
                case DialingStateOutcome.Busy:
                    return "Busy";
                case DialingStateOutcome.NoReply:
                    return "No reply";
                default:
                    return "No connection";
            }            
        }

        private void buttonMerge_Click(object sender, EventArgs e)
        {
            OnMergeClick?.Invoke(this, e);
        }

        private void buttonTalkPrivatelyWtihRespondent_Click(object sender, EventArgs e)
        {
            OnTalkPrivatelyWithRespondentClick?.Invoke(this, e);
        }

        private void buttonTalkPrivatelyWithTransferTarget_Click(object sender, EventArgs e)
        {
            OnTalkPrivatelyWithTransferTargetClick?.Invoke(this, e);
        }

        private void buttonComplete_Click(object sender, EventArgs e)
        {
            OnCompleteClick?.Invoke(this, e);
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            OnCancelClick?.Invoke(this, e);
        }

        private void WarmTransferForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!_canFormBeClosed)
            {
                e.Cancel = true;
                buttonCancel_Click(sender, e);
            }
        }

        private void buttonMerge_MouseEnter(object sender, EventArgs e)
        {
            toolTip.Show(Strings.TransferMergeToolTip, buttonMerge, -10, -20);
            if (buttonMerge.Enabled)
            {
                buttonMerge.BackColor = _hoverBlueButtonColor;
            }
        }

        private void buttonMerge_MouseLeave(object sender, EventArgs e)
        {
            toolTip.Hide(buttonMerge);
            if (buttonMerge.Enabled)
            {
                buttonMerge.BackColor = _defaultBlueButtonColor;
            }
        }

        private void buttonTalkPrivatelyWithRespondent_MouseEnter(object sender, EventArgs e)
        {
            toolTip.Show(Strings.TalkPrivatelyWtihRespondentToolTip, buttonTalkPrivatelyWithRespondent, -10, -20);
            if (buttonTalkPrivatelyWithRespondent.Enabled)
            {
                buttonTalkPrivatelyWithRespondent.BackColor = _hoverBlueButtonColor;
            }
        }

        private void buttonTalkPrivatelyWithRespondent_MouseLeave(object sender, EventArgs e)
        {
            toolTip.Hide(buttonTalkPrivatelyWithRespondent);
            if (buttonTalkPrivatelyWithRespondent.Enabled)
            {
                buttonTalkPrivatelyWithRespondent.BackColor = _defaultBlueButtonColor;
            }
        }

        private void buttonTalkPrivatelyWithTransferTarget_MouseEnter(object sender, EventArgs e)
        {
            toolTip.Show(Strings.TalkPrivatelyWithTransferTargetToolTip, buttonTalkPrivatelyWithTransferTarget, -10, -20);
            if (buttonTalkPrivatelyWithTransferTarget.Enabled)
            {
                buttonTalkPrivatelyWithTransferTarget.BackColor = _hoverBlueButtonColor;
            }
        }

        private void buttonTalkPrivatelyWithTransferTarget_MouseLeave(object sender, EventArgs e)
        {
            toolTip.Hide(buttonTalkPrivatelyWithTransferTarget);
            if (buttonTalkPrivatelyWithTransferTarget.Enabled)
            {
                buttonTalkPrivatelyWithTransferTarget.BackColor = _defaultBlueButtonColor;
            }
        }

        private void buttonComplete_MouseEnter(object sender, EventArgs e)
        {
            toolTip.Show(Strings.TransferCompleteToolTip, buttonComplete, -10, -20);
        }

        private void buttonComplete_MouseLeave(object sender, EventArgs e)
        {
            toolTip.Hide(buttonComplete);
        }

        private void buttonCancel_MouseEnter(object sender, EventArgs e)
        {
            toolTip.Show(Strings.TransferCancelToolTip, buttonCancel, -10, -20);
        }

        private void buttonCancel_MouseLeave(object sender, EventArgs e)
        {
            toolTip.Hide(buttonCancel);
        }

        private void buttonTalkPrivatelyWithTransferTarget_EnabledChanged(object sender, EventArgs e)
        {
            if (buttonTalkPrivatelyWithTransferTarget.Enabled)
            {
                buttonTalkPrivatelyWithTransferTarget.BackColor = _defaultBlueButtonColor;
                buttonTalkPrivatelyWithTransferTarget.ForeColor = _enabledButtonTextColor;
            }
            else
            {
                buttonTalkPrivatelyWithTransferTarget.BackColor = _disabledButtonColor;
                buttonTalkPrivatelyWithTransferTarget.ForeColor = _disabledButtonTextColor;
            }
        }

        private void buttonTalkPrivatelyWithRespondent_EnabledChanged(object sender, EventArgs e)
        {
            if (buttonTalkPrivatelyWithRespondent.Enabled)
            {
                buttonTalkPrivatelyWithRespondent.BackColor = _defaultBlueButtonColor;
                buttonTalkPrivatelyWithRespondent.ForeColor = _enabledButtonTextColor;
            }
            else
            {
                buttonTalkPrivatelyWithRespondent.BackColor = _disabledButtonColor;
                buttonTalkPrivatelyWithRespondent.ForeColor = _disabledButtonTextColor;
            }
        }

        private void buttonMerge_EnabledChanged(object sender, EventArgs e)
        {
            if (buttonMerge.Enabled)
            {
                buttonMerge.BackColor = _defaultBlueButtonColor;
                buttonMerge.ForeColor = _enabledButtonTextColor;
            }
            else
            {
                buttonMerge.BackColor = _disabledButtonColor;
                buttonMerge.ForeColor = _disabledButtonTextColor;
            }
        }

        private void buttonTalkPrivatelyWithRespondent_MouseDown(object sender, MouseEventArgs e)
        {
            if (buttonTalkPrivatelyWithRespondent.Enabled)
            {
                buttonTalkPrivatelyWithRespondent.BackColor = _pressedBlueButtonColor;
            }
        }

        private void buttonTalkPrivatelyWithRespondent_MouseUp(object sender, MouseEventArgs e)
        {
            if (buttonTalkPrivatelyWithRespondent.Enabled)
            {
                buttonTalkPrivatelyWithRespondent.BackColor = _hoverBlueButtonColor;
            }
        }

        private void buttonMerge_MouseDown(object sender, MouseEventArgs e)
        {
            if (buttonMerge.Enabled)
            {
                buttonMerge.BackColor = _pressedBlueButtonColor;
            }
        }

        private void buttonMerge_MouseUp(object sender, MouseEventArgs e)
        {
            if (buttonMerge.Enabled)
            {
                buttonMerge.BackColor = _hoverBlueButtonColor;
            }
        }

        private void buttonTalkPrivatelyWithTransferTarget_MouseDown(object sender, MouseEventArgs e)
        {
            if (buttonTalkPrivatelyWithTransferTarget.Enabled)
            {
                buttonTalkPrivatelyWithTransferTarget.BackColor = _pressedBlueButtonColor;
            }
        }

        private void buttonTalkPrivatelyWithTransferTarget_MouseUp(object sender, MouseEventArgs e)
        {
            if (buttonTalkPrivatelyWithTransferTarget.Enabled)
            {
                buttonTalkPrivatelyWithTransferTarget.BackColor = _hoverBlueButtonColor;
            }
        }
    }
}
