﻿namespace Confirmit.CATI.Console.Views.Controls
{
    partial class ProcessControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ltControls = new System.Windows.Forms.TableLayoutPanel();
            this.pbProgress = new System.Windows.Forms.PictureBox();
            this.lbMessage = new System.Windows.Forms.Label();
            this.ltControls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProgress)).BeginInit();
            this.SuspendLayout();
            // 
            // ltControls
            // 
            this.ltControls.ColumnCount = 1;
            this.ltControls.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ltControls.Controls.Add(this.pbProgress, 0, 0);
            this.ltControls.Controls.Add(this.lbMessage, 0, 1);
            this.ltControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ltControls.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ltControls.Location = new System.Drawing.Point(0, 0);
            this.ltControls.Name = "ltControls";
            this.ltControls.RowCount = 3;
            this.ltControls.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.ltControls.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.ltControls.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.ltControls.Size = new System.Drawing.Size(500, 336);
            this.ltControls.TabIndex = 0;
            // 
            // pbProgress
            // 
            this.pbProgress.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.pbProgress.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.progress;
            this.pbProgress.Location = new System.Drawing.Point(234, 110);
            this.pbProgress.Name = "pbProgress";
            this.pbProgress.Size = new System.Drawing.Size(32, 32);
            this.pbProgress.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbProgress.TabIndex = 4;
            this.pbProgress.TabStop = false;
            // 
            // lbMessage
            // 
            this.lbMessage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbMessage.AutoSize = true;
            this.lbMessage.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lbMessage.Location = new System.Drawing.Point(207, 159);
            this.lbMessage.Name = "lbMessage";
            this.lbMessage.Size = new System.Drawing.Size(86, 16);
            this.lbMessage.TabIndex = 1;
            this.lbMessage.Text = "Please wait.";
            this.lbMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ProcessControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.ltControls);
            this.Name = "ProcessControl";
            this.Size = new System.Drawing.Size(500, 336);
            this.ltControls.ResumeLayout(false);
            this.ltControls.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProgress)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel ltControls;
        private System.Windows.Forms.Label lbMessage;
        private System.Windows.Forms.PictureBox pbProgress;
    }
}
