﻿using Confirmit.CATI.Console.Shared.Log;
using mshtml;
using System;
using System.Collections.Generic;
using Confirmit.CATI.Console.Views.Classes.Utilities;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    public class SubQuestion
    {
        #region Fields

        private Guid m_Id;
        private bool _active = false;
        private Question parent;
        private List<IHTMLElement> inputElements;
        private readonly bool _highlightQuestion;
        #endregion

        #region Contructors

        private SubQuestion()
        {
        }

        public SubQuestion(Question owner, List<IHTMLElement> inputElements, bool highlightQuestion)
        {
            this.Id = Guid.NewGuid();
            this.parent = owner;
            this.inputElements = inputElements;
            _highlightQuestion = highlightQuestion;
        }

        #endregion

        #region Properties

        public Guid Id
        {
            get
            {
                return m_Id;
            }
            set
            {
                m_Id = value;
            }
        }

        public Question Parent
        {
            get { return parent; }
            set { parent = value; }
        }

        public IList<IHTMLElement> InputElements
        {
            get { return inputElements; }
        }

        public bool Active
        {
            get
            {
                return _active;
            }
            set
            {
                for (int index = 0; index < inputElements.Count; index++)
                {
                    _active = value;

                    if (_highlightQuestion)
                    {
                        if (value)
                        {
                            AddCssClassToSubquestion(inputElements[index].parentElement);
                            AddCssClassToParent(inputElements[index].parentElement);
                        }
                        else
                        {
                            if (inputElements[index].parentElement != null && inputElements[index].parentElement.className != null)
                            {
                                RemoveCssClassFromSubquestion(inputElements[index].parentElement);
                                RemoveCssClassFromParent(inputElements[index].parentElement);
                            }

                            _active = false;
                        }
                    }
                }
            }
        }

        private void RemoveCssClassFromSubquestion(IHTMLElement element)
        {
            element.className = element.className
                .Replace(StylesProvider.CurrentSubquestionContainerClassName, "");
        }

        private void AddCssClassToSubquestion(IHTMLElement element)
        {
            element.className += $" {StylesProvider.CurrentSubquestionContainerClassName}";
        }

        private void AddCssClassToParent(IHTMLElement element)
        {
            if (element.parentElement != null)
            {
                if (element.parentElement.className == null || !element.parentElement.className.Contains(StylesProvider.CurrentSubquestionContainerParentClassName))
                {
                    element.parentElement.className += $" {StylesProvider.CurrentSubquestionContainerParentClassName}";
                }
            }
        }

        private void RemoveCssClassFromParent(IHTMLElement element)
        {
            if (element.parentElement != null && element.parentElement.className != null)
            {
                element.parentElement.className = element.parentElement.className.Replace(StylesProvider.CurrentSubquestionContainerParentClassName, "");
            }
        }

        #endregion

        #region Methods               

        public void ScrollIntoView()
        {
            try
            {
                if (InputElements.Count > 0 && (InputElements[0].parentElement is IHTMLTableCell))
                    InputElements[0].parentElement.scrollIntoView(true);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        #endregion
    }
}
