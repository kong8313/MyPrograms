﻿namespace Confirmit.CATI.Console.Views.Controls
{
    partial class OnABreakControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainPanel = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.tlpDuration = new System.Windows.Forms.TableLayoutPanel();
            this.lbDuration = new System.Windows.Forms.Label();
            this.lbElapsedTime = new System.Windows.Forms.Label();
            this.tplButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnContinue = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.bottomPanel = new System.Windows.Forms.Panel();
            this.breakType = new System.Windows.Forms.Label();
            this.mainPanel.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tlpDuration.SuspendLayout();
            this.tplButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainPanel
            // 
            this.mainPanel.Controls.Add(this.tableLayoutPanel1);
            this.mainPanel.Controls.Add(this.bottomPanel);
            this.mainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainPanel.Location = new System.Drawing.Point(0, 0);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(490, 344);
            this.mainPanel.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.Window;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.lblTitle, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.breakType, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tlpDuration, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.tplButtons, 1, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 63F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(490, 313);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblTitle.Font = new System.Drawing.Font("Tahoma", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblTitle.Location = new System.Drawing.Point(104, 90);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(282, 19);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "You are currently on a break";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tlpDuration
            // 
            this.tlpDuration.ColumnCount = 4;
            this.tlpDuration.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpDuration.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpDuration.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpDuration.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpDuration.Controls.Add(this.lbDuration, 1, 0);
            this.tlpDuration.Controls.Add(this.lbElapsedTime, 2, 0);
            this.tlpDuration.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpDuration.Location = new System.Drawing.Point(101, 145);
            this.tlpDuration.Name = "tlpDuration";
            this.tlpDuration.RowCount = 1;
            this.tlpDuration.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpDuration.Size = new System.Drawing.Size(288, 28);
            this.tlpDuration.TabIndex = 3;
            // 
            // lbDuration
            // 
            this.lbDuration.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbDuration.AutoSize = true;
            this.lbDuration.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lbDuration.Location = new System.Drawing.Point(76, 12);
            this.lbDuration.Margin = new System.Windows.Forms.Padding(0);
            this.lbDuration.Name = "lbDuration";
            this.lbDuration.Size = new System.Drawing.Size(69, 16);
            this.lbDuration.TabIndex = 0;
            this.lbDuration.Text = "Duration:";
            this.lbDuration.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lbElapsedTime
            // 
            this.lbElapsedTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbElapsedTime.AutoSize = true;
            this.lbElapsedTime.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lbElapsedTime.Location = new System.Drawing.Point(145, 12);
            this.lbElapsedTime.Margin = new System.Windows.Forms.Padding(0);
            this.lbElapsedTime.Name = "lbElapsedTime";
            this.lbElapsedTime.Size = new System.Drawing.Size(66, 16);
            this.lbElapsedTime.TabIndex = 1;
            this.lbElapsedTime.Text = "00:00:00";
            // 
            // tplButtons
            // 
            this.tplButtons.ColumnCount = 2;
            this.tplButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tplButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tplButtons.Controls.Add(this.btnContinue, 0, 0);
            this.tplButtons.Controls.Add(this.btnLogout, 1, 0);
            this.tplButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tplButtons.Location = new System.Drawing.Point(101, 179);
            this.tplButtons.Name = "tplButtons";
            this.tplButtons.RowCount = 1;
            this.tplButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tplButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tplButtons.Size = new System.Drawing.Size(288, 57);
            this.tplButtons.TabIndex = 4;
            // 
            // btnContinue
            // 
            this.btnContinue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnContinue.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnContinue.Location = new System.Drawing.Point(3, 31);
            this.btnContinue.Margin = new System.Windows.Forms.Padding(3, 3, 20, 3);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(121, 23);
            this.btnContinue.TabIndex = 0;
            this.btnContinue.Text = "Continue working";
            this.btnContinue.UseVisualStyleBackColor = true;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLogout.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnLogout.Location = new System.Drawing.Point(164, 31);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(20, 3, 3, 3);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(121, 23);
            this.btnLogout.TabIndex = 1;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // bottomPanel
            // 
            this.bottomPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bottomPanel.Location = new System.Drawing.Point(0, 313);
            this.bottomPanel.Name = "bottomPanel";
            this.bottomPanel.Size = new System.Drawing.Size(490, 31);
            this.bottomPanel.TabIndex = 0;
            // 
            // breakType
            // 
            this.breakType.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.breakType, 3);
            this.breakType.Dock = System.Windows.Forms.DockStyle.Top;
            this.breakType.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.breakType.Location = new System.Drawing.Point(6, 109);
            this.breakType.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.breakType.Name = "breakType";
            this.breakType.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.breakType.Size = new System.Drawing.Size(478, 19);
            this.breakType.TabIndex = 5;
            this.breakType.Text = "Break Type:  Default";
            this.breakType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // OnABreakControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.mainPanel);
            this.Name = "OnABreakControl";
            this.Size = new System.Drawing.Size(490, 344);
            this.VisibleChanged += new System.EventHandler(this.OnABreakControl_VisibleChanged);
            this.mainPanel.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tlpDuration.ResumeLayout(false);
            this.tlpDuration.PerformLayout();
            this.tplButtons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Panel bottomPanel;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnContinue;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TableLayoutPanel tlpDuration;
        private System.Windows.Forms.Label lbDuration;
        private System.Windows.Forms.Label lbElapsedTime;
        private System.Windows.Forms.TableLayoutPanel tplButtons;
        private System.Windows.Forms.Label breakType;
    }
}
