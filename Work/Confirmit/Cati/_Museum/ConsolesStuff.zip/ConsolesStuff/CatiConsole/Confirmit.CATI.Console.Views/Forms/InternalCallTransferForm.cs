﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
    public partial class InternalCallTransferForm : Form, IViewInternalCallTransferForm
    {
        public InternalCallTransferForm()
        {
            InitializeComponent();
        }

        void IViewCallTransferForm<InternalTransferTarget>.Show(IWin32Window parent)
        {
            if (!Visible)
                ShowDialog(parent);
        }

        public event EventHandler<EventArgs> CallTransferStart;

        public void Localize(ILocalizationManager manager)
        {
            Localize(manager, ConsoleTransferType.InternalWarm);
        }

        public void Localize(ILocalizationManager manager, ConsoleTransferType transferType)
        {
            Text = string.Format(
                manager.GetString("InternalCallTransferForm_Caption"), 
                transferType == ConsoleTransferType.InternalCold 
                    ? manager.GetString("CallTransferForm_ColdTransferTypeName") 
                    : manager.GetString("CallTransferForm_WarmTransferTypeName"));

            lbTitle.Text = manager.GetString("InternalCallTransferForm_Title");
            lbTitleDescription.Text = manager.GetString("InternalCallTransferForm_Description");

            buttonCancel.Text = manager.GetString("CallTransferForm_ButtonCancel_Text");
            buttonTransfer.Text = transferType == ConsoleTransferType.InternalCold 
                ? manager.GetString("CallTransferForm_ButtonTransfer_Complete") 
                : manager.GetString("CallTransferForm_ButtonTransfer_Start");
        }

        public InternalTransferTarget Selected => (InternalTransferTarget)grid.SelectedRows.Cast<DataGridViewRow>().SingleOrDefault()?.Tag;

        private int GetTargetRowIndex(InternalTransferTarget target)
        {
            for (int i = 0; i < grid.Rows.Count; i++)
            {
                if (((InternalTransferTarget)grid.Rows[i].Tag).Name == target.Name)
                {
                    return i;
                }
            }

            return -1;
        }

        private bool IsTargetListIdentical(InternalTransferTarget[] transferTargets)
        {
            return grid.Rows.Count == transferTargets.Length && transferTargets.All(t => GetTargetRowIndex(t) != -1);
        }

        private Bitmap GetTargetIcon(InternalTransferTarget target)
        {
            if (target.CountOfFreeInterviewersLoggedIn >= 1)
            {
                return Properties.Resources.Group_green;
            }

            if (target.CountOfTotalInterviewersLoggedIn > 1)
            {
                return Properties.Resources.Group_yellow;
            }

            return Properties.Resources.Group_red;
        }

        public void SelectRow(string lastUsedTransferTargetGroupName)
        {
            for (var i = 0; i < grid.RowCount; i++)
            {
                if (((InternalTransferTarget)grid.Rows[i].Tag).Name == lastUsedTransferTargetGroupName)
                {
                    grid.CurrentCell = grid.Rows[i].Cells[0];
                    grid.FirstDisplayedScrollingRowIndex = i;
                    return;
                }
            }

            grid.CurrentCell = grid.Rows[0].Cells[0];
            grid.FirstDisplayedScrollingRowIndex = 0;
        }

        public void UpdateFormData(InternalTransferTarget[] transferTargets)
        {
            grid.SuspendLayout();

            if (IsTargetListIdentical(transferTargets))
            {
                foreach (var target in transferTargets)
                {
                    var index = GetTargetRowIndex(target);

                    grid.Rows[index].Cells["TargetIcon"].Value = GetTargetIcon(target);
                    grid.Rows[index].Cells["NumberOfInterviewersInWaitingOrSelectingState"].Value = target.CountOfFreeInterviewersLoggedIn;
                    grid.Rows[index].Cells["Description"].Value = target.Description;
                    grid.Rows[index].Cells["NumberOfWorkingInterviewers"].Value = target.CountOfTotalInterviewersLoggedIn;
                }
            }
            else
            {
                grid.Rows.Clear();

                foreach (var target in transferTargets)
                {
                    var index = grid.Rows.Add(GetTargetIcon(target), target.Name, target.Description, target.CountOfFreeInterviewersLoggedIn, target.CountOfTotalInterviewersLoggedIn);
                    grid.Rows[index].Tag = target;
                }
            }

            grid.ResumeLayout(true);
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void OnDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            CallTransferStart?.Invoke(this, e);
        }

        private void buttonTransfer_Click(object sender, EventArgs e)
        {
            CallTransferStart?.Invoke(this, e);
        }

        public void EnableTransferButton(bool isTransferPossible)
        {
            buttonTransfer.Enabled = isTransferPossible;
        }

        private void grid_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            CallTransferStart?.Invoke(this, e);
        }
    }
}