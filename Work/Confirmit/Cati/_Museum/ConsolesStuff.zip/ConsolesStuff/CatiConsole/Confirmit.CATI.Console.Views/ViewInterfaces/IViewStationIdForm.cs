﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Represents view interface for StationIdForm form.
    /// </summary>
    public interface IViewStationIdForm : ILocalizableView
    {
        /// <summary>
		/// Occurs when user clicks Ok button.
		/// </summary>
		event EventHandler<EventArgs> OkClick;

        /// <summary>
        /// Occurs when user clicks Cancel button or manualy closes form
        /// </summary>
        event EventHandler<CancelEventArgs> CancelClicking;

        /// <summary>
        /// Occurs when station id is going to be validated.
        /// </summary>
        event EventHandler<CancelEventArgs> ValidatingStationId;

        /// <summary>
        /// Gets entered station identifier
        /// </summary>
        string StationId
        {
            get;
            set;
        }

        /// <summary>
        /// Notifies user about validation error of specified control.
        /// </summary>
        /// <param name="message">Error message.</param>
        void AlertValidationError(string message);

        /// <summary>
        /// Shows modal station id form.
        /// </summary>
        /// <param name="parent">Parent window handle.</param>
        DialogResult Show(IWin32Window parent);
    }
}
