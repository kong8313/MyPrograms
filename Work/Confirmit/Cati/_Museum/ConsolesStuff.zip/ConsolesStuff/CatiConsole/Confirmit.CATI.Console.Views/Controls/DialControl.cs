﻿using System;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Controls
{
    public partial class DialControl : UserControl, IViewDialControl
    {
        #region Constructors

        public DialControl()
        {
            InitializeComponent();
        }

        #endregion

        #region IViewDialControl Members

        public string HangupMessage { get; set; }

        /// <summary>
        /// Gets/sets dialing message.
        /// </summary>
        public string Message
        {
            get
            {
                return lbMessage.Text;
            }
            set
            {
                lbMessage.Text = value;
            }
        }

        /// <summary>
        /// Gets/sets phone number.
        /// </summary>
        public string Phone
        {
            get;
            set;            
        }

        public bool IsDialCanellationButtonEnabled 
        {
            get
            {
                return btnCancel.Enabled;
            }
            set
            {
                btnCancel.Enabled = value;
            }
        }

        #endregion

        #region ILocalizableView Members

        /// <summary>
        /// Localizes view according given localization information.
        /// </summary>
        /// <param name="manager">Localization manager which contains localization info.</param>
        public void Localize(ILocalizationManager manager)
        {
            btnCancel.Text = manager.GetString("DialControl_CancelDialButton_Text");
            lbHint.Text = manager.GetString("DialControl_CancelDialHint_Text");
        }

        #endregion

        public event EventHandler<DialCancellationEventArgs> CancelClick;

        public void ShowCancelButton(bool isVisible)
        {
            ltPhone.Visible = isVisible;
        }

        public void EnableDialCanellationButton(bool isEnabled)
        {
            btnCancel.Enabled = isEnabled;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (CancelClick != null)
            {
                CancelClick(this, new DialCancellationEventArgs
                {
                    IsConfirmationDialogRequired = false
                });
                btnCancel.Enabled = false;
                Message = HangupMessage;
            }
        }
    }
}
