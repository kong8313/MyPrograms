﻿using System.Threading;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Implement base interface for monitorable views.
    /// </summary>
    public interface IPlayableView
    {
        /// <summary>
        /// Uses for safe GUI changes
        /// </summary>
        SynchronizationContext SynchronizationContext
        {
            get;
        }

    }
}

