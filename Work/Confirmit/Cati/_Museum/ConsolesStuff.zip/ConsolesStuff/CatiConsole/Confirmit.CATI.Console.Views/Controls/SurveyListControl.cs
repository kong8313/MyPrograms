﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Confirmit.CATI.Console.Shared.Utilities;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.Classes.SearchableGrid;
using Confirmit.CATI.Console.Views.Classes.Utilities;
using Confirmit.CATI.Console.Views.Resources;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Controls
{
	public partial class SurveyListControl : UserControl, IViewSurveyListControl
	{
        private const int m_InterviewIdColumnIndex = 0;
        private const int m_DefaultColumnWidth = 150; 

		/// <summary>
		/// Initializes new instance of SurveyListControl
		/// </summary>
		public SurveyListControl()
		{
			InitializeComponent();
            InitializeEventHandlers();           

            IsCreateNewButtonEnabled = true;
		}        

        /// <summary>
        /// Returns true if survey list is available for survey selecting
        /// </summary>
        /// <remarks>
        /// If property is false SurveyListControl will not be raised event SurveySelectionChanged.
        /// </remarks>
        private bool IsSurveySelectionEnabled => (lvSurveyList.View == View.Details);

	    private bool IsCreateNewButtonEnabled;

		/// <summary>
		/// Localizes view according given localization information.
		/// </summary>
		/// <param name="manager">Localization manager which contains localization info.</param>
		public void Localize(ILocalizationManager manager)
		{
		    chSurveyName.Text = manager.GetString("SurveyList_Column_SurveyName_Text");

            foreach (DataGridViewColumn c in m_grid.GridHeader.Columns)
            {
                c.HeaderText = manager.GetString(string.Format("SurveyList_Column_{0}_Text", c.Name)) ?? c.HeaderText;
            }                       
        }

		/// <summary>
		/// Occurs when survey selected index is changed.
		/// </summary>
		public event EventHandler<EventArgs> SurveySelectionChanged;		

		/// <summary>
		/// Occurs when survey is selected for interviewing.
		/// </summary>
		public event EventHandler<EventArgs> SurveySelected;

		/// <summary>
		/// Occurs when interview is selected for interviewing.
		/// </summary>
		public event EventHandler<EventArgs> InterviewSelected;

	    /// <summary>
	    /// Occurs when user try to create a new interview.
	    /// </summary>
	    public event EventHandler<EventArgs> CreateInterview;

        /// <summary>
        /// Occurs when splitter control is moved.
        /// </summary>
        public event EventHandler<EventArgs> SplitterMoved;

        /// <summary>
        /// Occurs when control is resized.
        /// </summary>
        public event EventHandler<EventArgs> FormResize;

        /// <summary>
        /// Occurs when user invoke interviews filtering.
        /// </summary>
        public event EventHandler<EventArgs> FilterInterviews;

	    /// <summary>
	    /// Occurs when user invoke reset interviews searching filters.
	    /// </summary>
	    public event EventHandler<EventArgs> ResetAllFilters;

        /// <summary>
        /// Occurs when user click header column for sort list.
        /// </summary> 
        public event EventHandler<ColumnSortModeChangedEventArgs> ColumnSortModeChanged;

		/// <summary>
		/// Gets or sets the index of selected survey.
		/// </summary>
		[Browsable(false)]
		public int SelectedSurvey
		{
			get 
			{
				if (lvSurveyList.SelectedIndices.Count == 0)
				{
					return -1;
				}
				else
				{
					return lvSurveyList.SelectedIndices[0];
				}
			}
			set
			{
				if (lvSurveyList.Items.Count > 0)
				{
					if (0 < value && value >= lvSurveyList.Items.Count)
					{
						throw new ArgumentOutOfRangeException("value");
					}

					lvSurveyList.Items[value].Selected = true;
				}
			}
		}

		/// <summary>
		/// Gets or sets the index of selected inetrview.
		/// </summary>
		[Browsable(false)]
		public int SelectedInterview
		{
			get 
			{
                if (m_grid.GridInterviews.SelectedRows.Count == 0)                 
                {
                    return -1;
                }
				else
				{
                    return int.Parse(m_grid.GridInterviews.SelectedRows[0].Cells[m_InterviewIdColumnIndex].Value.ToString());
				}
			}			
		}

        /// <summary>
        /// Gets list of SearchParameters
        /// </summary>
        public List<ConsoleSearchParameter> SearchParameters
        {
            get
            {
                var result = new List<ConsoleSearchParameter>();

                foreach (DataGridViewColumn c in m_grid.GridHeader.Columns)
                {
                    var cellValue = (string)m_grid.GridHeader.Rows[0].Cells[c.Name].Value;

                    if (String.IsNullOrEmpty(cellValue) == false)
                    {
                        result.Add(
                            new ConsoleSearchParameter
                            {
                                ColumnName = c.Name,
                                ColumnCaption = c.HeaderText,
                                ColumnTypeName = c.ValueType.FullName,
                                Value = cellValue
                            });
                    }
                }

                return result;
            }
        }

        /// <summary>
        /// Gets client size of survey list.
        /// </summary>
        public Size SurveyListClientSize => lvSurveyList.ClientSize;

	    /// <summary>
        /// Gets a value indicating whether the items in the SurveyListControl control 
        /// are sorted in ascending or descending order, or are not sorted.
        /// </summary>
        public SortOrder SortOrder => m_grid.GridHeader.SortOrder;

	    /// <summary>
        /// Gets sorted column index. If there is no sorted column, returns -1.
        /// </summary>
        public int SortedColumnIndex => m_grid.GridHeader.SortedColumn == null ? -1 : m_grid.GridHeader.SortedColumn.Index;

	    /// <summary>
		/// Enables/disables interview list.
		/// </summary>
		/// <param name="enable">If is true, then enables interview list;
		/// otherwise disables.</param>
		public void EnableInterviewList(bool enable)
		{
            m_grid.Enabled = enable;
			splSurveySplitter.Panel2Collapsed = !enable;
		}

		/// <summary>
		/// Binds survey list.
		/// </summary>
		/// <param name="surveys">Surveys collection.</param>
		public void BindSurveyList(string[] surveys)
		{
			lvSurveyList.Items.Clear();
            lvSurveyList.View = View.Details;

			if (surveys != null)
			{
				foreach (string survey in surveys)
				{
					lvSurveyList.Items.Add(survey);
				}
			}
		}

        /// <summary>
        /// Binds search parameters.
        /// </summary>
        /// <param name="parameters">Parameters collection.</param>
        public void BindSearchParameters(IEnumerable<ConsoleSearchParameter> parameters)
	    {
	        foreach (DataGridViewColumn c in m_grid.GridHeader.Columns)
	        {
	            var parameter = parameters.FirstOrDefault(param => param.ColumnName == c.Name);
	            if (parameter != null)
	            {
	                m_grid.GridHeader.Rows[0].Cells[c.Name].Value = parameter.Value;
	            }
	        }
	    }

        /// <summary>
        /// Binds interview list.
        /// </summary>
        /// <param name="table">DataTable with interviews.</param>
        /// <param name="fullRebuild">If true, data and schema will be changed; otherwise data will be updated.</param>
        /// <param name="bindHeader">If true header will be rebuid even fullRebuid is false. Search data will be remain.</param>
        public void BindInterviewList(DataTable table, bool fullRebuild, bool bindHeader)
        {
            if (fullRebuild)
            {
                BindInterviewsHeader(table.WithoutColumn("RespondentTime"), false);
            }
            else if (bindHeader)
            {
                BindInterviewsHeader(table.WithoutColumn("RespondentTime"), true);
            }

            BindInterviewsData(table);                        
        }

        

	    /// <summary>
        /// Show message into interview list.
        /// </summary>
        /// <param name="message">message for display</param>
        public void ShowMessageInterviewList(string message)
        {
            //TODO: AAZ
        }

        /// <summary>
        /// Show message into survey list.
        /// </summary>
        /// <param name="message">message for display</param>
        public void ShowMessageSurveyList(string message)
        {
            lvSurveyList.View = View.List;
            lvSurveyList.Items.Clear();
            lvSurveyList.Items.Add(message);
        }
    
        /// <summary>
        /// Sets width of "Survey name" column in survey list.
        /// </summary>
        /// <param name="width"></param>
        public void SetSurveyColumnWidth(int width)
        {
            lvSurveyList.Columns[0].Width = width;
        }

        /// <summary>
        /// Activate filter edit control for specified column.
        /// </summary>
        /// <param name="columnName">Name of column with incorrect filter value.</param>
        public void ActivateColumnFilter(string columnName)
        {            
            m_grid.GridHeader.CurrentCell = m_grid.GridHeader.Rows[0].Cells[columnName];
            m_grid.GridHeader.BeginEdit(true);
        }		

        public void EnableCreateNewButton(bool enabled)
        {
            btnCreateNew.BackgroundImage = enabled
                ? Properties.Resources.CreateNewInterview
                : Properties.Resources.CreateNewInterviewDisabled;

            IsCreateNewButtonEnabled = enabled;
        }

		private void lvSurveyList_DoubleClick(object sender, EventArgs e)
		{
			OnSurveySelected(EventArgs.Empty);
		}

        private void GridInterviews_DoubleClick(object sender, EventArgs e)
        {            
            OnInterviewSelected(EventArgs.Empty);
        }

        private void GridInterviews_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter &&
               m_grid.GridInterviews.Rows.Count > 0)
            {
                OnInterviewSelected(EventArgs.Empty);
            }
        }        

		private void lvSurveyList_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
		{
			if (IsSurveySelectionEnabled && e.IsSelected)
			{                
                OnSurveySelectionChanged(EventArgs.Empty);
			}
		}

        private void SurveyListControl_Resize(object sender, EventArgs e)
        {
            OnFormResize(EventArgs.Empty);
        }

        private void splSurveySplitter_SplitterMoved(object sender, SplitterEventArgs e)
        {
            OnSplitterMoved(EventArgs.Empty);
        }        

        private void lvSurveyList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter &&
                lvSurveyList.SelectedIndices.Count > 0)
            {
                OnSurveySelected(EventArgs.Empty);
            }
        }                        

        private void m_grid_StopEditOnEnter(object sender, EventArgs e)
        {
            OnFilterInterviews(EventArgs.Empty);
        }

        private void m_grid_ColumnSortModeChanged(object sender, ColumnSortModeChangedEventArgs e)
        {
            OnColumnSortModeChanged(e);
        }

	    private void btnStartSelected_Click(object sender, EventArgs e)
	    {
	        GridInterviews_DoubleClick(sender, e);
	    }

	    private void btnCreateNew_Click(object sender, EventArgs e)
	    {
	        if (!IsCreateNewButtonEnabled)
	        {
	            return;
	        }

            OnCreateInterview(EventArgs.Empty);
	    }

	    private void btnCreateNew_MouseEnter(object sender, EventArgs e)
	    {
            if (IsCreateNewButtonEnabled)
            {
                toolTip.Show(Strings.CreateNewInterviewTooltip, btnCreateNew, -10, -20);
                btnCreateNew.FlatStyle = FlatStyle.Standard;
            }
            else
            {
                toolTip.Show(Strings.CreateNewInterviewDisabledTooltip, btnCreateNew, -10, -20);
            }
	    }

	    private void btnCreateNew_MouseLeave(object sender, EventArgs e)
	    {
	        toolTip.Hide(btnCreateNew);

            if (IsCreateNewButtonEnabled)
            {
                btnCreateNew.FlatStyle = FlatStyle.Flat;
            }
	    }

	    private void btnStartSelected_MouseEnter(object sender, EventArgs e)
	    {
            toolTip.Show(Strings.StartSelectedInterviewTooltip, btnStartSelected, -10, -20);
            btnStartSelected.FlatStyle = FlatStyle.Standard;
	    }

	    private void btnStartSelected_MouseLeave(object sender, EventArgs e)
	    {
            toolTip.Hide(btnStartSelected);
            btnStartSelected.FlatStyle = FlatStyle.Flat;
	    }

	    private void btnResetAllFilters_Click(object sender, EventArgs e)
	    {
	        OnResetAllFilters(EventArgs.Empty);
	    }

	    private void btnResetAllFilters_MouseEnter(object sender, EventArgs e)
	    {
	        toolTip.Show(Strings.ResetFiltersTooltip, btnResetAllFilters, -10, -20);
	        btnResetAllFilters.FlatStyle = FlatStyle.Standard;
        }

	    private void btnResetAllFilters_MouseLeave(object sender, EventArgs e)
	    {
	        toolTip.Hide(btnResetAllFilters);
	        btnResetAllFilters.FlatStyle = FlatStyle.Flat;
        }

        private void InitializeEventHandlers()
        {
            m_grid.StopEditOnEnter += new EventHandler(m_grid_StopEditOnEnter);
            m_grid.GridInterviews.DoubleClick += new EventHandler(GridInterviews_DoubleClick);
            m_grid.GridInterviews.KeyUp += new KeyEventHandler(GridInterviews_KeyUp);
        }

        /// <summary>
        /// Adds header columns and 
        /// </summary>        
        private void BindInterviewsHeader(DataTable table, bool keepFilterData)
        {
            var filterData = new Dictionary<string, string>();
            var columnWidths = new Dictionary<string, int>();
            
            if (keepFilterData)
            {
                foreach (DataGridViewColumn c in m_grid.GridHeader.Columns)
                {
                    var value = (string)m_grid.GridHeader.Rows[0].Cells[c.Name].Value;
                    if (String.IsNullOrEmpty(value) == false)
                    {
                        filterData.Add(c.Name, value);
                    }
                    columnWidths.Add(c.Name, c.Width);
                }
            }

            m_grid.GridHeader.Columns.Clear();
            m_grid.GridInterviews.Columns.Clear();

            foreach (DataColumn c in table.Columns)
            {
                m_grid.AddColumn(c.ColumnName, c.Caption, c.DataType, m_DefaultColumnWidth);
            }

            if (keepFilterData)
            {
                foreach (DataGridViewColumn c in m_grid.GridHeader.Columns)
                {
                    if (filterData.ContainsKey(c.Name))
                    {
                        m_grid.GridHeader.Rows[0].Cells[c.Name].Value = filterData[c.Name];
                    }
                    if (columnWidths.ContainsKey(c.Name))
                    {
                        c.Width = columnWidths[c.Name];
                    }
                }
            }

            SetAutoFitForLastColumn();

            if (table.Columns.Contains("TimeToCall"))
            {
                DisablFilterForTimeToCallColumn();
            }
        }

	    private void DisablFilterForTimeToCallColumn()
	    {
            foreach (DataGridViewColumn c in m_grid.GridHeader.Columns)
            {
                if (string.Compare(c.Name, "TimeToCall", StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    m_grid.GridHeader.Rows[0].Cells[c.Name].ReadOnly = true;
                }
            }
	    }

	    /// <summary>
        /// Fills interviewer list
        /// </summary>       
        /// <remarks>
        /// We have to suspend layout before rows addition and resume it on finish
        /// otherwise if rows are adding while it is UI bound, each insert needs to think about a redraw. 
        /// That leads to incorrect scroll appearance.
        /// </remarks> 
        private void BindInterviewsData(DataTable table)
        {
            m_grid.GridInterviews.SuspendLayout();

            m_grid.GridInterviews.Rows.Clear();

            var isTimeToCallPresent = table.Columns.Contains("TimeToCall");            

            foreach (DataRow r in table.Rows)
            {
                var currentIndex = m_grid.GridInterviews.Rows.Add(r.ItemArray);

                if (isTimeToCallPresent)
                    AddTooltipForTimeToCallColumn(r, currentIndex);
            }            

            m_grid.GridHeader.CellBorderStyle = m_grid.GridInterviews.Rows.Count > 0?
                                                DataGridViewCellBorderStyle.SingleVertical : DataGridViewCellBorderStyle.Single;

            m_grid.GridInterviews.ResumeLayout(true);
        }	    

	    private void AddTooltipForTimeToCallColumn(DataRow row, int currentIndex)
	    {
            m_grid.GridInterviews.Rows[currentIndex].Cells["TimeToCall"].ToolTipText = (string) row["RespondentTime"];
	    }

	    /// <summary>
        /// Sets auto fit for last column.
        ///  </summary>
        /// <remarks>
        /// Needs for 'better' GUI-appearance of control.
        /// Sets minimum width equals to ordinary width otherwise it leads to problems with scrolls,
        /// last column width is shrinked to minimum width
        /// </remarks>
        private void SetAutoFitForLastColumn()
        {
            if (m_grid.GridHeader.Columns.Count > 0)
            {
                var lastColumn = m_grid.GridHeader.Columns[m_grid.GridHeader.Columns.Count - 1];

                lastColumn.Width = m_DefaultColumnWidth;
                lastColumn.MinimumWidth = m_DefaultColumnWidth;                
                lastColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;             
            }
        }

		/// <summary>
		/// Fires SurveySelectionChanged event.
		/// </summary>
		/// <param name="e"></param>
		private void OnSurveySelectionChanged(EventArgs e)
		{
            SurveySelectionChanged?.Invoke(this, e);

            ChangeStartSelectedButtonEnabled();
            ChangeResetFilterButtonEnabled();
        }

		/// <summary>
		/// Fires SurveySelected event.
		/// </summary>
		/// <param name="e"></param>
		private void OnSurveySelected(EventArgs e)
		{
            SurveySelected?.Invoke(this, e);
        }

		/// <summary>
		/// Fires InterviewSelected event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnInterviewSelected(EventArgs e)
		{
            InterviewSelected?.Invoke(this, e);
        }

        /// <summary>
        /// Fires CreateInterview event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnCreateInterview(EventArgs e)
	    {
            CreateInterview?.Invoke(this, e);
        }

        /// <summary>
        /// Fires ResetAllFilters event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnResetAllFilters(EventArgs e)
	    {
            ResetAllFilters?.Invoke(this, e);

            ChangeStartSelectedButtonEnabled();
            ChangeResetFilterButtonEnabled();
        }
        
        /// <summary>
        /// Fires SplitterMoved event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnSplitterMoved(EventArgs e)
        {
            SplitterMoved?.Invoke(this, e);
        }

        /// <summary>
        /// Fires FormResize event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnFormResize(EventArgs e)
        {
            FormResize?.Invoke(this, e);
        }

        /// <summary>
        /// Fires SearchInterviews event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnFilterInterviews(EventArgs e)
        {
            FilterInterviews?.Invoke(this, e);

            ChangeStartSelectedButtonEnabled();
            ChangeResetFilterButtonEnabled();
        }

	    private void ChangeStartSelectedButtonEnabled()
        {
	        var isStartSelectedEnabled = m_grid.GridInterviews.RowCount > 0;
	        btnStartSelected.Enabled = isStartSelectedEnabled;

	        btnStartSelected.BackgroundImage = isStartSelectedEnabled
	            ? Properties.Resources.StartSelectedInterview
                : Properties.Resources.StartSelectedInterviewDisabled;
        }

        private void ChangeResetFilterButtonEnabled()
        {
            var isFilterUsed = SearchParameters.Any(f => !string.IsNullOrEmpty(f.Value));
            btnResetAllFilters.Enabled = isFilterUsed;

            btnResetAllFilters.BackgroundImage = isFilterUsed
                ? Properties.Resources.ResetFilters
                : Properties.Resources.ResetFiltersDisabled;
        }

        /// <summary>
        /// Fires ColumnSortModeCnaged event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnColumnSortModeChanged(ColumnSortModeChangedEventArgs e)
        {
            ColumnSortModeChanged?.Invoke(this, e);
        }
    }
}