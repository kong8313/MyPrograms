﻿using System;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    public interface IViewKeyboardInput
    {
        #region Events
        /// <summary>
        /// Occurs when value in textbox control is changed
        /// </summary>
        event EventHandler<EventArgs> ValueChanged;

        #endregion

        #region Properties
        /// <summary>
        /// Gets or sets value in textbox
        /// </summary>
        string InputValue
        {
            get;
            set;
        }

        bool IsEnabled
        {
            get;
            set;
        }

        bool HasInputValue
        {
            get;
        }

        /// <summary>
        /// Indicate is current control focused
        /// </summary>
        bool IsFocused
        {
            get;
        }

        /// <summary>
        /// Set focus
        /// </summary>
        void SetFocus();

        /// <summary>
        /// Clear input field
        /// </summary>
        void Clear(); 
        #endregion

    }
}
