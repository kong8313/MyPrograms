﻿using System;

namespace Confirmit.CATI.Console.Views.Classes.Login
{
    /// <summary>
    /// Represents states returned by "Login to dialler" form.
    /// </summary>
    public enum LoginToDiallerResult
    {
        /// <summary>
        /// User is going to log in to dialler.
        /// </summary>
        LoginToDialler = 1,

        /// <summary>
        /// User wants to skip log in to dialler and work without dialler.
        /// </summary>
        SkipLoginToDialler = 2,

        /// <summary>
        /// User wants to log out.
        /// </summary>
        Logout = 3
    }
}
