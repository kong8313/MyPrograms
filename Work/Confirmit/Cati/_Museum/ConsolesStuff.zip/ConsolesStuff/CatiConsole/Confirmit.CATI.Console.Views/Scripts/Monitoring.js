﻿var CatiMonitoringView = function () {

}

function stringToNode(html) {
    var parser = new DOMParser();
    return parser.parseFromString(html, "text/html").body.childNodes[0];
}

function MutationHandler(mutations) {
    try {
        for (var index = 0; index < mutations.length; index++) {
            var mutation = mutations[index];
            var selector = mutation.selector;
            var type = mutation.type;
            var el;

            switch (type) {
                case "attributes":
                    var value = mutation.value;
                    el = document.querySelector(selector);
                    if (!el) continue;

                    if (mutation.attributeName === "class") {
                        el.className = value;
                    } 
                    else if (mutation.attributeName === "style") {
                        el.style.cssText = value;
                    }
                    else {
                        el[mutation.attributeName] = value;
                    }
                    break;
                case "characterData":
                    el = document.querySelector(selector);
                    if (!el) continue;

                    if (mutation.property) {
                        el[mutation.property] = mutation.value;
                    } else {
                        el.value = mutation.value;
                    }
                    break;
                case "childList":
                    for (var i = 0; i < mutation.removedNodes.length; i++) {
                        var element = document.querySelector(mutation.removedNodes[i]);
                        if (!element) continue;

                        element.parentNode.removeChild(element);
                    }

                    var target = document.querySelector(mutation.targetElementSelector);
                    if (!target) continue;

                    for (var i = 0; i < mutation.addedNodes.length; i++) {
                        var nodeDescription = mutation.addedNodes[i];

                        if (target.innerHTML === nodeDescription.value) {
                            continue;
                        }

                        var newNode = stringToNode(nodeDescription.value);

                        if (newNode.nodeType === 1) {
                            if (nodeDescription.nextElementSiblingSelector) {
                                target.insertBefore(newNode,
                                    document.querySelector(nodeDescription.nextElementSiblingSelector));
                            } else {
                                if (nodeDescription.previousElementSiblingSelector) {
                                    var previousElementSibling =
                                        document.querySelector(nodeDescription.previousElementSiblingSelector);
                                    if (!previousElementSibling) continue;

                                    if (previousElementSibling.nextSibling) {
                                        target.insertBefore(newNode, previousElementSibling.nextSibling);
                                    } else {
                                        target.appendChild(newNode);
                                    }
                                } else {
                                    target.appendChild(newNode);
                                }
                            }
                        }

                        if (newNode.nodeType === 3) {
                            target.innerHTML = nodeDescription.value;
                        }
                    }

                    break;
            }
        }
    } catch (error) {
        window.external.LogMutationError(JSON.stringify(error));
    }
}

CatiMonitoringView.prototype.setAnswer = function (data) {
    MutationHandler(JSON.parse(data));
}

// We should create dummy Confirmit object for not responsive survey to support 
// a calling of Confirmit.page.catiMonitoringView.setAnswer function from C# code;
if (!window.Confirmit) {
    window.Confirmit = { page: {} };
}

Confirmit.page.catiMonitoringView = new CatiMonitoringView();