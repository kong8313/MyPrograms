﻿namespace Confirmit.CATI.Console.Views.Forms
{
    partial class ChangePasswordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timerCheckPassword = new System.Windows.Forms.Timer(this.components);
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.btnChange = new System.Windows.Forms.Button();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.llCancel = new System.Windows.Forms.LinkLabel();
            this.tbCompany = new System.Windows.Forms.TextBox();
            this.tbUser = new System.Windows.Forms.TextBox();
            this.panelWrongPasswordConfirmation = new System.Windows.Forms.Panel();
            this.tbNewPassword = new System.Windows.Forms.TextBox();
            this.tbConfirmPassword = new System.Windows.Forms.TextBox();
            this.tbOldPassword = new System.Windows.Forms.TextBox();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // timerCheckPassword
            // 
            this.timerCheckPassword.Interval = 750;
            this.timerCheckPassword.Tick += new System.EventHandler(this.timerCheckPassword_Tick);
            // 
            // btnChange
            // 
            this.btnChange.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnChange.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChange.FlatAppearance.BorderSize = 0;
            this.btnChange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChange.ForeColor = System.Drawing.Color.Transparent;
            this.btnChange.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.change_pwd_button;
            this.btnChange.Location = new System.Drawing.Point(39, 368);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(122, 37);
            this.btnChange.TabIndex = 8;
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.Transparent;
            this.pnlMain.BackgroundImage = global::Confirmit.CATI.Console.Views.Properties.Resources.change_pwd;
            this.pnlMain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnlMain.Controls.Add(this.llCancel);
            this.pnlMain.Controls.Add(this.tbCompany);
            this.pnlMain.Controls.Add(this.tbUser);
            this.pnlMain.Controls.Add(this.panelWrongPasswordConfirmation);
            this.pnlMain.Controls.Add(this.tbNewPassword);
            this.pnlMain.Controls.Add(this.tbConfirmPassword);
            this.pnlMain.Controls.Add(this.tbOldPassword);
            this.pnlMain.Controls.Add(this.btnChange);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(490, 447);
            this.pnlMain.TabIndex = 6;
            // 
            // llCancel
            // 
            this.llCancel.AutoSize = true;
            this.llCancel.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llCancel.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llCancel.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(140)))), ((int)(((byte)(215)))));
            this.llCancel.Location = new System.Drawing.Point(185, 378);
            this.llCancel.Name = "llCancel";
            this.llCancel.Size = new System.Drawing.Size(54, 17);
            this.llCancel.TabIndex = 9;
            this.llCancel.TabStop = true;
            this.llCancel.Text = "Cancel";
            this.llCancel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.llCancel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llCancel_LinkClicked);
            // 
            // tbCompany
            // 
            this.tbCompany.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbCompany.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tbCompany.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.tbCompany.Location = new System.Drawing.Point(52, 334);
            this.tbCompany.Name = "tbCompany";
            this.tbCompany.Size = new System.Drawing.Size(385, 20);
            this.tbCompany.TabIndex = 7;
            // 
            // tbUser
            // 
            this.tbUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbUser.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tbUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.tbUser.Location = new System.Drawing.Point(52, 153);
            this.tbUser.Name = "tbUser";
            this.tbUser.Size = new System.Drawing.Size(385, 20);
            this.tbUser.TabIndex = 1;
            // 
            // panelWrongPasswordConfirmation
            // 
            this.panelWrongPasswordConfirmation.BackgroundImage = global::Confirmit.CATI.Console.Views.Properties.Resources.refuse;
            this.panelWrongPasswordConfirmation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panelWrongPasswordConfirmation.Location = new System.Drawing.Point(458, 287);
            this.panelWrongPasswordConfirmation.Name = "panelWrongPasswordConfirmation";
            this.panelWrongPasswordConfirmation.Size = new System.Drawing.Size(20, 20);
            this.panelWrongPasswordConfirmation.TabIndex = 7;
            this.panelWrongPasswordConfirmation.Visible = false;
            this.panelWrongPasswordConfirmation.MouseEnter += new System.EventHandler(this.panelWrongPasswordConfirmation_MouseEnter);
            this.panelWrongPasswordConfirmation.MouseLeave += new System.EventHandler(this.panelWrongPasswordConfirmation_MouseLeave);
            // 
            // tbNewPassword
            // 
            this.tbNewPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbNewPassword.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tbNewPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.tbNewPassword.Location = new System.Drawing.Point(52, 243);
            this.tbNewPassword.Name = "tbNewPassword";
            this.tbNewPassword.Size = new System.Drawing.Size(385, 20);
            this.tbNewPassword.TabIndex = 4;
            this.tbNewPassword.UseSystemPasswordChar = true;
            this.tbNewPassword.TextChanged += new System.EventHandler(this.tbPassword_TextChanged);
            // 
            // tbConfirmPassword
            // 
            this.tbConfirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbConfirmPassword.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tbConfirmPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.tbConfirmPassword.Location = new System.Drawing.Point(52, 288);
            this.tbConfirmPassword.Name = "tbConfirmPassword";
            this.tbConfirmPassword.Size = new System.Drawing.Size(385, 20);
            this.tbConfirmPassword.TabIndex = 6;
            this.tbConfirmPassword.UseSystemPasswordChar = true;
            this.tbConfirmPassword.TextChanged += new System.EventHandler(this.tbPassword_TextChanged);
            // 
            // tbOldPassword
            // 
            this.tbOldPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbOldPassword.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tbOldPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.tbOldPassword.Location = new System.Drawing.Point(52, 198);
            this.tbOldPassword.Name = "tbOldPassword";
            this.tbOldPassword.Size = new System.Drawing.Size(385, 20);
            this.tbOldPassword.TabIndex = 2;
            this.tbOldPassword.UseSystemPasswordChar = true;
            // 
            // ChangePasswordForm
            // 
            this.AcceptButton = this.btnChange;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(490, 447);
            this.Controls.Add(this.pnlMain);
            this.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ChangePasswordForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Password changing";
            this.Shown += new System.EventHandler(this.ChangePasswordForm_Shown);
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.TextBox tbNewPassword;
        private System.Windows.Forms.TextBox tbOldPassword;
        private System.Windows.Forms.TextBox tbConfirmPassword;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.Panel panelWrongPasswordConfirmation;
        private System.Windows.Forms.Timer timerCheckPassword;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.TextBox tbUser;
        private System.Windows.Forms.TextBox tbCompany;
        private System.Windows.Forms.LinkLabel llCancel;
    }
}