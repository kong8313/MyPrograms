﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.Classes.StatusBar;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Controls
{
    public partial class StatusBarControl : UserControl, IViewStatusBar
    {
        private Timer m_Timer = null;

        delegate void ModeChangedEventHandler();
        event ModeChangedEventHandler ModeChanged;

        StatusBarModes m_mode = StatusBarModes.LoginView;

        private ToolStripStatusLabel tsslUserName = new ToolStripStatusLabel();
        private ToolStripStatusLabel tsslUserNameLabel = new ToolStripStatusLabel() { Text = "User:" };

        private ToolStripStatusLabel tsslRespondentTime = new ToolStripStatusLabel();
        private ToolStripStatusLabel tsslRespondentTimeLabel = new ToolStripStatusLabel() { Text = "Respondent time:" };

        private ToolStripStatusLabel tsslInterviewerTime = new ToolStripStatusLabel();
        private ToolStripStatusLabel tsslInterviewerTimeLabel = new ToolStripStatusLabel() { Text = "Interviewer time:" };

        private ToolStripStatusLabel tsslSurveyName = new ToolStripStatusLabel();
        private ToolStripStatusLabel tsslSurveyNameLabel = new ToolStripStatusLabel() { Text = "Survey name:" };

        private ToolStripStatusLabel tsslInterviewName = new ToolStripStatusLabel();
        private ToolStripStatusLabel tsslInterviewNameLabel = new ToolStripStatusLabel() { Text = "Interview id:" };

        private ToolStripStatusLabel tsslQuestionName = new ToolStripStatusLabel();
        private ToolStripStatusLabel tsslQuestionNameLabel = new ToolStripStatusLabel() { Text = "Question name:" };

        private ToolStripStatusLabel tsslCurrentStateName = new ToolStripStatusLabel();
        private ToolStripStatusLabel tsslCurrentStateLabel = new ToolStripStatusLabel() { Text = "State:" };

        private ToolStripSeparator tsslInformationSep = new ToolStripSeparator() { Size = new Size(6, 23), Visible = false };
        private ToolStripStatusLabel tsslInformationName = new ToolStripStatusLabel();
        private ToolStripStatusLabel tsslInformationLabel = new ToolStripStatusLabel() { Text = "Information: " };

        private ToolStripSeparator tsslPendingLogoutSep = new ToolStripSeparator() { Size = new Size(6, 23), Visible = false };
        private ToolStripStatusLabel tsslPendingLogoutStateName = new ToolStripStatusLabel() { Visible = false };
        private ToolStripStatusLabel tsslPendingLogoutStateLabel = new ToolStripStatusLabel() { Text = "Pending logout:", Visible = false };

        private ToolStripSeparator tsslPendingBreakSep = new ToolStripSeparator() { Size = new Size(6, 23), Visible = false };
        private ToolStripStatusLabel tsslPendingBreakStateName = new ToolStripStatusLabel() { Visible = false };
        private ToolStripStatusLabel tsslPendingBreakStateLabel = new ToolStripStatusLabel() { Text = "Pending break:", Visible = false };

        private ToolStripStatusLabel tsslVersion = new ToolStripStatusLabel();
        private ToolStripStatusLabel tsslVersionLabel = new ToolStripStatusLabel() { Text = "Version:" };

        private ToolTip tooltip = new ToolTip();
        private string tooltipText = "";
        private bool showConnectionQualityIndicator = true;
        private ToolStripSeparator tsslConnectionQualitySep = new ToolStripSeparator { Size = new Size(6, 23), Visible = true };
        private ToolStripStatusLabel tsslConnectionQuality = new ToolStripStatusLabel
        {
            Image = Properties.Resources.good_connection
        };

        private ToolStripSeparator tsslCurrentPositionSep = new ToolStripSeparator() { Size = new Size(6, 23), Visible = false };
        private ToolStripStatusLabel tsslCurrentPosition = new ToolStripStatusLabel();
        private ToolStripStatusLabel tsslCurrentPositionLabel = new ToolStripStatusLabel() { Text = "Position:" };

        public StatusBarControl()
        {
            InitializeComponent();
            ModeChanged += new ModeChangedEventHandler(StatusBarControl_ModeChanged);

            tsslConnectionQuality.MouseHover += TsslConnectionQuality_MouseHover;
            tsslConnectionQuality.MouseLeave += TsslConnectionQuality_MouseLeave;

            Init();
        }

        private void TsslConnectionQuality_MouseHover(object sender, EventArgs e)
        {
            tooltip.Show(tooltipText, statusStrip,
                new Point(tsslConnectionQuality.Bounds.Right,
                    tsslConnectionQuality.Bounds.Top - 10));
        }

        private void TsslConnectionQuality_MouseLeave(object sender, EventArgs e)
        {
            tooltip.Hide(statusStrip);
        }

        void StatusBarControl_ModeChanged()
        {
            Init();
        }

        #region IViewStatusBar Members

        /// <summary>
        /// Current status bar mode
        /// There are two mode: Interviewing and MainView
        /// </summary>
        public StatusBarModes Mode
        {
            get
            {
                return m_mode;
            }
            set
            {
                if (m_mode != value)
                {
                    m_mode = value;
                    ModeChanged();
                }
            }
        }

        /// <summary>
        /// Set current user name
        /// </summary>
        public string UserName
        {
            get
            {
                return tsslUserName.Text;
            }
            set
            {
                tsslUserName.Text = value;
            }
        }

        /// <summary>
        /// Respondent time.
        /// </summary>
        public string RespondentTime
        {
            get
            {
                return tsslRespondentTime.Text;
            }
            set
            {
                tsslRespondentTime.Text = value;
            }
        }

        /// <summary>
        /// Interviewer time.
        /// </summary>
        public string InterviewerTime
        {
            get
            {
                return tsslInterviewerTime.Text;
            }
            set
            {
                tsslInterviewerTime.Text = value;
            }
        }

        /// <summary>
        /// Set or get survey name
        /// </summary>
        public string SurveyName
        {
            get { return tsslSurveyName.Text; }
            set
            {
                tsslSurveyName.Text = value;
            }
        }

        public void HighlightSurvey(bool isNewSurvey)
        {
            tsslSurveyName.ResetForeColor();
            tsslSurveyName.ForeColor = isNewSurvey ? Color.Green : Color.Empty;

            tsslSurveyName.Font = isNewSurvey ?
                new Font(tsslSurveyName.Font, FontStyle.Bold) :
                new Font(tsslSurveyName.Font, FontStyle.Regular);
        }

        public void UpdateConnectionIndicator(Bitmap image, string tooltip)
        {
            tsslConnectionQuality.Image = image;
            tooltipText = tooltip;
        }

        public void HideAndNeverShowConnectionIndicator()
        {
            showConnectionQualityIndicator = false;

            statusStrip.Items.Remove(tsslConnectionQuality);
            statusStrip.Items.Remove(tsslConnectionQualitySep);
        }

        /// <summary>
        /// Set or get interview name that is displayed in status bar
        /// </summary>
        public string InterviewName
        {
            get { return tsslInterviewName.Text; }
            set
            {
                tsslInterviewName.Text = value;
            }
        }

        /// <summary>
        /// Sets pending logout state in status bar
        /// </summary>
        public string PendingLogoutState
        {
            set
            {
                if (!String.IsNullOrEmpty(value))
                {
                    tsslPendingLogoutStateName.Text = value;
                    tsslPendingLogoutSep.Visible = true;
                    tsslPendingLogoutStateName.Visible = true;
                    tsslPendingLogoutStateLabel.Visible = true;
                }
                else
                {
                    tsslPendingLogoutSep.Visible = false;
                    tsslPendingLogoutStateName.Visible = false;
                    tsslPendingLogoutStateLabel.Visible = false;
                }
            }
        }
        
        /// <summary>
        /// Sets informatin in status bar
        /// </summary>
        public string Information
        {
            set
            {
                if (!String.IsNullOrEmpty(value))
                {
                    tsslInformationName.Text = value;
                    tsslInformationSep.Visible = true;
                    tsslInformationName.Visible = true;
                    tsslInformationLabel.Visible = true;
                }
                else
                {
                    tsslInformationSep.Visible = false;
                    tsslInformationName.Visible = false;
                    tsslInformationLabel.Visible = false;
                }
            }
        }

        /// <summary>
        /// Sets pending break state in status bar.
        /// </summary>
        public string PendingBreakState
        {
            set
            {
                if (!String.IsNullOrEmpty(value))
                {
                    tsslPendingBreakStateName.Text = value;
                    tsslPendingBreakSep.Visible = true;
                    tsslPendingBreakStateName.Visible = true;
                    tsslPendingBreakStateLabel.Visible = true;
                }
                else
                {
                    tsslPendingBreakSep.Visible = false;
                    tsslPendingBreakStateName.Visible = false;
                    tsslPendingBreakStateLabel.Visible = false;
                }
            }
        }

        /// <summary>
        /// Set or get question name that is displayed in status bar
        /// </summary>
        public string QuestionName
        {
            get { return tsslQuestionName.Text; }
            set
            {
                if (!String.IsNullOrEmpty(value))
                {
                    tsslQuestionName.Text = value;
                    tsslQuestionName.Visible = true;
                    tsslQuestionNameLabel.Visible = true;
                }
                else
                {
                    tsslQuestionName.Visible = false;
                    tsslQuestionNameLabel.Visible = false;
                }
            }
        }

        /// <summary>
        /// Set or get current position information that is displayed in status bar
        /// </summary>
        public string CurrentPosition
        {
            get { return tsslCurrentPosition.Text; }
            set
            {
                if (!String.IsNullOrEmpty(value))
                {
                    tsslCurrentPosition.Text = value;
                    tsslCurrentPosition.Visible = true;
                    tsslCurrentPositionLabel.Visible = true;
                    tsslCurrentPositionSep.Visible = true;
                }
                else
                {
                    tsslCurrentPosition.Visible = false;
                    tsslCurrentPositionLabel.Visible = false;
                    tsslCurrentPositionSep.Visible = false;
                }
            }
        }

        /// <summary>
        /// Gets/sets current interview state that is displayed in status bar
        /// </summary>
        public string CurrentState
        {
            get { return tsslCurrentStateName.Text; }
            set
            {
                tsslCurrentStateName.ForeColor = Color.Black;
                tsslCurrentStateName.Text = value;
            }
        }

        /// <summary>
        /// Gets/sets current interview state that is displayed in status bar
        /// </summary>
        /// <param name="state">state that is displayed in status bar</param>
        /// <param name="color">set the color of the message</param>
        public void SetCurrentState(string state, Color? color = null)
        {
            tsslCurrentStateName.ForeColor = color ?? Color.Black;
            tsslCurrentStateName.Text = state;
        }

        /// <summary>
        /// Gets/sets console version.
        /// </summary>
        public string Version
        {
            get
            {
                return tsslVersion.Text;
            }
            set
            {
                tsslVersion.Text = value;
            }
        }

        /// <summary>
        /// Display information message for specified time
        /// </summary>
        /// <param name="message">message text</param>
        /// <param name="seconds">time for display</param>
        public void ShowInformation(string message, int seconds)
        {
            ShowInformation(message);

            StartTimer(seconds);
        }

        /// <summary>
        /// Display message in status bar.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="color"></param>
        public void ShowInformation(string message, Color? color = null)
        {
            if (m_Timer != null)
            {
                StopTimer();
            }

            tsslInformationName.ForeColor = color ?? Color.Black;
            Information = message;
        }

        /// <summary>
        /// Removes informatiion message from status bar.
        /// </summary>
        public void ClearInformation()
        {
            Information = null;
        }

        void m_timer_Tick(object sender, EventArgs e)
        {
            StopTimer();
            ClearInformation();
        }

        #endregion

        /// <summary>
        /// Add labels depending current status bar mode
        /// </summary>
        private void Init()
        {
            statusStrip.Items.Clear();

            if (Mode != StatusBarModes.LoginView)
            {
                statusStrip.Items.Add(tsslUserNameLabel);
                statusStrip.Items.Add(tsslUserName);
            }

            if (Mode == StatusBarModes.Interviewing)
            {
                statusStrip.Items.Add(GetSeparator());
                statusStrip.Items.Add(tsslRespondentTimeLabel);
                statusStrip.Items.Add(tsslRespondentTime);
                statusStrip.Items.Add(GetSeparator());
                statusStrip.Items.Add(tsslInterviewerTimeLabel);
                statusStrip.Items.Add(tsslInterviewerTime);
                statusStrip.Items.Add(GetSeparator());
                statusStrip.Items.Add(tsslSurveyNameLabel);
                statusStrip.Items.Add(tsslSurveyName);
                statusStrip.Items.Add(GetSeparator());
                statusStrip.Items.Add(tsslInterviewNameLabel);
                statusStrip.Items.Add(tsslInterviewName);
            }
            else if (Mode == StatusBarModes.Reviewing)
            {
                statusStrip.Items.Add(GetSeparator());
                statusStrip.Items.Add(tsslSurveyNameLabel);
                statusStrip.Items.Add(tsslSurveyName);
                statusStrip.Items.Add(GetSeparator());
                statusStrip.Items.Add(tsslInterviewNameLabel);
                statusStrip.Items.Add(tsslInterviewName);
                statusStrip.Items.Add(GetSeparator());
                statusStrip.Items.Add(tsslCurrentStateLabel);
                statusStrip.Items.Add(tsslCurrentStateName);
            }
            else if (Mode == StatusBarModes.MainViewPlayer)
            {
                statusStrip.Items.Add(GetSeparator());
                statusStrip.Items.Add(tsslSurveyNameLabel);
                statusStrip.Items.Add(tsslSurveyName);

                statusStrip.Items.Add(GetSeparator());
                statusStrip.Items.Add(tsslInterviewNameLabel);
                statusStrip.Items.Add(tsslInterviewName);

                statusStrip.Items.Add(tsslCurrentPositionSep);
                statusStrip.Items.Add(tsslCurrentPositionLabel);
                statusStrip.Items.Add(tsslCurrentPosition);

                statusStrip.Items.Add(GetSeparator());
                statusStrip.Items.Add(tsslCurrentStateLabel);
                statusStrip.Items.Add(tsslCurrentStateName);

                statusStrip.Items.Add(tsslPendingLogoutSep);
                statusStrip.Items.Add(tsslPendingLogoutStateLabel);
                statusStrip.Items.Add(tsslPendingLogoutStateName);

                statusStrip.Items.Add(tsslPendingBreakSep);
                statusStrip.Items.Add(tsslPendingBreakStateLabel);
                statusStrip.Items.Add(tsslPendingBreakStateName);

                statusStrip.Items.Add(tsslInformationSep);
                statusStrip.Items.Add(tsslInformationLabel);
                statusStrip.Items.Add(tsslInformationName);
            }

            // adding version info at the right
            if (Mode != StatusBarModes.LoginView)
            {
                AddVersionBar();

                AddConnectionQualityIndicator();
            }

            foreach (ToolStripItem item in statusStrip.Items)
                item.TextAlign = ContentAlignment.MiddleLeft;

            tsslCurrentStateName.Font = new System.Drawing.Font("Tahoma", 11F, FontStyle.Bold, GraphicsUnit.Pixel);
        }

        private void AddConnectionQualityIndicator()
        {
            if (showConnectionQualityIndicator)
            {
                statusStrip.Items.Add(tsslConnectionQualitySep);
                statusStrip.Items.Add(tsslConnectionQuality);
            }
        }

        /// <summary>
        /// Return new separator object
        /// </summary>
        /// <returns></returns>
        private ToolStripSeparator GetSeparator()
        {
            ToolStripSeparator sep = new ToolStripSeparator();
            sep.Size = new Size(6, 23);
            return sep;
        }

        /// <summary>
        /// Adds status bar controls which are used for showing vaersion info.
        /// </summary>
        private void AddVersionBar()
        {
            // adding "spring" control to place version at right side
            statusStrip.Items.Add(new ToolStripStatusLabel { Spring = true });
            statusStrip.Items.Add(tsslVersionLabel);
            statusStrip.Items.Add(tsslVersion);
        }

        /// <summary>
        /// Initialiazes and starts information timer.
        /// </summary>
        /// <param name="seconds"></param>
        private void StartTimer(int seconds)
        {
            m_Timer = new Timer() { Interval = seconds * 500 };
            m_Timer.Tick += new EventHandler(m_timer_Tick);
            m_Timer.Start();
        }

        /// <summary>
        /// Stops information timer.
        /// </summary>
        private void StopTimer()
        {
            m_Timer.Stop();
            m_Timer = null;
        }

        #region ILocalizableView Members

        public void Localize(ILocalizationManager manager)
        {
            tsslUserNameLabel.Text = String.Format("{0}:", manager.GetString("StatusBar_UserLabel_Text"));
            tsslRespondentTimeLabel.Text = String.Format("{0}:", manager.GetString("StatusBar_RespondentTime_Text"));
            tsslInterviewerTimeLabel.Text = String.Format("{0}:", manager.GetString("StatusBar_InterviewerTime_Text"));
            tsslSurveyNameLabel.Text = String.Format("{0}:", manager.GetString("StatusBar_SurveyName_Text"));
            tsslInterviewNameLabel.Text = String.Format("{0}:", manager.GetString("StatusBar_InterviewName_Text"));
            tsslQuestionNameLabel.Text = String.Format("{0}:", manager.GetString("StatusBar_QuestionName_Text"));
            tsslCurrentStateLabel.Text = String.Format("{0}:", manager.GetString("StatusBar_State_Text"));
            tsslInformationLabel.Text = String.Format("{0}:", manager.GetString("StatusBar_Information_Text"));
            tsslPendingLogoutStateLabel.Text = String.Format("{0}:", manager.GetString("StatusBar_PendingLogoutState_Text"));
            tsslVersionLabel.Text = String.Format("{0}:", manager.GetString("StatusBar_Version_Text"));
            tooltipText = manager.GetString("StatusBarControl_ConnectionQuality_Good_ToolTipText");
        }

        #endregion
    }
}
