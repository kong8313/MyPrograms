﻿using System;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    public class QuestionSelectedEventArgs : EventArgs
    {
        public string QuestionId
        {
            get;
            set;
        }

        public string QuestionTitle
        {
            get;
            set;
        }

        public string QuestionText
        {
            get;
            set;
        }

        public int QuestionIndex
        {
            get;
            set;
        }

        public int SubQuestionIndex
        {
            get;
            set;
        }

        public  bool IsSubQuestion { get; set; }

        public QuestionType QuestionType { get; set; }
    }
}
