﻿var CatiPageView = function (responsiveApiObject) {
    this._currentQuestionIndex = null;
    this.subquestions = {};
    this.currentSubquestionIndex = null;

    this._currentQuestionClass = "cf-question--current-cati";
    this._currentSubquestionClass = "cf-grid-layout__row--current-cati";
    this._gridRowClass = ".cf-grid-layout__row";

    var getQuestionViews = function() {
        return responsiveApiObject._pageView._questionViews.filter(function(view) {
            return view._question.type !== "Info" && view._question.type !== "GeoLocation";
        });
    }.bind(this);

    this._questionViews = getQuestionViews();
    this.questionsViewsCount = this._questionViews.length;

    this.isLastSubquestion = function () {
        var rows = this.getCurrentQuestionRows();
        return rows === null ||
            rows.length === 0 ||
            this.currentSubquestionIndex === null ||
            this.currentSubquestionIndex === rows.length - 1;
    }.bind(this);

    this.questions = responsiveApiObject.page.questions;
    this._pageView = responsiveApiObject._pageView;
    this.getQuestion = responsiveApiObject.page.getQuestion;

    subscribeElementsOnClick.call(this);

    responsiveApiObject.page.dynamicQuestionsChangeCompleteEvent.on(function () {
        setTimeout(function () {
            this._questionViews = getQuestionViews();
            this.questionsViewsCount = this._questionViews.length;
            subscribeElementsOnClick.call(this);
        }.bind(this), 0);
    }.bind(this));
};

var subscribeElementsOnClick = function () {
    this._questionViews.forEach(function (view, index) {
        var container = this.getContainer(view);
        var rows = container.find(this._gridRowClass).filter(function (i, r) { return r.id; });

        container[0].onclick = function () {
            if (this.doQuestion(index)) {
                this.doNextSubquestion();
            }
        }.bind(this);

        if (rows.length > 0) {
            for (var j = 0; j < rows.length; j++) {
                rows[j].onclick = function (e) {
                    var currentRowId = 0;

                    for (var i = 0; i < rows.length; i++) {
                        if (e.currentTarget.id === rows[i].id) {
                            currentRowId = i;
                            break;
                        }
                    }

                    this.doQuestion(index);
                    this.doSubquestion(currentRowId);
                    e.stopPropagation();

                }.bind(this);
            }
        }
    }.bind(this));
};

CatiPageView.prototype.getCurrentQuestion = function () {
    if (this._currentQuestionIndex != null) {
        var view = this._questionViews[this._currentQuestionIndex];
        return view._question;
    }

    return null;
};

CatiPageView.prototype.getCurrentQuestionId = function () {
    return this.getCurrentQuestion() ? this.getCurrentQuestion().id : "";
};

CatiPageView.prototype.getCurrentQuestionTitle = function () {
    return this.getCurrentQuestion() ? this.getCurrentQuestion().title : "";
};

CatiPageView.prototype.getCurrentQuestionDefaultValue = function () {
    return this.getCurrentQuestion() ? this.getCurrentQuestion().defaultValue : "";
};

CatiPageView.prototype.getCurrentQuestionRefusedValue = function () {
    return this.getCurrentQuestion() ? this.getCurrentQuestion().refusedValue : "";
};

CatiPageView.prototype.getContainer = function (view) {
    return !view._questionContainer ? view._container : view._questionContainer;
};

CatiPageView.prototype.doQuestion = function (index) {
    if (this._currentQuestionIndex === index) {
        return false;
    }

    if (this._currentQuestionIndex != null) {
        this.getContainer(this._questionViews[this._currentQuestionIndex]).removeClass(this._currentQuestionClass);
    }

    this.cleanSubquestions();

    this._currentQuestionIndex = index;
    this.getContainer(this._questionViews[this._currentQuestionIndex]).addClass(this._currentQuestionClass);
    this.getContainer(this._questionViews[this._currentQuestionIndex])[0].scrollIntoView();
    var question = this._questionViews[this._currentQuestionIndex]._question;

    window.external.OnResponsiveQuestionSelected(question.id, question.type, question.text, question.title, index, 0);

    return true;
};

CatiPageView.prototype.doNextQuestion = function () {
    if (this.doNextSubquestion()) return;
    if (this._currentQuestionIndex < this.questionsViewsCount - 1) {
        this.doQuestion(this._currentQuestionIndex + 1);
        this.doNextSubquestion();
    }
};

CatiPageView.prototype.doPreviousQuestion = function () {
    if (this.doPreviousSubquestion()) return;
    if (this._currentQuestionIndex > 0) {
        this.doQuestion(this._currentQuestionIndex - 1);
        this.doNextSubquestion();
    }
};

CatiPageView.prototype.doLastQuestion = function () {
    this.doQuestion(this.questionsViewsCount - 1);
    this.doNextSubquestion();
};

CatiPageView.prototype.doFirstQuestion = function () {
    this.doQuestion(0);
    this.doNextSubquestion();
};

CatiPageView.prototype.hasOpenEndQuestion = function () {
    var hasOpenQuestions = this.questions
        .filter(function (q) {
            return q.type === "OpenText" || q.type === "Date" || q.type === "OpenTextList";
        }).length > 0;

    var hasOtherQuestions = this.questions
        .filter(function (q) {
            return ((q.type === "Grid3d" || q.type === "Grid" || q.type === "Multi") && Object.keys(q.otherValues).length > 0)
                || (q.type === "Single" && q.otherValue);
        }).length > 0;

    return hasOpenQuestions || hasOtherQuestions;
};

CatiPageView.prototype.setDefaultActiveQuestion = function () {
    if (!this.shouldHighlightQuestion()) {
        return;
    }

    this.doQuestion(0);
    this.doNextSubquestion();
};

CatiPageView.prototype.shouldHighlightQuestion = function () {
    return this.questionsViewsCount !== 0;
};

CatiPageView.prototype.doNextSubquestion = function () {
    var rows = this.getCurrentQuestionRows();
    if (rows && rows.length > 0) {
        var keys = Object.keys(this.subquestions);
        if (keys.length > 0 && this.currentSubquestionIndex != null) {
            var newSubquestionIndex = this.currentSubquestionIndex + 1;
            if (newSubquestionIndex > (rows.length - 1)) return false;

            this.doSubquestion(newSubquestionIndex);
            return true;
        }
        else {
            this.doFirstSubquestion();
        }

        return true;
    } else {
        return false;
    }
};

CatiPageView.prototype.doPreviousSubquestion = function () {
    var rows = this.getCurrentQuestionRows();
    if (rows && rows.length > 0) {
        var keys = Object.keys(this.subquestions);
        if (keys.length > 0 && this.currentSubquestionIndex != null) {
            var newSubquestionIndex = this.currentSubquestionIndex - 1;
            if (newSubquestionIndex < 0) return false;

            this.doSubquestion(newSubquestionIndex);
            return true;
        }
        else {
            this.doLastSubquestion();
        }

        return true;
    } else {
        return false;
    }
};

CatiPageView.prototype.getCurrentQuestionRows = function () {
    if (this._currentQuestionIndex != null) {
        var view = this._questionViews[this._currentQuestionIndex];
        var questionId = view._question.id;
        return this.getContainer(view).find('.cf-grid-layout__row[id*="' + questionId + '_"]');
    }

    return null;
};

CatiPageView.prototype.doFirstSubquestion = function () {
    this.doSubquestion(0);
};

CatiPageView.prototype.doLastSubquestion = function () {
    var rows = this.getCurrentQuestionRows();
    if (rows && rows.length > 0) {
        this.doSubquestion(rows.length - 1);
    }
};

CatiPageView.prototype.doSubquestion = function (index) {
    var rows = this.getCurrentQuestionRows();
    var questionId = this.getCurrentQuestionId();

    if (!rows || rows.length == 0) {
        return;
    }

    var subquestionElement = rows[index];

    if (this.subquestions[questionId] === subquestionElement.id) {
        return;
    }

    this.setSubquestion(questionId, subquestionElement, index);

    var question = this.getQuestion(questionId);
    switch (question.type) {
        case "Grid":
        case "Grid3d":
        case "NumericList":
        case "OpenTextList":
        case "GridBars":
        case "StarRating":
        case "HorizontalRatingScaleGrid":
            window.external.OnResponsiveQuestionSelected(question.id, question.type, question.text, question.title, this._currentQuestionIndex, index);
            break;
        default:
            window.external.OnResponsiveSubQuestionSelected(this._currentQuestionIndex, index);
    }
};

CatiPageView.prototype.cleanSubquestions = function () {
    this.subquestions = {};
    this.currentSubquestionIndex = null;
    this._pageView._pageForm.parent().find(this._gridRowClass).removeClass(this._currentSubquestionClass);
};

CatiPageView.prototype.setSubquestion = function (questionId, element, index) {
    if (element && element.id) {
        this.cleanSubquestions();
        this.currentSubquestionIndex = index;

        this.subquestions[questionId] = element.id;
        element.className += (" " + this._currentSubquestionClass);
        element.scrollIntoView();
    }
};

CatiPageView.prototype.isCurrentQuestionLast = function () {
    return (this._currentQuestionIndex != null &&
        this._currentQuestionIndex === (this.questionsViewsCount - 1) &&
        this.isLastSubquestion())
        || this._questionViews.length === 0;
};

CatiPageView.prototype.hasCurrentQuestionAnswersWithFocusedOtherField = function () {
    var view = this._questionViews[this._currentQuestionIndex];
    if (!document.activeElement || !document.activeElement.id) return false;
    return this.getContainer(view).find("#" + document.activeElement.id).length === 1;
};

CatiPageView.prototype.getTextInputOfCurrentQuestion = function () {
    var view = this._questionViews[this._currentQuestionIndex];

    var elements;
    var keys = Object.keys(this.subquestions);

    var container = this.getContainer(view);

    if (keys.length > 0 && view._question.type !== "Grid3d") {
        var subquestion = this.subquestions[keys[0]];
        container = this.getContainer(view).find("#" + subquestion).first();
    }

    elements = container.find("input[type=text],input[type=number],textarea");

    elements = elements.filter(function (i, e) {
        if (!e.id) return false;
        var splittedId = e.id.split("_");
        if (splittedId.length === 2 || splittedId.length === 3 && splittedId[2] !== "other") return true;
        return false;
    });

    if (elements.length === 0) return null;

    return elements.first();
}

CatiPageView.prototype.focusOpenText = function () {
    var currentInput = this.getTextInputOfCurrentQuestion();

    if (currentInput) {
        currentInput.focus();
    }
}

CatiPageView.prototype.focusOnOtherIfExists = function (answers, code, fieldName) {
    if (!answers) return;

    var filtered = answers.filter(function (x) {
        return x.code === code || x.fieldName === fieldName;
    });
    if (filtered.length === 1) {
        var answer = filtered[0];
        if (answer.isOther) {
            var element = this._pageView._pageForm.parent().find("#" + answer.otherFieldName);
            element.first().focus();
            return false;
        }
    }
    return true;
};

CatiPageView.prototype.setValues = function (value) {
    var questionId = this.getCurrentQuestionId();
    var question = this.getQuestion(questionId);

    var includesCommas = value.includes(",");

    if (!includesCommas) {
        this.setValue(value);
        return;
    }

    var splitted = value.split(",");

    switch (question.type) {
        case "Single":
        case "Multi":
        case "Ranking":
        case "Grid3d":
        case "Grid":
        case "GridBars":
        case "StarRating":
        case "HorizontalRatingScaleGrid":
            splitted.forEach(function (answer) {
                this.setValue(answer, true);
            }.bind(this));
            break;
        default:
            this.setValue(value);
    }
};

CatiPageView.prototype.setValue = function (value, ignoreOther) {
    if (typeof ignoreOther === "undefined") ignoreOther = false;

    var questionId = this.getCurrentQuestionId();
    var splitted;
    var question = this.getQuestion(questionId);

    var currentInput = this.getTextInputOfCurrentQuestion();

    if (currentInput) {
        window.handleMutation({ type: "input", target: currentInput[0] });
    }

    var alreadySelected = false;
    // subquestion focused
    var keys = Object.keys(this.subquestions);
    if (keys.length > 0) {
        var rowId = keys[0];
        var subquestion = this.subquestions[rowId];

        splitted = subquestion.split("_");
        if (splitted.length === 2) {
            switch (question.type) {
                case "Grid3d":
                    var innerQuestion = question.getInnerQuestion(subquestion);
                    for (var i in innerQuestion.values) {
                        if (innerQuestion.values[i] === value) {
                            alreadySelected = true;
                        }
                    }

                    innerQuestion.setValue(value, !alreadySelected);
                    if (!alreadySelected) {
                        !ignoreOther && this.focusOnOtherIfExists(innerQuestion.answers, value);
                    }
                    break;
                case "Grid":
                case "NumericList":
                case "OpenTextList":
                case "GridBars":
                case "StarRating":
                case "HorizontalRatingScaleGrid":
                    question.setValue(splitted[1], value);
                    return !ignoreOther && this.focusOnOtherIfExists(question.answers, null, subquestion);
                default:
                    question.setValue(splitted[1], value);
                    return !ignoreOther && this.focusOnOtherIfExists(question.answers, value);
            }
        }
        return false;
    }

    // switch questions type and set value
    switch (question.type) {
        case "Multi":
            for (var i in question.values) {
                if (question.values[i] === value) {
                    alreadySelected = true;
                }
            }
            question.setValue(value, !alreadySelected);
            if (!alreadySelected) {
                return !ignoreOther && this.focusOnOtherIfExists(question.answers, value);
            }
            break;
        case "Ranking":
            var selectedCount = Object.keys(question.values).length;
            for (var i in question.values) {
                if (i === value) {
                    alreadySelected = true;
                }
            }
            question.setValue(value, alreadySelected ? null : (selectedCount + 1));
            if (!alreadySelected) {
                return !ignoreOther && this.focusOnOtherIfExists(question.answers, value);
            }
            break;
        default:
            question.setValue(value);
            return !ignoreOther && this.focusOnOtherIfExists(question.answers, value);
    }

    return false;
};

Confirmit.page.catiPageView = new CatiPageView(Confirmit);