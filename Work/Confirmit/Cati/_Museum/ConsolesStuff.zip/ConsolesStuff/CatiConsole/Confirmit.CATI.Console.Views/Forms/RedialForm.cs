﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
    public partial class RedialForm : Form, IViewRedialForm
    {
        /// <summary>
        /// Occurs when user press any key.
        /// </summary>
        public event EventHandler<ProcessCmdKeyEventArgs> FormProcessCmdKey;

        private readonly SynchronizationContext _synchronizationContext;

        public string DialingMessage { get; set; }

        public string HangupDialingMessage { get; set; }

        public RedialForm()
        {
            InitializeComponent();

            _synchronizationContext = SynchronizationContext.Current;

            InitializeControls();

            InitializeErrorProviders();

            HandleDestroyed += RedialForm_HandleDestroyed;
        }

        private void InitializeControls()
        {
            tlpCallOutcome.Visible = false;
            pclDialing.Visible = false;
            tbDialNumber.Clear();
            rbRedialDefault.Checked = true;

            pclDialing.CancelButton.Click += pclDialing_CancelClick;
        }

        void pclDialing_CancelClick(object sender,EventArgs e)
        {
            if (CancelClick != null)
            {
                CancelClick(this, new DialCancellationEventArgs
                {
                    IsConfirmationDialogRequired = false
                });
                pclDialing.CancelButton.Enabled = false;
                SetProcessMessage(HangupDialingMessage);
            }
        }

        void RedialForm_HandleDestroyed(object sender, EventArgs e)
        {
            OnFormClose(EventArgs.Empty);
        }

        public event EventHandler<DialCancellationEventArgs> CancelClick;

        public bool SuppressFormClosing { get; set; }

        public string DialNumber
        {
            get { return tbDialNumber.Text; }
            set { tbDialNumber.Text = value; }
        }

        public bool RedialNewNumber
        {
            get { return rbRedialNew.Checked; }
            set
            {
                rbRedialDefault.Checked = !value;
                rbRedialNew.Checked = value;

                tbDialNumber.Enabled = rbRedialNew.Checked;
            }
        }

        public bool ShowRedialNewNumber { get; set; }

        public FormCloseReasons FormResult { get; set; }

        public bool IsVisible
        {
            get { return Visible; }
        }

        public bool IsInProgressIndicatorVisible
        {
            get { return pclDialing.Visible; }
        }

        public string LastCallOutcomeName
        {
            get { return lbLastCallOutcomeName.Text; }
        }

        void IViewRedialForm.Show(IWin32Window parent)
        {
            if (!Visible)
            {
                if (!ShowRedialNewNumber)
                {
                    tableLayoutPanel3.Visible = false;
                    tableLayoutPanel1.SetRow(tlpCallOutcome, 1);
                    Height = 133;
                }

                ShowDialog(parent);
            }
        }

        public void Localize(ILocalizationManager manager)
        {
            Text = manager.GetString("RedialForm_Caption");
            rbRedialDefault.Text = manager.GetString("RedialForm_RadioRedialDefault_Text");
            rbRedialNew.Text = manager.GetString("RedialForm_RadioRedialNew_Text");
            lbNote.Text = ShowRedialNewNumber ?
                manager.GetString("RedialForm_LabelNote_Text") :
                manager.GetString("RedialForm_LabelNote_RedailDisabled_Text");
            btnDial.Text = manager.GetString("RedialForm_ButtonOk_Text");
            btnCancel.Text = manager.GetString("RedialForm_ButtonCancel_Text");
            HangupDialingMessage = manager.GetString("RedialForm_HangupDialing_Text");
            DialingMessage = manager.GetString("RedialForm_Dialing_Text");
            SetProcessMessage(DialingMessage);
            pclDialing.CancelButton.Text = manager.GetString("RedialForm_CancelDialButton_Text");
            pclDialing.HintText = manager.GetString("RedialForm_CancelDialHint_Text");
            lbLastCallOutcomeName.Text = manager.GetString("RedialForm_LastCallOutcomeLabel_Text");
        }

        public void SetDialCanellationButtonVisibility(bool isVisible)
        {
            pclDialing.SetDialCancellationButtonVisibility(isVisible);
        }

        public void HangupDialing()
        {
            pclDialing_CancelClick(this, null);
            SetProcessMessage(HangupDialingMessage);
        }

        public void SetProcessMessage(string message)
        {
            pclDialing.ProcessMessage = message;
        }

        public bool IsDialCanellationButtonEnabled
        {
            get
            {
                return pclDialing.CancelButton.Enabled;
            }
            set
            {
                pclDialing.CancelButton.Enabled = value;
            }
        }

        public SynchronizationContext SynchronizationContext
        {
            get { return _synchronizationContext; }
        }

        public event EventHandler<EventArgs> OkClick;

        public event EventHandler<CancelEventArgs> ValidatingDialNumber;

        public event EventHandler<EventArgs> RedialTypeChanged;

        public event EventHandler<EventArgs> RedialNumberChanged;

        public event EventHandler<EventArgs> FormClose;

        public void ShowNonModal(IWin32Window parent)
        {
            if (Visible)
            {
                return;
            }

            InitializeControls();
            FormClosing += OnNonModalFormClosingEventHandler;

            StartPosition = FormStartPosition.Manual;
            var parentForm = (Form)parent;
            Location = new Point(parentForm.Location.X + (parentForm.Width - Width) / 2,
                parentForm.Location.Y + (parentForm.Height - Height) / 2);
            Show(parent);
        }

        private void OnNonModalFormClosingEventHandler(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
                e.Cancel = true;
        }

        public void AlertValidationError(RedialValidationControls control, string message)
        {
            switch (control)
            {
                case RedialValidationControls.DialNumber:
                    erpNumberValidity.SetError(tbDialNumber, message);
                    break;
                default:
                    throw new NotImplementedException();
            }
        }

        public void EnableInputControls(bool enable)
        {
            rbRedialNew.Enabled = enable;
            rbRedialDefault.Enabled = enable;
            btnDial.Enabled = enable;
            btnCancel.Enabled = enable;

            if (rbRedialNew.Checked)
            {
                tbDialNumber.Enabled = enable;
            }
        }

        public void SetDialingInProgressVisibility(bool visible)
        {
            pclDialing.Visible = visible;
        }

        public void HideForm()
        {
            Hide();
        }

        public void ClearValidationErrors()
        {
            erpNumberValidity.SetError(tbDialNumber, String.Empty);
        }

        public override bool ValidateChildren()
        {
            ClearValidationErrors();

            var result = base.ValidateChildren();

            if (!rbRedialNew.Checked) return result;

            var eaDialNumber = new CancelEventArgs();
            OnValidatingDialNumber(eaDialNumber);
            result &= !eaDialNumber.Cancel;

            return result;
        }

        public void NotifyLastCallOutcome(string callOutcome)
        {
            tlpCallOutcome.Visible = true;
            lbLastCallOutcomeName.Text = callOutcome;
        }

        private void OnRedialTypeChanged(object sender, EventArgs e)
        {
            if (RedialTypeChanged != null)
            {
                RedialTypeChanged(sender, e);
            }
        }

        private void OnRedialNumberChanged(object sender, EventArgs e)
        {
            if (RedialNumberChanged != null)
            {
                RedialNumberChanged(sender, e);
            }
        }

        private void OnValidatingDialNumber(CancelEventArgs e)
        {
            if (ValidatingDialNumber != null)
            {
                ValidatingDialNumber(this, e);
            }
        }

        private void OnFormClose(EventArgs e)
        {
            if (FormClose != null)
            {
                FormClose(this, e);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (SuppressFormClosing && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
            }

            base.OnFormClosing(e);
        }

        private void InitializeErrorProviders()
        {
            erpNumberValidity.SetIconAlignment(tbDialNumber, ErrorIconAlignment.MiddleRight);
        }

        private void btnDial_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
            {
                FormResult = FormCloseReasons.Ok;
                OnOkClick(EventArgs.Empty);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            HideForm();
        }

        private void OnOkClick(EventArgs e)
        {
            if (OkClick != null)
            {
                ResetProcessControl();
                OkClick(this, e);
            }
        }

        private void ResetProcessControl()
        {
            pclDialing.CancelButton.Enabled = true;
            SetProcessMessage(DialingMessage);
        }

        private void rbRedialNew_CheckedChanged(object sender, EventArgs e)
        {
            OnRedialTypeChanged(sender, EventArgs.Empty);
            tbDialNumber.Enabled = rbRedialNew.Checked;
        }

        private void tbDialNumber_TextChanged(object sender, EventArgs e)
        {
            OnRedialNumberChanged(sender, EventArgs.Empty);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            ProcessCmdKeyEventArgs eventArgs = new ProcessCmdKeyEventArgs { KeyData = keyData };

            if (FormProcessCmdKey != null)
            {
                OnFormProcessCmdKey(eventArgs);
            }

            if (eventArgs.Cancel)
            {
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void OnFormProcessCmdKey(ProcessCmdKeyEventArgs eventArgs)
        {
            FormProcessCmdKey(this, eventArgs);
        }
    }
}