﻿namespace Confirmit.CATI.Console.Views.Forms
{
	partial class AppointmentForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.lbTitle = new System.Windows.Forms.Label();
            this.ltMain = new System.Windows.Forms.TableLayoutPanel();
            this.ltRadios = new System.Windows.Forms.TableLayoutPanel();
            this.chbLogout = new System.Windows.Forms.CheckBox();
            this.ltButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.lbShowInterviewerAppointmens = new System.Windows.Forms.LinkLabel();
            this.gbEdit = new System.Windows.Forms.GroupBox();
            this.ltInputFields = new System.Windows.Forms.TableLayoutPanel();
            this.dtAppointmentDate = new System.Windows.Forms.DateTimePicker();
            this.dtExpirationDate = new System.Windows.Forms.DateTimePicker();
            this.cbAppointmentTime = new System.Windows.Forms.ComboBox();
            this.cbExpirationTime = new System.Windows.Forms.ComboBox();
            this.lbAppointmentTime = new System.Windows.Forms.Label();
            this.lbExpirationTime = new System.Windows.Forms.Label();
            this.lbAppointmentDate = new System.Windows.Forms.Label();
            this.lbExpirationDate = new System.Windows.Forms.Label();
            this.chbNeverExpire = new System.Windows.Forms.CheckBox();
            this.chbAllowAppOutsideShift = new System.Windows.Forms.CheckBox();
            this.gbTime = new System.Windows.Forms.GroupBox();
            this.lbInterviewerTime = new System.Windows.Forms.Label();
            this.lbInterviewer = new System.Windows.Forms.Label();
            this.lbRespondentTime = new System.Windows.Forms.Label();
            this.lbRespondent = new System.Windows.Forms.Label();
            this.pnlTitle = new System.Windows.Forms.Panel();
            this.lbTitleDescription = new System.Windows.Forms.Label();
            this.pbTitle = new System.Windows.Forms.PictureBox();
            this.erpAppointmentDate = new System.Windows.Forms.ErrorProvider(this.components);
            this.erpAppointmentTime = new System.Windows.Forms.ErrorProvider(this.components);
            this.erpExpirationDate = new System.Windows.Forms.ErrorProvider(this.components);
            this.erpExpirationTime = new System.Windows.Forms.ErrorProvider(this.components);
            this.ltMain.SuspendLayout();
            this.ltRadios.SuspendLayout();
            this.ltButtons.SuspendLayout();
            this.gbEdit.SuspendLayout();
            this.ltInputFields.SuspendLayout();
            this.gbTime.SuspendLayout();
            this.pnlTitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTitle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpAppointmentDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpAppointmentTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpExpirationDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpExpirationTime)).BeginInit();
            this.SuspendLayout();
            // 
            // lbTitle
            // 
            this.lbTitle.AutoSize = true;
            this.lbTitle.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lbTitle.Location = new System.Drawing.Point(12, 4);
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Size = new System.Drawing.Size(105, 13);
            this.lbTitle.TabIndex = 1;
            this.lbTitle.Text = "Edit Appointment";
            // 
            // ltMain
            // 
            this.ltMain.ColumnCount = 1;
            this.ltMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ltMain.Controls.Add(this.ltRadios, 0, 3);
            this.ltMain.Controls.Add(this.ltButtons, 0, 4);
            this.ltMain.Controls.Add(this.gbEdit, 0, 2);
            this.ltMain.Controls.Add(this.gbTime, 0, 1);
            this.ltMain.Controls.Add(this.pnlTitle, 0, 0);
            this.ltMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ltMain.Location = new System.Drawing.Point(0, 0);
            this.ltMain.Name = "ltMain";
            this.ltMain.RowCount = 5;
            this.ltMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.ltMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 47F));
            this.ltMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ltMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ltMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.ltMain.Size = new System.Drawing.Size(438, 326);
            this.ltMain.TabIndex = 0;
            // 
            // ltRadios
            // 
            this.ltRadios.ColumnCount = 1;
            this.ltRadios.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ltRadios.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.ltRadios.Controls.Add(this.chbLogout, 0, 0);
            this.ltRadios.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ltRadios.Location = new System.Drawing.Point(3, 264);
            this.ltRadios.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.ltRadios.Name = "ltRadios";
            this.ltRadios.RowCount = 1;
            this.ltRadios.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ltRadios.Size = new System.Drawing.Size(432, 26);
            this.ltRadios.TabIndex = 3;
            // 
            // chbLogout
            // 
            this.chbLogout.AutoSize = true;
            this.chbLogout.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.chbLogout.Location = new System.Drawing.Point(3, 3);
            this.chbLogout.Name = "chbLogout";
            this.chbLogout.Size = new System.Drawing.Size(62, 17);
            this.chbLogout.TabIndex = 0;
            this.chbLogout.Text = "Log out";
            this.chbLogout.UseVisualStyleBackColor = true;
            this.chbLogout.CheckedChanged += new System.EventHandler(this.chbLogout_CheckedChanged);
            // 
            // ltButtons
            // 
            this.ltButtons.ColumnCount = 3;
            this.ltButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75.07082F));
            this.ltButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.92918F));
            this.ltButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.ltButtons.Controls.Add(this.btnCancel, 2, 0);
            this.ltButtons.Controls.Add(this.btnOk, 1, 0);
            this.ltButtons.Controls.Add(this.lbShowInterviewerAppointmens, 0, 0);
            this.ltButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ltButtons.Location = new System.Drawing.Point(3, 293);
            this.ltButtons.Name = "ltButtons";
            this.ltButtons.RowCount = 1;
            this.ltButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ltButtons.Size = new System.Drawing.Size(432, 30);
            this.ltButtons.TabIndex = 4;
            // 
            // btnCancel
            // 
            this.btnCancel.CausesValidation = false;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnCancel.Location = new System.Drawing.Point(356, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(72, 23);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnOk.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnOk.Location = new System.Drawing.Point(275, 3);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 24);
            this.btnOk.TabIndex = 9;
            this.btnOk.Text = "&Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // lbShowInterviewerAppointmens
            // 
            this.lbShowInterviewerAppointmens.AutoSize = true;
            this.lbShowInterviewerAppointmens.Location = new System.Drawing.Point(3, 3);
            this.lbShowInterviewerAppointmens.Margin = new System.Windows.Forms.Padding(3);
            this.lbShowInterviewerAppointmens.Name = "lbShowInterviewerAppointmens";
            this.lbShowInterviewerAppointmens.Size = new System.Drawing.Size(118, 13);
            this.lbShowInterviewerAppointmens.TabIndex = 11;
            this.lbShowInterviewerAppointmens.TabStop = true;
            this.lbShowInterviewerAppointmens.Text = "Show my appointments";
            this.lbShowInterviewerAppointmens.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbShowInterviewerAppointmens_LinkClicked);
            // 
            // gbEdit
            // 
            this.gbEdit.Controls.Add(this.ltInputFields);
            this.gbEdit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbEdit.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gbEdit.Location = new System.Drawing.Point(3, 108);
            this.gbEdit.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.gbEdit.Name = "gbEdit";
            this.gbEdit.Size = new System.Drawing.Size(432, 156);
            this.gbEdit.TabIndex = 2;
            this.gbEdit.TabStop = false;
            this.gbEdit.Text = "Appointment";
            // 
            // ltInputFields
            // 
            this.ltInputFields.ColumnCount = 4;
            this.ltInputFields.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.04522F));
            this.ltInputFields.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.ltInputFields.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.95478F));
            this.ltInputFields.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 48F));
            this.ltInputFields.Controls.Add(this.dtAppointmentDate, 0, 1);
            this.ltInputFields.Controls.Add(this.dtExpirationDate, 0, 3);
            this.ltInputFields.Controls.Add(this.cbAppointmentTime, 2, 1);
            this.ltInputFields.Controls.Add(this.cbExpirationTime, 2, 3);
            this.ltInputFields.Controls.Add(this.lbAppointmentTime, 2, 0);
            this.ltInputFields.Controls.Add(this.lbExpirationTime, 2, 2);
            this.ltInputFields.Controls.Add(this.lbAppointmentDate, 0, 0);
            this.ltInputFields.Controls.Add(this.lbExpirationDate, 0, 2);
            this.ltInputFields.Controls.Add(this.chbNeverExpire, 0, 4);
            this.ltInputFields.Controls.Add(this.chbAllowAppOutsideShift, 0, 5);
            this.ltInputFields.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ltInputFields.Location = new System.Drawing.Point(3, 17);
            this.ltInputFields.Name = "ltInputFields";
            this.ltInputFields.RowCount = 6;
            this.ltInputFields.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.48249F));
            this.ltInputFields.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.51751F));
            this.ltInputFields.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.48249F));
            this.ltInputFields.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.51751F));
            this.ltInputFields.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.ltInputFields.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.ltInputFields.Size = new System.Drawing.Size(426, 136);
            this.ltInputFields.TabIndex = 1;
            // 
            // dtAppointmentDate
            // 
            this.dtAppointmentDate.Dock = System.Windows.Forms.DockStyle.Top;
            this.dtAppointmentDate.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dtAppointmentDate.Location = new System.Drawing.Point(3, 22);
            this.dtAppointmentDate.Name = "dtAppointmentDate";
            this.dtAppointmentDate.Size = new System.Drawing.Size(255, 21);
            this.dtAppointmentDate.TabIndex = 2;
            this.dtAppointmentDate.Value = new System.DateTime(2008, 5, 30, 0, 0, 0, 0);
            this.dtAppointmentDate.ValueChanged += new System.EventHandler(this.dtAppointmentDate_ValueChanged);
            // 
            // dtExpirationDate
            // 
            this.dtExpirationDate.Dock = System.Windows.Forms.DockStyle.Top;
            this.dtExpirationDate.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dtExpirationDate.Location = new System.Drawing.Point(3, 67);
            this.dtExpirationDate.Name = "dtExpirationDate";
            this.dtExpirationDate.Size = new System.Drawing.Size(255, 21);
            this.dtExpirationDate.TabIndex = 4;
            this.dtExpirationDate.ValueChanged += new System.EventHandler(this.dtExpirationDate_ValueChanged);
            // 
            // cbAppointmentTime
            // 
            this.cbAppointmentTime.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbAppointmentTime.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbAppointmentTime.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbAppointmentTime.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cbAppointmentTime.FormattingEnabled = true;
            this.cbAppointmentTime.Items.AddRange(new object[] {
            "10:00",
            "11:00",
            "12:00",
            "13:00"});
            this.cbAppointmentTime.Location = new System.Drawing.Point(274, 22);
            this.cbAppointmentTime.Name = "cbAppointmentTime";
            this.cbAppointmentTime.Size = new System.Drawing.Size(100, 21);
            this.cbAppointmentTime.TabIndex = 3;
            this.cbAppointmentTime.TextChanged += new System.EventHandler(this.cbAppointmentTime_TextChanged);
            this.cbAppointmentTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbAppointmentTime_KeyPress);
            // 
            // cbExpirationTime
            // 
            this.cbExpirationTime.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbExpirationTime.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbExpirationTime.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbExpirationTime.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cbExpirationTime.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cbExpirationTime.FormattingEnabled = true;
            this.cbExpirationTime.Location = new System.Drawing.Point(274, 67);
            this.cbExpirationTime.Name = "cbExpirationTime";
            this.cbExpirationTime.Size = new System.Drawing.Size(100, 21);
            this.cbExpirationTime.TabIndex = 5;
            this.cbExpirationTime.TextChanged += new System.EventHandler(this.cbExpirationTime_TextChanged);
            this.cbExpirationTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbExpirationTime_KeyPress);
            // 
            // lbAppointmentTime
            // 
            this.lbAppointmentTime.AutoSize = true;
            this.lbAppointmentTime.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbAppointmentTime.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lbAppointmentTime.Location = new System.Drawing.Point(274, 6);
            this.lbAppointmentTime.Name = "lbAppointmentTime";
            this.lbAppointmentTime.Size = new System.Drawing.Size(100, 13);
            this.lbAppointmentTime.TabIndex = 9;
            this.lbAppointmentTime.Text = "Time:";
            // 
            // lbExpirationTime
            // 
            this.lbExpirationTime.AutoSize = true;
            this.lbExpirationTime.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbExpirationTime.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lbExpirationTime.Location = new System.Drawing.Point(274, 51);
            this.lbExpirationTime.Name = "lbExpirationTime";
            this.lbExpirationTime.Size = new System.Drawing.Size(100, 13);
            this.lbExpirationTime.TabIndex = 10;
            this.lbExpirationTime.Text = "Time:";
            // 
            // lbAppointmentDate
            // 
            this.lbAppointmentDate.AutoSize = true;
            this.lbAppointmentDate.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbAppointmentDate.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lbAppointmentDate.Location = new System.Drawing.Point(3, 6);
            this.lbAppointmentDate.Name = "lbAppointmentDate";
            this.lbAppointmentDate.Size = new System.Drawing.Size(255, 13);
            this.lbAppointmentDate.TabIndex = 11;
            this.lbAppointmentDate.Text = "Appointment date:";
            // 
            // lbExpirationDate
            // 
            this.lbExpirationDate.AutoSize = true;
            this.lbExpirationDate.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbExpirationDate.Location = new System.Drawing.Point(3, 51);
            this.lbExpirationDate.Name = "lbExpirationDate";
            this.lbExpirationDate.Size = new System.Drawing.Size(255, 13);
            this.lbExpirationDate.TabIndex = 12;
            this.lbExpirationDate.Text = "Expiration date:";
            // 
            // chbNeverExpire
            // 
            this.chbNeverExpire.AutoSize = true;
            this.chbNeverExpire.Checked = true;
            this.chbNeverExpire.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbNeverExpire.Dock = System.Windows.Forms.DockStyle.Top;
            this.chbNeverExpire.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.chbNeverExpire.Location = new System.Drawing.Point(3, 93);
            this.chbNeverExpire.Name = "chbNeverExpire";
            this.chbNeverExpire.Size = new System.Drawing.Size(255, 16);
            this.chbNeverExpire.TabIndex = 6;
            this.chbNeverExpire.Text = "Does not expire";
            this.chbNeverExpire.UseVisualStyleBackColor = true;
            this.chbNeverExpire.CheckedChanged += new System.EventHandler(this.chbNeverExpire_CheckedChanged);
            // 
            // chbAllowAppOutsideShift
            // 
            this.chbAllowAppOutsideShift.AutoSize = true;
            this.chbAllowAppOutsideShift.Dock = System.Windows.Forms.DockStyle.Top;
            this.chbAllowAppOutsideShift.Location = new System.Drawing.Point(3, 115);
            this.chbAllowAppOutsideShift.Name = "chbAllowAppOutsideShift";
            this.chbAllowAppOutsideShift.Size = new System.Drawing.Size(255, 17);
            this.chbAllowAppOutsideShift.TabIndex = 13;
            this.chbAllowAppOutsideShift.Text = "Allow appointments outside of permitted shift hours";
            this.chbAllowAppOutsideShift.UseVisualStyleBackColor = true;
            this.chbAllowAppOutsideShift.CheckedChanged += new System.EventHandler(this.chbAllowAppOutsideShift_CheckedChanged);
            // 
            // gbTime
            // 
            this.gbTime.Controls.Add(this.lbInterviewerTime);
            this.gbTime.Controls.Add(this.lbInterviewer);
            this.gbTime.Controls.Add(this.lbRespondentTime);
            this.gbTime.Controls.Add(this.lbRespondent);
            this.gbTime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbTime.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gbTime.Location = new System.Drawing.Point(3, 64);
            this.gbTime.Name = "gbTime";
            this.gbTime.Size = new System.Drawing.Size(432, 41);
            this.gbTime.TabIndex = 5;
            this.gbTime.TabStop = false;
            this.gbTime.Text = "Current time";
            // 
            // lbInterviewerTime
            // 
            this.lbInterviewerTime.AutoSize = true;
            this.lbInterviewerTime.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lbInterviewerTime.Location = new System.Drawing.Point(332, 16);
            this.lbInterviewerTime.Name = "lbInterviewerTime";
            this.lbInterviewerTime.Size = new System.Drawing.Size(51, 13);
            this.lbInterviewerTime.TabIndex = 3;
            this.lbInterviewerTime.Text = "13:20:17";
            // 
            // lbInterviewer
            // 
            this.lbInterviewer.AutoSize = true;
            this.lbInterviewer.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lbInterviewer.Location = new System.Drawing.Point(254, 16);
            this.lbInterviewer.Name = "lbInterviewer";
            this.lbInterviewer.Size = new System.Drawing.Size(67, 13);
            this.lbInterviewer.TabIndex = 2;
            this.lbInterviewer.Text = "Interviewer:";
            // 
            // lbRespondentTime
            // 
            this.lbRespondentTime.AutoSize = true;
            this.lbRespondentTime.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lbRespondentTime.Location = new System.Drawing.Point(120, 16);
            this.lbRespondentTime.Name = "lbRespondentTime";
            this.lbRespondentTime.Size = new System.Drawing.Size(51, 13);
            this.lbRespondentTime.TabIndex = 1;
            this.lbRespondentTime.Text = "12:20:00";
            // 
            // lbRespondent
            // 
            this.lbRespondent.AutoSize = true;
            this.lbRespondent.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lbRespondent.Location = new System.Drawing.Point(30, 16);
            this.lbRespondent.Name = "lbRespondent";
            this.lbRespondent.Size = new System.Drawing.Size(69, 13);
            this.lbRespondent.TabIndex = 0;
            this.lbRespondent.Text = "Respondent:";
            // 
            // pnlTitle
            // 
            this.pnlTitle.BackColor = System.Drawing.Color.White;
            this.pnlTitle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnlTitle.Controls.Add(this.lbTitleDescription);
            this.pnlTitle.Controls.Add(this.lbTitle);
            this.pnlTitle.Controls.Add(this.pbTitle);
            this.pnlTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTitle.Location = new System.Drawing.Point(0, 0);
            this.pnlTitle.Margin = new System.Windows.Forms.Padding(0);
            this.pnlTitle.Name = "pnlTitle";
            this.pnlTitle.Size = new System.Drawing.Size(438, 61);
            this.pnlTitle.TabIndex = 6;
            // 
            // lbTitleDescription
            // 
            this.lbTitleDescription.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lbTitleDescription.Location = new System.Drawing.Point(12, 20);
            this.lbTitleDescription.Name = "lbTitleDescription";
            this.lbTitleDescription.Size = new System.Drawing.Size(373, 46);
            this.lbTitleDescription.TabIndex = 2;
            this.lbTitleDescription.Text = "Please supply appointment details in respondent timezone below. ";
            // 
            // pbTitle
            // 
            this.pbTitle.Dock = System.Windows.Forms.DockStyle.Right;
            this.pbTitle.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.title;
            this.pbTitle.Location = new System.Drawing.Point(338, 0);
            this.pbTitle.Name = "pbTitle";
            this.pbTitle.Size = new System.Drawing.Size(100, 61);
            this.pbTitle.TabIndex = 0;
            this.pbTitle.TabStop = false;
            // 
            // erpAppointmentDate
            // 
            this.erpAppointmentDate.ContainerControl = this;
            // 
            // erpAppointmentTime
            // 
            this.erpAppointmentTime.ContainerControl = this;
            // 
            // erpExpirationDate
            // 
            this.erpExpirationDate.ContainerControl = this;
            // 
            // erpExpirationTime
            // 
            this.erpExpirationTime.ContainerControl = this;
            // 
            // AppointmentForm
            // 
            this.AcceptButton = this.btnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(438, 326);
            this.Controls.Add(this.ltMain);
            this.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "AppointmentForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Appointment";
            this.ltMain.ResumeLayout(false);
            this.ltRadios.ResumeLayout(false);
            this.ltRadios.PerformLayout();
            this.ltButtons.ResumeLayout(false);
            this.ltButtons.PerformLayout();
            this.gbEdit.ResumeLayout(false);
            this.ltInputFields.ResumeLayout(false);
            this.ltInputFields.PerformLayout();
            this.gbTime.ResumeLayout(false);
            this.gbTime.PerformLayout();
            this.pnlTitle.ResumeLayout(false);
            this.pnlTitle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTitle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpAppointmentDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpAppointmentTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpExpirationDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpExpirationTime)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel ltMain;
		private System.Windows.Forms.GroupBox gbEdit;
        private System.Windows.Forms.TableLayoutPanel ltInputFields;
		private System.Windows.Forms.DateTimePicker dtAppointmentDate;
		private System.Windows.Forms.DateTimePicker dtExpirationDate;
		private System.Windows.Forms.ComboBox cbAppointmentTime;
		private System.Windows.Forms.ComboBox cbExpirationTime;
		private System.Windows.Forms.Label lbAppointmentTime;
		private System.Windows.Forms.Label lbExpirationTime;
		private System.Windows.Forms.Label lbAppointmentDate;
		private System.Windows.Forms.Label lbExpirationDate;
		private System.Windows.Forms.CheckBox chbNeverExpire;
		private System.Windows.Forms.TableLayoutPanel ltRadios;
        private System.Windows.Forms.TableLayoutPanel ltButtons;
		private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
		private System.Windows.Forms.GroupBox gbTime;
		private System.Windows.Forms.Label lbInterviewerTime;
		private System.Windows.Forms.Label lbInterviewer;
		private System.Windows.Forms.Label lbRespondentTime;
		private System.Windows.Forms.Label lbRespondent;
		private System.Windows.Forms.ErrorProvider erpAppointmentDate;
		private System.Windows.Forms.ErrorProvider erpAppointmentTime;
		private System.Windows.Forms.ErrorProvider erpExpirationDate;
		private System.Windows.Forms.ErrorProvider erpExpirationTime;
		private System.Windows.Forms.Panel pnlTitle;
		private System.Windows.Forms.PictureBox pbTitle;
        private System.Windows.Forms.Label lbTitleDescription;
		private System.Windows.Forms.CheckBox chbLogout;
        private System.Windows.Forms.Label lbTitle;
        private System.Windows.Forms.LinkLabel lbShowInterviewerAppointmens;
        private System.Windows.Forms.CheckBox chbAllowAppOutsideShift;
	}
}