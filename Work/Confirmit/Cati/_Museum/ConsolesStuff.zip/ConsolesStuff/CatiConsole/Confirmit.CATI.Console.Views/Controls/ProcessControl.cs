﻿using System.Windows.Forms;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Controls
{
    /// <summary>
    /// Class is responsible for show proccess screen during asynchronous operation 
    /// </summary>
    public partial class ProcessControl : UserControl, IViewProcessControl
    {
        public ProcessControl()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Process control will show this message during asynchronous operation
        /// </summary>
        public string ProcessMessage
        {
            set { lbMessage.Text = value; }
        }
    }
}
