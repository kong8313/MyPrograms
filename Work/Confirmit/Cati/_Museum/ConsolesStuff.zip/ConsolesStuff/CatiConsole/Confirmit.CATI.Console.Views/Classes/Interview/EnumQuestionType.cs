﻿namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    public enum QuestionType
    {
        Info,
        Open,
        Grid,
        Grid3D,
        Multi,
        MultiOpen,
        Ranking,
        SearchableMulti,
        Simple,        
        GridBars,
        CaptureOrder,
        RankedOrder,
        GridSlider,
        GridSliderLegacy,//TODO: Need to investigate is it used now or not and probably remove it because currently unsupported question type
        CardSort,
        CarouselGrid,
        ImageButtons,
        RankedOrderClick,
        DatePicker
    }
}
