﻿namespace Confirmit.CATI.Console.Views.Controls
{
    partial class SearchableGrid
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.pnlBodyGrid = new System.Windows.Forms.Panel();
            this.gridInterviews = new System.Windows.Forms.DataGridView();
            this.pnlHeaderGrid = new System.Windows.Forms.Panel();
            this.gridHeader = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mainPanel.SuspendLayout();
            this.pnlBodyGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridInterviews)).BeginInit();
            this.pnlHeaderGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridHeader)).BeginInit();
            this.SuspendLayout();
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.mainPanel.Controls.Add(this.pnlBodyGrid);
            this.mainPanel.Controls.Add(this.pnlHeaderGrid);
            this.mainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainPanel.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.mainPanel.Location = new System.Drawing.Point(0, 0);
            this.mainPanel.Margin = new System.Windows.Forms.Padding(0);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(400, 300);
            this.mainPanel.TabIndex = 0;
            this.mainPanel.Resize += new System.EventHandler(this.mainPanel_Resize);
            // 
            // pnlBodyGrid
            // 
            this.pnlBodyGrid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlBodyGrid.Controls.Add(this.gridInterviews);
            this.pnlBodyGrid.Location = new System.Drawing.Point(0, 102);
            this.pnlBodyGrid.Name = "pnlBodyGrid";
            this.pnlBodyGrid.Size = new System.Drawing.Size(409, 220);
            this.pnlBodyGrid.TabIndex = 1;
            // 
            // gridInterviews
            // 
            this.gridInterviews.AllowUserToAddRows = false;
            this.gridInterviews.AllowUserToDeleteRows = false;
            this.gridInterviews.AllowUserToResizeColumns = false;
            this.gridInterviews.AllowUserToResizeRows = false;
            this.gridInterviews.BackgroundColor = System.Drawing.SystemColors.Window;
            this.gridInterviews.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gridInterviews.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridInterviews.ColumnHeadersVisible = false;
            this.gridInterviews.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridInterviews.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.gridInterviews.GridColor = System.Drawing.SystemColors.Control;
            this.gridInterviews.Location = new System.Drawing.Point(0, 0);
            this.gridInterviews.Margin = new System.Windows.Forms.Padding(0);
            this.gridInterviews.MultiSelect = false;
            this.gridInterviews.Name = "gridInterviews";
            this.gridInterviews.RowHeadersVisible = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gridInterviews.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gridInterviews.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gridInterviews.RowTemplate.Height = 18;
            this.gridInterviews.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridInterviews.Size = new System.Drawing.Size(409, 220);
            this.gridInterviews.TabIndex = 0;
            this.gridInterviews.Scroll += new System.Windows.Forms.ScrollEventHandler(this.dataGridBody_Scroll);
            // 
            // pnlHeaderGrid
            // 
            this.pnlHeaderGrid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlHeaderGrid.Controls.Add(this.gridHeader);
            this.pnlHeaderGrid.Location = new System.Drawing.Point(0, 0);
            this.pnlHeaderGrid.Name = "pnlHeaderGrid";
            this.pnlHeaderGrid.Size = new System.Drawing.Size(409, 48);
            this.pnlHeaderGrid.TabIndex = 0;
            // 
            // gridHeader
            // 
            this.gridHeader.AllowUserToAddRows = false;
            this.gridHeader.AllowUserToDeleteRows = false;
            this.gridHeader.AllowUserToResizeRows = false;
            this.gridHeader.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.gridHeader.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gridHeader.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(1);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridHeader.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gridHeader.ColumnHeadersHeight = 24;
            this.gridHeader.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Format = "N2";
            dataGridViewCellStyle3.NullValue = null;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridHeader.DefaultCellStyle = dataGridViewCellStyle3;
            this.gridHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridHeader.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.gridHeader.GridColor = System.Drawing.SystemColors.Control;
            this.gridHeader.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.gridHeader.Location = new System.Drawing.Point(0, 0);
            this.gridHeader.Margin = new System.Windows.Forms.Padding(0);
            this.gridHeader.MultiSelect = false;
            this.gridHeader.Name = "gridHeader";
            this.gridHeader.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridHeader.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gridHeader.RowHeadersVisible = false;
            this.gridHeader.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.gridHeader.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.gridHeader.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Control;
            this.gridHeader.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Control;
            this.gridHeader.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.gridHeader.RowTemplate.Height = 23;
            this.gridHeader.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.gridHeader.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.gridHeader.ShowEditingIcon = false;
            this.gridHeader.Size = new System.Drawing.Size(409, 48);
            this.gridHeader.StandardTab = true;
            this.gridHeader.TabIndex = 104;
            this.gridHeader.TabStop = false;
            this.gridHeader.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridHeader_ColumnHeaderMouseClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Column1";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Column2";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Column3";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Column4";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Column5";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Column6";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Column7";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Column8";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // SearchableGrid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.mainPanel);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "SearchableGrid";
            this.Size = new System.Drawing.Size(400, 300);
            this.mainPanel.ResumeLayout(false);
            this.pnlBodyGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridInterviews)).EndInit();
            this.pnlHeaderGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridHeader)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.Panel pnlHeaderGrid;
        private System.Windows.Forms.Panel pnlBodyGrid;
        private System.Windows.Forms.DataGridView gridHeader;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridView gridInterviews;
    }
}
