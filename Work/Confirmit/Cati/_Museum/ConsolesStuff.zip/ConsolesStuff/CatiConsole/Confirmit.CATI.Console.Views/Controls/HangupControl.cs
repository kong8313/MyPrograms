﻿using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Controls
{
    public partial class HangupControl : UserControl, IViewHangupControl
    {
        #region Constructors

        public HangupControl()
        {
            InitializeComponent();
        }

        #endregion

        #region ILocalizableView Members

        /// <summary>
        /// Localizes view according given localization information.
        /// </summary>
        /// <param name="manager">Localization manager which contains localization info.</param>
        public void Localize(ILocalizationManager manager)
        {
            lbMessage.Text = manager.GetString("HangupControl_Message_Text");
        }

        #endregion
    }
}
