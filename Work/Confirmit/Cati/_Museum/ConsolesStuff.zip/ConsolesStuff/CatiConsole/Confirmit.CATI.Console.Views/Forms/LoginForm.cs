﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
	/// <summary>
	/// Represents login form to Fusion Web Service.
	/// </summary>
	public partial class LoginForm : Form, IViewLoginForm
	{
        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, int wParam, [MarshalAs(UnmanagedType.LPWStr)] string lParam);

		#region Fields

		private bool m_IsLoggedIn = false;
        private bool m_CompanyInputEnabled = true;

		#endregion

		#region Constructors

		/// <summary>
		/// Initializes new instance of LoginForm class.
		/// </summary>
		public LoginForm()
		{
			InitializeComponent();
		    Icon = Properties.Resources.AppIcon;
		}

		#endregion

		#region Event handlers

		private void LoginForm_FormClosed(object sender, FormClosedEventArgs e)
		{
            if (e.CloseReason != CloseReason.FormOwnerClosing)
            {
                OnFormClose(EventArgs.Empty);
            }
		}

		private void btnLogin_Click(object sender, EventArgs e)
		{
            if (cbSetAsDefaultCompany.Checked)
            {
                OnSetAsDefaultCompanyCheck(EventArgs.Empty);
            }
            OnLoginClick(EventArgs.Empty);
		}

        private void llChangePassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OnPasswordChangeClick(EventArgs.Empty);
        }

        private void LoginForm_Shown(object sender, EventArgs e)
        {
            tbUser.Focus();
        }

        private void cbSetAsDefaultCompany_CheckedChanged(object sender, EventArgs e)
        {
            if (cbSetAsDefaultCompany.Checked)
            {
                OnSetAsDefaultCompanyCheck(EventArgs.Empty);
            }
            else
            {
                OnSetAsDefaultCompanyUncheck(EventArgs.Empty);
            }
        }
        
        private void LoginForm_Load(object sender, EventArgs e)
        {
            OnFormLoad(EventArgs.Empty);

            if (CompanyInputEnabled)
            {
                cbSetAsDefaultCompany.Checked = !String.IsNullOrEmpty(LoginCompanyAlias);
            }
            else
            {
                HideCompanyControls();
            }
        }

		#endregion

		#region ILocalizableForm Members

		/// <summary>
		/// Localizes view according given localization information.
		/// </summary>
		/// <param name="manager">Localization manager which contains localization info.</param>
		public void Localize(ILocalizationManager manager)
		{
			Text = manager.GetString("LoginForm_Title");
            SetControlWaterMarkText(tbUser, manager.GetString("LoginForm_User"));
            SetControlWaterMarkText(tbPassword, manager.GetString("LoginForm_Password"));
		    SetControlWaterMarkText(tbCompany, manager.GetString("LoginForm_Company"));
            cbSetAsDefaultCompany.Text = manager.GetString("LoginForm_SetDefaultCompany");
		    lbApplicationTitle.Text = manager.GetString("LoginForm_ApplicationTitle");
            llChangePassword.Text = manager.GetString("LoginForm_ChangePasswordLinkLabel");
		}

		#endregion

		#region IViewLoginForm Members

		/// <summary>
		/// Occurs when user clicks Login button.
		/// </summary>
		public event EventHandler<EventArgs> LoginClick;

        /// <summary>
        /// Occurs when user clicks PasswordChangeClick link label.
        /// </summary>
        public event EventHandler<EventArgs> PasswordChangeClick;
        
        /// <summary>
        /// Occurs when user clicks cbSetAsDefaultCompany check box.
        /// </summary>
        public event EventHandler<EventArgs> SetAsDefaultCompanyCheck;

        /// <summary>
        /// Occurs when user clicks cbSetAsDefaultCompany uncheck box.
        /// </summary>
        public event EventHandler<EventArgs> SetAsDefaultCompanyUncheck;

        /// <summary>
        /// Occurs when form is loaded.
        /// </summary>
        public event EventHandler<EventArgs> FormLoad;

        /// <summary>
        /// Occurs when login form is closed.
        /// </summary>
        public event EventHandler<EventArgs> FormClose;

        /// <summary>
        /// Occurs when user press any key.
        /// </summary>
        public event EventHandler<ProcessCmdKeyEventArgs> FormProcessCmdKey;

		/// <summary>
		/// Name of log-in user.
		/// </summary>
		public string LoginUser
		{
			get
			{
				return tbUser.Text;
			}
			set
			{
				tbUser.Text = value;
			}
		}

		/// <summary>
		/// Log-in password.
		/// </summary>
		public string LoginPassword
		{
			get
			{
				return tbPassword.Text;
			}
			set
			{
				tbPassword.Text = value;
			}
		}

        /// <summary>
        /// Log-in company alias.
        /// </summary>
        public string LoginCompanyAlias
        {
            get
            {
                return tbCompany.Text;
            }
            set
            {
                tbCompany.Text = value;
            }
        }

        /// <summary>
        /// Indicates if user logged-in or not.
        /// </summary>
        public bool CompanyInputEnabled
        {
            get
            {
                return m_CompanyInputEnabled;
            }
            set
            {
                m_CompanyInputEnabled = value;
            }
        }

		/// <summary>
		/// Indicates if user logged-in or not.
		/// </summary>
		public bool IsLoggedIn
		{
			get
			{
				return m_IsLoggedIn;
			}
			set
			{
				m_IsLoggedIn = value;
			}
		}

		/// <summary>
		/// Clears data in all input forms.
		/// </summary>
		public void Clear()
		{
			tbUser.Text = String.Empty;
			tbPassword.Text = String.Empty;
		}

        /// <summary>
        /// Make the form visible
        /// </summary>
        public void ShowForm()
        {
            Visible = true;
        }

        /// <summary>
        /// Make the form invisible
        /// </summary>
        public void HideForm()
		{
            Visible = false;
        }
        
		/// <summary>
		/// Closes form.
		/// </summary>
		public void CloseForm()
		{
            Visible = false;
            //Process all accumulated events 
            //For example if user presses enter while form is going to be closed this events will go to MainForm.
            Application.DoEvents();
			Close();            
		}

		#endregion

		#region Methods

        /// <summary>
        /// Hides company related controls.
        /// </summary>
        private void HideCompanyControls()
        {
            tbCompany.Visible = false;
            cbSetAsDefaultCompany.Visible = false;
            pnlMain.BackgroundImage = Properties.Resources.cati_login3_comp;
        }

        /// <summary>
        /// Fires FormLoad event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnFormLoad(EventArgs e)
        {
            if (FormLoad != null)
            {
                FormLoad(this, e);
            }
        }

		/// <summary>
		/// Fires LoginCancel event.
		/// <param name="e">Event arguments.</param>
		/// </summary>
		protected virtual void OnFormClose(EventArgs e)
		{
			if (FormClose != null)
			{
				FormClose(this, e);
			}
		}

		/// <summary>
		/// Fires LoginClick event.
		/// <param name="e">Event arguments.</param>
		/// </summary>
		protected virtual void OnLoginClick(EventArgs e)
		{
			if (LoginClick != null)
			{
				LoginClick(this, e);
			}
		}

        protected virtual void OnPasswordChangeClick(EventArgs e)
        {
            if (PasswordChangeClick != null)
            {
                PasswordChangeClick(this, e);
            }
        }

        /// <summary>
        /// Fires when cbSetAsDefault checked
        /// <param name="e">Event arguments.</param>
        /// </summary>
        protected void OnSetAsDefaultCompanyCheck(EventArgs e)
        {
            if (SetAsDefaultCompanyCheck != null)
            {
                SetAsDefaultCompanyCheck(this, e);
            }
        }

        /// <summary>
        /// Fires when cbSetAsDefault unchecked
        /// <param name="e">Event arguments.</param>
        /// </summary>
        protected void OnSetAsDefaultCompanyUncheck(EventArgs e)
        {
            if (SetAsDefaultCompanyUncheck != null)
            {
                SetAsDefaultCompanyUncheck(this, e);
            }
        }

        /// <summary>
        /// Overrides ProcessCmdKey for key down interception
        /// </summary>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            var eventArgs = new ProcessCmdKeyEventArgs { KeyData = keyData };
            
            OnFormProcessCmdKey(eventArgs);            

            if (eventArgs.Cancel)
            {
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        /// <summary>
        /// Fires FormProcessCmdKey
        /// <param name="eventArgs">Event arguments.</param>
        /// </summary>    
        private void OnFormProcessCmdKey(ProcessCmdKeyEventArgs eventArgs)
        {
            if (FormProcessCmdKey != null)
            {
                FormProcessCmdKey(this, eventArgs);
            }
        }

        private void SetControlWaterMarkText(Control textBox, string waterMark)
        {
            SendMessage(textBox.Handle, 0x1501, 1, waterMark);
        }

        #endregion
    }
}
