﻿namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Represents view interface for ProcessControl control.
    /// </summary>
    public interface IViewProcessControl
    {
        /// <summary>
        /// Process control will show this message during asynchronous operation
        /// </summary>
        string ProcessMessage
        {
            set;
        }
    }
}
