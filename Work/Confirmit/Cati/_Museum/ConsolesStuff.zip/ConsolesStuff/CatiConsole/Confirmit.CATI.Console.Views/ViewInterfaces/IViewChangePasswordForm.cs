﻿using System;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    public interface IViewChangePasswordForm : IWin32Window, ILocalizableView
    {
        /// <summary>
        /// Occurs when user clicks Login button.
        /// </summary>
        event EventHandler<EventArgs> ChangeClick;

        /// <summary>
        /// Name of log-in user.
        /// </summary>
        string LoginUser
        {
            get;
            set;
        }

        /// <summary>
        /// Old password.
        /// </summary>
        string OldPassword
        {
            get;
            set;
        }

        /// <summary>
        /// New password.
        /// </summary>
        string NewPassword
        {
            get;
            set;
        }

        /// <summary>
        /// Confirm password
        /// </summary>
        string ConfirmPassword
        {
            get;
            set;
        }

        /// <summary>
        /// Log-in company alias
        /// </summary>
        string LoginCompanyAlias
        {
            get;
            set;
        }

        /// <summary>
        /// Closes form.
        /// </summary>
        void CloseForm();

        /// <summary>
        /// Set uset name, if it was entered in the login form
        /// </summary>
        /// <param name="userName"></param>
        void SetUserName(string userName);

        /// <summary>
        /// Set company alias, if it was entered in the login form
        /// </summary>
        /// <param name="companyAlias"></param>
        void SetCompanyAlias(string companyAlias);
    }
}