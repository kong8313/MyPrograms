﻿using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
    /// <summary>
    /// Class represents form with interviewer appointmens list
    /// </summary>
    public partial class InterviewerAppointmentsForm : Form, IViewInterviewerAppointmentsForm
    {
        #region Constructors

        /// <summary>
        /// Initializes new instance of InterviewerAppointmensForm
        /// </summary>
        public InterviewerAppointmentsForm()
        {
            InitializeComponent();
            Icon = Properties.Resources.AppIcon;
        }

        #endregion        

        #region ILocalizableView Members

        /// <summary>
        /// Localizes view according given localization information.
        /// </summary>
        /// <param name="manager">Localization manager which contains localization info.</param>
        public void Localize(ILocalizationManager manager)
        {
            Text = manager.GetString("InterviewerAppointmentsForm_Caption");
            chProjectId.Text = manager.GetString("InterviewerAppointmentsForm_ColumnProjectId_Text");
            chInterviewId.Text = manager.GetString("InterviewerAppointmentsForm_ColumnInterviewId_Text");
            chProjectName.Text = manager.GetString("InterviewerAppointmentsForm_ColumnProjectName_Text");
            chAppointmentInterviewerTime.Text = manager.GetString("InterviewerAppointmentsForm_ColumnAppointmentInterviewerTime_Text");
            chAppointmentTime.Text = manager.GetString("InterviewerAppointmentsForm_ColumnAppointmentTime_Text");
            chTimezone.Text = manager.GetString("InterviewerAppointmentsForm_ColumnTimezone_Text");            
        }

        #endregion

        #region IViewUpcomingAppointmentsForm Members

        /// <summary>
        /// Shows modal license form.
        /// </summary>
        /// <returns>Retruns dialog result.</returns>
        public new DialogResult Show()
        {
            return ShowDialog();
        }

        public void Bind(string[][] appointmens)
        {
            lvInterviewerAppointmens.Items.Clear();

            if (appointmens != null)
            {
                foreach (string[] appointment in appointmens)
                {
                    lvInterviewerAppointmens.Items.Add(
                        new ListViewItem(appointment)
                    );
                }
            }
        }

        #endregion

        private void InterviewerAppointmentsForm_Resize(object sender, System.EventArgs e)
        {
            AutoResizeLastColumn();
        }

        private void lvInterviewerAppointmens_ColumnWidthChanged(object sender, ColumnWidthChangedEventArgs e)
        {
            if (e.ColumnIndex != (lvInterviewerAppointmens.Columns.Count - 1))
            {
                AutoResizeLastColumn();
            }
        }

        private void AutoResizeLastColumn()
        {
            lvInterviewerAppointmens.Columns[lvInterviewerAppointmens.Columns.Count - 1].Width = -2;
        }
    }
}
