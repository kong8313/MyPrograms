﻿namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    /// <summary>
    /// Html element tag enumeration
    /// </summary>
    public enum TagNames
    {
        INPUT,
        TEXTAREA,
        SELECT,
        LABEL,
        DIV,
        IMG,
        UNDEFINED
    }

    /// <summary>
    /// Html element type enumeration
    /// </summary>
    public enum ElementTypes
    {
        Checkbox ,
        Radio,
        TextInput,
        TextArea ,
        Select,
        Undefined
    }
}
