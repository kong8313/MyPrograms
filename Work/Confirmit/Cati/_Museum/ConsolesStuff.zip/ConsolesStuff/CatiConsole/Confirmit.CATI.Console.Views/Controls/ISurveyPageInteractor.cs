﻿using System;
using System.Collections.Generic;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.SpellChecking;
using Confirmit.CATI.Console.Views.Classes.Utilities;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using mshtml;

namespace Confirmit.CATI.Console.Views.Controls
{
    public interface ISurveyPageInteractor
    {
        void Unsubscribe();
        string Its { get; }
        bool HasSoundInfo { get; }
        bool StartPlaybackAutomatically { get; }
        string SoundFileName { get; }
        bool IsConfirmitServicePage { get; }
        bool IsConfirmitInternalErrorPage { get; }
        bool IsEndInterviewPageLoaded { get; }
        int InterviewDuration { get; }
        string Status { get; set; }
        string CurrentQuestionId { get; }
        bool IsOpenendReviewStartPage { get; }
        bool ContainsForcedAppointment { get; }
        bool Is500ErrorPage { get; }
        bool IsCurrentQuestionLast { get; }
        bool HasOpenEndQuestion { get; }
        bool DisableCatiMarkupAndKeyboardSupport { get; }
        bool HasCurrentQuestionAnswersWithFocusedOtherField { get; }
        string DialPhone { get; }
        string CurrentQuestionTitle { get; }
        int CurrentQuestionIndex { get; set; }
        string TransferResource { get; }
        string DialMessage { get; }
        TelephonyPageType TelephonyPage { get; }
        int? DialStatus { get; set; }
        bool IsOkPage { get; }
        EventHandler<EventArgs> OnRedraw { get; set; }
        bool CurrentQuestionHasDefaultAnswer { get; }
        bool CurrentQuestionHasRefusedAnswer { get; }
        bool NavigationCanBeIgnored { get; }
        bool ReadOnly { get; set; }
        void FinishInterview();
        void TerminateInterview(int status);
        void ParseForSoundInfo();
        void UpdatePagePartially(string elementId, string elementOuterHtml, string activeElementId);
        string GetDatePickerDatePattern();
        void ChangeLanguage(int languageId);
        bool CheckAndGetTelephonyFlag(out bool allowTelephonyCommands);
        void SetAnswer(string elementId, string elementValue);
        void ContinueInterview();
        void FastForward();
        void DoNextPage();
        void DoPrevPage();
        void DoQuestion(int questionIndex);
        void DoSubQuestion(int subQuestionIndex);
        void DoPreviousQuestion();
        void DoNextQuestion();
        void DoFirstQuestion();
        void DoFirstQuestionFirstSubQuestion();
        void DoLastQuestion();
        void DoLastQuestionLastSubQuestion();
        void DoFirstSubQuestion();
        void DoLastSubQuestion();
        void DoEditQuestion();
        void MonitorChangesFor(string elementId, string activeElementId);
        void SetDefaultAnswer(out bool navigate, out bool keepFocus);
        void SetRefusedAnswer(out bool navigate, out bool keepFocus);
        void ProcessEnterData(string answer);
        void Subscribe();
        void ParseDocument();
        void SetDefaultActiveQuestion();
        bool IsFeatureRequired(BrowserFeature feature);
        void DoRequiredSubscriptions();
        IEnumerable<QuestionTextBlock> GetPageTextBlocks();
        void InsertStyles();
        void OnResponsiveQuestionSelected(string id, string type, string text, string title, int index, int subQuestionIndex);
        void DynamicQuestionAnswerChangedHandler(string elementId);
        void AjaxQuestionLoadedHandler();
        void OnResponsiveSubQuestionSelected(int questionIndex, int subQuestionIndex);
    }
}