﻿using Confirmit.CATI.Console.Shared.Log;
using mshtml;
using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Console.Views.Classes.Utilities;
using Confirmit.CATI.Console.Views.Resources;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    public class Question
    {
        private List<SubQuestion> _subQuestions;
        private List<IHTMLElement> _inputElements;
        private QuestionType _questionType = QuestionType.Simple;
        private readonly Dictionary<IHTMLElement, SubQuestion> _elementSubQuestionDictionary = new Dictionary<IHTMLElement, SubQuestion>();
        private AnswerCollection _activeAnswers;
        private readonly bool _highlightQuestion;
        private bool _active;

        private Question()
        {
        }

        public Question(IHTMLElement inputTypeElement, bool highlightQuestion)
        {
            var element = (IHTMLInputElement)inputTypeElement;

            Id = inputTypeElement.id;

            RootElement = ((IHTMLDOMNode)element).nextSibling as IHTMLElement;

            if ((RootElement == null) || !(RootElement is HTMLTable || RootElement is HTMLDivElement))
            {
                throw new ArgumentException(Strings.Exception_InvalidIHTMLElementIsPassed);
            }

            if (InputElements.Count == 0 && IsInfoQuestion(element) == false) // maybe nextSibling is header or question type is info as a result there are no input elements
            {
                _inputElements = null; // reset inputElements
                RootElement = (IHTMLElement)element.GetNextSiblingSkipComments().GetNextSiblingSkipComments();

                // is not header
                if (RootElement == null ||
                    (!RootElement.tagName.Equals("TABLE", StringComparison.InvariantCultureIgnoreCase) &&
                     !RootElement.tagName.Equals("DIV", StringComparison.InvariantCultureIgnoreCase)))
                {
                    RootElement = ((IHTMLDOMNode)element).nextSibling as IHTMLElement;
                }
            }

            _highlightQuestion = highlightQuestion;

            _questionType = GetQuestionType(element);
            QuestionId = GetQuestionId(element);
            Title = GetQuestionTitle(RootElement);
            Text = GetQuestionText(RootElement);
            HasFilledOtherAnswer = CheckOtherAnswerPresence();

            ActiveSubQuestionChanged += Question_ActiveSubQuestionChanged;
        }

        /// <summary>
        /// Occurs when value of any underlying html element is changed
        /// </summary>
        public event EventHandler<AnswerElementValueChangedEventArgs> AnswerElementValueChanged;

        /// <summary>
        /// Occurs when active subquestion is changed
        /// </summary>
        public event EventHandler<EventArgs> ActiveSubQuestionChanged;

        public event EventHandler<InputChangedFromKeyboardEventArgs> InputChangedFromKeyboard;

        /// <summary>
        /// Question corrresponding IHTMLElement
        /// </summary>
        public IHTMLElement RootElement { get; private set; }

        /// <summary>
        /// Id of question underlying HTMLElement element
        /// </summary>
        public string Id { get; set; }

        public string Title { get; set; }

        public string Text { get; set; }

        /// <summary>
        /// Question Id
        /// </summary>
        /// <remarks>
        ///It is gotten from attribute questionId of underlying HTMLElement element 
        /// </remarks>
        public string QuestionId { get; set; }

        /// <summary>
        /// Gets/sets default answer precode
        /// </summary>
        public string DefaultAnswerPrecode { get; set; }

        /// <summary>
        /// Gets/sets refused answer precode
        /// </summary>
        public string RefusedAnswerPrecode { get; set; }

        /// <summary>
        /// Gets/sets flag indicating that question contains "other" answer 
        /// which is not empty.
        /// </summary>
        public bool HasFilledOtherAnswer { get; set; }

        /// <summary>
        /// Gets a value indicating whether current qusetion has default answer.
        /// </summary>
        public bool HasDefaultAnswer
        {
            get
            {
                return ArePredefinedAnswersSupported() &&
                    !String.IsNullOrEmpty(DefaultAnswerPrecode);
            }
        }

        /// <summary>
        /// Gets a value indicating whether current qusetion has refused answer.
        /// </summary>
        public bool HasRefusedAnswer
        {
            get
            {
                return ArePredefinedAnswersSupported() &&
                    !String.IsNullOrEmpty(RefusedAnswerPrecode);
            }
        }

        public bool IsImageButtons { get; set; }

        public bool Active
        {
            get
            {
                return _active;
            }
            set
            {
                _active = value;

                if (value)
                {
                    ActiveAnswers = null;

                    if (_highlightQuestion)
                    {
                        RootElement.className += $" {StylesProvider.CurrentQuestionContainerClassName}";
                    }

                    if (Type == QuestionType.Grid ||
                        Type == QuestionType.Grid3D ||
                        Type == QuestionType.MultiOpen)
                    {
                        foreach (var subQuestion in SubQuestions)
                        {
                            if (subQuestion.Active)
                            {
                                return;
                            }
                        }
                        if (SubQuestions.Count > 0)
                        {
                            SubQuestions[0].Active = true;
                        }
                    }
                }
                else
                {
                    if (_highlightQuestion)
                    {
                        RootElement.className = RootElement.className.Replace(StylesProvider.CurrentQuestionContainerClassName, "");
                    }

                    // Deactive all sub questions if exist
                    if (Type == QuestionType.Grid ||
                        Type == QuestionType.Grid3D ||
                        Type == QuestionType.MultiOpen)
                    {
                        // If exist any sub question, deactive all
                        foreach (var subQuestion in SubQuestions)
                        {
                            if (subQuestion.Active)
                            {
                                subQuestion.Active = false;
                                return;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Question type
        /// </summary>
        public QuestionType Type
        {
            get
            {
                return _questionType;
            }
            set
            {
                _questionType = value;
            }
        }

        public string ActiveColor
        {
            get
            {
                if (RootElement.style != null && RootElement.style.borderLeftColor != null)
                    return RootElement.style.borderLeftColor.ToString();

                return string.Empty;
            }
        }

        /// <summary>
        /// Return SubQuestion collection
        /// </summary>
        public List<SubQuestion> SubQuestions
        {
            get
            {
                if (_subQuestions == null)
                {
                    if (Type != QuestionType.Grid && Type != QuestionType.Grid3D && Type != QuestionType.MultiOpen)
                        return null;

                    _subQuestions = new List<SubQuestion>();

                    if (_inputElements.Count == 0)
                        return _subQuestions;

                    IHTMLElement container = InputElements[0].parentElement;
                    do
                    {
                        // Move to table that is input elements container
                        container = container.parentElement;
                    }
                    while (container != null &&
                        !container.tagName.Equals("TABLE", StringComparison.InvariantCultureIgnoreCase));

                    _subQuestions = GetSubQuestionList((IHTMLTable)container, Type);
                }
                return _subQuestions;
            }
        }

        /// <summary>
        /// Gets active subquestion for current question
        /// </summary>
        public SubQuestion ActiveSubQuestion
        {
            get
            {
                foreach (var subQuestion in SubQuestions)
                {
                    if (subQuestion.Active)
                    {
                        return subQuestion;
                    }
                }
                return null;
            }
        }

        public void ResetAnswers()
        {
            _activeAnswers = null;
            _inputElements = null;
        }

        /// <summary>
        /// Gets active answers for current question
        /// </summary>
        public AnswerCollection ActiveAnswers
        {
            get
            {
                if (_activeAnswers == null)
                {
                    if (Type != QuestionType.Grid &&
                        Type != QuestionType.Grid3D &&
                        Type != QuestionType.MultiOpen)
                    {
                        _activeAnswers = new AnswerCollection(InputElements);
                    }
                    else
                    {
                        if (ActiveSubQuestion != null)
                        {
                            _activeAnswers = new AnswerCollection(ActiveSubQuestion.InputElements);
                        }
                    }
                }

                return _activeAnswers;
            }
            set
            {
                _activeAnswers = value;
            }
        }

        /// <summary>
        /// Return collection of all html elements for current question
        /// </summary>
        public IList<IHTMLElement> InputElements
        {
            get
            {
                if (_inputElements != null)
                {
                    return _inputElements;
                }

                var foundInputElements = new List<IHTMLElement>();

                var elements = ((IHTMLElement2)RootElement).getElementsByTagName("INPUT");

                foreach (IHTMLElement element in elements)
                {
                    if (((IHTMLInputElement)element).name != null &&
                        !((IHTMLInputElement)element).name.Equals("__Type", StringComparison.OrdinalIgnoreCase))
                    {
                        foundInputElements.Add(element);
                    }
                }

                elements = ((IHTMLElement2)RootElement).getElementsByTagName("TEXTAREA");

                foreach (IHTMLElement element in elements)
                {
                    foundInputElements.Add(element);
                }

                elements = ((IHTMLElement2)RootElement).getElementsByTagName("SELECT");

                foreach (IHTMLElement element in elements)
                {
                    foundInputElements.Add(element);
                    //subscribes for onchange event for monitoring purposes
                    ((HTMLSelectElementEvents2_Event)element).onchange += Question_SelectElement_OnChange;
                }

                foundInputElements = foundInputElements.OrderBy(x => x.sourceIndex).ToList();

                _inputElements = foundInputElements;
                return _inputElements;
            }
        }

        public bool IsCellClick { get; internal set; }

        public void OnInputChangedFromKeyboard(string elementId)
        {
            if (InputChangedFromKeyboard != null)
                InputChangedFromKeyboard(this, new InputChangedFromKeyboardEventArgs(elementId));
        }

        /// <summary>
        /// IHTMLElement (SelectElement) Value change event handler
        /// </summary>
        /// <param name="pEvtObj"></param>
        void Question_SelectElement_OnChange(IHTMLEventObj pEvtObj)
        {
            IHTMLElement srcElement = pEvtObj.srcElement;

            if (srcElement is IHTMLSelectElement)
            {
                var el = srcElement as IHTMLSelectElement;

                if (AnswerElementValueChanged != null)
                {
                    var arg = new AnswerElementValueChangedEventArgs
                    {
                        ElementId = srcElement.id,
                        ElementValue = el.value
                    };
                    AnswerElementValueChanged(this, arg);
                }
            }
        }

        /// <summary>
        /// Handler for ActiveSubQuestionChanged event
        /// </summary>
        /// <remarks>
        /// Occurs when subquestion is changed by user
        /// </remarks>
        void Question_ActiveSubQuestionChanged(object sender, EventArgs e)
        {
            _activeAnswers = null;
        }

        ///<summary>
        /// Fill active input elements by passed value
        /// It is used for keyboard support
        ///</summary>
        public void ProcessEnterData(string inputValue)
        {
            if (ActiveAnswers.Count == 0) return;

            try
            {
                if (Type == QuestionType.Open || Type == QuestionType.DatePicker)
                {
                    var answer = ActiveAnswers[0];

                    if (answer.IsDisabled == false &&
                        (answer.TagName == TagNames.TEXTAREA ||
                        answer.TagName == TagNames.INPUT))
                    {
                        answer.Value = inputValue;
                    }
                }
                else if (Type == QuestionType.MultiOpen)
                {
                    var answer = ActiveAnswers[0];
                    if (answer.IsDisabled == false &&
                        (answer.TagName == TagNames.TEXTAREA ||
                        answer.TagName == TagNames.INPUT))
                    {
                        answer.Value = inputValue;
                        answer.FireKeyUpEvent();
                    }
                }
                else if (Type == QuestionType.SearchableMulti)
                {
                    var answer = ActiveAnswers[0];

                    if (answer.TagName == TagNames.INPUT)
                    {
                        answer.Value = inputValue;
                        answer.FireKeyDownEvent();
                    }
                }
                else if (Type == QuestionType.CaptureOrder)
                {
                    ProcessEnterDataForCaptureOrder(inputValue, false);
                }
                else
                {
                    var answerIndex = 0;
                    var inputUserAnswers = inputValue.Split(new[] { ',' }).Select(c => c.Trim()).ToArray();

                    for (var i = 0; i < ActiveAnswers.Count; i++)
                    {
                        if (answerIndex >= inputUserAnswers.Length)
                            return;

                        var answer = ActiveAnswers[i];

                        if (answer.IsDisabled)
                        {
                            continue;
                        }

                        /* when we have multiple active answers and "other" answer
                         * we should suppress keyboard input, because in such case
                         * "other" answer captures input.
                         */
                        if (answer.IsOther && ActiveAnswers.Count > 1)
                        {
                            continue;
                        }

                        if (answer.TagName == TagNames.INPUT)
                        {
                            if (answer.ElementType == ElementTypes.Checkbox ||
                                answer.ElementType == ElementTypes.Radio)
                            {
                                if (inputUserAnswers.Contains(answer.PreCode))
                                {
                                    if (IsImageButtons)
                                    {
                                        IHTMLElement el = new HtmlFinder(RootElement.document).Find(TagNames.IMG, "inputId", answer.ElementId);

                                        if (el != null)
                                        {
                                            var dummy = new object();
                                            ((HTMLImg)el).FireEvent("onclick", ref dummy);

                                            if (answer.HasOther)
                                            {
                                                answer.Focus();
                                            }

                                            continue;
                                        }
                                    }

                                    if (answer.IsSinglePunch ||
                                        answer.ElementType == ElementTypes.Radio)
                                    {
                                        ActiveAnswers.UnselectAnswers(false);
                                    }

                                    if (ActiveAnswers.HasSinglePunchAnswers)
                                    {
                                        ActiveAnswers.UnselectAnswers(true);
                                    }

                                    answer.Checked = !answer.Checked;
                                    answer.FireClickEvent();

                                    OnInputChangedFromKeyboard(answer.ElementId);

                                    if (answer.HasOther)
                                    {
                                        answer.SetOtherValue();

                                        if (answer.Checked)
                                        {
                                            answer.Focus();
                                        }
                                    }
                                }
                            }
                            else if (answer.ElementType == ElementTypes.TextInput)
                            {
                                OnInputChangedFromKeyboard(answer.ElementId);

                                answer.Value = inputUserAnswers[answerIndex];
                                answerIndex++;
                            }
                        }
                        else if (answer.TagName == TagNames.TEXTAREA)
                        {
                            answer.Value = inputUserAnswers[answerIndex];
                            answerIndex++;
                        }
                        else if (answer.TagName == TagNames.SELECT)
                        {
                            /*In 3D-Grid question with Grid question inside with enabled DropDown option
                              several drop-down can be active at the same time
                            */

                            var optionIndex = -1;

                            if (int.TryParse(inputUserAnswers[answerIndex], out optionIndex))
                            {
                                answer.SelectedIndex = optionIndex;
                            }
                            answerIndex++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        /// <summary>
        /// Set answer for question by element
        /// </summary>
        /// <param name="element">target element for what new value should be set</param>
        /// <param name="elementValue">new value for element</param>
        /// <returns>true if new value was set otherwise false</returns>
        public bool SetAnswer(IHTMLElement element, string elementValue)
        {
            if (ActiveAnswers.Count == 0) return false;

            Answer answer = null;

            foreach (var answ in ActiveAnswers)
            {
                if (answ.ElementId == element.id ||
                    (answ.HasOther && answ.OtherElementId == element.id))
                {
                    answer = answ;
                }
            }

            if (answer == null) return false;

            if (answer.TagName == TagNames.INPUT)
            {
                if (answer.ElementType == ElementTypes.Checkbox ||
                    answer.ElementType == ElementTypes.Radio)
                {
                    if (Answer.GetTypeByElement(element) == ElementTypes.Radio ||
                        Answer.GetTypeByElement(element) == ElementTypes.Checkbox)
                    {
                        if (answer.ElementType == ElementTypes.Radio)
                        {
                            ActiveAnswers.UnselectAnswers(false);
                        }

                        if (Type == QuestionType.RankedOrder)
                        {
                            answer.Checked = !string.IsNullOrEmpty(elementValue);
                            answer.Value = elementValue;
                        }
                        else
                        {
                            answer.Checked = bool.Parse(elementValue);
                        }

                        if (answer.HasOther)
                        {
                            answer.SetOtherValue();
                        }
                    }
                    else if (Answer.GetTypeByElement(element) == ElementTypes.TextInput)
                    {
                        if (answer.ElementType == ElementTypes.Radio &&
                            !string.IsNullOrEmpty(elementValue))
                        {
                            ActiveAnswers.UnselectAnswers(false);
                        }
                        answer.Checked = !string.IsNullOrEmpty(elementValue);
                        answer.SetOtherValue(elementValue);
                    }
                }
                else if (answer.ElementType == ElementTypes.TextInput)
                {
                    answer.Value = elementValue;
                }
            }

            return false;
        }

        /// <summary>
        /// Set default answer for question
        /// </summary>
        /// <param name="navigateToNextQuestion"><c>true</c> if we should navigate to next question; otherwise <c>false</c>.</param>
        /// <param name="keepFocus"><c>true</c> if we should not move focus into input field on status bar; otherwise <c>false</c>.</param>        
        public void SetDefaultAnswer(out bool navigateToNextQuestion, out bool keepFocus)
        {
            SetAnswerByPrecode(DefaultAnswerPrecode, out navigateToNextQuestion, out keepFocus);
        }

        /// <summary>
        /// Set refused answer for question
        /// </summary>
        /// <param name="navigateToNextQuestion"><c>true</c> if we should navigate to next question; otherwise <c>false</c>.</param>
        /// <param name="keepFocus"><c>true</c> if we should not move focus into input field on status bar; otherwise <c>false</c>.</param>        

        public void SetRefusedAnswer(out bool navigateToNextQuestion, out bool keepFocus)
        {
            SetAnswerByPrecode(RefusedAnswerPrecode, out navigateToNextQuestion, out keepFocus);
        }

        /// <summary>
        /// Scrolls page to current question
        /// </summary>
        public void ScrollIntoView()
        {
            try
            {
                // scroll into current question.
                if (RootElement.tagName.Equals("TABLE", StringComparison.InvariantCultureIgnoreCase))
                    RootElement.scrollIntoView(true);
                else if (RootElement.tagName.Equals("DIV", StringComparison.InvariantCultureIgnoreCase))
                    RootElement.scrollIntoView(true);
                else
                {
                    IHTMLElement element = null;
                    if (((IHTMLElement2)RootElement).getElementsByTagName("TABLE").length > 0)
                        element = (IHTMLElement)((IHTMLElement2)RootElement).getElementsByTagName("TABLE").item(null, 0);
                    else if (((IHTMLElement2)RootElement).getElementsByTagName("DIV").length > 0)
                        element = (IHTMLElement)((IHTMLElement2)RootElement).getElementsByTagName("DIV").item(null, 0);
                    if (element != null)
                    {
                        if (element.tagName.Equals("TABLE", StringComparison.InvariantCultureIgnoreCase))
                            element.scrollIntoView(true);
                        else
                            element.scrollIntoView(true);
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                /*Do nothing. This exception occurs when browser isn't ready for scroll operation.
                  Most common reason is the page hasn't been completely loaded.*/
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        /// <summary>
        /// Return true if current question equals passed question
        /// </summary>
        public override bool Equals(Object obj)
        {
            if (obj == null || GetType() != obj.GetType()) return false;

            var q = (Question)obj;

            return (Id == q.Id);
        }

        /// <summary>
        /// Returns hash code
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        /// <summary>
        /// Returns active HTML elements for current question
        /// </summary>
        public IList<IHTMLElement> GetActiveInputElements()
        {
            if (Type != QuestionType.Grid &&
                Type != QuestionType.Grid3D &&
                Type != QuestionType.MultiOpen)
                return InputElements;

            foreach (var subQuestion in SubQuestions)
            {
                if (subQuestion.Active)
                    return subQuestion.InputElements;
            }

            return new List<IHTMLElement>();
        }

        /// <summary>
        /// Unselect all answers for current question
        /// </summary>
        /// <remarks>
        /// It is used when user select 'Exclusive' answer
        /// </remarks>
        public void AddSubQuestionsToHtmlSubQuestionDictionary()
        {
            try
            {
                if (Type == QuestionType.Grid ||
                    Type == QuestionType.Grid3D ||
                    Type == QuestionType.MultiOpen)
                {
                    foreach (var subQuestion in SubQuestions)
                    {
                        foreach (var inputElement in subQuestion.InputElements)
                        {
                            _elementSubQuestionDictionary.Add(inputElement, subQuestion);

                            if (_elementSubQuestionDictionary.ContainsKey(inputElement.parentElement) == false)
                            {
                                _elementSubQuestionDictionary.Add(inputElement.parentElement, subQuestion);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(String.Format(Strings.Exception_PageParsingError, QuestionId, ""), ex);
            }
        }

        /// <summary>
        /// Checks if question has "other" answer and it's value is not empty.
        /// </summary>
        /// <remarks>
        /// Input element has to be casted to HTMLInputElement 
        /// but not IHTMLInputElement, because this casting doesn't work for TextArea element
        /// </remarks>
        /// <returns>true, if question contains "other" answer with value; otherwise false.</returns>
        private bool CheckOtherAnswerPresence()
        {
            var result = false;

            if (InputElements == null)
            {
                return false;
            }

            foreach (IHTMLElement element in InputElements)
            {
                /* We are looking for input with "_other" endind. For example, for question q1 answer 1.
                       It should look something like "q1_1_other". If exists it means that question has "other" answer.    */

                if (String.IsNullOrEmpty(element.id) || element.id.Length <= 6)
                    continue;

                var elementType = Answer.GetTypeByElement(element);

                if ((elementType != ElementTypes.TextInput && elementType != ElementTypes.TextArea))
                    continue;

                var subId = element.id.Substring(element.id.Length - 6);

                var value = elementType == ElementTypes.TextInput ? ((IHTMLInputElement)element).value :
                    ((IHTMLTextAreaElement)element).value;

                if (!String.IsNullOrEmpty(subId) && subId.ToLower() == "_other" && !String.IsNullOrEmpty(value))
                {
                    result = true;
                    break;
                }
            }

            return result;
        }

        /// <summary>
        /// Returns question type for current question by passed HTMLElement
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        private QuestionType GetQuestionType(IHTMLInputElement element)
        {
            if (IsInfoQuestion(element))
            {
                return QuestionType.Info;
            }

            if (element.value.StartsWith("grid3d", StringComparison.InvariantCultureIgnoreCase))
            {
                return QuestionType.Grid3D;
            }
            if (element.value.StartsWith("grid", StringComparison.InvariantCultureIgnoreCase))
            {
                return QuestionType.Grid;
            }
            if (element.value.StartsWith("open", StringComparison.InvariantCultureIgnoreCase))
            {
                return QuestionType.Open;
            }
            if (element.value.StartsWith("ranking", StringComparison.InvariantCultureIgnoreCase))
            {
                return QuestionType.Ranking;
            }
            if (element.value.StartsWith("searchablemulti", StringComparison.InvariantCultureIgnoreCase))
            {
                return QuestionType.SearchableMulti;
            }
            if (element.value.StartsWith("multi", StringComparison.InvariantCultureIgnoreCase))
            {
                if (InputElements.Count == 0)
                {
                    return QuestionType.Multi;
                }
                foreach (IHTMLElement inputElement in InputElements)
                {
                    if (((Answer.GetTagNameByElement(inputElement) == TagNames.INPUT && Answer.GetTypeByElement(inputElement) == ElementTypes.TextInput) ||
                        Answer.GetTagNameByElement(inputElement) == TagNames.TEXTAREA) == false)
                    {
                        return QuestionType.Multi;
                    }
                }

                return QuestionType.MultiOpen;
            }

            return QuestionType.Simple;
        }

        private bool IsInfoQuestion(IHTMLInputElement element)
        {
            return element.value.StartsWith("info", StringComparison.InvariantCultureIgnoreCase);
        }

        /// <summary>
        /// Return question id for passed input element
        /// </summary>
        ///<remarks>
        ///Parses following format string <input type="hidden" name="__type" id="3" questionId="q3" value="multi"/>
        /// </remarks>
        private string GetQuestionId(IHTMLInputElement element)
        {
            object obj = ((IHTMLElement)element).getAttribute("questionId");

            if (obj != null)
            {
                return obj.ToString();
            }

            Logger.Write(Strings.Log_ParseErrorQuestionIdIsAbsent, MessageTypes.Error);

            return String.Empty;
        }

        private string GetQuestionTitle(IHTMLElement rootElement)
        {
            var result = String.Empty;
            var elementId = QuestionId + "_title";

            IHTMLElement el = ((IHTMLDocument3)(rootElement.document)).getElementById(elementId);

            if (el != null)
            {
                result = el.innerText;
            }

            return result;
        }

        private string GetQuestionText(IHTMLElement rootElement)
        {
            var result = String.Empty;
            var elementId = QuestionId + "_text";

            IHTMLElement el = ((IHTMLDocument3)(rootElement.document)).getElementById(elementId);

            if (el != null)
            {
                result = el.innerText;
            }

            return result;
        }

        /// <summary>
        /// Set answer for question by precode
        /// </summary>
        /// <param name="precode">Answer precode.</param>
        /// <param name="navigateToNextQuestion"><c>true</c> if we should navigate to next question; otherwise <c>false</c>.</param>
        /// <param name="keepFocus"><c>true</c> if we should not move focus into input field on status bar; otherwise <c>false</c>.</param>        
        /// <returns></returns>
        /// <remarks>
        /// Formats:
        /// multy (checkboxes): <input tabindex="10" type="checkbox" name="q3_pre1" id="q3_pre1" value="1"/>
        /// dropdown list: <select  name="q1" id="q1"> <option value="pre1" selected="selected">1</option></select>
        /// single (radio buttons): <input type="radio" name="q4" id="q4_a1" value="a1"/>
        /// </remarks>
        private void SetAnswerByPrecode(string precode, out bool navigateToNextQuestion, out bool keepFocus)
        {
            navigateToNextQuestion = true;
            keepFocus = false;

            if (String.IsNullOrEmpty(precode))
            {
                return;
            }

            if (Type == QuestionType.Open ||
                Type == QuestionType.DatePicker ||
                _questionType == QuestionType.Grid ||
                _questionType == QuestionType.Grid3D)
            {
                return;
            }

            var elementId = string.Format("{0}_{1}", QuestionId, precode);

            if (Type == QuestionType.CaptureOrder)
            {
                var answer = ActiveAnswers.FirstOrDefault(
                    x => x.PreCode.Equals(precode, StringComparison.InvariantCultureIgnoreCase));

                if (answer == null)
                {
                    return;
                }

                ProcessEnterDataForCaptureOrder(precode, true);
                navigateToNextQuestion = GetOtherByElementId(answer.ElementId) == null;
                keepFocus = true;

                return;
            }

            if (Type == QuestionType.MultiOpen)
            {
                var subQuestion = FindSubQuestionByElementId(elementId);
                if (subQuestion == null)
                {
                    // sub-question with such precode wasn't found
                    navigateToNextQuestion = false;
                    keepFocus = true;
                    return;
                }

                ActivateSubQuestion(GetSubQuestionIndex(subQuestion));
                navigateToNextQuestion = false;
            }
            else if (Type == QuestionType.Simple
                && ActiveAnswers.Count == 1
                && ActiveAnswers[0].TagName == TagNames.SELECT)
            {
                // It's single question with drop down list
                ActiveAnswers[0].Value = precode;
            }
            else
            {
                // flag indicates whether any answer has been modified
                var affected = false;

                for (var i = 0; i < ActiveAnswers.Count; i++)
                {
                    var answer = ActiveAnswers[i];

                    if (String.Equals(answer.ElementId, elementId, StringComparison.InvariantCultureIgnoreCase))
                    {
                        if (answer.TagName == TagNames.INPUT)
                        {
                            if (answer.ElementType == ElementTypes.Checkbox ||
                                answer.ElementType == ElementTypes.Radio)
                            {
                                if (answer.IsSinglePunch ||
                                    answer.ElementType == ElementTypes.Radio)
                                {
                                    ActiveAnswers.UnselectAnswers(false);
                                    affected = true;
                                }

                                if (ActiveAnswers.HasSinglePunchAnswers)
                                {
                                    ActiveAnswers.UnselectAnswers(true);
                                    affected = true;
                                }

                                if (answer.IsDisabled == false)
                                {
                                    answer.Checked = true;
                                    affected = true;
                                    if (answer.HasOther)
                                    {
                                        answer.SetOtherValue();
                                    }
                                }

                                if (answer.HasOther)
                                {
                                    answer.Focus();
                                    navigateToNextQuestion = false;
                                    keepFocus = true;
                                }
                            }
                        }
                        else if (answer.TagName == TagNames.SELECT)
                        {
                            answer.Value = precode;
                            affected = true;
                        }
                    }
                }

                if (affected == false)
                {
                    // seems no answers were affected, so we shouldn't leave current question
                    navigateToNextQuestion = false;
                    keepFocus = true;
                }
            }
        }

        /// <summary>
        /// Processing input data for Multi with Capture Order option selected
        /// </summary>
        /// <param name="inputValue">Precode or list of comma-delimited precodes</param>
        /// <param name="notUnselect">If true we not click checkbox or radio if it is already checked so input keeps its state</param>
        private void ProcessEnterDataForCaptureOrder(string inputValue, bool notUnselect)
        {
            var inputUserAnswers = inputValue.Split(new[] { ',' }).Select(c => c.Trim());

            foreach (var inputAnswer in inputUserAnswers)
            {
                var answer = ActiveAnswers.FirstOrDefault(x => x.PreCode == inputAnswer);

                if (answer == null)
                {
                    continue;
                }

                if (notUnselect == false || string.IsNullOrEmpty(answer.Value))
                {
                    FireClickEventByElementId(answer.ElementId + "__");
                }

                LookupAndFocusOther(answer);
            }
        }

        private IHTMLElement GetOtherByElementId(string elementId)
        {
            return InputElements.FirstOrDefault(
                    x => x.id.Equals(elementId + "_other", StringComparison.InvariantCultureIgnoreCase));
        }

        private void LookupAndFocusOther(Answer answer)
        {
            var otherElement = GetOtherByElementId(answer.ElementId);
            if (otherElement == null)
            {
                return;
            }

            if (answer.HasOther == false)
            {
                answer.SetOtherElement(otherElement);
            }

            if (answer.IsOtherDisabled == false && string.IsNullOrEmpty(answer.Value) == false)
            {
                answer.FocusOtherElement();
            }
        }

        private void FireClickEventByElementId(string elementId)
        {
            ExecuteJavaScript(string.Format("document.getElementById('{0}').click()", elementId));
        }

        private void ExecuteJavaScript(string script)
        {
            HTMLWindow2 window = (HTMLWindow2)(((IHTMLDocument)(RootElement.document)).Script);
            window.execScript(script, "javascript");
        }

        /// <summary>
        /// Return SubQuestion collection accoding question HTMLTable element
        /// Seach in each table row input elements
        /// </summary>
        /// <param name="container"></param>
        /// <param name="questionType"></param>
        /// <returns></returns>
        private List<SubQuestion> GetSubQuestionList(IHTMLTable container, QuestionType questionType)
        {
            if (questionType == QuestionType.Grid)
            {
                return GetSubQuestionListForGridQuestion(container);
            }
            if (questionType == QuestionType.Grid3D)
            {
                return GetSubQuestionListForGrid3DQuestion(container);
            }
            if (questionType == QuestionType.MultiOpen)
            {
                return GetSubQuestionListForMultiOpenQuestion();
            }

            return null;
        }

        private List<SubQuestion> GetSubQuestionListForGridQuestion(IHTMLTable container)
        {
            var subQuestionList = new List<SubQuestion>();
            foreach (IHTMLElement2 element in container.rows)
            {
                var inputElementList = new List<IHTMLElement>();
                CollectInputElementForEachTableRow(inputElementList, element);

                if (inputElementList.Count > 0)
                {
                    var subQuestion = new SubQuestion(this, inputElementList, _highlightQuestion);
                    subQuestionList.Add(subQuestion);
                }
            }
            return subQuestionList;
        }

        private List<SubQuestion> GetSubQuestionListForGrid3DQuestion(IHTMLTable container)
        {
            var inputElementList = new List<IHTMLElement>();
            var prefixInputElementIds = new List<string>();

            foreach (IHTMLElement2 element in container.rows)
            {
                CollectInputElementForEachTableRow(inputElementList, element);
            }

            foreach (IHTMLElement element in inputElementList)
            {
                var elementId = element.id;

                if (elementId.EndsWith("other") == false)
                {
                    var index = elementId.LastIndexOf("_", StringComparison.Ordinal);
                    var prefix = elementId.Substring(0, index);

                    if (prefixInputElementIds.Contains(prefix) == false)
                    {
                        prefixInputElementIds.Add(prefix);
                    }
                }
            }

            var subQuestionList = new List<SubQuestion>();

            for (var index = 0; index < prefixInputElementIds.Count; index++)
            {
                var list = inputElementList.Where(inputElement => inputElement.id.StartsWith(prefixInputElementIds[index] + "_")).ToList();

                subQuestionList.Add(new SubQuestion(this, list, _highlightQuestion));
            }

            return subQuestionList;
        }

        private List<SubQuestion> GetSubQuestionListForMultiOpenQuestion()
        {
            var subQuestionList = new List<SubQuestion>();
            foreach (IHTMLElement inputElement in InputElements)
            {
                var inputElementList = new List<IHTMLElement>(1);
                inputElementList.Add(inputElement);
                var subQuestion = new SubQuestion(this, inputElementList, _highlightQuestion);
                subQuestionList.Add(subQuestion);
            }
            return subQuestionList;
        }

        private void CollectInputElementForEachTableRow(List<IHTMLElement> inputElementList, IHTMLElement2 element)
        {
            IHTMLElementCollection inputElementCol = element.getElementsByTagName("INPUT");
            AddElementCollectionToList(inputElementList, inputElementCol);

            inputElementCol = element.getElementsByTagName("TEXTAREA");
            AddElementCollectionToList(inputElementList, inputElementCol);

            inputElementCol = element.getElementsByTagName("SELECT");
            AddElementCollectionToList(inputElementList, inputElementCol);
        }

        private void AddElementCollectionToList(List<IHTMLElement> inputElementList, IHTMLElementCollection inputElementCol)
        {
            foreach (IHTMLElement inputElement in inputElementCol)
            {
                inputElementList.Add(inputElement);
            }
        }

        /// <summary>
        /// Determines if current question type should support
        /// predefined answers. For now we have 2 predefined answers - 
        /// default and refused.
        /// </summary>
        /// <returns><c>true</c> if current question supports default and refused
        /// answers; otherwise <c>false</c>.</returns>
        private bool ArePredefinedAnswersSupported()
        {
            return Type != QuestionType.RankedOrder &&
                   Type != QuestionType.SearchableMulti &&
                   Type != QuestionType.GridBars &&
                   Type != QuestionType.CardSort &&
                   Type != QuestionType.GridSlider;
        }

        /// <summary>
        /// Set focus in text area for 'text' question
        /// </summary>
        public void DoEdit()
        {
            if (ActiveAnswers.Count > 0)
            {
                ActiveAnswers[0].Focus();
            }
        }

        /// <summary>
        /// Check subquestion with current question
        /// </summary>
        /// <returns> Return true if current question has subquestion otherwise return false</returns>
        public bool HasSubQuestion()
        {
            if (SubQuestions == null || SubQuestions.Count == 0) return false;

            if (Type == QuestionType.Grid ||
                Type == QuestionType.Grid3D ||
                Type == QuestionType.MultiOpen)
                return true;

            return false;
        }

        /// <summary>
        /// Activate subquestion by subQuestion intex in SubQuestion collection
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public bool ActivateSubQuestion(int index)
        {
            if (SubQuestions == null || SubQuestions.Count == 0) return false;
            if (index < 0 || index > SubQuestions.Count - 1) return false;

            if (Type == QuestionType.Grid ||
                Type == QuestionType.Grid3D ||
                Type == QuestionType.MultiOpen)
            {
                for (var i = 0; i < SubQuestions.Count; i++)
                {
                    SubQuestions[i].Active = false;
                }

                SubQuestions[index].Active = true;
                SubQuestions[index].ScrollIntoView();

                if (ActiveSubQuestionChanged != null)
                {
                    ActiveSubQuestionChanged(null, EventArgs.Empty);
                }

                return true;
            }

            return false;
        }

        /// <summary>
        /// Do active first subquestion of current question
        /// It is used only for Grid and 3DGrid question
        /// </summary>
        /// <returns>return true if activation finish with success</returns>
        public bool ActivateFirstSubQuestion()
        {
            return ActivateSubQuestion(0);
        }

        /// <summary>
        /// Do active last subquestion of current question
        /// It is used only for Grid and 3DGrid question
        /// </summary>
        /// <returns>return true if activation finish with success</returns>
        public bool ActivateLastSubQuestion()
        {
            if (SubQuestions == null) return false;

            var count = SubQuestions.Count;
            return ActivateSubQuestion(count - 1);
        }

        public bool ActivatePrevSubQuestion()
        {
            var index = GetActiveSubquestionIndex();
            if (index >= 1)
            {
                ActivateSubQuestion(index - 1);
                return true;
            }
            return false;
        }

        public bool ActivateNextSubQuestion()
        {
            var index = GetActiveSubquestionIndex();
            if (index >= 0 && index + 1 < SubQuestions.Count)
            {
                ActivateSubQuestion(index + 1);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Return question by IHTMLElement
        /// It is used for detect question in case when user click on IHTMLElement
        /// </summary>
        public SubQuestion FindSubQuestion(IHTMLElement element)
        {
            if (_elementSubQuestionDictionary.ContainsKey(element))
                return _elementSubQuestionDictionary[element];

            return null;
        }

        /// <summary>
        /// Return index of passed Subquestion
        /// If Subquestion wasn't found return -1
        /// </summary>
        /// <param name="subQuestion"></param>
        /// <returns></returns>
        public int GetSubQuestionIndex(SubQuestion subQuestion)
        {
            var result = -1;
            if (SubQuestions == null) return result;
            for (var index = 0; index < SubQuestions.Count; index++)
            {
                var subQue = SubQuestions[index];
                if (subQue.Id == subQuestion.Id)
                {
                    return index;
                }
            }
            return result;
        }

        /// <summary>
        /// Return index of current active subquestion of current question in SubQuestion collection
        /// </summary>
        /// <returns></returns>
        public int GetActiveSubquestionIndex()
        {
            var result = -1;
            if (SubQuestions == null) return result;

            for (var index = 0; index < SubQuestions.Count; index++)
            {
                var subquestion = SubQuestions[index];
                if (subquestion.Active)
                {
                    return index;
                }
            }
            return result;
        }

        /// <summary>
        /// Return question by IHTMLElement
        /// It is used for detect question in case when user click on IHTMLElement
        /// </summary>
        private SubQuestion FindSubQuestionByElementId(string elementId)
        {
            foreach (IHTMLElement el in _elementSubQuestionDictionary.Keys)
            {
                if (el.id == elementId)
                {
                    return _elementSubQuestionDictionary[el];
                }
            }
            return null;
        }

        public void Unsubscribe()
        {
            foreach (var element in InputElements.Where(x=>x.tagName.Equals("SELECT", StringComparison.OrdinalIgnoreCase)))
            {
                ((HTMLSelectElementEvents2_Event)element).onchange -= Question_SelectElement_OnChange;
            }
        }
    }
}