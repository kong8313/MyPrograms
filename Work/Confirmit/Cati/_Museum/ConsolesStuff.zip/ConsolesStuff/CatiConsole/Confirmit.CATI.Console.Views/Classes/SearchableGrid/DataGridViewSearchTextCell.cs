﻿
#region Usings
using System;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;
#endregion

namespace Confirmit.CATI.Console.Views.Classes.SearchableGrid
{
    /// <summary>
    /// Implements TextCell for Searchable grid
    /// </summary>
    public class DataGridViewSearchTextCell : DataGridViewTextBoxCell
    {
        #region Fields

        private static Type cellType = typeof(DataGridViewSearchTextCell);
        private static Type valueType = typeof(string);
        private static Type editorType = typeof(DataGridViewSearchTextEditingControl);

        #endregion        

        #region Properties

        /// <summary>
        /// Flag indicated is 'enter' key pressed or not
        /// </summary>
        public bool HasEnterPressed
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public DataGridViewSearchTextCell()
            : base()
        {
        }

        #endregion

        #region DataGridViewTextBoxCell

        public override Type EditType
        {
            get { return editorType; }
        }

        public override Type ValueType
        {
            get { return valueType; }
        }        

        public override void InitializeEditingControl(int rowIndex, object initialFormattedValue, DataGridViewCellStyle dataGridViewCellStyle)
        {
            base.InitializeEditingControl(rowIndex, initialFormattedValue, dataGridViewCellStyle);

            HasEnterPressed = false;

            DataGridViewSearchTextEditingControl editingControl
                = base.DataGridView.EditingControl as DataGridViewSearchTextEditingControl;
            
            if (editingControl != null)
            {
                if (Value == null || Value is DBNull)
                    editingControl.Text = (string)DefaultNewRowValue;
                else
                    editingControl.Text = (string)Value;
            }

            editingControl.PreviewKeyDown += new PreviewKeyDownEventHandler(editingControl_PreviewKeyDown);
        }        

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public override void DetachEditingControl()
        {
            DataGridView dataGridView = base.DataGridView;

            if ((dataGridView == null) || (dataGridView.EditingControl == null))
            {
                throw new InvalidOperationException();
            }

            DataGridViewSearchTextEditingControl editingControl
                = base.DataGridView.EditingControl as DataGridViewSearchTextEditingControl;            

            if (editingControl != null)
            {
                editingControl.ClearUndo();
            }

            editingControl.PreviewKeyDown -= new PreviewKeyDownEventHandler(editingControl_PreviewKeyDown);

            base.DetachEditingControl();
        }

        #endregion        

        #region Methods

        void editingControl_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                HasEnterPressed = true;
            }
        }                

        #endregion       
    }	
}
