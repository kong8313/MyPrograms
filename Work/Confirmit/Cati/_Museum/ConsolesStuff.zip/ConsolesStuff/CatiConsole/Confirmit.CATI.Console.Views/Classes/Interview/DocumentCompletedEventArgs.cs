﻿using System;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    /// <summary>
    /// Class is used in communication between InterviewPage browser and InterviewPresenter
    /// </summary>
    public class DocumentCompletedEventArgs : EventArgs
    {
        private string m_PageContent;

        /// <summary>
        /// Get or set current html string. It represents current html page loaded into webBrowser
        /// </summary>
        public string PageContent
        {
            get 
            {
                return m_PageContent;
            }
            set
            {
                m_PageContent = value;
            }
        }
    }
}
