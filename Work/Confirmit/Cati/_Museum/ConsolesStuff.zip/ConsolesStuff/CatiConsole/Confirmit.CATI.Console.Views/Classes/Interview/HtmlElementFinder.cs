﻿using System;
using mshtml;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    public class HtmlFinder
    {
        private readonly IHTMLDocument3 _document;

        public HtmlFinder(IHTMLDocument3 document)
        {
            _document = document;
        }

        public IHTMLElement Find(TagNames tagName, String attributeName, string attributeValue)
        {
            var elements = _document.getElementsByTagName(tagName.ToString());

            /*Linq is not used intentionally. 
              For some reason it can significantly decrease performance. */

            for (int i = 0; i < elements.length; i++)
            {
                var element = (IHTMLElement)elements.item(i);
                var elementAttributeValue  = element.getAttribute(attributeName);
                
                if (elementAttributeValue is DBNull == false &&
                    elementAttributeValue.ToString() == attributeValue.ToString())

                    return element;
            }
            return null;
        }
    }
}
