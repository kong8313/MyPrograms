﻿using System;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    public interface IViewOnABreakControl : ILocalizableView
    {
        /// <summary>
        /// Occurs when user is going to logout after pending break.
        /// </summary>
        event EventHandler<EventArgs> LogoutClick;

        /// <summary>
        /// Occurs when user is going to continue work after pending break.
        /// </summary>
        event EventHandler<EventArgs> ContinueWorkClick;

        /// <summary>
        /// Gets/sets start time of a break.
        /// </summary>        
        DateTime StartTime { get; set; }

        string BreakTypeInfo { get; set; }

        void SetBreakType(bool displayBreakType, string breakTypeInfo);
    }
}