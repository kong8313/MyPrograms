﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
    /// <summary>
    /// Form is responsible for station identifier input
    /// </summary>
    public partial class StationIdForm : Form, IViewStationIdForm
    {
        #region Constructors
        public StationIdForm()
        {
            InitializeComponent();
        }
        #endregion

        #region IViewStationIdForm Members

        /// <summary>
        /// Occurs when user click OK button
        /// </summary>
        public event EventHandler<EventArgs> OkClick;

        /// <summary>
        /// Occurs when user click Cancel button
        /// </summary>
        public event EventHandler<CancelEventArgs> CancelClicking;

        /// <summary>
        /// Occurs when extension number name is going to be validated.
        /// </summary>
        public event EventHandler<CancelEventArgs> ValidatingStationId;

        /// <summary>
        /// Gets entered station identificator
        /// </summary>
        public string StationId
        {
            get { return this.tbStationId.Text.Trim(); }
            set { tbStationId.Text = value; }
        }

        /// <summary>
        /// Validates children controls.
        /// </summary>
        /// <returns></returns>
        public override bool ValidateChildren()
        {
            ClearValidationErrors();

            bool result = base.ValidateChildren();

            CancelEventArgs args = new CancelEventArgs();

            OnValidatingStationId(args);

            result &= !args.Cancel;

            return result;
        }

        /// <summary>
        /// Notifies user about validation error 
        /// </summary>
        /// <param name="message">Error message. Message shouldn't be empty.</param>
        public void AlertValidationError(string message)
        {
            erpStationId.SetError(tbStationId, message);
        }

        /// <summary>
        /// Clears all validation errors.
        /// </summary>
        public void ClearValidationErrors()
        {
            erpStationId.SetError(tbStationId, String.Empty);
        }

        /// <summary>
        /// Shows modal station form.
        /// </summary>
        /// <param name="parent">Parent window handle.</param>
        DialogResult IViewStationIdForm.Show(IWin32Window parent)
        {
            if (!this.Visible)
            {
                return  ShowDialog(parent);
            }

            return DialogResult.None;
        }

        #endregion

        #region ILocalizableView Members

        /// <summary>
        /// Localizes view according given localization information.
        /// </summary>
        /// <param name="manager">Localization manager which contains localization info.</param>
        public void Localize(ILocalizationManager manager)
        {
            Text = manager.GetString("StationIdForm_Caption");
            lbTitle.Text = manager.GetString("StationIdForm_Title");
            lbTitleDescription.Text = manager.GetString("StationIdForm_TitleDescription");
            btnOk.Text = manager.GetString("StationIdForm_ButtonOk_Text");
            btnCancel.Text = manager.GetString("StationIdForm_ButtonCancel_Text");
        }

        #endregion       

        #region Event handlers

        /// <summary>
        /// Ok button click event handler.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void btnOk_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
            {
                OnOkClick(e);
                DialogResult = DialogResult.OK;
                Close();
            }
        }

        /// <summary>
        /// Fires CancelClick event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }        

        private void StationIdForm_Shown(object sender, EventArgs e)
        {
            tbStationId.Focus();
        }

        private void StationIdForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (DialogResult == DialogResult.Cancel)
                {
                    CancelEventArgs args = new CancelEventArgs();
                    OnCancelClicking(args);

                    if (args.Cancel)
                    {
                        e.Cancel = true;
                    }
                }
            }
        } 

        #endregion

        #region Methods

        /// <summary>
        /// Fires ValidatingContactName event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnValidatingStationId(CancelEventArgs e)
        {
            if (ValidatingStationId != null)
            {
                ValidatingStationId(this, e);
            }
        }

        /// <summary>
        /// Fires OkClick event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnOkClick(EventArgs e)
        {
            if (OkClick != null)
            {
                OkClick(this, e);
            }
        }

        /// <summary>
        /// Fires CancelClick event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnCancelClicking(CancelEventArgs args)
        {
            if (CancelClicking != null)
            {
                CancelClicking(this, args);
            }
        }

        #endregion
    }
}
