﻿using System;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Controls
{
    public partial class OnABreakControl : UserControl, IViewOnABreakControl
    {
        private const int TimerInterval = 1; // in seconds
        private Timer m_Timer;
        private string _breakTypeLabelText = "Break Type: ";

        public OnABreakControl()
        {
            InitializeComponent();
        }

        public bool ButtonsEnabled
        {
            get { return tplButtons.Enabled; }
            set { tplButtons.Enabled = value; }
        }

        public void SetBreakType(bool displayBreakType, string breakTypeInfo)
        {
            if (displayBreakType && !string.IsNullOrEmpty(breakTypeInfo))
            {
                BreakTypeInfo = breakTypeInfo;
                
                breakType.Text = $"{_breakTypeLabelText}{BreakTypeInfo}";
                breakType.Visible = true;
            }
            else
            {
                breakType.Visible = false;
            }
        }

        public string BreakTypeInfo { get; set; }

        public event EventHandler<EventArgs> LogoutClick;

        public event EventHandler<EventArgs> ContinueWorkClick; 

        public DateTime StartTime
        {
            get;
            set;
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            OnLogoutClick(EventArgs.Empty);
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            OnContinueWorkClick(EventArgs.Empty);
        }

        private void OnABreakControl_VisibleChanged(object sender, EventArgs e)
        {
            if (Visible)
            {
                StartTimeCounting();
            }
            else
            {                
                StopTimeCounting();
            }
        }

        private void m_Timer_Tick(object sender, EventArgs e)
        {                        
            UpdateElapsedTimeText();
        }

        private void UpdateElapsedTimeText()
        {
             var elapsedTime = (DateTime.UtcNow - StartTime);

             lbElapsedTime.Text = string.Format("{0:00}:{1:00}:{2:00}", (int)elapsedTime.TotalHours, (int)elapsedTime.Minutes, (int)elapsedTime.Seconds);
        }

        private void OnLogoutClick(EventArgs args)
        {
            if (LogoutClick != null)
            {
                LogoutClick(this, args);
            }
        }

        private void OnContinueWorkClick(EventArgs args)
        {
            if (ContinueWorkClick != null)
            {
                ContinueWorkClick(this, args);
            }
        }

        /// <summary>
        /// Initializes and starts timer.
        /// </summary>
        private void StartTimeCounting()
        {            
            UpdateElapsedTimeText();            

            m_Timer = new Timer { Interval = 1000 * TimerInterval };
            m_Timer.Tick += m_Timer_Tick;
            m_Timer.Start();
        }

        /// <summary>
        /// Stops and releases timer.
        /// </summary>
        private void StopTimeCounting()
        {
            if (m_Timer == null) return;

            m_Timer.Stop();
            m_Timer.Tick -= m_Timer_Tick;
            m_Timer.Dispose();
            m_Timer = null;
        }

        public void Localize(Classes.Localization.ILocalizationManager manager)
        {
            lbDuration.Text =  manager.GetString("OnABreakControl_Duration_Text");
            lblTitle.Text = manager.GetString("OnABreakControl_Title_Text");
            btnLogout.Text = manager.GetString("OnABreakControl_Logout_Text");
            btnContinue.Text = manager.GetString("OnABreakControl_ContinueWork_Text");
            _breakTypeLabelText = manager.GetString("OnABreakControl_BreakTypeLabel_Text");
        }
    }         
}
