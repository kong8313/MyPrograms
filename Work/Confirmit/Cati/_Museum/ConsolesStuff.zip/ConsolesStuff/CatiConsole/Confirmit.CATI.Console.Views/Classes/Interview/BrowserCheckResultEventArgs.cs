﻿using System;
using System.Collections.Generic;
using Confirmit.CATI.Console.Views.Classes.Utilities;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    /// <summary>
    /// Represents BrowserCheckResultEventArgs event data.
    /// </summary>
    public class BrowserCheckResultEventArgs : EventArgs
    {
        public List<BrowserFeature> UnsupportedFeatures { get; set; }
    }
}