﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.SpellChecking;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using mshtml;

namespace Confirmit.CATI.Console.Views.Controls
{
    public abstract class BaseSurveyPageInteractor
    {
        private const string SoundFileNameItem = "__soundFileName";
        private const string AutoStartPlayingItem = "__autoStartPlaying";
        private const string ItsFinalItem = "__itsFinal";
        private const string TelephonyCommandType = "commandType";
        private const string DialCommandName = "Dial";
        private const string HangupCommandName = "Hangup";
        private const string InternalTransferCommandName = "InternalTransfer";
        private const string ExternalTransferCommandName = "ExternalTransfer";
        private const string AllowDialingCommandName = "AllowIgnoreDialing";
        private const string AllowDialingFlagElementName = "allowDialing";
        private const string TransferResourceItem = "transferResource";
        private const string DialTextItem = "dialingText";
        private const string DialPhoneItem = "telephone";
        private const string DialStatusItem = "__dialstatus";
        private const string ForcedAppointmentItem = "__forceappointment";
        private const string InterviewDurationItem = "__interviewDurationFinal";
        private const string StatusFinalItem = "__statusFinal";
        private const string DisableCatiMarkupAndKeyboardSupportName = "DisableCATIMarkupAndKeyboardSupport";
        private const string LParameterItem = "l";
        private const string ReviewInputValue = "REVIEW";
        private const string Http500Error = "500 - INTERNAL SERVER ERROR";

        protected ExtendedWebBrowser WebBrowser;

        public void ChangeLanguage(int languageId)
        {
            IHTMLDocument3 doc;
            IHTMLInputElement language;
            if (WebBrowser.Document != null &&
                (doc = (IHTMLDocument3)WebBrowser.Document.DomDocument) != null &&
                (language = (IHTMLInputElement)doc.getElementById(LParameterItem)) != null
            )
            {
                language.value = languageId.ToString(CultureInfo.InvariantCulture);
            }
        }

        public bool Is500ErrorPage
        {
            get
            {
                var page = GetPageContent();
                return (string.IsNullOrEmpty(page) == false && page.Contains(Http500Error));
            }
        }

        /// <summary>
        /// Return html of current page loaded into WebBrowser
        /// </summary>
        /// <returns></returns>
        public string GetPageContent()
        {
            String pageContent = String.Empty;

            try
            {
                if (WebBrowser.Document != null)
                {
                    //we need actual html for ajax monitoring
                    pageContent = ((IHTMLDocument3)WebBrowser.Document.DomDocument).documentElement.innerHTML;

                    var docType = GetDocumentType();

                    if (String.IsNullOrEmpty(docType) == false)
                    {
                        //add doctype line to output html
                        pageContent = pageContent.Insert(0, docType);
                    }

                    return pageContent;
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }

            return pageContent;
        }

        private string GetDocumentType()
        {
            if (WebBrowser.Document == null)
            {
                return string.Empty;
            }

            string pageTextContainingDocType;

            try
            {
                pageTextContainingDocType = WebBrowser.DocumentText;
            }
            catch (FileNotFoundException ex)
            {
                Logger.Write(ex);
                pageTextContainingDocType = WebBrowser.Document.All[0].InnerHtml;
            }

            var mc = Regex.Match(pageTextContainingDocType, @"\<\!DOCTYPE.+?\>", RegexOptions.IgnoreCase);

            return mc.Success ? mc.Value : string.Empty;
        }

        public bool IsOpenendReviewStartPage
        {
            get
            {
                bool result = false;

                if (WebBrowser.Document != null)
                {
                    HtmlElementCollection colls = WebBrowser.Document.GetElementsByTagName("input");
                    foreach (HtmlElement e in colls)
                    {
                        if (e.GetAttribute("value") == ReviewInputValue)
                        {
                            result = true;
                            break;
                        }
                    }
                }

                return result;
            }
        }

        public bool ContainsForcedAppointment
        {
            get
            {
                IHTMLDocument3 doc;
                if (WebBrowser.Document != null &&
                    (doc = (IHTMLDocument3)WebBrowser.Document.DomDocument) != null &&
                    doc.getElementById(ForcedAppointmentItem) != null)
                {
                    return true;
                }

                return false;
            }
        }

        public bool DisableCatiMarkupAndKeyboardSupport
        {
            get
            {
                object doc;
                bool isDisabled = WebBrowser.Document != null &&
                                  (doc = WebBrowser.Document.DomDocument) != null &&
                                  ((IHTMLDocument3)doc).getElementById(DisableCatiMarkupAndKeyboardSupportName) != null;

                return isDisabled;
            }
        }

        public string DialPhone
        {
            get
            {
                string result = String.Empty;

                IHTMLDocument3 doc;
                IHTMLInputElement text;
                if (WebBrowser.Document != null &&
                    (doc = (IHTMLDocument3)WebBrowser.Document.DomDocument) != null &&
                    (text = (IHTMLInputElement)doc.getElementById(DialPhoneItem)) != null)
                {
                    result = text.value ?? String.Empty;
                }

                return result;
            }
        }

        public TelephonyPageType TelephonyPage
        {
            get
            {
                var value = GetInputValueById(TelephonyCommandType);

                return ConvertTelephonyCommandToTelephonyPageType(value);
            }
        }

        private static TelephonyPageType ConvertTelephonyCommandToTelephonyPageType(string value)
        {
            TelephonyPageType result = TelephonyPageType.None;

            if (value == DialCommandName)
            {
                result = TelephonyPageType.Dial;
            }
            else if (value == HangupCommandName)
            {
                result = TelephonyPageType.Hangup;
            }
            else if (value == InternalTransferCommandName)
            {
                result = TelephonyPageType.InternalTransfer;
            }
            else if (value == ExternalTransferCommandName)
            {
                result = TelephonyPageType.ExternalTransfer;
            }

            return result;
        }

        public int? DialStatus
        {
            get
            {
                int? result = null;

                IHTMLDocument3 doc;
                IHTMLInputElement dialStatus;
                if (WebBrowser.Document != null &&
                    (doc = (IHTMLDocument3)WebBrowser.Document.DomDocument) != null &&
                    (dialStatus = (IHTMLInputElement)doc.getElementById(DialStatusItem)) != null
                )
                {
                    int t;
                    if (Int32.TryParse(dialStatus.value, out t))
                    {
                        result = t;
                    }
                }

                return result;
            }
            set
            {
                IHTMLDocument3 doc;
                IHTMLInputElement dialStatus;
                if (WebBrowser.Document != null &&
                    (doc = (IHTMLDocument3)WebBrowser.Document.DomDocument) != null &&
                    (dialStatus = (IHTMLInputElement)doc.getElementById(DialStatusItem)) != null)
                {
                    dialStatus.value = value.ToString();
                }
            }
        }

        private IHTMLInputElement GetInputElementById(string id)
        {
            return ((IHTMLDocument3)WebBrowser.Document?.DomDocument)?.getElementById(id) as IHTMLInputElement;
        }

        private string GetInputValueById(string id)
        {
            return GetInputElementById(id)?.value;
        }

        public string TransferResource => GetInputValueById(TransferResourceItem) ?? String.Empty;

        public string DialMessage => GetInputValueById(DialTextItem) ?? String.Empty;

        public string Status
        {
            get
            {
                string status = null;

                if (WebBrowser.Document != null)
                {
                    var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;

                    var statusField = doc.getElementById(StatusFinalItem) as IHTMLInputElement;

                    if (statusField != null)
                    {
                        status = statusField.value;
                    }
                }

                return status;
            }
            set
            {
                if (WebBrowser.Document == null) return;

                var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;

                var statusField = doc.getElementById(StatusFinalItem) as IHTMLInputElement;

                if (statusField != null)
                {
                    statusField.value = value;
                }
            }
        }

        public int InterviewDuration
        {
            get
            {
                int duration = 0;

                if (WebBrowser.Document != null)
                {
                    var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;

                    var itsField = doc.getElementById(InterviewDurationItem) as IHTMLInputElement;

                    if (itsField != null)
                    {
                        int.TryParse(itsField.value, out duration);
                    }
                }

                return duration;
            }
        }

        public string Its
        {
            get
            {
                string its = null;

                if (WebBrowser.Document != null)
                {
                    var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;

                    var itsField = doc.getElementById(ItsFinalItem) as IHTMLInputElement;

                    if (itsField != null)
                    {
                        its = itsField.value;
                    }
                }

                return its;
            }
        }

        public bool CheckAndGetTelephonyFlag(out bool allowTelephonyCommands)
        {
            allowTelephonyCommands = true;
            bool result = false;

            IHTMLDocument3 doc;
            IHTMLElement input;
            if (WebBrowser.Document != null &&
                (doc = (IHTMLDocument3)WebBrowser.Document.DomDocument) != null &&
                (input = doc.getElementById(TelephonyCommandType)) != null)
            {
                IHTMLInputElement commandType = input as IHTMLInputElement;
                if (commandType != null)
                {
                    if (commandType.value == AllowDialingCommandName)
                    {
                        // page contains "Allow dialing" flag
                        result = true;
                        IHTMLInputElement dialingFlag =
                            doc.getElementById(AllowDialingFlagElementName) as IHTMLInputElement;
                        if (dialingFlag != null)
                        {
                            allowTelephonyCommands = Boolean.Parse(dialingFlag.value);
                        }
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Gets a value indicating whether current page contains Sound file info or not.
        /// </summary>
        public bool HasSoundInfo => !string.IsNullOrEmpty(SoundFileName);

        /// <summary>
        /// Gets a value indicating whether sound file must start playback automatically
        /// </summary>
        public bool StartPlaybackAutomatically { get; private set; }

        /// <summary>
        /// Gets sound file name for the current page
        /// </summary>
        public string SoundFileName { get; private set; }

        public void ParseForSoundInfo()
        {
            if (WebBrowser.Document != null)
            {
                var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;

                var soundFileNameField = doc.getElementById(SoundFileNameItem) as IHTMLInputElement;
                SoundFileName = soundFileNameField != null ? soundFileNameField.value : null;

                var autoStartPlayingField = doc.getElementById(AutoStartPlayingItem) as IHTMLInputElement;
                StartPlaybackAutomatically = autoStartPlayingField != null && autoStartPlayingField.value.ToLower().Equals("true");
            }
        }

        public IEnumerable<QuestionTextBlock> GetPageTextBlocks(string formId)
        {
            IHTMLDocument3 doc;
            var result = new List<KeyValuePair<int, QuestionTextBlock>>();

            if (WebBrowser.Document != null &&
               (doc = (IHTMLDocument3)WebBrowser.Document.DomDocument) != null)
            {
                try
                {
                    if (((IHTMLDocument2)doc).forms.item(formId, 0) != null)
                    {
                        IHTMLElementCollection elements = doc.getElementsByTagName("INPUT");

                        foreach (IHTMLElement element in elements)
                        {
                            var answer = new Answer(element);

                            if (answer.ElementType == ElementTypes.TextInput &&
                                answer.IsDisabled == false && answer.IsInvisible == false &&
                                string.IsNullOrEmpty(answer.Value) == false &&
                                answer.ElementId != null)
                            {
                                result.Add(new KeyValuePair<int, QuestionTextBlock>(element.sourceIndex,
                                                                                    new QuestionTextBlock(answer.ElementId, answer.Value)));
                            }
                        }

                        elements = doc.getElementsByTagName("TEXTAREA");

                        foreach (IHTMLElement element in elements)
                        {
                            var answer = new Answer(element);

                            if (answer.IsDisabled == false && answer.IsInvisible == false &&
                                string.IsNullOrEmpty(answer.Value) == false)
                            {
                                result.Add(new KeyValuePair<int, QuestionTextBlock>(element.sourceIndex,
                                                                                    new QuestionTextBlock(answer.ElementId, answer.Value)));
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Write(ex);
                }
            }
            return result.OrderBy(x => x.Key).Select(x => x.Value);
        }
    }
}