﻿using System;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    public class KeyboadInputEventArgs : EventArgs
    {
        #region Members
        private Keys m_KeyCode = Keys.None;
        private bool m_Control = false;
        private bool m_Shift = false;
        private string m_InputValue = String.Empty;
        #endregion
        public Keys KeyCode
        {
            get
            {
                return m_KeyCode; 
            }
            set 
            {
                m_KeyCode = value; 
            }
        }
        public bool Control
        {
            get
            {
                return m_Control;
            }
            set
            {
                m_Control = value;
            }
        }
        public bool Shift
        {
            get
            {
                return m_Shift;
            }
            set
            {
                m_Shift = value;
            }
        }
        public String InputValue
        {
            get
            {
                return m_InputValue;
            }
            set
            {
                m_InputValue = value;
            }
        }
    }
 
}
