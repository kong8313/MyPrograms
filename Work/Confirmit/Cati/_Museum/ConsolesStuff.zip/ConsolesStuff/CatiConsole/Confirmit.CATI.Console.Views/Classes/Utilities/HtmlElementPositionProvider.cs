﻿using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.Classes.Utilities
{
    class HtmlElementPositionProvider
    {
        /// <summary>
        /// Returns element offset from the left of the page
        /// </summary>
        /// <param name="el"></param>
        /// <returns></returns>
        public int GetOffsetFromLeft(HtmlElement el)
        {
            var xPosition = el.OffsetRectangle.Left;

            var currentElement = el.OffsetParent;
            while (currentElement != null)
            {
                xPosition += currentElement.OffsetRectangle.Left;
                currentElement = currentElement.OffsetParent;
            }

            return xPosition;
        }

        /// <summary>
        /// Returns element offset from the top of the page
        /// </summary>
        /// <param name="el"></param>
        /// <returns></returns>
        public int GetOffsetFromTop(HtmlElement el)
        {
            var yPosition = el.OffsetRectangle.Top;

            var currentElement = el.OffsetParent;
            while (currentElement != null)
            {
                yPosition += currentElement.OffsetRectangle.Top;
                currentElement = currentElement.OffsetParent;
            }

            return yPosition;
        }
    }
}
