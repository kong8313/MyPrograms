using System;

namespace Confirmit.CATI.Console.Views.Controls
{
    public class PagePartiallyChangedEventArgs : EventArgs
    {
        public string NewOuterHtml { get; set; }

        public string ElementId { get; set; }

        public string ActiveElementId { get; set; }
    }
}