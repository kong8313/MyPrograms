﻿(function () {
    function mutationHandler(mutations) {
        var eventsForMonitoringConsole = filterAndMapMutations(mutations);

        window.external.ResponsiveQuestionChange(JSON.stringify(eventsForMonitoringConsole));

        eventsForMonitoringConsole.length = 0;
    }

    function domElementChangeHandler(e) {
        mutationHandler([e]);
    }

    var mo = new MutationObserver(mutationHandler),
        options = {
            attributes: true,
            characterData: true,
            childList: true,
            subtree: true,
            attributeOldValue: true,
            characterDataOldValue: true
        };

    mo.observe(document.querySelector('.cf-page__question-list'), options);

    window.onbeforeunload = dispose;

    subscribeAllInputElements(document);

    window.handleMutation = domElementChangeHandler;

    function dispose() {
        var mutations = mo.takeRecords();
        if (mutations.length !== 0)
            mutationHandler(mutations);

        if (mo) {
            mo.disconnect();
        }
    }

    function mapMutations(mutations) {
        var result = [];

        for (var index = 0; index < mutations.length; index++) {
            var mutation = mutations[index];

            switch (mutation.type) {
                case "attributes":
                    if (mutation.attributeName === "class") {
                        result.push({
                            selector: getFullPath(mutation.target),
                            type: mutation.type,
                            attributeName: mutation.attributeName,
                            value: mutation.target.className
                        });
                    }
                    if (mutation.attributeName === "style") {
                        result.push({
                            selector: getFullPath(mutation.target),
                            type: mutation.type,
                            attributeName: mutation.attributeName,
                            value: mutation.target.style.cssText
                        });
                    }
                    if (mutation.attributeName === "value") {
                        result.push({
                            selector: getFullPath(mutation.target),
                            type: mutation.type,
                            attributeName: mutation.attributeName,
                            value: mutation.target.value
                        });
                    }
                    break;
                case "input":
                case "change":
                    result.push({
                        selector: getFullPath(mutation.target),
                        type: "characterData",
                        value: mutation.target.value
                    });
                    break;
                case "childList":
                    var mutationDescription = {
                        type: mutation.type,
                        removedNodes: [],
                        addedNodes: [],
                        targetElementSelector: getFullPath(mutation.target)
                    };

                    for (var i = 0; i < mutation.removedNodes.length; i++) {
                        var currentNode = mutation.removedNodes[i];

                        if (currentNode.nodeType === 1) {
                            var path = getFullPath(currentNode);

                            if (!path) {
                                if (currentNode.id) {
                                    path = "#" + currentNode.id;
                                } else {
                                    path = mutationDescription.targetElementSelector + "> ";

                                    for (var j = 0; j < currentNode.classList.length; j++) {
                                        path += "." + currentNode.classList[j];
                                    }
                                }
                            }

                            mutationDescription.removedNodes.push(path);
                        }
                    }

                    for (var i = 0; i < mutation.addedNodes.length; i++) {
                        var currentNode = mutation.addedNodes[i];

                        if (currentNode.nodeType === 1) {
                            mutationDescription.addedNodes.push({
                                previousElementSiblingSelector: currentNode.previousElementSibling ? getFullPath(currentNode.previousElementSibling) : "",
                                nextElementSiblingSelector: currentNode.nextElementSibling ? getFullPath(currentNode.nextElementSibling) : "",
                                value: currentNode.outerHTML
                            });
                        }

                        if (currentNode.nodeType === 3 &&
                            mutation.target.childNodes.length === 1 &&
                            mutation.target.childNodes[0].nodeType) {
                            mutationDescription.addedNodes.push({
                                previousElementSiblingSelector: "",
                                nextElementSiblingSelector: "",
                                value: mutation.target.innerHTML
                            });
                            break;
                        }
                    }

                    if (mutationDescription.addedNodes.length !== 0 || mutationDescription.removedNodes.length !== 0) {
                        result.push(mutationDescription);
                    }

                    break;
            }
        }

        return result;
    }

    function filterMutations(mutations) {
        var classMutations = {};
        var valueMutations = {};
        var result = [];

        for (var i = 0; i < mutations.length; i++) {
            var mutation = mutations[i];

            switch (mutation.type) {
                case "attributes":
                    if (mutation.attributeName === "class") {
                        classMutations[mutation.selector] = mutation;
                    } else if (mutation.attributeName === "value") {
                        valueMutations[mutation.selector] = mutation;
                    } else {
                        result.push(mutation);
                    }
                    break;
                case "childList":
                default:
                    result.push(mutation);
                    break;
            }
        }

        Array.prototype.push.apply(result, Object.values(classMutations));
        Array.prototype.push.apply(result, Object.values(valueMutations));

        return result;
    }

    function filterAndMapMutations(mutations) {
        return filterMutations(mapMutations(mutations));
    }

    function subscribeAllInputElements(container) {
        var inputs = container.getElementsByTagName("input");

        for (var index = 0; index < inputs.length; index++) {
            inputs[index].addEventListener("input", domElementChangeHandler);
            inputs[index].addEventListener('keydown', function (event) {
                if (event.keyCode === 13) {
                    window.external.SetFocusOnKeyboardInput();
                }
            });
        }

        var textareas = container.getElementsByTagName("textarea");

        for (var index = 0; index < textareas.length; index++) {
            textareas[index].addEventListener("input", domElementChangeHandler);
        }

        var selects = container.getElementsByTagName("select");

        for (var index = 0; index < selects.length; index++) {
            selects[index].addEventListener("change", domElementChangeHandler);
        }
    }

    Confirmit.page.dynamicQuestionsChangeCompleteEvent.on(function (e) {
        setTimeout(function () {
            for (var i = 0; i < e.length; i++) {
                subscribeAllInputElements(document.getElementById(e[i].id));
            }
        }, 0);
    });

    function getFullPath(el) {
        var names = [];
        while (el.parentNode) {
            if (el.id) {
                names.unshift("#" + el.id);
                break;
            } else {
                if (el == el.ownerDocument.documentElement) {
                    names.unshift(el.tagName);
                }
                else {
                    for (var c = 1, e = el; e.previousElementSibling; e = e.previousElementSibling, c++);
                    names.unshift(el.tagName + ":nth-child(" + c + ")");
                }

                el = el.parentNode;
            }
        }

        return names.join(" > ");
    }
})();