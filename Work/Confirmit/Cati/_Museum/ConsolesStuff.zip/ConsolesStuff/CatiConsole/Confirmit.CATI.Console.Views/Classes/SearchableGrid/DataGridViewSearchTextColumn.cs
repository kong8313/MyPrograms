﻿
#region Usings
using System;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
#endregion

namespace Confirmit.CATI.Console.Views.Classes.SearchableGrid
{
    [ToolboxBitmap(typeof(TextBox))] 
    public class DataGridViewSearchTextColumn : DataGridViewColumn
    {       
        #region Constructors

        /// <summary>
        /// Constructor of DataGridViewSearchTextColumn class
        /// </summary>
        public DataGridViewSearchTextColumn()
            : base(new DataGridViewSearchTextCell())
        {
            SortMode = DataGridViewColumnSortMode.Automatic;
            base.CellTemplate.Style.BackColor = SystemColors.Window;
            base.CellTemplate.Style.SelectionBackColor = SystemColors.Window;
        }        

        #endregion
     
        #region Derived properties

        [Browsable(false),
         DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public override DataGridViewCell CellTemplate
        {
            get 
            { 
                return base.CellTemplate; 
            }
            set
            {
                if ((value != null) && !(value is DataGridViewSearchTextCell))
                {
                    throw new InvalidCastException("WrongCellTemplateType: must be DataGridViewSearchTextCell");
                }

                base.CellTemplate = value;
            }
        }
                
        #endregion

    }  
}
