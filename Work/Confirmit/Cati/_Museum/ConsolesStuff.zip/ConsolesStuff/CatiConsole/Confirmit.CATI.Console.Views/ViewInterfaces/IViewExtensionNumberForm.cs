﻿using System;
using System.ComponentModel;
using Confirmit.CATI.Console.Views.Classes.Login;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Represents view interface for ProcessControl control.
    /// </summary>
    public interface IViewExtensionNumberForm : ILocalizableView
    {
        /// <summary>
		/// Occurs when user clicks Ok button.
		/// </summary>
		event EventHandler<EventArgs> OkClick;

        /// <summary>
        /// Occurs when user clicks Cancel button or manualy closes form
        /// </summary>
        event EventHandler<CancelEventArgs> CancelClicking;

        /// <summary>
        /// Occurs when extension number name is going to be validated.
        /// </summary>
        event EventHandler<CancelEventArgs> ValidatingExtensionNumber;


        /// <summary>
        /// Gets entered extension number
        /// </summary>
        string ExtensionNumber
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets possibility to enter extension number        
        /// </summary>
        /// <remarks>
        /// For TCI dialler this form is used with disabled extension number input.
        /// </remarks>
        bool ExtensionNumberInputEnabled
        {
            get;
            set;
        }

        /// <summary>
        /// Notifies user about validation error of specified control.
        /// </summary>
        /// <param name="message">Error message.</param>
        /// <remarks>If the message length is greater than zero, then the error icon is displayed, 
        /// and the ToolTip for the error icon is the error description text. 
        /// If the message length is zero, the error icon is hidden.
        /// </remarks>
        void AlertValidationError(string message);

        /// <summary>
        /// Shows the form as a modal dialog box with the specified owner.
        /// </summary>
        /// <param name="owner">Owner window.</param>
        /// <returns>LoginToDiallerResult object.</returns>
        LoginToDiallerResult ShowDialog(IWin32Window owner);
    }
}
