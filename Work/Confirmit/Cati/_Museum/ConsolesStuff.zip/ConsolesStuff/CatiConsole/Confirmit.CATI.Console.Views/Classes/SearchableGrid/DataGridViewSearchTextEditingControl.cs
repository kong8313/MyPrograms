﻿
#region Usings
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
#endregion

namespace Confirmit.CATI.Console.Views.Classes.SearchableGrid
{
    /// <summary>
    /// DataGridViewSearchTextEditingControl is the SearchTextBox that is hosted
    /// in a DataGridViewSearchTextColumn.
    /// </summary>
    public class DataGridViewSearchTextEditingControl : TextBox, IDataGridViewEditingControl
    {        
        #region Constructor

        public DataGridViewSearchTextEditingControl()
        {            
        }

        #endregion

        #region IDataGridViewEditingControl's properties

        public DataGridView EditingControlDataGridView
        {
            get;
            set;
        }

        public object EditingControlFormattedValue
        {
            get { return Text; }
            set
            {
                if (value is string)
                    Text = (string)value;
            }
        }

        public int EditingControlRowIndex
        {
            get;
            set;
        }

        public bool EditingControlValueChanged
        {
            get;
            set;
        }

        public Cursor EditingPanelCursor
        {
            get { return base.Cursor; }
        }

        public bool RepositionEditingControlOnValueChange
        {
            get { return false; }
        }

        #endregion

        #region IDataGridViewEditingControl's methods

        public void ApplyCellStyleToEditingControl(
            DataGridViewCellStyle dataGridViewCellStyle)
        {
            //important to set here 'Fixed3D' border style. For some reason other variant looks bad on XP
            BorderStyle = BorderStyle.Fixed3D;            
        }

        /// <summary>
        /// An editing control implements this method to determine which input keys should be processed by the control, 
        /// and which input keys should be processed by the DataGridView. 
        /// </summary>
        ///<remarks>
        /// The EditingControlWantsInputKey method is called by the DataGridView. 
        /// The DataGridView will pass in true for dataGridViewWantsInputKey when it can process the keyData
        /// </remarks>
        public bool EditingControlWantsInputKey(Keys key, bool dataGridViewWantsInputKey)
        {
            switch (key & Keys.KeyCode)
            {
                case Keys.Left:
                case Keys.Right:
                case Keys.Home:
                case Keys.End:
                    return true;
                default:
                    return !dataGridViewWantsInputKey;
            }            
        }

        public object GetEditingControlFormattedValue(DataGridViewDataErrorContexts context)
        {
            return EditingControlFormattedValue;
        }

        public void PrepareEditingControlForEdit(bool selectAll)
        {
            if (selectAll)
                SelectAll();
            else
            {
                SelectionStart = 0;
                SelectionLength = 0;
            }
        }        

        #endregion

        #region TextBox event

        protected override void OnTextChanged(System.EventArgs e)
        {
            base.OnTextChanged(e);

            EditingControlValueChanged = true;

            if (EditingControlDataGridView != null)
            {
                EditingControlDataGridView.CurrentCell.Value = Text;
            }
        }

        #endregion             
    }
}
