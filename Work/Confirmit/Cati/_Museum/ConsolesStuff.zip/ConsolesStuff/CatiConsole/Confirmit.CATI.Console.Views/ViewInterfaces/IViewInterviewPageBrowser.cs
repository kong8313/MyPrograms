﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using Confirmit.CATI.Console.Views.Classes.ExtendedWebBrowser;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.SpellChecking;
using Confirmit.CATI.Console.Views.Controls;
using mshtml;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Enumeration of possible telephony pages.
    /// </summary>
    public enum TelephonyPageType
    {
        /// <summary>
        /// Page is not telephony page.
        /// </summary>
        None = 0,

        /// <summary>
        /// Dial page.
        /// </summary>
        Dial = 1,

        /// <summary>
        /// Hang up page.
        /// </summary>
        Hangup = 2,
        
        /// <summary>
        /// Internal transfer
        /// </summary>
        InternalTransfer = 3,

        /// <summary>
        /// External transfer
        /// </summary>
        ExternalTransfer = 4
    }

    /// <summary>
    /// Represents view interface for InterviewPageBrowser control.
    /// </summary>
    public interface IViewInterviewPageBrowser : IPlayableView, ILocalizableView
    {
        /// <summary>
        /// Returns Uri for current page
        /// </summary>
        Uri Uri
        {
            get;
        }

        /// <summary>
        /// Gets or sets ReadOnly property
        /// It is used in Player for disable interface
        /// </summary>
        bool ReadOnly
        {
            get;
            set;
        }

        /// <summary>
        /// Returns true if current active question is last question on displayed page
        /// Otherwise return false
        /// </summary>
        bool IsCurrentQuestionLast
        {
            get;
        }

        /// <summary>
        /// Returns true if current page has open end question or has question with "other"
        /// answer which value is not empty.
        /// </summary>
        /// <remarks>
        /// It is used during review, check this property for do fast forward
        /// </remarks>
        bool HasOpenEndQuestion
        {
            get;
        }

        bool DisableCatiMarkupAndKeyboardSupport
        {
            get;
        }

        /// <summary>
        /// Returns true if current question has answer with "other" field otherwise false.        
        /// </summary>
        bool HasCurrentQuestionAnswersWithFocusedOtherField
        {
            get;
        }

        void InitPageInteractor();

        bool IsPageInteractorInitialized { get; }

        bool IsResponsiveSurvey { get; }

        ISurveyPageInteractor SurveyPageInteractor { get; }

        /// <summary>
        /// Return view for KeyboardInputControl
        /// </summary>
        IViewKeyboardInput ViewKeyboardInput
        {
            get;
        }

        /// <summary>
        /// Gets telephony page type of current page.
        /// </summary>
        TelephonyPageType TelephonyPage
        {
            get;
        }

        /// <summary>
        /// Get transfer resource, if exists on current page. Otherwise returns empty string.
        /// </summary>
        string TransferResource
        {
            get;
        }

        /// <summary>
        /// Gets dialing message if exists on current page. Otherwise returns empty string.
        /// </summary>
        string DialMessage
        {
            get;
        }

        /// <summary>
        /// Gets dialing phone if exists on current page. Otherwise returns empty string.
        /// </summary>
        string DialPhone
        {
            get;
        }

        /// <summary>
        /// return name of current question in InterviewPageBrowser
        /// </summary>
        string CurrentQuestionTitle
        {
            get;
        }

        /// <summary>
        /// Gets/sets index of current active question.
        /// </summary>
        int CurrentQuestionIndex
        {
            get;
            set;
        }

        string CurrentQuestionId { get; }

        /// <summary>
        /// Gets value indicating that current page informs us about openend review mode.
        /// </summary>
        bool IsOpenendReviewStartPage
        {
            get;
        }

        /// <summary>
        /// Gets value indicating that current page is final page with "Ok" button.
        /// </summary>
        bool IsOkPage
        {
            get;
        }

        /// <summary>
        /// Gets the confirmit interview status returned from the Confirmit in the OK page
        /// </summary>
        string Status
        {
            get; set;
        }

        /// <summary>
        /// Gets the confirmit interview its returned from the Confirmit in the OK page
        /// </summary>
        string Its
        {
            get;
        }

        /// <summary>
        /// Gets the confirmit interview duration returned from the Confirmit in the OK page
        /// </summary>
        int InterviewDuration
        {
            get;
        }

        /// <summary>
        /// Return true if end service page is loaded into control
        /// </summary>
        bool IsEndInterviewServicePage
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether current page is Confirmit
        /// internal error page. This page is returned if error occurs 
        /// in survey engine during interviewing process. For example,
        /// this page is returned if survey script error occurs in Confirmit.
        /// </summary>
        bool IsConfirmitInternalErrorPage
        {
            get;
        }

        /// <summary>
        /// Return true if end interview page is loaded into control
        /// </summary>
        bool IsEndInterviewPageLoaded
        {
            get;
        }

        /// <summary>
        /// Gets value indicating that current page is CATI Console
        /// predefined custom error page.
        /// </summary>
        bool IsPredefinedErrorPage
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether navigation error has occured.
        /// </summary>
        bool IsNavigationError
        {
            get;
        }

        bool Is500ErrorPage
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether current page is Confirmit service page
        /// which is returned when survey is in maintenance mode. For example, it is
        /// returned during survey launch.
        /// </summary>
        bool IsConfirmitServicePage
        {
            get;
        }

        /// <summary>
        /// Gets or sets a value indicating whether extended logging 
        /// of browser operations is needed.
        /// </summary>
        bool ExtendedLoggingEnabled
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets dial status if exists on page. Otherwise does this property is null.
        /// </summary>
        int? DialStatus
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets delay in milliseconds to update page in the monitoring player
        /// </summary>
        int PageUpdateMonitoringDelay
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets delay in milliseconds to send event about mouse click
        /// It is needed for some question when user clicks on label
        /// </summary>
        int MouseClickAnswerMonitoringDelay
        {
            get;
            set;
        }

        /// <summary>
        /// Gets a value indicating whether current page contains Sound file info or not.
        /// </summary>
        bool HasSoundInfo
        {
            get;
        }

        /// <summary>
        /// Gets sound file name for the current page
        /// </summary>
        string SoundFileName
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether sound file must start playback automatically
        /// </summary>
        bool StartPlaybackAutomatically
        {
            get;
        }

        bool ContainsForcedAppointment { get; }
        bool ShouldNavigationBeIgnored { get; }

        bool ContainsCallTransferConfiguration { get; }

        bool ContainsScreenRecordingEnabledFlag { get; }

        string CallTransferConfiguration { get; }

        /// <summary>
        /// Occurs when control already loaded page is going to complet it. It is cancelable
        /// event. If you cancel this event any further page processing will be stoped and
        /// DocumentCompleted event will not be sent.
        /// </summary>
        event CancelEventHandler DocumentCompleting;

        /// <summary>
        /// Occurs when control loaded new interview page or page is refreshed via ajax.
        /// </summary>
        event EventHandler<EventArgs> DocumentCompleted;

        /// <summary>
        /// Occurs when control is navigating to a new page.
        /// </summary>
        event EventHandler<CustomBeforeNavigateEventArgs> BeforeNavigate;

        /// <summary>
        /// Occurs when question is selected.
        /// </summary>
        event EventHandler<QuestionSelectedEventArgs> QuestionSelected;

        /// <summary>
        /// Occurs when sub-question of current question is selected.
        /// </summary>
        event EventHandler<QuestionSelectedEventArgs> SubQuestionSelected;

        /// <summary>
        /// Occurs when answer value is changed
        /// </summary>
        event EventHandler<AnswerElementValueChangedEventArgs> AnswerValueChanged;
        
        /// <summary>
        /// Occurs when answer value is changed in responsive layout
        /// </summary>
        event EventHandler<AnswerElementValueChangedEventArgs> ResponsiveQuestionChanged;

        /// <summary>
        /// Occurs when answer value is changed for dynamic question
        /// </summary>
        event EventHandler<EventArgs> DynamicQuestionAnswerValueChanged;

        /// <summary>
        /// Occurs when question is loaded via ajax
        /// </summary>
        event EventHandler<EventArgs> AjaxQuestionLoaded;

        event EventHandler<PagePartiallyChangedEventArgs> PagePartiallyChanged;

        /// <summary>
        /// Occurs when Ok button is clicked;
        /// </summary>
        event EventHandler<EventArgs> OkClick;

        event EventHandler SubmitOtherValue;

        /// <summary>
        /// Occurs when default answer for question is set
        /// </summary>
        event EventHandler<PredefinedAnswerSelectedEventArgs> DefaultAnswerSelected;

        /// <summary>
        /// Occurs when refused answer for question is set
        /// </summary>        
        event EventHandler<PredefinedAnswerSelectedEventArgs> RefusedAnswerSelected;

        /// <summary>
        /// Occurs in a case of navigation failed. If NavigateErroreventArgs.Cancel is true,
        /// browser will be redirected to built-in system error page. Otherwise redirect is not performed.
        /// </summary>
        event EventHandler<NavigateErrorEventArgs> NavigateError;

        /// <summary>
        /// Load specified page into control
        /// </summary>
        /// <param name="uri">uri for navigation</param>
        void Navigate(Uri uri);

        /// <summary>
        /// Refreshes current page
        /// </summary>
        void RefreshPage();

        /// <summary>
        /// Emulate page next button click
        /// </summary>
        void DoNextPage();

        /// <summary>
        /// Emulate page previous button click
        /// </summary>
        void DoPrevPage();

        /// <summary>
        /// Select question by index in collection
        /// </summary>
        /// <param name="questionIndex"></param>
        void DoQuestion(int questionIndex);

        /// <summary>
        /// Select subQuestion of current question
        /// If current question is null do nothing
        /// </summary>
        void DoSubQuestion(int subQuestionIndex);

        /// <summary>
        /// Select previous question
        /// If current question is GRID or 3DGrid will be selected previous subquestion
        /// If previous question is GRID or 3DGrid will be selected question & first subquestion
        /// </summary>
        void DoPreviousQuestion();

        /// <summary>
        /// Select next question
        /// If current question is GRID or 3DGrid will be selected next subquestion
        /// If next question is GRID or 3DGrid will be selected question & first subquestion
        /// </summary>
        void DoNextQuestion();

        /// <summary>
        /// Select first question on page
        /// </summary>
        void DoFirstQuestion();

        /// <summary>
        /// Selects first subquestion of the first question.
        /// </summary>
        void DoFirstQuestionFirstSubQuestion();

        /// <summary>
        /// Select last question on page
        /// </summary>
        void DoLastQuestion();

        /// <summary>
        /// Select last subquestion of last question
        /// </summary>
        void DoLastQuestionLastSubQuestion();

        /// <summary>
        /// Select first sub question of current question
        /// If current question hasn't subquestion do nothing
        /// </summary>
        void DoFirstSubQuestion();

        /// <summary>
        /// Select last sub question of current question
        /// If current question hasn't subquestion do nothing
        /// </summary>
        void DoLastSubQuestion();

        /// <summary>
        /// Set focus to input element if current question has open or multi open type
        /// </summary>
        void DoEditQuestion();

        /// <summary>
        /// Set default answer for current question on page
        /// </summary>
        void SetDefaultAnswer();

        /// <summary>
        /// Set refused answer for current question on page
        /// </summary>
        void SetRefusedAnswer();

        /// <summary>
        /// Fill current question by passed value
        /// </summary>     
        void ProcessEnterData(string answer);

        /// <summary>
        /// Finish current interview
        /// </summary>
        void FinishInterview();

        /// <summary>
        /// Terminate current interview with specified status.
        /// </summary>
        /// <param name="status">Termination status.</param>
        void TerminateInterview(int status);

        /// <summary>
        /// Do fast forward action for current interview.
        /// </summary>
        void FastForward();

        /// <summary>
        /// Returns current page html content
        /// </summary>
        string GetPageContent();

        /// <summary>
        /// Calls click() event for specified elementId
        /// </summary>
        /// <param name="elementId"></param>
        void FireClickEventByElementId(string elementId);

        /// <summary>
        /// Checks if current page contains information about "Allow/disallow dialing" flag
        /// set in Confirmit. If page contains such info, returns <c>true</c> and 
        /// <paramref name="allowTelephonyCommands"/> is set to value of "Allow/disallow dialing" flag.
        /// Otherwise returns <c>false</c> and <paramref name="allowTelephonyCommands"/> is always
        /// <c>true</c>.
        /// </summary>
        /// <param name="allowTelephonyCommands">Returns value of Confirmit "Allow/disallow dialing" flag.</param>
        /// <returns>Returns <c>true</c> if page contains info; otherwise <c>false</c>.</returns>
        bool CheckAndGetTelephonyFlag(out bool allowTelephonyCommands);

        /// <summary>
        /// Sets the HTML contents of the page displayed in the WebBrowser control 
        /// </summary>
        /// <param name="pageContent">HTML text</param>
        void LoadContent(string pageContent);

        /// <summary>
        /// Sets Answer on current html page
        /// Finds html element on the page and set value of element
        /// </summary>
        void SetAnswer(string elementId, string elementValue);

        /// <summary>
        /// Continues interview by pressing Next button.
        /// </summary>
        void ContinueInterview();

        /// <summary>
        /// Changes language of current interview. Function sets given value to "l" parameter in current page DOM.
        /// </summary>
        /// <param name="languageId">Language indentifier.</param>
        void ChangeLanguage(int languageId);

        /// <summary>
        /// Shows error page with given message. This method constructs error page, containing
        /// message and loads it to browser.
        /// </summary>
        /// <param name="message">Error message.</param>
        void ShowErrorPage(string message);

        /// <summary>
        /// Collects all text blocks on the current page.
        /// </summary>
        /// <returns>
        /// Returns enumeration of QuestionTextBlock.
        /// </returns>
        IEnumerable<QuestionTextBlock> GetPageTextBlocks();

        /// <summary>
        /// Updates text blocks on the current page.
        /// </summary>        
        void UpdatePageTextBlocks(IEnumerable<QuestionTextBlock> textblocks);

        void EnableKeyboardSupport(bool enabled);

        void UpdatePagePartially(string elementId, string elementOuterHtml, string activeElementId);

        void FocusActiveElement();

        string GetDatePickerDatePattern();

        void ExecuteJavaScript(string script);

        void PrepareBrowser();

        void HighlightEnterZone(Color color);

        void CheckBrowserFeatures();

        /// <summary>
        /// Method will be executed from JavaScript 
        /// after page is loaded(each time)
        /// </summary>
        void CheckedFeatureDisabled(string feature);

        /// <summary>
        /// Method will be executed from JavaScript 
        /// after browser feature checking
        /// </summary>
        void BrowserFeaturesCheckingIsFinished();

        void AddNotificationAtTopOfThePage(string content);

        void ResponsiveQuestionChange(string data);

        void SetAnswerForResponsive(string id, string value);
        void LogSurveyLayoutType();
        void LoadContentSync(string pageContent);
    }
}