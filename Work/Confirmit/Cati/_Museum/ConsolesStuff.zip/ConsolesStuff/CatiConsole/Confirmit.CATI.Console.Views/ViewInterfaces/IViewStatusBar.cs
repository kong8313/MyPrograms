﻿using System.Drawing;
using Confirmit.CATI.Console.Views.Classes.StatusBar;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    public interface IViewStatusBar : ILocalizableView
    {
        /// <summary>
        /// Hide or show interview info panel
        /// </summary>
        StatusBarModes Mode
        {
            get;
            set;
        }

        /// <summary>
        /// Get or set user name in StatusBar
        /// </summary>
        string UserName
        {
            get;
            set;
        }

        /// <summary>
        /// Get or set respondent time.
        /// </summary>
        string RespondentTime
        {
            get;
            set;
        }

        /// <summary>
        /// Get or set interviewer time.
        /// </summary>
        string InterviewerTime
        {
            get;
            set;
        }

        /// <summary>
        /// Get or set survey name in StatusBar
        /// </summary>
        string SurveyName
        {
            get;
            set;
        }

        /// <summary>
        /// Get or set interview name in StatusBar
        /// </summary>
        string InterviewName
        {
            get;
            set;
        }

        /// <summary>
        /// Sets pending break state in status bar
        /// </summary>
        string PendingBreakState
        {
            set;
        }

        /// <summary>
        /// Sets pending logout state in status bar
        /// </summary>
        string PendingLogoutState
        {            
            set;
        }

        /// <summary>
        /// Get or set question name in StatusBar
        /// </summary>
        string QuestionName
        {
            get;
            set;
        }

        /// <summary>
        /// Set or get current position information that is displayed in status bar
        /// </summary>
        string CurrentPosition
        {
            get;
            set;
        }

        /// <summary>
        /// Get or set interview mode in StatusBar
        /// </summary>
        /// <remarks>
        /// Interviewing/Open end reviewing
        /// </remarks>
        string CurrentState
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets current interview state that is displayed in status bar
        /// </summary>
        /// <param name="state">state that is displayed in status bar</param>
        /// <param name="color">set the color of the message</param>
        void SetCurrentState(string state, Color? color = null);

        /// <summary>
        /// Gets/sets console version.
        /// </summary>
        string Version
        {
            get;
            set;
        }

        /// <summary>
        /// Display message in status bar for specified time.
        /// </summary>
        void ShowInformation(string message, int seconds);

        /// <summary>
        /// Display message in status bar.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="color"></param>
        void ShowInformation(string message, Color? color = null);

        /// <summary>
        /// Removes informatiion message from status bar.
        /// </summary>
        void ClearInformation();

        void HighlightSurvey(bool isNewSurvey);

        void UpdateConnectionIndicator(Bitmap image, string tooltip);

        void HideAndNeverShowConnectionIndicator();
    }
}
