﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.Classes.Login;
using Confirmit.CATI.Console.Views.Classes.StatusBar;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{ 
    /// <summary>
	/// Represents view entity for MainForm form.
	/// </summary>
    public interface IViewMainForm : IWin32Window, ILocalizableView, IPlayableView
    {
        /// <summary>
        /// Index of selected language in survey language list.
        /// </summary>
        int SelectedSurveyLanguage
		{
			get;
			set;
		}

        int? SelectedBreakIndex { get; set; }

        /// <summary>
        /// Gets index of selected question in redo questions list.
        /// If there is no selected question returns negative number.
        /// </summary>
        int SelectedRedoQuestion
        {
            get;
        }

        /// <summary>
        /// Gets/sets current application cursor.
        /// </summary>
        Cursor Cursor
        {
            get;
            set;
        }

        /// <summary>
        /// Gets flag indicating that survey list control is shown to user.
        /// </summary>
        bool IsSurveyListShown
        {
            get;
        }

        /// <summary>
        /// Binds survey language list with given values.
        /// </summary>
        /// <param name="languages">Array of languages names to bind.</param>
        void BindSurveyLanguageList(string[] languages);

        /// <summary>
        /// Binds list of redo questions with given values.
        /// </summary>
        /// <param name="questions">List of question to bind.</param>
        void BindRedoList(string[] questions);

		/// <summary>
		/// Gets/sets value indicating state of "Log out after finishing current interview" option.
		/// If option is checked, returns true; otherwise false.
		/// </summary>
		bool IsLogoutAfterFinishingChecked { get; set; }

        bool IsPreviousPageEnabled { get; }

        bool IsFastForwardEnabled { get; }

        bool IsTerminateEnabled { get; }

        bool IsAppointmentsEnabled { get; }

        bool IsHangUpEnabled { get; }

        bool IsRefreshEnabled { get; }

        bool IsCheckSpellingEnabled { get; }

        /// <summary>
        /// Gets flag indicating is Logout after finish button enabled or not.
        /// </summary>
        bool IsLogoutAfterFinishingEnabled { get; set; }

        /// <summary>
        /// </summary>
        bool IsPendingBreakChecked { get; set; }

        bool IsChangeTaskChoiceChecked { get; set; }

        /// <summary>
        /// Gets flag indicating is Pending break button enabled or not.
        /// </summary>
        bool IsPendingBreakEnabled { get; set; }

        bool IsDialCanellationButtonEnabled { get; set; }

        Color DefaultControlColor { get; set; }

        /// <summary>
        /// Shows log in form and disables all other controls.
        /// </summary>
        void ShowLoginForm();

        /// <summary>
        /// Shows redial button in form.
        /// </summary>
        void ShowRedialButton(bool show);

        /// <summary>
        /// Shows internal call transfer button in form.
        /// </summary>
        void ShowInternalCallTransferButton(bool show);

        /// <summary>
        /// Shows external call transfer button in form.
        /// </summary>
        void ShowExternalCallTransferButton(bool show);

        void SetAutoPilotMode();

        /// <summary>
        /// Shows ChangePassword form
        /// </summary>
        void ShowChangePasswordForm();

        /// <summary>
        /// Clear state of visual components
        /// </summary>
        void ClearVisualState();

        /// <summary>
        /// Shows ExtensionNumber form
        /// </summary>
        LoginToDiallerResult ShowExtensionNumberForm();
		
        void ShowInterviewPageControl(ToolbarState state);

        /// <summary>
        /// Disables all toolbars
        /// </summary>
        void DisableToolbars();

        void EnableTelephonyToolbar(bool enableAllExceptRedial, bool enableRedial, ToolbarState state);

        /// <summary>
        /// Enables/Disables Appointment button in the interview toolbar
        /// </summary>
        void EnableAppointmentButton(bool enable);

        /// <summary>
        /// Enables/Disables Terminate button in the interview toolbar
        /// </summary>
        void EnableTerminateButton(bool enable);

		/// <summary>
		/// Shows survey list control and hides all other controls.
		/// </summary>
        void ShowSurveyListControl(ToolbarState state);

        /// <summary>
        /// Shows dial contorl and hides all other controls.
        /// </summary>
        void ShowDialControl();

        /// <summary>
        /// Show hang up control and hides all other controls.
        /// </summary>
        void ShowHangupControl();

        /// <summary>
        /// Show internal transfer control and hide all other controls.
        /// </summary>
        void ShowInternalTransferControl(ILocalizationManager manager, string surveyName, string respondentName, string trasferingInterviewer, string interviewId);

        /// <summary>
        /// Show login to dialer control and hides all other controls. This function enables Logout toolbar button.
        /// </summary>
        /// <param name="processMessage">This message will be shown while processing.</param>
        void ShowProcessControl(string processMessage);

        /// <summary>
        /// Show login to dialer control and hides all other controls. If enableLogout flag is true,
        /// toolbar button Logout will not be enabled.
        /// </summary>
        /// <param name="processMessage">This message will be shown while processing.</param>
        /// <param name="logoutEnabled">Flag indicates should we enable toolbar Logout button or not.</param>
        /// <param name="pendingBreakEnabled">Flag indicates will be PendingBreak button enabled while operation or not.</param>
        void ShowProcessControl(string processMessage, bool logoutEnabled, bool pendingBreakEnabled);

		/// <summary>
		/// Shows form without any controls on it.
		/// </summary>
		void ShowBlankForm();

		/// <summary>
		/// Closes form.
		/// </summary>
		void CloseForm();

        /// <summary>
        /// Restart current application
        /// </summary>
        void RestartApplication();

        /// <summary>
        /// Changes toolbar messagin icon
        /// </summary>
        /// <param name="newMessageIn"></param>
        void ChangeToolbarMessagingIcon(bool newMessageIn);

        /// <summary>
        /// Shows or hides Playback toolbar 
        /// </summary>
        /// <param name="isVisible"> </param>
        /// <param name="pauseIsAvailable"> </param>
        /// <param name="toggleVoiceSourceIsAvailable"> </param>
        void ShowPlaybackToolbar(bool isVisible, bool pauseIsAvailable, bool toggleVoiceSourceIsAvailable);

        /// <summary>
        /// Set visibility fot dial cancellation button
        /// </summary>
        void SetDialCanellationButtonVisibility(bool isVisible);

        /// <summary>
        /// Update connection indicator icon
        /// </summary>
        void UpdateConnectionIndicator(ConnectionQuality quality);

        /// <summary>
        /// Occurs when form is loaded.
        /// </summary>
        event EventHandler<EventArgs> FormLoad;

        /// <summary>
        /// Occures when user is going to close form.
        /// </summary>
        event FormClosingEventHandler FormExiting;

		/// <summary>
		/// Occurs when the form is closed.
		/// </summary>
		event EventHandler<EventArgs> FormClose;

        /// <summary>
        /// Occures when user is going to start new interview.
        /// </summary>
        event EventHandler<EventArgs> NewInterview;

		/// <summary>
		/// Occures when user is going to see previous interview page.
		/// </summary>
		event EventHandler<EventArgs> PreviousPage;

		/// <summary>
		/// Occures when user is going to see next interview page.
		/// </summary>
		event EventHandler<EventArgs> NextPage;

		/// <summary>
		/// Occurs when user is going to see appointments editing dialog.
		/// </summary>
		event EventHandler<EventArgs> ShowAppointments;

        event EventHandler<EventArgs> ShowRedialForm;

		/// <summary>
		/// Occurs when user is going to log out.
		/// </summary>
		event EventHandler<EventArgs> Logout;

        /// <summary>
        /// Occurs when user is going to set pending break.
        /// </summary>
        event EventHandler<EventArgs> PendingBreak;

        event EventHandler<EventArgs> ChangeTaskChoice;

        event EventHandler<EventArgs> FormActivated;
        
		/// <summary>
		/// Occurs when current interview is going to be terminated.
		/// </summary>
		event EventHandler<EventArgs> TerminateInterview;

		/// <summary>
		/// Occurs when user changed selected language for survey.
		/// </summary>
		event EventHandler<EventArgs> SelectedSurveyLanguageChanged;

        /// <summary>
        /// Occurs when user is going to open redo drop-down list.
        /// </summary>
        event EventHandler<EventArgs> RedoDropDownOpening;

        /// <summary>
        /// Occurs when user opens redo drop-down list.
        /// </summary>
        event EventHandler<EventArgs> RedoDropDownOpen;

        /// <summary>
        /// Occurs when user closes redo drop-down list.
        /// </summary>
        event EventHandler<EventArgs> RedoDropDownClose;

        /// <summary>
        /// Occurs when user click pending logout while interviewing process
        /// </summary>
        event EventHandler<EventArgs> PendingLogout;

        /// <summary>
        /// Occurs when user selected question in redo list.
        /// </summary>
        event EventHandler<EventArgs> RedoQuestionChanged;

        /// <summary>
        /// Occurs when user is going to do fast forward.
        /// </summary>
        event EventHandler<EventArgs> FastForward;

        /// <summary>
        /// Occurs when user is going to hang up.
        /// </summary>
        event EventHandler<EventArgs> HangUp;        
        
        /// <summary>
        /// Occurs when user is going to do internal call transfer.
        /// </summary>
        event EventHandler<EventArgs> InternalCallTransfer;

        /// <summary>
        /// Occurs when user is going to do external call transfer.
        /// </summary>
        event EventHandler<EventArgs> ExternalCallTransfer;

        /// <summary>
        /// Occurs when user is going to refresh current interview list.
        /// </summary>
        event EventHandler<EventArgs> RefreshInterviewList;

        /// <summary>
        /// Occurs when user is going to see appointments list.
        /// </summary>
        event EventHandler<EventArgs> ShowInterviewerAppointments;
        
        /// <summary>
        /// Occurs when user is going to open MessagingForm.
        /// </summary>
        event EventHandler<EventArgs> ShowMessagingForm;

        /// <summary>
        /// Occurs when user is going to check spelling.
        /// </summary>
        event EventHandler<EventArgs> SpellCheck;

        /// <summary>
        /// Occurs when user is going to play sound file to respondent.
        /// </summary>
        event EventHandler<EventArgs> StartPlayback;

        /// <summary>
        /// Occurs when user is going to pause/resume playing sound file to respondent.
        /// </summary>
        event EventHandler<EventArgs> PauseOrResumePlayback;

        /// <summary>
        /// Occurs when user is going to pause/resume playing sound file to respondent.
        /// </summary>
        event EventHandler<EventArgs> StopPlayback;

        /// <summary>
        /// Occurs when user is going to switch agent from hear respondent to hear playing and back.
        /// </summary>
        event EventHandler<EventArgs> ToggleInterviewerListensToPlaybackOrRespondent;

        /// <summary>
        /// Occurs when user press any key.
        /// </summary>
        event EventHandler<ProcessCmdKeyEventArgs> FormProcessCmdKey;

        /// <summary>
        /// Occurs when user press cancel button during dialing process.
        /// </summary>
        event EventHandler<DialCancellationEventArgs> CancelDialing;

        void ShowOnABreakControl();

        void SpecifyMainFormStyle(string title, Color color, bool isInboundCall, bool isTestMode);

        void ClickPendingBreak();

        void BindBreakTypes(List<BreakType> breakTypes);

        void ShowBreakDetails(bool displayBreakType, string breakInfo);

        void ShowPendingBreakDropdown();

        void UpdatePendingBreakControls(bool cleanCheckedItems = false);
    }
}
