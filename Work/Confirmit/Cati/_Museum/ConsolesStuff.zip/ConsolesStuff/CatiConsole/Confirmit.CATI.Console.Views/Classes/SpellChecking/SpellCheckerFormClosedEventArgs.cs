﻿using System;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.Classes.SpellChecking
{
    public class SpellCheckerFormClosedEventArgs : EventArgs
    {
        public DialogResult Result
        {
            get; 
            set;
        }
    }
}