﻿using Confirmit.CATI.Console.Views.Classes.Localization;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Represents view interface for GetInternalTransfer control.
    /// </summary>
    public interface IViewGetInternalTransferControl : ILocalizableView
    {
        void Localize(ILocalizationManager manager, string surveyName, string respondentName, string transferingInterviewer, string interviewId);
    }
}
