﻿using Confirmit.CATI.Common.ConsoleService.Abstract;
using System;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    public interface IViewWarmTransferForm : ILocalizableView, IDisposable
    {
        /// <summary>
		/// Occurs when user clicks Ok button.
		/// </summary>
		event EventHandler<EventArgs> OnCompleteClick;

        /// <summary>
        /// Occurs when user clicks Cancel button or manualy closes form
        /// </summary>
        event EventHandler<EventArgs> OnCancelClick;

        /// <summary>
        /// Occurs when need to merge an interviewer, a current respondent and a transfer target to one call
        /// </summary>
        event EventHandler<EventArgs> OnMergeClick;

        /// <summary>
        /// Occurs when need to do a private call with an interviewer and a current respondent (without a transfer target)
        /// </summary>
        event EventHandler<EventArgs> OnTalkPrivatelyWithRespondentClick;

        /// <summary>
        /// Occurs when need to do a private call with an interviewer and a transfer target (without a current respondent)
        /// </summary>
        event EventHandler<EventArgs> OnTalkPrivatelyWithTransferTargetClick;

        void ShowForm(ConsoleTransferState transferstate);

        void CloseForm();
    }
}
