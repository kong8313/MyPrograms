﻿using System;

namespace Confirmit.CATI.Console.Views.Classes.SearchableGrid
{
    /// <summary>
    /// Represents class which contains data of ColumnSortModeChanged event.
    /// </summary>
    public class ColumnSortModeChangedEventArgs : EventArgs
    {
        #region Constructors

        /// <summary>
        /// Initialiazes a new instance of ColumnSortModeChangedEventArgs and fills
        /// it with column index.
        /// </summary>
        /// <param name="columnIndex">Sortable column index.</param>
        public ColumnSortModeChangedEventArgs(int columnIndex)
        {
            ColumnIndex = columnIndex;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the index of column which has changed sort mode.
        /// </summary>
        public int ColumnIndex
        {
            get;
            private set;
        }

        #endregion
    }
}
