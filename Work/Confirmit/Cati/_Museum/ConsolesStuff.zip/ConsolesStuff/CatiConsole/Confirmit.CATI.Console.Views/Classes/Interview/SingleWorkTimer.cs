﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{    
    /// <summary>
    /// Class does some work after delay
    /// </summary>
    public class DelayWorkManager
    {        
        private Timer m_Timer;
        private int m_DelayTimeout = 200;

        private object m_Arg = null;
        private Action m_SingleWorkEventHandler = null;
        private Action<object> m_SingleWorkEventHandlerWithArgument = null;
        
        /// <summary>
        /// Constructor
        /// </summary>        
        public DelayWorkManager(Action singleWorkEventHandler)
        {
            m_SingleWorkEventHandler = singleWorkEventHandler;
        }

        /// <summary>
        /// DelayWorkManager constructors
        /// </summary>
        /// <param name="singleWorkEventHandler">Method that will run after delay</param>
        /// <param name="delay">Timeout before work in milliseconds</param>
        public DelayWorkManager(Action singleWorkEventHandler, int delay)
            : this(singleWorkEventHandler)
        {
            m_DelayTimeout = delay;
        }

        /// <summary>
        /// DelayWorkManager constructors
        /// </summary>
        /// <param name="singleWorkEventHandler">Method that will run after delay</param>
        /// <param name="delay">Timeout before work in milliseconds</param>
        /// <param name="args">Argument for function</param>
        public DelayWorkManager(Action<object> singleWorkEventHandlerWithArgument, int delay, object arg)        
        {
            m_Arg = arg;
            m_DelayTimeout = delay;
            m_SingleWorkEventHandlerWithArgument = singleWorkEventHandlerWithArgument;            
        }

        /// <summary>
        /// Starts work. If delay is 0, passed function will be called immediately;
        /// otherwise timer will be started.
        /// </summary>
        public void Run()
        {
            if (m_DelayTimeout == 0)
            {
                DoWork();
            }
            else
            {
                StartTimer();
            }
        }

        /// <summary>
        /// Initializes and starts timer.
        /// </summary>
        private void StartTimer()
        {            
            m_Timer = new Timer();
            m_Timer.Interval = m_DelayTimeout;
            m_Timer.Tick += new EventHandler(m_Timer_Tick);
            m_Timer.Start();
        }

        /// <summary>
        /// Stops and releases timer.
        /// </summary>
        private void StopTimer()
        {
            if (m_Timer == null) return;

            m_Timer.Stop();
            m_Timer.Tick -= new EventHandler(m_Timer_Tick);
            m_Timer.Dispose();
            m_Timer = null;
        }

        /// <summary>
        /// Timer tick event handler        
        /// </summary>
        private void m_Timer_Tick(object sender, EventArgs e)
        {
            StopTimer();

            DoWork();                 
        }

        private void DoWork()
        {
            if (m_SingleWorkEventHandler != null)
            {
                m_SingleWorkEventHandler();
            }
            else if (m_SingleWorkEventHandlerWithArgument != null)
            {
                m_SingleWorkEventHandlerWithArgument(m_Arg);
            }
        }
    }
}
