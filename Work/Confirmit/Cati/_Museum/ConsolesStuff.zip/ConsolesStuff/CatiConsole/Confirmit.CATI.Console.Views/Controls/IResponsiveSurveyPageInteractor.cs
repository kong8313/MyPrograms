﻿namespace Confirmit.CATI.Console.Views.Controls
{
    public interface IResponsiveSurveyPageInteractor
    {
        string GetQuestionType(string questionId);
        void SetBoolValueForInnerQuestion(string questionId, string innerQuestionId, string innerPrecode, bool b);
        void SetBoolValue(string questionId, bool b, string precode);
        void SetStringValue(string questionId, string value, string precode = "");
        void SetOtherValue(string questionId, string precode, string predefinedAnswer);
    }
}