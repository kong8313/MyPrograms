﻿using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
    /// <summary>
    /// Represents license agreement form.
    /// </summary>
    public partial class LicenseForm : Form, IViewLicenseForm
    {
        #region Constructors

        public LicenseForm()
        {
            InitializeComponent();
            Icon = Properties.Resources.AppIcon;
        }

        #endregion

        #region IViewLicenseForm Members

        /// <summary>
        /// Gets/sets license text.
        /// </summary>
        public string DocumentText
        {
            get
            {
                return webBrowser.DocumentText;
            }
            set
            {
                webBrowser.DocumentText = value;
            }
        }

        /// <summary>
        /// Shows/hides panel with buttons.
        /// </summary>
        public bool ButtonsVisible
        {
            get
            {
                return pnlButtons.Visible;
            }
            set
            {
                pnlButtons.Visible = value;
            }
        }

        /// <summary>
        /// Shows modal license form.
        /// </summary>
        /// <returns>Retruns dialog result.</returns>
        public new DialogResult Show()
        {
            return ShowDialog();
        }

        #endregion

        #region ILocalizableView Members

        public void Localize(ILocalizationManager manager)
        {
            Text = manager.GetString("LicenseForm_Caption");
            btnAccept.Text = manager.GetString("LicenseForm_ButtonAccept_Text");
            btnDecline.Text = manager.GetString("LicenseForm_ButtonDecline_Text");
        }

        #endregion
    }
}
