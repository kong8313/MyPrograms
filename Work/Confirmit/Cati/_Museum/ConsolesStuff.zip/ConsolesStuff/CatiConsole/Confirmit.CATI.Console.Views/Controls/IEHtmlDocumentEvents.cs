using System;
using Confirmit.CATI.Console.Views.Classes.Interview;
using mshtml;

namespace Confirmit.CATI.Console.Views.Controls
{
	/// <summary>
	/// Summary description for IEHtmlDocumentEvents.
	/// </summary>
	public class IEHtmlDocumentEvents : mshtml.HTMLDocumentEvents2
	{
        public void onkeydown(mshtml.IHTMLEventObj pEvtObj)
        {
            if (pEvtObj == null)
                throw new ArgumentNullException(String.Empty, String.Empty);

            if (pEvtObj.altKey)
            {
                switch (pEvtObj.keyCode)
                {
                    // you can add what ever keys you want to handle here
                    case 37:
                        pEvtObj.cancelBubble = true;
                        pEvtObj.keyCode = 0;
                        break;
                    default:
                        break;
                }
            }
            else
            {
                if (IsRestrictedBrowserShortcut(pEvtObj))
                {
                    pEvtObj.cancelBubble = true;
                    pEvtObj.keyCode = 0;
                    pEvtObj.returnValue = false;
                }

                // 116(F5), 8(Back), 18(Atl->), ESC, Tab
                if (pEvtObj.keyCode == 116 || pEvtObj.keyCode == 8 || pEvtObj.keyCode == 18 || pEvtObj.keyCode == 9)
                {                    
                    pEvtObj.cancelBubble = true;
                    pEvtObj.keyCode = 0;                    
                }
            }
        }

	    #region Unused methods

		public void ondataavailable(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public bool onbeforedeactivate(mshtml.IHTMLEventObj pEvtObj)
		{
			return true;
		}

		public bool onstop(mshtml.IHTMLEventObj pEvtObj)
		{
			return true;
		}

		public void onrowsinserted(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public bool onselectstart(mshtml.IHTMLEventObj pEvtObj)
		{
			return true;
		}

		public bool onkeypress(mshtml.IHTMLEventObj pEvtObj)
		{
			return true;
		}

		public bool onhelp(mshtml.IHTMLEventObj pEvtObj)
		{
			return true;
		}

		public void onpropertychange(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void oncellchange(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public bool oncontextmenu(mshtml.IHTMLEventObj pEvtObj)
		{
			return false; // Cancel the context menu
		}

		public bool ondblclick(mshtml.IHTMLEventObj pEvtObj)
		{
			return true;
		}

		public void onfocusin(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void ondatasetcomplete(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void onkeyup(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void onfocusout(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void onbeforeeditfocus(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public bool ondragstart(mshtml.IHTMLEventObj pEvtObj)
		{
			return true;
		}

		public bool oncontrolselect(mshtml.IHTMLEventObj pEvtObj)
		{
			return true;
		}

		public void onactivate(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void onmouseup(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public bool onbeforeactivate(mshtml.IHTMLEventObj pEvtObj)
		{
			return true;
		}

		public bool onrowexit(mshtml.IHTMLEventObj pEvtObj)
		{
			return true;
		}

		public bool onbeforeupdate(mshtml.IHTMLEventObj pEvtObj)
		{
			return true;
		}

		public void onrowsdelete(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void onreadystatechange(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void onmousemove(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void onrowenter(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void onafterupdate(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void ondeactivate(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void onselectionchange(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void ondatasetchanged(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void onmouseover(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public bool onmousewheel(mshtml.IHTMLEventObj pEvtObj)
		{
            return true;
		}

		public bool onerrorupdate(mshtml.IHTMLEventObj pEvtObj)
		{
			return true;
		}

		public void onmouseout(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public void onmousedown(mshtml.IHTMLEventObj pEvtObj)
		{
		}

		public bool onclick(mshtml.IHTMLEventObj pEvtObj)
		{
            return true;
		}

		#endregion

        private static bool IsRestrictedBrowserShortcut(IHTMLEventObj pEvtObj)
        {
            /*
             * Ctrl-R (82)
             * Ctrl-O (79)
             * Ctrl-L (76)
             * Ctrl-N (78)
             * Ctrl-W (87)
             * Ctrl-S (83)
             */
            return pEvtObj.ctrlKey && 
                (pEvtObj.keyCode == 82 || pEvtObj.keyCode == 79 || pEvtObj.keyCode == 76 ||
                pEvtObj.keyCode == 78 || pEvtObj.keyCode == 87 || pEvtObj.keyCode ==83);
        }
	}
}
