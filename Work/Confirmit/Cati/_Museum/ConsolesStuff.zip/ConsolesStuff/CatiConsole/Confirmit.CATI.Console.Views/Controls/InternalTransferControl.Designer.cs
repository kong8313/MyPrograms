﻿namespace Confirmit.CATI.Console.Views.Controls
{
    partial class InternalTransferControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbTitle = new System.Windows.Forms.Label();
            this.lbSurveyName = new System.Windows.Forms.Label();
            this.lbRespondentName = new System.Windows.Forms.Label();
            this.lbTransferingInterviewer = new System.Windows.Forms.Label();
            this.lbInterviewId = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbTitle
            // 
            this.lbTitle.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitle.Location = new System.Drawing.Point(3, 0);
            this.lbTitle.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Size = new System.Drawing.Size(420, 25);
            this.lbTitle.TabIndex = 2;
            this.lbTitle.Text = "Incoming call transfer";
            this.lbTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbSurveyName
            // 
            this.lbSurveyName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbSurveyName.AutoEllipsis = true;
            this.lbSurveyName.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSurveyName.Location = new System.Drawing.Point(0, 55);
            this.lbSurveyName.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.lbSurveyName.Name = "lbSurveyName";
            this.lbSurveyName.Size = new System.Drawing.Size(507, 20);
            this.lbSurveyName.TabIndex = 4;
            this.lbSurveyName.Text = "Survey Name: OlympicCodedUIPreviewerDialer_022119_15_17_30 (p2459657)";
            this.lbSurveyName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbRespondentName
            // 
            this.lbRespondentName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbRespondentName.AutoEllipsis = true;
            this.lbRespondentName.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRespondentName.Location = new System.Drawing.Point(0, 95);
            this.lbRespondentName.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.lbRespondentName.Name = "lbRespondentName";
            this.lbRespondentName.Size = new System.Drawing.Size(507, 20);
            this.lbRespondentName.TabIndex = 5;
            this.lbRespondentName.Text = "Respondent Name: Peter Parker";
            this.lbRespondentName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbTransferingInterviewer
            // 
            this.lbTransferingInterviewer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbTransferingInterviewer.AutoEllipsis = true;
            this.lbTransferingInterviewer.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTransferingInterviewer.Location = new System.Drawing.Point(0, 135);
            this.lbTransferingInterviewer.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.lbTransferingInterviewer.Name = "lbTransferingInterviewer";
            this.lbTransferingInterviewer.Size = new System.Drawing.Size(507, 20);
            this.lbTransferingInterviewer.TabIndex = 6;
            this.lbTransferingInterviewer.Text = "Transferring Interviewer: Lord Volandemort";
            this.lbTransferingInterviewer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbInterviewId
            // 
            this.lbInterviewId.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbInterviewId.AutoEllipsis = true;
            this.lbInterviewId.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbInterviewId.Location = new System.Drawing.Point(0, 175);
            this.lbInterviewId.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.lbInterviewId.Name = "lbInterviewId";
            this.lbInterviewId.Size = new System.Drawing.Size(507, 20);
            this.lbInterviewId.TabIndex = 7;
            this.lbInterviewId.Text = "Interview ID: 1234567";
            this.lbInterviewId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // InternalTransferControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.lbInterviewId);
            this.Controls.Add(this.lbTransferingInterviewer);
            this.Controls.Add(this.lbRespondentName);
            this.Controls.Add(this.lbSurveyName);
            this.Controls.Add(this.lbTitle);
            this.Name = "InternalTransferControl";
            this.Size = new System.Drawing.Size(507, 220);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbTitle;
        private System.Windows.Forms.Label lbSurveyName;
        private System.Windows.Forms.Label lbRespondentName;
        private System.Windows.Forms.Label lbTransferingInterviewer;
        private System.Windows.Forms.Label lbInterviewId;
    }
}
