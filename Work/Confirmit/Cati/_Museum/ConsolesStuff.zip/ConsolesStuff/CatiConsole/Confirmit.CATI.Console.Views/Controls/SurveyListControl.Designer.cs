﻿namespace Confirmit.CATI.Console.Views.Controls
{
	partial class SurveyListControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.lvSurveyList = new System.Windows.Forms.ListView();
            this.chSurveyName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.splSurveySplitter = new System.Windows.Forms.SplitContainer();
            this.btnResetAllFilters = new System.Windows.Forms.Button();
            this.btnStartSelected = new System.Windows.Forms.Button();
            this.btnCreateNew = new System.Windows.Forms.Button();
            this.m_grid = new Confirmit.CATI.Console.Views.Controls.SearchableGrid();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splSurveySplitter)).BeginInit();
            this.splSurveySplitter.Panel1.SuspendLayout();
            this.splSurveySplitter.Panel2.SuspendLayout();
            this.splSurveySplitter.SuspendLayout();
            this.SuspendLayout();
            // 
            // lvSurveyList
            // 
            this.lvSurveyList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chSurveyName});
            this.lvSurveyList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvSurveyList.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lvSurveyList.FullRowSelect = true;
            this.lvSurveyList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvSurveyList.HideSelection = false;
            this.lvSurveyList.Location = new System.Drawing.Point(0, 0);
            this.lvSurveyList.MultiSelect = false;
            this.lvSurveyList.Name = "lvSurveyList";
            this.lvSurveyList.Size = new System.Drawing.Size(220, 341);
            this.lvSurveyList.TabIndex = 0;
            this.lvSurveyList.UseCompatibleStateImageBehavior = false;
            this.lvSurveyList.View = System.Windows.Forms.View.Details;
            this.lvSurveyList.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.lvSurveyList_ItemSelectionChanged);
            this.lvSurveyList.DoubleClick += new System.EventHandler(this.lvSurveyList_DoubleClick);
            this.lvSurveyList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lvSurveyList_KeyUp);
            // 
            // chSurveyName
            // 
            this.chSurveyName.Text = "Survey name";
            this.chSurveyName.Width = 153;
            // 
            // splSurveySplitter
            // 
            this.splSurveySplitter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splSurveySplitter.Location = new System.Drawing.Point(0, 0);
            this.splSurveySplitter.Name = "splSurveySplitter";
            // 
            // splSurveySplitter.Panel1
            // 
            this.splSurveySplitter.Panel1.Controls.Add(this.lvSurveyList);
            // 
            // splSurveySplitter.Panel2
            // 
            this.splSurveySplitter.Panel2.Controls.Add(this.btnResetAllFilters);
            this.splSurveySplitter.Panel2.Controls.Add(this.btnStartSelected);
            this.splSurveySplitter.Panel2.Controls.Add(this.btnCreateNew);
            this.splSurveySplitter.Panel2.Controls.Add(this.m_grid);
            this.splSurveySplitter.Size = new System.Drawing.Size(866, 341);
            this.splSurveySplitter.SplitterDistance = 220;
            this.splSurveySplitter.TabIndex = 3;
            this.splSurveySplitter.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splSurveySplitter_SplitterMoved);
            // 
            // btnResetAllFilters
            // 
            this.btnResetAllFilters.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnResetAllFilters.BackgroundImage = global::Confirmit.CATI.Console.Views.Properties.Resources.ResetFilters;
            this.btnResetAllFilters.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnResetAllFilters.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnResetAllFilters.FlatAppearance.BorderSize = 0;
            this.btnResetAllFilters.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnResetAllFilters.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnResetAllFilters.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResetAllFilters.Location = new System.Drawing.Point(514, 6);
            this.btnResetAllFilters.Name = "btnResetAllFilters";
            this.btnResetAllFilters.Size = new System.Drawing.Size(125, 33);
            this.btnResetAllFilters.TabIndex = 5;
            this.btnResetAllFilters.UseVisualStyleBackColor = true;
            this.btnResetAllFilters.Click += new System.EventHandler(this.btnResetAllFilters_Click);
            this.btnResetAllFilters.MouseEnter += new System.EventHandler(this.btnResetAllFilters_MouseEnter);
            this.btnResetAllFilters.MouseLeave += new System.EventHandler(this.btnResetAllFilters_MouseLeave);
            // 
            // btnStartSelected
            // 
            this.btnStartSelected.BackgroundImage = global::Confirmit.CATI.Console.Views.Properties.Resources.StartSelectedInterview;
            this.btnStartSelected.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnStartSelected.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnStartSelected.FlatAppearance.BorderSize = 0;
            this.btnStartSelected.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnStartSelected.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnStartSelected.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStartSelected.Location = new System.Drawing.Point(3, 6);
            this.btnStartSelected.Name = "btnStartSelected";
            this.btnStartSelected.Size = new System.Drawing.Size(220, 33);
            this.btnStartSelected.TabIndex = 4;
            this.btnStartSelected.UseVisualStyleBackColor = true;
            this.btnStartSelected.Click += new System.EventHandler(this.btnStartSelected_Click);
            this.btnStartSelected.MouseEnter += new System.EventHandler(this.btnStartSelected_MouseEnter);
            this.btnStartSelected.MouseLeave += new System.EventHandler(this.btnStartSelected_MouseLeave);
            // 
            // btnCreateNew
            // 
            this.btnCreateNew.BackgroundImage = global::Confirmit.CATI.Console.Views.Properties.Resources.CreateNewInterview;
            this.btnCreateNew.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnCreateNew.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnCreateNew.FlatAppearance.BorderSize = 0;
            this.btnCreateNew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnCreateNew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnCreateNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateNew.Location = new System.Drawing.Point(228, 6);
            this.btnCreateNew.Name = "btnCreateNew";
            this.btnCreateNew.Size = new System.Drawing.Size(203, 33);
            this.btnCreateNew.TabIndex = 3;
            this.btnCreateNew.UseVisualStyleBackColor = true;
            this.btnCreateNew.Click += new System.EventHandler(this.btnCreateNew_Click);
            this.btnCreateNew.MouseEnter += new System.EventHandler(this.btnCreateNew_MouseEnter);
            this.btnCreateNew.MouseLeave += new System.EventHandler(this.btnCreateNew_MouseLeave);
            // 
            // m_grid
            // 
            this.m_grid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_grid.Location = new System.Drawing.Point(0, 43);
            this.m_grid.Margin = new System.Windows.Forms.Padding(0);
            this.m_grid.Name = "m_grid";
            this.m_grid.Size = new System.Drawing.Size(642, 298);
            this.m_grid.TabIndex = 0;
            this.m_grid.ColumnSortModeChanged += new System.EventHandler<Confirmit.CATI.Console.Views.Classes.SearchableGrid.ColumnSortModeChangedEventArgs>(this.m_grid_ColumnSortModeChanged);
            // 
            // SurveyListControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splSurveySplitter);
            this.Name = "SurveyListControl";
            this.Size = new System.Drawing.Size(866, 341);
            this.Resize += new System.EventHandler(this.SurveyListControl_Resize);
            this.splSurveySplitter.Panel1.ResumeLayout(false);
            this.splSurveySplitter.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splSurveySplitter)).EndInit();
            this.splSurveySplitter.ResumeLayout(false);
            this.ResumeLayout(false);

		}

		#endregion

        private System.Windows.Forms.ListView lvSurveyList;
        private System.Windows.Forms.ColumnHeader chSurveyName;
        private System.Windows.Forms.SplitContainer splSurveySplitter;
        private SearchableGrid m_grid;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Button btnStartSelected;
        private System.Windows.Forms.Button btnCreateNew;
        private System.Windows.Forms.Button btnResetAllFilters;
    }
}
