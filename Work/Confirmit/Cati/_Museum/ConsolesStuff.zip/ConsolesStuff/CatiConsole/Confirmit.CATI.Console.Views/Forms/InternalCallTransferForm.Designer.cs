﻿using Confirmit.CATI.Console.Views.Controls;

namespace Confirmit.CATI.Console.Views.Forms
{
    partial class InternalCallTransferForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlTitle = new System.Windows.Forms.Panel();
            this.lbTitleDescription = new System.Windows.Forms.Label();
            this.lbTitle = new System.Windows.Forms.Label();
            this.pbTitle = new System.Windows.Forms.PictureBox();
            this.buttonTransfer = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewSearchTextColumn1 = new Confirmit.CATI.Console.Views.Classes.SearchableGrid.DataGridViewSearchTextColumn();
            this.dataGridViewSearchTextColumn2 = new Confirmit.CATI.Console.Views.Classes.SearchableGrid.DataGridViewSearchTextColumn();
            this.dataGridViewSearchTextColumn3 = new Confirmit.CATI.Console.Views.Classes.SearchableGrid.DataGridViewSearchTextColumn();
            this.dataGridViewSearchTextColumn4 = new Confirmit.CATI.Console.Views.Classes.SearchableGrid.DataGridViewSearchTextColumn();
            this.grid = new System.Windows.Forms.DataGridView();
            this.TargetIcon = new System.Windows.Forms.DataGridViewImageColumn();
            this.TargetName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NumberOfInterviewersInWaitingOrSelectingState = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NumberOfWorkingInterviewers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlTitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTitle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTitle
            // 
            this.pnlTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlTitle.BackColor = System.Drawing.Color.White;
            this.pnlTitle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnlTitle.Controls.Add(this.lbTitleDescription);
            this.pnlTitle.Controls.Add(this.lbTitle);
            this.pnlTitle.Controls.Add(this.pbTitle);
            this.pnlTitle.Location = new System.Drawing.Point(0, 0);
            this.pnlTitle.Margin = new System.Windows.Forms.Padding(0);
            this.pnlTitle.Name = "pnlTitle";
            this.pnlTitle.Size = new System.Drawing.Size(784, 61);
            this.pnlTitle.TabIndex = 7;
            // 
            // lbTitleDescription
            // 
            this.lbTitleDescription.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lbTitleDescription.Location = new System.Drawing.Point(12, 20);
            this.lbTitleDescription.Name = "lbTitleDescription";
            this.lbTitleDescription.Size = new System.Drawing.Size(373, 39);
            this.lbTitleDescription.TabIndex = 2;
            this.lbTitleDescription.Text = "Description";
            // 
            // lbTitle
            // 
            this.lbTitle.AutoSize = true;
            this.lbTitle.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lbTitle.Location = new System.Drawing.Point(12, 4);
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Size = new System.Drawing.Size(32, 13);
            this.lbTitle.TabIndex = 1;
            this.lbTitle.Text = "Title";
            // 
            // pbTitle
            // 
            this.pbTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbTitle.Image = global::Confirmit.CATI.Console.Views.Properties.Resources.InternalCallTransferTitle;
            this.pbTitle.Location = new System.Drawing.Point(679, 0);
            this.pbTitle.Name = "pbTitle";
            this.pbTitle.Size = new System.Drawing.Size(105, 61);
            this.pbTitle.TabIndex = 0;
            this.pbTitle.TabStop = false;
            // 
            // buttonTransfer
            // 
            this.buttonTransfer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonTransfer.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.buttonTransfer.Location = new System.Drawing.Point(630, 432);
            this.buttonTransfer.Margin = new System.Windows.Forms.Padding(3, 3, 2, 6);
            this.buttonTransfer.Name = "buttonTransfer";
            this.buttonTransfer.Size = new System.Drawing.Size(75, 23);
            this.buttonTransfer.TabIndex = 5;
            this.buttonTransfer.Text = "Transfer";
            this.buttonTransfer.UseVisualStyleBackColor = true;
            this.buttonTransfer.Click += new System.EventHandler(this.buttonTransfer_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCancel.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.buttonCancel.Location = new System.Drawing.Point(709, 432);
            this.buttonCancel.Margin = new System.Windows.Forms.Padding(2, 3, 5, 6);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 6;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 150F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Group name";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.HeaderText = "Description";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle1.Format = "N0";
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewTextBoxColumn3.FillWeight = 180F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Number of interviewers in waiting or selecting state";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 180;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle2.Format = "N0";
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn4.FillWeight = 180F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Number of working interviewers in the group";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 180;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Column2";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Column3";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Column4";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Column5";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewSearchTextColumn1
            // 
            this.dataGridViewSearchTextColumn1.HeaderText = "Name";
            this.dataGridViewSearchTextColumn1.Name = "dataGridViewSearchTextColumn1";
            this.dataGridViewSearchTextColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewSearchTextColumn2
            // 
            this.dataGridViewSearchTextColumn2.HeaderText = "Description";
            this.dataGridViewSearchTextColumn2.Name = "dataGridViewSearchTextColumn2";
            this.dataGridViewSearchTextColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewSearchTextColumn3
            // 
            dataGridViewCellStyle3.Format = "N0";
            dataGridViewCellStyle3.NullValue = null;
            this.dataGridViewSearchTextColumn3.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewSearchTextColumn3.HeaderText = "Number of working interviewers";
            this.dataGridViewSearchTextColumn3.Name = "dataGridViewSearchTextColumn3";
            this.dataGridViewSearchTextColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewSearchTextColumn4
            // 
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = null;
            this.dataGridViewSearchTextColumn4.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewSearchTextColumn4.HeaderText = "Interviewers in waiting or selecting state";
            this.dataGridViewSearchTextColumn4.Name = "dataGridViewSearchTextColumn4";
            this.dataGridViewSearchTextColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // grid
            // 
            this.grid.AllowUserToAddRows = false;
            this.grid.AllowUserToDeleteRows = false;
            this.grid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grid.BackgroundColor = System.Drawing.SystemColors.Window;
            this.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TargetIcon,
            this.TargetName,
            this.Description,
            this.NumberOfInterviewersInWaitingOrSelectingState,
            this.NumberOfWorkingInterviewers});
            this.grid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grid.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.grid.Location = new System.Drawing.Point(0, 67);
            this.grid.Margin = new System.Windows.Forms.Padding(6, 6, 6, 3);
            this.grid.MultiSelect = false;
            this.grid.Name = "grid";
            this.grid.ReadOnly = true;
            this.grid.RowHeadersVisible = false;
            this.grid.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid.Size = new System.Drawing.Size(784, 359);
            this.grid.TabIndex = 11;
            this.grid.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.grid_CellMouseDoubleClick);
            // 
            // TargetIcon
            // 
            this.TargetIcon.FillWeight = 28F;
            this.TargetIcon.HeaderText = "";
            this.TargetIcon.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.TargetIcon.MinimumWidth = 28;
            this.TargetIcon.Name = "TargetIcon";
            this.TargetIcon.ReadOnly = true;
            this.TargetIcon.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.TargetIcon.Width = 28;
            // 
            // TargetName
            // 
            this.TargetName.FillWeight = 150F;
            this.TargetName.HeaderText = "Group name";
            this.TargetName.Name = "TargetName";
            this.TargetName.ReadOnly = true;
            this.TargetName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.TargetName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TargetName.Width = 150;
            // 
            // Description
            // 
            this.Description.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Description.HeaderText = "Description";
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            this.Description.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Description.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // NumberOfInterviewersInWaitingOrSelectingState
            // 
            dataGridViewCellStyle5.Format = "N0";
            this.NumberOfInterviewersInWaitingOrSelectingState.DefaultCellStyle = dataGridViewCellStyle5;
            this.NumberOfInterviewersInWaitingOrSelectingState.FillWeight = 150F;
            this.NumberOfInterviewersInWaitingOrSelectingState.HeaderText = "Number of interviewers in waiting or selecting state";
            this.NumberOfInterviewersInWaitingOrSelectingState.Name = "NumberOfInterviewersInWaitingOrSelectingState";
            this.NumberOfInterviewersInWaitingOrSelectingState.ReadOnly = true;
            this.NumberOfInterviewersInWaitingOrSelectingState.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.NumberOfInterviewersInWaitingOrSelectingState.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NumberOfInterviewersInWaitingOrSelectingState.Width = 150;
            // 
            // NumberOfWorkingInterviewers
            // 
            dataGridViewCellStyle6.Format = "N0";
            this.NumberOfWorkingInterviewers.DefaultCellStyle = dataGridViewCellStyle6;
            this.NumberOfWorkingInterviewers.FillWeight = 150F;
            this.NumberOfWorkingInterviewers.HeaderText = "Number of working interviewers in the group";
            this.NumberOfWorkingInterviewers.Name = "NumberOfWorkingInterviewers";
            this.NumberOfWorkingInterviewers.ReadOnly = true;
            this.NumberOfWorkingInterviewers.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.NumberOfWorkingInterviewers.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NumberOfWorkingInterviewers.Width = 150;
            // 
            // InternalCallTransferForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(784, 457);
            this.Controls.Add(this.pnlTitle);
            this.Controls.Add(this.grid);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonTransfer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "InternalCallTransferForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Internal call transfer";
            this.pnlTitle.ResumeLayout(false);
            this.pnlTitle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTitle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);

        }


        #endregion
        private Classes.SearchableGrid.DataGridViewSearchTextColumn dataGridViewSearchTextColumn1;
        private Classes.SearchableGrid.DataGridViewSearchTextColumn dataGridViewSearchTextColumn2;
        private Classes.SearchableGrid.DataGridViewSearchTextColumn dataGridViewSearchTextColumn3;
        private Classes.SearchableGrid.DataGridViewSearchTextColumn dataGridViewSearchTextColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.Button buttonTransfer;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Panel pnlTitle;
        private System.Windows.Forms.Label lbTitleDescription;
        private System.Windows.Forms.Label lbTitle;
        private System.Windows.Forms.PictureBox pbTitle;
        private System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.DataGridViewImageColumn TargetIcon;
        private System.Windows.Forms.DataGridViewTextBoxColumn TargetName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn NumberOfInterviewersInWaitingOrSelectingState;
        private System.Windows.Forms.DataGridViewTextBoxColumn NumberOfWorkingInterviewers;
    }
}