﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
    public partial class ChangePasswordForm : Form, IViewChangePasswordForm
    {
        private string _passwordWarningMessage;

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, int wParam, [MarshalAs(UnmanagedType.LPWStr)] string lParam);

        private bool _clearUserTextBox;
        private bool _clearCompanyAliasTextBox;

        public ChangePasswordForm()
        {
            InitializeComponent();
            Icon = Properties.Resources.AppIcon;
        }

        public void Localize(ILocalizationManager manager)
        {
            _clearUserTextBox = true;
            _clearCompanyAliasTextBox = true;
            Text = manager.GetString("ChangePasswordForm_Title");
            _passwordWarningMessage = manager.GetString("ChangePasswordForm_NewAndConfirmPasswordsAreDifferentWarning");
            llCancel.Text = manager.GetString("Cancel");
            SetControlWaterMarkText(tbUser, manager.GetString("LoginForm_User"));
            SetControlWaterMarkText(tbOldPassword, manager.GetString("ChangePasswordForm_OldPassword"));
            SetControlWaterMarkText(tbNewPassword, manager.GetString("ChangePasswordForm_NewPassword"));
            SetControlWaterMarkText(tbConfirmPassword, manager.GetString("ChangePasswordForm_ConfirmPassword"));
            SetControlWaterMarkText(tbCompany, manager.GetString("LoginForm_Company"));
        }

        private void SetControlWaterMarkText(Control textBox, string waterMark)
        {
            SendMessage(textBox.Handle, 0x1501, 1, waterMark);
        }

        public event EventHandler<EventArgs> ChangeClick;

        public string LoginUser
        {
            get
            {
                return tbUser.Text;
            }
            set
            {
                tbUser.Text = value;
            }
        }

        public string OldPassword
        {
            get
            {
                return tbOldPassword.Text;
            }

            set
            {
                tbOldPassword.Text = value;
            }
        }

        public string NewPassword
        {
            get
            {
                return tbNewPassword.Text;
            }

            set
            {
                tbNewPassword.Text = value;
            }
        }

        public string ConfirmPassword
        {
            get
            {
                return tbConfirmPassword.Text;
            }

            set
            {
                tbConfirmPassword.Text = value;
            }
        }

        public string LoginCompanyAlias
        {
            get
            {
                return tbCompany.Text;
            }

            set
            {
                tbCompany.Text = value;
            }
        }

        public void CloseForm()
        {
            Visible = false;
            //Process all accumulated events 
            //For example if user presses enter while form is going to be closed this events will go to MainForm.
            Application.DoEvents();
            Close();
        }

        public void SetUserName(string userName)
        {
            tbUser.Text = userName;
            _clearUserTextBox = false;
        }

        public void SetCompanyAlias(string companyAlias)
        {
            tbCompany.Text = companyAlias;
            _clearCompanyAliasTextBox = false;
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            OnChangeClick(EventArgs.Empty);
        }

        /// <summary>
        /// Fires ChangeClick event.
        /// <param name="e">Event arguments.</param>
        /// </summary>
        protected virtual void OnChangeClick(EventArgs e)
        {
            if (ChangeClick != null)
            {
                ChangeClick(this, e);
            }
        }

        private void llCancel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Overrides ProcessDialogKey for key down interception
        /// </summary>
        protected override bool ProcessDialogKey(Keys keyData)
        {
            if (keyData == Keys.Enter)
            {
                btnChange_Click(null, EventArgs.Empty);
                return true;
            }

            if (keyData == Keys.Escape)
            {
                Close();
            }

            return base.ProcessDialogKey(keyData);
        }

        private void ChangePasswordForm_Shown(object sender, EventArgs e)
        {
            tbOldPassword.Text = tbNewPassword.Text = tbConfirmPassword.Text = null;

            if (_clearCompanyAliasTextBox)
            {
                tbCompany.Text = null;
            }

            if (_clearUserTextBox)
            {
                tbUser.Text = null;
                tbUser.Focus();
            }
            else
            {
                tbOldPassword.Focus();
            }
        }

        /// <summary>
        /// Show warning icon, if new and confirm passwordsa re different
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbPassword_TextChanged(object sender, EventArgs e)
        {
            panelWrongPasswordConfirmation.Visible = false;
            // Start waiting timerCheckPassword.Interval milliseconds after the latest change
            timerCheckPassword.Stop();
            timerCheckPassword.Start();
        }

        /// <summary>
        /// Validation, that new and confirm passwords are different, calls in timerCheckPassword.Interval after last change in text boxed
        /// Change text box
        /// Wait timerCheckPassword.Interval milliseconds
        /// Check passwords
        /// Show warning panel, if needed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timerCheckPassword_Tick(object sender, EventArgs e)
        {
            timerCheckPassword.Stop();
            if (!string.IsNullOrEmpty(tbNewPassword.Text) &&
               !string.IsNullOrEmpty(tbConfirmPassword.Text) &&
               tbNewPassword.Text != tbConfirmPassword.Text)
            {
                panelWrongPasswordConfirmation.Visible = true;
            }
        }

        private void panelWrongPasswordConfirmation_MouseEnter(object sender, EventArgs e)
        {
            toolTip.Show(_passwordWarningMessage, panelWrongPasswordConfirmation, 15, -20);
        }

        private void panelWrongPasswordConfirmation_MouseLeave(object sender, EventArgs e)
        {
            toolTip.Hide(panelWrongPasswordConfirmation);
        }
    }
}
