﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Console.Views.Classes.SpellChecking;
using Confirmit.CATI.Console.Views.Classes.Localization;

namespace Confirmit.CATI.Console.Views.Forms
{
    /// <summary>
    /// Represents Spell checker form.
    /// </summary>
    public partial class SpellCheckerForm : Form, ISpellCheckerView
    {
        #region Members

        private const char CarrigeReturnSymbol = '\n';
        private readonly Color SelectionRedColor = Color.Red;
        private ILocalizationManager localizationManager;        

        #endregion

        #region Constructors

        public SpellCheckerForm()
        {
            InitializeComponent();
            Icon = Properties.Resources.AppIcon;
        }

        #endregion

        #region Properties

        private List<String> Suggestions
        {
            get;
            set;
        }

        #endregion
       
        #region Event Handlers

        private void SpellCheckerForm_Load(object sender, EventArgs e)
        {
            OnFormLoad(EventArgs.Empty);            
        }

        private void SpellCheckerForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            OnFormClose(EventArgs.Empty);
        }        

        private void btnIgnore_Click(object sender, EventArgs e)
        {
            OnIgnore(EventArgs.Empty);
        }

        private void btnIgnoreAll_Click(object sender, EventArgs e)
        {
            OnIgnoreAll(EventArgs.Empty);
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            HandleChangeWord();
        }        

        private void btnChangeAll_Click(object sender, EventArgs e)
        {
            var args = new ChangeEventArgs { SuggestedWord = tbChangeTo.Text };
            OnChangeAll(args);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            OnDelete(EventArgs.Empty);
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            FormResult = FormCloseReasons.Ok;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            FormResult = FormCloseReasons.Cancel;
            Close();
        }                

        private void lbSuggestionList_SelectedIndexChanged(object sender, EventArgs e)
        {
            HandleSelectedIndexChanged();
        }      

        private void lbSuggestionList_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            HandleSelectedIndexChanged();
            HandleChangeWord();           
        }

        /// <summary>
        /// Focus enter hadler for RichTextBox control
        /// </summary>        
        /// <remarks>
        /// It's needed to prevent user input because this control is used only for display question text.
        /// </remarks>
        private void rtbText_Enter(object sender, EventArgs e)
        {
            if(btnIgnore.Enabled)
            {
                btnIgnore.Focus();
            }
            else
            {
                btnCancel.Focus();    
            }            
        }

        #endregion

        #region ILocalizableView Members

        /// <summary>
        /// Localizes view according given localization information.
        /// </summary>
        /// <param name="manager">Localization manager which contains localization info.</param>
        public void Localize(ILocalizationManager manager)
        {
            Text = manager.GetString("SpellCheckerForm_Caption");
            btnIgnore.Text = manager.GetString("SpellCheckerForm_ButtonIgnore_Text");
            btnIgnoreAll.Text = manager.GetString("SpellCheckerForm_ButtonIgnoreAll_Text");
            btnChange.Text = manager.GetString("SpellCheckerForm_ButtonChange_Text");
            btnChangeAll.Text = manager.GetString("SpellCheckerForm_ButtonChangeAll_Text");
            btnDelete.Text = manager.GetString("SpellCheckerForm_ButtonDelete_Text");
            btnOK.Text = manager.GetString("SpellCheckerForm_ButtonOK_Text");
            btnCancel.Text = manager.GetString("SpellCheckerForm_ButtonCancel_Text");
            lblChangeTo.Text = manager.GetString("SpellCheckerForm_ChangeTo_Text") + ":";
            lblSuggestions.Text = manager.GetString("SpellCheckerForm_Suggestions_Text") + ":";

            localizationManager = manager;
        }

        #endregion

        #region ISpellCheckerView Members

        public event EventHandler IgnoreWord;

        public event EventHandler IgnoreAllWords;

        public event EventHandler<ChangeEventArgs> ChangeWord;

        public event EventHandler<ChangeEventArgs> ChangeAllWords;

        public event EventHandler DeleteWord;

        public event EventHandler FormLoaded;

        public event EventHandler<EventArgs> FormClose;

        /// <summary>
        /// Gets/sets form close reason describing why user close form.
        /// </summary>
        public FormCloseReasons FormResult
        {
            get;
            set;
        }
        
        public void ShowLoadingScreen()
        {
            lblStatus.Text = localizationManager.GetString("SpellCheckerForm_QuestionLoading");

            EmptyInputFields();
            EnableUserInputControls(false);
        }

        public void ShowCompletionScreen()
        {
            lblStatus.ForeColor = Color.Green;            
            lblStatus.Font = new Font(lblStatus.Font, FontStyle.Bold);            
            lblStatus.Text = localizationManager.GetString("SpellCheckerForm_SpellCheckCompleted");

            EmptyInputFields();
            EnableUserInputControls(false, true);            
        }

        public void ShowErrorScreen(string  errorMessage)
        {            
            lblStatus.Text = errorMessage;
            lblStatus.ForeColor = SelectionRedColor;

            EmptyInputFields();                       
            EnableUserInputControls(false, false);            
        }

        public void InitTextBlock(string questionText, int misspelledWordIndex, string misspelledWord, IEnumerable<string> suggestions, bool isRepeatedWord)
        {
            if (String.IsNullOrEmpty(questionText))
            {
                throw new ArgumentNullException("questionText");
            }

            if (String.IsNullOrEmpty(misspelledWord))
            {
                throw new ArgumentNullException("misspelledWord");
            }

            if (misspelledWordIndex < 0 || misspelledWordIndex > questionText.Length - 1)
            {
                throw new ArgumentOutOfRangeException("misspelledWordIndex");
            }

            EmptyInputFields();
            EnableUserInputControls(true, false);

            InitRichTextBox(questionText, misspelledWordIndex, misspelledWord);

            Suggestions = suggestions.ToList();

            if (Suggestions.Count > 0)
            {
                lbSuggestionList.DataSource = Suggestions;
                lbSuggestionList.SelectionMode = SelectionMode.One;

                tbChangeTo.Text = Suggestions.First();
            }
            else
            {
                lbSuggestionList.Items.Add(localizationManager.GetString("SpellCheckerForm_NoSpellingSuggestions"));
                lbSuggestionList.SelectionMode = SelectionMode.None;
                tbChangeTo.Text = misspelledWord;
            }

            if (isRepeatedWord)
            {
                tbChangeTo.Enabled = false;

                pnlDeleteButtons.Visible = true;
                pnlChangeButtons.Visible = false;

                lblStatus.Text = localizationManager.GetString("SpellCheckerForm_RepeatedWord");
            }
            else
            {
                tbChangeTo.Enabled = true;

                pnlDeleteButtons.Visible = false;
                pnlChangeButtons.Visible = true;
                lblStatus.Text = localizationManager.GetString("SpellCheckerForm_NotInDictionary");
            }
        }

        /// <summary>
        /// Returns count of carrigage return symbols in the specified text.
        /// </summary>
        /// <param name="textBlock">Text block.</param>
        private int GetCarriageReturnsCount(string textBlock)
        {
            return textBlock.ToCharArray().Count(x => x == CarrigeReturnSymbol);
        }

        /// <summary>
        /// Shows modal appointment form.
        /// </summary>
        /// <param name="parent">Parent window handle.</param>
        void ISpellCheckerView.Show(IWin32Window parent)
        {
            if (!this.Visible)
            {
                ShowDialog(parent);
            }
        }

        #endregion

        #region Methods

        private void OnFormLoad(EventArgs args)
        {
            if (FormLoaded != null)
            {
                FormLoaded(this, args);
            }
        }

        private void OnFormClose(EventArgs args)
        {
            if (FormClose != null)
            {
               FormClose(this, args);
            }
        }  

        private void OnIgnore(EventArgs arg)
        {
            if (IgnoreWord != null)
            {
                IgnoreWord(this, arg);
            }
        }

        private void OnIgnoreAll(EventArgs arg)
        {
            if (IgnoreAllWords != null)
            {
                IgnoreAllWords(this, arg);
            }
        }

        private void OnDelete(EventArgs args)
        {
            if (DeleteWord != null)
            {
                DeleteWord(this, args);
            }
        }

        private void OnChange(ChangeEventArgs args)
        {
            if (ChangeWord != null)
            {
                ChangeWord(this, args);
            }
        }

        private void OnChangeAll(ChangeEventArgs args)
        {
            if (ChangeAllWords != null)
            {
                ChangeAllWords(this, args);
            }
        }

        private void InitRichTextBox(string text, int misspelledWordIndex, string misspelledWord)
        {            
            rtbText.Text = text;

            int carriageReturnsCount = GetCarriageReturnsCount(text.Remove(misspelledWordIndex));

            HighlightWord(misspelledWordIndex - carriageReturnsCount, misspelledWord.Length);
        }

        private void HighlightWord(int startIndex, int length)
        {
            rtbText.SelectAll();
            rtbText.SelectionColor = SystemColors.WindowText;
            rtbText.Select(startIndex, length);
            rtbText.SelectionColor = SelectionRedColor;
            rtbText.ScrollToCaret();
        }

        private void EmptyInputFields()
        {
            rtbText.Text = string.Empty;
            tbChangeTo.Text = string.Empty;

            lbSuggestionList.DataSource = null;
            lbSuggestionList.Items.Clear();
        }

        private void EnableUserInputControls(bool enabled)
        {
            EnableUserInputControls(enabled, enabled);
        }

        private void EnableUserInputControls(bool enabled, bool okButtonEnabled)
        {
            tbChangeTo.Enabled = enabled;
            btnIgnore.Enabled = enabled;
            btnIgnoreAll.Enabled = enabled;
            btnChange.Enabled = enabled;
            btnChangeAll.Enabled = enabled;
            btnDelete.Enabled = enabled;
            btnOK.Enabled = okButtonEnabled;

            if (btnIgnore.Enabled)
            {
                btnIgnore.Focus();
            }
        }

        private void HandleSelectedIndexChanged()
        {
            if (Suggestions.Count > 0 &&
                lbSuggestionList.SelectedIndex >= 0)
            {
                tbChangeTo.Text = Suggestions[lbSuggestionList.SelectedIndex];
            }
        }

        private void HandleChangeWord()
        {
            var args = new ChangeEventArgs { SuggestedWord = tbChangeTo.Text };
            OnChange(args);
        }

        #endregion                     
        
    }
}
