﻿using System;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    /// <summary>
    /// Class is used in communication between certain question and InterviewPageBrowser
    /// </summary>
    public class AnswerElementValueChangedEventArgs : EventArgs
    {
        /// <summary>
        /// Answer html element id
        /// </summary>
        public string ElementId
        {
            get;
            set;
        }
        
        /// <summary>
        /// Get or set new element value
        /// </summary>
        public string ElementValue
        {
            get;
            set;
        }
    }
}
