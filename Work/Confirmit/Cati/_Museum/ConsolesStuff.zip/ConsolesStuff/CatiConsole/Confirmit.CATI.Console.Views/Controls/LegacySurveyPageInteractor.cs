﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.SpellChecking;
using Confirmit.CATI.Console.Views.Classes.Utilities;
using Confirmit.CATI.Console.Views.Resources;
using mshtml;

namespace Confirmit.CATI.Console.Views.Controls
{
    public class LegacySurveyPageInteractor : BaseSurveyPageInteractor, ISurveyPageInteractor, ILegacySurveyPageInteractor
    {
        private const string ExitItem = "__btnExit";
        private const string OkButtonItem = "okbutton";
        private const string NextButtonItem = "__fwd";
        private const string FastForwardItem = "__fafwd";
        private const string ItsItem = "__its";
        private const string ServiceDivId = "Internal_In_service_text";
        private const string InternalErrorId = "Internal_Internal_error_text";
        private const string SurveyClosedId = "Internal_Survey_closed_text";
 
        private readonly QuestionCollection _questionCollection = new QuestionCollection();
        private EventHandler<PagePartiallyChangedEventArgs> _pagePartiallyChangedHandler;
        private readonly EventHandler<QuestionSelectedEventArgs> _questionSelectedHandler;
        private readonly EventHandler<AnswerElementValueChangedEventArgs> _answerValueChangedHandler;
        private readonly EventHandler<EventArgs> _dynamicQuestionAnswerValueChangedHandler;
        private readonly EventHandler<EventArgs> _ajaxQuestionLoadedHandler;
        private readonly EventHandler<QuestionSelectedEventArgs> _subQuestionSelectedHandler;

        private bool _isAssigned;
        private string _documentText;

                
        public bool IsConfirmitServicePage
        {
            get
            {
                bool result = false;

                IHTMLDocument3 doc;
                if (WebBrowser.Document != null &&
                    (doc = (IHTMLDocument3)WebBrowser.Document.DomDocument) != null &&
                    doc.getElementById(ServiceDivId) != null)
                {
                    result = true;
                }

                return result;
            }
        }

        /// <summary>
        /// Fires AnswerValueChnaged event for simple questions
        /// </summary>  
        private void OnAnswerChanged(AnswerElementValueChangedEventArgs e)
        {
            _answerValueChangedHandler?.Invoke(this, e);
        }

        /// <summary>
        /// Fires DynamicQuestionAnswerValueChanged event for dynamic questions
        /// </summary>  
        private void OnDynamicQuestionAnswerChanged()
        {
            _dynamicQuestionAnswerValueChangedHandler?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Fires SubQuestionSelected event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnSubQuestionSelected(QuestionSelectedEventArgs e)
        {
            _subQuestionSelectedHandler?.Invoke(this, e);
        }

        public LegacySurveyPageInteractor(ExtendedWebBrowser webBrowser,
            EventHandler<PagePartiallyChangedEventArgs> onPagePartiallyChanged,
            EventHandler<QuestionSelectedEventArgs> onQuestionSelected,
            EventHandler<AnswerElementValueChangedEventArgs> answerValueChanged,
            EventHandler<EventArgs> dynamicQuestionAnswerValueChanged, EventHandler<EventArgs> onAjaxQuestionLoaded,
            EventHandler<QuestionSelectedEventArgs> onSubQuestionSelected, bool readOnly)
        {
            _pagePartiallyChangedHandler = onPagePartiallyChanged;
            _questionSelectedHandler = onQuestionSelected;
            _answerValueChangedHandler = answerValueChanged;
            _dynamicQuestionAnswerValueChangedHandler = dynamicQuestionAnswerValueChanged;
            _ajaxQuestionLoadedHandler = onAjaxQuestionLoaded;
            _subQuestionSelectedHandler = onSubQuestionSelected;
            ReadOnly = readOnly;
            this.WebBrowser = webBrowser;

            CurrentQuestionIndex = -1;
            DialStatus = null;
            _currentQuestion = null;
        }

        private bool InCaseOfCarouselGrid(string elementId)
        {
            if (string.IsNullOrEmpty(elementId) && _currentQuestion != null && _currentQuestion.Type == QuestionType.CarouselGrid)
            {
                var fieldsetId = string.Format("fieldset_{0}", _currentQuestion.QuestionId);
                ExecuteJavaScript(HtmlMonitoringAdapter.GetUpdateHtmlScript(fieldsetId));
                new DelayWorkManager(() => MonitorChangesFor(fieldsetId, elementId), PageUpdateMonitoringDelay + 100).Run();

                return true;
            }

            return false;
        }

        private void OnPagePartiallyChanged(PagePartiallyChangedEventArgs args)
        {
            _pagePartiallyChangedHandler?.Invoke(this, args);
        }

        /// <summary>
        /// Allows to display changes of some element in monitoring
        /// </summary>
        /// <param name="elementId">Id of the element that we want to update to monitoring</param>
        /// <param name="activeElementId">Id of the element we want to focus on (usually inside container with id="elementId")</param>
        public void MonitorChangesFor(string elementId, string activeElementId = "")
        {
            if (WebBrowser.Document == null)
            {
                return;
            }

            var doc = (HTMLDocument)WebBrowser.Document.DomDocument;

            ExecuteJavaScript(HtmlMonitoringAdapter.GetUpdateHtmlScript(elementId));

            if (doc != null)
            {
                var elementOuterHtml = LinkRepairer.Repair(doc.getElementById(elementId).outerHTML, WebBrowser.Document.Url.Host, WebBrowser.Document.Url.Scheme);

                OnPagePartiallyChanged(new PagePartiallyChangedEventArgs
                {
                    ElementId = elementId,
                    NewOuterHtml = elementOuterHtml,
                    ActiveElementId = activeElementId
                });
            }
        }

        /// <summary>
        /// Method will be executed from JavaScript 
        /// when user changes answer for dynamic questions
        /// </summary>
        public void DynamicQuestionAnswerChangedHandler(string elementId = "")
        {
            if (WebBrowser.Document == null)
            {
                return;
            }

            if (InCaseOfCarouselGrid(elementId)) return;

            if (string.IsNullOrEmpty(elementId))
            {
                return;
            }

            var doc = (HTMLDocument)WebBrowser.Document.DomDocument;
            var question = _questionCollection.FindQuestion(doc.getElementById(elementId));

            if (question != null && _currentQuestion != null && _currentQuestion.QuestionId != question.QuestionId)
            {
                int questionIndex = _questionCollection.IndexOf(question);
                DoQuestion(questionIndex);
            }

            var fieldsetId = string.Format("fieldset_{0}", question.QuestionId);
            var fieldset = doc.getElementById(fieldsetId);

            if (fieldset == null)
            {
                ExecuteJavaScript(HtmlMonitoringAdapter.GetUpdateHtmlScript(string.Empty));
                new DelayWorkManager(OnDynamicQuestionAnswerChanged, PageUpdateMonitoringDelay).Run();
            }
            else
            {
                ExecuteJavaScript(HtmlMonitoringAdapter.GetUpdateHtmlScript(fieldsetId));
                new DelayWorkManager(() => MonitorChangesFor(fieldsetId, elementId), PageUpdateMonitoringDelay).Run();
            }
        }


        /// <summary>
        /// Method will be executed from JavaScript 
        /// when user question is loaded via Ajax
        /// </summary>
        public void AjaxQuestionLoadedHandler()
        {
            string questionId = _currentQuestion.QuestionId;

            ParseDocument();

            Question question = _questionCollection.GetByQuestionId(questionId);

            if (question != null)
            {
                DoQuestion(_questionCollection.GetQuestionIndex(question));
            }
            else
            {
                SetDefaultActiveQuestion();
            }

            OnAjaxQuestionLoaded();
        }

        public void OnResponsiveSubQuestionSelected(int questionIndex, int subQuestionIndex)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Fires AjaxQuestionLoaded event for ajax questions
        /// </summary>  
        private void OnAjaxQuestionLoaded()
        {
            _ajaxQuestionLoadedHandler?.Invoke(this, EventArgs.Empty);
        }

        private void RefreshQuestionsAfterPagePartialUpdate(Question question)
        {
            if (question != null)
            {
                question.ResetAnswers();
                if (_currentQuestion.QuestionId == question.QuestionId)
                {
                    _currentQuestion = question;
                }
            }
        }

        /// <summary>
        /// Get or set current active question on page
        /// </summary>
        private Question _currentQuestion;

        public Question CurrentQuestion => _currentQuestion;

        public bool CurrentQuestionHasDefaultAnswer
        {
            get { return _currentQuestion != null && _currentQuestion.HasDefaultAnswer; }
        }

        public bool CurrentQuestionHasRefusedAnswer
        {
            get { return _currentQuestion != null && _currentQuestion.HasRefusedAnswer; }
        }

        public bool NavigationCanBeIgnored
        {
            get
            {
                if (CurrentQuestionType == QuestionType.Open ||
                    CurrentQuestionType == QuestionType.DatePicker ||
                    CurrentQuestionType == QuestionType.MultiOpen ||
                    CurrentQuestionType == QuestionType.SearchableMulti)
                {
                    return true;
                }

                return false;
            }
        }

        public bool ReadOnly { get; set; }

        /// <summary>
        /// Gets question collection 
        /// </summary>
        public QuestionCollection Questions => _questionCollection;

        public bool IsConfirmitInternalErrorPage
        {
            get
            {
                bool result = false;

                IHTMLDocument3 doc;
                if (WebBrowser.Document != null &&
                    (doc = (IHTMLDocument3)WebBrowser.Document.DomDocument) != null &&
                    doc.getElementById(InternalErrorId) != null)
                {
                    result = true;
                }

                return result;
            }
        }

        public void FinishInterview()
        {
            if (WebBrowser.Document != null && WebBrowser.IsBusy == false)
            {
                if (IsEndInterviewPageLoaded)
                {
                    IHTMLDocument3 doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;
                    IHTMLElement okButtonElement = doc.getElementById("okbutton");
                    okButtonElement.click();
                }
            }
        }

        public void TerminateInterview(int status)
        {
            if (IsConfirmitInternalErrorPage)
            {
                DoNextPage();
                return;
            }

            if (WebBrowser.Document != null && WebBrowser.IsBusy == false)
            {
                HTMLDocument doc = WebBrowser.Document.DomDocument as HTMLDocument;
                if (doc == null)
                {
                    return;
                }

                IHTMLInputElement itsField = doc.getElementById(ItsItem) as IHTMLInputElement;
                if (itsField != null)
                {
                    itsField.value = status.ToString(CultureInfo.InvariantCulture);
                }

                var isClosedSurvey = doc.getElementById(SurveyClosedId) != null;
                if (isClosedSurvey)
                {
                    var el = doc.getElementById("ctlform");
                    el.insertAdjacentHTML("afterbegin", "<input type=\"hidden\" name=\"__btnExit\" value='' />");

                    var nextButton = doc.getElementById(NextButtonItem);
                    nextButton?.click();
                }
                else
                {
                    IHTMLElement exit = doc.getElementById(ExitItem);
                    exit?.click();
                }

                
            }
        }

        public void UpdatePagePartially(string elementId, string elementOuterHtml, string activeElementId)
        {
            if (WebBrowser.Document == null)
            {
                return;
            }

            var doc = (HTMLDocument)WebBrowser.Document.DomDocument;

            if (doc == null)
            {
                return;
            }

            var element = doc.getElementById(elementId);

            var question = _questionCollection.FindQuestionByElementId(elementId);
            if (question == null && string.IsNullOrEmpty(activeElementId) == false)
            {
                question = _questionCollection.FindQuestionByElementId(elementId);
            }

            element.outerHTML = elementOuterHtml;

            RefreshQuestionsAfterPagePartialUpdate(question);

            ScrollToActiveElementAfterPagePartialUpdate(activeElementId);
        }

        void CurrentQuestion_InputChangedFromKeyboard(object sender, InputChangedFromKeyboardEventArgs e)
        {
            ScrollToHtmlElement(e.ElementId);
        }
        private void ScrollToHtmlElement(string elementId)
        {
            if (WebBrowser.Document != null)
            {
                ScrollToHtmlElement(WebBrowser.Document.GetElementById(elementId));
            }
        }

        private void ScrollToHtmlElement(HtmlElement element)
        {
            if (WebBrowser.Document == null || element == null)
            {
                return;
            }

            var htmlMeasuringAssistant = new HtmlElementPositionProvider();
            var elementX = htmlMeasuringAssistant.GetOffsetFromLeft(element);
            var elementY = htmlMeasuringAssistant.GetOffsetFromTop(element);

            if (elementX == 0 && elementY == 0)
            {
                ScrollToHtmlElement(element.Parent);
                return;
            }

            var htmlElement = WebBrowser.Document.GetElementsByTagName("HTML")[0];
            var scrollTop = htmlElement.ScrollTop;
            var scrollLeft = htmlElement.ScrollLeft;
            var visibleWidth = htmlElement.ClientRectangle.Width;
            var visibleHeight = htmlElement.ClientRectangle.Height;

            if (elementY <= scrollTop || (elementY + element.ClientRectangle.Height) >= (scrollTop + visibleHeight))
                scrollTop = elementY;

            if (elementX <= scrollLeft || (elementX + element.ClientRectangle.Width) >= (scrollLeft + visibleWidth))
                scrollLeft = elementX;

            if (WebBrowser.Document.Window != null)
            {
                WebBrowser.Document.Window.ScrollTo(scrollLeft, scrollTop);
            }
        }
        private void ScrollToActiveElementAfterPagePartialUpdate(string activeElementId)
        {
            if (string.IsNullOrEmpty(activeElementId) || WebBrowser.Document == null)
            {
                return;
            }

            var doc = (HTMLDocument)WebBrowser.Document.DomDocument;
            var elementActive = doc.getElementById(activeElementId);

            if (elementActive.tagName.Equals("input", StringComparison.InvariantCultureIgnoreCase) == false) return;

            var elementType = Answer.GetTypeByElement(elementActive);

            if (elementType == ElementTypes.Radio || elementType == ElementTypes.Checkbox)
            {
                if (((IHTMLInputElement)(elementActive)).@checked == false)
                    return;
            }

            ScrollToHtmlElement(activeElementId);
        }


        private void OnQuestionSelected(bool isSubQuestion = false)
        {
            OnRedraw.Invoke(this, null);

            if (_currentQuestion == null) return;

            var arg = new QuestionSelectedEventArgs
            {
                QuestionIndex = CurrentQuestionIndex,
                SubQuestionIndex = _currentQuestion.GetActiveSubquestionIndex(),
                QuestionId = _currentQuestion.QuestionId,
                QuestionTitle = _currentQuestion.Title,
                QuestionText = _currentQuestion.Text,
                IsSubQuestion = isSubQuestion,
                QuestionType = _currentQuestion.Type
            };

            _questionSelectedHandler?.Invoke(this, arg);
        }

        public void FocusActiveElement()
        {
            throw new NotImplementedException();
        }


        private void Question_ActiveSubQuestionChanged(object sender, EventArgs e)
        {
            QuestionSelectedEventArgs args = new QuestionSelectedEventArgs
            {
                QuestionIndex = CurrentQuestionIndex,
                SubQuestionIndex = _currentQuestion.GetActiveSubquestionIndex()
            };

            OnSubQuestionSelected(args);
        }

        /// <summary>
        /// Returns false if we have only multiple info nodes on a page
        /// </summary>
        /// <returns></returns>
        private bool ShouldHighlightQuestion()
        {
            return (_questionCollection.Count == 1 && DoesPageContainMultipleInfoNodes()) == false;
        }

        private Question GetFirstQuestion()
        {
            return _questionCollection[0];
        }

        private Question GetFirstNonInfoQuestion()
        {
            return _questionCollection.Cast<Question>().FirstOrDefault(x => x.Type != QuestionType.Info);
        }


        private bool DoesPageContainMultipleInfoNodes()
        {
            var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;
            IHTMLElementCollection elements = doc.getElementsByName("__type");

            return
                elements.Cast<IHTMLInputElement>()
                    .Count(element => element.value.StartsWith("info", StringComparison.InvariantCultureIgnoreCase)) > 1;
        }

        private void ActivateQuestion(Question question, bool setActive = true)
        {
            if (question == null)
            {
                throw new ArgumentNullException("question");
            }

            _currentQuestion = question;
            if (setActive)
            {
                _currentQuestion.Active = true;
            }

            _currentQuestion.ScrollIntoView();
            OnQuestionSelected();
        }

        /// <summary>
        /// Returns array of DefaultAndRefusedInfo elements
        /// </summary>
        /// <remarks>
        /// Method search following format string 
        /// var DefaultAndRefused = [{"QuestionId":"q9","DefaultAnswerPrecode":"pre3","RefusedAnswerPrecode":"pre3"}, ...];
        /// </remarks>
        /// <returns></returns>
        private DefaultAndRefusedInfo[] GetDefaultAndRefusedInfo()
        {
            string documentText = DocumentText;

            if (String.IsNullOrEmpty(documentText))
                return new DefaultAndRefusedInfo[0];

            Match mch = Regex.Match(documentText, @"(?<=DefaultAndRefused[\s]*[=]).*?(?=[;]\s*[<][/]script[>])", RegexOptions.IgnoreCase);

            if (mch.Success)
            {
                string jsonFormatInfo = mch.Value;

                DataContractJsonSerializer ser
                    = new DataContractJsonSerializer(typeof(DefaultAndRefusedInfo[]));

                using (MemoryStream ms = new MemoryStream(Encoding.Unicode.GetBytes(jsonFormatInfo)))
                {
                    try
                    {
                        return (DefaultAndRefusedInfo[])ser.ReadObject(ms);
                    }
                    catch (Exception ex)
                    {
                        Logger.Write(ex);
                    }
                }
            }

            return new DefaultAndRefusedInfo[0];
        }



        /// <summary>
        /// Return error question that was met first
        /// </summary>
        ///Folloing format for error page: 
        ///  <input type="hidden" name="__type" id="1" value="grid"/>
        ///  <div class="question">
        ///  <div id="q46_error"  class="error">Please select answers for
        ///  </div>
        ///  </div>
        private Question GetFirstErrorQuestion()
        {
            if (WebBrowser.Document == null)
            {
                return null;
            }

            var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;
            if (doc.getElementById("errormsg") != null)
            {
                IHTMLElementCollection elements = doc.getElementsByTagName("SPAN");
                foreach (IHTMLElement element in elements)
                {
                    if (!string.IsNullOrEmpty(element.id) && element.id.EndsWith("error", StringComparison.OrdinalIgnoreCase))
                        return _questionCollection.GetQuestionByElement((IHTMLElement)((IHTMLDOMNode)element).nextSibling);
                }
            }
            else if (doc.getElementById("globalerror_error") != null)
            {
                IHTMLElementCollection elements = doc.getElementsByTagName("DIV");
                foreach (IHTMLElement element in elements)
                {
                    if (Answer.GetTagNameByElement(element) == TagNames.DIV)
                    {
                        if (!string.IsNullOrEmpty(element.id) &&
                            element.id.EndsWith("error", StringComparison.OrdinalIgnoreCase) &&
                            !element.id.Equals("globalerror_error", StringComparison.OrdinalIgnoreCase))
                        {
                            var parentSibling = (IHTMLElement)element.parentElement.GetPreviousSiblingSkipComments();
                            if (parentSibling != null && Answer.GetTagNameByElement(parentSibling) == TagNames.INPUT)
                            {
                                return _questionCollection.GetQuestionByElement(parentSibling);
                            }

                            var sibling = (IHTMLElement)element.GetPreviousSiblingSkipComments();
                            if (sibling != null && Answer.GetTagNameByElement(sibling) == TagNames.INPUT)
                            {
                                return _questionCollection.GetQuestionByElement(sibling);
                            }
                        }
                    }
                }
            }
            return null;
        }


        /// <summary>
        /// Activate first question in Pagem_PageQuestions collection
        /// </summary>
        public void SetDefaultActiveQuestion()
        {
            //to prevent active question's duplication in monitoring console
            if (_currentQuestion != null)
            {
                return;
            }

            if (_questionCollection.Count == 0)
            {
                return;
            }

            var question = GetFirstErrorQuestion();

            if (question == null)
            {
                question = GetFirstNonInfoQuestion();
            }

            if (question == null)
            {
                question = GetFirstQuestion();
            }

            var activate = ShouldHighlightQuestion();

            ActivateQuestion(question, activate);

            FocusFirstByClass("_catiConsoleFocus");
        }

        public bool IsFeatureRequired(BrowserFeature feature)
        {
            foreach (Question question in Questions)
            {
                if (question.Type == QuestionType.CarouselGrid)
                {
                    return true;
                }
                break;
            }

            return false;
        }

        /// <summary>
        /// Subscribes each dynamic question for value changed event handler
        /// Method uses the DOM's "window.external" mechanism of the webbrowser
        /// to call .NET 'AnswerForDynamicQuestionSelected' method from JavaScript code
        /// </summary>
        private void SubscribeForDynamicQuestionAnswers()
        {
            try
            {
                var script = new DynamicQuestionSubscription().GetScript();

                ExecuteJavaScript(script);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        public void DoRequiredSubscriptions()
        {
            if (ReadOnly)
            {
                ExecuteJavaScript(Scripts.Monitoring);
                return;
            }

            SubscribeForDynamicQuestionAnswers();
        }

        public string GetDatePickerDatePattern()
        {
            if (String.IsNullOrEmpty(DocumentText))
            {
                return null;
            }

            var regex = new Regex("Y[.]DatePicker[.]datePattern = \"(?<date>.+?)\";");
            var match = regex.Match(DocumentText);

            return match.Success ? match.Groups["date"].Value : null;
        }

        public void ExecuteJavaScript(string script)
        {
            if (WebBrowser.Document != null && WebBrowser.Document.Window != null)
            {
                ((IHTMLWindow2)WebBrowser.Document.Window.DomWindow).execScript(script, "javascript");
            }
        }

        public bool ExtendedLoggingEnabled { get; set; }

        public bool IsEndInterviewPageLoaded
        {
            get
            {
                if (WebBrowser.Document == null || _currentQuestion == null ||
                    _currentQuestion.Type != QuestionType.Info)
                {
                    return false;
                }

                var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;
                if (((IHTMLDocument2)doc).forms.item("ctlform", 0) != null)
                {
                    if (doc.getElementById("okbutton") != null)
                        return true;
                }

                return false;
            }
        }

        

        

        public string CurrentQuestionId
        {
            get
            {
                if (_currentQuestion != null)
                {
                    return _currentQuestion.QuestionId;
                }
                return String.Empty;
            }
        }

        public bool IsCurrentQuestionLast
        {
            get
            {
                var lastQuestionIndex = _questionCollection.Count - 1;
                if (CurrentQuestionIndex == lastQuestionIndex)
                {
                    return true;
                }

                if (CurrentQuestionIndex == _questionCollection.Count - 2 &&
                    _questionCollection[lastQuestionIndex].Type == QuestionType.Info)
                {
                    return true;
                }

                return false;
            }
        }

        public bool HasOpenEndQuestion => _questionCollection.HasOpenEndQuestion;

        public bool HasCurrentQuestionAnswersWithFocusedOtherField
        {
            get
            {
                if (WebBrowser.Document != null && WebBrowser.IsBusy == false)
                {
                    if (_currentQuestion != null && _currentQuestion.ActiveAnswers != null)
                    {
                        return _currentQuestion.ActiveAnswers.HasAnswersWithFocusedOtherField;
                    }
                }
                return false;
            }
        }

        public void FocusFirstByClass(string className)
        {
            var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;
            var items = doc.documentElement.all;
            foreach (IHTMLElement item in items)
            {
                if (string.IsNullOrWhiteSpace(item.className) == false && item.className.Split(' ').Contains(className))
                {
                    ((IHTMLElement2)item).focus();
                    return;
                }
            }
        }

        public void SetAnswer(string elementId, string elementValue)
        {
            try
            {
                if (WebBrowser.Document == null)
                {
                    return;
                }

                var activeElement = WebBrowser.Document.GetElementById(elementId);
                if (activeElement == null)
                {
                    return;
                }

                var domElement = (IHTMLElement)activeElement.DomElement;

                if (_currentQuestion != null)
                {
                    if (_currentQuestion.SetAnswer(domElement, elementValue))
                    {
                        return;
                    }
                }

                var elementType = Answer.GetTypeByElement(domElement);

                if (elementType == ElementTypes.TextArea)
                {
                    ((IHTMLTextAreaElement)(domElement)).value = elementValue;
                }
                else if (elementType == ElementTypes.Select)
                {
                    ((IHTMLSelectElement)(domElement)).value = elementValue;
                }
                else if (elementType == ElementTypes.Checkbox || elementType == ElementTypes.Radio)
                {
                    ((IHTMLInputElement)(domElement)).@checked = bool.Parse(elementValue);
                }
                else if (elementType == ElementTypes.TextInput)
                {
                    ((IHTMLInputElement)(domElement)).value = elementValue;
                }

                ScrollToHtmlElement(activeElement);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }

        public QuestionType CurrentQuestionType
        {
            get
            {
                if (_currentQuestion != null)
                    return _currentQuestion.Type;

                return QuestionType.Simple;
            }
        }

        public string CurrentQuestionTitle
        {
            get
            {
                if (_currentQuestion != null)
                {
                    return _currentQuestion.Title;
                }
                return String.Empty;
            }
        }

        public IList<IHTMLElement> CurrentQuestionInputs
        {
            get
            {
                if (_currentQuestion != null)
                    return _currentQuestion.InputElements;

                return new List<IHTMLElement>();
            }
        }

        public List<SubQuestion> CurrentQuestionSubQuestions
        {
            get
            {
                if (_currentQuestion != null)
                {
                    return _currentQuestion.SubQuestions;
                }

                return new List<SubQuestion>();
            }
        }

        public int CurrentQuestionIndex
        {
            get
            {
                int result = -1;
                if (_questionCollection != null)
                {
                    result = _questionCollection.IndexOf(_currentQuestion);
                }

                return result;
            }
            set
            {
                if (_questionCollection != null)
                {
                    if (value >= _questionCollection.Count)
                    {
                        throw new ArgumentOutOfRangeException("value");
                    }

                    if (_currentQuestion != null)
                    {
                        _currentQuestion.Active = false;
                    }

                    if (value >= 0)
                    {
                        ActivateQuestion(_questionCollection[value]);
                    }
                }
            }
        }

        public int PageUpdateMonitoringDelay { get; set; }

        /// <summary>
        /// Continues interview by pressing button. If this is final page with
        /// "Ok" button, we press it. Otherwise we press "Next" button.
        /// </summary>
        public void ContinueInterview()
        {
            if (WebBrowser.Document == null || WebBrowser.IsBusy)
            {
                return;
            }

            if (IsOkPage)
            {
                ((IHTMLDocument3)WebBrowser.Document.DomDocument).getElementById(OkButtonItem).click();
            }
            else
            {
                IHTMLDocument3 doc;
                IHTMLElement nextButton;
                if (WebBrowser.Document != null &&
                    (doc = (IHTMLDocument3)WebBrowser.Document.DomDocument) != null &&
                    (nextButton = doc.getElementById(NextButtonItem)) != null
                )
                {
                    nextButton.click();
                }
            }
        }

        /// <summary>
        /// Do fast forward action for current interview.
        /// </summary>
        public void FastForward()
        {
            if (WebBrowser.Document != null && WebBrowser.IsBusy == false)
            {
                var doc = WebBrowser.Document.DomDocument as IHTMLDocument3;

                if (doc != null)
                {
                    IHTMLElement fastForward = doc.getElementById(FastForwardItem);

                    if (fastForward != null)
                    {
                        if (fastForward is IHTMLInputElement || fastForward is IHTMLTextAreaElement)
                        {
                            ((IHTMLElement2)fastForward).focus();
                        }

                        fastForward.click();
                    }
                }
            }
        }

        /// <summary>
        /// Emulates page next button click
        /// </summary>
        /// <remarks>
        /// Checks flag WebBrowser.IsBusy to prevent multiple requests
        /// </remarks>
        public void DoNextPage()
        {
            if (WebBrowser.Document != null && WebBrowser.IsBusy == false)
            {
                var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;
                IHTMLElement nextButton = null;
                try
                {
                    nextButton = (IHTMLElement)doc.getElementsByName(NextButtonItem).item(null, 0) ??
                                 (IHTMLElement)doc.getElementsByName(FastForwardItem).item(null, 0);

                    if (nextButton != null)
                    {
                        if (nextButton is IHTMLInputElement)
                            ((IHTMLElement2)nextButton).focus();

                        nextButton.click();
                    }
                }
                finally
                {
                    if (nextButton != null)
                    {
                        Marshal.ReleaseComObject(nextButton);
                    }
                }
            }
        }

        public void DoPrevPage()
        {
            if (WebBrowser.Document != null && WebBrowser.IsBusy == false)
            {
                var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;
                IHTMLElement prevButton = null;
                try
                {
                    prevButton = (IHTMLElement)doc.getElementsByName("__bck").item(null, 0);
                    if (prevButton != null)
                    {
                        if (prevButton is IHTMLInputElement)
                            ((IHTMLElement2)prevButton).focus();

                        prevButton.click();
                    }
                }
                finally
                {
                    if (prevButton != null)
                    {
                        Marshal.ReleaseComObject(prevButton);
                    }
                }
            }
        }

        public void DoQuestion(int questionIndex)
        {
            if (WebBrowser.IsBusy) return;

            if (_questionCollection.Count == 0 || questionIndex < 0 || questionIndex >= _questionCollection.Count) return;

            if (_currentQuestion == null) return;

            //If current question has been selected we shoudn't do something
            if (questionIndex == _questionCollection.IndexOf(_currentQuestion))
                return;

            _currentQuestion.Active = false;

            string id = _currentQuestion.Id;

            _currentQuestion = _questionCollection[questionIndex];
            _currentQuestion.Active = true;
            _currentQuestion.ScrollIntoView();

            if (id != _currentQuestion.Id)
            {
                OnQuestionSelected();
            }
        }

        public void DoSubQuestion(int subQuestionIndex)
        {
            if (WebBrowser.IsBusy) return;
            if (_currentQuestion != null)
            {
                _currentQuestion.ActivateSubQuestion(subQuestionIndex);
                OnRedraw.Invoke(this, null);
            }
        }

        public void DoPreviousQuestion()
        {
            if (_currentQuestion == null) return;

            if (_currentQuestion.ActivatePrevSubQuestion())
            {
                OnQuestionSelected(true);
                return;
            }

            int currentQuestionIndex = _questionCollection.IndexOf(_currentQuestion);
            var prevQuestionIndex = currentQuestionIndex - 1;

            if (prevQuestionIndex >= 0 && _questionCollection[prevQuestionIndex].Type == QuestionType.Info)
            {
                prevQuestionIndex--;
            }

            if (currentQuestionIndex >= 0 && prevQuestionIndex >= 0)
            {
                DoQuestion(prevQuestionIndex);
                if (_currentQuestion.ActivateLastSubQuestion())
                {
                    OnQuestionSelected(true);
                }
            }
        }

        public void DoNextQuestion()
        {
            if (_currentQuestion == null) return;

            if (_currentQuestion.ActivateNextSubQuestion())
            {
                OnQuestionSelected(true);
                return;
            }

            int currentQuestionIndex = _questionCollection.IndexOf(_currentQuestion);
            var nextQuestionIndex = currentQuestionIndex + 1;

            if (nextQuestionIndex < _questionCollection.Count &&
                _questionCollection[nextQuestionIndex].Type == QuestionType.Info)
            {
                // We skip only once because there can be only one question with type=Info inside questionCollection
                // It happens because all info nodes have id="0" so we always keep only first one
                nextQuestionIndex++;
            }

            if (currentQuestionIndex >= 0 && nextQuestionIndex < _questionCollection.Count)
                DoQuestion(nextQuestionIndex);
        }

        public void DoFirstQuestion()
        {
            if (_currentQuestion == null) return;
            DoQuestion(0);
        }

        public void DoFirstQuestionFirstSubQuestion()
        {
            DoFirstQuestion();
            if (_currentQuestion != null)
            {
                _currentQuestion.ActivateFirstSubQuestion();
            }
        }

        public void DoLastQuestion()
        {
            if (_currentQuestion == null) return;
            DoQuestion(_questionCollection.Count - 1);
        }

        public void DoLastQuestionLastSubQuestion()
        {
            DoLastQuestion();
            if (_currentQuestion != null)
                _currentQuestion.ActivateLastSubQuestion();
        }

        public void DoFirstSubQuestion()
        {
            if (_currentQuestion == null) return;
            if (_currentQuestion.ActivateFirstSubQuestion())
            {
                OnQuestionSelected(true);
            }
        }

        public void DoLastSubQuestion()
        {
            if (_currentQuestion == null) return;
            if (_currentQuestion.ActivateLastSubQuestion())
            {
                OnQuestionSelected(true);
            }
        }

        public void DoEditQuestion()
        {
            _currentQuestion?.DoEdit();
        }

        public void SetDefaultAnswer(out bool navigate, out bool keepFocus)
        {
            _currentQuestion.SetDefaultAnswer(out navigate, out keepFocus);
        }

        public void SetRefusedAnswer(out bool navigate, out bool keepFocus)
        {
            _currentQuestion.SetRefusedAnswer(out navigate, out keepFocus);
        }

        public IEnumerable<QuestionTextBlock> GetPageTextBlocks()
        {
            return GetPageTextBlocks("ctlform");
        }

        public void InsertStyles()
        {
            ((IHTMLDocument2)WebBrowser.Document.DomDocument)
                .createStyleSheet("", 0)
                .cssText = StylesProvider.GetStylesForCurrentQuestion();
        }

        public void OnResponsiveQuestionSelected(string id, string type, string text, string title, int index, int subQuestionIndex)
        {
            throw new NotImplementedException();
        }

        public void ProcessEnterData(string inputValue)
        {
            if (WebBrowser.IsBusy) return;
            if (_currentQuestion == null) return;

            /* disable keyboard support for grid-bar and capture-order questions because 
               they are entirely built by javascript */

            if (_currentQuestion.Type == QuestionType.GridBars) return;

            try
            {
                if (WebBrowser.Document != null && _isAssigned)
                {
                    ((HTMLDocumentEvents2_Event)WebBrowser.Document.DomDocument).onclick -= WebBrowserExtendedEvents_onclick;
                    WebBrowser.Document.Click -= Document_Click;
                    _isAssigned = false;
                }

                if (ReadOnly)
                {
                    _currentQuestion.InputChangedFromKeyboard += CurrentQuestion_InputChangedFromKeyboard;
                }

                _currentQuestion.ProcessEnterData(inputValue);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
            finally
            {
                if (WebBrowser.Document != null && !_isAssigned)
                {
                    ((HTMLDocumentEvents2_Event)WebBrowser.Document.DomDocument).onclick += WebBrowserExtendedEvents_onclick;
                    WebBrowser.Document.Click += Document_Click;
                    _isAssigned = true;
                }

                if (ReadOnly)
                {
                    _currentQuestion.InputChangedFromKeyboard += CurrentQuestion_InputChangedFromKeyboard;
                }
            }
        }

        /// <summary>
        /// Gets value indicating that current page is final page with "Ok" button.
        /// </summary>
        public bool IsOkPage
        {
            get
            {
                var result = false;

                IHTMLDocument3 doc;
                if (WebBrowser.Document != null &&
                    (doc = (IHTMLDocument3)WebBrowser.Document.DomDocument) != null &&
                    doc.getElementById(OkButtonItem) != null && doc.getElementById(SurveyClosedId) == null
                )
                {
                    result = true;
                }

                return result;
            }
        }

        private IHTMLElement GetAlternativeRootElement(string questionId, string tagName)
        {
            var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;
            var rootElement = doc.getElementById("fieldset_" + questionId);

            var elements = ((IHTMLElement2)rootElement).getElementsByTagName(tagName);

            foreach (IHTMLElement htmlElement in elements)
            {
                return htmlElement;
            }

            return rootElement;
        }

        private bool IsGridBarQuestion(Question question)
        {
            return IsQuestionOfType(question, QuestionType.GridBars);
        }

        private bool IsGridSliderQuestion(Question question)
        {
            return IsQuestionOfType(question, QuestionType.GridSlider);
        }

        private bool IsGridSliderLegacyQuestion(Question question)
        {
            return IsQuestionOfType(question, QuestionType.GridSliderLegacy);
        }

        private bool IsCardSortQuestion(Question question)
        {
            return IsQuestionOfType(question, QuestionType.CardSort);
        }

        private bool IsCarouselGridQuestion(Question question)
        {
            return IsQuestionOfType(question, QuestionType.CarouselGrid);
        }

        private bool IsCaptureOrderQuestion(Question question)
        {
            return IsQuestionOfType(question, QuestionType.CaptureOrder);
        }

        private bool IsRankedOrderQuestion(Question question)
        {
            return IsQuestionOfType(question, QuestionType.RankedOrder) || IsQuestionOfType(question, QuestionType.RankedOrderClick);
        }

        private bool IsImageButtonsQuestion(Question question)
        {
            return IsQuestionOfType(question, QuestionType.ImageButtons);
        }

        private bool IsDateQuestion(Question question)
        {
            return IsQuestionOfType(question, QuestionType.DatePicker);
        }

        public string DocumentText
        {
            get
            {
                if (_documentText != null)
                {
                    return _documentText;
                }

                try
                {
                    //For unknown reason WebBrowser.DocumentText property can raise exception

                    if (WebBrowser.Document != null)
                    {
                        _documentText = ((IHTMLDocument3)WebBrowser.Document.DomDocument).documentElement.innerHTML;
                    }
                }
                catch (Exception ex)
                {
                    _documentText = string.Empty;
                    Logger.Write(ex);
                }

                return _documentText;
            }
        }

        public EventHandler<EventArgs> OnRedraw { get; set; }

        private bool CheckCellClickFeature(Question question)
        {
           return IsQuestionOfType(question, "CellClick");
        }

        private bool IsQuestionOfType(Question question, QuestionType questionType)
        {
            return IsQuestionOfType(question, questionType.ToString());
        }

        private bool IsQuestionOfType(Question question, string questionType)
        {
            if (String.IsNullOrEmpty(DocumentText) == false)
            {
                // we use following regex: Y[.]WixInstance[.]addComponent\(\{\"type\"\:\"question_type\"\,\"fieldsetId\"\:\"fieldset_question_id
                string jsLoadPattern =
                    string.Format(
                        "Y[.]WixInstance[.]addComponent\\(\\{{\\\"type\\\"\\:\\\"{0}\\\"\\,\\\"fieldsetId\\\"\\:\\\"fieldset_{1}",
                        questionType,
                        question.QuestionId);

                return Regex.IsMatch(DocumentText, jsLoadPattern);
            }
            return false;
        }

        public void ParseDocument()
        {
            if (WebBrowser.Document == null)
            {
                return;
            }

            _documentText = null;
            _questionCollection.Clear();

            var doc = (IHTMLDocument3)WebBrowser.Document.DomDocument;

            var hightlightQuestion = DisableCatiMarkupAndKeyboardSupport == false;

            try
            {
                if (((IHTMLDocument2)doc).forms.item("ctlform", 0) != null)
                {
                    IHTMLElementCollection elements = doc.getElementsByName("__type");

                    foreach (IHTMLElement element in elements)
                    {
                        IHTMLElement alternativeRootElement = null;
                        var question = new Question(element, hightlightQuestion);

                        //redefine question type
                        if (question.Type == QuestionType.Grid)
                        {
                            question.IsCellClick = CheckCellClickFeature(question);

                            if (IsGridBarQuestion(question))
                            {
                                question.Type = QuestionType.GridBars;
                            }
                            else if (IsGridSliderQuestion(question))
                            {
                                question.Type = QuestionType.GridSlider;
                            }
                            else if (IsGridSliderLegacyQuestion(question))
                            {
                                question.Type = QuestionType.GridSliderLegacy;
                            }
                            else if (IsCardSortQuestion(question))
                            {
                                question.Type = QuestionType.CardSort;
                            }
                            else if (IsCarouselGridQuestion(question))
                            {
                                question.Type = QuestionType.CarouselGrid;
                            }
                        }
                        else if (question.Type == QuestionType.Multi ||
                                 question.Type == QuestionType.MultiOpen)
                        {
                            if (IsCaptureOrderQuestion(question))
                            {
                                alternativeRootElement = GetAlternativeRootElement(question.QuestionId, "TBODY");

                                question.Type = QuestionType.CaptureOrder;
                            }
                            else if (IsRankedOrderQuestion(question))
                            {
                                question.Type = QuestionType.RankedOrder;
                            }
                        }
                        else if (question.Type == QuestionType.Open)
                        {
                            if (IsDateQuestion(question))
                            {
                                question.Type = QuestionType.DatePicker;
                            }
                        }

                        /* All questions since Filix (v 18) version can be rendered as ImageButtons questions. */
                        if (IsImageButtonsQuestion(question))
                        {
                            question.IsImageButtons = true;
                        }

                        if (_questionCollection.Contains(question) == false)
                        {
                            _questionCollection.Add(question, alternativeRootElement);
                            question.AnswerElementValueChanged += Question_AnswerElementValueChanged;
                            question.ActiveSubQuestionChanged += Question_ActiveSubQuestionChanged;
                        }
                    }

                    DefaultAndRefusedInfo[] infos = GetDefaultAndRefusedInfo();
                    _questionCollection.InitDefaultAndRefusedInfo(infos);
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
            finally
            {
                if (ExtendedLoggingEnabled)
                {
                    Logger.Write(Strings.Log_PageIsParsed, MessageTypes.Information);
                }
            }
        }

        bool WebBrowserExtendedEvents_onclick(IHTMLEventObj pEvtObj)
        {
            if (_currentQuestion == null)
                return true;

            IHTMLElement element = pEvtObj.srcElement;

            Question question = _questionCollection.FindQuestion(element);

            if (question != null)
            {
                int questionIndex = _questionCollection.IndexOf(question);
                DoQuestion(questionIndex);

                if (_currentQuestion.Type == QuestionType.Grid ||
                    _currentQuestion.Type == QuestionType.Grid3D ||
                    _currentQuestion.Type == QuestionType.MultiOpen)
                {
                    SubQuestion subQuestion = _currentQuestion.FindSubQuestion(element);
                    if (subQuestion != null)
                    {
                        int subQuestionIndex = _currentQuestion.GetSubQuestionIndex(subQuestion);
                        //if subquestion has selected already we shouldn't select it again 
                        if (subQuestionIndex != _currentQuestion.GetActiveSubquestionIndex())
                        {
                            if (_currentQuestion.ActivateSubQuestion(subQuestionIndex))
                            {
                                OnQuestionSelected();
                            }
                        }
                    }
                }

                OnElementMouseClick(element);
            }

            return true;
        }

        /// <summary>
        /// Raises AnswerElementMouseClick event in case user click on HTMLInputElement and this element is answer element(checkbox/radio button)
        /// </summary>
        /// <remarks>
        /// - Other solution is to subscribe for mouseClick event for specific HTMLInputElement in Question class, but problems with GUI reveal
        /// - If page is not completely loaded we should do nothing
        /// </remarks>
        private void OnElementMouseClick(object arg)
        {
            if (WebBrowser.IsBusy) return;

            try
            {
                IHTMLInputElement elmt = null;

                var element = (IHTMLElement)arg;
                var tag = Answer.GetTagNameByElement(element);

                if (tag == TagNames.INPUT)
                {
                    elmt = (IHTMLInputElement)element;
                }

                if (elmt != null)
                {
                    var args = new AnswerElementValueChangedEventArgs
                    {
                        ElementId = ((IHTMLElement)elmt).id,
                    };

                    var elementType = Answer.GetTypeByElement((IHTMLElement)(elmt));

                    if (elementType == ElementTypes.Radio ||
                        elementType == ElementTypes.Checkbox)
                    {
                        args.ElementValue = elmt.@checked.ToString();

                        OnAnswerElementMouseClick(args);
                    }
                    else if (elementType == ElementTypes.TextInput)
                    {
                        args.ElementValue = elmt.value;

                        OnAnswerElementMouseClick(args);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }
        event EventHandler<AnswerElementValueChangedEventArgs> AnswerElementMouseClick;
        private void OnAnswerElementMouseClick(AnswerElementValueChangedEventArgs e)
        {
            if (AnswerElementMouseClick != null)
            {
                AnswerElementMouseClick(this, e);
            }
        }


        private void WebBrowserExtendedEvents_onkeyup(IHTMLEventObj pEvtObj)
        {
            IHTMLElement elmt = pEvtObj.srcElement;

            var elementType = Answer.GetTypeByElement(elmt);

            if (elementType == ElementTypes.TextArea ||
                elementType == ElementTypes.TextInput)
            {
                string value = String.Empty;

                if (elmt is IHTMLInputElement)
                {
                    value = ((IHTMLInputElement)elmt).value;
                }
                else if (elmt is IHTMLTextAreaElement)
                {
                    value = ((IHTMLTextAreaElement)elmt).value;
                }

                var arg = new AnswerElementValueChangedEventArgs
                {
                    ElementId = elmt.id,
                    ElementValue = value
                };

                OnAnswerChanged(arg);

            }
        }

        /// <summary>
        /// Currently is used only beacause for some reason WebBrowserExtendedEvents_onclick works 
        /// only if subscription on WebBrowser.Document.Click exists.
        /// </summary>
        void Document_Click(object sender, HtmlElementEventArgs e)
        {
        }

        /// <summary>
        /// Clear control current state
        /// </summary>
        private void ClearState()
        {
            _currentQuestion = null;
            _questionCollection.Clear();
        }

        private void Question_AnswerElementValueChanged(object sender, AnswerElementValueChangedEventArgs e)
        {
            _answerValueChangedHandler?.Invoke(this, e);
        }

        public void Subscribe()
        {
            AnswerElementMouseClick += Question_AnswerElementValueChanged;
            if (WebBrowser.Document != null && !_isAssigned)
            {
                WebBrowser.Document.Click += Document_Click;
                ((HTMLDocumentEvents2_Event)WebBrowser.Document.DomDocument).onclick += WebBrowserExtendedEvents_onclick;
                ((HTMLDocumentEvents2_Event)WebBrowser.Document.DomDocument).onkeyup += WebBrowserExtendedEvents_onkeyup;

                _isAssigned = true;
            }

            if (String.IsNullOrEmpty(DocumentText) == false && ReadOnly == false)
            {
                ExecuteJavaScript(HtmlMonitoringAdapter.GetRegisterFunctionsScript());
            }

            ClearState();
        }

        public void Unsubscribe()
        {
            if (WebBrowser.Document != null)
            {
                ((HTMLDocumentEvents2_Event) WebBrowser.Document.DomDocument).onclick -=
                    WebBrowserExtendedEvents_onclick;
                ((HTMLDocumentEvents2_Event) WebBrowser.Document.DomDocument).onkeyup -=
                    WebBrowserExtendedEvents_onkeyup;
                WebBrowser.Document.Click -= Document_Click;
            }

            AnswerElementMouseClick -= Question_AnswerElementValueChanged;

            foreach (Question question in _questionCollection)
            {
                question.AnswerElementValueChanged -= Question_AnswerElementValueChanged;
                question.ActiveSubQuestionChanged -= Question_ActiveSubQuestionChanged;
                question.Unsubscribe();
            }
        }
    }
}