﻿namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    /// <summary>
    /// Represents available modes of interviewing process
    /// Interviewing is standart interview
    /// Reviewing is review of previously completed interview
    /// </summary>
    public enum InterviewModes
    {
        Selecting = 0,
        Interviewing = 1,
        Reviewing = 2
    }
}

