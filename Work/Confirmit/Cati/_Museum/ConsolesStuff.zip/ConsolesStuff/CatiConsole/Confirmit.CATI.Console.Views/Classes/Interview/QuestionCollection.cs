﻿using System;
using mshtml;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using Confirmit.CATI.Console.Views.Resources;

namespace Confirmit.CATI.Console.Views.Classes.Interview
{
    /// <summary>
    /// Represent class for page question collection
    /// </summary>
    public class QuestionCollection : IEnumerable
    {
        private List<Question> m_PageQuestions = new List<Question>();
        private Dictionary<IHTMLElement, Question> m_ElementQuestionDictionary = new Dictionary<IHTMLElement, Question>();

        /// <summary>
        /// Clear collection
        /// </summary>
        public void Clear()
        {
            m_PageQuestions.Clear();
            m_ElementQuestionDictionary.Clear();
        }

        /// <summary>
        /// Adds question to collection
        /// </summary>
        ///<remarks>
        ///For specified question method fills m_ElementQuestionDictionary and m_ElementSubQuestionDictionary dictionary.
        ///It will be used for detect question when user clicks some element on page
        /// </remarks>
        public void Add(Question question, IHTMLElement alternativeRootElement = null)
        {
            if (question.Type == QuestionType.CaptureOrder || question.Type == QuestionType.Grid)
            {
                AddQuestionsInputsToHtmlQuestionDictionary(question, alternativeRootElement ?? question.RootElement);
            }
            else
            {
                AddQuestionsToHtmlQuestionDictionary(question, alternativeRootElement ?? question.RootElement);
            }

            question.AddSubQuestionsToHtmlSubQuestionDictionary();

            m_PageQuestions.Add(question);
        }

        /// <summary>
        /// Returns index of CurrentQuestion in m_PageQuestions collection
        /// </summary>
        /// <param name="question"></param>
        /// <returns></returns>
        public int GetQuestionIndex(Question question)
        {
            /*TODO
             replace this method by method IndexOf
             aaz */
            for (int index = 0; index < m_PageQuestions.Count; index++)
            {
                Question que = m_PageQuestions[index];
                if (question.Equals(que))
                {
                    return index;
                }
            }
            return -1;
        }

        /// <summary>
        /// Returns index of specified question
        /// </summary>
        public int IndexOf(Question question)
        {
            return m_PageQuestions.IndexOf(question);
        }

        /// <summary>
        /// Returns question by element. It is used when user selects some element on page.
        /// We should detect for what question belongs selected element
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public Question FindQuestion(IHTMLElement element)
        {
            if (m_ElementQuestionDictionary.ContainsKey(element))
                return m_ElementQuestionDictionary[element];
            else
                return null;
        }

        public Question FindQuestionByElementId(string elementId)
        {
            foreach (var element in m_ElementQuestionDictionary)
            {
                if (string.IsNullOrEmpty(element.Key.id))
                {
                    continue;
                }

                if (element.Key.id.Equals(elementId, StringComparison.InvariantCultureIgnoreCase))
                {
                    return m_ElementQuestionDictionary[element.Key];
                }
            }

            return null;
        }

        /// <summary>
        /// Return question from question collection by IHTMLElement element
        /// where element represents as following: input type="hidden" name="__type" id="1" value="single"/>
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public Question GetQuestionByElement(IHTMLElement element)
        {
            string elementId = element.id;

            for (int index = 0; index < m_PageQuestions.Count; index++)
            {
                Question que = m_PageQuestions[index];
                if (que.Id == elementId)
                {
                    return que;
                }
            }
            return null;
        }

        /// <summary>
        /// Returns question by passed Question id.
        /// </summary>
        public Question GetByQuestionId(string questionId)
        {
            foreach (Question q in m_PageQuestions)
            {
                if (q.QuestionId == questionId)
                {
                    return q;
                }
            }
            return null;
        }

        /// <summary>
        /// Determines whether a question is in the collection.
        /// </summary>
        /// <returns>
        /// True if question is found in the collection otherwise, false.
        /// </returns>
        public bool Contains(Question question)
        {
            return m_PageQuestions.Contains(question);
        }

        /// <summary>
        /// Returns count of question on page
        /// </summary>
        public int Count
        {
            get
            {
                return m_PageQuestions.Count;
            }
        }

        /// <summary>
        /// Gets or sets the element at the specified index.
        /// </summary>
        public Question this[int index]
        {
            get
            {
                return m_PageQuestions[index];
            }
        }

        /// <summary>
        /// Returns true if current page has open end question or has question with "other"
        /// answer which value is not empty.
        /// </summary>
        /// <remarks>
        /// It is used in preview mode to do fast forwar if first page hasn't open end question.
        /// </remarks>
        public bool HasOpenEndQuestion
        {
            get
            {
                foreach (Question q in m_PageQuestions)
                {
                    if (q.Type == QuestionType.Grid3D)
                    {
                        foreach (var sub in q.SubQuestions)
                        {
                            // check if 3DGrid contains Open Text List question
                            // - otherwise it will be skipped during fast-forward (if 3Dgrid is at the beginning in openend review)
                            if (sub.InputElements.All(x => Answer.GetTagNameByElement(x) == TagNames.INPUT
                                         && ((IHTMLInputElement)x).type.Equals("text", StringComparison.InvariantCultureIgnoreCase)))
                            {
                                return true;
                            }
                        }
                    }

                    if (q.Type == QuestionType.Open ||
                        q.Type == QuestionType.DatePicker ||
                        q.Type == QuestionType.MultiOpen ||
                        q.HasFilledOtherAnswer)
                        return true;
                }
                return false;
            }
        }

        /// <summary>
        /// Method is responsible for set for each question default and refused precode
        /// </summary>
        /// <param name="infos"></param>
        public void InitDefaultAndRefusedInfo(DefaultAndRefusedInfo[] infos)
        {
            Question question = null;
            foreach (DefaultAndRefusedInfo info in infos)
            {
                question = GetByQuestionId(info.QuestionId);
                if (question != null)
                {
                    question.DefaultAnswerPrecode = info.DefaultAnswerPrecode;
                    question.RefusedAnswerPrecode = info.RefusedAnswerPrecode;
                }
            }
        }

        private void AddQuestionsToHtmlQuestionDictionary(Question question, IHTMLElement element)
        {
            var exitRecursion = false;
            AddQuestionsToHtmlQuestionDictionary(question, element, out exitRecursion);
        }

        private void AddQuestionsToHtmlQuestionDictionary(Question question, IHTMLElement element, out bool exitRecursion)
        {
            exitRecursion = false;

            try
            {
                /*There can be not closed elements in layout, for example missed closed </Font> tag, 
                  that leads that all following elements are consided to be children. */
                if ((element as IHTMLInputElement) != null &&
                    (element as IHTMLInputElement).name == "__type")
                {
                    exitRecursion = true;
                    return;
                }

                m_ElementQuestionDictionary.Add(element, question);

                if (element.children == null)
                    return;

                var childElements = element.children as IHTMLElementCollection;

                if (childElements != null)

                    foreach (IHTMLElement childElement in childElements)
                    {
                        AddQuestionsToHtmlQuestionDictionary(question, childElement, out exitRecursion);

                        if (exitRecursion)
                            return;

                    }
            }
            catch (Exception ex)
            {
                throw new Exception(String.Format(Strings.Exception_PageParsingError, question.QuestionId, element.outerHTML), ex);
            }
        }

        /// <summary>
        /// Simplified method without recursion
        /// </summary>
        /// <param name="question"></param>
        /// <param name="element"></param>
        private void AddQuestionsInputsToHtmlQuestionDictionary(Question question, IHTMLElement element)
        {
            try
            {
                /*There can be not closed elements in layout, for example missed closed </Font> tag, 
                  that leads that all following elements are consided to be children. */
                if ((element as IHTMLInputElement) != null &&
                    (element as IHTMLInputElement).name == "__type")
                {
                    return;
                }

                m_ElementQuestionDictionary.Add(element, question);

                if (element.children == null)
                    return;

                if (question.IsCellClick)
                {
                    PutChildElementsToDictionary(question, element, "TD");
                }

                PutChildElementsToDictionary(question, element, "INPUT");

                PutChildElementsToDictionary(question, element, "SELECT");

                PutChildElementsToDictionary(question, element, "TEXTAREA");
            }
            catch (Exception ex)
            {
                throw new Exception(String.Format(Strings.Exception_PageParsingError, question.QuestionId, element.outerHTML), ex);
            }
        }

        private void PutChildElementsToDictionary(Question question, IHTMLElement element, string tagName)
        {
            var childElements = ((IHTMLElement2) element).getElementsByTagName(tagName);

            if (childElements != null && childElements.length > 0)

                foreach (IHTMLElement childElement in childElements)
                {
                    m_ElementQuestionDictionary.Add(childElement, question);
                }
        }

        public IEnumerator GetEnumerator()
        {
            return m_PageQuestions.GetEnumerator();
        }
    }
}
