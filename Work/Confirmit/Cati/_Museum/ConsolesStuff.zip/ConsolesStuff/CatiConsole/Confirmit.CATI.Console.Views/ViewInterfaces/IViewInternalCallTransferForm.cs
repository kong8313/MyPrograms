﻿using System;
using System.Windows.Forms;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Views.Classes.Localization;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Represents view entity for CallTransferForm forms.
    /// </summary>
    public interface IViewCallTransferForm<T> : ILocalizableView, IDisposable
    {
        void UpdateFormData(T[] transferTargets);

        void SelectRow(string targetName);

        void Show(IWin32Window parent);

        void Hide();

        T Selected { get; }

        event EventHandler<EventArgs> CallTransferStart;

        void Localize(ILocalizationManager manager, ConsoleTransferType transferType);
    }

    public interface IViewInternalCallTransferForm : IViewCallTransferForm<InternalTransferTarget>
    {
        void EnableTransferButton(bool isTransferPossible);
    }

    public interface IViewExternalCallTransferForm : IViewCallTransferForm<ExternalTransferTarget> { }
}
