﻿namespace Confirmit.CATI.Console.Views.Classes.StatusBar
{
    /// <summary>
    /// Represents modes of status bar
    /// </summary>
    public enum StatusBarModes
    {
        LoginView = 0,
        MainView = 1,
        Interviewing = 2,
        Reviewing =3,
        MainViewPlayer = 4
    }
}
