﻿using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.Interfaces
{
    public interface IKeyboardSupport
    {
        event PreviewKeyDownEventHandler KeyButtonDown;
    }
}
