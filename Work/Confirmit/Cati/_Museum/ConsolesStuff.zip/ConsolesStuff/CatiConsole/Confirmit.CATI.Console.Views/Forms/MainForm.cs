﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.Classes.Login;
using Confirmit.CATI.Console.Views.Classes.StatusBar;
using Confirmit.CATI.Console.Views.Controls;
using Confirmit.CATI.Console.Views.Interfaces;
using Confirmit.CATI.Console.Views.Resources;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
	/// <summary>
	/// Represents application main form. Contains all application forms and controls.
	/// </summary>
    public partial class MainForm : Form, IViewMainForm, IKeyboardSupport, IButtonsStateProvider
	{
	    /// <summary>
        /// This object is used for locking threads.
        /// </summary>
        private readonly object _locker = new object();

	    private readonly SynchronizationContext _synchronizationContext;
	    private ChangePasswordForm _changePasswordForm;

	    /// <summary>
        /// Flag indicates that application has already been restarted.
        /// </summary>
        private bool _isAlreadyRestarted;
		private LoginForm _loginForm;

	    public MainForm()
		{ 
			InitializeComponent();
            _synchronizationContext = SynchronizationContext.Current;
            Icon = Properties.Resources.AppIcon;

	        DefaultControlColor = tsInterviewToolbar.BackColor;

            dialingControl.CancelClick += dialingControl_CancelClick;

		    _connectionIndicatorTooltips = new Dictionary<ConnectionQuality, string>();
		}

        void dialingControl_CancelClick(object sender, DialCancellationEventArgs e)
        {
            if (CancelDialing != null)
            {
                CancelDialing(sender, e);
            }
        }

	    /// <summary>
		/// Login form of application.
		/// </summary>
		public LoginForm LoginForm
		{
			get
			{
				return _loginForm;
			}
			set
			{
				_loginForm = value;
			}
		}

        /// <summary>
        /// ChangePassword form of application.
		/// </summary>
        public ChangePasswordForm ChangePasswordForm
        {
            get
            {
                return _changePasswordForm;
            }
            set
            {
                _changePasswordForm = value;
            }
        }

        public Color DefaultControlColor { get; set; }

        public IViewExtensionNumberForm ExtensionNumberForm
        {
            get;
            set;
        }

	    /// <summary>
	    /// Gets the instance of InterviewPageBrowser
	    /// </summary>
	    public InterviewPageBrowser InterviewPageBrowser
	    {
	        get
	        {
	            return interviewPageBrowser;
	        }
	    }

	    /// <summary>
	    /// Gets the instance of survey list control.
	    /// </summary>
	    public SurveyListControl SurveyListControl
	    {
	        get
	        {
	            return surveyList;
	        }
	    }

	    /// <summary>
	    /// Gets the instance of status bar control.
	    /// </summary>
	    public StatusBarControl StatusBarControl
	    {
	        get
	        {
	            return statusBar;
	        }
	    }

	    /// <summary>
	    /// Gets the instance of OnABreak control.
	    /// </summary>
	    public OnABreakControl OnABreakControl
	    {
	        get
	        {
	            return onABreakControl;
	        }
	    }

	    /// <summary>
	    /// Gets the instance of dialing control.
	    /// </summary>
	    public DialControl DialControl
	    {
	        get
	        {
	            return dialingControl;
	        }
	    }

	    /// <summary>
	    /// Gets the instance of hang up control.
	    /// </summary>
	    public HangupControl HangupControl
	    {
	        get
	        {
	            return hangupControl;
	        }
	    }

	    /// <summary>
	    /// Gets the instance of login to dialer control.
	    /// </summary>
	    public ProcessControl ProcessControl
	    {
	        get
	        {
	            return processControl;
	        }
	    }

	    public event PreviewKeyDownEventHandler KeyButtonDown;

	    private Dictionary<ConnectionQuality, string> _connectionIndicatorTooltips;

	    /// <summary>
		/// Localizes view according given localization information.
		/// </summary>
		/// <param name="manager">Localization manager which contains localization info.</param>
		public void Localize(ILocalizationManager manager)
		{
			Text = manager.GetString("MainForm_Caption");

			tsbMainLogout.Text = manager.GetString("MainForm_TSButtonMainLogout_Text");
			tsbMainLogout.ToolTipText = manager.GetString("MainForm_TSButtonMainLogout_ToolTip");
            tscSurveyLanguages.ToolTipText = manager.GetString("MainForm_TSComboSurveyLanguage_ToolTip");

			tsbPrevious.Text = manager.GetString("MainForm_TSButtonPrevious_Text");
			tsbPrevious.ToolTipText = manager.GetString("MainForm_TSButtonPrevious_ToolTip");
			tsbNext.Text = manager.GetString("MainForm_TSButtonNext_Text");
			tsbNext.ToolTipText = manager.GetString("MainForm_TSButtonNext_ToolTip");
			tsbAppointments.Text = manager.GetString("MainForm_TSButtonAppointments_Text");
			tsbAppointments.ToolTipText = manager.GetString("MainForm_TSButtonAppointments_ToolTip");
			tsbLogoutAfterFinish.Text = manager.GetString("MainForm_TSButtonLogoutAfterFinish_Text");
			tsbLogoutAfterFinish.ToolTipText = manager.GetString("MainForm_TSButtonLogoutAfterFinish_ToolTip");
			tsbTerminate.Text = manager.GetString("MainForm_TSButtonTerminate_Text");
			tsbTerminate.ToolTipText = manager.GetString("MainForm_TSButtonTerminate_ToolTipText");
            tsbRefresh.Text = manager.GetString("MainForm_TSButtonRefresh_Text");
            tsbRefresh.ToolTipText = manager.GetString("MainForm_TSButtonRefresh_ToolTipText");
		    tsbSpellCheck.Text = manager.GetString("MainForm_TSButtonCheckSpelling_Text");
            tsbSpellCheck.ToolTipText = manager.GetString("MainForm_TSButtonCheckSpelling_ToolTipText");
            tsbRedo.Text = manager.GetString("MainForm_TSButtonRedo_Text");
            tsbRedo.ToolTipText = manager.GetString("MainForm_TSButtonRedo_ToolTipText");
            tsbFastForward.Text = manager.GetString("MainForm_TSButtonFastForward_Text");
            tsbFastForward.ToolTipText = manager.GetString("MainForm_TSButtonFastForward_ToolTipText");
            tsbPendingBreak.Text = manager.GetString("MainForm_TSButtonPendingBreak_Text");            
            tsbPendingBreak.ToolTipText = manager.GetString("MainForm_TSButtonPendingBreak_ToolTipText");
            tsbChangeTaskChoice.Text = manager.GetString("MainForm_TSButtonChangeTaskChoice_Text");
            tsbChangeTaskChoice.ToolTipText = manager.GetString("MainForm_TSButtonChangeTaskChoice_ToolTipText");
            tsbHangUp.Text = manager.GetString("MainForm_TSButtonHangUp_Text");
            tsbHangUp.ToolTipText = manager.GetString("MainForm_TSButtonHangUp_ToolTipText");
            tsbRedial.Text = manager.GetString("MainForm_TSButtonRedial_Text");
            tsbRedial.ToolTipText = manager.GetString("MainForm_TSButtonRedial_ToolTipText");

            ExtensionNumberForm.Localize(manager);

            tsbAppointmensList.Text = manager.GetString("MainForm_TSAppointmensList_Text");
            tsbAppointmensList.ToolTipText = manager.GetString("MainForm_TSAppointmensList_Text");
            tsbMessageForm.Text = manager.GetString("MainForm_TSMessagingForm_Text");

		    _connectionIndicatorTooltips[ConnectionQuality.No] = manager.GetString("StatusBarControl_ConnectionQuality_No_ToolTipText");
		    _connectionIndicatorTooltips[ConnectionQuality.Poor] = manager.GetString("StatusBarControl_ConnectionQuality_Poor_ToolTipText");
		    _connectionIndicatorTooltips[ConnectionQuality.Normal] = manager.GetString("StatusBarControl_ConnectionQuality_Normal_ToolTipText");
		    _connectionIndicatorTooltips[ConnectionQuality.Good] = manager.GetString("StatusBarControl_ConnectionQuality_Good_ToolTipText");
        }

	    /// <summary>
        /// Index of selected language in survey language list.
		/// </summary>
		public int SelectedSurveyLanguage
		{
			get
			{
				return tscSurveyLanguages.SelectedIndex;
			}
			set
			{
                if (value < 0 || value >= tscSurveyLanguages.Items.Count)
                {
                    throw new ArgumentOutOfRangeException("value");
                }

				tscSurveyLanguages.SelectedIndex = value;
			}
		}

        /// <summary>
        /// Gets index of selected question in redo questions list.
        /// If there is no selected question returns negative number.
        /// </summary>
        public int SelectedRedoQuestion
        {
            get
            {
                int result = -1;
                for (int i = 0; i <= tsbRedo.DropDownItems.Count; i++)
                {
                    if (tsbRedo.DropDownItems[i].Selected)
                    {
                        result = i;
                        break;
                    }
                }

                return result;
            }
        }

        /// <summary>
        /// Gets/sets current application cursor.
        /// </summary>
        Cursor IViewMainForm.Cursor
        {
            get
            {
                return base.Cursor;
            }
            set
            {
                base.Cursor = value;
            }
        }

        /// <summary>
        /// Gets flag indicating that survey list control is shown to user.
        /// </summary>
        public bool IsSurveyListShown
        {
            get
            {
                return SurveyListControl.Visible;
            }
        }

	    public void SetDialCanellationButtonVisibility(bool isVisible)
	    {
            dialingControl.ShowCancelButton(isVisible);
	    }

	    public void UpdateConnectionIndicator(ConnectionQuality quality)
	    {
	        Bitmap image = null;

	        switch (quality)
	        {
                case ConnectionQuality.Good:
                    image = Properties.Resources.good_connection;
                    break;
                case ConnectionQuality.Normal:
                    image = Properties.Resources.normal_connection;
                    break;
                case ConnectionQuality.Poor:
                    image = Properties.Resources.poor_connection;
                    break;
                case ConnectionQuality.No:
                    image = Properties.Resources.no_connection;
                    break;
	        }

	        var tooltip = _connectionIndicatorTooltips[quality];

	        StatusBarControl.UpdateConnectionIndicator(image, tooltip);
	    }

	    /// <summary>
		/// Occurs when form is loaded.
		/// </summary>
		public event EventHandler<EventArgs> FormLoad;

        /// <summary>
        /// Occures when user is going to close form.
        /// </summary>
        public event FormClosingEventHandler FormExiting;

		/// <summary>
		/// Occurs when the form is closed.
		/// </summary>
		public event EventHandler<EventArgs> FormClose;

		/// <summary>
		/// Occures when user is going to start new interview.
		/// </summary>
		public event EventHandler<EventArgs> NewInterview;

		/// <summary>
		/// Occures when user is going to see previous interview page.
		/// </summary>
		public event EventHandler<EventArgs> PreviousPage;

		/// <summary>
		/// Occures when user is going to see next interview page.
		/// </summary>
		public event EventHandler<EventArgs> NextPage;

		/// <summary>
		/// Occurs when user is going to see appointments editing dialog.
		/// </summary>
		public event EventHandler<EventArgs> ShowAppointments;

        public event EventHandler<EventArgs> ShowRedialForm;

		/// <summary>
		/// Occures when user is going to log out.
		/// </summary>
		public event EventHandler<EventArgs> Logout;

	    public event EventHandler<EventArgs> PendingBreak;

        public event EventHandler<EventArgs> ChangeTaskChoice;

        public event EventHandler<EventArgs> FormActivated;

	    /// <summary>
		/// Occurs when current interview is going to be terminated.
		/// </summary>
		public event EventHandler<EventArgs> TerminateInterview;

		/// <summary>
		/// Occurs when user changed selected language.
		/// </summary>
		public event EventHandler<EventArgs> SelectedSurveyLanguageChanged;

        /// <summary>
        /// Occurs when user is going to open redo drop-down list.
        /// </summary>
        public event EventHandler<EventArgs> RedoDropDownOpening;

        /// <summary>
        /// Occurs when user opens redo drop-down list.
        /// </summary>
        public event EventHandler<EventArgs> RedoDropDownOpen;

        /// <summary>
        /// Occurs when user closes redo drop-down list.
        /// </summary>
        public event EventHandler<EventArgs> RedoDropDownClose;

        /// <summary>
        /// Occurs when user is going to set pending logout flag.
        /// </summary>
        public event EventHandler<EventArgs> PendingLogout;

        /// <summary>
        /// Occurs when user selected question in redo list.
        /// </summary>
        public event EventHandler<EventArgs> RedoQuestionChanged;

        /// <summary>
        /// Occurs when user is going to do fast forward.
        /// </summary>
        public event EventHandler<EventArgs> FastForward;

        /// <summary>
        /// Occurs when user is going to do hang up.
        /// </summary>
        public event EventHandler<EventArgs> HangUp;

        /// <summary>
        /// Occurs when user is going to do internal call transfer.
        /// </summary>
        public event EventHandler<EventArgs> InternalCallTransfer;

        /// <summary>
        /// Occurs when user is going to do external call transfer.
        /// </summary>
        public event EventHandler<EventArgs> ExternalCallTransfer;

        /// <summary>
        /// Occurs when user is going to refresh current interview list.
        /// </summary>
        public event EventHandler<EventArgs> RefreshInterviewList;

        /// <summary>
        /// Occurs when user press any key.
        /// </summary>
        public event EventHandler<ProcessCmdKeyEventArgs> FormProcessCmdKey;

        /// <summary>
        /// Occurs when user precc Cancel during dialing process.
        /// </summary>
        public event EventHandler<DialCancellationEventArgs> CancelDialing;

	    /// <summary>
        /// Occurs when user is going to see all interviewer appointments.
        /// </summary>
        public event EventHandler<EventArgs>  ShowInterviewerAppointments;

        /// <summary>
        /// Occurs when user is going to open Message form
        /// </summary>
        public event EventHandler<EventArgs> ShowMessagingForm;

        /// <summary>
        /// Occurs when user is going to play sound file to respondent.
        /// </summary>
        public event EventHandler<EventArgs> StartPlayback;

        /// <summary>
        /// Occurs when user is going to check spelling.
        /// </summary>
        public event EventHandler<EventArgs> SpellCheck;

        /// <summary>
        /// Occurs when user is going to pause/resume playing sound file to respondent.
        /// </summary>
        public event EventHandler<EventArgs> PauseOrResumePlayback;

        /// <summary>
        /// Occurs when user is going to pause/resume playing sound file to respondent.
        /// </summary>
        public event EventHandler<EventArgs> StopPlayback;

        /// <summary>
        /// Occurs when user is going to switch agent from hear respondent to hear playing and back.
        /// </summary>
        public event EventHandler<EventArgs> ToggleInterviewerListensToPlaybackOrRespondent;

        /// <summary>
		/// Closes form.
		/// </summary>
		public void CloseForm()
		{
			Close();
		}

	    /// <summary>
	    /// Binds survey language list with given values.
	    /// </summary>
	    /// <param name="languages">Array of languages to bind.</param>
	    public void BindSurveyLanguageList(string[] languages)
		{
			tscSurveyLanguages.Items.Clear();
			tscSurveyLanguages.Items.AddRange(languages);
		}

        /// <summary>
        /// Binds list of redo questions with given values.
        /// </summary>
        /// <param name="questions">List of question to bind.</param>
        public void BindRedoList(string[] questions)
        {
            tsbRedo.DropDown.Items.Clear();
            foreach (string question in questions)
            {
                tsbRedo.DropDown.Items.Add(question);
            }
        }

	    /// <summary>
		/// Shows log in form and disables all other controls.
		/// </summary>
		public void ShowLoginForm()
		{
			ShowBlankForm();
			LoginForm.ShowDialog(this);
		}

        /// <summary>
        /// Shows redial button in form.
        /// </summary>
        public void ShowRedialButton(bool show)
        {
            tsbRedial.Visible = show;
        }
        
        /// <summary>
        /// Shows internal call transfer button in form.
        /// </summary>
        public void ShowInternalCallTransferButton(bool show)
        {
            tsbInternalCallTransfer.Visible = show;
        }

	    /// <summary>
	    /// Shows external call transfer button in form.
	    /// </summary>
	    public void ShowExternalCallTransferButton(bool show)
	    {
	        tsbExternalCallTransfer.Visible = show;
	    }

        /// <summary>
        /// Shows log in form and disables all other controls.
        /// </summary>
        public void ShowChangePasswordForm()
        {            
            ChangePasswordForm.ShowDialog(this);
        }

        /// <summary>
        /// Clear state of visual components
        /// </summary>
        public void ClearVisualState()
        {
            tsbLogoutAfterFinish.Checked = false;
        }

        /// <summary>
        /// Shows ExtensionNumberForm
        /// </summary>
        public LoginToDiallerResult ShowExtensionNumberForm()
        {
            return ExtensionNumberForm.ShowDialog(this);
        }

	    /// <summary>
	    /// Shows interview page browser control and hides all other controls.
	    /// </summary>
	    public void ShowInterviewPageControl(ToolbarState toolbarState)
	    {
            surveyList.Enabled = false;
            surveyList.Visible = false;
            EnableInterviewToolbar(true, toolbarState);
            EnableMessagingToolbar(true, toolbarState.IsChangeTaskChoiceEnabled, toolbarState);
            EnableMainToolbar(false);

            interviewPageBrowser.Enabled = true;
            interviewPageBrowser.Visible = true;

            dialingControl.Enabled = false;
            dialingControl.Visible = false;
            hangupControl.Enabled = false;
            hangupControl.Visible = false;
            processControl.Visible = false;
            processControl.Enabled = false;
            onABreakControl.Enabled = false;
            onABreakControl.Visible = false;
            internalTransferControl.Enabled = false;
            internalTransferControl.Visible = false;
        }

		/// <summary>
		/// Shows survey list control and hides all other controls.
		/// </summary>
        public void ShowSurveyListControl(ToolbarState state)
		{
			interviewPageBrowser.Enabled = false;
			interviewPageBrowser.Visible = false;

		    var toolbarState = new ToolbarState
		    {
		        IsHangUpEnabled = false,
		        IsPendingLogoutEnabled = false,
		        IsRedialEnabled = false,
                IsInternalCallTransferEnabled = false,
                IsExternalCallTransferEnabled = false,
                IsTakeBreakEnabled = state.IsTakeBreakEnabled,
                IsChangeTaskChoiceEnabled = state.IsChangeTaskChoiceEnabled,
                IsMessageFormEnabled = state.IsMessageFormEnabled,
                IsAppointmensListEnabled = state.IsAppointmensListEnabled,
                IsRefreshEnabled = state.IsRefreshEnabled,
                IsLogoutEnabled = state.IsLogoutEnabled
		    };

            EnableInterviewToolbar(false, toolbarState);
            EnableMainToolbar(true, toolbarState);
            EnableMessagingToolbar(true, state.IsChangeTaskChoiceEnabled, toolbarState);

			surveyList.Enabled = true;
			surveyList.Visible = true;
            surveyList.Focus();

            dialingControl.Enabled = false;
            dialingControl.Visible = false;
            hangupControl.Enabled = false;
            hangupControl.Visible = false;
            processControl.Visible = false;
            processControl.Enabled = false;
            onABreakControl.Enabled = false;
            onABreakControl.Visible = false;
            internalTransferControl.Enabled = false;
            internalTransferControl.Visible = false;
        }

	    /// <summary>
        /// Shows dial control and hides all other controls.
        /// </summary>
        public void ShowDialControl()
        {
            HideAndDisableAllControls(true, true);

            dialingControl.Enabled = true;
            dialingControl.Visible = true;            
        }

        /// <summary>
        /// Show hang up control and hides all other controls.
        /// </summary>
        public void ShowHangupControl()
        {
            HideAndDisableAllControls();

            hangupControl.Enabled = true;
            hangupControl.Visible = true;            
        }
        
        public void ShowInternalTransferControl(ILocalizationManager manager, string surveyName, string respondentName, string trasferingInterviewer, string interviewId)
        {
            if (!internalTransferControl.Visible)
            {
                HideAndDisableAllControls();

                internalTransferControl.Enabled = true;
                internalTransferControl.Visible = true;
            }

            internalTransferControl.Localize(manager, surveyName, respondentName, trasferingInterviewer, interviewId);
        }

        /// <summary>
        /// Show login to dialer control and hides all other controls.
        /// </summary>
        /// <param name="processMessage">Message to show.</param>
        public void ShowProcessControl(string processMessage)
        {
            ShowProcessControl(processMessage, true, true);
        }

	    /// <summary>
	    /// Show login to dialer control and hides all other controls. If enableLogout flag is true,
	    /// toolbar button Logout will not be disabled.
	    /// </summary>
	    /// <param name="processMessage">Message to show.</param>
	    /// <param name="enableLogout">Flag indicates should we enable toolbar Logout button or not.</param>
	    /// <param name="pendingBreakEnabled"></param>
	    public void ShowProcessControl(string processMessage, bool enableLogout, bool pendingBreakEnabled)
        {
            interviewPageBrowser.Enabled = false;
            interviewPageBrowser.Visible = false;

            surveyList.Enabled = false;
            surveyList.Visible = false;

            var toolbarState = new ToolbarState
            {
                IsHangUpEnabled = false,
                IsPendingLogoutEnabled = false,
                IsRedialEnabled = false,
                IsInternalCallTransferEnabled = false,
                IsExternalCallTransferEnabled = false
            };

            EnableInterviewToolbar(false, toolbarState);

            tsbChangeTaskChoice.Enabled = false;
            tsbPendingBreak.Enabled = pendingBreakEnabled;

            if (enableLogout)
            {
                tsbRefresh.Enabled = false;
                tsbAppointmensList.Enabled = false;
                tsbMainLogout.Enabled = true;
            }
            else
            {
                EnableMainToolbar(false);
            }

            dialingControl.Enabled = false;
            dialingControl.Visible = false;
            hangupControl.Enabled = false;
            hangupControl.Visible = false;
            onABreakControl.Enabled = false;
            onABreakControl.Visible = false;
            internalTransferControl.Enabled = false;
            internalTransferControl.Visible = false;

            processControl.ProcessMessage = processMessage;
            processControl.Visible = true;
            processControl.Enabled = true;
        }

        /// <summary>
        /// Shows on a break control.
        /// </summary>
        /// <remarks>
        /// PendingBreak button must be unchecked and disabled.
        /// </remarks>
        public void ShowOnABreakControl()
        {
            HideAndDisableAllControls();

            onABreakControl.Enabled = true;
            onABreakControl.Visible = true;                       
        }

	    public void EnableDialCanellationButton(bool isEnabled)
	    {
	       DialControl.EnableDialCanellationButton(isEnabled);
	    }

	    /// <summary>
		/// Shows form without any controls on it.
		/// </summary>
		public void ShowBlankForm()
		{
            if (WindowState == FormWindowState.Minimized)
            {
                //should do this because main form will remain minimized
                WindowState = FormWindowState.Maximized;
            }

			interviewPageBrowser.Enabled = false;
			interviewPageBrowser.Visible = false;

			surveyList.Enabled = false;
			surveyList.Visible = false;

            var toolbarState = new ToolbarState
            {
                IsHangUpEnabled = false,
                IsPendingLogoutEnabled = false,
                IsRedialEnabled = false,
                IsInternalCallTransferEnabled = false,
                IsExternalCallTransferEnabled = false
            };

            EnableInterviewToolbar(false, toolbarState);
            EnableMessagingToolbar(false, false);
			EnableMainToolbar(false);

            dialingControl.Enabled = false;
            dialingControl.Visible = false;
            hangupControl.Enabled = false;
            hangupControl.Visible = false;
            processControl.Visible = false;
            processControl.Enabled = false;
            onABreakControl.Visible = false;
            onABreakControl.Enabled = false;
            internalTransferControl.Enabled = false;
            internalTransferControl.Visible = false;
        }

        /// <summary>
        /// Restart current application
        /// </summary>
        /// <remarks>
        /// It is used if we need forced application restart.
        /// For example when receive ForceLogout in KeepAlive method
        /// </remarks>
        public void RestartApplication()
        {
            lock (_locker)
            {
                if (_isAlreadyRestarted == false)
                {
                    Application.Restart();
                    _isAlreadyRestarted = true;
                }
            }
        }

        /// <summary>
        /// Changes toolbar messagin icon
        /// </summary>
        /// <param name="newMessageIn"></param>
        public void ChangeToolbarMessagingIcon(bool newMessageIn)
        {
            if (newMessageIn == false)
            {
                tsbMessageForm.Image = Properties.Resources.MessageBox;                
            }
            else
            {
                tsbMessageForm.Image = Properties.Resources.MessageIn;
            }
        }

        public void ShowPlaybackToolbar(bool isVisible, bool pauseIsAvailable, bool toggleVoiceSourceIsAvailable)
        {
            tsPlaybackToolbar.Visible = isVisible;
            toolStripSeparator4.Visible = isVisible;
            tsbPauseOrResumePlayback.Visible = pauseIsAvailable;
            tsbToggleInterviewerListensToPlaybackOrRespondent.Visible = toggleVoiceSourceIsAvailable;
        }

	    public SynchronizationContext SynchronizationContext
        {
          get { return _synchronizationContext; }
        }

	    /// <summary>
		/// Gets/sets value indicating state of "Log out after finishing current interview" option.
		/// If option is checked, returns true; otherwise false.
		/// </summary>
		public bool IsLogoutAfterFinishingChecked 
		{
			get
			{
				return tsbLogoutAfterFinish.Checked; 
			}
			set
			{
				tsbLogoutAfterFinish.Checked = value;
			}
		}

	    public bool IsNextPageEnabled
	    {
            get { return tsbNext.Enabled; }
	    }

	    public bool IsPreviousPageEnabled
	    {
	        get { return tsbPrevious.Enabled; }
	    }

	    public bool IsFastForwardEnabled
	    {
	        get { return tsbFastForward.Enabled; }
	    }

	    public bool IsTerminateEnabled
	    {
	        get { return tsbTerminate.Enabled; }
	    }

	    public bool IsAppointmentsEnabled
	    {
	        get { return tsbAppointments.Enabled; }
	    }

	    public bool IsHangUpEnabled
	    {
            get { return tsbHangUp.Enabled; }
	    }

	    public bool IsRefreshEnabled
	    {
	        get { return tsbRefresh.Enabled; }
	    }

	    public bool IsCheckSpellingEnabled
        {
	        get { return tsbSpellCheck.Enabled; }
        }

	    /// <summary>
        /// Gets flag indicating is Logout after finish button enabled or not.
        /// </summary>
        public bool IsLogoutAfterFinishingEnabled
        {
            get => tsbLogoutAfterFinish.Enabled;
	        set => tsbLogoutAfterFinish.Enabled = value;
	    }

	    /// <summary>
	    /// Gets/sets flag indicating is Pending break checked or not.        
	    /// </summary>
	    public bool IsPendingBreakChecked { get; set; }

	    /// <summary>
	    /// Gets flag indicating is Pending break button enabled or not.
	    /// </summary>
	    public bool IsPendingBreakEnabled
        {
            get => tsbPendingBreak.Enabled;
	        set => tsbPendingBreak.Enabled = value;
	    }

	    public bool IsDialCanellationButtonEnabled 
        {
	        get
	        {
	            return DialControl.IsDialCanellationButtonEnabled;
	        }
	        set
	        {
	            DialControl.IsDialCanellationButtonEnabled = value; 
	        }
	    }

	    public bool IsChangeTaskChoiceChecked
        {
            get
            {
                return tsbChangeTaskChoice.Checked;
            }
            set
            {
                tsbChangeTaskChoice.Checked = value;
            }
        }

	    /// <summary>
	    /// Disables Appointment button in the interview toolbar
	    /// </summary>
	    public void EnableAppointmentButton(bool enable)
	    {
	        tsbAppointments.Enabled = enable;
	    }

	    /// <summary>
	    /// Disables Terminate button in the interview toolbar
	    /// </summary>
	    public void EnableTerminateButton(bool enable)
	    {
	        tsbTerminate.Enabled = enable;
	    }

        /// <summary>
        /// Disables interview toolbar
        /// </summary>
        public void DisableToolbars()
	    {
	        var toolbarState = new ToolbarState
	        {
	            IsHangUpEnabled = false,
	            IsPendingLogoutEnabled = false,
	            IsRedialEnabled = false,
                IsInternalCallTransferEnabled = false,
                IsExternalCallTransferEnabled = false
	        };

	        EnableMainToolbar(false);
	        EnableInterviewToolbar(false, toolbarState);
	        IsPendingBreakEnabled = false;
	    }

        public void SetAutoPilotMode()
        {
            Text += Strings.MainFormAutoPilotModeText;
        }

	    private void MainForm_Load(object sender, EventArgs e)
	    {
	        OnFormLoad(EventArgs.Empty);
	    }

	    void MainForm_Activated(object sender, EventArgs e)
	    {
	        NotifyFormActivated(EventArgs.Empty);
	    }

	    void MainForm_LostFocus(object sender, EventArgs e)
	    {
	        if (WindowState != FormWindowState.Minimized)
	        {
	            NotifyFormActivated(EventArgs.Empty);
	        }
	    }

	    private void tsbPrevious_Click(object sender, EventArgs e)
	    {
	        OnPreviousPage(EventArgs.Empty);
	    }

	    private void tsbNext_Click(object sender, EventArgs e)
	    {
	        OnNextPage(EventArgs.Empty);
	    }		

	    private void tsbMainLogout_Click(object sender, EventArgs e)
	    {
	        OnLogout(EventArgs.Empty);
	    }

	    private void tsbAppointments_Click(object sender, EventArgs e)
	    {
	        OnShowAppointments(EventArgs.Empty);
	    }

	    private void tsbRedial_Click(object sender, EventArgs e)
	    {
	        OnShowRedialForm(EventArgs.Empty);
	    }

	    private void tbsTerminate_Click(object sender, EventArgs e)
	    {
	        OnTerminateInterview(EventArgs.Empty);
	    }

	    private void tscSurveyLanguages_SelectedIndexChanged(object sender, EventArgs e)
	    {
	        OnSelectedSurveyLanguageChanged(EventArgs.Empty);
	    }

	    private void tsbRedo_DropDownOpened(object sender, EventArgs e)
	    {
	        OnRedoDropDownOpen(EventArgs.Empty);
	    }

	    private void tsbRedo_DropDownClosed(object sender, EventArgs e)
	    {
	        OnRedoDropDownClose(EventArgs.Empty);
	    }

	    private void tsbRedo_DropDownOpening(object sender, EventArgs e)
	    {
	        OnRedoDropDownOpening(EventArgs.Empty);
	    }

	    private void tsbRedo_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
	    {           
	        OnRedoQuestionChanged(EventArgs.Empty);
	    }

	    private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
	    {
	        OnFormExiting(e);
	    }

	    private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
	    {
	        OnFormClose(e);
	    }

	    private void tsbFastForward_Click(object sender, EventArgs e)
	    {
	        OnFastForward(EventArgs.Empty);
	    }

	    private void tsbLogoutAfterFinish_Click(object sender, EventArgs e)
	    {
            OnPendingLogout(EventArgs.Empty);
	    }

	    private void tsbRefresh_Click(object sender, EventArgs e)
	    {
	        OnRefreshInterviewList(EventArgs.Empty);
	    }
        
        private void tsbAppointmensList_Click(object sender, EventArgs e)
	    {
	        OnShowInterviewerAppointmens(EventArgs.Empty);
	    }

	    private void tsbMessageForm_Click(object sender, EventArgs e)
	    {
	        OnShowMessagingForm(EventArgs.Empty);            
	    }

	    private void tsbHangUp_Click(object sender, EventArgs e)
	    {
	        OnHangUp(EventArgs.Empty);
	    }

	    private void tsbSpellCheck_Click(object sender, EventArgs e)
	    {
	        OnSpellCheck(EventArgs.Empty);
	    }
       
	    private void tsbStartPlayback_Click(object sender, EventArgs e)
	    {
	        OnStartPlayback(EventArgs.Empty);
	    }

	    private void tsbPauseOrResumePlayback_Click(object sender, EventArgs e)
	    {
	        OnPauseOrResumePlayback(EventArgs.Empty);
	    }

	    private void tsbStopPlayback_Click(object sender, EventArgs e)
	    {
	        OnStopPlayback(EventArgs.Empty);
	    }

	    private void tsbPendingBreak_Click(object sender, EventArgs e)
	    {
	        ClickPendingBreak();
	    }

        public void ClickPendingBreak()
        {
            OnPendingBreak(EventArgs.Empty);
        }

        public void ShowPendingBreakDropdown()
        {
            tsbPendingBreak.DropDown.Show();
        }

        public void BindBreakTypes(List<BreakType> breakTypes)
        {
            tsbPendingBreak.DropDown.Items.Clear();
            if (breakTypes.Count == 1) return;

            tsbPendingBreak.Click -= tsbPendingBreak_Click;

            foreach (var item in breakTypes)
	        {
	            tsbPendingBreak.DropDown.Items.Add(new ToolStripMenuItem(item.Name)
	            {
	                ToolTipText = item.Description,
	                CheckOnClick = true,
	                ImageScaling = ToolStripItemImageScaling.None
	            });
	        }
	    }

	    public void ShowBreakDetails(bool displayBreakType, string breakInfo)
	    {
	        onABreakControl.SetBreakType(displayBreakType, breakInfo);
	    }

	    public int? SelectedBreakIndex { get; set; }

	    private void tsbToggleInterviewerListensToPlaybackOrRespondent_Click(object sender, EventArgs e)
	    {
	        OnToggleInterviewerListensToPlaybackOrRespondent(EventArgs.Empty);
	    }

	    private void tsbChangeTaskChoice_Click(object sender, EventArgs e)
	    {
            OnChangeTaskChoice(EventArgs.Empty);
	    }

        private void HideAndDisableAllControls(bool isPendingLogoutEnabled = false, bool isTakeBreakEnabled = false)
        {
            interviewPageBrowser.Enabled = false;
            interviewPageBrowser.Visible = false;

            surveyList.Enabled = false;
            surveyList.Visible = false;

            var toolbarState = new ToolbarState
            {
                IsPendingLogoutEnabled = isPendingLogoutEnabled,
                IsTakeBreakEnabled = isTakeBreakEnabled
            };

            EnableInterviewToolbar(true, toolbarState);
            EnableMainToolbar(false);
            EnableMessagingToolbar(false, false);
            IsPendingBreakEnabled = isTakeBreakEnabled;
            ShowPlaybackToolbar(false, false, false);

            dialingControl.Enabled = false;
            dialingControl.Visible = false;
            hangupControl.Enabled = false;
            hangupControl.Visible = false;
            processControl.Visible = false;
            processControl.Enabled = false;
            onABreakControl.Visible = false;
            onABreakControl.Enabled = false;
            internalTransferControl.Enabled = false;
            internalTransferControl.Visible = false;
        }

	    /// <summary>
		/// Fires FormLoad event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnFormLoad(EventArgs e)
		{
            SubscribeToKeyDownEvent(Controls);

            if (FormLoad != null)
			{
				FormLoad(this, e);
			}
		}

        private void SubscribeToKeyDownEvent(Control.ControlCollection colls)
        {
            foreach (Control ctr in colls)
            {
                ctr.PreviewKeyDown += Form_KeyDown;
                SubscribeToKeyDownEvent(ctr.Controls);
            }
        }

        private void Form_KeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (KeyButtonDown != null)
            {
                KeyButtonDown(sender, e);
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            ProcessCmdKeyEventArgs eventArgs = new ProcessCmdKeyEventArgs { KeyData = keyData };

            if (FormProcessCmdKey != null)
            {
                OnFormProcessCmdKey(eventArgs);
            }

            if (eventArgs.Cancel)
            {
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void OnFormProcessCmdKey(ProcessCmdKeyEventArgs eventArgs)
        {
            FormProcessCmdKey(this, eventArgs);
        }

        /// <summary>
        /// Fires FormExiting event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnFormExiting(FormClosingEventArgs e)
        {
            if (FormExiting != null)
            {
                FormExiting(this, e);
            }
        }

		/// <summary>
		/// Fires FormClose event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnFormClose(EventArgs e)
		{
			if (FormClose != null)
			{
				FormClose(this, e);
			}
		}

		/// <summary>
		/// Fires NewInterview event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnNewInterview(EventArgs e)
		{
			if (NewInterview != null)
			{
				NewInterview(this, e);
			}
		}

        private void NotifyFormActivated(EventArgs e)
        {
            if ((FormActivated != null) && (CanFocus))
            {
                FormActivated(this, e);
            }
        }

		/// <summary>
		/// Fires PreviousPage event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnPreviousPage(EventArgs e)
		{
			if (PreviousPage != null)
			{
				PreviousPage(this, e);
			}
		}

		/// <summary>
		/// Fires NextPage event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnNextPage(EventArgs e)
		{
			if (NextPage != null)
			{
				NextPage(this, e);
			}
		}

		/// <summary>
		/// Fires Logout event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnLogout(EventArgs e)
		{
			if (Logout != null)
			{
				Logout(this, e);
			}
		}

		/// <summary>
		/// Fires ShowAppointment event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnShowAppointments(EventArgs e)
		{
			if (ShowAppointments != null)
			{
				ShowAppointments(this, e);
			}
		}

        private void OnShowRedialForm(EventArgs e)
        {
            if (ShowRedialForm != null)
            {
                ShowRedialForm(this, e);
            }
        }

	    /// <summary>
	    /// Fires TerminateInterview event.
	    /// </summary>
        /// <param name="e">Event arguments.</param>
	    private void OnTerminateInterview(EventArgs e)
		{
			if (TerminateInterview != null)
			{
				TerminateInterview(this, e);
			}
		}

		/// <summary>
		/// Fires SelectedSurveyLanguageChanged event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnSelectedSurveyLanguageChanged(EventArgs e)
		{
			if (SelectedSurveyLanguageChanged != null)
			{
				SelectedSurveyLanguageChanged(this, e);
			}
		}

        /// <summary>
        /// Fires RedoDropDownOpening event.
        /// </summary>
        /// <param name="e"></param>
        private void OnRedoDropDownOpening(EventArgs e)
        {
            if (RedoDropDownOpening != null)
            {
                RedoDropDownOpening(this, e);
            }
        }

        /// <summary>
        /// Fires RedoDropDownOpen event.
        /// </summary>
        /// <param name="e"></param>
        private void OnRedoDropDownOpen(EventArgs e)
        {
            if (RedoDropDownOpen != null)
            {
                RedoDropDownOpen(this, e);
            }
        }

        /// <summary>
        /// Fires RedoDropDownClose event.
        /// </summary>
        /// <param name="e"></param>
        private void OnRedoDropDownClose(EventArgs e)
        {
            if (RedoDropDownClose != null)
            {
                RedoDropDownClose(this, e);
            }
        }

         /// <summary>
        /// Fires PendingLogout event.
        /// </summary>
        /// <param name="e"></param>
        private void OnPendingLogout(EventArgs e)
        {
            if (PendingLogout != null)
            {
                PendingLogout(this, e);
            }
        }
        /// <summary>
        /// Fires Logout event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnPendingBreak(EventArgs e)
        {
            if (PendingBreak != null)
            {
                PendingBreak(this, e);
            }
        }

        private void OnChangeTaskChoice(EventArgs e)
        {
            if (ChangeTaskChoice != null)
            {
                ChangeTaskChoice(this, e);
            }
        }
   
        /// <summary>
        /// Fires RedoQuestionChanged event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnRedoQuestionChanged(EventArgs e)
        {
            if (RedoQuestionChanged != null)
            {
                RedoQuestionChanged(this, e);
            }
        }

        /// <summary>
        /// Fires FastForward event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnFastForward(EventArgs e)
        {
            if (FastForward != null)
            {
                FastForward(this, e);
            }
        }

        /// <summary>
        /// Fires HangUp event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnHangUp(EventArgs e)
        {
            if (HangUp != null)
            {
                HangUp(this, e);
            }
        }

        /// <summary>
        /// Fires Refresh event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnRefreshInterviewList(EventArgs e)
        {
            if (RefreshInterviewList != null)
            {
                RefreshInterviewList(this, e);
            }
        }

		/// <summary>
        /// Fires ShowAppointmensList event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnShowInterviewerAppointmens(EventArgs e)
        {
            if (ShowInterviewerAppointments != null)
            {
                ShowInterviewerAppointments(this, e);
            }
        }

        /// <summary>
        /// Fires ShowMessagingForm event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnShowMessagingForm(EventArgs e)
        {
            if (ShowMessagingForm != null)
            {
                ShowMessagingForm(this, e);
            }
        }

        /// <summary>
        /// Fires StartPlayback event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        public void OnStartPlayback(EventArgs e)
        {
            if (StartPlayback != null)
            {
                StartPlayback(this, e);
            }
        }

        /// <summary>
        /// Fires StartPlayback event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        public void OnSpellCheck(EventArgs e)
        {
            if (SpellCheck != null)
            {
                SpellCheck(this, e);
            }
        }

        /// <summary>
        /// Fires PauseOrResumePlayback event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnPauseOrResumePlayback(EventArgs e)
        {
            if (PauseOrResumePlayback != null)
            {
                PauseOrResumePlayback(this, e);
            }
        }

        /// <summary>
        /// Fires StopPlayback event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnStopPlayback(EventArgs e)
        {
            if (StopPlayback != null)
            {
                StopPlayback(this, e);
            }
        }

        /// <summary>
        /// Fires OnToggleInterviewerListensToPlaybackOrRespondent event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnToggleInterviewerListensToPlaybackOrRespondent(EventArgs e)
        {
            if (ToggleInterviewerListensToPlaybackOrRespondent != null)
            {
                ToggleInterviewerListensToPlaybackOrRespondent(this, e);
            }
        }

        public void EnableTelephonyToolbar(bool enable, bool enableRedial, ToolbarState state)
        {
            tsbRedial.Enabled = enableRedial && state.IsRedialEnabled;
            tsbHangUp.Enabled = enable && state.IsHangUpEnabled;
            tsbInternalCallTransfer.Enabled = enable && state.IsInternalCallTransferEnabled;
            tsbExternalCallTransfer.Enabled = enable && state.IsExternalCallTransferEnabled;
        }

        /// <summary>
        /// Enables/disables interview toolbar.
        /// </summary>
        /// <param name="enable">If true, enables toolbar; otherwise disables.</param>
        /// <param name="state"></param>
        private void EnableInterviewToolbar(bool enable, ToolbarState state)
        {
            tsbPrevious.Enabled = enable && state.IsPreviousPageEnabled;
            tsbNext.Enabled = enable && state.IsNextPageEnabled;
            tsbAppointments.Enabled = enable && state.IsAppointmentEnabled;
            tsbRedo.Enabled = enable && state.IsRedoEnabled;
            tsbFastForward.Enabled = enable && state.IsFastForwardEnabled;
            tsbSpellCheck.Enabled = enable && state.IsCheckSpellingEnabled;
            EnableTelephonyToolbar(enable, enable, state);
            tsbLogoutAfterFinish.Enabled = enable && state.IsPendingLogoutEnabled;
            tsbTerminate.Enabled = enable && state.IsTerminateEnabled;
            tsbPendingBreak.Enabled = enable && state.IsTakeBreakEnabled;
            tsbChangeTaskChoice.Enabled = enable && state.IsChangeTaskChoiceEnabled;
            tsbMessageForm.Enabled = enable && state.IsMessageFormEnabled;
            tsbAppointmensList.Enabled = enable && state.IsAppointmensListEnabled;
            tsbRefresh.Enabled = enable && state.IsRefreshEnabled;
            tsbMainLogout.Enabled = enable && state.IsLogoutEnabled;
            tscSurveyLanguages.Enabled = enable;

            if (enable && state.Mode == InterviewModes.Reviewing)
            {
                tsbRedo.Enabled = false;
                tsbTerminate.Enabled = false;
                tsbAppointments.Enabled = false;
                tscSurveyLanguages.Enabled = false;
            }
        }

        public void SpecifyMainFormStyle(string title, Color color, bool isInboundCall, bool isTestMode)
        {
            Text = title;

            btnTestMode.Visible = isTestMode;
            tssTestMode.Visible = isTestMode;

            btnInboundCall.Visible = isInboundCall;
            tssInboundCall.Visible = isInboundCall;

            tscToolbarContainer.TopToolStripPanel.BackColor = color;
            tsInterviewToolbar.BackColor = color;
            tsMessaging.BackColor = color;
            tsToolbar.BackColor = color;
        }

        /// <summary>
        /// Enables/disables main toolbar.
        /// </summary>
		/// <param name="enable">If true, enables toolbar; otherwise disables.</param>
		/// <param name="state">Toolbar state</param>
        private void EnableMainToolbar(bool enable, ToolbarState state = null)
		{
            tsbMainLogout.Enabled = enable && (state == null || state.IsLogoutEnabled);
            tsbRefresh.Enabled = enable && (state == null || state.IsRefreshEnabled);
            tsbAppointmensList.Enabled = enable && (state == null || state.IsAppointmensListEnabled);
		}

	    /// <summary>
	    /// Enables/disables messaging toolbar.
	    /// </summary>
	    /// <param name="enable">If true, enables toolbar; otherwise disables.</param>
        /// <param name="changeTaskChoiceEnabled">If true, enable tsbChangeTaskChoice button otherwise disable.</param>
        /// <param name="state">Toolbar state</param>
        private void EnableMessagingToolbar(bool enable, bool changeTaskChoiceEnabled, ToolbarState state = null)
        {
            tsbMessageForm.Enabled = enable && (state == null || state.IsMessageFormEnabled);
            tsbPendingBreak.Enabled = enable && (state == null || state.IsTakeBreakEnabled);
            tsbChangeTaskChoice.Enabled = changeTaskChoiceEnabled && (state == null || state.IsChangeTaskChoiceEnabled);
        }

        private void tsbLogoutAfterFinish_CheckedChanged(object sender, EventArgs e)
        {
            tsbLogoutAfterFinish.Image = tsbLogoutAfterFinish.Checked ? Properties.Resources.LogoutSelected : Properties.Resources.Logout;
        }

        public void UpdatePendingBreakControls(bool cleanCheckedItems = false)
        {
            tsbPendingBreak.Image = IsPendingBreakChecked ? Properties.Resources.WorkBreakSelected : Properties.Resources.WorkBreak;
            if (!IsPendingBreakChecked && cleanCheckedItems)
            {
                foreach (ToolStripMenuItem item in tsbPendingBreak.DropDownItems)
                {
                    item.Checked = false;
                }
            }
        }

        private void tsbChangeTaskChoice_CheckedChanged(object sender, EventArgs e)
        {
            tsbChangeTaskChoice.Image = tsbChangeTaskChoice.Checked ? Properties.Resources.ChangeTaskChoiceSelected : Properties.Resources.ChangeTaskChoice; 
        }

        private void tsbInternalCallTransfer_Click(object sender, EventArgs e)
        {
            InternalCallTransfer?.Invoke(this, e);
        }

        private void tsbExternalCallTransfer_Click(object sender, EventArgs e)
        {
            ExternalCallTransfer?.Invoke(this, e);
        }

        private void tsbPendingBreak_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            foreach (ToolStripMenuItem item in tsbPendingBreak.DropDownItems)
            {
                if (item != e.ClickedItem)
                {
                    item.Checked = false;
                }
            }

            IsPendingBreakChecked = !((ToolStripMenuItem)e.ClickedItem).Checked;
            SelectedBreakIndex = IsPendingBreakChecked ? tsbPendingBreak.DropDownItems.IndexOf(e.ClickedItem) : (int?) null;
            OnPendingBreak(EventArgs.Empty);
        }
    }
}
