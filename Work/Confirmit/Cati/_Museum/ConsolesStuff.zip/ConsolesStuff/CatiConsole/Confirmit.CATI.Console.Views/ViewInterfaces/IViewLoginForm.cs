﻿using System;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Interview;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
	/// <summary>
	/// Represents view interface for LoginForm form.
	/// </summary>
    public interface IViewLoginForm : IWin32Window, ILocalizableView
	{
		/// <summary>
		/// Occurs when user clicks Login button.
		/// </summary>
		event EventHandler<EventArgs> LoginClick;

        /// <summary>
		/// Occurs when user clicks PasswordChangeClick link label.
		/// </summary>
        event EventHandler<EventArgs> PasswordChangeClick;
        
        /// <summary>
        /// Occurs when login form is loaded.
        /// </summary>
        event EventHandler<EventArgs> FormLoad;

        /// <summary>
        /// Occurs when login form is closed.
        /// </summary>
        event EventHandler<EventArgs> FormClose;

        /// <summary>
        /// Occurs when user check cbSetAsDefaultCompany check box.
        /// </summary>
        event EventHandler<EventArgs> SetAsDefaultCompanyCheck;

        /// <summary>
        /// Occurs when user uncheck cbSetAsDefaultCompany check box.
        /// </summary>
        event EventHandler<EventArgs> SetAsDefaultCompanyUncheck;

        /// <summary>
        /// Occurs when user press any key.
        /// </summary>
        event EventHandler<ProcessCmdKeyEventArgs> FormProcessCmdKey;

		/// <summary>
		/// Name of log-in user.
		/// </summary>
		string LoginUser 
		{ 
			get; 
			set; 
		}

		/// <summary>
		/// Log-in password.
		/// </summary>
		string LoginPassword
		{
			get;
			set;
		}

        /// <summary>
        /// Log-in company alias
        /// </summary>
        string LoginCompanyAlias
        {
            get;
            set;
        }

		/// <summary>
		/// Indicates if user logged-in or not.
		/// </summary>
		bool IsLoggedIn
		{
			get;
			set;
		}

        /// <summary>
        /// Indicates is company input enabled or not.
        /// </summary>
        bool CompanyInputEnabled
        {
            get;
            set;
        }

		/// <summary>
		/// Clears data in all input forms.
		/// </summary>
		void Clear();

		/// <summary>
		/// Closes form.
		/// </summary>
		void CloseForm();

        /// <summary>
        /// Make the form visible
        /// </summary>
        void ShowForm();

        /// <summary>
        /// Make the form invisible
        /// </summary>
        void HideForm();
	}
}
