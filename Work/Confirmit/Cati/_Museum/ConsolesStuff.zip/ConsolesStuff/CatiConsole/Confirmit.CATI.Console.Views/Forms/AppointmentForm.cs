﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Views.Forms
{
	/// <summary>
	/// Represents appointment form.
	/// </summary>
	public partial class AppointmentForm : Form, IViewAppointmentForm
	{
        private SynchronizationContext m_SynchronizationContext;
	    private FormClosingEventHandler _formClosing;

	    /// <summary>
		/// Initializes new instance of AppointmentForm class.
		/// </summary>
		public AppointmentForm()
		{
			InitializeComponent();

            m_SynchronizationContext = SynchronizationContext.Current;

			InitializeErrorProviders();

			FormResult = FormCloseReasons.None;
			SuppressEvents = false;
			HandleDestroyed += AppointmentForm_HandleDestroyed;
		}

	    /// <summary>
		/// Localizes view according given localization information.
		/// </summary>
		/// <param name="manager">Localization manager which contains localization info.</param>
		public void Localize(ILocalizationManager manager)
		{
			Text = manager.GetString("AppointmentForm_Caption");
			lbTitle.Text = manager.GetString("AppointmentForm_Title");
			lbTitleDescription.Text = manager.GetString("AppointmentForm_TitleDescription");
			gbTime.Text = manager.GetString("AppointmentForm_GroupTime_Text");
			lbRespondent.Text = manager.GetString("AppointmentForm_LabelRespondentTime_Text");
			lbInterviewer.Text = manager.GetString("AppointmentForm_LabelInterviewerTime_Text");
			gbEdit.Text = manager.GetString("AppointmentForm_GroupEdit_Text");
			lbAppointmentDate.Text = manager.GetString("AppointmentForm_LabelAppointmentDate_Text");
			lbAppointmentTime.Text = manager.GetString("AppointmentForm_LabelAppointmentTime_Text");
			lbExpirationDate.Text = manager.GetString("AppointmentForm_LabelExpirationDate_Text");
			lbExpirationTime.Text = manager.GetString("AppointmentForm_LabelExpirationTime_Text");
			chbNeverExpire.Text = manager.GetString("AppointemntForm_CheckNeverExpire_Text");
			chbLogout.Text = manager.GetString("AppointmentForm_RadioLogout_Text");
			btnOk.Text = manager.GetString("AppointmentForm_ButtonOk_Text");
			btnCancel.Text = manager.GetString("AppointmentForm_ButtonCancel_Text");
            lbShowInterviewerAppointmens.Text = manager.GetString("AppointmentForm_ShowInterviewerAppointmens_Text");
            chbAllowAppOutsideShift.Text = manager.GetString("AppointmentForm_CheckAllowOutsideShifts_Text");
        }

	    /// <summary>
		/// Occurs when button Ok is clicked.
		/// </summary>
		public event EventHandler<EventArgs> OkClick;

		/// <summary>
		/// Occurs when button Remove is clicked.
		/// </summary>
		public event EventHandler<EventArgs> RemoveClick;

		/// <summary>
		/// Occurs when contact name is going to be validated.
		/// </summary>
		public event EventHandler<CancelEventArgs> ValidatingContactName;

		/// <summary>
		/// Occurs when appointment date is going to be validated.
		/// </summary>
		public event EventHandler<CancelEventArgs> ValidatingAppointmentDate;

		/// <summary>
		/// Occurs when appointment time is going to be validated.
		/// </summary>
		public event EventHandler<CancelEventArgs> ValidatingAppointmentTime;

		/// <summary>
		/// Occurs when expiration date is going to be validated.
		/// </summary>
		public event EventHandler<CancelEventArgs> ValidatingExpirationDate;

		/// <summary>
		/// Occurs when expiration time is going to be validated.
		/// </summary>
		public event EventHandler<CancelEventArgs> ValidatingExpirationTime;

		/// <summary>
		/// Occurs when form is going to be validated. This event is fired only
		/// if children controls validation is successfull.
		/// </summary>
		public event EventHandler<CancelEventArgs> ValidatingForm;

		/// <summary>
		/// Occurs when "Never expire" option is changed.
		/// </summary>
		public event EventHandler<EventArgs> NeverExpireChanged;

		/// <summary>
		/// Occurs when the form is closed.
		/// </summary>
		public event EventHandler<EventArgs> FormClose;

        /// <summary>
        /// Occurs before the form is closed.
        /// </summary>
        event FormClosingEventHandler IViewAppointmentForm.FormClosing
        {
            add { _formClosing += value; }
            remove { _formClosing -= value; }
        }

		/// <summary>
		/// Occurs when contact name is changed.
		/// </summary>
		public event EventHandler<EventArgs> ContactNameChanged;

		/// <summary>
		/// Occurs when appointment date is changed.
		/// </summary>
		public event EventHandler<EventArgs> AppointmentDateChanged;

		/// <summary>
		/// Occurs when appointment time is changed.
		/// </summary>
		public event EventHandler<EventArgs> AppointmentTimeChanged;

		/// <summary>
		/// Occurs when appointment date is changed.
		/// </summary>
		public event EventHandler<EventArgs> ExpirationDateChanged;

		/// <summary>
		/// Occurs when appointment time is changed.
		/// </summary>
		public event EventHandler<EventArgs> ExpirationTimeChanged;

		/// <summary>
		/// Occurs when "Log out" flag is changed.
		/// </summary>
		public event EventHandler<EventArgs> LogoutChanged;

        /// <summary>
        /// Occurs when user click Show Interviewer Appointmens button.
        /// </summary>
        public event EventHandler<EventArgs> ShowInterviewerAppointmens;

        /// <summary>
        /// Occurs when "Allow appointments outside of permitter shift" property is changed in appointment form.
        /// </summary>
	    public event EventHandler<EventArgs> AllowAppointmentsOutsideShiftChanged;

	    /// <summary>
		/// Appointment date.
		/// </summary>
		public DateTime AppointmentDate
		{
			get
			{
				return dtAppointmentDate.Value;
			}
			set
			{
				dtAppointmentDate.Value = value;
			}
		}

		/// <summary>
		/// Appointment time.
		/// </summary>
		public string AppointmentTime
		{
			get
			{
				return cbAppointmentTime.Text;
			}
			set
			{
				cbAppointmentTime.Text = value;
			}
		}

		/// <summary>
		/// Expiration date.
		/// </summary>
		public DateTime ExpirationDate
		{
			get
			{
				return dtExpirationDate.Value;
			}
			set
			{
				dtExpirationDate.Value = value;
			}
		}

		/// <summary>
		/// Expiration time.
		/// </summary>
		public string ExpirationTime
		{
			get
			{
				return cbExpirationTime.Text;
			}
			set
			{
				cbExpirationTime.Text = value;
			}
		}

		/// <summary>
		/// Flag indicates what appointment should or shouldn't expire.
		/// </summary>
		public bool NeverExpire
		{
			get
			{
				return chbNeverExpire.Checked;
			}
			set
			{
				chbNeverExpire.Checked = value;
			}
		}

        /// <summary>
        /// Gets or sets a value indicating whether we should check if appointment
        /// belongs to some existing shift or not.
        /// </summary>
        public bool AllowAppointmentsOutsideShifts
        {
            get
            {
                return chbAllowAppOutsideShift.Checked;
            }

            set
            {
                chbAllowAppOutsideShift.Checked = value;
            }
        }

		/// <summary>
		/// Flag indicates that we should log out after appointment creation.
		/// </summary>
		public bool Logout
		{
			get
			{
				return chbLogout.Checked;
			}
			set
			{
				chbLogout.Checked = value;
			}
		}

		/// <summary>
		/// Respondent time.
		/// </summary>
		public string RespondentTime
		{
			get
			{
				return lbRespondentTime.Text;
			}
			set
			{
				lbRespondentTime.Text = value;
			}
		}

		/// <summary>
		/// Interviewer time.
		/// </summary>
		public string InterviewerTime
		{
			get
			{
				return lbInterviewerTime.Text;
			}
			set
			{
				lbInterviewerTime.Text = value;
			}
		}

		/// <summary>
		/// Flag indicates that we should suppress event generation. By default it is false.
		/// </summary>
		public bool SuppressEvents
		{
			get;
			set;
		}

	    /// <summary>
        /// Flag indicates that we open form for edit existent appointment.  By default it is false.
        /// </summary>
        public string DialogDescription
        {
            get
            {
                return lbTitleDescription.Text;
            }
            set
            {
                lbTitleDescription.Text = value;
            }
        }       

		/// <summary>
		/// Gets/sets form result describing why user close form.
		/// </summary>
		public FormCloseReasons FormResult
		{
			get;
			set;
		}

        public bool IsVisible
        {
            get
            {
                return this.Visible;
            }
        }

        /// <summary>
        /// Notifies user about validation error of specified control.
        /// </summary>
		/// <param name="control">Validated control.</param>
		/// <param name="message">Error message. Message shouldn't be empty.</param>
		/// <remarks>If the message length is greater than zero, then the error icon is displayed, 
		/// and the ToolTip for the error icon is the error description text. 
		/// If the message length is zero, the error icon is hidden.
		/// </remarks>
		public void AlertValidationError(AppointmentValidationControls control, string message)
		{
			switch(control)
			{
				case AppointmentValidationControls.AppointmentDate:
					erpAppointmentDate.SetError(dtAppointmentDate, message);
					break;
				case AppointmentValidationControls.AppointmentTime:
					erpAppointmentTime.SetError(cbAppointmentTime, message);
					break;
				case AppointmentValidationControls.ExpirationDate:
					erpExpirationDate.SetError(dtExpirationDate, message);
					break;
				case AppointmentValidationControls.ExpirationTime:
					erpExpirationTime.SetError(cbExpirationTime, message);
					break;
				default:
					throw new NotImplementedException();
			}
		}

		/// <summary>
		/// Clears all validation errors.
		/// </summary>
		public void ClearValidationErrors()
		{
			erpAppointmentDate.SetError(dtAppointmentDate, String.Empty);
			erpAppointmentTime.SetError(cbAppointmentTime, String.Empty);
			erpExpirationDate.SetError(dtExpirationDate, String.Empty);
			erpExpirationTime.SetError(cbExpirationTime, String.Empty);
		}

		/// <summary>
		/// Enables/disables expiration date and time controls.
		/// </summary>
		/// <param name="enable">Flag indicates enable controls or disable.</param>
		public void EnableExpirationTimeControls(bool enable)
		{
			dtExpirationDate.Enabled = enable;
			cbExpirationTime.Enabled = enable;
		}

		/// <summary>
		/// Binds appointment time control with the list of predefined values.
		/// </summary>
		/// <param name="items">Predefined items.</param>
		public void BindAppointmentTimeList(string[] items)
		{
			cbAppointmentTime.Items.Clear();
			cbAppointmentTime.Items.AddRange(items);
		}

		/// <summary>
		/// Binds expiration time control with the list of predefined values.
		/// </summary>
		/// <param name="items">Predefined items.</param>
		public void BindExpirationTimeList(string[] items)
		{
			cbExpirationTime.Items.Clear();
			cbExpirationTime.Items.AddRange(items);
		}

		/// <summary>
		/// Closes from.
		/// </summary>
        public void CloseForm(DialogResult dialogResult)
		{
            DialogResult = dialogResult;
			Close();
		}

        /// <summary>
        /// Hides form.
        /// </summary>
        public void HideForm()
        {
            Hide();
        }

	    public void HideCancelButton()
	    {
	        ltButtons.Controls.Remove(btnCancel);
	        ltButtons.Controls.Remove(btnOk);
	        ltButtons.Controls.Add(btnOk, 2, 0);
	    }

	    public bool ShowAppointmentsOutsidePermittedShiftTime { get; set; }

        public bool ShowLinkToInterviewerAppointments { get; set; }

        private void HideAppointmentsOutsidePermittedShiftTimeOption()
        {
            if (!ShowAppointmentsOutsidePermittedShiftTime)
            {
                var rowHeight = 22;
                Height -= rowHeight;
                ltMain.Height -= rowHeight;
                gbEdit.Height -= rowHeight;
                ltInputFields.Height -= rowHeight;
                chbAllowAppOutsideShift.Visible = false;
                chbAllowAppOutsideShift.Height = 0;
                ltInputFields.SetRow(chbAllowAppOutsideShift, 4);
                ltInputFields.RowCount -= 1;
                ltInputFields.RowStyles.RemoveAt(5);
            }
        }

        private void HideLinkToInterviewerAppointments()
        {
            if (!ShowLinkToInterviewerAppointments)
            {
                lbShowInterviewerAppointmens.Visible = false;
            }
        }

        /// <summary>
        /// Shows modal appointment form.
        /// </summary>
        /// <param name="parent">Parent window handle.</param>
        void IViewAppointmentForm.Show(IWin32Window parent)
		{
	        if (!this.Visible)
	        {
                HideAppointmentsOutsidePermittedShiftTimeOption();
                HideLinkToInterviewerAppointments();

                ShowDialog(parent);
	        }
		}

	    /// <summary>
        /// Shows non-modal for monitoring console
        /// Closing event disabled
        /// </summary>
        /// <param name="parent"></param>
        public void ShowNonModal(IWin32Window parent)
        {
            if (!this.Visible)
            {
                HideAppointmentsOutsidePermittedShiftTimeOption();
                HideLinkToInterviewerAppointments();

                EnableInputControls(false);
                this.FormClosing += (object sender, FormClosingEventArgs e) =>
                {
                    if (e.CloseReason == CloseReason.UserClosing)
                        e.Cancel = true;
                };

                StartPosition = FormStartPosition.Manual;
                var parentForm = (Form) parent;
                Location = new Point(parentForm.Location.X + (parentForm.Width - Width) / 2, parentForm.Location.Y + (parentForm.Height - Height) / 2);
                Show(parent);                
            }
        }

        /// <summary>
        /// Enables/disables all input controls on form.
        /// </summary>
        /// <param name="enable">if true, enables controls; otherwise disables.</param>
        public void EnableInputControls(bool enable)
        {
            chbNeverExpire.Enabled = enable;
            cbAppointmentTime.Enabled = enable;
            dtAppointmentDate.Enabled = enable;
            dtExpirationDate.Enabled = enable;
            chbLogout.Enabled = enable;
            cbExpirationTime.Enabled = enable;
            chbLogout.Enabled = enable;
            btnOk.Enabled = enable;
            btnCancel.Enabled = enable;
            chbAllowAppOutsideShift.Enabled = enable;
        }

	    private void btnOk_Click(object sender, EventArgs e)
		{
			if (ValidateChildren())
			{			    
				FormResult = FormCloseReasons.Ok;

				OnOkClick(EventArgs.Empty);
			}
		}

        private void btnCancel_Click(object sender, EventArgs e)
        {
            FormResult = FormCloseReasons.Cancel;
        }

		private void tbContactName_Validating(object sender, CancelEventArgs e)
		{
			OnValidatingContactName(e);
		}

		private void AppointmentForm_HandleDestroyed(object sender, EventArgs e)
		{
            if (FormResult == FormCloseReasons.None ||
                DialogResult == DialogResult.Cancel)
			{
				FormResult = FormCloseReasons.Cancel;
			}

			OnFormClose(EventArgs.Empty);
		}

		private void chbNeverExpire_CheckedChanged(object sender, EventArgs e)
		{
			OnNeverExpiredChanged(sender, EventArgs.Empty);
		}

		private void tbContactName_TextChanged(object sender, EventArgs e)
		{
			OnContactNameChanged(sender, EventArgs.Empty);
		}

		private void dtAppointmentDate_ValueChanged(object sender, EventArgs e)
		{
			OnAppointmentDateChanged(sender, EventArgs.Empty);
		}

		private void cbAppointmentTime_TextChanged(object sender, EventArgs e)
		{
			OnAppointmentTimeChanged(sender, EventArgs.Empty);
		}

		private void dtExpirationDate_ValueChanged(object sender, EventArgs e)
		{
			OnExpirationDateChanged(sender, EventArgs.Empty);
		}

		private void cbExpirationTime_TextChanged(object sender, EventArgs e)
		{
			OnExpirationTimeChanged(sender, EventArgs.Empty);
		}

		private void chbLogout_CheckedChanged(object sender, EventArgs e)
		{
			OnLogoutChanged(sender, EventArgs.Empty);
		}

        private void chbAllowAppOutsideShift_CheckedChanged(object sender, EventArgs e)
        {
            OnAllowAppOutsideShift(sender, EventArgs.Empty);
        }

	    private void cbAppointmentTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            cbAppointmentTime.DroppedDown = false;
        }

        private void cbExpirationTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            cbExpirationTime.DroppedDown = false;
        }

        private void lbShowInterviewerAppointmens_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OnShowInterviewerAppointmens();
        }

	    /// <summary>
		/// Validates children controls.
		/// </summary>
		/// <returns></returns>
		public override bool ValidateChildren()
		{
			ClearValidationErrors();

			bool result = base.ValidateChildren();

			CancelEventArgs eaContactName = new CancelEventArgs();
			OnValidatingContactName(eaContactName);
			result &= !eaContactName.Cancel;

			CancelEventArgs eaAppointmentDate = new CancelEventArgs();
			OnValidatingAppointmentDate(eaAppointmentDate);
			result &= !eaAppointmentDate.Cancel;

			CancelEventArgs eaAppointmentTime = new CancelEventArgs();
			OnValidatingAppointmentTime(eaAppointmentTime);
			result &= !eaAppointmentTime.Cancel;

			if (!NeverExpire)
			{
				CancelEventArgs eaExpirationDate = new CancelEventArgs();
				OnValidatingExpirationDate(eaExpirationDate);
				result &= !eaExpirationDate.Cancel;

				CancelEventArgs eaExpirationTime = new CancelEventArgs();
				OnValidatingExpirationTime(eaExpirationTime);
				result &= !eaExpirationTime.Cancel;
			}

			if (result)
			{
				// we fire form validation events only if children controls are ok
				CancelEventArgs eaForm = new CancelEventArgs();
				OnValidatingForm(eaForm);
				result &= !eaForm.Cancel;
			}

			return result;
		}

		/// <summary>
		/// Initializes error providers.
		/// </summary>
		private void InitializeErrorProviders()
		{
			erpAppointmentDate.SetIconAlignment(dtAppointmentDate, ErrorIconAlignment.MiddleRight);
			erpAppointmentTime.SetIconAlignment(cbAppointmentTime, ErrorIconAlignment.MiddleRight);
			erpExpirationDate.SetIconAlignment(dtExpirationDate, ErrorIconAlignment.MiddleRight);
			erpExpirationTime.SetIconAlignment(cbExpirationTime, ErrorIconAlignment.MiddleRight);
		}

		/// <summary>
		/// Fires ValidatingContactName event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnValidatingContactName(CancelEventArgs e)
		{
			if (!SuppressEvents && ValidatingContactName != null)
			{
				ValidatingContactName(this, e);
			}
		}

		/// <summary>
		/// Fires ValidatingAppointmentDate event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnValidatingAppointmentDate(CancelEventArgs e)
		{
			if (!SuppressEvents && ValidatingAppointmentDate != null)
			{
				ValidatingAppointmentDate(this, e);
			}
		}

		/// <summary>
		/// Fires ValidatingAppointmentTime event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnValidatingAppointmentTime(CancelEventArgs e)
		{
			if (!SuppressEvents && ValidatingAppointmentTime != null)
			{
				ValidatingAppointmentTime(this, e);
			}
		}

		/// <summary>
		/// Fires ValidatingExpirationTime event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnValidatingExpirationTime(CancelEventArgs e)
		{
			if (!SuppressEvents && ValidatingExpirationTime != null)
			{
				ValidatingExpirationTime(this, e);
			}
		}

		/// <summary>
		/// Fires ValidatingExpirationDate event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnValidatingExpirationDate(CancelEventArgs e)
		{
			if (!SuppressEvents && ValidatingExpirationDate != null)
			{
				ValidatingExpirationDate(this, e);
			}
		}

		/// <summary>
		/// Fires ValidatingForm event.
		/// </summary>
		/// <param name="e">Eveny arguments.</param>
		private void OnValidatingForm(CancelEventArgs e)
		{
			if (!SuppressEvents && ValidatingForm != null)
			{
				ValidatingForm(this, e);
			}
		}

		/// <summary>
		/// Fires NaverExpiredChanged event.
		/// </summary>
		/// <param name="sender">Object which sent event. For this event
		/// we pass real control which produced event, not reference
		/// to AppointmentForm control.</param>
		/// <param name="e">Event arguments.</param>
		private void OnNeverExpiredChanged(object sender, EventArgs e)
		{
			if (!SuppressEvents && NeverExpireChanged != null)
			{
				NeverExpireChanged(sender, e);
			}
		}

		/// <summary>
		/// Fires FormClose event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnFormClose(EventArgs e)
		{
			if (!SuppressEvents && FormClose != null)
			{
				FormClose(this, e);
			}
		}

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (SuppressEvents) return;

            base.OnFormClosing(e);

            if (_formClosing != null)
            {
                _formClosing(this, e);
            }
        }

		/// <summary>
		/// Fires OkClick event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnOkClick(EventArgs e)
		{
			if (!SuppressEvents && OkClick != null)
			{
				OkClick(this, e);
			}
		}

		/// <summary>
		/// Fires RemoveClick event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnRemoveClick(EventArgs e)
		{
			if (!SuppressEvents && RemoveClick != null)
			{
				RemoveClick(this, e);
			}
		}

		/// <summary>
		/// Fires ContactNameChanged event.
		/// </summary>
		/// <param name="sender">Object which sent event. For this event
		/// we pass real control which produced event, not reference
		/// to AppointmentForm control.</param>
		/// <param name="e">Event arguments.</param>
		private void OnContactNameChanged(object sender, EventArgs e)
		{
			if (!SuppressEvents && ContactNameChanged != null)
			{
				ContactNameChanged(sender, e);
			}
		}

		/// <summary>
		/// Fires AppointmentDateChanged event.
		/// </summary>
		/// <param name="sender">Object which sent event. For this event
		/// we pass real control which produced event, not reference
		/// to AppointmentForm control.</param>
		/// <param name="e">Event arguments.</param>
		private void OnAppointmentDateChanged(object sender, EventArgs e)
		{
			if (!SuppressEvents && AppointmentDateChanged != null)
			{
				AppointmentDateChanged(sender, e);
			}
		}

		/// <summary>
		/// Fires AppointmentTimeChanged event.
		/// </summary>
		/// <param name="sender">Object which sent event. For this event
		/// we pass real control which produced event, not reference
		/// to AppointmentForm control.</param>
		/// <param name="e">Event arguments.</param>
		private void OnAppointmentTimeChanged(object sender, EventArgs e)
		{
			if (!SuppressEvents && AppointmentTimeChanged != null)
			{
				AppointmentTimeChanged(sender, e);
			}
		}

		/// <summary>
		/// Fires ExpirationDateChanged event.
		/// </summary>
		/// <param name="sender">Object which sent event. For this event
		/// we pass real control which produced event, not reference
		/// to AppointmentForm control.</param>
		/// <param name="e">Event arguments.</param>
		private void OnExpirationDateChanged(object sender, EventArgs e)
		{
			if (!SuppressEvents && ExpirationDateChanged != null)
			{
				ExpirationDateChanged(sender, e);
			}
		}

		/// <summary>
		/// Fires ExpirationTimeChanged event.
		/// </summary>
		/// <param name="sender">Object which sent event. For this event
		/// we pass real control which produced event, not reference
		/// to AppointmentForm control.</param>
		/// <param name="e">Event arguments.</param>
		private void OnExpirationTimeChanged(object sender, EventArgs e)
		{
			if (!SuppressEvents && ExpirationTimeChanged != null)
			{
				ExpirationTimeChanged(sender, e);
			}
		}

		/// <summary>
		/// Fires LogoutChanged event.
		/// </summary>
		/// <param name="sender">Object which sent event. For this event
		/// we pass real control which produced event, not reference
		/// to AppointmentForm control.</param>
		/// <param name="e">Event arguments.</param>
		private void OnLogoutChanged(object sender, EventArgs e)
		{
			if (!SuppressEvents && LogoutChanged != null)
			{
				LogoutChanged(sender, e);
			}
		}

        private void OnAllowAppOutsideShift(object sender, EventArgs e)
        {
            if (!SuppressEvents && LogoutChanged != null)
            {
                AllowAppointmentsOutsideShiftChanged(sender, e);
            }
        }

        private void OnShowInterviewerAppointmens()
        {
            if (ShowInterviewerAppointmens != null)
            {
                ShowInterviewerAppointmens(this, EventArgs.Empty);
            }
        }

	    public SynchronizationContext SynchronizationContext
        {
            get { return m_SynchronizationContext; }
        }
    }
}
