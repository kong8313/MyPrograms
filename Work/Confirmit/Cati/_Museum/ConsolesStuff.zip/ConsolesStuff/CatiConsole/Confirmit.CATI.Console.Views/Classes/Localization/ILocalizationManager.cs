﻿using System;
using System.Globalization;

namespace Confirmit.CATI.Console.Views.Classes.Localization
{
	/// <summary>
	/// Represents interface which manages application current culture and
	/// resources.
	/// </summary>
	public interface ILocalizationManager
	{
		#region Properties

		/// <summary>
		/// Gets/sets the current application culture. 
		/// </summary>
		CultureInfo CurrentCulture
		{ 
			get; 
			set;
		}

		#endregion

		#region Events

		/// <summary>
		/// Occurs when application culture is changed.
		/// </summary>
		event EventHandler<EventArgs> CurrentCultureChanged;

		#endregion

		#region Methods

		/// <summary>
		/// Returns the value of the specified String resource.
		/// </summary>
		/// <param name="name">The name of the resource to get.</param>
		/// <returns>The value of the resource localized for the caller's current culture settings. 
		/// If a match is not possible, null is returned.
		/// </returns>
		string GetString(string name);

		/// <summary>
		/// Returns the value of the specified String resource formated with specified
		/// arguments.
		/// </summary>
		/// <param name="name">The name of the resource to get.</param>
		/// <param name="args">An Object array containing zero or more objects to format.</param>
		/// <returns>The value of the resource localized for the caller's current culture settings. 
		/// If a match is not possible, null is returned.
		/// </returns>
		string GetString(string name, object[] args);

		#endregion
	}
}
