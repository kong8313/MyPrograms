﻿using System;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
    /// <summary>
    /// Represents Interface for MessagingForm
    /// </summary>
    public interface IViewMessagingForm : ILocalizableView, IDisposable
    {
        /// Occurs when button Ok is clicked.
        event EventHandler<EventArgs> OkClick;

        /// <summary>
        /// Occurs when form is closed.
        /// </summary>
        event EventHandler<EventArgs> FormClose;

        /// <summary>
        /// Occurs when user clicks notification icon
        /// </summary>
        event EventHandler<EventArgs> NotificationClick;

        /// <summary>
        /// Returns true if form is visible for user
        /// othewise return false
        /// </summary>
        bool IsFormVisible { get; }

        /// <summary>
        /// Adds messages to list
        /// </summary>
        /// <param name="messages"></param>
        void AddMessage(string author, string time, string body);

        /// <summary>
        /// Shows modal messaging form.
        /// </summary>
        /// <param name="parent">Parent window handle.</param>
        void Show(IWin32Window parent);

        /// <summary>
        /// Shows notification in task bar
        /// </summary>
        void ShowNotification(string ballonMessage);

        /// <summary>
        /// Hides notification in task bar
        /// </summary>
        void HideNotification();

        /// <summary>
        /// Closes from.
        /// </summary>
        void CloseForm();

        /// <summary>
        /// Adds text into message list
        /// </summary>
        void AddText(string text);

        /// <summary>
        /// Clears message list
        /// </summary>
        void Clear();

    }
}
