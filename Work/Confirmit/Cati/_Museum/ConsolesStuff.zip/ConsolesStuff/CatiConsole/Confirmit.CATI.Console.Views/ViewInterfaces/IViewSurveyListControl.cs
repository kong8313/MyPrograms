﻿using System;
using System.Drawing;
using System.Data;
using System.Collections.Generic;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Views.Classes.SearchableGrid;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Views.ViewInterfaces
{
	/// <summary>
	/// Represents view interface for SurveyListControl control.
	/// </summary>
	public interface IViewSurveyListControl : ILocalizableView
	{
		/// <summary>
		/// Occurs when survey selected index is changed.
		/// </summary>
		event EventHandler<EventArgs> SurveySelectionChanged;		

		/// <summary>
		/// Occurs when survey is selected for interviewing.
		/// </summary>
		event EventHandler<EventArgs> SurveySelected;

		/// <summary>
		/// Occurs when interview is selected for interviewing.
		/// </summary>
		event EventHandler<EventArgs> InterviewSelected;

	    /// <summary>
	    /// Occurs when a user try to create a new interview.
	    /// </summary>
	    event EventHandler<EventArgs> CreateInterview;
        
        /// <summary>
        /// Occurs when splitter control is moved.
        /// </summary>
        event EventHandler<EventArgs> SplitterMoved;

        /// <summary>
        /// Occurs when control is resized.
        /// </summary>
        event EventHandler<EventArgs> FormResize;

        /// <summary>
        /// Occurs when user invoke interviews searching.
        /// </summary>
        event EventHandler<EventArgs> FilterInterviews;

        /// <summary>
        /// Occurs when user invoke reset interviews searching filters.
        /// </summary>
	    event EventHandler<EventArgs> ResetAllFilters;
        
        /// <summary>
        /// Occurs when user click header column for sort list.
        /// </summary> 
        event EventHandler<ColumnSortModeChangedEventArgs> ColumnSortModeChanged;

		/// <summary>
		/// Gets/sets the index of selected survey.
		/// </summary>
		int SelectedSurvey { get; set; }

		/// <summary>
		/// Gets/sets the index of selected interview.
		/// </summary>
		int SelectedInterview { get; }               

        /// <summary>
        /// Gets client size of survey list.
        /// </summary>
        Size SurveyListClientSize { get; }

        /// <summary>
        /// Gets search parameters.
        /// </summary>
        List<ConsoleSearchParameter> SearchParameters { get; }

        /// <summary>
        /// Gets a value indicating whether the items in the SurveyListControl control 
        /// are sorted in ascending or descending order, or are not sorted.
        /// </summary>
        SortOrder SortOrder { get; }

        /// <summary>
        /// Gets sorted column index. If there is no sorted column, returns -1.
        /// </summary>
        int SortedColumnIndex { get; }

		/// <summary>
		/// Enables/disables interview list.
		/// </summary>
		/// <param name="enable">If is true, then enables interview list;
		/// otherwise disables.</param>
		void EnableInterviewList(bool enable);

		/// <summary>
		/// Binds survey list.
		/// </summary>
		/// <param name="surveys">Surveys collection.</param>
		void BindSurveyList(string[] surveys);

        /// <summary>
        /// Binds interview list.
        /// </summary>
        /// <param name="table">DataTable with interviews.</param>
        /// <param name="fullRebuild">If true, data and schema will be changed; otherwise data will be updated.</param>
        /// <param name="bindHeader">If true header will be rebuid even fullRebuid is false. Search data will be remain.</param>
        void BindInterviewList(DataTable table, bool fullRebuild, bool bindHeader);

	    /// <summary>
	    /// Binds search parameters.
	    /// </summary>
	    /// <param name="parameters">Parameters collection.</param>
        void BindSearchParameters(IEnumerable<ConsoleSearchParameter> parameters);

        /// <summary>
		/// Show message into interview list.
		/// </summary>
		/// <param name="message">message for display</param>
        void ShowMessageInterviewList(string message);

        /// <summary>
        /// Show message into survey list.
        /// </summary>
        /// <param name="message">message for display</param>
        void ShowMessageSurveyList(string message);

        /// <summary>
        /// Sets width of "Survey name" column in survey list.
        /// </summary>
        /// <param name="width"></param>
        void SetSurveyColumnWidth(int width);

        /// <summary>
        /// Activate filter edit control for specified column.
        /// </summary>
        /// <param name="columnName">Name of column with incorrect filter value.</param>
        void ActivateColumnFilter(string columnName);

        /// <summary>
        /// Enabled ot disable CreateNew button
        /// </summary>
        /// <param name="enabled">true or false</param>
	    void EnableCreateNewButton(bool enabled);
    }
}
