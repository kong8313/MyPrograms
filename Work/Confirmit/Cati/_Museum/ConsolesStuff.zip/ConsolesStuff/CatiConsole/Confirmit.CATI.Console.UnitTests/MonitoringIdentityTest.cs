﻿using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Console.Services.MonitoringService;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    /// <summary>
    /// Summary description for MonitoringIdentityTest
    /// </summary>
    [TestClass]
    public class MonitoringIdentityTest
    {
        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_Null_ReturnsFalse()
        {
            var test = new MonitoringIdentity();
            Assert.IsFalse(test.Equals(null));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_DifferentMonitoringSessionID_ReturnsFalse()
        {
            var test1 = new MonitoringIdentity();
            var test2 = new MonitoringIdentity { MonitoringSessionId = 100 };
            Assert.IsFalse(test1.Equals(test2));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_DifferentDeferredSessionID_ReturnsFalse()
        {
            var test1 = new MonitoringIdentity { DeferredIdentity = new DeferredIdentity { SurveyId = 2 } };
            var test2 = new MonitoringIdentity { DeferredIdentity = new DeferredIdentity { SurveyId = 1 } };
            Assert.IsFalse(test1.Equals(test2));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_NullDeferredSessionIDNotNullDeferredSessionID_ReturnsFalse()
        {
            var test1 = new MonitoringIdentity();
            var test2 = new MonitoringIdentity { DeferredIdentity = new DeferredIdentity() };

            Assert.IsFalse(test1.Equals(test2));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_NotNullDeferredSessionIDNullDeferredSessionID_ReturnsFalse()
        {
            var test1 = new MonitoringIdentity { DeferredIdentity = new DeferredIdentity() };
            var test2 = new MonitoringIdentity();

            Assert.IsFalse(test1.Equals(test2));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_EqualIdentity_ReturnsTrue()
        {
            var test1 = new MonitoringIdentity
            {
                MonitoringSessionId = 1,
                DeferredIdentity = new DeferredIdentity { SurveyId = 1 }
            };

            var test2 = new MonitoringIdentity
            {
                MonitoringSessionId = 1,
                DeferredIdentity = new DeferredIdentity { SurveyId = 1 }
            };

            Assert.IsTrue(test1.Equals(test2));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_EqualIdentityNullDeferredSessionID_ReturnsTrue()
        {
            var test1 = new MonitoringIdentity { MonitoringSessionId = 100 };
            var test2 = new MonitoringIdentity { MonitoringSessionId = 100 };
            Assert.IsTrue(test1.Equals(test2));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_SameIdentity_ReturnsTrue()
        {
            var test1 = new MonitoringIdentity
            {
                MonitoringSessionId = 1,
                DeferredIdentity = new DeferredIdentity { SurveyId = 1 }
            };

            Assert.IsTrue(test1.Equals(test1));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Clone_NotNullDeferredSessionID_ReturnsClonedObject()
        {
            var test1 = new MonitoringIdentity
            {
                MonitoringSessionId = 1,
                DeferredIdentity = new DeferredIdentity { SurveyId = 1, DeferredRecordId = 2, InterviewId = 3}
            };

            var test2 = test1.Clone();

            Assert.IsTrue(test1.Equals(test2) && !ReferenceEquals(test1, test2));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Clone_NullDeferredSessionID_ReturnsClonedObject()
        {
            var test1 = new MonitoringIdentity { MonitoringSessionId = 123};
            var test2 = test1.Clone();

            Assert.IsTrue(test1.Equals(test2) && !ReferenceEquals(test1, test2));
        }
    }
}
