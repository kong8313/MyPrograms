﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Console.Classes.Sender;
using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Services.CatiService.Fakes;
using Confirmit.CATI.Console.Services.MonitoringService;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.Monitoring.Common.StateData;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class EventSenderTest
    {
        private StubICatiServiceHelper _stubICatiServiceHelper;
        private EventSender _eventSender;
        private MonitoringIdentity _monitoringIdentity;
        private DateTime _firstEventUtc;
        private bool _hasFinishedMessage;
        private MonitoringIdentity _identityFromQueue;
        private DateTime _firstEventFromQueueUtc;
        private Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity> _startEvent;
        private Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity> _initialEvent;
        private List<StateEventInfo> _eventListForDeferredMonitoring;

        [TestInitialize]
        public void Initialize()
        {
            var registrator = InitServiceLocator();
            _stubICatiServiceHelper = new StubICatiServiceHelper();
            registrator.RegisterInstance<ICatiServiceHelper>(_stubICatiServiceHelper);

            PrepareEventSender();
        }

        private void PrepareEventSender()
        {
            _eventSender = new EventSender();
            var stateChangedEventArgsStart = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewStartMessage,
                State = null
            };
            var stateChangedEventArgsInitial = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewInitialMessage,
                State = new InterviewingInitialStateData()
            };
            _identityFromQueue = new MonitoringIdentity {DeferredIdentity = new DeferredIdentity {DeferredRecordId = 1}};

            _firstEventFromQueueUtc = new DateTime(1, 1, 1, 1, 1, 1);
            _startEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(_firstEventFromQueueUtc,
                stateChangedEventArgsStart, _identityFromQueue);
            _eventSender.Enqueue(_startEvent);

            var dateTime2 = new DateTime(1, 1, 1, 1, 1, 2);
            _initialEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(dateTime2, stateChangedEventArgsInitial, _identityFromQueue);
            _eventSender.Enqueue(_initialEvent);

            _monitoringIdentity = null;
            _eventListForDeferredMonitoring = new List<StateEventInfo>();
            _firstEventUtc = DateTime.MaxValue;
            _hasFinishedMessage = false;
        }

        [TestCleanup]
        public void Cleanup()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Cleanup();
            AsyncOperationInvoker.Instance.ClearResources();
        }

        private IServiceRegistrator InitServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            var registrator = (IServiceRegistrator)serviceLocator;
            return registrator;
        }

        [TestMethod]
        public void GetEventsToSend_NoConsentForScreenRecording_ReturnsEmptyArrayForDeferredMonitoring()
        {
            // set consent for survey
            _stubICatiServiceHelper.IsInterviewScreenRecordingEnabledInt32 = (sid) => false;
            
            // get actual events from EventSender
            var actualLiveEvents = _eventSender.GetEventsToSend(ref _firstEventUtc, ref _eventListForDeferredMonitoring, ref _hasFinishedMessage, ref _monitoringIdentity);

            // get expected events
            var stateEventInfo1 = _eventSender.GetStateEventInfo(_startEvent);
            var stateEventInfo2 = _eventSender.GetStateEventInfo(_initialEvent);
            var expectedLiveEvents = new List<StateEventInfo> {stateEventInfo1, stateEventInfo2};

            Assert.AreEqual(0, _eventListForDeferredMonitoring.Count);
            Assert.AreEqual(_firstEventFromQueueUtc, _firstEventUtc);
            Assert.AreEqual(false, _hasFinishedMessage);
            Assert.AreEqual(_identityFromQueue, _monitoringIdentity);
            CompareEvents(expectedLiveEvents, actualLiveEvents);
        }

        [TestMethod]
        public void GetEventsToSend_IsConsentForScreenRecordingForSurveyNoConsentForScreenRecordingForInterview_ReturnsArrayForDeferredMonitoringTheSameAsForLive()
        {
            // set consent for survey
            _stubICatiServiceHelper.IsInterviewScreenRecordingEnabledInt32 = (sid) => true;

            // get actual events from EventSender
            var actualLiveEvents = _eventSender.GetEventsToSend(ref _firstEventUtc, ref _eventListForDeferredMonitoring, ref _hasFinishedMessage, ref _monitoringIdentity);

            // get expected events
            var stateEventInfo1 = _eventSender.GetStateEventInfo(_startEvent);
            var stateEventInfo2 = _eventSender.GetStateEventInfo(_initialEvent);
            var expectedLiveEvents = new List<StateEventInfo> { stateEventInfo1, stateEventInfo2 };

            Assert.AreEqual(expectedLiveEvents.Count, actualLiveEvents.Count);
            Assert.AreEqual(expectedLiveEvents.Count, _eventListForDeferredMonitoring.Count);
            CompareEvents(expectedLiveEvents, actualLiveEvents);
            CompareEvents(expectedLiveEvents, _eventListForDeferredMonitoring);
        }

        [TestMethod]
        public void GetEventsToSend_IsConsentForScreenRecordingForInterviewNoConsentForSurvey_ReturnsArrayForDeferredMonitoringWithSpecialStartAndInitialMessages()
        {
            // set consent for survey
            _stubICatiServiceHelper.IsInterviewScreenRecordingEnabledInt32 = (sid) => false;

            var stateChangedEventArgsFirstAnswer = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserAnswerValueChangedMessage,
                State = new AnswerEnteredStateData { ElementId = "1"}
            };
            var firstAnswerEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 3), stateChangedEventArgsFirstAnswer, _identityFromQueue);
            _eventSender.Enqueue(firstAnswerEvent);

            var stateChangedEventArgsMessageComplete = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage,
                State = new DocumentCompletedStateData
                {
                    PageContent = "PageContent"
                },
                IsScreenRecordingEnabled = true
            };
            var pageCompletedEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 4), stateChangedEventArgsMessageComplete, _identityFromQueue);
            _eventSender.Enqueue(pageCompletedEvent);

            var stateChangedEventArgsSecondAnswer = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserAnswerValueChangedMessage,
                State = new AnswerEnteredStateData { ElementId = "2"}
            };
            var secondAnswerEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 5), stateChangedEventArgsSecondAnswer, _identityFromQueue);
            _eventSender.Enqueue(secondAnswerEvent);

            // get actual events from EventSender
            var actualLiveEvents = _eventSender.GetEventsToSend(ref _firstEventUtc, ref _eventListForDeferredMonitoring, ref _hasFinishedMessage, ref _monitoringIdentity);

            // get expected events
            var newStartEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 3), _startEvent.Second, _startEvent.Third);
            var stateEventInfo1 = _eventSender.GetStateEventInfo(newStartEvent);
            var state = (InterviewingInitialStateData) _initialEvent.Second.State;
            state.PageContent = ((DocumentCompletedStateData) stateChangedEventArgsMessageComplete.State).PageContent;
            var newInitialEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 3), _initialEvent.Second, _initialEvent.Third) {Second = {State = state}};
            var stateEventInfo2 = _eventSender.GetStateEventInfo(newInitialEvent);
            var stateEventInfo3 = _eventSender.GetStateEventInfo(secondAnswerEvent);
            var expectedDeferredEvents = new List<StateEventInfo> { stateEventInfo1, stateEventInfo2, stateEventInfo3 };

            Assert.AreEqual(expectedDeferredEvents.Count, _eventListForDeferredMonitoring.Count);
            Assert.AreNotEqual(expectedDeferredEvents.Count, actualLiveEvents.Count);
            CompareEvents(expectedDeferredEvents, _eventListForDeferredMonitoring);
        }

        [TestMethod]
        public void GetEventsToSend_SeveralConsentsForScreenRecordingForInterviewNoConsentForSurvey_ReturnsEventsForDeferredMonitoringStartingFromFirstConsent()
        {
            // set consent for survey
            _stubICatiServiceHelper.IsInterviewScreenRecordingEnabledInt32 = (sid) => false;

            // add more events to queue, including 2 events with consent for screen recording for interview
            var stateChangedEventArgsFirstAnswer = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserAnswerValueChangedMessage,
                State = new AnswerEnteredStateData { ElementId = "1" }
            };
            var firstAnswerEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 3), stateChangedEventArgsFirstAnswer, _identityFromQueue);
            _eventSender.Enqueue(firstAnswerEvent);

            var stateChangedEventArgsMessageComplete = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage,
                State = new DocumentCompletedStateData
                {
                    PageContent = "PageContent"
                },
                IsScreenRecordingEnabled = true
            };
            var pageCompletedEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 4), stateChangedEventArgsMessageComplete, _identityFromQueue);
            _eventSender.Enqueue(pageCompletedEvent);

            var stateChangedEventArgsSecondAnswer = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserAnswerValueChangedMessage,
                State = new AnswerEnteredStateData { ElementId = "2" }
            };
            var secondAnswerEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 5), stateChangedEventArgsSecondAnswer, _identityFromQueue);
            _eventSender.Enqueue(secondAnswerEvent);

            var stateChangedEventArgsMessageComplete2 = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage,
                State = new DocumentCompletedStateData
                {
                    PageContent = "PageContent2"
                },
                IsScreenRecordingEnabled = true
            };
            var pageCompletedEvent2 = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 6), stateChangedEventArgsMessageComplete2, _identityFromQueue);
            _eventSender.Enqueue(pageCompletedEvent2);

            var stateChangedEventArgsThirdAnswer = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserAnswerValueChangedMessage,
                State = new AnswerEnteredStateData { ElementId = "3" }
            };
            var thirdAnswerEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 7), stateChangedEventArgsThirdAnswer, _identityFromQueue);
            _eventSender.Enqueue(thirdAnswerEvent);

            // get actual events from EventSender
            var actualLiveEvents = _eventSender.GetEventsToSend(ref _firstEventUtc, ref _eventListForDeferredMonitoring, ref _hasFinishedMessage, ref _monitoringIdentity);

            // get expected events
            var newStartEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 3), _startEvent.Second, _startEvent.Third);
            var stateEventInfo1 = _eventSender.GetStateEventInfo(newStartEvent);
            var state = (InterviewingInitialStateData)_initialEvent.Second.State;
            state.PageContent = ((DocumentCompletedStateData)stateChangedEventArgsMessageComplete.State).PageContent;
            var newInitialEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 3), _initialEvent.Second, _initialEvent.Third)
                { Second = { State = state } };
            var stateEventInfo2 = _eventSender.GetStateEventInfo(newInitialEvent);
            var stateEventInfo3 = _eventSender.GetStateEventInfo(secondAnswerEvent);
            var stateEventInfo4 = _eventSender.GetStateEventInfo(pageCompletedEvent2);
            var stateEventInfo5 = _eventSender.GetStateEventInfo(thirdAnswerEvent);
            var expectedDeferredEvents = new List<StateEventInfo> { stateEventInfo1, stateEventInfo2, stateEventInfo3, stateEventInfo4, stateEventInfo5 };

            Assert.AreEqual(expectedDeferredEvents.Count, _eventListForDeferredMonitoring.Count);
            Assert.AreNotEqual(expectedDeferredEvents.Count, actualLiveEvents.Count);
            CompareEvents(expectedDeferredEvents, _eventListForDeferredMonitoring);
        }

        [TestMethod]
        public void GetEventsToSend_IsConsentForScreenRecordingForInterviewIsConsentForSurvey_ReturnsArrayForDeferredMonitoringTheSameAsArrayForLiveMonitoring()
        {
            // set consent for survey
            _stubICatiServiceHelper.IsInterviewScreenRecordingEnabledInt32 = (sid) => true;

            // add more events to queue, including event with consent for screen recording for interview
            var stateChangedEventArgsFirstAnswer = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserAnswerValueChangedMessage,
                State = new AnswerEnteredStateData { ElementId = "1" }
            };
            var firstAnswerEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 3), stateChangedEventArgsFirstAnswer, _identityFromQueue);
            _eventSender.Enqueue(firstAnswerEvent);

            var stateChangedEventArgsMessageComplete = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage,
                State = new DocumentCompletedStateData
                {
                    PageContent = "PageContent"
                },
                IsScreenRecordingEnabled = true
            };
            var pageCompletedEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 4), stateChangedEventArgsMessageComplete, _identityFromQueue);
            _eventSender.Enqueue(pageCompletedEvent);

            var stateChangedEventArgsSecondAnswer = new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserAnswerValueChangedMessage,
                State = new AnswerEnteredStateData { ElementId = "2" }
            };
            var secondAnswerEvent = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(
                new DateTime(1, 1, 1, 1, 1, 5), stateChangedEventArgsSecondAnswer, _identityFromQueue);
            _eventSender.Enqueue(secondAnswerEvent);

            // get actual events from EventSender
            var actualLiveEvents = _eventSender.GetEventsToSend(ref _firstEventUtc, ref _eventListForDeferredMonitoring, ref _hasFinishedMessage, ref _monitoringIdentity);

            // get expected events
            var stateEventInfo1 = _eventSender.GetStateEventInfo(_startEvent);
            var stateEventInfo2 = _eventSender.GetStateEventInfo(_initialEvent);
            var stateEventInfo3 = _eventSender.GetStateEventInfo(firstAnswerEvent);
            var stateEventInfo4 = _eventSender.GetStateEventInfo(pageCompletedEvent);
            var stateEventInfo5 = _eventSender.GetStateEventInfo(secondAnswerEvent);
            var expectedDeferredEvents = new List<StateEventInfo> { stateEventInfo1, stateEventInfo2, stateEventInfo3, stateEventInfo4, stateEventInfo5 };

            Assert.AreEqual(expectedDeferredEvents.Count, _eventListForDeferredMonitoring.Count);
            Assert.AreEqual(expectedDeferredEvents.Count, actualLiveEvents.Count);
            CompareEvents(expectedDeferredEvents, _eventListForDeferredMonitoring);
            CompareEvents(actualLiveEvents, _eventListForDeferredMonitoring);
        }

        private void CompareEvents(IReadOnlyList<StateEventInfo> expectedEvents, IReadOnlyList<StateEventInfo> actualEvents)
        {
            for (var i = 0; i < expectedEvents.Count; i++)
            {
                Assert.AreEqual(expectedEvents[i].TimeStamp.ToString(CultureInfo.InvariantCulture),
                    actualEvents[i].TimeStamp.ToString(CultureInfo.InvariantCulture));
                Assert.AreEqual(expectedEvents[i].MessageType, actualEvents[i].MessageType);
                Assert.AreEqual(expectedEvents[i].State.Length, actualEvents[i].State.Length);
            }
        }
    }
}
