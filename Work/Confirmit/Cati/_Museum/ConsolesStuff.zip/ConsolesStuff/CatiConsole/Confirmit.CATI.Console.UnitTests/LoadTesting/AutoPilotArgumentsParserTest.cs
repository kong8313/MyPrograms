﻿using System;
using System.Globalization;
using Confirmit.CATI.Console.Classes.LoadTesting;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Resources;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests.LoadTesting
{
    [TestClass]
    public class AutoPilotArgumentsParserTest
    {
        [TestMethod, Owner(@"FIRM\DenisM")]
        public void AutoPilotArgumentsParser_PassCorrectArgs_Success()
        {
            var args = new[]
            {
                "UserName=test1", "Password=1", "MinDelay=500", "MaxDelay=700", @"FileName=p0000001.txt",
                "TimesToRepeat=2", "StationId=asd123", "Company=Confirmit", "ExtensionNumber=123"
            };

            var arguments =
                new AutoPilotArgumentsParser(new StubIAutopilotFileNameValidator()).ParseArguments(args);
            Assert.AreEqual("test1", arguments.UserName);
            Assert.AreEqual("1", arguments.Password);
            Assert.AreEqual(500, arguments.MinDelay);
            Assert.AreEqual(700, arguments.MaxDelay);
            Assert.AreEqual("p0000001.txt", arguments.FileName);
            Assert.AreEqual(2, arguments.TimesToRepeat);
            Assert.AreEqual("asd123", arguments.StationId);
            Assert.AreEqual("Confirmit", arguments.Company);
            Assert.AreEqual(new CultureInfo("en-US"), arguments.Locale);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void AutoPilotArgumentsParser_NotPassTimesToRepeat_Success()
        {
            var args = new[]
            {
                "UserName=test1", "Password=1", "MinDelay=500", "MaxDelay=700", @"FileName=p0000001.txt",
                "StationId=asd123", "Company=Confirmit", "ExtensionNumber=123"
            };

            var arguments =
                new AutoPilotArgumentsParser(new StubIAutopilotFileNameValidator()).ParseArguments(args);

            Assert.AreEqual(1, arguments.TimesToRepeat);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void AutoPilotArgumentsParser_PassZeroTimesToRepeat_Success()
        {
            var args = new[]
            {
                "UserName=test1", "Password=1", "MinDelay=500", "MaxDelay=700", @"FileName=p0000001.txt",
                "TimesToRepeat=0", "StationId=asd123", "Company=Confirmit", "ExtensionNumber=123"
            };

            var arguments =
                new AutoPilotArgumentsParser(new StubIAutopilotFileNameValidator()).ParseArguments(args);

            Assert.AreEqual(1, arguments.TimesToRepeat);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void AutoPilotArgumentsParser_PassNegativeTimesToRepeat_Success()
        {
            var args = new[]
            {
                "UserName=test1", "Password=1", "MinDelay=500", "MaxDelay=700", @"FileName=p0000001.txt",
                "TimesToRepeat=-2", "StationId=asd123", "Company=Confirmit", "ExtensionNumber=123"
            };

            var arguments =
                new AutoPilotArgumentsParser(new StubIAutopilotFileNameValidator()).ParseArguments(args);

            Assert.AreEqual(1, arguments.TimesToRepeat);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void AutoPilotArgumentsParser_PassBadStationId_FailWithMessage()
        {
            var args = new[]
            {
                "UserName=test1", "Password=1", "MinDelay=500", "MaxDelay=700", @"FileName=p0000001.txt",
                "TimesToRepeat=2", "StationId=123", "Company=Confirmit", "ExtensionNumber=123"
            };

            var message = string.Empty;
            try
            {
                new AutoPilotArgumentsParser(new StubIAutopilotFileNameValidator()).ParseArguments(args);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is AutopilotArgumentException);
                message = ex.Message;
            }

            Assert.AreEqual(LocalizationManager.Instance.GetString("Error_InvalidStationNumber"), message);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void AutoPilotArgumentsParser_PassLessArgs_FailWithMessage()
        {
            var args = new[]
            {
                "UserName=test1", "MinDelay=500", "MaxDelay=700", "FileName=p0000001.txt",
                "TimesToRepeat=2", "StationId=asd123", "Company=Confirmit", "ExtensionNumber=123"
            };

            var message = string.Empty;
            try
            {
                new AutoPilotArgumentsParser(new StubIAutopilotFileNameValidator()).ParseArguments(args);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is AutopilotArgumentException);
                message = ex.Message;
            }

            Assert.AreEqual(Strings.Autopilot_NotAllArgumentsSupplied_Error, message);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void AutoPilotArgumentsParser_PassMinDelayGreaterThanMaxDelay_FailWithMessage()
        {
            
            
            var args = new[]
            {
                "UserName=test1", "Password=1", "MinDelay=900", "MaxDelay=700", "FileName=p0000001.txt",
                "TimesToRepeat=2", "StationId=asd123", "Company=Confirmit", "ExtensionNumber=123"
            };

            var message = string.Empty;
            try
            {
                new AutoPilotArgumentsParser(new StubIAutopilotFileNameValidator()).ParseArguments(args);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is AutopilotArgumentException);
                message = ex.Message;
            }

            Assert.AreEqual(Strings.Autopilot_MinDelay_Error, message);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void AutoPilotArgumentsParser_PassNonExistingFileName_FailWithMessage()
        {
            var args = new[]
            {
                "UserName=test1", "Password=1", "MinDelay=100", "MaxDelay=700", "FileName=p0000009.txt",
                "TimesToRepeat=2", "StationId=asd123", "Company=Confirmit", "ExtensionNumber=123"
            };

            var message = string.Empty;
            try
            {
                var parser = new AutoPilotArgumentsParser(new StubIAutopilotFileNameValidator()
                {
                    ValidateFileNameAction = obj =>
                    {
                        throw new AutopilotArgumentException(string.Format(Strings.Autopilot_FileNotExists_Error,
                            obj));
                    }
                });
                parser.ParseArguments(args);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is AutopilotArgumentException);
                message = ex.Message;
            }

            Assert.AreEqual(string.Format(Strings.Autopilot_FileNotExists_Error, "p0000009.txt"), message);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void AutoPilotArgumentsParser_PassNegativeMinDelay_FailWithMessage()
        {
            var args = new[]
            {
                "UserName=test1", "Password=1", "MinDelay=-500", "MaxDelay=700", "FileName=p0000009.txt",
                "TimesToRepeat=2", "StationId=asd123", "Company=Confirmit", "ExtensionNumber=123"
            };

            var message = string.Empty;
            try
            {
                new AutoPilotArgumentsParser(new StubIAutopilotFileNameValidator()).ParseArguments(args);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is AutopilotArgumentException);
                message = ex.Message;
            }

            Assert.AreEqual(string.Format(Strings.Autopilot_SuppliedValueNotValidInteger_Error, "-500", "MinDelay"),
                message);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void AutoPilotArgumentsParser_PassNegativeMaxDelay_FailWithMessage()
        {
            var args = new[]
            {
                "UserName=test1", "Password=1", "MinDelay=100", "MaxDelay=-70", "FileName=p0000009.txt",
                "TimesToRepeat=2", "StationId=asd123", "Company=Confirmit", "ExtensionNumber=123"
            };

            var message = string.Empty;
            try
            {
                new AutoPilotArgumentsParser(new StubIAutopilotFileNameValidator()).ParseArguments(args);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is AutopilotArgumentException);
                message = ex.Message;
            }

            Assert.AreEqual(string.Format(Strings.Autopilot_SuppliedValueNotValidInteger_Error, "-70", "MaxDelay"),
                    message);
        }
    }
}
