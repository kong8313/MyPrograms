﻿using System;
using System.Collections.Generic;
using Confirmit.CATI.Console.Classes.CheckSpelling;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Classes.CheckSpelling.Fakes;
using Confirmit.CATI.Console.Presenters;
using Confirmit.CATI.Console.Views.Classes.SpellChecking;
using Confirmit.CATI.Console.Views.ViewInterfaces.Fakes;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class PresenterSpellCheckerTests
    {
        private StubISpellCheckerView _checkerForm;
        private StubISpellCheckService _spellCheckService;

        [TestInitialize]
        public void TestInitialize()
        {
            _checkerForm = new StubISpellCheckerView();
            _spellCheckService = new StubISpellCheckService();
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void PresenterSpellChecker_TextBlockContainsOneErrorInvokeChangeEvent_Success()
        {
            var textBlocks = new List<QuestionTextBlock> { new QuestionTextBlock("1", "Test textx with one error") };

            var errors = new[] { new SpellError("textx", 0, ErrorType.NotInDictionary, new[] { "text" }) };

            _spellCheckService.StartCheckSpellingString = textBlock => 
            {
                _spellCheckService.OnSpellCheckCompleted(new SpellCheckCompletedEventArgs { SpellErrors = errors });
            };

            var presenterSpellChecker = new PresenterSpellChecker(_checkerForm, _spellCheckService, textBlocks);

            presenterSpellChecker.StartWork();

            _checkerForm.OnChangeWord(new ChangeEventArgs { SuggestedWord = "text" });

            Assert.AreEqual("Test text with one error", presenterSpellChecker.TextBlocks[0].Value);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void PresenterSpellChecker_TextBlockContainsRepeatedWordInvokeChangeAll_Success()
        {
            var textBlocks = new List<QuestionTextBlock> { new QuestionTextBlock("1", "Test error error message.") };

            var errors = new[] { new SpellError("error", 5, ErrorType.RepeatedWord, new[] { "error" }) };

            _spellCheckService.StartCheckSpellingString = textBlock =>
            {
                _spellCheckService.OnSpellCheckCompleted(new SpellCheckCompletedEventArgs { SpellErrors = errors });
            };

            var presenterSpellChecker = new PresenterSpellChecker(_checkerForm, _spellCheckService, textBlocks);

            presenterSpellChecker.StartWork();

            _checkerForm.OnDeleteWord(EventArgs.Empty);

            Assert.AreEqual("Test error message.", presenterSpellChecker.TextBlocks[0].Value);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void PresenterSpellChecker_TextBlockContainsSeveralIdenticalErrorsInvokeChangeAllEvent_Success()
        {
            var textBlocks = new List<QuestionTextBlock> { new QuestionTextBlock("1", "Test eror message eror.") };

            var errors = new[] { new SpellError("eror", 5, ErrorType.NotInDictionary, new[] { "error" }) };

            _spellCheckService.StartCheckSpellingString = textBlock =>
            {
                _spellCheckService.OnSpellCheckCompleted(new SpellCheckCompletedEventArgs { SpellErrors = errors });
            };

            var presenterSpellChecker = new PresenterSpellChecker(_checkerForm, _spellCheckService, textBlocks);

            presenterSpellChecker.StartWork();

            _checkerForm.OnChangeAllWords(new ChangeEventArgs { SuggestedWord = "error" });

            Assert.AreEqual("Test error message error.", presenterSpellChecker.TextBlocks[0].Value);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void PresenterSpellChecker_TextBlockContainsThreeIdenticalErrorsInvokeIgnoreTwoTimesAndChangeOneTime_Success()
        {
            var textBlocks = new List<QuestionTextBlock> { new QuestionTextBlock("1", "eror eror text eror.") };

            var errors = new[] { new SpellError("eror", 5, ErrorType.NotInDictionary, new[] { "error" }) };

            _spellCheckService.StartCheckSpellingString = textBlock =>
            {
                _spellCheckService.OnSpellCheckCompleted(new SpellCheckCompletedEventArgs { SpellErrors = errors });
            };

            var presenterSpellChecker = new PresenterSpellChecker(_checkerForm, _spellCheckService, textBlocks);

            presenterSpellChecker.StartWork();

            _checkerForm.OnIgnoreWord(EventArgs.Empty);
            _checkerForm.OnIgnoreWord(EventArgs.Empty);
            _checkerForm.OnChangeWord(new ChangeEventArgs { SuggestedWord = "error" });

            Assert.AreEqual("eror eror text error.", presenterSpellChecker.TextBlocks[0].Value);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void PresenterSpellChecker_TextBlockContainsTwoIdenticalErrorsInvokeIgnoreAll_Success()
        {
            var textBlocks = new List<QuestionTextBlock> { new QuestionTextBlock("1", "text eror with eror") };

            var errors = new[] { new SpellError("eror", 5, ErrorType.NotInDictionary, new[] { "error" }) };

            _spellCheckService.StartCheckSpellingString = textBlock =>
            {
                _spellCheckService.OnSpellCheckCompleted(new SpellCheckCompletedEventArgs { SpellErrors = errors });
            };

            var presenterSpellChecker = new PresenterSpellChecker(_checkerForm, _spellCheckService, textBlocks);

            presenterSpellChecker.StartWork();

            _checkerForm.OnIgnoreAllWords(EventArgs.Empty);

            Assert.AreEqual("text eror with eror", presenterSpellChecker.TextBlocks[0].Value);
        }   
    }
}
