﻿using System;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Shared.Utilities.Fakes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;

namespace Confirmit.CATI.Console.UnitTests
{
    /// <summary>
    /// Unit tests for DateTimeManager
    /// </summary>
    [TestClass]
    public class EnvironmentValidatorTest
    {
        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void GetDotNetVersion_JustGetVersion_VersionIsMoreThen462()
        {
            var environmentValidator = new EnvironmentValidator(new OsVersionProvider(), new LocalMachineRegistryKeyProvider());
            DotNetVersion dotNetVersion = environmentValidator.GetDotNetVersion();

            Assert.IsTrue(Convert.ToInt32(dotNetVersion.Release) >= 394802);
            Assert.IsFalse(string.IsNullOrEmpty(dotNetVersion.Version));
            Assert.IsFalse(string.IsNullOrEmpty(dotNetVersion.Servicing));
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void IsEnvironmentSupported_VersionsOfFrameworkAndOsAreFine_ReturnTrue()
        {
            IOsVersionProvider provider = new StubIOsVersionProvider
            {
                GetVersion = () => new Version(10, 0)
            };
            var environmentValidator = new EnvironmentValidator(provider, new LocalMachineRegistryKeyProvider());
            bool isEnvironmentSupported = environmentValidator.IsEnvironmentSupported();

            Assert.IsTrue(isEnvironmentSupported);
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void IsEnvironmentSupported_WindowsVista_ReturnFalse()
        {
            IOsVersionProvider provider = new StubIOsVersionProvider
            {
                GetVersion = () => new Version(6, 0)
            };
            var environmentValidator = new EnvironmentValidator(provider, new LocalMachineRegistryKeyProvider());
            bool isEnvironmentSupported = environmentValidator.IsEnvironmentSupported();

            Assert.IsFalse(isEnvironmentSupported);
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void IsEnvironmentSupported_Windows7WithoutSp1_ReturnFalse()
        {
            IOsVersionProvider provider = new StubIOsVersionProvider
            {
                GetVersion = () => new Version(6, 1, 7600)
            };
            var environmentValidator = new EnvironmentValidator(provider, new LocalMachineRegistryKeyProvider());
            bool isEnvironmentSupported = environmentValidator.IsEnvironmentSupported();

            Assert.IsFalse(isEnvironmentSupported);
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void IsEnvironmentSupported_Windows7WithSp1_ReturnTrue()
        {
            IOsVersionProvider provider = new StubIOsVersionProvider
            {
                GetVersion = () => new Version(6, 1, 7601)
            };
            var environmentValidator = new EnvironmentValidator(provider, new LocalMachineRegistryKeyProvider());
            bool isEnvironmentSupported = environmentValidator.IsEnvironmentSupported();

            Assert.IsTrue(isEnvironmentSupported);
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void IsEnvironmentSupported_Windows8_ReturnFalse()
        {
            IOsVersionProvider provider = new StubIOsVersionProvider
            {
                GetVersion = () => new Version(6, 2)
            };
            var environmentValidator = new EnvironmentValidator(provider, new LocalMachineRegistryKeyProvider());
            bool isEnvironmentSupported = environmentValidator.IsEnvironmentSupported();

            Assert.IsFalse(isEnvironmentSupported);
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void IsEnvironmentSupported_Windows81_ReturnTrue()
        {
            IOsVersionProvider provider = new StubIOsVersionProvider
            {
                GetVersion = () => new Version(6, 3)
            };
            var environmentValidator = new EnvironmentValidator(provider, new LocalMachineRegistryKeyProvider());
            bool isEnvironmentSupported = environmentValidator.IsEnvironmentSupported();

            Assert.IsTrue(isEnvironmentSupported);
        }

        private RegistryKey OpenSubKey(int release, int servicing, string version, string productName)
        {
            RegistryKey key = Registry.LocalMachine.CreateSubKey(@"SOFTWARE\CatiIntTest\");

            if (key == null)
            {
                throw new Exception("No access to the registry");
            }

            key.SetValue("Release", release);
            key.SetValue("Servicing", servicing);
            key.SetValue("Version", version);
            key.SetValue("ProductName", productName);

            return key;
        }

        private void ClearTestKey()
        {
            if (Registry.LocalMachine.OpenSubKey(@"SOFTWARE\CatiIntTest\") != null)
            {
                Registry.LocalMachine.DeleteSubKey(@"SOFTWARE\CatiIntTest\");
            }
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void IsEnvironmentSupported_OldFramework_ReturnFalse()
        {
            var registryProvider = new StubILocalMachineRegistryKeyProvider 
            {
                OpenSubKeyString = path => OpenSubKey(394800, 0, "", "")
            };
            
            try
            {
                IOsVersionProvider provider = new StubIOsVersionProvider
                {
                    GetVersion = () => new Version(10, 0)
                };
                var environmentValidator = new EnvironmentValidator(provider, registryProvider);
                bool isEnvironmentSupported = environmentValidator.IsEnvironmentSupported();

                Assert.IsFalse(isEnvironmentSupported);
            }
            finally
            {
                ClearTestKey();
            }
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void IsEnvironmentSupported_FrameworkVersionForWin10_ReturnTrue()
        {
            var registryProvider = new StubILocalMachineRegistryKeyProvider
            {
                OpenSubKeyString = path => OpenSubKey(394802, 0, "4.6.01590", "Windows OS")
            };

            try
            {
                IOsVersionProvider provider = new StubIOsVersionProvider
                {
                    GetVersion = () => new Version(10, 0)
                };
                var environmentValidator = new EnvironmentValidator(provider, registryProvider);
                bool isEnvironmentSupported = environmentValidator.IsEnvironmentSupported();

                Assert.IsTrue(isEnvironmentSupported);
            }
            finally
            {
                ClearTestKey();
            }
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void GetWarning_NetFrameworkVersionIsWrong_CorrectMessageIsReturned()
        {
            var registryProvider = new StubILocalMachineRegistryKeyProvider
            {
                OpenSubKeyString = path => OpenSubKey(394800, 0, "", "Windows OS")
            };

            try
            {
                IOsVersionProvider provider = new StubIOsVersionProvider
                {
                    GetVersion = () => new Version(10, 0)
                };
                var environmentValidator = new EnvironmentValidator(provider, registryProvider);
                string message = environmentValidator.GetWarning("First Part\r\n{0}\r\nSecond Part", "Wrong OS Name {0}", "Wrong Net Framework Version");

                Assert.AreEqual("First Part\r\nWrong Net Framework Version\r\n\r\nSecond Part", message);
            }
            finally
            {
                ClearTestKey();
            }
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void GetWarning_NetFrameworkAndOsVersionsAreWrong_CorrectMessageIsReturned()
        {
            var registryProvider = new StubILocalMachineRegistryKeyProvider
            {
                OpenSubKeyString = path => OpenSubKey(394800, 0, "", "Windows OS")
            };

            try
            {
                IOsVersionProvider provider = new StubIOsVersionProvider
                {
                    GetVersion = () => new Version(6, 0)
                };
                var environmentValidator = new EnvironmentValidator(provider, registryProvider);
                string message = environmentValidator.GetWarning("First Part\r\n{0}\r\nSecond Part", "Wrong OS Name {0}", "Wrong Net Framework Version");

                Assert.AreEqual("First Part\r\nWrong OS Name Windows OS\r\nWrong Net Framework Version\r\n\r\nSecond Part", message);
            }
            finally
            {
                ClearTestKey();
            }
        }

        [TestMethod, Owner(@"FIRM\grigoryk")]
        public void GetWarning_OsVersionIsWrong_CorrectMessageIsReturned()
        {
            var registryProvider = new StubILocalMachineRegistryKeyProvider
            {
                OpenSubKeyString = path => OpenSubKey(394802, 0, "", "Windows OS")
            };

            try
            {
                IOsVersionProvider provider = new StubIOsVersionProvider
                {
                    GetVersion = () => new Version(6, 0)
                };
                var environmentValidator = new EnvironmentValidator(provider, registryProvider);
                string message = environmentValidator.GetWarning("First Part\r\n{0}\r\nSecond Part", "Wrong OS Name {0}", "Wrong Net Framework Version");

                Assert.AreEqual("First Part\r\nWrong OS Name Windows OS\r\n\r\nSecond Part", message);
            }
            finally
            {
                ClearTestKey();
            }
        }
    }
}