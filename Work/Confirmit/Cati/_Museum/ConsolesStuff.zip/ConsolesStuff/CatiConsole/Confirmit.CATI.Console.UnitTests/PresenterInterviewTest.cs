﻿using System;
using System.Runtime.Remoting.Messaging;
using System.Windows.Forms;
using Confirmit.CATI.Common.ServiceLocation;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Confirmit.CATI.Console.Presenters;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Log.Fakes;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.StatusBar;
using Confirmit.CATI.Console.Views.Interfaces;
using Confirmit.CATI.Console.Views.Interfaces.Fakes;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Console.Views.ViewInterfaces.Fakes;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class PresenterInterviewTest
    {
        private StubIAlerter _alerter;

        [TestInitialize()]
        public void Initialize()
        {
            var registrator = InitServiceLocator();

            _alerter = new StubIAlerter();

            registrator.RegisterInstance<IAlerter>(_alerter);
        }

        [TestCleanup]
        public void Cleanup()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Cleanup();
        }

        private IServiceRegistrator InitServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            var registrator = (IServiceRegistrator)serviceLocator;
            return registrator;
        }

        private PresenterInterview GetInstance(
            IViewInterviewPageBrowser browser,
            IKeyboardSupport keyboardSupport,
            IViewStatusBar statusBar,
            IButtonsStateProvider buttonsStateProvider)
        {
            IViewKeyboardInput keyboardInput = new StubIViewKeyboardInput();
            ((StubIViewInterviewPageBrowser)browser).ViewKeyboardInputGet = () => keyboardInput;

            PresenterInterview presInterview = new PresenterInterview(browser, keyboardSupport, statusBar, buttonsStateProvider)
            {
                CurrentInterviewProperties = new InterviewProperties()
            };

            return presInterview;
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void PresenterInterview_ViewInterviewPageBrowserIsNull_Exception()
        {
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presenter = new PresenterInterview(
                null,
                keyboardSupport,
                statusBar,
                null
            );
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void PresenterInterview_KeyboardSupportIsNull_Exception()
        {
            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();

            PresenterInterview presenter = new PresenterInterview(
                browser,
                null,
                statusBar,
                null
            );
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void PresenterInterview_StartReview_NavigateWithCorrectUrl()
        {
            InterviewProperties interviewPro = new InterviewProperties
            {
                InterviewId = 1,
                SurveyId = "1",
                InterviewURL = "http://test/test.aspx"
            };
            Uri assumedUri = new Uri("http://test/test.aspx?__reviewing=1");

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            Uri nuvigateUrl = null;
            browser.NavigateUri = uri => { nuvigateUrl = uri; };

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);

            presInterview.StartInterviewReview(interviewPro, null);

            Assert.AreEqual("Openend review", statusBar.CurrentState);
            Assert.AreEqual("1", statusBar.SurveyName);
            Assert.AreEqual("1", statusBar.InterviewName);
            Assert.AreEqual(StatusBarModes.Reviewing, statusBar.Mode);
            Assert.AreEqual(assumedUri, nuvigateUrl);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ProcessKeyboardInput_EndPageEnterPressed_FinishInterview()
        {
            PreviewKeyDownEventArgs args = new PreviewKeyDownEventArgs(Keys.Enter);

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);

            bool readOnlyWasExecuted = false;
            browser.ReadOnlyGet = () => { readOnlyWasExecuted = true; return false; };
            bool telephonyPageWasExecuted = false;
            browser.IsPageInteractorInitializedGet = () => true;
            browser.TelephonyPageGet = () => { telephonyPageWasExecuted = true; return TelephonyPageType.None; };
            bool disableCatiMarkupAndKeyboardSupportWasExecuted = false;
            browser.DisableCatiMarkupAndKeyboardSupportGet = () => { disableCatiMarkupAndKeyboardSupportWasExecuted = true; return false; };
            bool isEndInterviewPageLoadedWasExecuted = false;
            browser.IsEndInterviewPageLoadedGet = () => { isEndInterviewPageLoadedWasExecuted = true; return true; };
            bool finishInterviewWasExecuted = false;
            browser.FinishInterview = () => { finishInterviewWasExecuted = true; };

            presInterview.ProcessKeyboardInput(args);

            Assert.IsTrue(readOnlyWasExecuted);
            Assert.IsTrue(telephonyPageWasExecuted);
            Assert.IsTrue(disableCatiMarkupAndKeyboardSupportWasExecuted);
            Assert.IsTrue(isEndInterviewPageLoadedWasExecuted);
            Assert.IsTrue(finishInterviewWasExecuted);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ProcessKeyboardInput_KeyboardInputHasValueEnterPressed_ProcessEnterData()
        {
            string inputValue = "InputValue";
            PreviewKeyDownEventArgs args = new PreviewKeyDownEventArgs(Keys.Enter);

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);

            IViewKeyboardInput viewKeyboardInput = ((IViewInterviewPageBrowser)browser).ViewKeyboardInput;

            bool readOnlyWasExecuted = false;
            browser.ReadOnlyGet = () => { readOnlyWasExecuted = true; return false; };
            bool telephonyPageWasExecuted = false;
            browser.IsPageInteractorInitializedGet = () => true;
            browser.TelephonyPageGet = () => { telephonyPageWasExecuted = true; return TelephonyPageType.None; };
            bool disableCatiMarkupAndKeyboardSupportWasExecuted = false;
            browser.DisableCatiMarkupAndKeyboardSupportGet = () => { disableCatiMarkupAndKeyboardSupportWasExecuted = true; return false; };
            bool isEndInterviewPageLoadedWasExecuted = false;
            browser.IsEndInterviewPageLoadedGet = () => { isEndInterviewPageLoadedWasExecuted = true; return false; };
            bool navigationIgnoreCheckWasExecuted = false;
            browser.ShouldNavigationBeIgnoredGet = () => { navigationIgnoreCheckWasExecuted = true; return false; };
            bool isFocusedWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).IsFocusedGet = () => { isFocusedWasExecuted = true; return false; };
            bool hasInputValueWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).HasInputValueGet = () => { hasInputValueWasExecuted = true; return true; };
            bool clearWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).Clear = () => { clearWasExecuted = true; };
            viewKeyboardInput.InputValue = inputValue;
            bool hasCurrentQuestionAnswersWithFocusedOtherFieldWasExecuted = false;
            browser.HasCurrentQuestionAnswersWithFocusedOtherFieldGet = () => { hasCurrentQuestionAnswersWithFocusedOtherFieldWasExecuted = true; return false; };
            bool processEnterDataWasExecuted = false;
            browser.ProcessEnterDataString = answer => { processEnterDataWasExecuted = true; };

            presInterview.ProcessKeyboardInput(args);

            Assert.IsTrue(readOnlyWasExecuted);
            Assert.IsTrue(telephonyPageWasExecuted);
            Assert.IsTrue(disableCatiMarkupAndKeyboardSupportWasExecuted);
            Assert.IsTrue(isEndInterviewPageLoadedWasExecuted);
            Assert.IsTrue(navigationIgnoreCheckWasExecuted);
            Assert.IsTrue(isFocusedWasExecuted);
            Assert.IsTrue(hasInputValueWasExecuted);
            Assert.IsTrue(hasInputValueWasExecuted);
            Assert.IsTrue(hasCurrentQuestionAnswersWithFocusedOtherFieldWasExecuted);
            Assert.IsTrue(clearWasExecuted);
            Assert.IsTrue(processEnterDataWasExecuted);

            Assert.AreEqual(inputValue, viewKeyboardInput.InputValue);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ProcessKeyboardInput_KeyboardInputHasntValueEnterPressed_DoNextQuestion()
        {
            PreviewKeyDownEventArgs args = new PreviewKeyDownEventArgs(Keys.Enter);

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);

            IViewKeyboardInput viewKeyboardInput = ((IViewInterviewPageBrowser)browser).ViewKeyboardInput;

            bool readOnlyWasExecuted = false;
            browser.ReadOnlyGet = () => { readOnlyWasExecuted = true; return false; };
            bool telephonyPageWasExecuted = false;
            browser.IsPageInteractorInitializedGet = () => true;
            browser.TelephonyPageGet = () => { telephonyPageWasExecuted = true; return TelephonyPageType.None; };
            bool disableCatiMarkupAndKeyboardSupportWasExecuted = false;
            browser.DisableCatiMarkupAndKeyboardSupportGet = () => { disableCatiMarkupAndKeyboardSupportWasExecuted = true; return false; };
            bool isEndInterviewPageLoadedWasExecuted = false;
            browser.IsEndInterviewPageLoadedGet = () => { isEndInterviewPageLoadedWasExecuted = true; return false; };
            bool navigationIgnoreCheckWasExecuted = false;
            browser.ShouldNavigationBeIgnoredGet = () => { navigationIgnoreCheckWasExecuted = true; return false; };
            bool isFocusedWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).IsFocusedGet = () => { isFocusedWasExecuted = true; return false; };
            bool hasInputValueWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).HasInputValueGet = () => { hasInputValueWasExecuted = true; return false; };
            bool clearWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).Clear = () => { clearWasExecuted = true; };
            bool isCurrentQuestionLastWasExecuted = false;
            browser.IsCurrentQuestionLastGet = () => { isCurrentQuestionLastWasExecuted = true; return false; };
            bool hasCurrentQuestionAnswersWithFocusedOtherFieldWasExecuted = false;
            browser.HasCurrentQuestionAnswersWithFocusedOtherFieldGet = () => { hasCurrentQuestionAnswersWithFocusedOtherFieldWasExecuted = true; return false; };
            bool doNextQuestionWasExecuted = false;
            browser.DoNextQuestion = () => { doNextQuestionWasExecuted = true; };
            bool setFocusWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).SetFocus = () => { setFocusWasExecuted = true; };

            presInterview.ProcessKeyboardInput(args);

            Assert.IsTrue(readOnlyWasExecuted);
            Assert.IsTrue(telephonyPageWasExecuted);
            Assert.IsTrue(disableCatiMarkupAndKeyboardSupportWasExecuted);
            Assert.IsTrue(isEndInterviewPageLoadedWasExecuted);
            Assert.IsTrue(navigationIgnoreCheckWasExecuted);
            Assert.IsTrue(isFocusedWasExecuted);
            Assert.IsTrue(hasInputValueWasExecuted);
            Assert.IsTrue(isCurrentQuestionLastWasExecuted);
            Assert.IsTrue(hasCurrentQuestionAnswersWithFocusedOtherFieldWasExecuted);

            Assert.IsTrue(doNextQuestionWasExecuted);
            Assert.IsTrue(clearWasExecuted);
            Assert.IsTrue(setFocusWasExecuted);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ProcessKeyboardInput_DownPressed_DoNextQuestion()
        {
            PreviewKeyDownEventArgs args = new PreviewKeyDownEventArgs(Keys.Down);

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);
            IViewKeyboardInput viewKeyboardInput = ((IViewInterviewPageBrowser)browser).ViewKeyboardInput;

            bool readOnlyWasExecuted = false;
            browser.ReadOnlyGet = () => { readOnlyWasExecuted = true; return false; };
            bool telephonyPageWasExecuted = false;
            browser.IsPageInteractorInitializedGet = () => true;
            browser.TelephonyPageGet = () => { telephonyPageWasExecuted = true; return TelephonyPageType.None; };
            bool disableCatiMarkupAndKeyboardSupportWasExecuted = false;
            browser.DisableCatiMarkupAndKeyboardSupportGet = () => { disableCatiMarkupAndKeyboardSupportWasExecuted = true; return false; };
            bool isEndInterviewPageLoadedWasExecuted = false;
            browser.IsEndInterviewPageLoadedGet = () => { isEndInterviewPageLoadedWasExecuted = true; return false; };
            bool navigationIgnoreCheckWasExecuted = false;
            browser.ShouldNavigationBeIgnoredGet = () => { navigationIgnoreCheckWasExecuted = true; return false; };
            bool isFocusedWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).IsFocusedGet = () => { isFocusedWasExecuted = true; return false; };
            bool doNextQuestionWasExecuted = false;
            browser.DoNextQuestion = () => { doNextQuestionWasExecuted = true; };
            bool setFocusWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).SetFocus = () => { setFocusWasExecuted = true; };

            presInterview.ProcessKeyboardInput(args);

            Assert.IsTrue(readOnlyWasExecuted);
            Assert.IsTrue(telephonyPageWasExecuted);
            Assert.IsTrue(disableCatiMarkupAndKeyboardSupportWasExecuted);
            Assert.IsTrue(isEndInterviewPageLoadedWasExecuted);
            Assert.IsTrue(navigationIgnoreCheckWasExecuted);
            Assert.IsTrue(isFocusedWasExecuted);

            Assert.IsTrue(doNextQuestionWasExecuted);
            Assert.IsTrue(setFocusWasExecuted);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ProcessKeyboardInput_UpPressed_DoNextQuestion()
        {
            PreviewKeyDownEventArgs args = new PreviewKeyDownEventArgs(Keys.Up);

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);
            IViewKeyboardInput viewKeyboardInput = ((IViewInterviewPageBrowser)browser).ViewKeyboardInput;

            bool readOnlyWasExecuted = false;
            browser.ReadOnlyGet = () => { readOnlyWasExecuted = true; return false; };
            bool telephonyPageWasExecuted = false;
            browser.IsPageInteractorInitializedGet = () => true;
            browser.TelephonyPageGet = () => { telephonyPageWasExecuted = true; return TelephonyPageType.None; };
            bool disableCatiMarkupAndKeyboardSupportWasExecuted = false;
            browser.DisableCatiMarkupAndKeyboardSupportGet = () => { disableCatiMarkupAndKeyboardSupportWasExecuted = true; return false; };
            bool isEndInterviewPageLoadedWasExecuted = false;
            browser.IsEndInterviewPageLoadedGet = () => { isEndInterviewPageLoadedWasExecuted = true; return false; };
            bool navigationIgnoreCheckWasExecuted = false;
            browser.ShouldNavigationBeIgnoredGet = () => { navigationIgnoreCheckWasExecuted = true; return false; };
            bool isFocusedWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).IsFocusedGet = () => { isFocusedWasExecuted = true; return false; };
            bool doPreviousQuestionWasExecuted = false;
            browser.DoPreviousQuestion = () => { doPreviousQuestionWasExecuted = true; };
            bool setFocusWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).SetFocus = () => { setFocusWasExecuted = true; };

            presInterview.ProcessKeyboardInput(args);

            Assert.IsTrue(readOnlyWasExecuted);
            Assert.IsTrue(telephonyPageWasExecuted);
            Assert.IsTrue(disableCatiMarkupAndKeyboardSupportWasExecuted);
            Assert.IsTrue(isEndInterviewPageLoadedWasExecuted);
            Assert.IsTrue(navigationIgnoreCheckWasExecuted);
            Assert.IsTrue(isFocusedWasExecuted);

            Assert.IsTrue(doPreviousQuestionWasExecuted);
            Assert.IsTrue(setFocusWasExecuted);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ProcessKeyboardInput_Tab_DoNextQuestion()
        {
            PreviewKeyDownEventArgs args = new PreviewKeyDownEventArgs(Keys.Tab);

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);

            IViewKeyboardInput viewKeyboardInput = ((IViewInterviewPageBrowser)browser).ViewKeyboardInput;

            bool readOnlyWasExecuted = false;
            browser.ReadOnlyGet = () => { readOnlyWasExecuted = true; return false; };
            bool telephonyPageWasExecuted = false;
            browser.IsPageInteractorInitializedGet = () => true;
            browser.TelephonyPageGet = () => { telephonyPageWasExecuted = true; return TelephonyPageType.None; };
            bool disableCatiMarkupAndKeyboardSupportWasExecuted = false;
            browser.DisableCatiMarkupAndKeyboardSupportGet = () => { disableCatiMarkupAndKeyboardSupportWasExecuted = true; return false; };
            bool isEndInterviewPageLoadedWasExecuted = false;
            browser.IsEndInterviewPageLoadedGet = () => { isEndInterviewPageLoadedWasExecuted = true; return false; };
            bool navigationIgnoreCheckWasExecuted = false;
            browser.ShouldNavigationBeIgnoredGet = () => { navigationIgnoreCheckWasExecuted = true; return false; };
            bool isFocusedWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).IsFocusedGet = () => { isFocusedWasExecuted = true; return false; };
            bool doNextQuestionWasExecuted = false;
            browser.DoNextQuestion = () => { doNextQuestionWasExecuted = true; };
            bool setFocusWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).SetFocus = () => { setFocusWasExecuted = true; };

            presInterview.ProcessKeyboardInput(args);

            Assert.IsTrue(readOnlyWasExecuted);
            Assert.IsTrue(telephonyPageWasExecuted);
            Assert.IsTrue(disableCatiMarkupAndKeyboardSupportWasExecuted);
            Assert.IsTrue(isEndInterviewPageLoadedWasExecuted);
            Assert.IsTrue(navigationIgnoreCheckWasExecuted);
            Assert.IsTrue(isFocusedWasExecuted);

            Assert.IsTrue(doNextQuestionWasExecuted);
            Assert.IsTrue(setFocusWasExecuted);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ProcessKeyboardInput_TabShift_DoPreviousQuestion()
        {
            PreviewKeyDownEventArgs args = new PreviewKeyDownEventArgs(Keys.Tab | Keys.Shift);

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);

            IViewKeyboardInput viewKeyboardInput = ((IViewInterviewPageBrowser)browser).ViewKeyboardInput;

            bool readOnlyWasExecuted = false;
            browser.ReadOnlyGet = () => { readOnlyWasExecuted = true; return false; };
            bool telephonyPageWasExecuted = false;
            browser.IsPageInteractorInitializedGet = () => true;
            browser.TelephonyPageGet = () => { telephonyPageWasExecuted = true; return TelephonyPageType.None; };
            bool disableCatiMarkupAndKeyboardSupportWasExecuted = false;
            browser.DisableCatiMarkupAndKeyboardSupportGet = () => { disableCatiMarkupAndKeyboardSupportWasExecuted = true; return false; };
            bool isEndInterviewPageLoadedWasExecuted = false;
            browser.IsEndInterviewPageLoadedGet = () => { isEndInterviewPageLoadedWasExecuted = true; return false; };
            bool navigationIgnoreCheckWasExecuted = false;
            browser.ShouldNavigationBeIgnoredGet = () => { navigationIgnoreCheckWasExecuted = true; return false; };
            bool isFocusedWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).IsFocusedGet = () => { isFocusedWasExecuted = true; return false; };
            bool doPreviousQuestionWasExecuted = false;
            browser.DoPreviousQuestion = () => { doPreviousQuestionWasExecuted = true; };
            bool setFocusWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).SetFocus = () => { setFocusWasExecuted = true; };

            presInterview.ProcessKeyboardInput(args);

            Assert.IsTrue(readOnlyWasExecuted);
            Assert.IsTrue(telephonyPageWasExecuted);
            Assert.IsTrue(disableCatiMarkupAndKeyboardSupportWasExecuted);
            Assert.IsTrue(isEndInterviewPageLoadedWasExecuted);
            Assert.IsTrue(navigationIgnoreCheckWasExecuted);
            Assert.IsTrue(isFocusedWasExecuted);

            Assert.IsTrue(doPreviousQuestionWasExecuted);
            Assert.IsTrue(setFocusWasExecuted);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ProcessKeyboardInput_HomePressed_DoFirstSubQuestion()
        {
            PreviewKeyDownEventArgs args = new PreviewKeyDownEventArgs(Keys.Home);

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);
            IViewKeyboardInput viewKeyboardInput = ((IViewInterviewPageBrowser)browser).ViewKeyboardInput;

            bool readOnlyWasExecuted = false;
            browser.ReadOnlyGet = () => { readOnlyWasExecuted = true; return false; };
            bool telephonyPageWasExecuted = false;
            browser.IsPageInteractorInitializedGet = () => true;
            browser.TelephonyPageGet = () => { telephonyPageWasExecuted = true; return TelephonyPageType.None; };
            bool disableCatiMarkupAndKeyboardSupportWasExecuted = false;
            browser.DisableCatiMarkupAndKeyboardSupportGet = () => { disableCatiMarkupAndKeyboardSupportWasExecuted = true; return false; };
            bool isEndInterviewPageLoadedWasExecuted = false;
            browser.IsEndInterviewPageLoadedGet = () => { isEndInterviewPageLoadedWasExecuted = true; return false; };
            bool navigationIgnoreCheckWasExecuted = false;
            browser.ShouldNavigationBeIgnoredGet = () => { navigationIgnoreCheckWasExecuted = true; return false; };
            bool isFocusedWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).IsFocusedGet = () => { isFocusedWasExecuted = true; return false; };
            browser.HasCurrentQuestionAnswersWithFocusedOtherFieldGet = () => false;
            bool doFirstSubQuestionWasExecuted = false;
            browser.DoFirstSubQuestion = () => { doFirstSubQuestionWasExecuted = true; };
            bool setFocusWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).SetFocus = () => { setFocusWasExecuted = true; };

            presInterview.ProcessKeyboardInput(args);

            Assert.IsTrue(readOnlyWasExecuted);
            Assert.IsTrue(telephonyPageWasExecuted);
            Assert.IsTrue(disableCatiMarkupAndKeyboardSupportWasExecuted);
            Assert.IsTrue(isEndInterviewPageLoadedWasExecuted);
            Assert.IsTrue(navigationIgnoreCheckWasExecuted);
            Assert.IsTrue(isFocusedWasExecuted);

            Assert.IsTrue(doFirstSubQuestionWasExecuted);
            Assert.IsTrue(setFocusWasExecuted);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ProcessKeyboardInput_HomeControlPressed_DoFirstSubQuestion()
        {
            PreviewKeyDownEventArgs args = new PreviewKeyDownEventArgs(Keys.Home | Keys.Control);

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);
            IViewKeyboardInput viewKeyboardInput = ((IViewInterviewPageBrowser)browser).ViewKeyboardInput;

            bool readOnlyWasExecuted = false;
            browser.ReadOnlyGet = () => { readOnlyWasExecuted = true; return false; };
            bool telephonyPageWasExecuted = false;
            browser.IsPageInteractorInitializedGet = () => true;
            browser.TelephonyPageGet = () => { telephonyPageWasExecuted = true; return TelephonyPageType.None; };
            bool disableCatiMarkupAndKeyboardSupportWasExecuted = false;
            browser.DisableCatiMarkupAndKeyboardSupportGet = () => { disableCatiMarkupAndKeyboardSupportWasExecuted = true; return false; };
            bool isEndInterviewPageLoadedWasExecuted = false;
            browser.IsEndInterviewPageLoadedGet = () => { isEndInterviewPageLoadedWasExecuted = true; return false; };
            bool navigationIgnoreCheckWasExecuted = false;
            browser.ShouldNavigationBeIgnoredGet = () => { navigationIgnoreCheckWasExecuted = true; return false; };
            bool isFocusedWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).IsFocusedGet = () => { isFocusedWasExecuted = true; return false; };
            browser.HasCurrentQuestionAnswersWithFocusedOtherFieldGet = () => false;
            bool doFirstQuestionFirstSubQuestionWasExecuted = false;
            browser.DoFirstQuestionFirstSubQuestion = () => { doFirstQuestionFirstSubQuestionWasExecuted = true; };
            bool setFocusWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).SetFocus = () => { setFocusWasExecuted = true; };

            presInterview.ProcessKeyboardInput(args);

            Assert.IsTrue(readOnlyWasExecuted);
            Assert.IsTrue(telephonyPageWasExecuted);
            Assert.IsTrue(disableCatiMarkupAndKeyboardSupportWasExecuted);
            Assert.IsTrue(isEndInterviewPageLoadedWasExecuted);
            Assert.IsTrue(navigationIgnoreCheckWasExecuted);
            Assert.IsTrue(isFocusedWasExecuted);

            Assert.IsTrue(doFirstQuestionFirstSubQuestionWasExecuted);
            Assert.IsTrue(setFocusWasExecuted);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ProcessKeyboardInput_EndPressed_DoLastSubQuestion()
        {
            PreviewKeyDownEventArgs args = new PreviewKeyDownEventArgs(Keys.End);

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);
            IViewKeyboardInput viewKeyboardInput = ((IViewInterviewPageBrowser)browser).ViewKeyboardInput;

            bool readOnlyWasExecuted = false;
            browser.ReadOnlyGet = () => { readOnlyWasExecuted = true; return false; };
            bool telephonyPageWasExecuted = false;
            browser.IsPageInteractorInitializedGet = () => true;
            browser.TelephonyPageGet = () => { telephonyPageWasExecuted = true; return TelephonyPageType.None; };
            bool disableCatiMarkupAndKeyboardSupportWasExecuted = false;
            browser.DisableCatiMarkupAndKeyboardSupportGet = () => { disableCatiMarkupAndKeyboardSupportWasExecuted = true; return false; };
            bool isEndInterviewPageLoadedWasExecuted = false;
            browser.IsEndInterviewPageLoadedGet = () => { isEndInterviewPageLoadedWasExecuted = true; return false; };
            bool navigationIgnoreCheckWasExecuted = false;
            browser.ShouldNavigationBeIgnoredGet = () => { navigationIgnoreCheckWasExecuted = true; return false; };
            bool isFocusedWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).IsFocusedGet = () => { isFocusedWasExecuted = true; return false; };
            browser.HasCurrentQuestionAnswersWithFocusedOtherFieldGet = () => false;
            bool doLastSubQuestionWasExecuted = false;
            browser.DoLastSubQuestion = () => { doLastSubQuestionWasExecuted = true; };
            bool setFocusWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).SetFocus = () => { setFocusWasExecuted = true; };

            presInterview.ProcessKeyboardInput(args);

            Assert.IsTrue(readOnlyWasExecuted);
            Assert.IsTrue(telephonyPageWasExecuted);
            Assert.IsTrue(disableCatiMarkupAndKeyboardSupportWasExecuted);
            Assert.IsTrue(isEndInterviewPageLoadedWasExecuted);
            Assert.IsTrue(navigationIgnoreCheckWasExecuted);
            Assert.IsTrue(isFocusedWasExecuted);

            Assert.IsTrue(doLastSubQuestionWasExecuted);
            Assert.IsTrue(setFocusWasExecuted);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ProcessKeyboardInput_EndControlPressed_DoLastQuestion()
        {
            PreviewKeyDownEventArgs args = new PreviewKeyDownEventArgs(Keys.End | Keys.Control);

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);
            IViewKeyboardInput viewKeyboardInput = ((IViewInterviewPageBrowser)browser).ViewKeyboardInput;

            bool readOnlyWasExecuted = false;
            browser.ReadOnlyGet = () => { readOnlyWasExecuted = true; return false; };
            bool telephonyPageWasExecuted = false;
            browser.IsPageInteractorInitializedGet = () => true;
            browser.TelephonyPageGet = () => { telephonyPageWasExecuted = true; return TelephonyPageType.None; };
            bool disableCatiMarkupAndKeyboardSupportWasExecuted = false;
            browser.DisableCatiMarkupAndKeyboardSupportGet = () => { disableCatiMarkupAndKeyboardSupportWasExecuted = true; return false; };
            bool isEndInterviewPageLoadedWasExecuted = false;
            browser.IsEndInterviewPageLoadedGet = () => { isEndInterviewPageLoadedWasExecuted = true; return false; };
            bool navigationIgnoreCheckWasExecuted = false;
            browser.ShouldNavigationBeIgnoredGet = () => { navigationIgnoreCheckWasExecuted = true; return false; };
            bool isFocusedWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).IsFocusedGet = () => { isFocusedWasExecuted = true; return false; };
            browser.HasCurrentQuestionAnswersWithFocusedOtherFieldGet = () => false;
            bool doLastQuestionLastSubQuestionWasExecuted = false;
            browser.DoLastQuestionLastSubQuestion = () => { doLastQuestionLastSubQuestionWasExecuted = true; };
            bool setFocusWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).SetFocus = () => { setFocusWasExecuted = true; };

            presInterview.ProcessKeyboardInput(args);

            Assert.IsTrue(readOnlyWasExecuted);
            Assert.IsTrue(telephonyPageWasExecuted);
            Assert.IsTrue(disableCatiMarkupAndKeyboardSupportWasExecuted);
            Assert.IsTrue(isEndInterviewPageLoadedWasExecuted);
            Assert.IsTrue(navigationIgnoreCheckWasExecuted);
            Assert.IsTrue(isFocusedWasExecuted);

            Assert.IsTrue(doLastQuestionLastSubQuestionWasExecuted);
            Assert.IsTrue(setFocusWasExecuted);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ProcessKeyboardInput_F2Pressed_DoEditQuestion()
        {
            PreviewKeyDownEventArgs args = new PreviewKeyDownEventArgs(Keys.F2);

            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);
            IViewKeyboardInput viewKeyboardInput = ((IViewInterviewPageBrowser)browser).ViewKeyboardInput;

            bool readOnlyWasExecuted = false;
            browser.ReadOnlyGet = () => { readOnlyWasExecuted = true; return false; };
            bool telephonyPageWasExecuted = false;
            browser.IsPageInteractorInitializedGet = () => true;
            browser.TelephonyPageGet = () => { telephonyPageWasExecuted = true; return TelephonyPageType.None; };
            bool disableCatiMarkupAndKeyboardSupportWasExecuted = false;
            browser.DisableCatiMarkupAndKeyboardSupportGet = () => { disableCatiMarkupAndKeyboardSupportWasExecuted = true; return false; };
            bool isEndInterviewPageLoadedWasExecuted = false;
            browser.IsEndInterviewPageLoadedGet = () => { isEndInterviewPageLoadedWasExecuted = true; return false; };
            bool navigationIgnoreCheckWasExecuted = false;
            browser.ShouldNavigationBeIgnoredGet = () => { navigationIgnoreCheckWasExecuted = true; return false; };
            bool isFocusedWasExecuted = false;
            ((StubIViewKeyboardInput)viewKeyboardInput).IsFocusedGet = () => { isFocusedWasExecuted = true; return false; };
            bool doEditQuestionWasExecuted = false;
            browser.DoEditQuestion = () => { doEditQuestionWasExecuted = true; };

            presInterview.ProcessKeyboardInput(args);

            Assert.IsTrue(readOnlyWasExecuted);
            Assert.IsTrue(telephonyPageWasExecuted);
            Assert.IsTrue(disableCatiMarkupAndKeyboardSupportWasExecuted);
            Assert.IsTrue(isEndInterviewPageLoadedWasExecuted);
            Assert.IsTrue(navigationIgnoreCheckWasExecuted);
            Assert.IsTrue(isFocusedWasExecuted);

            Assert.IsTrue(doEditQuestionWasExecuted);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void AddQueryToUri_CorrectUriCorrectQuery_CorrectResultUri()
        {
            var browser = new StubIViewInterviewPageBrowser();
            IViewStatusBar statusBar = new StubIViewStatusBar();
            IKeyboardSupport keyboardSupport = new StubIKeyboardSupport();

            PresenterInterview presInterview = GetInstance(browser, keyboardSupport, statusBar, null);

            string queryToAppend = "a=1";
            Uri originalUri = new Uri("http://test/test.aspx");
            string assumedUrl = "http://test/test.aspx?a=1";

            Uri resultUri = presInterview.AddQueryToUri(originalUri, queryToAppend);
            Assert.AreEqual(resultUri.AbsoluteUri, assumedUrl);

            queryToAppend = "a=1&b=2";
            originalUri = new Uri("http://test/test.aspx?test=1");
            assumedUrl = "http://test/test.aspx?test=1&a=1&b=2";

            resultUri = presInterview.AddQueryToUri(originalUri, queryToAppend);
            Assert.AreEqual(resultUri.AbsoluteUri, assumedUrl);
        }

    }
}
