﻿using System;
using Confirmit.CATI.Console.Services.CatiService;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class AsyncCatiServiceHelperTest
    {
        public class CatiServiceManagerStub
        {
            public static string Phone;
            public static Initiator Initiator;

            public static void Dial(string phone, Initiator initiator)
            {
                Phone = phone;
                Initiator = initiator;
            }
        }

        private AsyncOperationInvoker GetInstance()
        {
            return AsyncOperationInvoker.Instance;
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        [ExpectedException(typeof(InvalidOperationException))]
        public void Dial_CommandInProgress_ExceptionThrows()
        {
            AsyncOperationInvoker helper = GetInstance();

            Action<GetStateEventArgs> handler = args => { };

            try
            {
                helper.Execute(null, handler, 10000);
                helper.Execute(null, handler);
            }
            finally
            {
                helper.ClearResources();
            }
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Dial_StartedCorrectly_StartsTimer()
        {
            AsyncOperationInvoker helper = GetInstance();
            Action<GetStateEventArgs> handler = args => { };
            try
            {
                helper.Execute(() => CatiServiceManagerStub.Dial("123456", Initiator.Script), handler, 10000);

                Assert.IsTrue(helper.IsInProgress);
                Assert.AreEqual("123456", CatiServiceManagerStub.Phone);
                Assert.AreEqual(Initiator.Script, CatiServiceManagerStub.Initiator);
            }
            finally
            {
                helper.ClearResources();
            }
        }
    }
}