﻿using Confirmit.CATI.Console.Shared.Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Confirmit.CATI.Console.Classes.Utilities;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class LinkRepairerTests
    {        
        [TestMethod, Owner(@"FIRM\KirillV")]
        public void LinkRepairer_ImageRelativePath_CorrectAbsolutePath()
        {
            const string hostName = "survey.euro.confirmit.com";

            const string testPage = @"<IMG border=0 hspace=0 SRC=""/isa/BDJPFRDMEYBPBKLVADAYFQCDAVIOEQJR/main-bottom-right.jpg"">";
            const string expectedPage = @"<IMG border=0 hspace=0 SRC=""http://survey.euro.confirmit.com/isa/BDJPFRDMEYBPBKLVADAYFQCDAVIOEQJR/main-bottom-right.jpg"">";

           Assert.AreEqual(expectedPage, LinkRepairer.Repair(testPage, hostName, "http"));
        }

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void LinkRepairer_ImageAbsolutePath_TheSameAbsolutePath()
        {
            const string hostName = "survey.euro.confirmit.com";

            const string testPage = @"<img height=""83"" alt="""" src=""http://www.confirmit.com/App_Themes/Confirmit/Img/logo.jpg"" width=""132"" border=""0""/>";
            const string expectedPage = testPage;

            Assert.AreEqual(expectedPage, LinkRepairer.Repair(testPage, hostName, "http"));
        }

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void LinkRepairer_CssRelativePathNotToClientUtil_CorrectAbsolutePath()
        {
            const string hostName = "survey.euro.confirmit.com";

            const string testPage = @"<link id=""ss__cs"" HREF=""stylesheet.aspx?pid=p1118484&amp;executionMode=Cawi&amp;unique=2-16"" type=""text/css""/>";
            const string expectedPage = @"<link id=""ss__cs"" HREF=""http://survey.euro.confirmit.com/wix/stylesheet.aspx?pid=p1118484&amp;executionMode=Cawi&amp;unique=2-16"" type=""text/css""/>";

            Assert.AreEqual(expectedPage, LinkRepairer.Repair(testPage, hostName, "http"));
        }

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void LinkRepairer_CssRelativePathToClientUtil_CorrectAbsolutePath()
        {
            const string hostName = "survey.euro.confirmit.com";

            const string testPage = @"<link id=""wix-carousel-grid"" href=""/cf_clientutil/wix/carousel-grid.css?v=214"" rel=""stylesheet"" type=""text/css"">";
            const string expectedPage = @"<link id=""wix-carousel-grid"" HREF=""http://survey.euro.confirmit.com/cf_clientutil/wix/carousel-grid.css?v=214"" rel=""stylesheet"" type=""text/css"">";

            Assert.AreEqual(expectedPage, LinkRepairer.Repair(testPage, hostName, "http"));
        }

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void LinkRepairer_ScriptRelativePathToClientUtil_CorrectAbsolutePath()
        {
            const string hostName = "survey.euro.confirmit.com";

            const string testPage = @"<script id=""yui_3_14_1_1_1518181215666_2"" src=""/cf_clientutil/wix/wix.js?v=214"" charset=""utf-8"" async=""""></script>";
            const string expectedPage = @"<script id=""yui_3_14_1_1_1518181215666_2"" SRC=""http://survey.euro.confirmit.com/cf_clientutil/wix/wix.js?v=214"" charset=""utf-8"" async=""""></script>";

            Assert.AreEqual(expectedPage, LinkRepairer.Repair(testPage, hostName, "http"));
        }     
        
        [TestMethod, Owner(@"FIRM\AlexanderM")]
        public void LinkRepairer_ImageRelativePath_HTTPS_CorrectAbsolutePath()
        {
            const string hostName = "survey.euro.confirmit.com";

            const string testPage = @"<IMG border=0 hspace=0 SRC=""/isa/BDJPFRDMEYBPBKLVADAYFQCDAVIOEQJR/main-bottom-right.jpg"">";
            const string expectedPage = @"<IMG border=0 hspace=0 SRC=""https://survey.euro.confirmit.com/isa/BDJPFRDMEYBPBKLVADAYFQCDAVIOEQJR/main-bottom-right.jpg"">";

            Assert.AreEqual(expectedPage, LinkRepairer.Repair(testPage, hostName, "https"));
        }

        [TestMethod, Owner(@"FIRM\AlexanderM")]
        public void LinkRepairer_ImageAbsolutePath_HTTPS_TheSameAbsolutePath()
        {
            const string hostName = "survey.euro.confirmit.com";

            const string testPage = @"<img height=""83"" alt="""" src=""https://www.confirmit.com/App_Themes/Confirmit/Img/logo.jpg"" width=""132"" border=""0""/>";
            const string expectedPage = testPage;

            Assert.AreEqual(expectedPage, LinkRepairer.Repair(testPage, hostName, "https"));
        }

        [TestMethod, Owner(@"FIRM\AlexanderM")]
        public void LinkRepairer_CssRelativePathNotToClientUtil_HTTPS_CorrectAbsolutePath()
        {
            const string hostName = "survey.euro.confirmit.com";

            const string testPage = @"<link id=""ss__cs"" HREF=""stylesheet.aspx?pid=p1118484&amp;executionMode=Cawi&amp;unique=2-16"" type=""text/css""/>";
            const string expectedPage = @"<link id=""ss__cs"" HREF=""https://survey.euro.confirmit.com/wix/stylesheet.aspx?pid=p1118484&amp;executionMode=Cawi&amp;unique=2-16"" type=""text/css""/>";

            Assert.AreEqual(expectedPage, LinkRepairer.Repair(testPage, hostName, "https"));
        }

        [TestMethod, Owner(@"FIRM\AlexanderM")]
        public void LinkRepairer_CssRelativePathToClientUtil_HTTPS_CorrectAbsolutePath()
        {
            const string hostName = "survey.euro.confirmit.com";

            const string testPage = @"<link id=""wix-carousel-grid"" href=""/cf_clientutil/wix/carousel-grid.css?v=214"" rel=""stylesheet"" type=""text/css"">";
            const string expectedPage = @"<link id=""wix-carousel-grid"" HREF=""https://survey.euro.confirmit.com/cf_clientutil/wix/carousel-grid.css?v=214"" rel=""stylesheet"" type=""text/css"">";

            Assert.AreEqual(expectedPage, LinkRepairer.Repair(testPage, hostName, "https"));
        }

        [TestMethod, Owner(@"FIRM\AlexanderM")]
        public void LinkRepairer_ScriptRelativePathToClientUtil_HTTPS_CorrectAbsolutePath()
        {
            const string hostName = "survey.euro.confirmit.com";

            const string testPage = @"<script id=""yui_3_14_1_1_1518181215666_2"" src=""/cf_clientutil/wix/wix.js?v=214"" charset=""utf-8"" async=""""></script>";
            const string expectedPage = @"<script id=""yui_3_14_1_1_1518181215666_2"" SRC=""https://survey.euro.confirmit.com/cf_clientutil/wix/wix.js?v=214"" charset=""utf-8"" async=""""></script>";

            Assert.AreEqual(expectedPage, LinkRepairer.Repair(testPage, hostName, "https"));
        }

        [TestMethod, Owner(@"FIRM\AlexanderM")]
        public void LinkRepairer_AboutBlank_NotChanged()
        {
            const string hostName = "survey.euro.confirmit.com";

            const string testPage = @"<html><body></body></html>";

            Assert.AreEqual(testPage, LinkRepairer.Repair(testPage, hostName, "about"));
        }
    }
}
