﻿using System;
using Confirmit.CATI.Console.Services.CatiService;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Confirmit.CATI.Common;

namespace Confirmit.CATI.Console.UnitTests
{
	[TestClass]
	public class TimezoneConverterTest
	{
		[TestMethod, Owner(@"FIRM\SergeyC")]
		public void FromUTCToLocal_CorrectTimezone_Success()
		{
            Timezone t = new Timezone()
            {
                Bias = -60,
                DaylightBias = -60,
                DaylightName = "Timezone 1",
                DaylightType = DaylightType.Disable,
                Id = 1,
                Name = "Timezone 1",
                StandardBias = 0,
                StandardName = "Timezone 1"
            };

			DateTime now = new DateTime(2008, 10, 10);
			DateTime result = TimezoneConverter.ConvertTimeFromUtc(t, now);
            Assert.AreEqual(now.AddHours(1), result);
		}

		[TestMethod, Owner(@"FIRM\SergeyC")]
		public void FromLocalToUTC_CorrectTimezone_Success()
		{
            Timezone t = new Timezone()
            {
                Bias = -60,
                DaylightBias = -60,
                DaylightName = "Timezone 1",
                DaylightType = DaylightType.Disable,
                Id = 1,
                Name = "Timezone 1",
                StandardBias = 0,
                StandardName = "Timezone 1"
            };

			DateTime now = new DateTime(2008, 10, 10);
			DateTime result = TimezoneConverter.ConvertTimeToUtc(t, now);
            Assert.AreEqual(now.AddHours(-1), result);
		}
	}
}
