﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Confirmit.CATI.Console.Shared.Utilities;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class ConnectionQualityAnalyzerTest
    {
        private ConnectionQualityAnalyzer connectionQualityAnalyzer;
        private int keepAliveKeepAliveCallsToSave = 3;
        private int fastConnectionThreshold = 300;
        private int normalConnectionThreshold = 1000;

        [TestInitialize]
        public void Init()
        {
            connectionQualityAnalyzer = new ConnectionQualityAnalyzer(
                keepAliveKeepAliveCallsToSave,
                fastConnectionThreshold,
                normalConnectionThreshold);
        }

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void OneFastCall_GoodConnection()
        {
            var expected = ConnectionQuality.Good;
            var lastCallDuration = 10;

            var actual = connectionQualityAnalyzer.AddCallAndAnalyzeConnection(lastCallDuration);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void ThreeFastCalls_GoodConnection()
        {
            var expectedQuality = ConnectionQuality.Good;
            var lastCallDurations = new[] { 10, 50, 100 };

            foreach (var lastCallDuration in lastCallDurations)
            {
                var actualQuality = connectionQualityAnalyzer.AddCallAndAnalyzeConnection(lastCallDuration);
                Assert.AreEqual(expectedQuality, actualQuality);
            }
        }

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void OneSlowAndThreeFastCalls_GoodConnection()
        {
            var firstExpectedQuality = ConnectionQuality.Poor;
            var secondExpectedQuality = ConnectionQuality.Normal;
            var thirdAndSoOnExpectedQuality = ConnectionQuality.Good;
            var lastCallDurations = new[] { 3000, 10, 50, 100 };

            for (var i = 0; i < lastCallDurations.Length; i++)
            {
                var actualQuality = connectionQualityAnalyzer.AddCallAndAnalyzeConnection(lastCallDurations[i]);

                if (i < 2)
                {
                    Assert.AreEqual(firstExpectedQuality, actualQuality);
                }

                if (i == 2)
                {
                    Assert.AreEqual(secondExpectedQuality, actualQuality);
                }

                if (i > 2)
                {
                    Assert.AreEqual(thirdAndSoOnExpectedQuality, actualQuality);
                }
            }
        }

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void OneFailedCall_PoorConnection()
        {
            var expectedQuality = ConnectionQuality.Poor;

            var actualQuality = connectionQualityAnalyzer.AddCallAndAnalyzeConnection(0);

            Assert.AreEqual(expectedQuality, actualQuality);
        }

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void TwoFailedCalls_NoConnection()
        {
            var firstExpectedQuality = ConnectionQuality.Poor;
            var secondExpectedQuality = ConnectionQuality.No;

            var firstActualQuality = connectionQualityAnalyzer.AddCallAndAnalyzeConnection(0);
            Assert.AreEqual(firstExpectedQuality, firstActualQuality);

            var secondActualQuality = connectionQualityAnalyzer.AddCallAndAnalyzeConnection(0);
            Assert.AreEqual(secondExpectedQuality, secondActualQuality);
        }
    }
}