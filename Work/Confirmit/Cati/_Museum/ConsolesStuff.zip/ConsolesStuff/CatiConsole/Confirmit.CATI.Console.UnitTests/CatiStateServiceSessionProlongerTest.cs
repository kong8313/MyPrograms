﻿using System;
using Confirmit.CATI.Common.Exceptions;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Services.CatiService.Fakes;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class CatiStateServiceSessionProlongerTest
    {
        private CatiStateServiceSessionProlonger _prolonger;

        private StubICatiServiceManager _catiServiceManager;
        private StubIUserProperties _userProperties;
        private bool _postProcessorCalled;

        [TestInitialize()]
        public void Initialize()
        {
            var registrator = InitServiceLocator();

            _catiServiceManager = new StubICatiServiceManager();
            _userProperties = new StubIUserProperties();

            registrator.RegisterInstance<ICatiServiceManager>(_catiServiceManager);
            registrator.RegisterInstance<IUserProperties>(_userProperties);

            _postProcessorCalled = true;
            _prolonger = new CatiStateServiceSessionProlonger(PostProcessor);
        }

        [TestCleanup]
        public void Cleanup()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Cleanup();
            AsyncOperationInvoker.Instance.ClearResources();
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void ExecuteWithSessionProlongation_GivenFuncIsCalled_ProperValueIsReturned()
        {
            int expected = 432;

            var result = _prolonger.ExecuteWithSessionProlongation(() => TestFunc(expected));
            Assert.AreEqual(expected, result);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void ExecuteWithSessionProlongation_SessionHasExpired_AuthenticationKeyIsTakenFromConsoleService()
        {
            var generateCalled = false;
            UserPassport.Instance.Properties = _userProperties;
            _catiServiceManager.GenerateAuthenticationKey = () =>
            {
                generateCalled = true;
                return Guid.NewGuid();
            };

            CallAndCatchSessionExpirationException(() => { throw new StateServiceSessionExpiredException(); });
            Assert.IsTrue(generateCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void ExecuteWithSessionProlongation_SessionHasExpired_AuthenticationKeyIsStoredInUserProperties()
        {
            Guid guid = Guid.NewGuid();
            var updateCalled = false;
            _catiServiceManager.GenerateAuthenticationKey = () => guid;

            UserPassport.Instance.Properties = _userProperties;
            _userProperties.UpdateAuthenticationKeyGuid = key =>
            {
                updateCalled = true;
                Assert.AreEqual(guid, key);
            };

            CallAndCatchSessionExpirationException(() => { throw new StateServiceSessionExpiredException(); });
            Assert.IsTrue(updateCalled);
        }


        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void ExecuteWithSessionProlongation_SessionHasExpired_PostProcessorIsCalled()
        {
            UserPassport.Instance.Properties = _userProperties;
            CallAndCatchSessionExpirationException(() => { throw new StateServiceSessionExpiredException(); });

            Assert.IsTrue(_postProcessorCalled);
        }

        private void CallAndCatchSessionExpirationException(Func<int> action)
        {
            try
            {
                _prolonger.ExecuteWithSessionProlongation(action);
            }
            catch (StateServiceSessionExpiredException)
            {
            }
        }

        public int TestFunc(int i)
        {
            return i;
        }

        public void PostProcessor()
        {
            _postProcessorCalled = true;
        }

        private IServiceRegistrator InitServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            var registrator = (IServiceRegistrator)serviceLocator;
            return registrator;
        }
    }
}
