﻿using System;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Controls;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class InterviewPageBrowserTest
    {
        private InterviewPageBrowser _browser;

        [TestInitialize]
        public void TestInitialize()
        {
            _browser = new InterviewPageBrowser();
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ParsePageWith3DQuestion2SubQuestion_Success()
        {
            const string pageContent = @"<Html><Body><Form id='ctlform'>
            <input type='hidden' name='__type' id='58' questionId='q7' value='grid3D'/><div class='questionarea'>
            <TABLE class=confirmit-grid summary='Answers of q7'><TR>
            <TD class=gridcell headers=q7_header1><INPUT id=q7_3to4_1 value=1 type=checkbox name=q7_3to4_1></TD>
            <TD class=gridcell headers=q7_header2><INPUT id=q7_11to14_1 value=1 type=checkbox name=q7_11to14_1></TD>
            </TR></TABLE></DIV></form></body></Html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(1, questions.Count);
            Assert.AreEqual(2, questions[0].SubQuestions.Count);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ParsePageSingleQuestionWithOtherField_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'><input type='hidden' name='__type' id='4' questionid='sat4cm' value='single' /><div class='questionarea'>
            <fieldset id='fieldset_sat4cm'><table><tr>
            <td class='input'><input tabindex='4' type='radio' name='sat4cm' id='sat4cm_4' disabled='disabled' value='4' checked='checked' /></td>
            <td class='answerlabel'><textarea cols='75' rows='2' tabindex='5' name='sat4cm_4_other' class='confirmit-textarea other_input' id='sat4cm_4_other'>sdfasdfasdf</textarea></td>
            </tr></table></fieldset></div></form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(1, questions.Count);
            Assert.AreEqual(true, questions.HasOpenEndQuestion);
            Assert.AreEqual(true, questions[0].HasFilledOtherAnswer);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void ParsePage3DGridWithOpenTextList_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'><input type='hidden' name='__type' id='1' questionId='g52' value='grid3D'/><div class='questionarea'>
                <div id='g52_text'  class='text'>3dgrid with opentxt list</div>
                <fieldset id='fieldset_g52'>
                <table class='confirmit-grid' summary='Answers of g52'><tbody><tr><th class='gridlabel'>1</th>
                    <td headers='g52_header1' class='gridcell'><input size='30' tabindex='1' name='q53_1' class='input' id='q53_1' type='text' value=''/></td>
                    <td headers='g52_header2' class='gridcell'><input size='30' tabindex='2' name='q54_1' class='input' id='q54_1' type='text' value=''/></td>
                  </tr><tr><th class='gridlabel'>2</th>
                    <td headers='g52_header1' class='gridcell'><input size='30' tabindex='3' name='q53_2' class='input' id='q53_2' type='text' value=''/></td>
                    <td headers='g52_header2' class='gridcell'><input size='30' tabindex='4' name='q54_2' class='input' id='q54_2' type='text' value=''/></td>
                  </tr></tbody></table></fieldset></div></form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(1, questions.Count);
            Assert.AreEqual(true, questions.HasOpenEndQuestion);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ParsePageWithTwoQuestionsSingleAndOpenEndContainingOpenFontTag_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'><input type='hidden' name='__type' id='69' questionid='Dial_Outcome' value='single' /><div class='questionarea'>
            <div id='Dial_Outcome_text' class='text'><p><font><strong>Your next call...<br></strong></font>
            <font style='BACKGROUND-COLOR: #ffffff' color=#0033ff></font></p>
            <p><font></font></p><p><font></div>
            <fieldset id='fieldset_Dial_Outcome'>
            <table><tr><td class='input'><input tabindex='1' type='radio' name='Dial_Outcome' id='Dial_Outcome_0' value='0' checked='checked' /></td></tr>
            <tr><td class='input'><input tabindex='2' type='radio' name='Dial_Outcome' id='Dial_Outcome_1' value='1' /></td></tr></table>
            </fieldset></div><input type='hidden' name='__type' id='70' questionid='NumberNotes' value='open' /><div class='questionarea'>
            <fieldset id='fieldset_NumberNotes'><textarea cols='50' rows='5' tabindex='7' name='NumberNotes' class='confirmit-textarea input' id='NumberNotes'>bbbb</textarea>
            </fieldset></div></form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(2, questions.Count);
            Assert.AreEqual(QuestionType.Simple, questions[0].Type);
            Assert.AreEqual(QuestionType.Open, questions[1].Type);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ParsePageSingle_GlobalImagesOn_Success()
        {
            const string pageContent =
                @"<html><body><form class='ctlform' id='ctlform' name='ctlform'>
            <input type='hidden' name='__type' id='1' questionid='q1' value='single' /><div class='questionarea'>
            <fieldset id='fieldset_q1'><table><tr><td class='input'><input type='radio' name='q1' id='q1_3' value='3' /></td></tr></table></fieldset>
            </div><input type='hidden' name='__type' id='2' questionid='q2' value='open' /><div class='questionarea'>
            <fieldset id='fieldset_q2'><table><tr><td><textarea cols='50' rows='5' name='q2' id='q2'></textarea></td></tr></table></fieldset></div></form>
            <script>Y.WixInstance.addComponent({""type"":""ImageButtons"",""fieldsetId"":""fieldset_q1"",""questionType"":""single"",""defaultImage"":"""",""hoverImage""});</script>
            </body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(2, questions.Count);
            Assert.AreEqual(QuestionType.Simple, questions[0].Type);
            Assert.AreEqual(true, questions[0].IsImageButtons);
            Assert.AreEqual(QuestionType.Open, questions[1].Type);
            Assert.AreEqual(false, questions[1].IsImageButtons);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ParsePageSingleGlobalImagesOnPageRebuiltWithJavaScript_FindImageElements_Success()
        {
            const string pageContent =
                @"<html><BODY><FORM id=ctlform><INPUT id=1 type=hidden value=single name=__type questionId='q1'>
            <DIV class=questionarea><FIELDSET id=fieldset_q1><TABLE><TR>
            <TD class=input><A href='#'><IMG id=__q1_1_image style='HEIGHT: 16px; WIDTH: 16px' border=0 align=absMiddle src='/cf_clientutil/wix/images/radiobutton_checked_16.png' inputId='q1_1'></A>
            <INPUT id=q1_1 style='POSITION: absolute; TOP: -9000px' CHECKED type=radio value=1 name=q1 imageid='__q1_1_image'>
            </TD></TR></TABLE></FIELDSET></DIV>
            <INPUT id=2 type=hidden value=open name=__type questionId='q2'>
            <DIV class=questionarea><FIELDSET id=fieldset_q2>
            <TABLE><TR><TD class=input><TEXTAREA id=q2 class='confirmit-textarea input' rows=5 cols=50 name=q2></TEXTAREA></TD></TR></TABLE></FIELDSET>
            </DIV></FORM><SCRIPT>Y.WixInstance.addComponent({""type"":""ImageButtons"",""fieldsetId"":""fieldset_q1"",""questionType"":""single""});</SCRIPT></BODY>";

            const string firstAnswerElementId = "q1_1";

            _browser.LoadContentSync(pageContent);

            var el = new HtmlFinder(_browser.Document).Find(TagNames.IMG, "inputId", firstAnswerElementId);
            Assert.AreEqual(firstAnswerElementId, el.getAttribute("inputId").ToString());
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ParsePageSingleGlobalImagesOnPageRebuiltWithJavaScript_PageContainsImagesWithouAttributes_FindImageElements_Success()
        {
            const string pageContent =
                @"<html><BODY><FORM id=ctlform><INPUT id=2 type=hidden value=single name=__type questionId='q78'>
            <DIV class=questionarea><FIELDSET id=fieldset_q78><TABLE><TR>
            <TD><A  href='#'><IMG id=__q78_1_image style='HEIGHT: 16px; WIDTH: 16px' border=0 align=absMiddle src='/cf_clientutil/wix/images/radiobutton_checked_16.png' inputId='q78_1'>
            </A><INPUT tabIndex=1 id=q78_1 style='POSITION: absolute; TOP: -9000px' CHECKED type=radio value=1 name=q78 imageid='__q78_1_image'></TD>
            </TR></TABLE></FIELDSET> </DIV>
            <script>
            Y.WixInstance.addComponent({ ""type"": ""ImageButtons"", ""fieldsetId"": ""fieldset_q78"", ""questionType"": ""single"", ""defaultImage"": """", ""hoverImage"": """", ""selectedImage"": """", ""imageWidth"": """", ""imageHeight"": """" });
            Y.WixInstance.addComponent({ ""type"": ""LabelClick"", ""fieldsetId"": ""fieldset_q78"" });
            </script></FORM></BODY>";
            const string firstAnswerElementId = "q78_1";

            _browser.LoadContentSync(pageContent);

            var el = new HtmlFinder(_browser.Document).Find(TagNames.IMG, "inputId", firstAnswerElementId);
            Assert.AreEqual(firstAnswerElementId, el.getAttribute("inputId").ToString());
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ParsePageSingleQuestionWithOtherTextAreaField_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'><input type='hidden' name='__type' id='98' questionId='contct2' value='single'/><div class='questionarea'>
            <fieldset id='fieldset_contct2'>
            <table>
            <tr><td class='input_single'><input tabindex='1' type='radio' name='contct2' id='contct2_1' value='1'/></td></tr>
            <tr><td class='input_single'><input tabindex='5' type='radio' name='contct2' id='contct2_5' value='5'/></td>
            <td class='answerlabel'><textarea cols='50' rows='3' tabindex='6' name='contct2_5_other' id='contct2_5_other'></textarea></td></tr>
            <tr><td class='input_single'><input tabindex='13' type='radio' name='contct2' id='contct2_12' value='12'/></td></tr>
            <tr><td class='input_single'><input tabindex='14' type='radio' name='contct2' id='contct2_13' value='13'/></td>
            <td class='answerlabel'><textarea cols='50' rows='3' tabindex='15' name='contct2_13_other' id='contct2_13_other'></textarea></td></tr>
            </table></fieldset></div></form></body></html>";

            _browser.LoadContentSync(pageContent);

            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(1, questions.Count);
            Assert.AreEqual(QuestionType.Simple, questions[0].Type);
            Assert.AreEqual(4, questions[0].ActiveAnswers.Count);
            Assert.AreEqual(true, questions[0].ActiveAnswers[1].HasOther);
            Assert.AreEqual(true, questions[0].ActiveAnswers[3].HasOther);

        }

        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void ParseSoundInfo_Success()
        {
            const string pageContent =
                @"<html><body><FORM id=ctlform><INPUT id=2 value=single type=hidden name=__type questionId='q2'>
            <DIV class=questionarea>
            <INPUT value=boomer.wav alt='' type=hidden name=__soundFileName>
            <INPUT value=true alt='' type=hidden name=__autoStartPlaying>
            </DIV><FIELDSET id=fieldset_q2><TABLE>
            <TR><TD class=input><INPUT id=q2_1 tabIndex=1 value=1 type=radio name=q2></TD></TR>
            <TR><TD class=input><INPUT id=q2_2 tabIndex=2 value=2 type=radio name=q2></TD></TR>
            </TABLE></FIELDSET></FORM></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseForSoundInfo();

            Assert.AreEqual("boomer.wav", _browser.SoundFileName);
            Assert.AreEqual(true, _browser.StartPlaybackAutomatically);
        }

        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void ParseSoundInfo_HtmlContainsTwoSoundInfoBlocks_SuccessAndOnlyTheFirstBlockIsTakenIntoAccount()
        {
            const string pageContent =
                @"<html><body><FORM id=ctlform>
            <INPUT id=2 value=single type=hidden name=__type questionId='q2'>
            <INPUT value=boomer.wav alt='' type=hidden name=__soundFileName>
            <INPUT value=true alt='' type=hidden name=__autoStartPlaying>
            <INPUT value=boomer1.wav alt='' type=hidden name=__soundFileName>
            <INPUT value=false alt='' type=hidden name=__autoStartPlaying>
            <FIELDSET id=fieldset_q2></FIELDSET>
            </FORM></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseForSoundInfo();

            Assert.AreEqual("boomer.wav", _browser.SoundFileName);
            Assert.AreEqual(true, _browser.StartPlaybackAutomatically);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ParseContains2InfoAnd1Single_InfoIsDynamicQuestion_Success()
        {
            const string pageContent =
                @"<html><body><Form id='ctlform'>
            <input id='0' name='__type' value='Info' type='hidden'><div class='question'></div>
            <input id='6' name='__type' value='single' type='hidden' questionid='Q9'><div class='question'>				
            <fieldset id='fieldset_Q9'><table>								<tr>
            <td><input id='Q9_1' tabindex='1' name='Q9' value='1' checked type='radio'></td>									
            </tr></table></fieldset></div>
            <input id='0' name='__type' value='Info' type='hidden'><div class='question'>
            </div></FORM></body></html>";

            _browser.LoadContentSync(pageContent);

            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(2, questions.Count);
        }

        /// <summary>
        /// In this test the name of first subquestion is a part of names of other subquestions:
        /// E2, E2B, E2C
        /// </summary>
        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void ParseContains3DGrid_SubQuestionsHaveSpecialNames_Success()
        {
            const string pageContent =
                @"<Html><Body><Form id='ctlform'>
            <input type='hidden' name='__type' id='1' questionId='E2G' value='grid3D'/><div class='question'>
            <fieldset id='fieldset_E2G'><table><tr>
            <td headers='E2G_header1'><input size='5' tabindex='1' name='E2_1' id='E2_1' type='text' value=''/></td>
            <td headers='E2G_header2'><input size='5' tabindex='2' name='E2B_1' id='E2B_1' type='text' value=''/></td>
            <td headers='E2G_header3'><input size='5' tabindex='3' name='E2C_1' id='E2C_1' type='text' value=''/></td>
            </tr></table></fieldset></DIV></form></body></Html>";

            _browser.LoadContentSync(pageContent);

            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(1, questions.Count);
            Assert.AreEqual(3, questions[0].SubQuestions.Count);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void ParseHttp500ErrorPage_PageIsRecognizedAs500ErrorPage_Success()
        {
            const string pageContent = @"<html><body><h1>500 - INTERNAL SERVER ERROR</h1></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.ExecuteJavaScript(HtmlMonitoringAdapter.GetRegisterFunctionsScript());
            _browser.InitPageInteractor();
            _browser.ParseDocument();

            Assert.AreEqual(true, _browser.Is500ErrorPage);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void ParsePageWithForcedAppointment_ForcedAppointmentMarkIsFoundOnPage_Success()
        {
            const string pageContent = @"<html><BODY><input value=true type=hidden name=__forceappointment /></BODY></html>";

            _browser.LoadContentSync(pageContent);

            _browser.InitPageInteractor();
            _browser.ParseDocument();

            Assert.AreEqual(true, _browser.ContainsForcedAppointment);
        }

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void ParsePageWithCallTransferConfiguration_CallTransferConfigurationIsNotFoundOnPage_Success()
        {
            const string pageContent = "<html><BODY></BODY></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();

            _browser.ParseDocument();

            Assert.AreEqual(false, _browser.ContainsCallTransferConfiguration);
        }

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void ParsePageWithCallTransferConfiguration_CallTransferConfigurationIsFoundOnPage_Success()
        {
            const string pageContent = "<html><BODY><input value=\"{'Type':'0', 'TransferTarget':'i42'}\" type=hidden name=__catiCallTransferConfiguration /></BODY></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();

            _browser.ParseDocument();

            Assert.AreEqual(true, _browser.ContainsCallTransferConfiguration);
            Assert.AreEqual("{'Type':'0', 'TransferTarget':'i42'}", _browser.CallTransferConfiguration);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void ParsePagePageWithDatePicker_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='3' questionId='q10' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q10'><table><tr><td><input size='15' type='text' tabindex='23' name='q10' class='open' id='q10' value=''>
            <img class='confirmit-cal-img' src='/cf_clientutil/images/calendar_16.png' id='q10_picker'>
            <div class='confirmit-cal' id='q10_calendar'></div></fieldset></div>
            <script type='text/javascript'>
            Y.WixInstance.addComponent({""type"":""DatePicker"",""fieldsetId"":""fieldset_q10"",""questionId"":""q10""});
            </script></form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(1, questions.Count);
            Assert.AreEqual(QuestionType.DatePicker, questions[0].Type);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void DoNextQuestion_FromLastQuestion_NothingHappened()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='1' questionId='q10' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q10'><table><tr><td><input size='15' type='text' tabindex='23' name='q10' class='open' id='q10' value=''>
            </div></fieldset></div>
            <input type='hidden' name='__type' id='2' questionId='q11' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q11'><table><tr><td><input size='15' type='text' tabindex='23' name='q11' class='open' id='q11' value=''>
            </div></fieldset></div>
            </form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(2, questions.Count);

            _browser.SetDefaultActiveQuestion();
            _browser.DoQuestion(1);
            _browser.DoNextQuestion();
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void DoPreviousQuestion_FromFirstQuestion_NothingHappened()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='1' questionId='q10' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q10'><table><tr><td><input size='15' type='text' tabindex='23' name='q10' class='open' id='q10' value=''>
            </div></fieldset></div>
            <input type='hidden' name='__type' id='2' questionId='q11' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q11'><table><tr><td><input size='15' type='text' tabindex='23' name='q11' class='open' id='q11' value=''>
            </div></fieldset></div>
            </form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(2, questions.Count);

            _browser.SetDefaultActiveQuestion();
            _browser.DoPreviousQuestion();
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void DoPreviousQuestion_FromSecondQuestion_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='1' questionId='q10' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q10'><table><tr><td><input size='15' type='text' tabindex='23' name='q10' class='open' id='q10' value=''>
            </div></fieldset></div>
            <input type='hidden' name='__type' id='2' questionId='q11' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q11'><table><tr><td><input size='15' type='text' tabindex='23' name='q11' class='open' id='q11' value=''>
            </div></fieldset></div>
            <input type='hidden' name='__type' id='3' questionId='q12' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q12'><table><tr><td><input size='15' type='text' tabindex='23' name='q12' class='open' id='q12' value=''>
            </div></fieldset></div>
            </form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(3, questions.Count);

            _browser.SetDefaultActiveQuestion();
            _browser.DoQuestion(1);
            _browser.DoPreviousQuestion();

            var currentQuestion = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).CurrentQuestion;
            Assert.AreEqual(questions[0], currentQuestion);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void DoNextQuestion_FromSecondQuestion_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='1' questionId='q10' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q10'><table><tr><td><input size='15' type='text' tabindex='23' name='q10' class='open' id='q10' value=''>
            </div></fieldset></div>
            <input type='hidden' name='__type' id='2' questionId='q11' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q11'><table><tr><td><input size='15' type='text' tabindex='23' name='q11' class='open' id='q11' value=''>
            </div></fieldset></div>
            <input type='hidden' name='__type' id='3' questionId='q12' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q12'><table><tr><td><input size='15' type='text' tabindex='23' name='q12' class='open' id='q12' value=''>
            </div></fieldset></div>
            </form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(3, questions.Count);

            _browser.SetDefaultActiveQuestion();
            _browser.DoQuestion(1);
            _browser.DoNextQuestion();

            var currentQuestion = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).CurrentQuestion;
            Assert.AreEqual(questions[2], currentQuestion);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void CheckIfCurrentQuestionIsTheLast_LastOneIsInfo_Correct()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='12' questionId='q6' value='multi'><div class='questionarea'>
            <fieldset id='fieldset_q6'>
            <table ><tr><td><input tabindex='1' type='checkbox' name='q6_1' id='q6_1' value='1'></td></tr>
            <tr><td><input tabindex='2' type='checkbox' name='q6_2' id='q6_2' value='1'></td></tr></table>
            </fieldset></div>
            <input type='hidden' name='__type' id='0'  value='Info'><div class='questionarea'>text</div>
            <input type='hidden' name='__type' id='0'  value='Info'><div class='questionarea'>text</div>
            <input type='hidden' name='__type' id='0'  value='Info'><div class='questionarea'>text</div>
            <input type='hidden' name='__type' id='0'  value='Info'><div class='questionarea'>text</div>
            </form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            Assert.AreEqual(2, questions.Count);

            _browser.SetDefaultActiveQuestion();

            Assert.IsTrue(_browser.IsCurrentQuestionLast, "Last non-info question should be the last one");
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void CheckIfCurrentQuestionIsTheLast_LastOneIsNonInfo_Correct()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='1' questionId='q10' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q10'><table><tr><td><input size='15' type='text' tabindex='23' name='q10' class='open' id='q10' value=''>
            </div></fieldset></div>
            <input type='hidden' name='__type' id='2' questionId='q11' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q11'><table><tr><td><input size='15' type='text' tabindex='23' name='q11' class='open' id='q11' value=''>
            </div></fieldset></div>
            <input type='hidden' name='__type' id='3' questionId='q12' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q12'><table><tr><td><input size='15' type='text' tabindex='23' name='q12' class='open' id='q12' value=''>
            </div></fieldset></div>
            </form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();
            var questions = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).Questions;

            _browser.SetDefaultActiveQuestion();
            Assert.AreEqual(3, questions.Count);

            _browser.DoQuestion(1);
            Assert.IsFalse(_browser.IsCurrentQuestionLast, "Second question should not be the last one");

            _browser.DoQuestion(2);
            Assert.IsTrue(_browser.IsCurrentQuestionLast, "Third question should be the last one");
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void DoNextPage_AfterRedo_FastForwardClicked()
        {
            //const string pageContent = @"<!DOCTYPE html><html><body>
            //<input type='button' value='fastforward' tabindex='9996' id='forwardbutton' name='__fafwd' style='display: None !important'>
            //<input type='submit' id='forwardbutton' name='__fafwd' tabindex='9998' value='  >>  '></body></html>";

            //_browser.LoadContentSync(pageContent);
            //_browser.ParseDocument();

            //_browser.ExecuteJavaScript(@"document.getElementsByName('__fafwd')[0].onclick = function(event){
            //                                var event = event = event || window.event;
            //                                window.external.JavascriptEventHandler(event.type);
            //                                }");

            //bool nexButtonClicked;
            //string eventType = string.Empty;

            //_browser.JavascriptEvent += (sender, args) =>
            //{
            //    eventType = args.JavascriptArguments[0].ToString();
            //};

            //_browser.DoNextPage();

            //Assert.IsTrue(nexButtonClicked, "No button was found to click during DoNextPage() method");
            //Assert.AreEqual("click", eventType, "OnClick event was not fired");
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void GetPageContent_GetWithCheckedCheckbox_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='12' questionId='q6' value='multi'><div class='questionarea'>
            <fieldset id='fieldset_q6'>
            <table><tr><td><input tabindex='1' type='checkbox' name='q6_1' id='q6_1' value='1'></td></tr>
            <tr><td><input tabindex='2' type='checkbox' name='q6_2' id='q6_2' value='1'></td></tr></table>
            </fieldset></div>
            </form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.ExecuteJavaScript(HtmlMonitoringAdapter.GetRegisterFunctionsScript());
            _browser.InitPageInteractor();
            _browser.ParseDocument();

            _browser.SetDefaultActiveQuestion();
            _browser.SetAnswer("q6_1", "True");

            var content = _browser.GetPageContent();

            Assert.AreNotEqual("-1", content.IndexOf("checked", StringComparison.InvariantCultureIgnoreCase));
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void CheckIfAnswerIsDisabled_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='12' questionId='q6' value='multi'><div class='questionarea'>
            <fieldset id='fieldset_q6'>
            <table><tr><td><input tabindex='1' type='checkbox' name='q6_1' id='q6_1' value='1' disabled></td></tr>
            <tr><td><input tabindex='2' type='checkbox' name='q6_2' id='q6_2' value='1' disabled='disabled'></td></tr>
            <tr><td><input tabindex='3' type='checkbox' name='q6_3' id='q6_3' value='1'></td></tr></table>
            </fieldset></div>
            </form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();

            _browser.SetDefaultActiveQuestion();
            var currentQuestion = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).CurrentQuestion;
            Assert.AreEqual(3, currentQuestion.ActiveAnswers.Count);
            Assert.IsTrue(currentQuestion.ActiveAnswers[0].IsDisabled, "Input element contains disabled attribute");
            Assert.IsTrue(currentQuestion.ActiveAnswers[1].IsDisabled, "Input element contains disabled='disabled' attribute");
            Assert.IsFalse(currentQuestion.ActiveAnswers[2].IsDisabled, "Input element doesn't contain disabled attribute");
        }
    }
}
