using Confirmit.CATI.Console.Services.CatiService;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class InterviewPropertiesTest
    {
        [TestMethod, Owner(@"FIRM\alm")]
        public void InterviewUrlSetterTests()
        {
            InterviewUrlSetterSingleTest(initialValue: null, newValue: null, expectedValue: null);
            InterviewUrlSetterSingleTest(initialValue: null, newValue: "Url1", expectedValue: "Url1");
            InterviewUrlSetterSingleTest(initialValue: "Url1", newValue: null, expectedValue: null);

            InterviewUrlSetterSingleTest(initialValue: "", newValue: "", expectedValue: "");
            InterviewUrlSetterSingleTest(initialValue: "", newValue: "Url1", expectedValue: "Url1");
            InterviewUrlSetterSingleTest(initialValue: "Url1", newValue: "", expectedValue: "");

            InterviewUrlSetterSingleTest(initialValue: "Url1", newValue: "Url2", expectedValue: "Url2");
        }

        //[TestMethod, Owner(@"FIRM\alm")]
        public void InterviewUrlSetterSingleTest(string initialValue, string newValue, string expectedValue)
        {
            var target = new InterviewProperties
            {
                InterviewURL = initialValue
            };

            Assert.AreEqual(initialValue, target.InterviewURL,
                string.Format("InterviewURL is not initialized with the initial value /// initialValue=[{0}], newValue=[{1}], expectedValue=[{2}]",
                initialValue ?? "null", newValue ?? "null", expectedValue ?? "null"));

            target.InterviewURL = newValue;

            Assert.AreEqual(expectedValue, target.InterviewURL,
                string.Format("InterviewURL is not as expected /// initialValue=[{0}], newValue=[{1}], expectedValue=[{2}]",
                initialValue ?? "null", newValue ?? "null", expectedValue ?? "null"));
        }

        [TestMethod, Owner(@"FIRM\alm")]
        public void InterviewUrlAndSecurityIdIsEmpty_NewUrlIsSet_SecurityIdIsAsExpected()
        {
            var target = new InterviewProperties
            {
                InterviewURL = "",
            };

            const string expectedSecurityId = "1a2b3c4d5e6f7g8h9i";

            target.InterviewURL = "&__sid__=" + expectedSecurityId + "&";

            Assert.AreEqual(expectedSecurityId, target.SecurityId, ("SecurityId is not as expected"));
        }
    }
}