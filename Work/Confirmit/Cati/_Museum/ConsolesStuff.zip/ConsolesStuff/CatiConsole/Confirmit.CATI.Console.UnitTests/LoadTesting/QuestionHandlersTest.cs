﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Confirmit.CATI.Console.Classes.LoadTesting;
using Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers;
using Confirmit.CATI.Console.Views.Controls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using mshtml;

namespace Confirmit.CATI.Console.UnitTests.LoadTesting
{
    [TestClass]
    public class QuestionHandlersTest
    {
        private InterviewPageBrowser _browser;

        [TestInitialize]
        public void TestInitialize()
        {
            _browser = new InterviewPageBrowser();
        }

        [TestMethod]
        public void QuestionHandlersTest_MultiGridQuestionHandler_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='1' questionId='g8' value='grid3D'><div class='questionarea'>
            <fieldset id='fieldset_g8'><table><thead>
            <tr><th id='g8_header0' ></th>
            <th id='g8_header1' class='scale'>1</th>
            <th id='g8_header2' class='scale'>2<input size='15' tabindex='1' name='g8_2_other' class='other' id='g8_2_other' type='text' value=''></th>
            <th id='g8_header3' class='scale'>3<input size='15' tabindex='2' name='g8_3_other' class='other' id='g8_3_other' type='text' value=''></th>
            <th id='g8_header4' class='scale'>4</th>
            </tr></thead><tbody>
            <tr><td headers='g8_header1' class='gridcell'>1: <input tabindex='3' type='checkbox' name='g8_1_1' id='g8_1_1' value='1'></td>
            <td headers='g8_header2' class='gridcell'>2: <input tabindex='4' type='checkbox' name='g8_1_2' id='g8_1_2' value='1'></td>
            <td headers='g8_header3' class='gridcell'>3: <input tabindex='5' type='checkbox' name='g8_1_3' id='g8_1_3' value='1'></td>
            <td headers='g8_header4' class='gridcell'>4: <input tabindex='6' type='checkbox' name='g8_1_4' id='g8_1_4' value='1'></td>
            </tr></tbody></table></fieldset></div>";

            _browser.LoadContentSync(pageContent);

            _browser.InitPageInteractor();
            _browser.ParseDocument();

            _browser.SetDefaultActiveQuestion();

            var lines = new List<string>
            {
                "g8_2_other	g8_3_other	g8_1_1	g8_1_2	g8_1_3	g8_1_4",
                "wffsdf	dsadfasdf	1	0	1	0"
            };
            var provider = new PredefinedAnswersProvider(lines, null, 1);
            var answers = provider.GetNextInterviewAnswers().Answers;
            var handler = new MultiGridQuestionHandler(_browser, answers);
            ((IQuestionHandler)handler).SetAnswers();

            var inputs = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).CurrentQuestionInputs;
            foreach (var answerKey in answers.Keys)
            {
                var answerInput = inputs.FirstOrDefault(x => x.id.Equals(answerKey, StringComparison.OrdinalIgnoreCase));
                var htmlInputElement = (IHTMLInputElement)(answerInput);
                Assert.IsNotNull(htmlInputElement);
                if (htmlInputElement.type.Equals("checkbox", StringComparison.OrdinalIgnoreCase))
                {
                    Assert.AreEqual(answers[answerKey] == "1", htmlInputElement.@checked);
                }
                else
                {
                    Assert.AreEqual(answers[answerKey], htmlInputElement.value);
                }
            }
        }

        [TestMethod]
        public void QuestionHandlersTest_RankingQuestionHandler_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='1' questionId='q12' value='multi'><div class='questionarea'>
            <fieldset id='fieldset_q12'>
            <table  class='confirmit-table'>
            <tr><td><input size='3' tabindex='19' name='q12_1' class='number-align' id='q12_1' type='text' value=''></td></tr>
            <tr><td><input size='3' tabindex='20' name='q12_2' class='number-align' id='q12_2' type='text' value=''></td></tr>
            <tr><td><input size='3' tabindex='21' name='q12_3' class='number-align' id='q12_3' type='text' value=''></td></tr>
            <tr><td><input size='3' tabindex='22' name='q12_4' class='number-align' id='q12_4' type='text' value=''></td></tr>
            </table></fieldset></div></form></body></html>";

            _browser.LoadContentSync(pageContent);

            _browser.InitPageInteractor();
            _browser.ParseDocument();

            _browser.SetDefaultActiveQuestion();

            var lines = new List<string>
            {
                "q12_1	q12_2	q12_3	q12_4",
                "2	1	4	3"
            };
            var provider = new PredefinedAnswersProvider(lines, null, 1);

            var answers = provider.GetNextInterviewAnswers().Answers;
            var handler = new RankingQuestionHandler(_browser, answers);
            ((IQuestionHandler)handler).SetAnswers();

            var inputs = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).CurrentQuestionInputs;
            foreach (var answerKey in answers.Keys)
            {
                var answerInput = inputs.FirstOrDefault(x => x.id.Equals(answerKey, StringComparison.OrdinalIgnoreCase));
                var htmlInputElement = (IHTMLInputElement)(answerInput);
                Assert.IsNotNull(htmlInputElement);
                Assert.AreEqual(answers[answerKey], htmlInputElement.value);
            }
        }

        [TestMethod]
        public void QuestionHandlersTest_OpenQuestionHandlerWithDate_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='1' questionId='q10' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q10'><table><tr><td><input size='15' type='text' tabindex='23' name='q10' class='open' id='q10' value=''>
            <img class='confirmit-cal-img' src='/cf_clientutil/images/calendar_16.png' id='q10_picker'>
            <div class='confirmit-cal' id='q10_calendar'></div></fieldset></div>
            <script type='text/javascript'>
            Y.WixInstance.addComponent({""type"":""DatePicker"",""fieldsetId"":""fieldset_q10"",""questionId"":""q10""});
            Y.DatePicker.datePattern = ""M/d/yyyy"";
            </script></form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();

            _browser.SetDefaultActiveQuestion();

            var lines = new List<string>
            {
                "q10",
                "16.07.2015"
            };

            var provider = new PredefinedAnswersProvider(lines, null, 1);
            var answers = provider.GetNextInterviewAnswers().Answers;
            var handler = new DateQuestionHandler(_browser, answers, new CultureInfo("ru-RU"));
            ((IQuestionHandler)handler).SetAnswers();

            var inputs = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).CurrentQuestionInputs;
            var answerInput = inputs.FirstOrDefault(x => x.id.Equals("q10", StringComparison.OrdinalIgnoreCase));

            var htmlInputElement = (IHTMLInputElement)(answerInput);
            Assert.IsNotNull(htmlInputElement);
            Assert.AreEqual("7/16/2015", htmlInputElement.value);
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void QuestionHandlersTest_OpenQuestionHandlerWithDateAndWrongLocale_Exception()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='1' questionId='q10' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q10'><table><tr><td><input size='15' type='text' tabindex='23' name='q10' class='open' id='q10' value=''>
            <img class='confirmit-cal-img' src='/cf_clientutil/images/calendar_16.png' id='q10_picker'>
            <div class='confirmit-cal' id='q10_calendar'></div></fieldset></div>
            <script type='text/javascript'>
            Y.WixInstance.addComponent({""type"":""DatePicker"",""fieldsetId"":""fieldset_q10"",""questionId"":""q10""});
            Y.DatePicker.datePattern = ""M/d/yyyy"";
            </script></form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();

            _browser.SetDefaultActiveQuestion();

            var lines = new List<string>
            {
                "q10",
                "16.07.2015"
            };

            var provider = new PredefinedAnswersProvider(lines, null, 1);
            var answers = provider.GetNextInterviewAnswers().Answers;
            var handler = new DateQuestionHandler(_browser, answers, new CultureInfo("en-US"));
            ((IQuestionHandler)handler).SetAnswers();
        }

        [TestMethod]
        public void QuestionHandlersTest_OpenQuestionHandler_Success()
        {
            const string pageContent =
                @"<html><body><form id='ctlform'>
            <input type='hidden' name='__type' id='1' questionId='q10' value='open'><div class='questionarea'>
            <fieldset id='fieldset_q10'><table><tr><td><input size='15' type='text' tabindex='23' name='q10' class='open' id='q10' value=''>
            <img class='confirmit-cal-img' src='/cf_clientutil/images/calendar_16.png' id='q10_picker'>
            <div class='confirmit-cal' id='q10_calendar'></div></fieldset></div>
            </form></body></html>";

            _browser.LoadContentSync(pageContent);
            _browser.InitPageInteractor();
            _browser.ParseDocument();

            _browser.SetDefaultActiveQuestion();

            var lines = new List<string>
            {
                "q10",
                "blahblah"
            };

            var provider = new PredefinedAnswersProvider(lines, null, 1);
            var answers = provider.GetNextInterviewAnswers().Answers;
            var handler = new OpenQuestionHandler(_browser, answers);
            ((IQuestionHandler)handler).SetAnswers();

            var inputs = ((LegacySurveyPageInteractor) _browser.SurveyPageInteractor).CurrentQuestionInputs;
            var answerInput = inputs.FirstOrDefault(x => x.id.Equals("q10", StringComparison.OrdinalIgnoreCase));

            var htmlInputElement = (IHTMLInputElement)(answerInput);
            Assert.IsNotNull(htmlInputElement);
            Assert.AreEqual("blahblah", htmlInputElement.value);
        }
    }
}
