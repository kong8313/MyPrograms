﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Console.Classes.LoadTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests.LoadTesting
{
    [TestClass]
    public class PredefinedAnswersProviderTest
    {
        [TestMethod, Owner(@"FIRM\DenisM")]
        public void PredefinedAnswersProvider_OneLineInSourceGetAnswers_Success()
        {
            var list = new List<string> { "q1\tq2", "1\t2" };
            var provider = new PredefinedAnswersProvider(list, null, 1);

            var result = provider.GetNextInterviewAnswers();
            var expectedResult = new Dictionary<string, string> { { "q1", "1" }, { "q2", "2" } };
            CollectionAssert.AreEqual(expectedResult, result.Answers);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void PredefinedAnswersProvider_TwoLinesInSourceAndLoopGetAnswers_Success()
        {
            var answers = new List<string> {"responseid	q1	q2", "13	1	2", "14	1	2"};
            var loop = new List<string> {"responseid	q3	q4", "13	a	b", "13	c	d", "responseid	q3	q4", "14	a	b", "14	c	d"};
            var provider = new PredefinedAnswersProvider(answers, new List<List<string>> { loop }, 1);

            var result = provider.GetNextInterviewAnswers();
            var resultLoop = result.Loops.First();

            var keys = new[] { "responseid", "q3", "q4" };
            var expectedLoop1Answers = new List<string[]> { new[] { "13", "a", "b" }, new[] { "13", "c", "d" } };
            var expectedLoop2Answers = new List<string[]> { new[] { "14", "a", "b" }, new[] { "14", "c", "d" } };

            CollectionAssert.AreEqual(keys, resultLoop.Keys);
            CollectionAssert.AreEqual(expectedLoop1Answers[0], resultLoop.Answers[0]);
            CollectionAssert.AreEqual(expectedLoop1Answers[1], resultLoop.Answers[1]);

            result = provider.GetNextInterviewAnswers();
            resultLoop = result.Loops.First();

            CollectionAssert.AreEqual(keys, resultLoop.Keys);
            CollectionAssert.AreEqual(expectedLoop2Answers[0], resultLoop.Answers[0]);
            CollectionAssert.AreEqual(expectedLoop2Answers[1], resultLoop.Answers[1]);
            
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void PredefinedAnswersProvider_OneLineInSourceAndTwoLoopsGetAnswers_Success()
        {
            var answers = new List<string> { "responseid	q1	q2", "13	1	2" };
            var loop1 = new List<string> { "responseid	q3	q4", "13	a	b", "13	c	d" };
            var loop2 = new List<string> { "responseid	q6	q5", "13	1	2", "13	3	4" };
            var provider = new PredefinedAnswersProvider(answers, new List<List<string>> { loop1, loop2 }, 1);

            var result = provider.GetNextInterviewAnswers();
            var resultLoop = result.Loops[0];

            var keysLoop1 = new[] { "responseid", "q3", "q4" };
            var expectedLoop1Answers = new List<string[]> { new[] { "13", "a", "b" }, new[] { "13", "c", "d" } };

            CollectionAssert.AreEqual(keysLoop1, resultLoop.Keys);
            CollectionAssert.AreEqual(expectedLoop1Answers[0], resultLoop.Answers[0]);
            CollectionAssert.AreEqual(expectedLoop1Answers[1], resultLoop.Answers[1]);

            resultLoop = result.Loops[1];
            var keysLoop2 = new[] { "responseid", "q6", "q5" };
            var expectedLoop2Answers = new List<string[]> { new[] { "13", "1", "2" }, new[] { "13", "3", "4" } };

            CollectionAssert.AreEqual(keysLoop2, resultLoop.Keys);
            CollectionAssert.AreEqual(expectedLoop2Answers[0], resultLoop.Answers[0]);
            CollectionAssert.AreEqual(expectedLoop2Answers[1], resultLoop.Answers[1]);

        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void PredefinedAnswersProvider_TwoLinesInSource_Success()
        {
            var list = new List<string> { "q1\tq2", "1\t2", "3\t4" };
            var provider = new PredefinedAnswersProvider(list, null, 2);

            var result = provider.GetNextInterviewAnswers();
            var expectedResult1 = new Dictionary<string, string> { { "q1", "1" }, { "q2", "2" } };
            var expectedResult2 = new Dictionary<string, string> { { "q1", "3" }, { "q2", "4" } };
            CollectionAssert.AreEqual(expectedResult1, result.Answers);

            result = provider.GetNextInterviewAnswers();
            CollectionAssert.AreEqual(expectedResult2, result.Answers);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void PredefinedAnswersProvider_RepeatTwoTimes_Success()
        {
            var list = new List<string> { "q1\tq2", "1\t2", "3\t4" };
            var provider = new PredefinedAnswersProvider(list, null, 2);

            provider.GetNextInterviewAnswers();
            provider.GetNextInterviewAnswers();

            var result = provider.GetNextInterviewAnswers();
            var expectedResult1 = new Dictionary<string, string> { { "q1", "1" }, { "q2", "2" } };
            var expectedResult2 = new Dictionary<string, string> { { "q1", "3" }, { "q2", "4" } };
            CollectionAssert.AreEqual(expectedResult1, result.Answers);

            result = provider.GetNextInterviewAnswers();
            CollectionAssert.AreEqual(expectedResult2, result.Answers);
        }

        [TestMethod, Owner(@"FIRM\DenisM")]
        public void PredefinedAnswersProvider_HandleLastInterviewReturnedEvent_Success()
        {
            var list = new List<string> { "q1\tq2", "1\t2", "3\t4" };
            var provider = new PredefinedAnswersProvider(list, null, 2);

            bool eventWasFired = false;
            provider.LastInterviewReturned += delegate { eventWasFired = true; };

            provider.GetNextInterviewAnswers();
            provider.GetNextInterviewAnswers();
            provider.GetNextInterviewAnswers();

            Assert.IsFalse(eventWasFired);

            provider.GetNextInterviewAnswers();

            Assert.IsTrue(eventWasFired);
        }
    }
}
