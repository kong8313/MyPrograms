﻿using System;
using System.Collections.Generic;
using System.Net;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Console.Classes.Utilities.Fakes;
using Confirmit.CATI.Console.Presenters;
using Confirmit.CATI.Console.Presenters.Fakes;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Services.CatiService.Fakes;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Log.Fakes;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Shared.Utilities.Fakes;
using Confirmit.CATI.Console.Views.Classes.StatusBar;
using Confirmit.CATI.Console.Views.Interfaces.Fakes;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Console.Views.ViewInterfaces.Fakes;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;

using ConfirmitDialerInterface;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using ILogger = Confirmit.CATI.Common.ILogger;
using Timezone = Confirmit.CATI.Console.Services.CatiService.Timezone;
using Confirmit.CATI.Common.Fakes;
using Confirmit.CATI.Console.Classes.Sender;
using Confirmit.CATI.Console.Classes.Sender.Fakes;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class PresenterMainFormTest
    {
        private StubICatiServiceManager _catiServiceManager;
        private StubIAlerter _alerter;
        private StubIKeepAliver _keepAliver;
        private StubILogger _logger;
        private StubIEventSender _eventSender;
        private StubITelephonyProvider _telephonyProvider;
        private StubITaskChoiceRouter _taskChoiceRouter;
        private StubICatiServiceHelper _catiServiceHelper;
        private StubIConsoleProperties _consoleProperties;
        private StubIGetStateStopwatch _stopwatch;

        [TestInitialize]
        public void Initialize()
        {
            var registrator = InitServiceLocator();

            _catiServiceManager = new StubICatiServiceManager();
            _alerter = new StubIAlerter();
            _keepAliver = new StubIKeepAliver();
            _logger = new StubILogger();
            _eventSender = new StubIEventSender();
            _telephonyProvider = new StubITelephonyProvider();
            _taskChoiceRouter = new StubITaskChoiceRouter();
            _catiServiceHelper = new StubICatiServiceHelper();
            _consoleProperties = new StubIConsoleProperties();
            _stopwatch = new StubIGetStateStopwatch();

            registrator.RegisterInstance<IKeepAliver>(_keepAliver);
            registrator.RegisterInstance<ILogger>(_logger);
            registrator.RegisterInstance<IEventSender>(_eventSender);
            registrator.RegisterInstance<ICatiServiceManager>(_catiServiceManager);
            registrator.RegisterInstance<ICatiServiceHelper>(_catiServiceHelper);
            registrator.RegisterInstance<IAlerter>(_alerter);
            registrator.RegisterInstance<ITelephonyProvider>(_telephonyProvider);
            registrator.RegisterInstance<ITaskChoiceRouter>(_taskChoiceRouter);
            registrator.RegisterInstance<IConsoleProperties>(_consoleProperties);
            registrator.RegisterInstance<IGetStateStopwatch>(_stopwatch);

            new InitializeApplication(_logger).InitClientSettings();
        }

        [TestCleanup]
        public void Cleanup()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Cleanup();
            AsyncOperationInvoker.Instance.ClearResources();
        }

        /// <summary>
        /// Returns new instance of PresenterMainForm. All constructor parameters
        /// are mocked objects.
        /// </summary>
        /// <returns></returns>
        private PresenterMainForm GetInstance()
        {
            var presTel = new PresenterTelephony(
                new StubIViewDialControl(),
                new StubIViewHangupControl(),
                _telephonyProvider);

            return GetInstance(presTel);
        }

        private PresenterMainForm GetInstance(PresenterTelephony presTel)
        {
            var mainForm = new StubIViewMainForm();

            return GetInstanceWithOptional(frmMain: mainForm, presenterTelephony: presTel);
        }

        private PresenterMainForm GetInstanceWithOptional(
            PresenterInterview presenterInterview = null,
            PresenterTelephony presenterTelephony = null,
            PresenterMessaging presenterMessaging = null,
            IViewMainForm frmMain = null,
            IViewLoginForm frmLogin = null,
            IViewChangePasswordForm frmChange = null,
            IViewExtensionNumberForm frmExtensionNumber = null,
            IViewSurveyListControl ctlSurveyList = null,
            IViewStatusBar ctlStatusBar = null,
            IViewOnABreakControl ctlOnABreak = null,
            IConsoleDescriptionProvider consoleDescriptionProvider = null,
            IEnvironmentValidator environmentValidator = null)
        {
            environmentValidator = environmentValidator ?? new StubIEnvironmentValidator();
            presenterTelephony = presenterTelephony ?? new PresenterTelephony(
                new StubIViewDialControl(),
                new StubIViewHangupControl(),
                _telephonyProvider);
            frmLogin = frmLogin ?? new StubIViewLoginForm();
            frmMain = frmMain ?? new StubIViewMainForm();
            presenterMessaging = presenterMessaging ?? new PresenterMessaging(new StubIViewMessagingForm(), frmMain);
            ctlStatusBar = ctlStatusBar ?? new StubIViewStatusBar();
            presenterInterview = presenterInterview ?? new PresenterInterview(
                new StubIViewInterviewPageBrowser { ViewKeyboardInputGet = () => new StubIViewKeyboardInput() },
                new StubIKeyboardSupport(),
                ctlStatusBar,
                null
                );
            frmChange = frmChange ?? new StubIViewChangePasswordForm();
            frmExtensionNumber = frmExtensionNumber ?? new StubIViewExtensionNumberForm();
            ctlSurveyList = ctlSurveyList ?? new StubIViewSurveyListControl();
            ctlOnABreak = ctlOnABreak ?? new StubIViewOnABreakControl();
            consoleDescriptionProvider = consoleDescriptionProvider ?? new StubIConsoleDescriptionProvider();

            return new PresenterMainForm(
                presenterInterview,
                presenterTelephony,
                presenterMessaging,
                frmMain,
                frmLogin,
                frmChange,
                frmExtensionNumber,
                ctlSurveyList,
                ctlStatusBar,
                ctlOnABreak,
                consoleDescriptionProvider,
                environmentValidator);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void PresenterMainForm_InterviewPresenterIsNull_Exception()
        {
            var mainForm = new StubIViewMainForm();

            var form = new PresenterMainForm(
                null,
                new PresenterTelephony(
                new StubIViewDialControl(),
                new StubIViewHangupControl(),
                new StubITelephonyProvider()),
                new PresenterMessaging(new StubIViewMessagingForm(), mainForm),
                mainForm,
                new StubIViewLoginForm(),
                new StubIViewChangePasswordForm(),
                new StubIViewExtensionNumberForm(),
                new StubIViewSurveyListControl(),
                new StubIViewStatusBar(),
                new StubIViewOnABreakControl(),
                null,
                new StubIEnvironmentValidator());
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void PresenterMainForm_TelephonyPresenterIsNull_Exception()
        {
            var mainForm = new StubIViewMainForm();
            var interviewPageBrowser = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput()
            };

            var form = new PresenterMainForm(
                new PresenterInterview(
                    interviewPageBrowser,
                    new StubIKeyboardSupport(),
                    new StubIViewStatusBar(),
                    new StubIButtonsStateProvider()),
                null,
                new PresenterMessaging(new StubIViewMessagingForm(), mainForm),
                mainForm,
                new StubIViewLoginForm(),
                new StubIViewChangePasswordForm(),
                new StubIViewExtensionNumberForm(),
                new StubIViewSurveyListControl(),
                new StubIViewStatusBar(),
                new StubIViewOnABreakControl(),
                null,
                new StubIEnvironmentValidator());
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void PresenterMainForm_MainFormViewIsNull_Exception()
        {
            var mainForm = new StubIViewMainForm();
            var interviewPageBrowser = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput()
            };

            var form = new PresenterMainForm(
                new PresenterInterview(
                    interviewPageBrowser,
                    new StubIKeyboardSupport(),
                    new StubIViewStatusBar(),
                    new StubIButtonsStateProvider()),
                new PresenterTelephony(
                new StubIViewDialControl(),
                new StubIViewHangupControl(),
                new StubITelephonyProvider()),
                new PresenterMessaging(new StubIViewMessagingForm(), mainForm),
                null,
                new StubIViewLoginForm(),
                new StubIViewChangePasswordForm(),
                new StubIViewExtensionNumberForm(),
                new StubIViewSurveyListControl(),
                new StubIViewStatusBar(),
                new StubIViewOnABreakControl(),
                null,
                new StubIEnvironmentValidator());
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void PresenterMainForm_LoginFormViewIsNull_Exception()
        {
            var mainForm = new StubIViewMainForm();
            var interviewPageBrowser = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput()
            };

            var form = new PresenterMainForm(
                new PresenterInterview(
                    interviewPageBrowser,
                    new StubIKeyboardSupport(),
                    new StubIViewStatusBar(),
                    new StubIButtonsStateProvider()),
                new PresenterTelephony(
                new StubIViewDialControl(),
                new StubIViewHangupControl(),
                new StubITelephonyProvider()),
                new PresenterMessaging(new StubIViewMessagingForm(), mainForm),
                mainForm,
                null,
                new StubIViewChangePasswordForm(),
                new StubIViewExtensionNumberForm(),
                new StubIViewSurveyListControl(),
                new StubIViewStatusBar(),
                new StubIViewOnABreakControl(),
                null,
                new StubIEnvironmentValidator());
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void PresenterMainForm_ExtensionNumberFormIsNull_Exception()
        {
            var mainForm = new StubIViewMainForm();
            var interviewPageBrowser = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput()
            };

            var form = new PresenterMainForm(
                new PresenterInterview(
                    interviewPageBrowser,
                    new StubIKeyboardSupport(),
                    new StubIViewStatusBar(),
                    new StubIButtonsStateProvider()),
                new PresenterTelephony(
                new StubIViewDialControl(),
                new StubIViewHangupControl(),
                new StubITelephonyProvider()),
                new PresenterMessaging(new StubIViewMessagingForm(), mainForm),
                mainForm,
                new StubIViewLoginForm(),
                new StubIViewChangePasswordForm(),
                null,
                new StubIViewSurveyListControl(),
                new StubIViewStatusBar(),
                new StubIViewOnABreakControl(),
                null,
                new StubIEnvironmentValidator());
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void PresenterMainForm_SurveyListViewIsNull_Exception()
        {
            var mainForm = new StubIViewMainForm();
            var interviewPageBrowser = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput()
            };

            var form = new PresenterMainForm(
                new PresenterInterview(
                    interviewPageBrowser,
                    new StubIKeyboardSupport(),
                    new StubIViewStatusBar(),
                    new StubIButtonsStateProvider()),
                new PresenterTelephony(
                new StubIViewDialControl(),
                new StubIViewHangupControl(),
                new StubITelephonyProvider()),
                new PresenterMessaging(new StubIViewMessagingForm(), mainForm),
                mainForm,
                new StubIViewLoginForm(),
                new StubIViewChangePasswordForm(),
                new StubIViewExtensionNumberForm(),
                null,
                new StubIViewStatusBar(),
                new StubIViewOnABreakControl(),
                null,
                new StubIEnvironmentValidator());
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void PresenterMainForm_CorrectParameters_Success()
        {
            GetInstance();
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Login_InvalidUserPassword_Alert()
        {
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => null;

            PresenterMainForm form = GetInstance();

            var alertCalled = false;

            _alerter.AlertExceptionString = (exception, caption) =>
            {
                alertCalled = true;
            };

            form.Login(string.Empty, string.Empty, 0);
            Assert.AreEqual(true, alertCalled);
        }

        private IServiceRegistrator InitServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            var registrator = (IServiceRegistrator)serviceLocator;
            return registrator;
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Login_WebExpectionOccurs_Alert()
        {
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription = (id, name, password, companyId, description) =>
                {
                    throw new WebException();
                };
            var alertCalled = false;

            _alerter.AlertStringStringMessageTypes = (message, caption, type) =>
            {
                alertCalled = true;
            };

            var form = GetInstance();

            form.Login(string.Empty, string.Empty, 0);
            Assert.AreEqual(true, alertCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Login_InvalidOperationExpectionOccurs_Alert()
        {
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) =>
                {
                    throw new InvalidOperationException();
                };
            var alertCalled = false;

            _alerter.AlertExceptionString = (exception, caption) =>
            {
                alertCalled = true;
            };

            var form = GetInstance();

            form.Login(string.Empty, string.Empty, 0);
            Assert.IsTrue(alertCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Login_CustomExpectionOccurs_Alert()
        {
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription = (id, name, password, companyId, description) =>
                {
                    throw new Exception();
                };
            var alertCalled = false;

            _alerter.AlertExceptionString = (exception, caption) =>
            {
                alertCalled = true;
            };

            var form = GetInstance();

            form.Login(string.Empty, string.Empty, 0);
            Assert.IsTrue(alertCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Login_CorrectParameters_Success()
        {
            bool clearCalled = false, closeFormCalled = false, showRedialButtonCalled = false, keepAliveCalled = false, isLoggedInSet = false;

            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription = (id, name, password, companyId, description) =>
                {
                    Assert.AreEqual(string.Empty, name);
                    Assert.AreEqual(string.Empty, password);
                    Assert.AreEqual(1, companyId);
                    Assert.AreEqual(null, description);

                    return new UserProperties(
                        AgentTaskChoiceMode.Automatic,
                        true,
                        false,
                        new CatiConsolePropertiesContainer()
                        );
                };

            var mainForm = new StubIViewMainForm
            {
                ShowRedialButtonBoolean = show =>
                {
                    Assert.AreEqual(false, show);
                    showRedialButtonCalled = true;
                }
            };

            var loginForm = new StubIViewLoginForm
            {
                Clear = () => { clearCalled = true; },
                CloseForm = () => { closeFormCalled = true; },
                IsLoggedInSetBoolean = b =>
                {
                    Assert.AreEqual(true, b);
                    isLoggedInSet = true;
                }
            };

            _keepAliver.StartKeepAliveThreadCatiConsolePropertiesContainerSendOrPostCallbackSendOrPostCallbackSendOrPostCallback =
                (properties, callback, logoutCallback, saveKeepAliveDuration) =>
                {
                    keepAliveCalled = true;
                };

            var form = GetInstanceWithOptional(frmLogin: loginForm, frmMain: mainForm);

            form.Login(string.Empty, string.Empty, 1);

            Assert.AreEqual(true, clearCalled);
            Assert.AreEqual(true, closeFormCalled);
            Assert.AreEqual(true, keepAliveCalled);
            Assert.AreEqual(true, showRedialButtonCalled);
            Assert.AreEqual(true, isLoggedInSet);
            Assert.AreEqual(StatusBarModes.MainView, form.StatusBar.Mode);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Logout_CustomExceptionWithRestartOptionSet_RestartApplication()
        {
            _catiServiceManager.SetPendingLogoutBoolean = logout => { throw new Exception(); };

            var loginForm = new StubIViewLoginForm { IsLoggedInGet = () => true };
            var mainForm = new StubIViewMainForm();
            var restartCalled = false;
            mainForm.RestartApplication = () => { restartCalled = true; };

            var form = GetInstanceWithOptional(frmMain: mainForm, frmLogin: loginForm);

            form.Logout(true, false);

            Assert.AreEqual(true, restartCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Logout_UserIsNotLoggedIn_DoesNothing()
        {
            var loginForm = new StubIViewLoginForm { IsLoggedInGet = () => false };

            var form = GetInstanceWithOptional(frmLogin: loginForm);

            form.Logout(false, false);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Logout_UserIsLoggedIn_Success()
        {
            var loginForm = new StubIViewLoginForm { IsLoggedInGet = () => true };
            var mainForm = new StubIViewMainForm();

            var form = GetInstanceWithOptional(frmMain: mainForm, frmLogin: loginForm);

            _eventSender.ProcessEventsObjectStateChangedEventArgsMonitoringIdentity = (sender, args, id) =>
            {
                Assert.AreEqual(args.MessageType, MonitoringMessageTypes.PendingLogoutStartMessage);
            };

            form.Logout(true, false);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void StartSelectionProcess_ManualMode_Success()
        {
            var form = GetInstance();
            var manualModeCalled = false;
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription = (id, name, password, companyId, description) => new UserProperties(
                AgentTaskChoiceMode.Manual,
                true,
                false,
                new CatiConsolePropertiesContainer()
                );

            _eventSender.ProcessEventsObjectStateChangedEventArgsMonitoringIdentity = (sender, args, id) =>
            {
                Assert.AreEqual(args.MessageType, MonitoringMessageTypes.InterviewSelectingStartMessage);
            };
            _taskChoiceRouter.StartManualModeGet = () => 
            {
                return () =>  manualModeCalled = true;
            };

            form.Login(string.Empty, string.Empty, 1);
            form.StartSelectionProcess();

            Assert.IsTrue(manualModeCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void StartSelectionProcess_SurveyAssignmentMode_Success()
        {
            var form = GetInstance();
            var assignmentModeCalled = false;
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription = (id, name, password, companyId, description) => new UserProperties(
                AgentTaskChoiceMode.CampaignAssignment,
                true,
                false,
                new CatiConsolePropertiesContainer()
                );

            _eventSender.ProcessEventsObjectStateChangedEventArgsMonitoringIdentity = (sender, args, id) =>
            {
                Assert.AreEqual(args.MessageType, MonitoringMessageTypes.InterviewSelectingStartMessage);
            };
            _taskChoiceRouter.StartSurveyAssignmentModeGet = () =>
            {
                return () => assignmentModeCalled = true;
            };

            form.Login(string.Empty, string.Empty, 1);
            form.StartSelectionProcess();

            Assert.IsTrue(assignmentModeCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void StartSelectionProcess_AutomaticMode_Success()
        {
            var form = GetInstance();
            var automaticModeCalled = false;
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription = (id, name, password, companyId, description) => new UserProperties(
                AgentTaskChoiceMode.Automatic,
                true,
                false,
                new CatiConsolePropertiesContainer()
                );

            _eventSender.ProcessEventsObjectStateChangedEventArgsMonitoringIdentity = (sender, args, id) =>
            {
                Assert.AreEqual(args.MessageType, MonitoringMessageTypes.InterviewSelectingStartMessage);
            };
            _taskChoiceRouter.StartAutomaticModeGet = () =>
            {
                return () => automaticModeCalled = true;
            };

            form.Login(string.Empty, string.Empty, 1);
            form.StartSelectionProcess();

            Assert.IsTrue(automaticModeCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void StartSurveyAssignmentMode_CustomExceptionOccurs_AlertAndBindEmptyList()
        {
            var surveyList = new StubIViewSurveyListControl();
            var form = GetInstanceWithOptional(ctlSurveyList: surveyList);
            var alertCalled = false;
            var bindAndShowSurveyListCalled = false;
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription = (id, name, password, companyId, description) => new UserProperties(
                AgentTaskChoiceMode.CampaignAssignment,
                true,
                false,
                new CatiConsolePropertiesContainer()
                );

            _catiServiceManager.GetSurveys = () =>
            {
                throw new Exception();
            };
            _alerter.AlertExceptionString = (exception, caption) =>
            {
                alertCalled = true;
            };
            surveyList.EnableInterviewListBoolean = enable =>
            {
                bindAndShowSurveyListCalled = true;
            };

            form.Login(string.Empty, string.Empty, 1);

            form.StartSurveyAssignmentMode();

            Assert.AreEqual(true, bindAndShowSurveyListCalled);
            Assert.AreEqual(true, alertCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void StartSurveyAssignmentMode_SurveyListIsEmpty_BindEmptyList()
        {
            var surveyList = new StubIViewSurveyListControl();
            var form = GetInstanceWithOptional(ctlSurveyList: surveyList);
            var bindAndShowSurveyListCalled = false;
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription = (id, name, password, companyId, description) => new UserProperties(
                AgentTaskChoiceMode.CampaignAssignment,
                true,
                false,
                new CatiConsolePropertiesContainer()
                );

            _catiServiceManager.GetSurveys = () => new SurveyCollection();
            surveyList.EnableInterviewListBoolean = enable =>
            {
                bindAndShowSurveyListCalled = true;
            };

            form.Login(string.Empty, string.Empty, 1);

            form.StartSurveyAssignmentMode();

            Assert.AreEqual(true, bindAndShowSurveyListCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void StartSurveyAssignmentMode_SurveyListContainsSingleObject_StartAutomatic()
        {
            var startInterviewCalled = false;
            var surveyList = new StubIViewSurveyListControl();
            var form = GetInstanceWithOptional(ctlSurveyList: surveyList);
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription = (id, name, password, companyId, description) => new UserProperties(
                AgentTaskChoiceMode.CampaignAssignment,
                false,
                false,
                new CatiConsolePropertiesContainer()
                );

            _catiServiceManager.GetSurveys = () => new SurveyCollection(new List<Common.ConsoleService.Abstract.Survey>() { new Common.ConsoleService.Abstract.Survey() { id = "p1234567890", name = string.Empty } });
            _catiServiceManager.StartInterviewStringInt32 = (id, interviewId) =>
            {
                startInterviewCalled = true;
                return true;
            };

            form.Login(string.Empty, string.Empty, 1);

            form.StartSurveyAssignmentMode();

            Assert.AreEqual(true, startInterviewCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void UpdateAndBindRedoList_NoCurrentInterview_DoesNothing()
        {
            bool getInterviewHistoryCalled = false;
            _catiServiceManager.GetInterviewHistoryStringStringInt32 = (id, identity, languageId) =>
            {
                getInterviewHistoryCalled = true;
                return new QuestionHistoryCollection();
            };
            var presenter = GetInstance();

            presenter.UpdateAndBindRedoList();

            Assert.AreEqual(false, getInterviewHistoryCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void UpdateAndBindRedoList_EmptySID_DoesNothing()
        {
            bool getInterviewHistoryCalled = false;
            _catiServiceManager.GetInterviewHistoryStringStringInt32 = (id, identity, languageId) =>
            {
                getInterviewHistoryCalled = true;
                return new QuestionHistoryCollection();
            };

            var presenter = GetInstance();
            presenter.CurrentInterviewProperties = new InterviewProperties();

            presenter.UpdateAndBindRedoList();

            Assert.AreEqual(false, getInterviewHistoryCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void UpdateAndBindRedoList_ExceptionThrows_RestoreCursor()
        {
            bool getInterviewHistoryCalled = false;
            _catiServiceManager.GetInterviewHistoryStringStringInt32 = (id, identity, languageId) =>
            {
                Assert.AreEqual("p0000000", id);
                Assert.AreEqual("?__sid__=YTRECE", identity);
                Assert.AreEqual(0, languageId);
                getInterviewHistoryCalled = true;
                throw new Exception();
            };

            var presenter = GetInstance();
            var props = new InterviewProperties
            {
                InterviewURL = "http://localhost?__sid__=YTRECE",
                SurveyId = "p0000000"
            };
            presenter.CurrentInterviewProperties = props;

            Assert.AreEqual(null, presenter.MainForm.Cursor);

            presenter.UpdateAndBindRedoList();

            Assert.AreEqual(true, getInterviewHistoryCalled);
            Assert.AreEqual(null, presenter.MainForm.Cursor);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void UpdateAndBindRedoList_CorrectList_BindRedoList()
        {
            bool getInterviewHistoryCalled = false;
            var bindRedoListCalled = false;
            var mainForm = new StubIViewMainForm();
            mainForm.BindRedoListArrayOfString = questions =>
            {
                bindRedoListCalled = true;
            };
            _catiServiceManager.GetInterviewHistoryStringStringInt32 = (id, identity, languageId) =>
            {
                Assert.AreEqual("p0000000", id);
                Assert.AreEqual("?__sid__=YTRECE", identity);
                Assert.AreEqual(0, languageId);
                getInterviewHistoryCalled = true;
                return new QuestionHistoryCollection();
            };

            var presenter = GetInstanceWithOptional(frmMain: mainForm);
            var props = new InterviewProperties
            {
                InterviewURL = "http://localhost?__sid__=YTRECE",
                SurveyId = "p0000000"
            };
            presenter.CurrentInterviewProperties = props;

            presenter.UpdateAndBindRedoList();

            Assert.AreEqual(true, getInterviewHistoryCalled);
            Assert.AreEqual(true, bindRedoListCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void BindRedoList_ListIsNull_ExceptionThrows()
        {
            PresenterMainForm presenter = GetInstance();
            presenter.BindRedoList(null);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void BindRedoList_ListIsCorrect_FillsMainViewRedoList()
        {
            var questions = new QuestionHistoryCollection
            {
                new QuestionHistory {QuestionId = "q1", QuestionName = "name1"},
                new QuestionHistory {QuestionId = "q2", QuestionName = "name2"}
            };

            var bindRedoListCalled = false;
            var mainForm = new StubIViewMainForm
            {
                BindRedoListArrayOfString = q =>
                {
                    CollectionAssert.AreEqual(new[] { "name1", "name2" }, q);
                    bindRedoListCalled = true;
                }
            };

            var presenter = GetInstanceWithOptional(frmMain: mainForm);

            presenter.BindRedoList(questions);

            Assert.AreEqual(true, bindRedoListCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void RedoQuestion_NoSelectedQuestion_DoesNothing()
        {
            var processEventsCalled = false;
            _eventSender.ProcessEventsObjectStateChangedEventArgsMonitoringIdentity = (sender, args, id) =>
            {
                processEventsCalled = true;
            };
            var mainForm = new StubIViewMainForm
            {
                SelectedRedoQuestionGet = () => -1
            };

            var presenter = GetInstanceWithOptional(frmMain: mainForm);
            presenter.CurrentInterviewProperties = new InterviewProperties();

            presenter.RedoQuestion();

            Assert.AreEqual(false, processEventsCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void RedoQuestion_InterviewNotStarted_DoesNothing()
        {
            var processEventsCalled = false;
            _eventSender.ProcessEventsObjectStateChangedEventArgsMonitoringIdentity = (sender, args, id) =>
            {
                processEventsCalled = true;
            };
            var mainForm = new StubIViewMainForm
            {
                SelectedRedoQuestionGet = () => 0
            };

            var presenter = GetInstanceWithOptional(frmMain: mainForm);

            presenter.RedoQuestion();

            Assert.AreEqual(false, processEventsCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void RedoQuestion_QuestionSelected_CallInterviewPresenter()
        {
            var navigateCalled = false;

            var ipb = new StubIViewInterviewPageBrowser
            {
                NavigateUri = uri => { navigateCalled = true; },
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput()
            };
            var mainForm = new StubIViewMainForm
            {
                SelectedRedoQuestionGet = () => 0,
            };
            var presenterInterview = new PresenterInterview(
                ipb,
                new StubIKeyboardSupport(),
                new StubIViewStatusBar(),
                null
                );
            var presenter = GetInstanceWithOptional(frmMain: mainForm, presenterInterview: presenterInterview);
            presenter.StoredRedoQuestions = new QuestionHistoryCollection();
            presenter.StoredRedoQuestions.Add(new QuestionHistory
            {
                QuestionId = "q1",
                UrlQuery = "http://localhost/__sid__=dsa"
            });
            presenter.CurrentInterviewProperties = new InterviewProperties();
            presenter.CurrentInterviewProperties.InterviewURL = "http://localhost/__sid__=dsa";

            presenter.RedoQuestion();

            Assert.AreEqual(true, navigateCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void GenerateQuestionRedoUrl_CorrectParameters_ContainsAddressFromInterviewProps()
        {
            var presenter = GetInstance();
            var question = new QuestionHistory()
            {
                QuestionId = "q1",
                UrlQuery = "http://localhost/__sid__=dsa"
            };

            presenter.CurrentInterviewProperties = new InterviewProperties()
            {
                InterviewURL = "http://localhost/wix/p1234567.aspx?__sid__=HHYUIWE&__t=sfa"
            };
            presenter.CurrentSurveyLanguageId = 3;


            var uri = presenter.GenerateQuestionRedoUrl(question, presenter.CurrentInterviewProperties);

            Assert.AreEqual("http://localhost/wix/p1234567.aspx", uri.GetLeftPart(UriPartial.Path));
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void GenerateQuestionRedoUrl_CorrectParameters_ContainsParamsFromQeustionRedoUrl()
        {
            PresenterMainForm presenter = GetInstance();
            QuestionHistory question = new QuestionHistory()
            {
                QuestionId = "q1",
                UrlQuery = "http://localhost/__sid__=dsa&l=9"
            };

            presenter.CurrentInterviewProperties = new InterviewProperties()
            {
                InterviewURL = "http://localhost/p1234567.aspx&__sid__=fff"
            };

            var uri = presenter.GenerateQuestionRedoUrl(question, presenter.CurrentInterviewProperties);

            Assert.IsTrue(uri.Query.Contains("__sid__=dsa"));
            Assert.IsTrue(uri.Query.Contains("l=9"));
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void GenerateQuestionRedoUrl_CorrectParameters_ValidUrl()
        {
            PresenterMainForm presenter = GetInstance();
            QuestionHistory question = new QuestionHistory()
            {
                QuestionId = "q1",
                UrlQuery = "http://localhost/__sid__=dsa"
            };

            presenter.CurrentInterviewProperties = new InterviewProperties()
            {
                InterviewURL = "http://localhost/wix/p1234567.aspx?__sid__=HHYUIWE"
            };
            presenter.CurrentSurveyLanguageId = 3;

            Uri uri = presenter.GenerateQuestionRedoUrl(question, presenter.CurrentInterviewProperties);

            Assert.IsTrue(uri.IsWellFormedOriginalString());
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void StringHelper_GetStringFromEnum_InterviewState_AllValuePresentInResources()
        {
            foreach (InterviewState enumValue in Enum.GetValues(typeof(InterviewState)))
            {
                if (String.IsNullOrEmpty(StringHelper.GetStringFromEnum(enumValue)))
                {
                    Assert.Fail(enumValue.ToString());
                }
            }
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void StartInterviewing_PassNullInterview_LogoutUser()
        {
            var logoutcalled = false;
            var pres = GetInstanceWithOptional(frmLogin: new StubIViewLoginForm() { IsLoggedInGet = () => true });
            _catiServiceManager.SetPendingLogoutBoolean = logout =>
            {
                logoutcalled = true;
            };
            pres.StartInterviewing(null);

            Assert.AreEqual(true, logoutcalled);

        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void StartInterviewing_IsSurveyRecordedNotSet_AlwaysCallDeferredStartMethod()
        {
            var deferredStartCalled = false;
            _catiServiceManager.GetSurveyLanguagesString = id => new LanguageCollection();
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => new UserProperties(
                    AgentTaskChoiceMode.Automatic,
                    false,
                    false,
                    new CatiConsolePropertiesContainer()
                    );
            _eventSender.ProcessEventsObjectStateChangedEventArgsMonitoringIdentity =
                (sender, args, id) =>
                {
                    deferredStartCalled = true;
                };
            var presenterMainForm = GetInstance();
            var prop = new InterviewProperties()
            {
                InterviewId = 1,
                InterviewURL = "http://localhost/",
                IsSurveyRecorded = false,
                ProjectId = 1,
                RespondentTimezone = new Timezone(),
                SurveyId = "p1234567",
                SurveyName = "TestSurvey"
            };
            presenterMainForm.Login(string.Empty, string.Empty, 1);
            presenterMainForm.StartInterviewing(prop);

            Assert.AreEqual(true, deferredStartCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void StartInterviewing_IsSurveyRecordedIsSet_CallDeferredStartMethod()
        {
            var deferrredStartCalled = false;
            _catiServiceManager.GetSurveyLanguagesString = id => new LanguageCollection();
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => new UserProperties(
                    AgentTaskChoiceMode.Automatic,
                    false,
                    false,
                    new CatiConsolePropertiesContainer()
                    );
            _eventSender.ProcessEventsObjectStateChangedEventArgsMonitoringIdentity =
                (sender, args, id) =>
                {
                    deferrredStartCalled = true;
                };
            var presenterMainForm = GetInstance();
            var prop = new InterviewProperties()
            {
                InterviewId = 1,
                InterviewURL = "http://localhost/",
                IsSurveyRecorded = true,
                ProjectId = 1,
                RespondentTimezone = new Timezone(),
                SurveyId = "p1234567",
                SurveyName = "TestSurvey"
            };
            presenterMainForm.Login(string.Empty, string.Empty, 1);
            presenterMainForm.StartInterviewing(prop);

            Assert.AreEqual(true, deferrredStartCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void StartDeferredMonitoring_FillIdentity_Success()
        {
            PresenterMainForm pres = GetInstance();
            InterviewProperties prop = new InterviewProperties()
            {
                InterviewId = 22,
                ProjectId = 67,
                DeferredRecordId = 123213
            };

            pres.CurrentInterviewProperties = prop;
            pres.StartDeferredMonitoring();

            Assert.AreEqual(UserPassport.Instance.MonitoringIdentity.DeferredIdentity.InterviewId, prop.InterviewId);
            Assert.AreEqual(UserPassport.Instance.MonitoringIdentity.DeferredIdentity.DeferredRecordId, prop.DeferredRecordId);
            Assert.AreEqual(UserPassport.Instance.MonitoringIdentity.DeferredIdentity.SurveyId, prop.ProjectId);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void StartDeferredMonitoring_FiresStateChangedEvent_Success()
        {

            var deferrredStartCalled = false;
            PresenterMainForm pres = GetInstance();
            InterviewProperties prop = new InterviewProperties()
            {
                InterviewId = 22,
                ProjectId = 67
            };

            _eventSender.ProcessEventsObjectStateChangedEventArgsMonitoringIdentity =
                (sender, args, id) =>
                {
                    Assert.AreEqual(args.MessageType, MonitoringMessageTypes.InterviewStartMessage);
                    Assert.IsTrue(args.State is InterviewStartStateData);
                    Assert.IsTrue(((InterviewStartStateData)args.State).InterviewID == prop.InterviewId);
                    Assert.AreEqual(prop.InterviewId, id.DeferredIdentity.InterviewId);
                    Assert.AreEqual(prop.ProjectId, id.DeferredIdentity.SurveyId);

                    deferrredStartCalled = true;
                };


            pres.CurrentInterviewProperties = prop;
            pres.StartDeferredMonitoring();

            Assert.AreEqual(true, deferrredStartCalled);
        }

        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void StartPlayback_NoDialer_StartPlaybackIsNotCalled()
        {
            var startPlaybackCalled = false;
            _telephonyProvider.StartPlaybackStringInt32Out = (string file, out int seconds) =>
            {
                startPlaybackCalled = true;
                seconds = 0;
            };
            var mainForm = new StubIViewMainForm();
            var presForm = GetInstanceWithOptional(frmMain: mainForm);

            mainForm.OnStartPlayback(null);

            Assert.AreEqual(false, startPlaybackCalled);
        }

        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void PauseOrResumePlayback_NoDialer_PauseOrResumePlaybackIsNotCalled()
        {
            var pauseOrResumeCalled = false;
            _telephonyProvider.PauseOrResumePlayback = () =>
            {
                pauseOrResumeCalled = true;
            };

            var mainForm = new StubIViewMainForm();
            var presForm = GetInstanceWithOptional(frmMain: mainForm);

            mainForm.OnPauseOrResumePlayback(null);

            Assert.AreEqual(false, pauseOrResumeCalled);
        }

        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void StopPlayback_NoDialer_StopPlaybackIsNotCalled()
        {
            var stopCalled = false;
            _telephonyProvider.StopPlayback = () =>
            {
                stopCalled = true;
            };

            var mainForm = new StubIViewMainForm();
            var presForm = GetInstanceWithOptional(frmMain: mainForm);

            mainForm.OnStopPlayback(null);

            Assert.AreEqual(false, stopCalled);
        }

        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void ToggleInterviewerListensToPlaybackOrRespondent_NoDialer_ToggleInterviewerListensToPlaybackOrRespondentIsNotCalled()
        {
            var toggleCalled = false;
            _catiServiceManager.ToggleInterviewerListensToPlaybackOrRespondent = () =>
            {
                toggleCalled = true;
            };

            var mainForm = new StubIViewMainForm();
            var presForm = GetInstanceWithOptional(frmMain: mainForm);

            mainForm.OnToggleInterviewerListensToPlaybackOrRespondent(null);

            Assert.AreEqual(false, toggleCalled);
        }


        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void AutoPlaybackFoundOnQuestionPage_PreviousSoundFileIsNull_PlaybackToolbarIsShownAndStopPlaybackIsNotCalledAndStartPlaybackAreCalled()
        {
            var stopCalled = false;
            var showPlaybackToolbarCalled = false;
            var startPlaybackCalled = false;

            _telephonyProvider.StopPlayback = () => { stopCalled = true; };
            _telephonyProvider.StartPlaybackStringInt32Out = (string file, out int seconds) =>
            {
                Assert.AreEqual("A sound file", file);
                startPlaybackCalled = true;
                seconds = 0;
            };
            var props = new UserProperties(AgentTaskChoiceMode.Automatic, true, false, 1, false, false, false, true,
                true, 1, string.Empty, null, Guid.NewGuid(), new byte[] { }, new byte[] { },
                new CatiConsolePropertiesContainer());
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => props;

            var mainForm = new StubIViewMainForm();

            mainForm.ShowPlaybackToolbarBooleanBooleanBoolean = (visible, available, isAvailable) =>
            {
                showPlaybackToolbarCalled = true;
                Assert.IsTrue(visible && available && isAvailable);
            };

            var ipb = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput(),
                HasSoundInfoGet = () => true,
                SoundFileNameGet = () => "A sound file",
                StartPlaybackAutomaticallyGet = () => true
            };
            var presenterInterview = new PresenterInterview(
                ipb,
                new StubIKeyboardSupport(),
                new StubIViewStatusBar(),
                null
                );
            var presForm = GetInstanceWithOptional(frmMain: mainForm, presenterInterview: presenterInterview);

            presForm.IsDialerInSystem = true;

            presForm.Login(string.Empty, string.Empty, 1);
            ipb.OnDocumentCompleted(null);

            Assert.IsFalse(stopCalled);
            Assert.IsTrue(startPlaybackCalled);
            Assert.IsTrue(showPlaybackToolbarCalled);
        }

        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void AutoPlaybackFoundOnQuestionPage_ButNoDialer_PlaybackToolbarIsNotShownAndNeitherStopNorStartPlaybackAreCalled()
        {
            var stopCalled = false;
            var showPlaybackToolbarCalled = false;
            var startPlaybackCalled = false;

            _telephonyProvider.StopPlayback = () => { stopCalled = true; };
            _telephonyProvider.StartPlaybackStringInt32Out = (string file, out int seconds) =>
            {
                startPlaybackCalled = true;
                seconds = 0;
            };
            var props = new UserProperties(AgentTaskChoiceMode.Automatic, false, false, 1, false, false, false, true,
                true, 1, string.Empty, null, Guid.NewGuid(), new byte[] { }, new byte[] { },
                new CatiConsolePropertiesContainer());
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => props;

            var mainForm = new StubIViewMainForm();

            mainForm.ShowPlaybackToolbarBooleanBooleanBoolean = (visible, available, isAvailable) =>
            {
                showPlaybackToolbarCalled = true;
            };

            var ipb = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput(),
                HasSoundInfoGet = () => true,
                SoundFileNameGet = () => "A sound file",
                StartPlaybackAutomaticallyGet = () => true
            };
            var presenterInterview = new PresenterInterview(
                ipb,
                new StubIKeyboardSupport(),
                new StubIViewStatusBar(),
                null
                );
            var presForm = GetInstanceWithOptional(frmMain: mainForm, presenterInterview: presenterInterview);

            presForm.Login(string.Empty, string.Empty, 1);
            ipb.OnDocumentCompleted(null);

            Assert.IsFalse(stopCalled);
            Assert.IsFalse(startPlaybackCalled);
            Assert.IsFalse(showPlaybackToolbarCalled);
        }

        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void NotAutoPlaybackFoundOnQuestionPage_PreviousAndNewSoundFilesDiffer_StopPlaybackIsCalledStartPlaybackIsNotCalled()
        {
            var stopCalled = false;
            var startPlaybackCalled = false;

            _telephonyProvider.StopPlayback = () => { stopCalled = true; };
            _telephonyProvider.StartPlaybackStringInt32Out = (string file, out int seconds) =>
            {
                Assert.AreEqual("A sound file", file);
                startPlaybackCalled = true;
                seconds = 0;
            };
            var props = new UserProperties(AgentTaskChoiceMode.Automatic, true, false, 1, false, false, false, true,
                true, 1, string.Empty, null, Guid.NewGuid(), new byte[] { }, new byte[] { },
                new CatiConsolePropertiesContainer());
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => props;

            var mainForm = new StubIViewMainForm();

            var ipb = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput(),
                HasSoundInfoGet = () => true,
                SoundFileNameGet = () => "A sound file",
                StartPlaybackAutomaticallyGet = () => false
            };
            var presenterInterview = new PresenterInterview(
                ipb,
                new StubIKeyboardSupport(),
                new StubIViewStatusBar(),
                null
                );
            var presForm = GetInstanceWithOptional(frmMain: mainForm, presenterInterview: presenterInterview);

            presForm.IsDialerInSystem = true;

            presForm.Login(string.Empty, string.Empty, 1);
            ipb.OnDocumentCompleted(null);

            ipb.SoundFileNameGet = () => "A sound file 2";

            ipb.OnDocumentCompleted(null);

            Assert.IsTrue(stopCalled);
            Assert.IsFalse(startPlaybackCalled);
        }

        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void AutoPlaybackFoundOnQuestionPage_PreviousAndNewSoundFilesAreEqual_NeitherStopNorStartPlaybackAreCalled()
        {
            var stopCalled = false;
            var startPlaybackCalled = false;

            _telephonyProvider.StopPlayback = () => { stopCalled = true; };
            _telephonyProvider.StartPlaybackStringInt32Out = (string file, out int seconds) =>
            {
                Assert.AreEqual("A sound file", file);
                startPlaybackCalled = true;
                seconds = 0;
            };
            var props = new UserProperties(AgentTaskChoiceMode.Automatic, true, false, 1, false, false, false, true,
                true, 1, string.Empty, null, Guid.NewGuid(), new byte[] { }, new byte[] { },
                new CatiConsolePropertiesContainer());
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => props;

            var mainForm = new StubIViewMainForm();

            var ipb = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput(),
                HasSoundInfoGet = () => true,
                SoundFileNameGet = () => "A sound file",
                StartPlaybackAutomaticallyGet = () => false
            };
            var presenterInterview = new PresenterInterview(
                ipb,
                new StubIKeyboardSupport(),
                new StubIViewStatusBar(),
                null
                );
            var presForm = GetInstanceWithOptional(frmMain: mainForm, presenterInterview: presenterInterview);

            presForm.IsDialerInSystem = true;

            presForm.Login(string.Empty, string.Empty, 1);
            ipb.OnDocumentCompleted(null);

            ipb.OnDocumentCompleted(null);

            Assert.IsFalse(stopCalled);
            Assert.IsFalse(startPlaybackCalled);
        }

        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void PlaybackNotFoundOnQuestionPage_PreviousSoundFileIsNotNull_PlaybackToolbarIsHiddenAndStopPlaybackIsCalled()
        {
            var stopCalled = false;
            var showPlaybackToolbarCalled = false;

            _telephonyProvider.StopPlayback = () => { stopCalled = true; };
            var props = new UserProperties(AgentTaskChoiceMode.Automatic, true, false, 1, false, false, false, true,
                true, 1, string.Empty, null, Guid.NewGuid(), new byte[] { }, new byte[] { },
                new CatiConsolePropertiesContainer());
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => props;

            var mainForm = new StubIViewMainForm();

            var ipb = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput(),
                HasSoundInfoGet = () => true,
                SoundFileNameGet = () => "A sound file",
                StartPlaybackAutomaticallyGet = () => false
            };
            var presenterInterview = new PresenterInterview(
                ipb,
                new StubIKeyboardSupport(),
                new StubIViewStatusBar(),
                null
                );
            var presForm = GetInstanceWithOptional(frmMain: mainForm, presenterInterview: presenterInterview);

            presForm.IsDialerInSystem = true;

            presForm.Login(string.Empty, string.Empty, 1);
            ipb.OnDocumentCompleted(null);

            ipb.HasSoundInfoGet = () => false;
            mainForm.ShowPlaybackToolbarBooleanBooleanBoolean = (visible, available, isAvailable) =>
            {
                Assert.IsFalse(visible);
                Assert.IsTrue(available);
                Assert.IsTrue(isAvailable);
                showPlaybackToolbarCalled = true;
            };

            ipb.OnDocumentCompleted(null);

            Assert.IsTrue(stopCalled);
            Assert.IsTrue(showPlaybackToolbarCalled);
        }

        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void PlaybackNotFoundOnQuestionPage_PreviousSoundFileIsNull_PlaybackToolbarIsHiddenButStopPlaybackIsNotCalled()
        {
            var stopCalled = false;
            var showPlaybackToolbarCalled = false;

            _telephonyProvider.StopPlayback = () => { stopCalled = true; };
            var props = new UserProperties(AgentTaskChoiceMode.Automatic, true, false, 1, false, false, false, true,
                true, 1, string.Empty, null, Guid.NewGuid(), new byte[] { }, new byte[] { },
                new CatiConsolePropertiesContainer());
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => props;

            var mainForm = new StubIViewMainForm();
            mainForm.ShowPlaybackToolbarBooleanBooleanBoolean = (visible, available, isAvailable) =>
            {
                Assert.IsFalse(visible);
                Assert.IsTrue(available);
                Assert.IsTrue(isAvailable);
                showPlaybackToolbarCalled = true;
            };
            var ipb = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput(),
                HasSoundInfoGet = () => false,
                StartPlaybackAutomaticallyGet = () => false
            };
            var presenterInterview = new PresenterInterview(
                ipb,
                new StubIKeyboardSupport(),
                new StubIViewStatusBar(),
                null
                );
            var presForm = GetInstanceWithOptional(frmMain: mainForm, presenterInterview: presenterInterview);

            presForm.IsDialerInSystem = true;

            presForm.Login(string.Empty, string.Empty, 1);

            ipb.OnDocumentCompleted(null);

            Assert.IsFalse(stopCalled);
            Assert.IsTrue(showPlaybackToolbarCalled);
        }

        [TestMethod, Owner(@"FIRM\MikhailT")]
        public void PlaybackNotFoundOnQuestionPage_PreviousSoundFileIsNotEmptyButNoDialler_NeitherPlaybackToolbarIsHiddenNorStopPlaybackIsCalled()
        {
            var stopCalled = false;
            var showPlaybackToolbarCalled = false;

            _telephonyProvider.StopPlayback = () => { stopCalled = true; };
            var props = new UserProperties(AgentTaskChoiceMode.Automatic, true, false, 1, false, false, false, true,
                true, 1, string.Empty, null, Guid.NewGuid(), new byte[] { }, new byte[] { },
                new CatiConsolePropertiesContainer());
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => props;

            var mainForm = new StubIViewMainForm();

            var ipb = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput(),
                HasSoundInfoGet = () => true,
                SoundFileNameGet = () => "A sound file",
                StartPlaybackAutomaticallyGet = () => false
            };
            var presenterInterview = new PresenterInterview(
                ipb,
                new StubIKeyboardSupport(),
                new StubIViewStatusBar(),
                null
                );
            var presForm = GetInstanceWithOptional(frmMain: mainForm, presenterInterview: presenterInterview);

            presForm.Login(string.Empty, string.Empty, 1);
            presForm.IsDialerInSystem = true;

            ipb.OnDocumentCompleted(null);

            presForm.IsDialerInSystem = false;
            mainForm.ShowPlaybackToolbarBooleanBooleanBoolean = (visible, available, isAvailable) =>
            {
                showPlaybackToolbarCalled = true;
            };
            ipb.HasSoundInfoGet = () => false;
            ipb.OnDocumentCompleted(null);

            Assert.IsFalse(stopCalled);
            Assert.IsFalse(showPlaybackToolbarCalled);
        }

        [TestMethod, Owner(@"FIRM\alm")]
        public void PresenterMainForm_ThereIsNoUsualDialer_ThereIsNoCustomDialer_ChangeTaskChoiceIsEnabled()
        {
            var mainForm = new StubIViewMainForm();
            var interviewPageBrowser = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput()
            };

            var presenterTelephony = new PresenterTelephony(
                new StubIViewDialControl(),
                new StubIViewHangupControl(),
                new StubITelephonyProvider
                {
                    IsCustomDialerGet = () => false
                });

            var target = new PresenterMainForm(
                new PresenterInterview(
                    interviewPageBrowser,
                    new StubIKeyboardSupport(),
                    new StubIViewStatusBar(),
                    new StubIButtonsStateProvider()),
                presenterTelephony,
                new PresenterMessaging(new StubIViewMessagingForm(), mainForm),
                mainForm,
                new StubIViewLoginForm(),
                new StubIViewChangePasswordForm(),
                new StubIViewExtensionNumberForm(),
                new StubIViewSurveyListControl(),
                new StubIViewStatusBar(),
                new StubIViewOnABreakControl(),
                new StubIConsoleDescriptionProvider(),
                new StubIEnvironmentValidator());

            var catiConsolePropertiesContainer = new CatiConsolePropertiesContainer();
            catiConsolePropertiesContainer.EnableChangeTaskChoiceToolbarButton = true;

            target.IsDialerInSystem = false;

            UserPassport.Instance.Properties = new StubIUserProperties
            {
                ConsolePropertiesGet = () => catiConsolePropertiesContainer,
                TaskChoicePermissionsGet = () => TaskChoicePermissions.Automatic | TaskChoicePermissions.Manual
            };

            var toolbarState = target.GetToolbarState();

            Assert.IsTrue(toolbarState.IsChangeTaskChoiceEnabled);
        }

        [TestMethod, Owner(@"FIRM\alm")]
        public void PresenterMainForm_ThereIsUsualDialer_ThereIsNoCustomDialer_ChangeTaskChoiceIsNotEnabled()
        {
            var mainForm = new StubIViewMainForm();
            var interviewPageBrowser = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput()
            };

            var presenterTelephony = new PresenterTelephony(
                new StubIViewDialControl(),
                new StubIViewHangupControl(),
                new StubITelephonyProvider
                {
                    IsCustomDialerGet = () => false
                });

            var target = new PresenterMainForm(
                new PresenterInterview(
                    interviewPageBrowser,
                    new StubIKeyboardSupport(),
                    new StubIViewStatusBar(),
                    new StubIButtonsStateProvider()),
                presenterTelephony,
                new PresenterMessaging(new StubIViewMessagingForm(), mainForm),
                mainForm,
                new StubIViewLoginForm(),
                new StubIViewChangePasswordForm(),
                new StubIViewExtensionNumberForm(),
                new StubIViewSurveyListControl(),
                new StubIViewStatusBar(),
                new StubIViewOnABreakControl(),
                new StubIConsoleDescriptionProvider(), 
                new StubIEnvironmentValidator());

            var catiConsolePropertiesContainer = new CatiConsolePropertiesContainer();
            catiConsolePropertiesContainer.EnableChangeTaskChoiceToolbarButton = true;

            target.IsDialerInSystem = true;

            UserPassport.Instance.Properties = new StubIUserProperties
            {
                ConsolePropertiesGet = () => catiConsolePropertiesContainer,
                TaskChoicePermissionsGet = () => TaskChoicePermissions.Automatic | TaskChoicePermissions.Manual
            };

            var toolbarState = target.GetToolbarState();

            Assert.IsFalse(toolbarState.IsChangeTaskChoiceEnabled);
        }

        [TestMethod, Owner(@"FIRM\alm")]
        public void PresenterMainForm_ThereIsNoUsualDialer_ThereIsCustomDialer_ChangeTaskChoiceIsEnabled()
        {
            var mainForm = new StubIViewMainForm();
            var interviewPageBrowser = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput()
            };

            var presenterTelephony = new PresenterTelephony(
                new StubIViewDialControl(),
                new StubIViewHangupControl(),
                new StubITelephonyProvider
                {
                    IsCustomDialerGet = () => true
                });

            var target = new PresenterMainForm(
                new PresenterInterview(
                    interviewPageBrowser,
                    new StubIKeyboardSupport(),
                    new StubIViewStatusBar(),
                    new StubIButtonsStateProvider()),
                presenterTelephony,
                new PresenterMessaging(new StubIViewMessagingForm(), mainForm),
                mainForm,
                new StubIViewLoginForm(),
                new StubIViewChangePasswordForm(),
                new StubIViewExtensionNumberForm(),
                new StubIViewSurveyListControl(),
                new StubIViewStatusBar(),
                new StubIViewOnABreakControl(),
                new StubIConsoleDescriptionProvider(),
                new StubIEnvironmentValidator());

            var catiConsolePropertiesContainer = new CatiConsolePropertiesContainer();
            catiConsolePropertiesContainer.EnableChangeTaskChoiceToolbarButton = true;

            target.IsDialerInSystem = false;

            UserPassport.Instance.Properties = new StubIUserProperties
            {
                ConsolePropertiesGet = () => catiConsolePropertiesContainer,
                TaskChoicePermissionsGet = () => TaskChoicePermissions.Automatic | TaskChoicePermissions.Manual
            };

            var toolbarState = target.GetToolbarState();

            Assert.IsTrue(toolbarState.IsChangeTaskChoiceEnabled);
        }

        [TestMethod, Owner(@"FIRM\alm")]
        public void PresenterMainForm_ThereIsUsualDialer_ThereIsCustomDialer_ChangeTaskChoiceIsEnabled()
        {
            var mainForm = new StubIViewMainForm();
            var interviewPageBrowser = new StubIViewInterviewPageBrowser
            {
                ViewKeyboardInputGet = () => new StubIViewKeyboardInput()
            };

            var presenterTelephony = new PresenterTelephony(
                new StubIViewDialControl(),
                new StubIViewHangupControl(),
                new StubITelephonyProvider
                {
                    IsCustomDialerGet = () => true
                });

            var target = new PresenterMainForm(
                new PresenterInterview(
                    interviewPageBrowser,
                    new StubIKeyboardSupport(),
                    new StubIViewStatusBar(),
                    new StubIButtonsStateProvider()),
                presenterTelephony,
                new PresenterMessaging(new StubIViewMessagingForm(), mainForm),
                mainForm,
                new StubIViewLoginForm(),
                new StubIViewChangePasswordForm(),
                new StubIViewExtensionNumberForm(),
                new StubIViewSurveyListControl(),
                new StubIViewStatusBar(),
                new StubIViewOnABreakControl(),
                new StubIConsoleDescriptionProvider(),
                new StubIEnvironmentValidator());

            var catiConsolePropertiesContainer = new CatiConsolePropertiesContainer();
            catiConsolePropertiesContainer.EnableChangeTaskChoiceToolbarButton = true;

            target.IsDialerInSystem = true;

            UserPassport.Instance.Properties = new StubIUserProperties
            {
                ConsolePropertiesGet = () => catiConsolePropertiesContainer,
                TaskChoicePermissionsGet = () => TaskChoicePermissions.Automatic | TaskChoicePermissions.Manual
            };

            var toolbarState = target.GetToolbarState();

            Assert.IsTrue(toolbarState.IsChangeTaskChoiceEnabled);
        }
    }
}
