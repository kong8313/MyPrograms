﻿using System;
using Confirmit.CATI.Console.Presenters;
using Confirmit.CATI.Console.Services.CatiService;

using ConfirmitDialerInterface;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Services.CatiService.Fakes;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class BackendTelephonyProviderTests
    {
        private StubICatiServiceManager _catiServiceManager;

        [TestInitialize()]
        public void Initialize()
        {
            var registrator = InitServiceLocator();

            _catiServiceManager = new StubICatiServiceManager();

            registrator.RegisterInstance<ICatiServiceManager>(_catiServiceManager);
        }

        [TestCleanup]
        public void Cleanup()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Cleanup();
            AsyncOperationInvoker.Instance.ClearResources();
        }

        private IServiceRegistrator InitServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            var registrator = (IServiceRegistrator)serviceLocator;
            return registrator;
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        [ExpectedException(typeof(Exception))]
        public void Dial_ExceptionOccurs_ReturnsCustomErrorStatus()
        {
            var pres = new BackendTelephonyProvider();
            var telephonyResultCalled = false;
            pres.TelephonyResult += (sender, args) =>
            {
                telephonyResultCalled = true;
                Assert.AreEqual((int) CallOutcome.Error, args.Status);
            };

            _catiServiceManager.DialStringInitiator = (phone, initiator) => { throw new Exception(); };

            pres.Dial("123456", String.Empty);

            Assert.IsTrue(telephonyResultCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void CheckDialStatus_ExceptionHasBeenRecieved_ReturnsCustomErrorStatus()
        {
            var telephonyResultCalled = false;
            var pres = new BackendTelephonyProvider();
            var e = new GetStateEventArgs { Exception = new Exception() };
            pres.TelephonyResult += (sender, args) =>
            {
                telephonyResultCalled = true;
                Assert.AreEqual((int)CallOutcome.Error, args.Status);
            };

            pres.CheckDialStatus(e);

            Assert.IsTrue(telephonyResultCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void CheckDialStatus_TimeoutHasExpired__ReturnsCustomErrorStatus()
        {
            var telephonyResultCalled = false;
            var pres = new BackendTelephonyProvider();
            var e = new GetStateEventArgs ();
            pres.TelephonyResult += (sender, args) =>
            {
                telephonyResultCalled = true;
                Assert.AreEqual((int)CallOutcome.Error, args.Status);
            };

            pres.CheckDialStatus(e);

            Assert.IsTrue(telephonyResultCalled);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void CheckDialStatus_DialingInProgress_ContinuePolling()
        {
            var pres = new BackendTelephonyProvider();
            var e = new GetStateEventArgs
            {
                State = new ProcessState { InterviewState = InterviewState.DIALLING }
            };

            pres.CheckDialStatus(e);

            Assert.IsFalse(e.Cancel);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]        
        public void CheckDialStatus_DialingHasFinished_ReturnsCallOutcomeStatus()
        {
            var telephonyResultCalled = false;
            var pres = new BackendTelephonyProvider();
            var e = new GetStateEventArgs
            {
                State = new ProcessState
                {
                    InterviewState = InterviewState.INTERVIEWING,
                    CallOutcome = CallOutcome.Connected
                }
            };

            pres.CheckDialStatus(e);

            pres.TelephonyResult += (sender, args) =>
            {
                telephonyResultCalled = true;
                Assert.AreEqual((int)CallOutcome.Connected, args.Status);
            };

            pres.CheckDialStatus(e);

            Assert.IsTrue(e.Cancel);
            Assert.IsTrue(telephonyResultCalled);
        }

        [TestMethod, Owner(@"FIRM\SvatlanaT")]
        public void CheckDialStatus_DialingRejectedBecauseOfBlacklist_BlacklistCallOutcomeStatus()
        {
            var telephonyResultCalled = false;
            var pres = new BackendTelephonyProvider();
            var e = new GetStateEventArgs
            {
                State = new ProcessState
                {
                    InterviewState = InterviewState.INTERVIEWING,
                    CallOutcome = CallOutcome.Blacklist
                }
            };

            pres.CheckDialStatus(e);

            pres.TelephonyResult += (sender, args) =>
            {
                telephonyResultCalled = true;
                Assert.AreEqual((int)CallOutcome.Blacklist, args.Status);
            };

            pres.CheckDialStatus(e);

            Assert.IsTrue(e.Cancel);
            Assert.IsTrue(telephonyResultCalled);
        }
    }
}