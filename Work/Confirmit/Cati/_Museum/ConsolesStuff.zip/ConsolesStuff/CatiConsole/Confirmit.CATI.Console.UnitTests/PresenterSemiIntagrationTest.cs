﻿using System;
using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Console.Presenters;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Views.ViewInterfaces;

using ConfirmitDialerInterface;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Windows.Forms;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Common.Fakes;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.Sender;
using Confirmit.CATI.Console.Classes.Sender.Fakes;
using Confirmit.CATI.Console.Classes.Utilities.Fakes;
using Confirmit.CATI.Console.Presenters.Fakes;
using Confirmit.CATI.Console.Services.CatiService.Fakes;
using Confirmit.CATI.Console.Shared.Log.Fakes;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Shared.Utilities.Fakes;
using Confirmit.CATI.Console.Views.Classes.Login;
using Confirmit.CATI.Console.Views.Interfaces.Fakes;
using Confirmit.CATI.Console.Views.ViewInterfaces.Fakes;
using ILogger = Confirmit.CATI.Common.ILogger;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class PresenterSemiIntagrationTest
    {
        private StubICatiServiceManager _catiServiceManager;
        private StubIAlerter _alerter;
        private StubIKeepAliver _keepAliver;
        private StubILogger _logger;
        private StubIEventSender _eventSender;
        private StubITelephonyProvider _telephonyProvider;
        private StubITaskChoiceRouter _taskChoiceRouter;
        private StubICatiServiceHelper _catiServiceHelper;
        private StubIConsoleProperties _consoleProperties;
        private StubIGetStateStopwatch _getStateStopwatch;

        [TestInitialize()]
        public void Initialize()
        {
            var registrator = InitServiceLocator();

            _catiServiceManager = new StubICatiServiceManager();
            _alerter = new StubIAlerter();
            _keepAliver = new StubIKeepAliver();
            _logger = new StubILogger();
            _eventSender = new StubIEventSender();
            _telephonyProvider = new StubITelephonyProvider();
            _taskChoiceRouter = new StubITaskChoiceRouter();
            _catiServiceHelper = new StubICatiServiceHelper();
            _consoleProperties = new StubIConsoleProperties();
            _getStateStopwatch = new StubIGetStateStopwatch();

            registrator.RegisterInstance<IKeepAliver>(_keepAliver);
            registrator.RegisterInstance<ILogger>(_logger);
            registrator.RegisterInstance<IEventSender>(_eventSender);
            registrator.RegisterInstance<ICatiServiceManager>(_catiServiceManager);
            registrator.RegisterInstance<ICatiServiceHelper>(_catiServiceHelper);
            registrator.RegisterInstance<IAlerter>(_alerter);
            registrator.RegisterInstance<ITelephonyProvider>(_telephonyProvider);
            registrator.RegisterInstance<ITaskChoiceRouter>(_taskChoiceRouter);
            registrator.RegisterInstance<IConsoleProperties>(_consoleProperties);
            registrator.RegisterInstance<IGetStateStopwatch>(_getStateStopwatch);

            new InitializeApplication(_logger).InitClientSettings();
        }

        [TestCleanup]
        public void Cleanup()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Cleanup();
            AsyncOperationInvoker.Instance.ClearResources();
        }

        private IServiceRegistrator InitServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            var registrator = (IServiceRegistrator)serviceLocator;
            return registrator;
        }

        private PresenterMainForm GetInstanceWithOptional(
            PresenterInterview presenterInterview = null,
            PresenterTelephony presenterTelephony = null,
            PresenterMessaging presenterMessaging = null,
            IViewMainForm frmMain = null,
            IViewLoginForm frmLogin = null,
            IViewChangePasswordForm frmChange = null,
            IViewExtensionNumberForm frmExtensionNumber = null,
            IViewSurveyListControl ctlSurveyList = null,
            IViewStatusBar ctlStatusBar = null,
            IViewOnABreakControl ctlOnABreak = null,
            IConsoleDescriptionProvider consoleDescriptionProvider = null,
            IEnvironmentValidator environmentValidator = null)
        {
            environmentValidator = environmentValidator ?? new StubIEnvironmentValidator();
            presenterTelephony = presenterTelephony ?? new PresenterTelephony(
                new StubIViewDialControl(),
                new StubIViewHangupControl(),
                _telephonyProvider);
            frmLogin = frmLogin ?? new StubIViewLoginForm();
            frmMain = frmMain ?? new StubIViewMainForm();
            presenterMessaging = presenterMessaging ?? new PresenterMessaging(new StubIViewMessagingForm(), frmMain);
            ctlStatusBar = ctlStatusBar ?? new StubIViewStatusBar();
            presenterInterview = presenterInterview ?? new PresenterInterview(
                new StubIViewInterviewPageBrowser { ViewKeyboardInputGet = () => new StubIViewKeyboardInput() },
                new StubIKeyboardSupport(),
                ctlStatusBar,
                null
                );
            frmChange = frmChange ?? new StubIViewChangePasswordForm();
            frmExtensionNumber = frmExtensionNumber ?? new StubIViewExtensionNumberForm();
            ctlSurveyList = ctlSurveyList ?? new StubIViewSurveyListControl();
            ctlOnABreak = ctlOnABreak ?? new StubIViewOnABreakControl();
            consoleDescriptionProvider = consoleDescriptionProvider ?? new StubIConsoleDescriptionProvider();

            return new PresenterMainForm(
                presenterInterview,
                presenterTelephony,
                presenterMessaging,
                frmMain,
                frmLogin,
                frmChange,
                frmExtensionNumber,
                ctlSurveyList,
                ctlStatusBar,
                ctlOnABreak,
                consoleDescriptionProvider,
                environmentValidator);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void DoGetStateAndAnalyse_GetStateException_SetPendingLogout()
        {
            var presMainForm = GetInstanceWithOptional();
            var pendingLogoutCalled = false;
            _catiServiceHelper.GetState = () =>
            {
                throw new Exception();
            };
            _catiServiceManager.SetPendingLogoutBoolean = logout => { pendingLogoutCalled = true; };
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => new UserProperties(
                    AgentTaskChoiceMode.Automatic,
                    true,
                    false,
                    new CatiConsolePropertiesContainer()
                    );
            presMainForm.GetStateWsErrorElapsed.Start();
            _consoleProperties.GetStateWsErrorTimeoutGet = () => -1;

            presMainForm.Login(string.Empty, string.Empty, 1);
            presMainForm.DoGetStateAndAnalyse();
            Assert.IsTrue(pendingLogoutCalled);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void
            DoGetStateAndAnalyse_InterviewStateInterviewingInterviewerLoginStateLoggedInCorrectURL_StartInterview()
        {
            _consoleProperties.EnableServerLogGet = () => false;
            var ipbStub = new StubIViewInterviewPageBrowser { ViewKeyboardInputGet = () => new StubIViewKeyboardInput() };
            var presenterInterview = new PresenterInterview(
                ipbStub,
                new StubIKeyboardSupport(),
                new StubIViewStatusBar(),
                null
                );
            var navigateCalled = false;
            ipbStub.NavigateUri = uri =>
            {
                navigateCalled = true;
            };
            var presMainForm = GetInstanceWithOptional(presenterInterview);
            _catiServiceHelper.GetState = () => new ProcessState()
            {
                interviewerLoginState = LoginState.LOGGED_IN,
                InterviewState = InterviewState.INTERVIEWING,
                InterviewProperties = new InterviewProperties()
                {
                    SurveyId = "0",
                    InterviewId = 1,
                    InterviewURL = "http://localhost/confirmit/default.aspx",
                    SurveyName = "TestSurvey"
                }
            };
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => new UserProperties(
                    AgentTaskChoiceMode.Automatic,
                    true,
                    false,
                    new CatiConsolePropertiesContainer()
                    );

            presMainForm.Login(string.Empty, string.Empty, 1);
            presMainForm.DoGetStateAndAnalyse();

            Assert.IsTrue(navigateCalled);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void
            DoGetStateAndAnalyse_InterviewStateInterviewingInterviewerLoginStateLoggedInIncorrectURL_ContinueProcessingCycle
            ()
        {
            var showProcessControllCalled = false;
            var mainForm = new StubIViewMainForm
            {
                ShowProcessControlStringBooleanBoolean =
                    (message, enabled, breakEnabled) => { showProcessControllCalled = true; }
            };
            var presMainForm = GetInstanceWithOptional(frmMain: mainForm);
            _consoleProperties.EnableServerLogGet = () => false;
            _catiServiceHelper.GetState = () => new ProcessState()
            {
                interviewerLoginState = LoginState.LOGGED_IN,
                InterviewState = InterviewState.INTERVIEWING,
                InterviewProperties = new InterviewProperties()
                {
                    SurveyId = "0",
                    InterviewId = 1,
                    InterviewURL = "invalid url"
                }
            };
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => new UserProperties(
                    AgentTaskChoiceMode.Automatic,
                    true,
                    false,
                    new CatiConsolePropertiesContainer()
                    );

            presMainForm.Login(string.Empty, string.Empty, 1);
            presMainForm.DoGetStateAndAnalyse();

            Assert.IsTrue(showProcessControllCalled);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void DoGetStateAndAnalyse_NoCallsTimeoutExpiredAndUserConfirmLogout_Logout()
        {
            var pendingLogoutCalled = false;
            var presMainForm = GetInstanceWithOptional();
            _consoleProperties.EnableServerLogGet = () => false;
            _catiServiceHelper.GetState = () => new ProcessState()
            {
                interviewerLoginState = LoginState.LOGGED_IN,
                InterviewState = InterviewState.NO_CALLS,
                InterviewProperties = new InterviewProperties()
                {
                    SurveyId = "0",
                    InterviewId = 1
                }
            };
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => new UserProperties(
                    AgentTaskChoiceMode.Automatic,
                    true,
                    false,
                    new CatiConsolePropertiesContainer { NoCallsTimeout = -1 }
                    );
            _catiServiceManager.SetPendingLogoutBoolean = logout => { pendingLogoutCalled = true; };

            presMainForm.Login(string.Empty, string.Empty, 1);

            presMainForm.PreviousInterviewState = InterviewState.NO_CALLS;

            presMainForm.DoGetStateAndAnalyse();

            Assert.IsTrue(pendingLogoutCalled);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void DoGetStateAndAnalyse_NoCallsTimeoutExpiredAndUserChooseRetry_CallStartInterviewAndContinueCycle()
        {
            var restartCalled = false;
            var presMainForm = GetInstanceWithOptional();
            _consoleProperties.EnableServerLogGet = () => false;
            _catiServiceHelper.GetState = () => new ProcessState()
            {
                interviewerLoginState = LoginState.LOGGED_IN,
                InterviewState = InterviewState.NO_CALLS,
                InterviewProperties = new InterviewProperties()
                {
                    SurveyId = "0",
                    InterviewId = 1
                }
            };
            _alerter.AlertRetryConfirmationStringString = (message, caption) => DialogResult.Retry;
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => new UserProperties(
                    AgentTaskChoiceMode.Automatic,
                    true,
                    false,
                    new CatiConsolePropertiesContainer { NoCallsTimeout = -1 }
                    );
            _getStateStopwatch.Restart = () => { restartCalled = true; };

            presMainForm.Login(string.Empty, string.Empty, 1);

            presMainForm.PreviousInterviewState = InterviewState.NO_CALLS;

            presMainForm.DoGetStateAndAnalyse();

            Assert.IsTrue(restartCalled);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void DoGetStateAndAnalyse_FirstNoCallsStateOccurance_RestartNoCallsTimeout()
        {
            var restartCalled = false;
            var presMainForm = GetInstanceWithOptional();
            _consoleProperties.EnableServerLogGet = () => false;
            _catiServiceHelper.GetState = () => new ProcessState()
            {
                interviewerLoginState = LoginState.LOGGED_IN,
                InterviewState = InterviewState.NO_CALLS,
                InterviewProperties = new InterviewProperties()
                {
                    SurveyId = "0",
                    InterviewId = 1
                }
            };
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => new UserProperties(
                    AgentTaskChoiceMode.Automatic,
                    true,
                    false,
                    new CatiConsolePropertiesContainer()
                    );
            _getStateStopwatch.Restart = () => { restartCalled = true; };

            presMainForm.Login(string.Empty, string.Empty, 1);

            presMainForm.PreviousInterviewState = InterviewState.SELECTING;

            presMainForm.DoGetStateAndAnalyse();

            Assert.IsTrue(restartCalled);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void DoGetStateAndAnalyse_InterviewerLoginStateNotLoggedInWithoutPendingLogout_RestartApplication()
        {
            var restartCalled = false;
            var mainForm = new StubIViewMainForm();
            var presMainForm = GetInstanceWithOptional(frmMain: mainForm);
            _consoleProperties.EnableServerLogGet = () => false;
            _catiServiceHelper.GetState = () => new ProcessState()
            {
                interviewerLoginState = LoginState.NOT_LOGGED_IN,
                InterviewProperties = new InterviewProperties()
                {
                    SurveyId = "0",
                    InterviewId = 1
                }
            };

            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => new UserProperties(
                    AgentTaskChoiceMode.Automatic,
                    true,
                    false,
                    new CatiConsolePropertiesContainer()
                    );
            mainForm.RestartApplication = () => { restartCalled = true; };

            presMainForm.Login(string.Empty, string.Empty, 1);

            presMainForm.PreviousInterviewState = InterviewState.SELECTING;

            presMainForm.DoGetStateAndAnalyse();

            Assert.IsTrue(restartCalled);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void DoGetStateAndAnalyse_SelectingStateInManulMode_StartManualMode()
        {
            var mainForm = new StubIViewMainForm();
            var presMainForm = GetInstanceWithOptional(frmMain: mainForm);
            _consoleProperties.EnableServerLogGet = () => false;
            _catiServiceHelper.GetState = () => new ProcessState()
            {
                interviewerLoginState = LoginState.LOGGED_IN,
                InterviewState = InterviewState.SELECTING,
                InterviewProperties = new InterviewProperties()
                {
                    SurveyId = "0",
                    InterviewId = 1
                }
            };

            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => new UserProperties(
                    AgentTaskChoiceMode.Manual,
                    true,
                    false,
                    new CatiConsolePropertiesContainer()
                    );

            presMainForm.Login(string.Empty, string.Empty, 1);
            var startManualMode = false;
            _taskChoiceRouter.StartManualModeGet = () =>
            {
                return () => startManualMode = true;
            };

            presMainForm.DoGetStateAndAnalyse();
            Assert.IsTrue(startManualMode);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void DoGetStateAndAnalyse_SelectingStateInNoManulMode_Logout()
        {
            var logoutCalled = false;
            var presMainForm = GetInstanceWithOptional();
            _consoleProperties.EnableServerLogGet = () => false;
            _catiServiceHelper.GetState = () => new ProcessState()
            {
                interviewerLoginState = LoginState.LOGGED_IN,
                InterviewState = InterviewState.SELECTING,
                InterviewProperties = new InterviewProperties()
                {
                    SurveyId = "0",
                    InterviewId = 1
                }
            };

            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => new UserProperties(
                    AgentTaskChoiceMode.Automatic,
                    true,
                    false,
                    new CatiConsolePropertiesContainer()
                    );

            presMainForm.Login(string.Empty, string.Empty, 1);

            _catiServiceManager.SetPendingLogoutBoolean = logout => { logoutCalled = true; };

            presMainForm.DoGetStateAndAnalyse();
            Assert.IsTrue(logoutCalled);
        }

        /// <summary>
        /// When LoginToDialer result in error, ask user about retry or cancel,
        /// In retry case start login to dialer again.
        /// </summary>
        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void LoginToDialerErrorEventHandler_SkipLoginToDialler_StartProcess()
        {
            var e = new GetStateEventArgs
            {
                State = new ProcessState
                {
                    interviewerLoginState = LoginState.NOT_LOGGED_IN,
                    LoginToDialerState = LoginState.NOT_LOGGED_IN
                }
            };
            var startInterviewCalled = false;
            _catiServiceManager.StartInterviewStringInt32 = (id, interviewId) =>
            {
                startInterviewCalled = true;
                return true;
            };

            var mainForm = new StubIViewMainForm();
            mainForm.ShowExtensionNumberForm = () => LoginToDiallerResult.SkipLoginToDialler;
            var presMainForm = GetInstanceWithOptional(frmMain: mainForm);
            _catiServiceManager.LoginStringStringStringInt32ConsoleDescription =
                (id, name, password, companyId, description) => new UserProperties(
                    AgentTaskChoiceMode.Manual,
                    true,
                    false,
                    new CatiConsolePropertiesContainer()
                    );

            presMainForm.Login(string.Empty, string.Empty, 1);
            presMainForm.LoginToDialerErrorEventHandler(e);
            Assert.IsTrue(startInterviewCalled);
        }
    }
}
