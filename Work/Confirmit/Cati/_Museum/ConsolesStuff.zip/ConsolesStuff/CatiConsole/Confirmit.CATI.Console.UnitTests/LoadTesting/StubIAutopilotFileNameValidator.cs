using System;
using Confirmit.CATI.Console.Classes.LoadTesting;

namespace Confirmit.CATI.Console.UnitTests.LoadTesting
{
    public class StubIAutopilotFileNameValidator : IAutoPilotFileNameValidator
    {
        public void ValidateFileName(string fileName)
        {
            if (ValidateFileNameAction != null)
            {
                ValidateFileNameAction(fileName);
            }
        }

        public Action<string> ValidateFileNameAction;
    }
}