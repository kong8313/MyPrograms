using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Common.ConsoleService.Abstract;

namespace Confirmit.CATI.Console.UnitTests
{
    internal class TestConsoleDescriptionProvider : IConsoleDescriptionProvider
    {
        public ConsoleDescription GetConsoleDescription()
        {
            return new ConsoleDescription();
        }

        public string GetConsoleDescriptionText()
        {
            return string.Empty;
        }
    }
}