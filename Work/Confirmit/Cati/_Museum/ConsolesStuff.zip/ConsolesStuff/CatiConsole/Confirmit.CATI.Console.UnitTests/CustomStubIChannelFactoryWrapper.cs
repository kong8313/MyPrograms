﻿using System;
using Confirmit.CATI.Common.WcfTools;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using Confirmit.CATI.Common.ConsoleService;
using Confirmit.CATI.Common.ServiceLocation;

namespace Confirmit.CATI.Console.UnitTests
{
    public class CustomStubIChannelFactoryWrapper<T> : IChannelFactoryWrapper<T> where T : class
    {
        private IChannelFactoryWrapper<T> _inner;

        public CustomStubIChannelFactoryWrapper()
        {
            _inner = null;
        }

        public IChannelFactoryWrapper<T> Inner
        {
            set { _inner = value; }
            get { return _inner; }
        }

        public delegate T GetChannelDelegate();
        public GetChannelDelegate GetChannel;

        T IChannelFactoryWrapper<T>.GetChannel()
        {


            if (GetChannel != null)
            {
                return GetChannel();
            }
            else if (_inner != null)
            {
                return ((IChannelFactoryWrapper<T>)_inner).GetChannel();
            }

            return default(T);
        }

        public delegate Uri GetFactoryUriDelegate();
        public GetFactoryUriDelegate GetFactoryUri;

        Uri IChannelFactoryWrapper<T>.GetFactoryUri()
        {


            if (GetFactoryUri != null)
            {
                return GetFactoryUri();
            }
            else if (_inner != null)
            {
                return ((IChannelFactoryWrapper<T>)_inner).GetFactoryUri();
            }

            return default(Uri);
        }

        public delegate void ReleaseDelegate();
        public ReleaseDelegate Release;

        void IChannelFactoryWrapper<T>.Release()
        {

            if (Release != null)
            {
                Release();
            }
            else if (_inner != null)
            {
                ((IChannelFactoryWrapper<T>)_inner).Release();
            }
        }

        public delegate void ExecuteExpressionOfActionOfTDelegate(Action<T> action);
        public ExecuteExpressionOfActionOfTDelegate ExecuteExpressionOfActionOfT;

        void IChannelFactoryWrapper<T>.Execute(Action<T> action, string methodName)
        {

            if (ExecuteExpressionOfActionOfT != null)
            {
                ExecuteExpressionOfActionOfT(action);
            }
            else if (_inner != null)
            {
                ((IChannelFactoryWrapper<T>)_inner).Execute(action, methodName);
            }
        }
        
        public Func<Expression<Func<T, object>>, object> ExecuteExpressionOfFunctionOfT;

        TResult IChannelFactoryWrapper<T>.Execute<TResult>(Func<T, TResult> function, string methodName)
        {
            if (ExecuteExpressionOfFunctionOfT != null)
            {
                return (TResult)ExecuteExpressionOfFunctionOfT( arg => function.Invoke(arg));
            }

            if (_inner != null)
            {
                return ((IChannelFactoryWrapper<T>)_inner).Execute(function, methodName);
            }
            
            return default(TResult);
        }
    }
}