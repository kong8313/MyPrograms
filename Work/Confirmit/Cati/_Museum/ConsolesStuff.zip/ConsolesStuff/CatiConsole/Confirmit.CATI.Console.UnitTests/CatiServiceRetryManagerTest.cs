﻿using System;
using Confirmit.CATI.Console.Services.CatiService;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Confirmit.CATI.Common.Exceptions;
using System.ServiceModel;
using Confirmit.CATI.Common;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class CatiServiceRetryManagerTest
    {
        #region Utility methods

        /// <summary>
        /// Represents class which is used to test cases for FaultException UserMessageExceptionDetails exception.
        /// </summary>
        class TestFaultGenericException : FaultException<UserMessageExceptionDetails>
        {
            public TestFaultGenericException()
                : base(new UserMessageExceptionDetails())
            {
            }
        }

        /// <summary>
        /// Represents class which is used to test cases for FaultException.
        /// </summary>
        /// <typeparam name="T">Faul code type.</typeparam>
        class TestFaultCodeException<T> : FaultException
            where T : FaultCode, new()
        {
            public TestFaultCodeException()
                : base(String.Empty, new T())
            {
            }
        }

        class TestSupportedFaultCode : FaultCode
        {
            public TestSupportedFaultCode()
                : base(Constants.InternalServerErrorFaultCode)
            {
            }
        }

        class TestUnsupportedFaultCode : FaultCode
        {
            public TestUnsupportedFaultCode()
                : base(Constants.InternalServerErrorFaultCode + "123")
            {
            }
        }

        private void TestFunction(ref int checkValue, int counter)
        {
            checkValue = counter;
        }

        /// <summary>
        /// Throws exception of given type given times.
        /// </summary>
        /// <typeparam name="TException">Exception to throw.</typeparam>
        /// <param name="checkValue">Value to check results.</param>
        /// <param name="counter">Iteration counter.</param>
        /// <param name="maxIterToThrow">Till this iteration exception will be thrown.</param>
        private void TestFunctionWithException<TException>(ref int checkValue, int counter, int maxIterToThrow)
            where TException : Exception, new()
        {
            checkValue = counter;
            if (counter <= maxIterToThrow)
            {
                throw new TException();
            }
        }

        private void TestFunctionWithException<TException1, TException2>(ref int checkValue, int counter, int timesFirstThrown, int timesSecondThrown)
            where TException1 : Exception, new()
            where TException2 : Exception, new()
        {
            checkValue = counter;
            if (counter <= timesFirstThrown)
            {
                throw new TException1();
            }
            else if (timesFirstThrown < counter && counter <= timesFirstThrown + timesSecondThrown)
            {
                throw new TException2();
            }
        }

        private void InvokeMethodAndVerifyExceptionThrown<T>(Action action) where T : Exception
        {
            try
            {
                action.Invoke();
            }
            catch (T)
            {
                return;
            }

            Assert.Fail("Exception wasn't thrown. Expected exception with type {0}", typeof(T));
        }

        #endregion

        [TestInitialize]
        public void TestInitialize()
        {
            Properties.Settings.Default.CatiServiceRetrySleepTimeout = 10;
        }

        [TestCleanup]
        public void TestCleanup()
        {
            Properties.Settings.Default.CatiServiceRetrySleepTimeout = 500;
        }

        /// <summary>
        /// Invokes function only once successfully.
        /// </summary>
        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Invoke_SingleCallWithoutExceptions_Success()
        {
            int checkValue = 0;
            
            CatiServiceRetryManager.Invoke((counter) => TestFunction(ref checkValue, counter), false);

            Assert.AreEqual(1, checkValue, "Function was executed more than once");
        }

        /// <summary>
        /// 1. Cati repeated setting is set to 3.
        /// 2. First function call generates ArgumentException. Exception should be suppressed.
        /// 3. Second function call generates ArgumentException. Exception should be suppressed.
        /// 4. Third function call succeeds.
        /// </summary>
        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Invoke_TwoIterationWithNotCatiException_Success()
        {
            int checkValue = 0;

            CatiServiceRetryManager.Invoke((counter) => TestFunctionWithException<ArgumentException>(ref checkValue, counter, 2), false);

            Assert.AreEqual(3, checkValue);
        }

        /// <summary>
        /// 1. Cati repeated setting is set to 3.
        /// 2. Function throws not FaultException during all iterations.
        /// 3. Not Cati exception should be rethrown on 4-th iteration.
        /// </summary>
        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Invoke_NotFaultExceptionIsThrownAllTheTime_ExceptionIsRethrownAfterExceedingRetryCounter()
        {
            int checkValue = 0;

            InvokeMethodAndVerifyExceptionThrown<ArgumentException>(
                () => CatiServiceRetryManager.Invoke((counter) => TestFunctionWithException<ArgumentException>(ref checkValue, counter, 100), false)
            );

            Assert.AreEqual(4, checkValue);
        }

        /// <summary>
        /// 1. Function throws <code>FaultException<UserMessageExceptionDetails></code> at first iteration.
        /// 2. Exception should be rethrown immediately.
        /// </summary>
        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Invoke_FaultGenericExceptionIsThrown_ExceptionIsRethrownAtFirstIteration()
        {
            int checkValue = 0;

            InvokeMethodAndVerifyExceptionThrown<TestFaultGenericException>(
                () => CatiServiceRetryManager.Invoke((counter) => TestFunctionWithException<TestFaultGenericException>(ref checkValue, counter, 3), false)
            );

            Assert.AreEqual(1, checkValue);
        }

        /// <summary>
        /// 1. Function throws FaultException with supported fault code at first iteration.
        /// 2. Exception should be rethrown immediately.
        /// </summary>
        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Invoke_FaultCodeExceptionWitnSupportedCodeIsThrown_ExceptionIsRethrownAtFirstIteration()
        {
            int checkValue = 0;

            InvokeMethodAndVerifyExceptionThrown<TestFaultCodeException<TestSupportedFaultCode>>(
                () => CatiServiceRetryManager.Invoke(
                    (counter) => TestFunctionWithException<TestFaultCodeException<TestSupportedFaultCode>>(ref checkValue, counter, 3), false
                )
            );

            Assert.AreEqual(1, checkValue);
        }

        /// <summary>
        /// 1. Function throws FaultException with supported fault code at first iteration.
        /// 2. Exception should be rethrown immediately.
        /// </summary>
        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Invoke_FaultCodeExceptionWitnUnsupportedCodeIsThrown_ExceptionIsRethrownAfterExceedingRetryCounter()
        {
            int checkValue = 0;

            InvokeMethodAndVerifyExceptionThrown<TestFaultCodeException<TestUnsupportedFaultCode>>(
                () => CatiServiceRetryManager.Invoke(
                    (counter) => TestFunctionWithException<TestFaultCodeException<TestUnsupportedFaultCode>>(ref checkValue, counter, 100), false
                )
            );

            Assert.AreEqual(4, checkValue);
        }

        /// <summary>
        /// 1. Two times CommunicationException is thrown. Processing should be continued.
        /// 2. FaultException is thrown. Should be rethrown immediately.
        /// </summary>
        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Invoke_TwoNotFaultAndSingleFault_FaultExceptionIsRethrown()
        {
            int checkValue = 0;

            InvokeMethodAndVerifyExceptionThrown<TestFaultGenericException>(
                ()=> CatiServiceRetryManager.Invoke(
                    (counter) => TestFunctionWithException<CommunicationException, TestFaultGenericException>(ref checkValue, counter, 2, 100), false
                )
            );

            Assert.AreEqual(3, checkValue);
        }
    }
}
