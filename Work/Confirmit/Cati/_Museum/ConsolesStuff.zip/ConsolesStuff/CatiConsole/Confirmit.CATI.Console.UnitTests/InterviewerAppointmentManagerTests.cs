﻿using System;
using System.Linq;
using Confirmit.CATI.Common;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Console.Services.CatiService;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class InterviewerAppointmentManagerTests
    {
        [TestMethod, Owner(@"FIRM\DenisM")]
        public void InterviewerAppointmentManager_PrepareAppointmentsForBinding_Success()
        {
            var interviewerAppointmens = new AppointmentCollection();
            
            var appointmentTime = new DateTime(2014, 1, 1, 7, 30, 0, DateTimeKind.Utc);
            var expirationTime = appointmentTime.AddDays(1);

            TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("W. Europe Standard Time");
            var timezoneRespondent = new Timezone
            {
                Bias = -60,
                DaylightBias = -60,
                DaylightName = "Timezone 1",
                DaylightType = DaylightType.Disable,
                Id = 1,
                Name = "Timezone 1",
                StandardBias = 0,
                StandardName = "Timezone 1"
            };

            interviewerAppointmens.Add(new Appointment(1, "Name", appointmentTime, expirationTime)
            {
                Timezone = timezoneRespondent,
                ProjectID = "p00001",
                InterviewId = 33,
                ProjectName = "Project Name"
            });

            var appointments = InterviewerAppointmentManager.PrepareAppointmentsForBinding(interviewerAppointmens, timeZoneInfo).ToArray();
            Assert.AreEqual(1, appointments.Count());
            Assert.AreEqual("p00001", appointments[0][0]);
            Assert.AreEqual("33", appointments[0][1]);
            Assert.AreEqual("Project Name", appointments[0][2]);
            Assert.AreEqual(TimeZoneInfo.ConvertTimeBySystemTimeZoneId(appointmentTime, timeZoneInfo.StandardName).ToString("g", LocalizationManager.Instance.CurrentCulture), appointments[0][3]);
            Assert.AreEqual(TimezoneConverter.ConvertTimeFromUtc(timezoneRespondent, appointmentTime
                                          ).ToString("g", LocalizationManager.Instance.CurrentCulture), appointments[0][4]);
            Assert.AreEqual("Timezone 1", appointments[0][5]);
        }
    }
}
