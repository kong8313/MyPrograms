﻿using Confirmit.CATI.Console.Services.MonitoringService;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    /// <summary>
    /// Summary description for DeferredIdentityTest
    /// </summary>
    [TestClass]
    public class DeferredIdentityTest
    {
        public TestContext TestContext { get; set; }

        #region Equals

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_Null_ReturnsFalse()
        {
            var test = new DeferredIdentity();
            Assert.IsFalse(test.Equals(null));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_DifferentInterviewID_ReturnsFalse()
        {
            var test1 = new DeferredIdentity();
            var test2 = new DeferredIdentity {InterviewId = 100};
            Assert.IsFalse(test1.Equals(test2));
        }
        
        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_DifferentSurveyID_ReturnsFalse()
        {
            var test1 = new DeferredIdentity();
            var test2 = new DeferredIdentity { SurveyId = 100 };
            Assert.IsFalse(test1.Equals(test2));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_DifferentDeferredSessionID_ReturnsFalse()
        {
            var test1 = new DeferredIdentity();
            var test2 = new DeferredIdentity { DeferredRecordId = 100 };
            Assert.IsFalse(test1.Equals(test2));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_DifferentAll_ReturnsFalse()
        {
            var test1 = new DeferredIdentity { InterviewId = 200, SurveyId = 200, DeferredRecordId = 200 };
            var test2 = new DeferredIdentity { InterviewId = 100, SurveyId = 100, DeferredRecordId = 100 };
            Assert.IsFalse(test1.Equals(test2));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_EqualIdentity_ReturnsTrue()
        {
            var test1 = new DeferredIdentity { InterviewId = 100, SurveyId = 100, DeferredRecordId = 100 };
            var test2 = new DeferredIdentity { InterviewId = 100, SurveyId = 100, DeferredRecordId = 100 };
            Assert.IsTrue(test1.Equals(test2));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void Equals_SameIdentity_ReturnsTrue()
        {
            var test1 = new DeferredIdentity { InterviewId = 100, SurveyId = 100, DeferredRecordId = 100 };
            Assert.IsTrue(test1.Equals(test1));
        }
        
        #endregion
        
        #region ToDeferredIdentityObject

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void ToDeferredIdentityObject_Object_ReturnsConvertedObject()
        {
            var test1 = new DeferredIdentity { InterviewId = 100, SurveyId = 100, DeferredRecordId = 100 };
            var test2 = test1.ToDeferredIdentityObject();
            Assert.IsTrue((test1.InterviewId == test2.InterviewID) && (test1.SurveyId == test2.SurveySID) && (test1.DeferredRecordId == test2.DeferredRecordId));
        }

        [TestMethod, Owner(@"FIRM\SergeyL")]
        public void ToDeferredIdentityObject_Explicit_ReturnsConvertedObject()
        {
            var test1 = new DeferredIdentity { InterviewId = 100, SurveyId = 100, DeferredRecordId = 100 };
            var test2 = (DeferredIdentityObject)test1;
            Assert.IsTrue((test1.InterviewId == test2.InterviewID) && (test1.SurveyId == test2.SurveySID) && (test1.DeferredRecordId == test2.DeferredRecordId));
        }

        
        #endregion
    }
}
