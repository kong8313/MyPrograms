﻿using System;
using System.Globalization;
using System.Runtime.InteropServices.ComTypes;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Console.Resources;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    /// <summary>
    /// Unit tests for DateTimeManager
    /// </summary>
    [TestClass]
    public class DateTimeManagerTest
    {
        [TestMethod, Owner(@"FIRM\ElenaKs")]
        [ExpectedException(typeof(FormatException))]
        public void ParseDateTime_InputIsStringInNotLocalFormat_ThrowsException()
        {
            const string dateTimeStr = "8-21-2014 AM 21:00";
            DateTimeManager.ParseDateTime(dateTimeStr, false);
        }

        [TestMethod, Owner(@"FIRM\ElenaKs")]
        [ExpectedException(typeof(InvalidCastException))]
        public void ParseDateTime_InputIsDateTimeInNotLocalFormat_ThrowsException()
        {
            DateTimeManager.ParseDateTime(DateTimeManager.DefaultTimeInShiftInUtc, false);
        }

        [TestMethod, Owner(@"FIRM\ElenaKs")]
        public void ParseDateTime_InputIsDefaultTime_ReturnsNow()
        {
            var defaultTime = DateTimeManager.DefaultTimeInShiftInUtc.ToLocalTime().ToString(CultureInfo.InvariantCulture);
            Assert.AreEqual(Strings.Now, DateTimeManager.ParseDateTime(defaultTime, false));
        }

        [TestMethod, Owner(@"FIRM\ElenaKs")]
        public void ParseDateTime_InputIsProperlyFormattedString_ReturnsFormattedDateTime()
        {
            var dateTime = DateTime.Now;
            DateTimeManager.ParseDateTime(dateTime.ToString("g", LocalizationManager.Instance.CurrentCulture), false);
        }
    }
}