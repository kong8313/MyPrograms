﻿using System;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Classes.CallTransfer;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    /// <summary>
    /// Unit tests for CallTransferConfigurationConverter
    /// </summary>
    [TestClass]
    public class CallTransferConfigurationConverterTest
    {
        private readonly CallTransferConfigurationConverter _converter = new CallTransferConfigurationConverter();

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void ConvertJsonToTransferOptions_CallTypeIsInternalCold_Success()
        {
            var testData = "{\"Type\":\"0\", \"TransferTarget\":\"i42\"}";
            var expected = new TransferOptions
            {
                Resource = "i42",
                Type = ConsoleTransferType.InternalCold
            };

            var actual = _converter.ConvertJsonToTransferOptions(testData);

            Assert.AreEqual(expected.Type, actual.Type);
            Assert.AreEqual(expected.Resource, actual.Resource);
        }

        [TestMethod, Owner(@"FIRM\KirillV"), ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ConvertJsonToTransferOptions_CallTypeIsIncorrect_ExceptionWasThrown()
        {
            var testData = "{\"Type\":\"10\", \"TransferTarget\":\"i42\"}";

            _converter.ConvertJsonToTransferOptions(testData);
        }

        [TestMethod, Owner(@"FIRM\KirillV")]
        public void ConvertJsonToTransferOptions_TransferTargetIsEmpty_Success()
        {
            var testData = "{\"Type\":\"0\", \"TransferTarget\":\"\"}";
            var expected = new TransferOptions
            {
                Resource = null,
                Type = ConsoleTransferType.InternalCold
            };

            var actual = _converter.ConvertJsonToTransferOptions(testData);

            Assert.AreEqual(expected.Type, actual.Type);
            Assert.AreEqual(expected.Resource, actual.Resource);
        }
    }
}