﻿using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml;
using Confirmit.CATI.Console.Classes.Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class PhoneNumberValidatorTest
    {
        public TestContext TestContext { get; set; }

        private readonly string _assemblyLocation;
        private readonly ErrorCollector _errorCollector;
        private readonly PhoneNumberValidator _phoneNumberValidator;

        public PhoneNumberValidatorTest()
        {
            _assemblyLocation = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            _errorCollector = new ErrorCollector();
            _phoneNumberValidator = new PhoneNumberValidator();
        }

        [TestMethod, Owner(@"FIRM\maximg")]
        public void ValidateValidNumbers()
        {
            foreach (string phone in PhoneReader("ValidNumbers.xml"))
            {
                if (!_phoneNumberValidator.Validate(phone))
                {
                    _errorCollector.AddError(phone, "valid");
                }
            }

            _errorCollector.RaiseErrorIfNeeded();
            
        }

        [TestMethod, Owner(@"FIRM\maximg")]
        public void ValidateInvalidNumbers()
        {
            foreach (string phone in PhoneReader("InvalidNumbers.xml"))
            {
                if (_phoneNumberValidator.Validate(phone))
                {
                    _errorCollector.AddError(phone, "invalid");
                }
            }

            _errorCollector.RaiseErrorIfNeeded();
        }

        public IEnumerable<string> PhoneReader(string fileName)
        {
            string xmlFilePath = Path.Combine(_assemblyLocation, "TestData", fileName);
            var stringReader = new StringReader(File.ReadAllText(xmlFilePath));
            using (XmlReader reader = XmlReader.Create(stringReader))
            {
                while (reader.ReadToFollowing("Phone"))
                {
                    yield return reader.ReadInnerXml();
                }
            }
        }

        public class ErrorCollector
        {
            private readonly StringBuilder _errorMessage;
            
            public ErrorCollector()
            {
                _errorMessage = new StringBuilder();
            }

            public void AddError(string phone, string phoneType)
            {
                _errorMessage.AppendFormat("\r\nPhone number {0} should be treated as {1}", phone, phoneType);
            }

            public void RaiseErrorIfNeeded()
            {
                if (_errorMessage.Length > 0)
                {
                    Assert.Fail(_errorMessage.ToString());
                }
            }
        }
    }
}
