﻿using System;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Presenters;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Services.CatiService.Fakes;
using Confirmit.CATI.Console.Views.ViewInterfaces.Fakes;
using ConfirmitDialerInterface;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class PresenterTelephonyTest
    {
        private StubICatiServiceManager _catiServiceManager;

        [TestInitialize()]
        public void Initialize()
        {
            var registrator = InitServiceLocator();

            _catiServiceManager = new StubICatiServiceManager();
            registrator.RegisterInstance<ICatiServiceManager>(_catiServiceManager);
        }

        [TestCleanup]
        public void Cleanup()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Cleanup();
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Dial_Success_CallsHelperMethod()
        {
            var dialCalled = false;

            var pres = GetInstance();
            const string phone = "123456";

            _catiServiceManager.DialStringInitiator = (s, initiator) => { dialCalled = true; };

            pres.Dial(phone, String.Empty);

            Assert.IsTrue(dialCalled);
        }

        private PresenterTelephony GetInstance()
        {
            var dialView = new StubIViewDialControl();
            var hangupControl = new StubIViewHangupControl();
            var provider = new BackendTelephonyProvider();
            return new PresenterTelephony(dialView, hangupControl, provider);
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Hangup_ExceptionOccurs_ReturnsCustomErrorStatus()
        {
            PresenterTelephony pres = GetInstance();

            _catiServiceManager.HangupInitiator = initiator =>
            {
                throw new Exception();
            };
            Assert.AreEqual((int)CallOutcome.Error, pres.Hangup(Initiator.Script));
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Hangup_RetunsFalse_ReturnsCustomErrorStatus()
        {
            PresenterTelephony pres = GetInstance();

            _catiServiceManager.HangupInitiator = initiator => false;
            Assert.AreEqual((int)CallOutcome.Error, pres.Hangup(Initiator.Script));
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Hangup_Success_CheckParameters()
        {
            PresenterTelephony pres = GetInstance();

            _catiServiceManager.HangupInitiator = initiator =>
            {
                Assert.AreEqual(Initiator.Script, initiator);
                return false;
            };

            Assert.AreEqual((int)CallOutcome.Error, pres.Hangup(Initiator.Script));
        }

        [TestMethod, Owner(@"FIRM\SergeyC")]
        public void Hangup_Success_ReturnsCompletedStatus()
        {
            PresenterTelephony pres = GetInstance();

            _catiServiceManager.HangupInitiator = initiator => true;
            Assert.AreEqual((int)CallOutcome.Completed, pres.Hangup(Initiator.Script));
        }

        private IServiceRegistrator InitServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            var registrator = (IServiceRegistrator)serviceLocator;
            return registrator;
        }
    }
}