﻿using System.Collections.Generic;
using Confirmit.CATI.Console.Classes.LoadTesting;
using Confirmit.CATI.Console.Presenters;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.UnitTests.LoadTesting
{
    [TestClass]
    public class LoopProviderTest
    {
        [TestMethod]
        public void LoopProvider_TwoLoopItemsWithAnswers_Success()
        {
            var loopAnswers = new List<Loop>();
            loopAnswers.Add(new Loop
            {
                Answers = new List<string[]>
                {
                    new[] {"1", "2"},
                    new[] {"3", "4"}
                },
                Keys = new[] {"q1", "q2"}
            });

            var loopProvider = new LoopProvider(loopAnswers);
            var loopRow = loopProvider.GetLoopItemByQuestionId("q1");
            Assert.AreEqual("1", loopRow["q1"]);
            Assert.AreEqual("2", loopRow["q2"]);

            loopRow = loopProvider.GetLoopItemByQuestionId("q1");
            Assert.AreEqual("3", loopRow["q1"]);
            Assert.AreEqual("4", loopRow["q2"]);
        }

        [TestMethod]
        public void LoopProvider_TwoLoopsWithTwoLoopItemsWithAnswers_Success()
        {
            var loopAnswers = new List<Loop>
            {
                new Loop
                {
                    Answers = new List<string[]>
                    {
                        new[] {"1", "2"},
                        new[] {"3", "4"}
                    },
                    Keys = new[] {"q1", "q2"}
                },
                new Loop
                {
                    Answers = new List<string[]>
                    {
                        new[] {"5", "6"},
                        new[] {"7", "8"}
                    },
                    Keys = new[] {"q3", "q4"}
                }
            };

            var loopProvider = new LoopProvider(loopAnswers);
            var loopRow = loopProvider.GetLoopItemByQuestionId("q1");
            Assert.AreEqual("1", loopRow["q1"]);
            Assert.AreEqual("2", loopRow["q2"]);

            loopRow = loopProvider.GetLoopItemByQuestionId("q1");
            Assert.AreEqual("3", loopRow["q1"]);
            Assert.AreEqual("4", loopRow["q2"]);

            loopRow = loopProvider.GetLoopItemByQuestionId("q3");
            Assert.AreEqual("5", loopRow["q3"]);
            Assert.AreEqual("6", loopRow["q4"]);

            loopRow = loopProvider.GetLoopItemByQuestionId("q4");
            Assert.AreEqual("5", loopRow["q3"]);
            Assert.AreEqual("6", loopRow["q4"]);

            loopRow = loopProvider.GetLoopItemByQuestionId("q3");
            Assert.AreEqual("7", loopRow["q3"]);
            Assert.AreEqual("8", loopRow["q4"]);
        }
    }
}
