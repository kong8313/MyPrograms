﻿using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Services.CatiService;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ServiceModel;
using Confirmit.CATI.Common.ConsoleService;
using Confirmit.CATI.Common.ConsoleService.Fakes;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Log.Fakes;

namespace Confirmit.CATI.Console.UnitTests
{
    [TestClass]
    public class WebServiceManagerTest
    {
        private CatiServiceManager _catiServiceManager;
        private StubIConsoleService _consoleService;

        [TestInitialize()]
        public void Initialize()
        {
            var registrator = InitServiceLocator();
            registrator.RegisterInstance<IAlerter>(new StubIAlerter());

            _consoleService = new StubIConsoleService();

            var consoleServiceChannelFactory = new CustomStubIChannelFactoryWrapper<IConsoleService>
            {
                ExecuteExpressionOfActionOfT = action =>
                {
                    action.Invoke(_consoleService);
                },
                ExecuteExpressionOfFunctionOfT = function =>
                {
                    var method = function.Compile();
                    return method.Invoke(_consoleService);
                }
            };

            _catiServiceManager = new CatiServiceManager(new AuthenticationData())
            {
                m_ConsoleServiceChannelFactory = consoleServiceChannelFactory
            };
        }

        [TestCleanup]
        public void Cleanup()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Cleanup();
        }

        private IServiceRegistrator InitServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            var registrator = (IServiceRegistrator)serviceLocator;
            return registrator;
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void WrapUp_CommunicationExceptionOnFirstAttemptSuccessOnSecondAttempt_Success()
        {
            var details = new CompletedInterviewDetails();
            var wrapupCalled = false;

            _consoleService.WrapUpInt32BooleanInt32CompletedInterviewDetails =
                (id, calls, number, interviewDetails) =>
                {
                    Assert.AreEqual(1, id);
                    Assert.AreEqual(true, calls);
                    Assert.AreEqual(details, interviewDetails);
                    if (number == 1)
                    {
                        throw new CommunicationException();
                    }
                    if (number == 2)
                    {
                        wrapupCalled = true;
                    }
                };

            _catiServiceManager.WrapUp(1, true, details);

            Assert.IsTrue(wrapupCalled);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void Dial_CommunicationExceptionOnFirstAttemptSuccessOnSecondAttempt_Success()
        {
            var dialCalled = false;

            _consoleService.DialStringInt32Int32 = (phone, initiator, number) =>
            {
                Assert.AreEqual("12345", phone);
                Assert.AreEqual((int)Initiator.Script, initiator);
                if (number == 1)
                {
                    throw new CommunicationException();
                }
                if (number == 2)
                {
                    dialCalled = true;
                }
            };

            _catiServiceManager.Dial("12345", Initiator.Script);

            Assert.IsTrue(dialCalled);
        }

        [TestMethod, Owner(@"FIRM\AlexanderZh")]
        public void SendFusionReviewFlag_CommunicationExceptionOnFirstAttemptSuccessOnSecondAttempt_Success()
        {
            var sendFlagCalled = false;

            _consoleService.GetForceOpenendReviewInt32 = number =>
            {
                if (number == 1)
                {
                    throw new CommunicationException();
                }
                if (number == 2)
                {
                    sendFlagCalled = true;
                }
                return true;
            };

            _catiServiceManager.SendFusionReviewFlag();

            Assert.IsTrue(sendFlagCalled);
        }
    }
}
