﻿using System.IO;
using System.Reflection;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Confirmit.CATI.Console.InfrastructureTest
{
    [TestClass]
    public class InfrastructureTest
    {
        private string _copyToRootPath;
        private string _rootPath;

        [TestMethod, Owner(@"FIRM\GrigoryK")]
        public void CompareFilesInCopyToRootFolder_FilesAreTheSame()
        {
            SetPaths();
            
            CompareAllFiles(_copyToRootPath);
        }

        private void SetPaths()
        {
            string assemblypath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? string.Empty;
            _rootPath = Path.GetFullPath(Path.Combine(assemblypath, @"..\"));
            _copyToRootPath = Path.GetFullPath(Path.Combine(assemblypath, @"..\CatiConsole\MSBuild\CopyToRoot\"));
        }

        private void CompareAllFiles(string path)
        {
            foreach (var directoryPath in Directory.GetDirectories(path))
            {
                CompareAllFiles(directoryPath);
            }

            foreach (var filePath in Directory.GetFiles(path))
            {
                string originalFilePath = filePath.Replace(_copyToRootPath, _rootPath);
                Assert.IsTrue(IsFilesTheSame(filePath, originalFilePath), string.Format("Files '{0}' and '{1}' are different. Copy a new version of original file to 'CatiConsole\\MSBuild\\CopyToRoot' folder.", filePath, originalFilePath));
            }
        }

        private bool IsFilesTheSame(string filePath1, string filePath2)
        {
            byte[] file1 = File.ReadAllBytes(filePath1);
            byte[] file2 = File.ReadAllBytes(filePath2);

            if (file1.Length != file2.Length)
            {
                return false;
            }

            for (int i = 0; i < file1.Length; i++)
            {
                if (file1[i] != file2[i])
                {
                    return false;
                }
            }

            return true;
        }
    }
}
