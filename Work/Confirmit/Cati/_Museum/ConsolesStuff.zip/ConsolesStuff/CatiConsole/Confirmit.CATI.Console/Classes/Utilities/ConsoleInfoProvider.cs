﻿using System;
using System.Globalization;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    internal class ConsoleInfoProvider : ILogInfoProvider
    {
        private readonly UserPassport _userPassport;
        private readonly IInterviewProperties _interviewProperties;
        private readonly string _stationId;
        private readonly IConsoleDescriptionProvider _descriptionProvider;

        public ConsoleInfoProvider(
            UserPassport userPassport,
            IInterviewProperties interviewProperties,
            string stationId,
            IConsoleDescriptionProvider descriptionProvider)
        {
            _userPassport = userPassport;
            _interviewProperties = interviewProperties;
            _stationId = stationId;
            _descriptionProvider = descriptionProvider;
        }

        public string GetInfo()
        {
            var currentInterviewProperties = _interviewProperties.CurrentInterviewProperties;
            var userProperties = _userPassport.Properties;

            return String.Format(
                Strings.ServerLoggingDetails,
                _userPassport.UserName,
                userProperties != null
                    ? userProperties.InterviewerId.ToString(CultureInfo.InvariantCulture)
                    : String.Empty,
                _userPassport.CompanyAlias,
                _userPassport.CompanyId,
                currentInterviewProperties != null ? currentInterviewProperties.SurveyId : String.Empty,
                currentInterviewProperties != null ? 
                    currentInterviewProperties.InterviewId.ToString(CultureInfo.InvariantCulture) : 
                    String.Empty,
                _stationId,
                _descriptionProvider.GetConsoleDescriptionText());
        }
    }
}
