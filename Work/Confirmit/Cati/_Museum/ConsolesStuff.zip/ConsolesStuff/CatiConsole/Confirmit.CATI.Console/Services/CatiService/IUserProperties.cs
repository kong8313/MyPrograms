﻿using System;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using ConfirmitDialerInterface;

namespace Confirmit.CATI.Console.Services.CatiService
{
    public interface IUserProperties
    {
        bool AlreadyLoggedIn { get; }
        Guid AuthenticationKey { get; }
        string AutomaticSurveyName { get; }
        bool ConnectedToDialer { get; }
        CatiConsolePropertiesContainer ConsoleProperties { get; }
        byte[] EncryptionIV { get; }
        byte[] EncryptionKey { get; }
        bool HasStationExtensionNumber { get; }
        int InterviewerId { get; }
        bool IsHangUpEnabled { get; }
        bool IsPauseResumePlaybackEnabled { get; }
        bool IsToggleVoiceSourceSupported { get; }
        TaskChoicePermissions? TaskChoicePermissions { get; }
        AgentTaskChoiceMode UserAssignmentMode { get; set; }

        bool CheckPredictiveModeAfterAbnornalTermination();
        bool IsLoggedToDialer();
        void UpdateAuthenticationKey(Guid authenticationKey);
        void UpdateUserAssignmentMode(AgentTaskChoiceMode newMode);

        LoginState LoginToDialerState { get; }
    }
}