﻿using System;

namespace Confirmit.CATI.Console.Classes.CheckSpelling
{
    public interface ISpellCheckService
    {
        event EventHandler<SpellCheckErrorEventArgs> SpellCheckError;
        event EventHandler<SpellCheckCompletedEventArgs> SpellCheckCompleted;

        void StartCheckSpelling(string textBlock);
    }
}