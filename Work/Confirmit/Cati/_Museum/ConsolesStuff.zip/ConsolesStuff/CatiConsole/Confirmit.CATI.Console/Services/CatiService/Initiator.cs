﻿namespace Confirmit.CATI.Console.Services.CatiService
{
    /// <summary>
    /// Telephony command initiator enumeration.
    /// </summary>
    public enum Initiator
    {
        /// <summary>
        /// Command is initiated by script.
        /// </summary>
        Script = 0,

        /// <summary>
        /// Command is initiated by user menu.
        /// </summary>
        MainMenu = 1,

        /// <summary>
        /// Command is initiated by (re)dialing dialog.
        /// </summary>
        DialCancellation = 2
    }
}
