﻿namespace Confirmit.CATI.Console.Services.CatiService
{
    public interface IGetStateStopwatch
    {
        long ElapsedMilliseconds { get; }

        void Reset();
        void Start();
        void Restart();
    }
}