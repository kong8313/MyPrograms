using System.Collections.Generic;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class RankingQuestionHandler : BaseQuestionHandler, IQuestionHandler
    {
        public RankingQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers)
            : base(pageBrowser, predefinedAnswers)
        {
        }

        void IQuestionHandler.SetAnswers()
        {
            var keys = GetKeysForNonOther();
            foreach (var key in keys)
            {
                if (string.IsNullOrEmpty(PredefinedAnswers[key]))
                {
                    continue;
                }

                SetAnswer(string.Format("{0}", key), PredefinedAnswers[key]);
            }

            SetOtherForNonEmpty();
        }
    }
}