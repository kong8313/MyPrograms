﻿using System;
using System.Diagnostics;
using Confirmit.CATI.Console.Classes.Localization;
using System.Windows.Forms;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;
using ConfirmitDialerInterface;

namespace Confirmit.CATI.Console.Presenters
{
    internal class PresenterRedialForm : IMonitorable
    {
        public PresenterRedialForm(IViewRedialForm redialForm, PresenterTelephony telephonyPresenter)
        {
            if (redialForm == null)
            {
                throw new ArgumentNullException("redialForm");
            }

            TelephonyPresenter = telephonyPresenter;
            RedialForm = redialForm;
            Initiator = Initiator.MainMenu;

            _alerter = ServiceLocator.Resolve<IAlerter>();

            InitEventHandlers();
            InitLocalization();
        }

        private bool _isDialCanellationButtonVisibile;

        private bool _isCancelled;

        private CatiConsolePropertiesContainer CatiConsoleProperties
        {
            get { return UserPassport.Instance.Properties.ConsoleProperties; }
        }

        public RedialFormCloseReasons CloseResult { get; set; }

        public Initiator Initiator { get; private set; }

        internal IViewRedialForm RedialForm { get; set; }

        public event EventHandler<DialCancellationEventArgs> CancelClick;

        private PresenterTelephony TelephonyPresenter;

        private IAlerter _alerter;

        public event StateChangedEventHandler StateChanged;

        public event EventHandler CallIsConnected;

        public void ShowDialog(IWin32Window parent, Initiator initiator)
        {
            Initiator = initiator;

            try
            {
                RedialForm.ShowRedialNewNumber = CatiConsoleProperties.EnableRedialNewNumberRedialDialogAbility;

                InitLocalization();

                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.RedialFormInitialMessage,
                        State = null
                    },
                    UserPassport.Instance.MonitoringIdentity
                );

                RedialForm.CancelClick += RedialForm_CancelClick;
                RedialForm.Show(parent);
            }
            catch (Exception ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
            }
        }

        public void SetDialCanellationButtonVisibility(bool isVisible)
        {
            RedialForm.SetDialCanellationButtonVisibility(isVisible);
            _isDialCanellationButtonVisibile = isVisible;
        }

        void RedialForm_CancelClick(object sender, DialCancellationEventArgs e)
        {
            if (CancelClick != null)
            {
                _isCancelled = true;

                OnStateChanged(
                   new StateChangedEventArgs
                   {
                       MessageType = MonitoringMessageTypes.RedialFormHangupDialCalledMessage,
                       State = new RedialHangupDialCalledStateData
                       {
                           Message = RedialForm.HangupDialingMessage
                       }
                   },
                   UserPassport.Instance.MonitoringIdentity
                );

                CancelClick(sender, e);
            }
        }

        private void RedialForm_OkClick(object sender, EventArgs e)
        {
            try
            {
                Logger.Write(Strings.Log_RedialIsStarted, MessageTypes.Information);

                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.RedialFormDialCalledMessage,
                        State = new RedialDialCalledStateData
                        {
                            IsDialCanellationButtonVisible = CatiConsoleProperties.EnableAbilityToCancelDial,
                            Message = RedialForm.DialingMessage
                        }
                    },
                    UserPassport.Instance.MonitoringIdentity
                );
                
                StartRedial(RedialForm.RedialNewNumber ? RedialForm.DialNumber : string.Empty);
            }

            catch (Exception ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Allert_ErrorCaption"));
            }
        }

        private void StartRedial(string phone)
        {
            RedialForm.SuppressFormClosing = true;
            RedialForm.EnableInputControls(false);
            RedialForm.SetDialingInProgressVisibility(true);
            TelephonyPresenter.TelephonyResult += TelephonyPresenter_TelephonyResult;
            TelephonyPresenter.Redial(phone, string.Empty);
        }

        void TelephonyPresenter_TelephonyResult(object sender, Classes.Telephony.TelephonyResultEventArgs e)
        {
            var statusName = ((CallOutcome)e.Status);
            var formattedStatus = string.Format("{0} ({1})", statusName, e.Status);
            var isConnected = false;

            Logger.Write(string.Format(Strings.Log_RedialResultReceived, statusName), MessageTypes.Information);

            RedialForm.NotifyLastCallOutcome(formattedStatus);
            TelephonyPresenter.TelephonyResult -= TelephonyPresenter_TelephonyResult;
            RedialForm.SetDialingInProgressVisibility(false);

            if (e.Status == (int)CallOutcome.Connected)
            {
                isConnected = true;

                RedialForm.HideForm();

                if (!_isCancelled)
                {
                    CallIsConnected?.Invoke(this, e);
                }
            }
            else
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("RedialForm_TelephonyResultMessage", formattedStatus),
                    LocalizationManager.Instance.GetString("Alerter_RedialCaption"),
                    MessageTypes.Information
                    );
            }

            OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.RedialFormTelephonyResultMessage,
                        State = new RedialTelephonyResultStateData
                        {
                            ControlName = sender.ToString(),
                            CallOutcome = formattedStatus,
                            IsConnected = isConnected
                        }
                    },
                    UserPassport.Instance.MonitoringIdentity
                );

            RedialForm.SuppressFormClosing = false;
            RedialForm.EnableInputControls(true);
        }

        private void LocalizationManager_CurrentCultureChanged(object sender, EventArgs e)
        {
            LocalizeViews(LocalizationManager.Instance);
        }

        void RedialForm_ValidatingDialNumber(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (RedialForm.DialNumber == string.Empty)
            {
                RedialForm.AlertValidationError(RedialValidationControls.DialNumber,
                    LocalizationManager.Instance.GetString("Error_BlankTelephoneNumber"));
                e.Cancel = true;
            }
        }

        private void InitEventHandlers()
        {
            RedialForm.OkClick += RedialForm_OkClick;
            RedialForm.ValidatingDialNumber += RedialForm_ValidatingDialNumber;
            RedialForm.RedialTypeChanged += RedialForm_RedialTypeChanged;
            RedialForm.RedialNumberChanged += RedialForm_RedialNumberChanged;
            RedialForm.FormClose += RedialForm_FormClose;
            RedialForm.FormProcessCmdKey += RedialForm_FormProcessCmdKey;
            LocalizationManager.Instance.CurrentCultureChanged += LocalizationManager_CurrentCultureChanged;
        }

        void RedialForm_FormProcessCmdKey(object sender, ProcessCmdKeyEventArgs e)
        {
            if (!_isDialCanellationButtonVisibile)
            {
                return;
            }

            if (RedialForm.IsDialCanellationButtonEnabled &&
                e.KeyData == (Keys.Control | Keys.X))
            {
                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.RedialFormHangupDialCalledMessage,
                        State = new RedialHangupDialCalledStateData
                        {
                            Message = RedialForm.HangupDialingMessage
                        }
                    },
                    UserPassport.Instance.MonitoringIdentity
                );

                RedialForm.HangupDialing();
            }
        }

        void RedialForm_FormClose(object sender, EventArgs e)
        {
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.RedialFormCloseMessage,
                    State = null
                },
                UserPassport.Instance.MonitoringIdentity
            );
        }

        void RedialForm_RedialNumberChanged(object sender, EventArgs e)
        {
            OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.RedialFormDialNumberChangedMessage,
                        State = new RedialNumberChangedStateData
                        {
                            DialNumber = RedialForm.DialNumber,
                            ControlName = ((TextBox)sender).Name
                        }
                    },
                    UserPassport.Instance.MonitoringIdentity
                );
        }

        void RedialForm_RedialTypeChanged(object sender, EventArgs e)
        {
            var radioButtonNew = sender as RadioButton;
            if (radioButtonNew == null)
            {
                return;
            }

            OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.RedialFormRedialTypeChangedMessage,
                        State = new RedialTypeChangedStateData
                        {
                            IsNewNumberDialChecked = radioButtonNew.Checked,
                            ControlName = radioButtonNew.Name
                        }
                    },
                    UserPassport.Instance.MonitoringIdentity
                );
        }

        private void InitLocalization()
        {
            LocalizeViews(LocalizationManager.Instance);
        }

        private void LocalizeViews(ILocalizationManager manager)
        {
            RedialForm.Localize(manager);
        }

        public BaseStateData GetState()
        {
            return new RedialInitialStateData
            {
                DialNumber = RedialForm.DialNumber
            };
        }

        private void OnStateChanged(StateChangedEventArgs e, MonitoringIdentity sessionId)
        {
            if (StateChanged != null)
            {
                StateChanged(this, e, sessionId);
            }
        }
    }
}
