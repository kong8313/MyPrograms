﻿using System;
using System.Data;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Security;

using Confirmit.CATI.Common;
using Confirmit.CATI.Common.Exceptions;
using Confirmit.CATI.Common.Validators;
using Confirmit.CATI.Common.WcfTools;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Common.ConsoleService;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Services.CatiService.Exceptions;
using Confirmit.CATI.Console.Services.MonitoringService;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Resources;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Monitoring.Common.Contracts;
using ConfirmitDialerInterface;

namespace Confirmit.CATI.Console.Services.CatiService
{
    /// <summary>
    /// Represents intermediate level between application and Fusion Web Service.
    /// </summary>
    public class CatiServiceManager : ICatiServiceManager
    {
        private int _companyId;
        private string _userName = string.Empty;
        private bool _enablePersistentConnectionClosing;

        internal IChannelFactoryWrapper<IConsoleService> m_ConsoleServiceChannelFactory;
        private IChannelFactoryWrapper<IConsoleStateService> m_StateServiceChannelFactory;
        private IChannelFactoryWrapper<IInterviewerContract> m_MonitoringServiceChannelFactory;

        private readonly CatiStateServiceSessionProlonger _stateServiceProlonger;
        private readonly IAuthenticationData _authenticationData;

        public CatiServiceManager(IAuthenticationData authenticationData)
        {
            _authenticationData = authenticationData;
            _stateServiceProlonger = new CatiStateServiceSessionProlonger(RecreateStateChannelFactory);
        }

        /// <summary>
        /// Releases all existing WCF client proxies allocated by this class.
        /// </summary>
        public void Release()
        {
            ReleaseConsoleService();

            ReleaseStateService();

            ReleaseMonitoringService();
        }

        private void ReleaseStateService()
        {
            if (m_StateServiceChannelFactory != null)
            {
                var uri = m_StateServiceChannelFactory.GetFactoryUri();

                m_StateServiceChannelFactory.Release();

                Logger.Write(
                    string.Format("EnablePersistentConnectionClosing = '{0}', uri='{1}'", _enablePersistentConnectionClosing, uri),
                    MessageTypes.Information);
                if (_enablePersistentConnectionClosing && uri != null)
                {
                    Logger.Write("Kill persistent connections for State Service", MessageTypes.Information);
                    var servicePoint = ServicePointManager.FindServicePoint(uri);
                    servicePoint.CloseConnectionGroup("");
                    Logger.Write("Done", MessageTypes.Information);
                }
            }
        }

        private void ReleaseConsoleService()
        {
            if (m_ConsoleServiceChannelFactory != null)
            {
                m_ConsoleServiceChannelFactory.Release();
            }
        }

        private void ReleaseMonitoringService()
        {
            if (m_MonitoringServiceChannelFactory != null)
            {
                m_MonitoringServiceChannelFactory.Release();
            }
        }

        private void ConfigureChannelFactories(string userName, string userPassword, int companyId)
        {
            // clean-up cached proxies and channel factories to recreate them with new login / password.
            Release();

            _companyId = companyId;
            _userName = userName;

            ConfigureConsoleChannelFactory(companyId, userName, userPassword);

            ConfigureStateChannelFactory(companyId, userName);

            ConfigureMonitoringServiceChannelFactory(companyId, userName, userPassword);
        }

        private void ConfigureStateChannelFactory(int companyId, string userName)
        {
            m_StateServiceChannelFactory = new ChannelFactoryWrapper<IConsoleStateService>(
                new ConsoleStateServiceChannelFactoryWrapperConfiguration(companyId, userName, _authenticationData), new Logger());
        }

        private void ConfigureConsoleChannelFactory(int companyId, string userName, string userPassword)
        {
            m_ConsoleServiceChannelFactory = new ChannelFactoryWrapper<IConsoleService>(
                new ConsoleServiceChannelFactoryWrapperConfiguration(companyId, userName, userPassword), new Logger());
        }

        private void ConfigureMonitoringServiceChannelFactory(int companyId, string userName, string userPassword)
        {
            m_MonitoringServiceChannelFactory = new ChannelFactoryWrapper<IInterviewerContract>(
                new InterviewerMonitoringServiceChannelFactoryWrapperConfiguration(companyId, userName, userPassword), new Logger());
        }

        private void RecreateStateChannelFactory()
        {
            ReleaseStateService();

            ConfigureStateChannelFactory(_companyId, _userName);
        }

        /// <summary>
        /// Logs user in CATI Web Service.
        /// </summary>
        /// <param name="stationId">StationId as defined in Settings.config</param>
        /// <param name="userName">User name.</param>
        /// <param name="userPassword">User password.</param>
        /// <param name="companyId">Company identifier.</param>
        /// <param name="consoleDescription">ConsoleDescription contains MachineName, ConsoleVersion and so on</param>
        /// <returns>Properties associated with given console user, if log in is 
        /// successful; otherwise null. </returns>
        /// <remarks>We reset service client instance before calling login method</remarks>
        public UserProperties Login(string stationId, string userName, string userPassword, int companyId, ConsoleDescription consoleDescription)
        {
            try
            {
                PersonInfo personInfo = null;
                DiallerInfo diallerInfo = null;

                ConfigureChannelFactories(userName, userPassword, companyId);

                CatiConsolePropertiesContainer properties = null;

                m_ConsoleServiceChannelFactory.Execute(x => x.Login(stationId, consoleDescription, out personInfo, out diallerInfo, out properties));

                if (properties == null)
                {
                    return null;
                }

                _enablePersistentConnectionClosing = properties.EnablePersistentConnectionClosing;

                return new UserProperties(
                    (AgentTaskChoiceMode)personInfo.PersonMode,
                    diallerInfo.ConnectedToDialer,
                    personInfo.AlreadyLoggedIn,
                    diallerInfo.CurrentLoggedInToDialerState,
                    diallerInfo.CurrentIsPredictive,
                    diallerInfo.HasExtensionNumber,
                    diallerInfo.IsHangUpSupported,
                    diallerInfo.IsPauseOrResumePlaybackSupported,
                    diallerInfo.IsToggleVoiceSourceSupported,
                    personInfo.PersonId,
                    personInfo.AutoSurveyId,
                    (TaskChoicePermissions?)personInfo.TaskChoicePermissions,
                    personInfo.AuthenticationKey,
                    personInfo.EncryptionKey,
                    personInfo.EncryptionIV,
                    properties
                    );
            }
            catch (EndpointNotFoundException ex)
            {
                throw new CatiInvalidInstanceException(ex);
            }
            catch (MessageSecurityException)
            {
                throw new UserMessageException(CatiInterviewerConsoleUITexts.SecurityVerificationFailed, "SecurityVerificationFailed");
            }
        }

        /// <summary>
        /// Returns collection of open surveys associated with current user.
        /// </summary>
        /// <returns>Collection of surveys, if exists; otherwise empty collection.</returns>
        public SurveyCollection GetSurveys()
        {
            Common.ConsoleService.Abstract.Survey[] surveys = m_ConsoleServiceChannelFactory.Execute(x => x.GetOpenedSurveys());

            var result = new SurveyCollection();
            if (surveys != null && surveys.Length > 0)
            {
                result = new SurveyCollection(surveys);
            }

            return result;
        }

        /// <summary>
        /// Returns collection of interviews of given survey associated with current user.
        /// </summary>
        /// <param name="surveyId">Survey identifier.</param>
        /// <param name="searchParameters"> array of the SearchParameter</param>
        /// <returns>Collection of interviews, if exists; otherwise empty collection.</returns>
        public DataTable GetInterviews(string surveyId, ConsoleSearchParameter[] searchParameters)
        {
            SearchParameter[] parameters =
                searchParameters.Select(
                    x =>
                    new SearchParameter
                    {
                        ColumnName = x.ColumnName,
                        ColumnTypeName = x.ColumnTypeName,
                        Value = x.Value
                    }).ToArray();

            DataTable result = m_ConsoleServiceChannelFactory.Execute(x => x.GetSurveyInterviews(surveyId, parameters));

            return result;
        }

        /// <summary>
        /// Returns apointment for given interview.
        /// </summary>
        /// <param name="surveyId">Survey identifier.</param>
        /// <param name="interviewId">Interview identifier.</param>
        /// <returns>Appointment if exists; otherwise null.</returns>
        public Appointment GetAppointment(string surveyId, int interviewId)
        {
            if (surveyId == null || String.IsNullOrEmpty(surveyId))
            {
                throw new ArgumentNullException("surveyId");
            }

            if (interviewId <= 0)
            {
                throw new ArgumentException(
                    LocalizationManager.Instance.GetString("Error_InvalidIdentifierMessage", interviewId),
                    "interviewId");
            }

            Appointment result = null;

            Common.ConsoleService.Abstract.Appointment[] apps =
                m_ConsoleServiceChannelFactory.Execute(x => x.GetInterviewAppointmentList(surveyId, interviewId));

            if (apps != null && apps.Length > 0)
            {
                result = new Appointment(apps[0]);
            }

            return result;
        }

        public Timezone GetInterviewTimezone(string surveyId, int interviewId)
        {
            if (surveyId == null || String.IsNullOrEmpty(surveyId))
            {
                throw new ArgumentNullException("surveyId");
            }

            if (interviewId <= 0)
            {
                throw new ArgumentException(
                    LocalizationManager.Instance.GetString("Error_InvalidIdentifierMessage", interviewId),
                    "interviewId");
            }

            return new Timezone(
                m_ConsoleServiceChannelFactory.Execute(x => x.GetInterviewTimezone(surveyId, interviewId)));
        }

        /// <summary>
        /// Returns all apointments for current interviewer.
        /// </summary>
        public AppointmentCollection GetInterviewerAppointments()
        {
            Common.ConsoleService.Abstract.Appointment[] apps =
                m_ConsoleServiceChannelFactory.Execute(x => x.GetAllAppointmentList());

            return new AppointmentCollection(apps);
        }

        /// <summary>
        /// Returns all apointments for current interviewer.
        /// </summary>
        public SupervisorMessageCollection GetMessages()
        {
            Messages[] msgs = m_ConsoleServiceChannelFactory.Execute(x => x.GetMessages());

            return new SupervisorMessageCollection(msgs);
        }

        /// <summary>
        /// Returns all spelling errors for specified text block.
        /// </summary>
        public SpellError[] CheckTextSpelling(int languageId, string textBlock)
        {
            return m_ConsoleServiceChannelFactory.Execute(x => x.CheckTextSpelling(languageId, textBlock));
        }

        public bool SetPendingBreakStatus(bool enabled, int? breakType)
        {
            var status = enabled ? PendingBreakStatus.Break : PendingBreakStatus.None;
            return m_ConsoleServiceChannelFactory.Execute(x => x.SetPendingBreakStatus(status, breakType));
        }

        /// <summary>
        /// Sends Fusion notification that opened review has started.
        /// If exception occurs and it is not CatiException call of method will be repeated
        /// </summary>
        public void ContinueWorkAfterBreak()
        {
            CatiServiceRetryManager.Invoke(ContinueWorkAfterBreakInternal, true);
        }

        public void ContinueWorkAfterBreakInternal(int attemptNumber)
        {
            m_ConsoleServiceChannelFactory.Execute(x => x.ContinueWorkAfterBreak(attemptNumber));
        }

        /// <summary>
        /// Saves given appointment to given interview. If given appointment is null,
        /// removes previous saved appointment.
        /// </summary>
        /// <param name="surveyId">Survey identifier.</param>
        /// <param name="interviewId">Interview identifier.</param>
        /// <param name="appointment">Appointment to save.</param>
        /// <param name="allowOutsideShift">Flag indicates whether we should check
        /// that appointment belongs to some existing shift.</param>
        public void SetAppointment(
            string surveyId,
            int interviewId,
            Appointment appointment,
            bool allowOutsideShift)
        {
            if (String.IsNullOrEmpty(surveyId))
            {
                throw new ArgumentNullException("surveyId");
            }

            var appointments =
                (appointment == null)
                    ? new Common.ConsoleService.Abstract.Appointment[0]
                    : new[] { appointment.ToWSAppointment() };

            m_ConsoleServiceChannelFactory.Execute(x => x.SetInterviewAppointmentList(surveyId, interviewId, appointments, allowOutsideShift));
        }

        /// <summary>
        /// Retruns user assignment mode.
        /// </summary>
        /// <returns>Mode.</returns>
        public AgentTaskChoiceMode GetPersonMode()
        {
            return (AgentTaskChoiceMode)m_ConsoleServiceChannelFactory.Execute(x => x.GetPersonMode());
        }

        /// <summary>
        /// Notifies Web Service that client is still connected.
        /// </summary>
        public KeepAliveResult KeepAlive()
        {
            return new KeepAliveResult(
                _stateServiceProlonger.ExecuteWithSessionProlongation(
                    () => m_StateServiceChannelFactory.Execute(x => x.KeepAlive())));
        }

        /// <summary>
        /// Starts dialing process.
        /// If exception occurs and it is not CatiException call of method will be repeated
        /// </summary>
        public void Dial(string phone, Initiator initiator)
        {
            CatiServiceRetryManager.Invoke(counter => Dial(phone, initiator, counter), true);
        }

        /// <summary>
        /// Starts dialing process.
        /// </summary>
        /// <param name="phone">Phone number.</param>
        /// <param name="initiator">Initiator. For now it should be Script.</param>
        /// <param name="attemptNumber">The number of the currect attempt</param>
        /// <returns>true, if dialing started successfully; otherwise false.</returns>
        public void Dial(string phone, Initiator initiator, int attemptNumber)
        {
            if (attemptNumber > 1)
            {
                Logger.Write(
                    Strings.ResourceManager.GetString("Log_AttemptToCallMethod", attemptNumber, "Dial"),
                    MessageTypes.Information);
            }

            m_ConsoleServiceChannelFactory.Execute(x => x.Dial(phone, (int)initiator, attemptNumber));
        }

        /// <summary>
        /// Hangs up telephony connection.
        /// </summary>
        /// <param name="initiator">Initiator. For now it should be Script.</param>
        /// <returns>true, if connection is hung up successfully; otherwise false.</returns>
        public bool Hangup(Initiator initiator)
        {
            return m_ConsoleServiceChannelFactory.Execute(x => x.Hangup((int)initiator));
        }

        /// <summary>
        /// Starts playing a sound file.
        /// </summary>
        /// <param name="filename"> file to play </param>
        /// <param name="timeOfPlayingInSeconds"> The time Of Playing In Seconds. </param>
        public void StartPlayback(string filename, out int timeOfPlayingInSeconds)
        {
            int timeInSeconds = 0;
            m_ConsoleServiceChannelFactory.Execute(x => x.StartPlayback(filename, out timeInSeconds));
            timeOfPlayingInSeconds = timeInSeconds;
        }

        /// <summary>
        /// Pauses/resumes playing a sound file.
        /// </summary>
        public void PauseOrResumePlayback()
        {
            m_ConsoleServiceChannelFactory.Execute(x => x.PauseOrResumePlayback());
        }

        /// <summary>
        /// Stops playing a sound file.
        /// </summary>
        public void StopPlayback()
        {
            m_ConsoleServiceChannelFactory.Execute(x => x.StopPlayback());
        }

        /// <summary>
        /// Switchs agent from hear respondent to hear playing and back.
        /// </summary>
        public void ToggleInterviewerListensToPlaybackOrRespondent()
        {
            m_ConsoleServiceChannelFactory.Execute(x => x.ToggleInterviewerListensToPlaybackOrRespondent());
        }

        /// <summary>
        /// Returns current state of CatiWS.
        /// </summary>
        /// <returns>State object.</returns>
        public ProcessState GetState()
        {
            ProcessState result = null;

            State state = _stateServiceProlonger.ExecuteWithSessionProlongation(
                () => m_StateServiceChannelFactory.Execute(x => x.GetState()));

            if (state != null)
            {
                result = new ProcessState(state, _authenticationData.EncryptionKey, _authenticationData.EncryptionIv, _authenticationData.StationId);
            }

            return result;
        }

        /// <summary>
        /// It is the request to start an interview for the logged in person.
        /// </summary>
        /// <returns>
        /// true if the system successfully started searching for an interview for the interviewer,
        /// false otherwise.
        /// </returns>
        public bool StartInterview(string surveyId, int interviewId)
        {
            return m_ConsoleServiceChannelFactory.Execute(x => x.StartInterview(surveyId, interviewId));
        }

        /// <summary>
        /// It is the request to create a new interview for the logged in person.
        /// </summary>
        /// <returns>
        /// id of created interview
        /// </returns>
        public int CreateNewInterview(string surveyId)
        {
            return m_ConsoleServiceChannelFactory.Execute(x => x.CreateNewInterview(surveyId));
        }

        /// <summary>
        /// It is the request to call transfer.
        /// </summary>
        public void TransferStart(TransferOptions options)
        {
            m_ConsoleServiceChannelFactory.Execute(x => x.TransferStart(options));
        }

        public InternalTransferTarget[] GetInternalTransferTargets()
        {
            return m_ConsoleServiceChannelFactory.Execute(x => x.GetInternalTransferTargets());
        }

        public ExternalTransferTarget[] GetExternalTransferTargets()
        {
            return m_ConsoleServiceChannelFactory.Execute(x => x.GetExternalTransferTargets());
        }

        /// <summary>
        /// Notifies Fusion if the logged in person wants to logout.
        /// </summary>
        /// <param name="logout">true if the person wants to logout, false if the person wants to continue his/her session</param>
        public void SetPendingLogout(bool logout)
        {
            m_ConsoleServiceChannelFactory.Execute(x => x.SetPendingLogout(logout));
        }

        public void TransferComplete()
        {
            m_ConsoleServiceChannelFactory.Execute(x => x.TransferComplete());
        }

        public void TransferCancel()
        {
            m_ConsoleServiceChannelFactory.Execute(x => x.TransferCancel());
        }

        public void TransferSetConnectionState(TransferConnectionState connectionState)
        {
            m_ConsoleServiceChannelFactory.Execute(x => x.TransferSetConnectionState(connectionState));
        }

        public bool IsInterviewScreenRecordingEnabled(int surveyId)
        {
            return m_MonitoringServiceChannelFactory.Execute(service => service.IsInterviewScreenRecordingEnabled(surveyId));
        }

        public void RemoveRecordIfEmpty(int deferredRecordId)
        {
            m_MonitoringServiceChannelFactory.Execute(service => service.RemoveRecordIfEmpty(deferredRecordId));
        }

        /// <summary>
        /// Informs BE that current interview has been finished.
        /// If exception occurs and it is not CatiException call of method will be repeated
        /// </summary>
        public void WrapUp(int interviewId, bool lookupForNewCalls, CompletedInterviewDetails details)
        {
            CatiServiceRetryManager.Invoke(counter => WrapUp(interviewId, lookupForNewCalls, counter, details), true);
        }

        /// <summary>
        /// CATI console must call this method at the moment when an interview is finished.
        /// </summary>
        public void WrapUp(int interviewId, bool lookUpForNewCalls, int attemptNumber, CompletedInterviewDetails details)
        {
            if (attemptNumber > 1)
            {
                Logger.Write(
                    Strings.ResourceManager.GetString("Log_AttemptToCallMethod", attemptNumber, "WrapUp"),
                    MessageTypes.Information);
            }

            m_ConsoleServiceChannelFactory.Execute(x => x.WrapUp(interviewId, lookUpForNewCalls, attemptNumber, details));
        }

        /// <summary>
        /// The method initiates an interviewer login to the dialler.
        /// CATI console calls this method if there is a dialler in the system.
        /// </summary>
        /// <param name="extensionNumber">The interviewer extension phone number.</param>
        /// <param name="surveyId">Survey Id can be null or empty for AUTOMATIC users.</param>
        /// <param name="isPredictiveMode">Is called for survey in predictive mode?</param>
        /// <remarks>
        /// Confirmit surveyId like pNNNNNNN is used.
        /// Login to dialer operation is asynchronous. CATI console must call GetState method 
        /// to find out if login to MN dialer has finished.
        /// </remarks>
        public void LoginToDialer(string extensionNumber, string surveyId, out bool isPredictiveMode)
        {
            bool isPredictive = false;
            m_ConsoleServiceChannelFactory.Execute(x => x.LoginToDialer(extensionNumber, surveyId, out isPredictive));
            isPredictiveMode = isPredictive;
        }

        /// <summary>
        /// CATI console calls the method at the end of the interviewer session.
        /// CATI console must call it if and only if the interviewer login state becomes NOT_LOGGED_IN
        /// </summary>
        /// <remarks>
        /// It is last method before logout, we should throw exception
        /// </remarks>
        public void ConfirmLogout()
        {
            m_ConsoleServiceChannelFactory.Execute(x => x.ConfirmLogout());
        }

        /// <summary>
        /// CATI console calls the method when [X] button pressed
        /// </summary>
        public void TerminateTask()
        {
            m_ConsoleServiceChannelFactory.Execute(x => x.TerminateTask());
        }

        /// <summary>
        /// Sends Fusion notification that opened review has started.
        /// If exception occurs and it is not CatiException call of method will be repeated
        /// </summary>
        public void SendFusionReviewFlag()
        {
            CatiServiceRetryManager.Invoke(SendFusionReviewFlag, true);
        }

        /// <summary>
        /// Sends Fusion notification that opened review has started.
        /// </summary>
        /// <param name="attemptNumber">Current number of attemps</param>
        public void SendFusionReviewFlag(int attemptNumber)
        {
            if (attemptNumber > 1)
            {
                Logger.Write(
                    Strings.ResourceManager.GetString("Log_AttemptToCallMethod", attemptNumber, "SendFusionReviewFlag"),
                    MessageTypes.Information);
            }

            m_ConsoleServiceChannelFactory.Execute(x => x.GetForceOpenendReview(attemptNumber));
        }

        public void UpdatePersonMode(AgentTaskChoiceMode personMode)
        {
            CatiServiceRetryManager.Invoke(counter => UpdatePersonMode(personMode, counter), true);
        }

        /// <summary>
        /// Updates Person mode for current interviewer
        /// </summary>
        /// <param name="personMode">New person mode</param>
        /// <param name="attemptNumber">The number of the current attempt</param>
        /// <returns></returns>
        public void UpdatePersonMode(AgentTaskChoiceMode personMode, int attemptNumber)
        {
            m_ConsoleServiceChannelFactory.Execute(x => x.UpdatePersonMode((int)personMode));
        }

        /// <summary>
        /// Gets survey languages.
        /// </summary>
        /// <param name="surveyId">Survey id</param>
        public LanguageCollection GetSurveyLanguages(string surveyId)
        {
            return m_ConsoleServiceChannelFactory.Execute(x => x.GetSurveyLanguages(surveyId));
        }

        /// <summary>
        /// Gets collection of interview history objects.
        /// </summary>
        /// <param name="projectId">Project identifier.</param>
        /// <param name="respondentIdentity">Respondent identity.</param>
        /// <param name="languageId">Language identifier.</param>
        /// <returns>Collection of objects.</returns>
        public QuestionHistoryCollection GetInterviewHistory(string projectId, string respondentIdentity, int languageId)
        {
            var interviews = m_ConsoleServiceChannelFactory.Execute(x => x.GetInterviewHistory(projectId, respondentIdentity, languageId));

            return interviews ?? new QuestionHistoryCollection();
        }

        public Guid GenerateAuthenticationKey()
        {
            return m_ConsoleServiceChannelFactory.Execute(x => x.GenerateAuthenticationKey());
        }

        /// <summary>
        /// Sends monitoring events to Monitoring service.
        /// </summary>
        /// <param name="companyId">Company identifier.</param>
        /// <param name="interviewerId">Interviewer identifier.</param>
        /// <param name="monitoringIdentity">Monitoring session identity object.</param>
        /// <param name="packet"></param>
        public void SaveLiveMonitoringEvents(int companyId,
            int interviewerId,
            MonitoringIdentity monitoringIdentity,
            byte[] packet)
        {
            ParameterValidator.GreaterThan(companyId, 0, "companyId");
            ParameterValidator.GreaterThan(interviewerId, 0, "interviewerId");
            ParameterValidator.GreaterThan(packet.Length, 0, "packet");

            try
            {
                var identity = new IdentityObject
                {
                    CompanyID = companyId,
                    InterviewerID = interviewerId,
                    MonitoringSessionID = monitoringIdentity.MonitoringSessionId,
                    DeferredIdentity =
                        (monitoringIdentity.DeferredIdentity == null)
                            ? null
                            : (DeferredIdentityObject)monitoringIdentity.DeferredIdentity
                };

                m_MonitoringServiceChannelFactory.Execute(service => service.SaveLiveMonitoringEvents(identity, packet));
            }
            catch (FaultException<Exception>)
            {
                // Exception thrown by Monitoring WS.
            }
            catch (FaultException)
            {
                // general fault exception
            }
            // ReSharper disable EmptyGeneralCatchClause
            catch
            // ReSharper restore EmptyGeneralCatchClause
            {
                // We log exceptions in WcfExecutor.
            }
        }

        /// <summary>
        /// Sends monitoring events to Monitoring service.
        /// </summary>
        /// <param name="companyId">Company identifier.</param>
        /// <param name="interviewerId">Interviewer identifier.</param>
        /// <param name="monitoringIdentity">Monitoring session identity object.</param>
        /// <param name="packet"></param>
        /// <param name="hasFinishedMessage">if the packet contains one of the finishing events</param>
        /// <param name="firstEventUtc">Utc time of the fist event in the packet</param>
        public void SaveDeferredMonitoringEvents(int companyId,
            int interviewerId,
            MonitoringIdentity monitoringIdentity,
            byte[] packet,
            bool hasFinishedMessage,
            DateTime firstEventUtc)
        {
            ParameterValidator.GreaterThan(companyId, 0, "companyId");
            ParameterValidator.GreaterThan(interviewerId, 0, "interviewerId");
            ParameterValidator.GreaterThan(packet.Length, 0, "packet");

            try
            {
                var identity = new IdentityObject
                {
                    CompanyID = companyId,
                    InterviewerID = interviewerId,
                    MonitoringSessionID = monitoringIdentity.MonitoringSessionId,
                    DeferredIdentity =
                        (monitoringIdentity.DeferredIdentity == null)
                            ? null
                            : (DeferredIdentityObject)monitoringIdentity.DeferredIdentity
                };

                m_MonitoringServiceChannelFactory.Execute(service => service.SaveDeferredMonitoringEvents(identity, packet, hasFinishedMessage, firstEventUtc, DateTime.UtcNow));
            }
            catch (FaultException<Exception>)
            {
                // Exception thrown by Monitoring WS.
            }
            catch (FaultException)
            {
                // general fault exception
            }
            // ReSharper disable EmptyGeneralCatchClause
            catch
            // ReSharper restore EmptyGeneralCatchClause
            {
                // We log exceptions in WcfExecutor.
            }
        }
    }
}
