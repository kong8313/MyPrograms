﻿using System;
using System.Text.RegularExpressions;

namespace Confirmit.CATI.Console.Classes.CheckSpelling
{
    /// <summary>
    /// Helper class for text modification.
    /// </summary>
    public static class TextModifier
    {
        /// <summary>
        /// Removes specified word in the text.
        /// </summary>
        /// <returns>
        /// Returns text after deletion of the word.
        /// </returns>
        public static string DeleteWord(string text, string word, int startIndex)
        {
            var regex = new Regex(word + "\\s?");
            return regex.Replace(text, String.Empty, 1, startIndex);
        }

        /// <summary>
        /// Replaces specified word in the text by the new one.
        /// </summary>
        public static string ChangeWord(string text, string oldWord, string newWord, int startIndex)
        {
            var regex = new Regex(oldWord);
            return regex.Replace(text, newWord, 1, startIndex);
        }

        public static string ChangeAllWords(string text, string oldWord, string newWord)
        {
            var regex = new Regex(String.Format("\\b{0}\\b", oldWord));
            return regex.Replace(text, newWord);
        }

        /// <summary>
        /// Return index of first word from specified position.
        /// </summary>
        /// <param name="text">Text block.</param>
        /// <param name="startIndex">Start position.</param>
        public static int GetFirstWordIndexFromPosition(string text, int startIndex)
        {
            int result = -1;

            var regex = new Regex(@"(?=\b\w)");
            var match = regex.Match(text, startIndex + 1);

            if(match.Success)
            {
                result = match.Index;
            }

            return result;
        }

        /// <summary>
        /// Finds index of word in the text block.
        /// </summary>
        /// <param name="text">Text block.</param>
        /// <param name="word">Word which index is looking for.</param>
        /// <param name="startIndex">Start index in the text block.</param>
        /// <returns></returns>
        public static int GetWordIndex(string text, string word, int startIndex)
        {
            int result = -1;

            var regex = new Regex(String.Format("\\b{0}\\b", word));
            var match = regex.Match(text, startIndex);

            if (match.Success)
            {
               result = match.Index;
            }

            return result;
        }
    }
}