﻿using System;
using System.Collections.Generic;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Services.CatiService;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public class InterviewerAppointmentManager
    {
        public static IEnumerable<string[]> PrepareAppointmentsForBinding(AppointmentCollection interviewerAppointmens,
            TimeZoneInfo timeZoneInfo)
        {
            var appointments = new List<string[]>();

            foreach (Appointment app in interviewerAppointmens)
            {
                var appointmentTimeInterviewer = TimeZoneInfo.ConvertTimeFromUtc(app.AppointmentTime, timeZoneInfo)
                    .ToString("g", LocalizationManager.Instance.CurrentCulture);
                var appointmentTimeRespondent = TimezoneConverter.ConvertTimeFromUtc(app.Timezone, app.AppointmentTime)
                    .ToString("g", LocalizationManager.Instance.CurrentCulture);

                appointments.Add(
                    new string[]
                    {
                        app.ProjectID,
                        app.InterviewId.ToString(),
                        app.ProjectName,
                        appointmentTimeInterviewer,
                        appointmentTimeRespondent,
                        app.Timezone.Name
                    });
            }

            return appointments;
        }
    }
}