﻿using System.Collections.Generic;
using Confirmit.CATI.Common;

using ConfirmitDialerInterface;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    /// <summary>
    /// Helps with interviewer task choice permissions
    /// </summary>
    public static class  TaskChoicePermissionsHelper
    {
        /// <summary>
        /// Returns dictionary with allowed task choices
        /// </summary>
        /// <param name="permissions"></param>
        /// <returns></returns>
        public static Dictionary<string, int> GetAllowed(TaskChoicePermissions permissions)
        {
            Dictionary<string, int>  allowedTaskChoices = new Dictionary<string, int>();

            if ((permissions & TaskChoicePermissions.Automatic) == TaskChoicePermissions.Automatic)
            {
                allowedTaskChoices.Add(StringHelper.GetStringFromEnum(AgentTaskChoiceMode.Automatic), (int)AgentTaskChoiceMode.Automatic);
            }

            if ((permissions & TaskChoicePermissions.Manual) == TaskChoicePermissions.Manual)
            {
                allowedTaskChoices.Add(StringHelper.GetStringFromEnum(AgentTaskChoiceMode.Manual), (int)AgentTaskChoiceMode.Manual);
            }

            if ((permissions & TaskChoicePermissions.SurveyAssignment) == TaskChoicePermissions.SurveyAssignment)
            {
                allowedTaskChoices.Add(StringHelper.GetStringFromEnum(AgentTaskChoiceMode.CampaignAssignment), (int)AgentTaskChoiceMode.CampaignAssignment);
            }

            return allowedTaskChoices;
        }

        /// <summary>
        /// Returns first allowed permission
        /// </summary>
        /// <param name="permissions"></param>
        /// <returns></returns>
        public static AgentTaskChoiceMode GetFirstAllowed(TaskChoicePermissions permissions)
        {            
            if ((permissions & TaskChoicePermissions.Automatic) == TaskChoicePermissions.Automatic)
            {
                return AgentTaskChoiceMode.Automatic;
            }
            else if ((permissions & TaskChoicePermissions.Manual) == TaskChoicePermissions.Manual)
            {
                return AgentTaskChoiceMode.Manual;
            }
            else if ((permissions & TaskChoicePermissions.SurveyAssignment) == TaskChoicePermissions.SurveyAssignment)
            {
                return AgentTaskChoiceMode.CampaignAssignment;
            }

            return AgentTaskChoiceMode.Automatic;
        }
    }
}
