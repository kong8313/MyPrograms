﻿using System;
using Confirmit.CATI.Common;

namespace Confirmit.CATI.Console.Services.CatiService.Exceptions
{
    /// <summary>
    /// Occurs when appointment contradicts exclusion.
    /// </summary>
    class CatiAppContradictsExclusionShiftsException : CatiServiceException
    {
        #region Constructors

        /// <summary>
        /// Initializes new instance of CatiAppContradictsExclusionShiftsException.
        /// </summary>
        public CatiAppContradictsExclusionShiftsException()
            : base()
        {
            Error = CATIErrorCodes.AppContradictsExclusionShifts;
        }

        /// <summary>
        /// Initializes new instance of CatiAppContradictsExclusionShiftsException class and fills if with given data.
        /// </summary>
        /// <param name="message">Message.</param>
        /// <param name="innerException">Inner exception.</param>
        public CatiAppContradictsExclusionShiftsException(string message, Exception innerException)
            : base(message, innerException)
        {
            Error = CATIErrorCodes.AppContradictsExclusionShifts;
        }

        #endregion
    }
}
