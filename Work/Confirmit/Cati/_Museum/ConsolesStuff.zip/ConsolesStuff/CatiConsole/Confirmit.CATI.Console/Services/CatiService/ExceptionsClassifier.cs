﻿using System;
using System.ServiceModel;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.Exceptions;

namespace Confirmit.CATI.Console.Services.CatiService
{
    public static class ExceptionsClassifier
    {
        public static bool IsCommunicationError(Exception ex)
        {
            return !(ex is FaultException<UserMessageExceptionDetails> ||
                     (ex is FaultException && ((FaultException)ex).Code.Name == Constants.InternalServerErrorFaultCode));
        }
    }
}