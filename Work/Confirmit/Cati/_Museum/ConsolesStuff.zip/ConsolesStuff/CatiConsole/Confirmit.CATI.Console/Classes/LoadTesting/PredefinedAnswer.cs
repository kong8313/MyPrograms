﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Confirmit.CATI.Console.Classes.LoadTesting
{
    public class PredefinedAnswers
    {
        public int ResponseId { get; set; }

        public Dictionary<string, string> Answers { get; set; }

        public List<Loop> Loops { get; set; }
    }
}
