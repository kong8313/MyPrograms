using System;
using System.Collections.Generic;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class SearchableMultiQuestionHandler : BaseQuestionHandler, IQuestionHandler
    {
        public SearchableMultiQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers)
            : base(pageBrowser, predefinedAnswers)
        {
        }

        void IQuestionHandler.SetAnswers()
        {
            var keys = GetKeysForNonOther();

            foreach (var key in keys)
            {
                int valueInt;
                try
                {
                    valueInt = Convert.ToInt32(PredefinedAnswers[key]);
                    if (valueInt == 0)
                    {
                        continue;
                    }
                }
                catch (Exception ex)
                {
                    Logger.Write(ex);
                    continue;
                }

                if (Convert.ToBoolean(valueInt) == true)
                {
                    FireClick(string.Format("{0}_", key));
                }
            }

            SetOtherForNonEmpty();
        }
    }
}