﻿using System;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.Telephony;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Shared.Log;

using ConfirmitDialerInterface;

namespace Confirmit.CATI.Console.Presenters
{
    public class BackendTelephonyProvider : ITelephonyProvider
    {
        private readonly ICatiServiceManager _catiServiceManager;
        private const int m_CustomErrorStatus = (int)CallOutcome.Error;
        const int firstTimeoutForDailerOperation = 3000;

        public bool IsCustomDialer
        {
            get { return false; }
        }

        public BackendTelephonyProvider()
        {
            _catiServiceManager = ServiceLocator.Resolve<ICatiServiceManager>();
        }

        /// <summary>
        /// Occurs when we receive telephony command result status.
        /// </summary>
        public event TelephonyResultEventHandler TelephonyResult;

         /// <summary>
        /// Occurs when console logged in to dialer 
        /// </summary>
        /// <remarks>
        /// Initially method LoginToDialer is called
        /// Event occurs when GetState returns Logged_In state
        /// </remarks>
        public event EventHandler<GetStateEventArgs> LoggedToDialerInEvent;

        /// <summary>
        /// Occurs when interviewer is logged out by system
        /// </summary>
        /// <remarks>
        /// Initially method LoginToDialer is called
        /// Event occurs when GetState returns Not_Logged_In state for interviewer
        /// </remarks>
        public event EventHandler<GetStateEventArgs> LogoutWhileLoginToDialerEvent;

        /// <summary>
        /// Occurs when timeout for command LoginToDialer is expired
        /// </summary>
        public event EventHandler<GetStateEventArgs> LoginToDialerErrorEvent;

        public void Dial(string phone, string message)
        {
            try
            {
                // for now initiator should be Script
                AsyncOperationInvoker.Instance.Execute(
                    () => _catiServiceManager.Dial(phone, Initiator.Script),
                    CheckDialStatus,
                    firstTimeoutForDailerOperation);
            }
            catch (Exception ex)
            {
                if (ExceptionsClassifier.IsCommunicationError(ex))
                {
                    throw;
                }

                StopProcessing(m_CustomErrorStatus);
            }
        }

        public void Redial(string phone, string message)
        {
            try
            {
                // for now initiator should be Script
                AsyncOperationInvoker.Instance.Execute(
                    () => _catiServiceManager.Dial(phone, Initiator.MainMenu),
                    CheckDialStatus,
                    firstTimeoutForDailerOperation);
            }
            catch (Exception ex)
            {
                if (ExceptionsClassifier.IsCommunicationError(ex))
                {
                    throw;
                }

                StopProcessing(m_CustomErrorStatus);
            }
        }

        public bool Hangup(Initiator initiator)
        {
            return _catiServiceManager.Hangup(initiator);
        }

        public void LoginToDialer(string number, string surveyId, out bool isPredictiveMode)
        {
            isPredictiveMode = false;

            try
            {
                bool isPredictiveModeTemp = true;

                AsyncOperationInvoker.Instance.Execute(
                    () => _catiServiceManager.LoginToDialer(number, surveyId, out isPredictiveModeTemp),
                    LoginToDialerHandler,
                    firstTimeoutForDailerOperation);

                isPredictiveMode = isPredictiveModeTemp;
            }
            catch (Exception ex)
            {
                Logger.Write(ex);

                var e = new GetStateEventArgs
                {
                    Exception = ex
                };

                OnLoginToDialerErrorEvent(e);
            }
        }
        
        /// <summary>
        /// Starts playback sound file.
        /// </summary>
        /// <param name="soundFile"></param>
        /// <param name="timeOfPlayingInSeconds"></param>
        public void StartPlayback(string soundFile, out int timeOfPlayingInSeconds)
        {
            _catiServiceManager.StartPlayback(soundFile, out timeOfPlayingInSeconds);
        }

        /// <summary>
        /// Pauses or resumes playback sound file.
        /// </summary>
        public void PauseOrResumePlayback()
        {
            _catiServiceManager.PauseOrResumePlayback();
        }

        /// <summary>
        /// Stops playback sound file.
        /// </summary>
        public void StopPlayback()
        {
            _catiServiceManager.StopPlayback();
        }

        /// <summary>
        /// Handles GetStateEvent and checks if state is Ok. If state is Ok
        /// we stop GetState polling (set e.Cancel = true) and stop processing.
        /// Otherwise we continue to poll GetState.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        internal void CheckDialStatus(GetStateEventArgs e)
        {
            if (e.Exception != null)
            {
                // exception occurs during GetState() polling.
                // Return custom error
                StopProcessing(m_CustomErrorStatus);
            }
            else if (e.State == null)
            {
                // timeout expired. Return custom error
                StopProcessing(m_CustomErrorStatus);
            }
            else if (e.State.InterviewState != InterviewState.DIALLING &&
                e.State.InterviewState != InterviewState.REDIALLING)
            {
                // status is not DIALLING, so dialing has finished and return result
                StopProcessing((int)e.State.CallOutcome);
                e.Cancel = true;
            }
        }

        /// <summary>
        /// Stops and releases timer.
        /// </summary>
        /// <param name="errorStatus">Telephony command result status.</param>
        internal void StopProcessing(int errorStatus)
        {
            OnTelephonyResult(new TelephonyResultEventArgs { Status = errorStatus });
        }

        /// <summary>
        /// Fires TelephonyResult event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnTelephonyResult(TelephonyResultEventArgs e)
        {
            if (TelephonyResult != null)
            {
                TelephonyResult(this, e);
            }
        }

         private void OnLoggedToDialerInEvent(GetStateEventArgs e)
        {            
            if (LoggedToDialerInEvent != null)
            {
                LoggedToDialerInEvent(this, e);
            }
        }

        private void OnLoginToDialerErrorEvent(GetStateEventArgs e)
        {            
            if (LoginToDialerErrorEvent != null)
            {
                LoginToDialerErrorEvent(this, e);
            }
        }

        private void OnLogoutWhileLoginToDialerEvent(GetStateEventArgs e)
        {            
            if (LogoutWhileLoginToDialerEvent != null)
            {
                LogoutWhileLoginToDialerEvent(this, e);
            }
        }

        private void LoginToDialerHandler(GetStateEventArgs e)
        {
            if (e.State != null && e.Exception == null)
            {
                if (e.State.interviewerLoginState == LoginState.NOT_LOGGED_IN)
                {
                    AsyncOperationInvoker.Instance.ClearResources();
                    OnLogoutWhileLoginToDialerEvent(e);
                }
                else if (e.State.LoginToDialerState == LoginState.LOGGED_IN)
                {
                    AsyncOperationInvoker.Instance.ClearResources();
                    OnLoggedToDialerInEvent(e);
                }
                else if (e.State.LoginToDialerState == LoginState.NOT_LOGGED_IN)
                {
                    AsyncOperationInvoker.Instance.ClearResources();
                    OnLoginToDialerErrorEvent(e);
                }
            }
            else
            {
                AsyncOperationInvoker.Instance.ClearResources();
                OnLoginToDialerErrorEvent(e);
            }            
        }
    }
}
