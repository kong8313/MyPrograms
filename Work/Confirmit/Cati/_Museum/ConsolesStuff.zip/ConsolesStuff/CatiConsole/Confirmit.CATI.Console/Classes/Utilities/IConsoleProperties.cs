namespace Confirmit.CATI.Console.Classes.Utilities
{
    public interface IConsoleProperties
    {
        int GetStateWsErrorTimeout { get; }

        bool EnableServerLog { get; }
    }
}