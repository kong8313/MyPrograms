﻿using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public static class ApplicationManager
    {
        /// <summary>
        /// Gets a value indicating whether the calling process is associated with a Terminal Services client session
        /// Returns true if the user is associated with Terminal Services client session; otherwise, false.
        /// </summary>        
        public static bool IsTerminalServerSession
        {
            get
            {
                return SystemInformation.TerminalServerSession;
            }
        }

        public static string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        /// <summary>
        /// Gets path to folder where client settings file is stored
        /// </summary>
        /// <remarks>
        /// References to user-specific location, for example:
        /// 'C:\Users\AlexanderZh\AppData\Local\Confirmit\CATI'
        /// </remarks>
        public static string ApplicationUserSpecificPath
        {
            get
            {                
                return string.Format("{0}\\Confirmit\\CATI", Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData));
            }
        }

        /// <summary>
        /// Gets path to common folder where client files are stored
        /// </summary>
        public static string ApplicationCommonPath
        {
            get
            {
                return string.Format("{0}\\Confirmit\\CATI", Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData));
            }
        }

        /// <summary>
        /// Gets name of client settings file
        /// </summary>
        private static string SettingsFilename
        {
            get
            {
                return Properties.Settings.Default.ClientSettingsFileName;
            }
        }        

        /// <summary>
        /// Gets name of client settings file
        /// </summary>
        public static string ClientSettingsUserProfileFilePath
        {
            get
            {
                return Path.Combine(ApplicationManager.ApplicationUserSpecificPath, ApplicationManager.SettingsFilename);
            }
        }

        /// <summary>
        /// Gets name of client settings file located in common location.
        /// </summary>
        public static string ClientSettingsCommonFilePath
        {
            get
            {
                return Path.Combine(ApplicationManager.ApplicationCommonPath, ApplicationManager.SettingsFilename);
            }
        }

        /// <summary>
        /// Gets path to lisence agreement file. If file exists, we consider that user accepted license.
        /// </summary>
        public static string LicenseAgreementFilePath
        {
            get
            {
                return Path.Combine(ApplicationUserSpecificPath, "License Agreement.txt");
            }
        }

        /// <summary>
        /// Gets path to lisence agreement file that's located in old location.        
        /// </summary>
        /// <remarks>
        /// It should be deleted in some time after migration
        /// </remarks>
        public static string OldLicenseAgreementFilePath
        {
            get
            {
                return Path.Combine(ApplicationCommonPath, "License Agreement.txt");                
            }
        }

        /// <summary>
        /// Gets value indicating that license already has been shown.
        /// </summary>
        public static bool HasLicenseAgreementBeenShown
        {
            get
            {
                return File.Exists(LicenseAgreementFilePath);
            }
        }

        /// <summary>
        /// Saves license agreement.
        /// </summary>
        public static void SaveLicenseAgreement()
        {
            if (!File.Exists(LicenseAgreementFilePath))
            {
                using (File.Create(LicenseAgreementFilePath))
                {
                }
            }
        }

        /// <summary>
        /// Gets path to log file
        /// </summary>
        public static string GetLogFilePath(string logPostfix)
        {
            var postfix = string.IsNullOrEmpty(logPostfix) ? string.Empty : string.Format("_{0}", logPostfix);

            return Path.Combine(ApplicationUserSpecificPath,
                string.Format("{0}{1}.log", Path.GetFileNameWithoutExtension(Application.ExecutablePath), postfix));
        }
    }
}
