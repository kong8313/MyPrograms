﻿namespace Confirmit.CATI.Console.Services.CatiService
{
    /// <summary>
    /// Represents enumeration of available fields to search interviews
    /// </summary>
    public enum FilterInterviewsField
    {
        /// <summary>
        /// No search
        /// </summary>        
        None = 0,

        /// <summary>
        /// Search interviews using respondent name.
        /// </summary>
        RespondentName = 1,

        /// <summary>
        /// Search interviews using telephone number.
        /// </summary>
        TelephoneNumber = 2,

        /// <summary>
        /// Search interviews using interview id.
        /// </summary>
        InterviewId = 3
    }
}
