﻿using Confirmit.CATI.Console.Classes.LoadTesting;
using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Console.Presenters;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Views.Forms;
using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Shared.Exceptions;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// 
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                // Add the event handler for handling non-UI thread exceptions to the event. 
                AppDomain.CurrentDomain.UnhandledException +=
                    UnhandledExceptionsHandler.CurrentDomain_UnhandledException;
                // Add the event handler for handling UI thread exceptions to the event.
                Application.ThreadException += UnhandledExceptionsHandler.Application_ThreadException;

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                InitializeServiceLocator();
                var alerter = ServiceLocator.Resolve<IAlerter>();

                AutoPilotArguments autoPilotArguments = null;
                try
                {
                    var argumentsProvider = new ConsoleArgumentsProvider();
                    autoPilotArguments =
                        new AutoPilotArgumentsParser().ParseArguments(argumentsProvider.GetArguments());
                }
                catch (AutopilotArgumentException ex)
                {
                    Logger.Write(ex);
                    alerter.Alert(
                        ex.Message,
                        Strings.Message_CATIConsole,
                        MessageTypes.Error);

                    Application.Exit();
                    return;
                }

                var logPostfix = string.Empty;
                if (autoPilotArguments != null)
                {
                    logPostfix = autoPilotArguments.UserName;
                }
                else if (Environment.GetEnvironmentVariable("CATI_DEV") == "True")
                {
                    logPostfix = Process.GetCurrentProcess().Id.ToString();
                }

                using (var mutex = new Mutex(true, "CatiInterviewerConsole" + logPostfix))
                {
                    try
                    {
                        if (mutex.WaitOne(TimeSpan.FromSeconds(Properties.Settings.Default.RestartTimeout), false) ==
                            false)
                        {
                            alerter.Alert(
                                Strings.Message_AnotherVersionOfApplicationIsAlreadyRun,
                                Strings.Message_CATIConsole,
                                MessageTypes.Information);
                            return;
                        }
                    }
                    catch (AbandonedMutexException)
                    {
                        //Occurs when second instance is waiting the mutex and
                        //first instance exits but acquired mutex isn't released in time.
                        //Because current instance is already mutex owner we can pass this exception.
                    }

                    BrowserRenderingModeConfigurator.Setup(Properties.Settings.Default.BrowserEmulation);

                    var frmMain = (MainForm) ServiceLocator.Resolve<IViewMainForm>();
                    var frmLogin = new LoginForm();
                    var frmChangePassword = new ChangePasswordForm();
                    var frmExtensionNumber = new ExtensionNumberForm();
                    var frmMessagingForm = new MessagingForm();

                    frmMain.LoginForm = frmLogin;
                    frmMain.ChangePasswordForm = frmChangePassword;
                    frmMain.ExtensionNumberForm = frmExtensionNumber;

                    var applicationInitialize = ServiceLocator.Resolve<IInitializeApplication>();
                    applicationInitialize.InitClientSettings();
                    applicationInitialize.InitLogging(logPostfix);

                    var presInterview =
                        new PresenterInterview(frmMain.InterviewPageBrowser, frmMain, frmMain.StatusBarControl,
                            frmMain);

                    ITelephonyProvider telephonyProvider;
                    try
                    {
                        telephonyProvider = new TelephonyProviderFactory().Create();
                    }
                    catch (CustomDialerInitializationException)
                    {
                        alerter.Alert(
                            LocalizationManager.Instance.GetString("Message_UnableToInitializeCustomDialer"),
                            LocalizationManager.Instance.GetString("Caption_UnableToInitializeCustomDialer"),
                            MessageTypes.Error);
                        throw;
                    }

                    var presTelephony =
                        new PresenterTelephony(frmMain.DialControl, frmMain.HangupControl, telephonyProvider);

                    var presMessaging =
                        new PresenterMessaging(frmMessagingForm, frmMain);

                    IOsVersionProvider osVersionProvider = new OsVersionProvider();
                    IEnvironmentValidator environmentValidator = new EnvironmentValidator(
                        osVersionProvider, new LocalMachineRegistryKeyProvider());

                    IConsoleDescriptionProvider consoleDescriptionProvider =
                        new ConsoleDescriptionProvider(environmentValidator, osVersionProvider);

                    var presMain = new PresenterMainForm(
                        presInterview,
                        presTelephony,
                        presMessaging,
                        frmMain,
                        frmLogin,
                        frmChangePassword,
                        frmExtensionNumber,
                        frmMain.SurveyListControl,
                        frmMain.StatusBarControl,
                        frmMain.OnABreakControl,
                        consoleDescriptionProvider,
                        environmentValidator,
                        autoPilotArguments);

                    Application.Run(frmMain);
                }
            }
            catch (Exception e)
            {
                Trace.TraceError(e.ToString());
                Logger.Write(e);
            }
        }

        private static void InitializeServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            var registrator = new ServiceLocatorRegistry();
            registrator.RegisterTypes(serviceLocator);
        }
    }
}
