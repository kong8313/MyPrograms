﻿using System;
using Confirmit.CATI.Console.Services.MonitoringService;

namespace Confirmit.CATI.Console.Classes.Monitoring
{
    /// <summary>
    /// Represents monitoring identity.
    /// </summary>
    public class MonitoringIdentity : IEquatable<MonitoringIdentity>
    {
        /// <summary>
        /// Gets/sets monitoring session identifier.
        /// </summary>
        public long MonitoringSessionId { get; set; }

        /// <summary>
        /// Gets/sets deferred monitoring session identity.
        /// </summary>
        public DeferredIdentity DeferredIdentity { get; set; }

        /// <summary>
        /// Initialiazes new instance of MonitoringIdentity class. Fills MonitoringSessionID with 0.
        /// </summary>
        public MonitoringIdentity()
        {
            MonitoringSessionId = 0;
            DeferredIdentity = null;
        }

        public MonitoringIdentity Clone()
        {
            return new MonitoringIdentity
            {
                MonitoringSessionId = MonitoringSessionId,
                DeferredIdentity = (DeferredIdentity == null) ? null : new DeferredIdentity
                {
                    DeferredRecordId = DeferredIdentity.DeferredRecordId,
                    InterviewId = DeferredIdentity.InterviewId,
                    SurveyId = DeferredIdentity.SurveyId
                }
            };
        }
      
        public bool Equals(MonitoringIdentity other)
        {
            if (other == null)
            {
                return (false);
            }

            if (other.MonitoringSessionId != MonitoringSessionId)
            {
                return (false);
            }

            if (DeferredIdentity == null)
            {
                return (other.DeferredIdentity == null);
            }

            return (DeferredIdentity.Equals(other.DeferredIdentity));
        }
    }
}
