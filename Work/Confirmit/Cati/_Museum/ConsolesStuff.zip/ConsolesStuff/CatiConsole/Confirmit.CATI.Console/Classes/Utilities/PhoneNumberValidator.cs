using System;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public class PhoneNumberValidator
    {
        private const int MaximumLength = 256;  // Some empirical value

        public bool Validate(string phoneNumberOrUri)
        {
            if (String.IsNullOrWhiteSpace(phoneNumberOrUri))
            {
                return false;
            }

            return phoneNumberOrUri.Length <= MaximumLength;
        }
    }
}