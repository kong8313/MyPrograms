﻿using System;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;

namespace Confirmit.CATI.Console.Classes.Monitoring
{
	/// <summary>
	/// Represents class which contains data for StateChanged event of IMonitoring interface.
	/// </summary>
	public class StateChangedEventArgs : EventArgs
	{
		#region Constructors

		/// <summary>
		/// Initializes new instance of StateChangedEventArgs class.
		/// </summary>
		public StateChangedEventArgs()
			: base()
		{
		}

		#endregion

		#region Properties

		/// <summary>
		/// Gets/sets message type of event.
		/// </summary>
		public MonitoringMessageTypes MessageType
		{
			get;
			set;
		}

		/// <summary>
		/// Gets/sets data which contains state of the control which causes
		/// StateChanged event.
		/// </summary>
		public BaseStateData State
		{
			get;
			set;
		}

        public bool IsScreenRecordingEnabled
        {
            get;
            set;
        }

		#endregion
	}
}
