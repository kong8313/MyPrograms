﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Classes.Messaging;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Presenters
{
    /// <summary>
    /// Is responsible for messaging
    /// </summary>
    internal class PresenterMessaging
    {
        #region Fields        

        private bool m_HasMessages = false;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes new instance of PresenterAppointmentForm class and fills it with
        /// given data.
        /// </summary>
        /// <param name="appointmentForm">IViewMessagingForm instance</param>
        /// <param name="mainForm">IViewMainForm instance</param>
        public PresenterMessaging(IViewMessagingForm messagingForm, IViewMainForm mainForm)
        {
            if (messagingForm == null)
            {
                throw new ArgumentNullException("messagingForm");
            }

            if (mainForm == null)
            {
                throw new ArgumentNullException("mainForm");
            }

            MessagingForm = messagingForm;
            MainForm = mainForm;            
            InitEventHandlers();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets/sets instance of IViewAppointmentForm interface.
        /// </summary>
        internal IViewMessagingForm MessagingForm
        {
            get;
            set;
        }

        /// <summary>
        /// Retruns instance of IViewMainForm interface.
        /// </summary>
        internal IViewMainForm MainForm
        {
            get;
            set;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Shows appointment dialog for given interview.
        /// </summary>
        /// <param name="surveyId">Survey identifier.</param>
        /// <param name="interviewId">Interview identifier.</param>
        /// <param name="parent">Parent window handle.</param>
        public void ShowDialog(
            IWin32Window parent
        )
        {
            if (MessagingForm.IsFormVisible == false)
            {                
                FillMessageList();
                MainForm.ChangeToolbarMessagingIcon(false);
                MessagingForm.HideNotification();

                MessagingForm.Localize(LocalizationManager.Instance);
                MessagingForm.Show(parent);
            }
        }

        /// <summary>
        /// Handers new messages receiving
        /// It is called when PMF receives NewMessage flag from KeepAlive
        /// </summary>
        public void NewMessagesHandler(object sender, EventArgs e)
        {
            MessagingManager.Instance.StartDownload();
        }

        /// <summary>
        /// Initializes event handlers.
        /// </summary>
        private void InitEventHandlers()
        {            
            MessagingForm.NotificationClick += new EventHandler<EventArgs>(MessagingForm_NotificationClick);
            MessagingForm.OkClick += new EventHandler<EventArgs>(MessagingForm_OkClick);
            MessagingManager.Instance.MessagesReceived += new EventHandler(Instance_MessagesReceived);
        }
        
        /// <summary>
        /// Gets new available messages and adds them to list
        /// </summary>
        private void FillMessageList()
        {           
            List<SupervisorMessage> msgs = MessagingManager.Instance.GetMessages();

            if (m_HasMessages == false)
            {
                if (msgs.Count > 0)
                {
                    MessagingForm.Clear();
                    m_HasMessages = true;
                }
                else
                {
                    MessagingForm.AddText(LocalizationManager.Instance.GetString("Message_MessagingForm_ThereAreNoMessages"));
                }
            }

            foreach (SupervisorMessage m in msgs)
            {
                MessagingForm.AddMessage(
                    m.SupervisorName, 
                    m.CreateTime.ToLocalTime().ToString("g", LocalizationManager.Instance.CurrentCulture), 
                    m.Body
                );
            }            
        }

        #endregion

        #region Event handlers

        private void MessagingForm_OkClick(object sender, EventArgs e)
        {
            MessagingForm.CloseForm();
        }       

        private void MessagingForm_NotificationClick(object sender, EventArgs e)
        {
            ShowDialog(MainForm);
        }

        private void Instance_MessagesReceived(object sender, EventArgs e)
        {
            if (MessagingForm.IsFormVisible)
            {
                FillMessageList();
            }
            else
            {
                MainForm.ChangeToolbarMessagingIcon(true);
                string ballonBody = PrerareBallonText();                                    
                MessagingForm.ShowNotification(ballonBody);
            }
        }

        /// <summary>        
        /// Returns 20 first symbols of last received message's body
        /// </summary>
        /// <returns></returns>
        private string PrerareBallonText()
        {
            string result = String.Empty;
            SupervisorMessage lastMessage = MessagingManager.Instance.GetLastMessage();

            if (lastMessage != null && 
                !string.IsNullOrEmpty(lastMessage.Body))
            {
                result = (lastMessage.Body.Length > 20) ? lastMessage.Body.Substring(0, 20) : lastMessage.Body;
                result = string.Format("{0} ...", result);
            }

            return result;
        }

        #endregion
    }
}
