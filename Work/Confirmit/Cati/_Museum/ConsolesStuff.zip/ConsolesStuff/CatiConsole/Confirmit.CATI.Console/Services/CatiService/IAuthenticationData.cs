﻿using System;

namespace Confirmit.CATI.Console.Services.CatiService
{
    public interface IAuthenticationData
    {
        Guid AuthenticationKey { get; }
        byte[] EncryptionKey { get; }
        byte[] EncryptionIv { get; }
        string StationId { get; }

        void SetCustomParameters(Guid authenticationKey, byte[] encryptionKey, byte[] encryptionIv, string stationId);
    }
}