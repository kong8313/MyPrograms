using System;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Windows.Forms;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Utilities;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public class ConsoleDescriptionProvider : IConsoleDescriptionProvider
    {
        private const string NotAvailableText = "Not available";

        public ConsoleDescriptionProvider(IEnvironmentValidator environmentValidator, IOsVersionProvider osVersionProvider)
        {
            AssemblyVersion = GetSafe(() => ApplicationManager.AssemblyVersion);

            MachineName = GetSafe(Dns.GetHostName);

            IPAddresses = GetSafe(
                delegate
                {
                    var ipEntry = Dns.GetHostEntry(MachineName);
                    return string.Join(", ", ipEntry.AddressList.Select(item => item.ToString()).ToArray());
                });

            InternetExplorerVersion = GetSafe(
                delegate
                {
                    using (var webBrowser = new WebBrowser())
                    {
                        return webBrowser.Version.ToString();
                    }
                });

            OperatingSystemDescription = Environment.OSVersion.ToString();

            OperatingSystemVersion = osVersionProvider.GetVersion();

            ProcessId = Process.GetCurrentProcess().Id;

            DotNetVersion = environmentValidator.GetDotNetVersion();
        }        

        private DotNetVersion DotNetVersion { get; set; }

        private string AssemblyVersion { get; set; }

        private string MachineName { get; set; }

        private string IPAddresses { get; set; }

        private string InternetExplorerVersion { get; set; }

        private Version OperatingSystemVersion { get; set; }

        public string OperatingSystemDescription { get; set; }

        private int ProcessId { get; set; }

        private string GetSafe(Func<string> valueProvider)
        {
            try
            {
                return valueProvider();
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
                return NotAvailableText;
            }
        }

        public ConsoleDescription GetConsoleDescription()
        {
            return new ConsoleDescription
            {
                ConsoleVersion = AssemblyVersion,
                InternetExplorerVersion = InternetExplorerVersion,
                IPAddresses = IPAddresses,
                LocalTime = DateTime.Now,
                LocalTimezoneName = TimeZoneInfo.Local.ToString(),
                MachineName = MachineName,
                OperatingSystemDescription = OperatingSystemDescription,
                OperatingSystemVersion = OperatingSystemVersion.ToString(),
                ProcessId = ProcessId,
                DotNetVersion = DotNetVersion
            };
        }

        public string GetConsoleDescriptionText()
        {
            return string.Format(
                Strings.ServerLoggingConsoleDescription,
                ProcessId,
                AssemblyVersion,
                MachineName,
                IPAddresses,
                InternetExplorerVersion,
                OperatingSystemDescription,
                TimeZoneInfo.Local,
                DotNetVersion.Release,
                DotNetVersion.Servicing,
                DotNetVersion.Version);
        }

    }
}