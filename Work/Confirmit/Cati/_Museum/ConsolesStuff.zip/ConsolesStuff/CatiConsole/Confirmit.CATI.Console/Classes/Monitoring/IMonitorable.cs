﻿using Confirmit.CATI.Monitoring.Common.StateData;

namespace Confirmit.CATI.Console.Classes.Monitoring
{
    /// <summary>
    /// Represents delegate which handles StateChanged event.
    /// </summary>
    /// <param name="sender">Sender object.</param>
    /// <param name="args">Event arguments.</param>
    /// <param name="sessionId">Monitoring session identifier.</param>
    internal delegate void StateChangedEventHandler(object sender, StateChangedEventArgs args, MonitoringIdentity sessionId);

	/// <summary>
	/// Represents interface of objects which could be monitored by supervisor.
	/// </summary>
	internal interface IMonitorable
	{
		/// <summary>
		/// Occurs when control changes it's state and this change should be
		/// reflected during monitoring.
		/// </summary>
		event StateChangedEventHandler StateChanged;

        /// <summary>
        /// Returns current state of monitorable object.
        /// </summary>
        /// <returns>Object state data.</returns>
        BaseStateData GetState();
	}
}
