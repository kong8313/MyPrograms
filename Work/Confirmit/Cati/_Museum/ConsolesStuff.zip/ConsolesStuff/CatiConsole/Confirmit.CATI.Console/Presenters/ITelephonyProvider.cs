﻿using System;
using Confirmit.CATI.Console.Classes.Telephony;
using Confirmit.CATI.Console.Services.CatiService;

namespace Confirmit.CATI.Console.Presenters
{
    public interface ITelephonyProvider
    {
        bool IsCustomDialer { get; }

        /// <summary>
        /// Occurs when we recieve telephony command result status.
        /// </summary>
        event TelephonyResultEventHandler TelephonyResult;

        /// <summary>
        /// Occurs when console logged in to dialer 
        /// </summary>
        /// <remarks>
        /// Initially method LoginToDialer is called
        /// Event occurs when GetState returns Logged_In state
        /// </remarks>
        event EventHandler<GetStateEventArgs> LoggedToDialerInEvent;

        /// <summary>
        /// Occurs when interviewer is logged out by system
        /// </summary>
        /// <remarks>
        /// Initially method LoginToDialer is called
        /// Event occurs when GetState returns Not_Logged_In state for interviewer
        /// </remarks>
        event EventHandler<GetStateEventArgs> LogoutWhileLoginToDialerEvent;

        /// <summary>
        /// Occurs when timeout for command LoginToDialer is expired
        /// </summary>
        event EventHandler<GetStateEventArgs> LoginToDialerErrorEvent;

        void Dial(string phone, string message);

        void Redial(string phone, string message);

        bool Hangup(Initiator initiator);

        void LoginToDialer(string  number, string  surveyId,out bool  isPredictiveMode);
        
        /// <summary>
        /// Starts playback sound file.
        /// </summary>
        /// <param name="soundFile"></param>
        /// <param name="timeOfPlayingInSeconds"></param>
        void StartPlayback(string soundFile, out int timeOfPlayingInSeconds);

        /// <summary>
        /// Pauses or resumes playback sound file.
        /// </summary>
        void PauseOrResumePlayback();

        /// <summary>
        /// Stops playback sound file.
        /// </summary>
        void StopPlayback();
    }
}