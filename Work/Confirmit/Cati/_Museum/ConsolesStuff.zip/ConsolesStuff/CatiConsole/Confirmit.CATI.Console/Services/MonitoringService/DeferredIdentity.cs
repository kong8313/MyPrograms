﻿using System;
using Confirmit.CATI.Monitoring.Common.Contracts;

namespace Confirmit.CATI.Console.Services.MonitoringService
{
    /// <summary>
    /// Represents identity if deferred monitoring session.
    /// </summary>
    public class DeferredIdentity : IEquatable<DeferredIdentity>
    {
        /// <summary>
        /// Gets/sets deferred monitoring session record identifier.
        /// </summary>
        public int DeferredRecordId { get; set; }

        /// <summary>
        /// Gets/sets survey identifier.
        /// </summary>
        public int SurveyId { get; set; }

        /// <summary>
        /// Gets/sets interview identifier.
        /// </summary>
        public int InterviewId { get; set; }

        /// <summary>
        /// Converts current object to Monitoring Service DeferredIdentityObject.
        /// </summary>
        /// <returns>Monitoring Service deferred identity object.</returns>
        public DeferredIdentityObject ToDeferredIdentityObject()
        {
            return new DeferredIdentityObject
            {
                DeferredRecordId = DeferredRecordId,
                InterviewID = InterviewId,
                SurveySID = SurveyId
            };
        }

        /// <summary>
        /// Converts current object to Monitoring Service DeferredIdentityObject.
        /// </summary>
        /// <param name="obj">Object to convert.</param>
        /// <returns>Monitoring Service deferred identity object.</returns>
        public static explicit operator DeferredIdentityObject(DeferredIdentity obj)
        {
            return obj.ToDeferredIdentityObject();
        }

        public bool Equals(DeferredIdentity other)
        {
            if (other == null)
            {
                return false;
            }

            return ((other.InterviewId == InterviewId) &&
                    (other.SurveyId == SurveyId) &&
                    (other.DeferredRecordId == DeferredRecordId));
        }
    }
}
