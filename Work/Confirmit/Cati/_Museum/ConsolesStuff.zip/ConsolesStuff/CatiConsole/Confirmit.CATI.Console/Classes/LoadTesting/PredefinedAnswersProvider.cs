using System;
using System.Collections.Generic;
using System.Linq;

namespace Confirmit.CATI.Console.Classes.LoadTesting
{
    public class PredefinedAnswersProvider
    {
        private readonly List<PredefinedAnswers> _answersResult;
        private int _currentInterviewNumber = -1;
        private readonly int _timesToRepeat;
        private int _currentIteration = 1;
        private const string ResponseIdField = "responseid";

        public event EventHandler LastInterviewReturned;

        public PredefinedAnswersProvider(IEnumerable<string> lines, IEnumerable<IEnumerable<string>> loopLines, int timesToRepeat)
        {
            _timesToRepeat = timesToRepeat;
            _answersResult = new List<PredefinedAnswers>();
            var enumerable = lines as string[] ?? lines.ToArray();

            var headers = GetValuesFromTabbedString(enumerable.First());

            for (var i = 1; i < enumerable.Count(); i++)
            {
                var answers = ParseLine(enumerable[i], headers);
                int responseId = 0;
                if(answers.ContainsKey(ResponseIdField))
                {
                    int.TryParse(answers[ResponseIdField], out responseId);
                }

                _answersResult.Add(new PredefinedAnswers
                {
                    Answers = answers,
                    ResponseId = responseId
                });
            }

            FillLoopsData(loopLines);
        }

        private void FillLoopsData(IEnumerable<IEnumerable<string>> loopLines)
        {
            if (loopLines == null)
            {
                return;
            }

            var loopsData = loopLines as IEnumerable<string>[] ?? loopLines.ToArray();
            foreach (var loopData in loopsData)
            {
                var loopsAr = loopData as string[] ?? loopData.Where(x => string.IsNullOrWhiteSpace(x) == false).ToArray();

                var lastUsedResponseId = 0;
                var keys = GetValuesFromTabbedString(loopsAr[0]);

                Loop loopAnswersEntity = null;
                var shouldAddToAnswers = true;

                for (var i = 1; i < loopsAr.Count(); i++)
                {
                    var result = ParseLine(loopsAr[i], keys);

                    int responseId = 0;
                    if (result.ContainsKey(ResponseIdField))
                    {
                        int.TryParse(result[ResponseIdField], out responseId);
                    }

                    var answersForResponseId = _answersResult.FirstOrDefault(x => x.ResponseId == responseId);
                    if (answersForResponseId == null)
                    {
                        continue;
                    }

                    if (responseId != lastUsedResponseId)
                    {
                        lastUsedResponseId = answersForResponseId.ResponseId;
                        loopAnswersEntity = new Loop(keys);
                        shouldAddToAnswers = true;
                    }

                    if (answersForResponseId.Loops == null)
                    {
                        answersForResponseId.Loops = new List<Loop>();
                    }
                    
                    if (shouldAddToAnswers)
                    {
                        answersForResponseId.Loops.Add(loopAnswersEntity);
                        shouldAddToAnswers = false;
                    }

                    if (loopAnswersEntity != null)
                    {
                        loopAnswersEntity.Answers.Add(result.Values.ToArray());
                    }
                }
            }
        }

        private string[] GetValuesFromTabbedString(string readLine)
        {
            return readLine.Split('\t');
        }

        private Dictionary<string, string> ParseLine(string s, string[] headers)
        {
            var dic = new Dictionary<string, string>();
            var answers = s.Split('\t');
            for (var i = 0; i < answers.Count(); i++)
            {
                dic.Add(headers[i], answers[i]);
            }
            return dic;
        }

        public PredefinedAnswers GetNextInterviewAnswers()
        {
            _currentInterviewNumber++;
            var result = _answersResult[_currentInterviewNumber];

            // check if we at last interview of iteration now
            if (_currentInterviewNumber == _answersResult.Count - 1)
            {
                if (_currentIteration == _timesToRepeat)
                {
                    DoLastInterviewReturned();
                }
                else
                {
                    _currentIteration++;
                    _currentInterviewNumber = -1;
                }
            }

            return result;
        }

        private void DoLastInterviewReturned()
        {
            if (LastInterviewReturned != null)
            {
                LastInterviewReturned(this, EventArgs.Empty);
            }
        }
    }
}