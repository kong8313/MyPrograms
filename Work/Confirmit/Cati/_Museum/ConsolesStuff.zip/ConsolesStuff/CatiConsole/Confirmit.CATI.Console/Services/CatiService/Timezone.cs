﻿using System;
using Confirmit.CATI.Common;

namespace Confirmit.CATI.Console.Services.CatiService
{
	/// <summary>
	/// Represents time zone. This class is wrapper for CATI Web Service time zone.
	/// </summary>
	public class Timezone
	{
		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
		public Timezone() { }

		/// <summary>
		/// Initialiaze new instance of the Timezone and fills it with the 
		/// given values.
		/// </summary>
		/// <param name="id">Identifier.</param>
		/// <param name="name">Name.</param>
		public Timezone(
			int id,
			string name,
			string standardName,
			int bias,
			DateTime standardDate,
			int standardBias,
			DateTime daylightDate,
			int daylightBias,
			int daylightDayOfWeek,
			int standardDayOfWeek,
            DaylightType daylightType,
            string daylightName
			)
		{
			Id = id;
			Name = name;
			StandardName = standardName;
			Bias = bias;
			StandardBias = standardBias;

			StandardStart = standardDate;
			StandardBias = standardBias;
			DaylightStart = daylightDate;
			DaylightBias = daylightBias;

			DaylightDayOfWeek = daylightDayOfWeek;
			StandardDayOfWeek = standardDayOfWeek;
            DaylightType = daylightType;
            DaylightName = daylightName;
		}

		/// <summary>
		/// Initializes new instance of Timezone and fills it with given data.
		/// </summary>
		/// <param name="timezone"></param>
        public Timezone(Confirmit.CATI.Common.ConsoleService.Abstract.Timezone timezone)
		{
			Id = timezone.Id;
			Name = timezone.Name;
			StandardName = timezone.StandardName;
			Bias = timezone.Bias;
			StandardBias = timezone.StandardBias;
			DaylightBias = timezone.DaylightBias;

			StandardStart = timezone.StandardDate;
			DaylightStart = timezone.DaylightDate;
			DaylightDayOfWeek = timezone.DaylightDayOfWeek;
			StandardDayOfWeek = timezone.StandardDayOfWeek;
            DaylightType = timezone.DaylightType;
            DaylightName = timezone.DaylightName;
		}

		#endregion

		#region Properties
		
		/// <summary>
		/// Identifier.
		/// </summary>
		public int Id 
		{ 
			get; 
			set; 
		}

		/// <summary>
		/// Timezone name.
		/// </summary>
		public string Name
		{
			get;
			set;
		}

		/// <summary>
		/// Timezone standard name.
		/// </summary>
		public string StandardName 
		{ 
			get; 
			set; 
		}

		/// <summary>
		/// The current bias for local time translation on this computer, in minutes. 
		/// The bias is the difference, in minutes, between Coordinated Universal Time (UTC) and local time.
		/// </summary>
		public int Bias
		{
			get;
			set;
		}

		/// <summary>
		/// A date and local time when the transition from daylight saving time to standard time occurs.
		/// </summary>
		public DateTime? StandardStart
		{
			get;
			set;
		}

		/// <summary>
		/// Standard day of week.
		/// </summary>
		public int StandardDayOfWeek 
		{ 
			get; 
			set; 
		}

		/// <summary>
		/// The bias value to be used during local time translations that occur during standard time. 
		/// In most time zones, the value of this member is zero.
		/// </summary>
		public int StandardBias
		{
			get;
			set;
		}

		/// <summary>
		/// Daylight day of week.
		/// </summary>
		public int DaylightDayOfWeek 
		{ 
			get; 
			set; 
		}

		/// <summary>
		/// A date and local time when the transition from standard time to daylight saving time occurs.
		/// </summary>
		public DateTime? DaylightStart
		{
			get;
			set;
		}

		/// <summary>
		/// The bias value to be used during local time translations that occur during daylight saving time.
		/// </summary>
		public int DaylightBias
		{
			get;
			set;
		}

        /// <summary>
        /// Gets/sets timezone daylight type.
        /// </summary>
        public DaylightType DaylightType
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets daylight name.
        /// </summary>
        public string DaylightName
        {
            get;
            set;
        }

		#endregion
	}
}
