﻿using System;
using System.Diagnostics;
using System.Threading;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Common.Exceptions;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public class KeepAliver : IKeepAliver
    {
        private readonly ILogger _logger;
        private readonly IViewMainForm _mainForm;
        private ManualResetEvent _stopKeepAliveEvent;

        public KeepAliver(ILogger logger, IViewMainForm mainForm)
        {
            _logger = logger;
            _mainForm = mainForm;
        }

        /// <summary>
        /// Starts new thread for KeepAlive() CATI Web Service method.
        /// This method is used as "ping" method.
        /// Ping interval is calculated by certain algorithm:
        /// 1. "MessageInterval" property from Web Service, if exists; otherwise
        /// 2. "KeepAliveInterval" setting from application config file, if exists; otherwise
        /// 3. 10 seconds.
        /// </summary>
        public void StartKeepAliveThread(CatiConsolePropertiesContainer properties, SendOrPostCallback newMessageCallback, SendOrPostCallback logoutCallback, SendOrPostCallback saveKeepAliveDuration)
        {
            NewMessageFromKeepAlive = newMessageCallback;
            LogoutFromKeepAlive = logoutCallback;
            SaveKeepAliveDuration = saveKeepAliveDuration;

            /* keep alive timeout interval in seconds. The default value is 10.
             * You could rewrite it in application configuration file in 
             * KeepAliveInterval setting key.
             */
            int keepAliveTimeout = Properties.Settings.Default.KeepAliveInterval;
            if (properties != null)
            {
                // if message interval was given us from CATI Web Service, we should use it
                keepAliveTimeout = properties.MessageInterval;
            }

            _stopKeepAliveEvent = new ManualResetEvent(false);
            var thread = new Thread(KeepAliveThread) { IsBackground = true };
            thread.Start(keepAliveTimeout);
        }

        public void ClearResources()
        {
            if (_stopKeepAliveEvent != null)
            {
                _stopKeepAliveEvent.Set();
                _stopKeepAliveEvent.Close();
                _stopKeepAliveEvent = null;
            }
        }

        public SendOrPostCallback LogoutFromKeepAlive { get; set; }

        public SendOrPostCallback NewMessageFromKeepAlive { get; set; }

        public SendOrPostCallback SaveKeepAliveDuration { get; set; }

        /// <summary>
        /// Thread function which call KeepAlive Web Service method.
        /// </summary>
        /// <param name="threadInterval">Calls interval in seconds.</param>
        private void KeepAliveThread(object threadInterval)
        {
            int interval = (int)threadInterval;
            bool keepErrors = true;
            var watch = new Stopwatch();

            try
            {
                while (!_stopKeepAliveEvent.WaitOne(new TimeSpan(0, 0, interval), false))
                {
                    try
                    {
                        watch.Restart();
                        KeepAliveResult result = CatiServiceManagerWrapper.KeepAlive();
                        _mainForm.SynchronizationContext.Post(SaveKeepAliveDuration, watch.ElapsedMilliseconds);

                        _logger.Log(result.ToString(), TraceEventType.Information);

                        lock (UserPassport.Instance)
                        {
                            UserPassport.Instance.UserId = result.UserId;
                        }

                        UserPassport.Instance.SetMonitoringOptions(result.IsMonitoring, result.MonitoringSessionId);


                        if (result.NewMessage)
                        {
                            _mainForm.SynchronizationContext.Post(NewMessageFromKeepAlive, null);
                        }
                    }
                    catch (InterviewerNotLoggedInException)
                    {
                        _mainForm.SynchronizationContext.Post(LogoutFromKeepAlive, null);
                        break;
                    }
                    catch (StateServiceSessionExpiredException)
                    {
                        // it's legitimate exception if state service session
                        // has expired, so we won't do anything
                    }
                    catch (Exception ex)
                    {
                        _mainForm.SynchronizationContext.Post(SaveKeepAliveDuration, 0);

                        if (keepErrors)
                        {
                            _logger.Log(ex);
                            // we log keep alive error message only once
                            keepErrors = false;
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Very rare we could get Null Reference Exception during the logout process as during the logout process we do set _stopKeepAliveEvent to null
                // So here we will just catch and ignore an error
            }
        }
    }
}
