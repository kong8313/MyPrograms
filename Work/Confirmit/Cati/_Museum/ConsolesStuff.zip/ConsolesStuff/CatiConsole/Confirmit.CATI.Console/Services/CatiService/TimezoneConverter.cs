﻿using System;
using System.Collections.Generic;
using Confirmit.CATI.Common;

namespace Confirmit.CATI.Console.Services.CatiService
{
	/// <summary>
	/// Represents class which converts time in different time zones to UTC and vice versa.
	/// </summary>
	public class TimezoneConverter
	{
        #region Fields

        private static readonly DateTime BaseDateOfAdjustmentRuleTime =
                new DateTime(0001, 01, 01, 00, 00, 00, DateTimeKind.Unspecified);//0001-01-01T00:00:00Z

        #endregion

        #region Methods


        /// <summary>
        /// Converts local time in given time zone to UTC time.
        /// This function trims date milliseconds because we do not
        /// need milliseconds in Backend.
        /// </summary>
        /// <param name="timezone">Time zone.</param>
        /// <param name="localTime">Local time.</param>
        /// <returns>UTC time.</returns>
        public static DateTime ConvertTimeToUtc(Timezone timezone, DateTime localTime)
        {
            TimeZoneInfo info = GetTimezoneInfo(timezone);
            localTime = new DateTime(
                localTime.Year,
                localTime.Month,
                localTime.Day,
                localTime.Hour,
                localTime.Minute,
                localTime.Second,
                DateTimeKind.Unspecified);
            return TimeZoneInfo.ConvertTimeToUtc(localTime, info);
        }

        /// <summary>
        /// Converts given UTC time to local time in given time zone.
        /// This function trims date milliseconds because we do not
        /// need milliseconds in Backend.
        /// </summary>
        /// <param name="timezone">Time zone.</param>
        /// <param name="utcTime">UTC time.</param>
        /// <returns>Date in given time zone.</returns>
        public static DateTime ConvertTimeFromUtc(Timezone timezone, DateTime utcTime)
        {
            TimeZoneInfo info = GetTimezoneInfo(timezone);
            utcTime = new DateTime(
                utcTime.Year,
                utcTime.Month,
                utcTime.Day,
                utcTime.Hour,
                utcTime.Minute,
                utcTime.Second,
                utcTime.Kind);
            return TimeZoneInfo.ConvertTimeFromUtc(utcTime, info);
        }

        /// <summary>
        /// Constructs TimeZoneInfo object for given time zone. Creates new TimeZoneInfo object
        /// according time zone data.
        /// </summary>
        /// <param name="timezone">Time zone.</param>
        /// <returns>TimeZoneInfo object.</returns>
        public static TimeZoneInfo GetTimezoneInfo(Timezone timezone)
        {
            var adjustmentRule = new List<TimeZoneInfo.AdjustmentRule>();

            switch (timezone.DaylightType)
            {
                case DaylightType.Disable:
                    break;
                case DaylightType.Absolute:
                    adjustmentRule.Add(
                        TimeZoneInfo.AdjustmentRule.CreateAdjustmentRule(
                            DateTime.MinValue.Date,
                            DateTime.MaxValue.Date,
                            TimeSpan.FromMinutes(-timezone.DaylightBias),
                            TimeZoneInfo.TransitionTime.CreateFixedDateRule(
                                BaseDateOfAdjustmentRuleTime + timezone.DaylightStart.Value.TimeOfDay,
                                timezone.DaylightStart.Value.Month,
                                timezone.DaylightStart.Value.Day),
                            TimeZoneInfo.TransitionTime.CreateFixedDateRule(
                                BaseDateOfAdjustmentRuleTime + timezone.StandardStart.Value.TimeOfDay,
                                timezone.StandardStart.Value.Month,
                                timezone.StandardStart.Value.Day)
                        ));
                    break;
                case DaylightType.Relative:
                    adjustmentRule.Add(
                        TimeZoneInfo.AdjustmentRule.CreateAdjustmentRule(
                            DateTime.MinValue.Date,
                            DateTime.MaxValue.Date,
                            TimeSpan.FromMinutes(-timezone.DaylightBias),
                            TimeZoneInfo.TransitionTime.CreateFloatingDateRule(
                                BaseDateOfAdjustmentRuleTime + timezone.DaylightStart.Value.TimeOfDay,
                                timezone.DaylightStart.Value.Month,
                                timezone.DaylightStart.Value.Day,//number of week
                                (DayOfWeek)timezone.DaylightDayOfWeek),
                            TimeZoneInfo.TransitionTime.CreateFloatingDateRule(
                                BaseDateOfAdjustmentRuleTime + timezone.StandardStart.Value.TimeOfDay,
                                timezone.StandardStart.Value.Month,
                                timezone.StandardStart.Value.Day, //number of week
                                (DayOfWeek)timezone.StandardDayOfWeek)
                        ));
                    break;
                default:
                    throw new NotSupportedException(
                        String.Format("DaylightType for Timezone with ID = {0} is invalid", timezone.Id));
            }

            return TimeZoneInfo.CreateCustomTimeZone(
                timezone.StandardName,
                TimeSpan.FromMinutes(-timezone.Bias),
                timezone.Name,
                timezone.StandardName,
                timezone.DaylightName,
                adjustmentRule.ToArray());
        }

        #endregion
    }
}
