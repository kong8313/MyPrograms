﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Resources;

namespace Confirmit.CATI.Console.Services.CatiService
{
    internal class AsyncOperationInvoker
    {
        private const int m_TimerInterval = 1000; // 1 sec.         

        private Timer m_Timer;
        private Int32 m_TimeElapsed;

        private static AsyncOperationInvoker m_Instance;
        private readonly Stopwatch m_GetStateWSErrorElapsed = new Stopwatch();
        private bool m_IsFirstTimeTick;

        /// <summary>
        /// Gets singleton instance of AsyncServiceManager
        /// </summary>
        public static AsyncOperationInvoker Instance
        {
            get { return m_Instance ?? (m_Instance = new AsyncOperationInvoker()); }
        }

        /// <summary>
        /// Gets flag indicating is operation in progress or not.
        /// </summary>
        public bool IsInProgress
        {
            get
            {
                return m_Timer != null;
            }
        }

        /// <summary>
        /// Method is responsible for clear used resources
        /// </summary>
        /// <remarks>
        /// </remarks>
        public void ClearResources()
        {
            StopTimer();
            GetStateHandler = null;
        }

        /// <summary>
        /// Gets/sets method that will be handler GetState event.
        /// </summary>
        private Action<GetStateEventArgs> GetStateHandler
        {
            get;
            set;
        }

        /// <summary>
        /// Returns timeout for GetState operation in millisecond
        /// </summary>
        /// <remarks>
        /// If App.config it represented in seconds
        /// </remarks>
        private int GetStateTimeOut
        {
            get
            {
                return Properties.Settings.Default.GetStateTimeout * 1000;
            }
        }

        public void Execute(Action action, Action<GetStateEventArgs> eventHandler)
        {
            Execute(action, eventHandler, m_TimerInterval);
        }

        public void Execute(Action action, Action<GetStateEventArgs> eventHandler, int firstTimeout)
        {
            if (IsInProgress)
            {
                throw new InvalidOperationException(String.Format(Strings.Exception_AnotherAsynchronousOperationIsExecuted,
                                                                  eventHandler.Method,
                                                                  GetStateHandler.Method));
            }

            if (action != null)
            {
                action();
            }

            Init(eventHandler, firstTimeout);
        }

        /// <summary>
        /// Initializes polling and starts it.
        /// </summary>
        /// <param name="eventHandler">Event handler delegate.</param>
        /// <param name="firstTimeInterval">Timeout before first timer tick.</param>
        private void Init(Action<GetStateEventArgs> eventHandler, int firstTimeInterval)
        {
            GetStateHandler = eventHandler;
            StartTimer(firstTimeInterval);
        }

        /// <summary>
        /// Calls GetStateEventHandler
        /// </summary>
        /// <remarks>
        /// Called on each GetState call
        /// If GetStateEventHandler return true finish execution
        /// If timeElapsed exceed GetStateTimeOut calls StopTimer() and
        /// calls GetStateEventHanler with null parameter
        /// </remarks>
        /// <param name="e">contains GetState data</param>
        private void OnGetState(GetStateEventArgs e)
        {
            if (GetStateHandler != null)
            {
                GetStateHandler(e);
            }
        }

        /// <summary>
        /// Initializes and starts timer.
        /// </summary>
        private void StartTimer(int firstTimeInterval)
        {
            m_TimeElapsed = 0;
            m_IsFirstTimeTick = true;
            m_Timer = new Timer { Interval = firstTimeInterval };
            m_Timer.Tick += m_Timer_Tick;
            m_Timer.Start();
        }

        /// <summary>
        /// Stops and releases timer.
        /// </summary>
        private void StopTimer()
        {
            if (m_Timer == null) return;

            m_Timer.Stop();
            m_Timer.Tick -= m_Timer_Tick;
            m_Timer.Dispose();
            m_Timer = null;
        }

        /// <summary>
        /// Timer tick event handler
        /// Calls WS.GetState() on each tick
        /// </summary>
        private void m_Timer_Tick(object sender, EventArgs e)
        {
            m_TimeElapsed += m_Timer.Interval;

            if (m_IsFirstTimeTick)
            {
                m_Timer.Interval = m_TimerInterval;
                m_IsFirstTimeTick = false;
            }

            m_Timer.Enabled = false;

            var args = new GetStateEventArgs();

            try
            {
                args.State = ServiceLocator.Resolve<ICatiServiceHelper>().GetState();

                m_GetStateWSErrorElapsed.Reset();
            }
            catch (Exception ex)
            {
                //Enable time to enable next tick
                if (m_Timer != null) m_Timer.Enabled = true;

                if (m_GetStateWSErrorElapsed.IsRunning == false)
                {
                    m_GetStateWSErrorElapsed.Start();
                }
                else if (DoesGetStateWSErrorTimeoutExpire())
                {
                    StopTimer();
                    args.Exception = ex;
                    OnGetState(args);
                }

                return;
            }

            OnGetState(args);

            if (args.Cancel)
            {
                StopTimer();
            }
            else
            {
                if (m_TimeElapsed > GetStateTimeOut)
                {
                    StopTimer();
                    OnGetState(new GetStateEventArgs { State = null });
                }
            }

            if (m_Timer != null) m_Timer.Enabled = true;
        }


        /// <summary>
        /// Returns true, if calls to web service have finished with exception
        /// during 'GetStateWSErrorTimeout' timeout.        
        /// </summary>
        /// <returns>true, if timeout has expired; ohterwise false.</returns>        
        private bool DoesGetStateWSErrorTimeoutExpire()
        {
            return (m_GetStateWSErrorElapsed.ElapsedMilliseconds / 1000 > Properties.Settings.Default.GetStateWSErrorTimeout);
        }
    }
}
