﻿using System;
using System.Data;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Classes.Monitoring;
using ConfirmitDialerInterface;
using ConsoleSearchParameter = Confirmit.CATI.Console.Shared.Utilities.ConsoleSearchParameter;

namespace Confirmit.CATI.Console.Services.CatiService
{
    public interface ICatiServiceManager
    {
        UserProperties Login(string stationId, string userName, string userPassword, int companyId,
            ConsoleDescription consoleDescription);

        void SetPendingLogout(bool logout);

        SurveyCollection GetSurveys();

        bool StartInterview(string surveyId, int interviewId);

        int CreateNewInterview(string surveyId);

        QuestionHistoryCollection GetInterviewHistory(string projectId, string respondentIdentity, int languageId);

        LanguageCollection GetSurveyLanguages(string surveyId);

        void ToggleInterviewerListensToPlaybackOrRespondent();

        ProcessState GetState();

        void Dial(string phone, Initiator initiator);

        bool Hangup(Initiator initiator);

        Guid GenerateAuthenticationKey();

        void WrapUp(int interviewId, bool lookupForNewCalls, CompletedInterviewDetails details);

        void WrapUp(int interviewId, bool lookUpForNewCalls, int attemptNumber, CompletedInterviewDetails details);

        void Dial(string phone, Initiator initiator, int attemptNumber);

        void SendFusionReviewFlag(int attemptNumber);

        void Release();

        DataTable GetInterviews(string surveyId, ConsoleSearchParameter[] searchParameters);

        Appointment GetAppointment(string surveyId, int interviewId);

        Timezone GetInterviewTimezone(string surveyId, int interviewId);

        AppointmentCollection GetInterviewerAppointments();

        SupervisorMessageCollection GetMessages();

        SpellError[] CheckTextSpelling(int languageId, string textBlock);

        bool SetPendingBreakStatus(bool enabled, int? breakType);

        void ContinueWorkAfterBreak();

        void ContinueWorkAfterBreakInternal(int attemptNumber);

        void SetAppointment(string surveyId, int interviewId, Appointment appointment, bool allowOutsideShift);

        AgentTaskChoiceMode GetPersonMode();

        KeepAliveResult KeepAlive();

        void StartPlayback(string filename, out int timeOfPlayingInSeconds);

        void PauseOrResumePlayback();

        void StopPlayback();

        void LoginToDialer(string extensionNumber, string surveyId, out bool isPredictiveMode);

        void ConfirmLogout();

        void TerminateTask();

        void SendFusionReviewFlag();

        void UpdatePersonMode(AgentTaskChoiceMode personMode);

        void UpdatePersonMode(AgentTaskChoiceMode personMode, int attemptNumber);

        void SaveLiveMonitoringEvents(int companyId,
            int interviewerId,
            MonitoringIdentity monitoringIdentity,
            byte[] packet);

        void SaveDeferredMonitoringEvents(int companyId,
            int interviewerId,
            MonitoringIdentity monitoringIdentity,
            byte[] packet,
            bool hasFinishedMessage,
            DateTime firstEventUtc);

        void TransferStart(TransferOptions options);

        InternalTransferTarget[] GetInternalTransferTargets();

        ExternalTransferTarget[] GetExternalTransferTargets();

        void TransferComplete();

        void TransferCancel();

        void TransferSetConnectionState(TransferConnectionState connectionState);

        bool IsInterviewScreenRecordingEnabled(int surveyId);

        void RemoveRecordIfEmpty(int deferredRecordId);
    }
}