﻿using System;
using System.ServiceModel;
using Confirmit.CATI.Common.Exceptions;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.Console.Services.CatiService
{
    internal class CatiStateServiceSessionProlonger
    {
        private readonly object _lockObject = new object();
        private readonly Action _postProcessor;

        public CatiStateServiceSessionProlonger(Action postProcessor)
        {
            if (postProcessor == null)
            {
                throw new ArgumentNullException("postProcessor");
            }

            _postProcessor = postProcessor;
        }

        public T ExecuteWithSessionProlongation<T>(Func<T> func)
        {
            lock (_lockObject)
            {
                try
                {
                    return func();
                }
                catch (StateServiceSessionExpiredException)
                {
                    UpdateAuthenticationKey();
                    throw;
                }
                catch (EndpointNotFoundException)
                {
                    _postProcessor();
                    throw;
                }
            }
        }

        private void UpdateAuthenticationKey()
        {
            var catiServiceManager = ServiceLocator.Resolve<ICatiServiceManager>();
            Logger.Write("State service session has expired", MessageTypes.Information);
            UserPassport.Instance.Properties.UpdateAuthenticationKey(catiServiceManager.GenerateAuthenticationKey());
            Logger.Write("State service session has been successfully prolonged", MessageTypes.Information);

            _postProcessor();
        }
    }
}
