﻿using System;
using Confirmit.CATI.Common;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Services.CatiService;

using ConfirmitDialerInterface;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    /// <summary>
    /// Helps with getting user-friendly strings.
    /// </summary>
    public static class StringHelper
    {
        /// <summary>
        /// Converts InterviewState enumeration value to user-friendly string.
        /// </summary>
        /// <remarks>
        /// It is used to show user-friendly message in process control.
        /// </remarks>
        /// <param name="enumValue">value of InterviewState</param>
        /// <returns>user-friendly value</returns>
        public static string GetStringFromEnum(InterviewState enumValue)
        {
            switch(enumValue)
            {
                case InterviewState.DIALLING:
                    return LocalizationManager.Instance.GetString("Message_Dialing");
                case InterviewState.INTERVIEW_WRAP_UP:
                    return LocalizationManager.Instance.GetString("Message_InterviewWrapUp");
                case InterviewState.INTERVIEWING:
                    return LocalizationManager.Instance.GetString("Message_Inteviewing");
                case InterviewState.NO_CALLS:
                    return LocalizationManager.Instance.GetString("Message_NoCalls");
                case InterviewState.OPENEND_REVIEW:
                    return LocalizationManager.Instance.GetString("Message_OpenEndReview");
                case InterviewState.SELECTING:
                    return LocalizationManager.Instance.GetString("Message_InterviewSelecting");
                case InterviewState.WAITING:
                    return LocalizationManager.Instance.GetString("Message_Waiting");
                case InterviewState.REDIALLING:
                    return LocalizationManager.Instance.GetString("Message_Redialling");
                default:
                    return enumValue.ToString();
            }
        }

        /// <summary>
        /// Converts FilterInterviewsField enumeration value to user-friendly string.
        /// </summary>
        /// <remarks>
        /// It is used to show localiezed user-friendly message in process control.
        /// </remarks>
        public static string GetStringFromEnum(FilterInterviewsField enumValue)
        {
            switch (enumValue)
            {
                case FilterInterviewsField.InterviewId:
                    return LocalizationManager.Instance.GetString("SurveyList_FilterField_InterviewId") ?? enumValue.ToString();
                case FilterInterviewsField.RespondentName:
                    return LocalizationManager.Instance.GetString("SurveyList_FilterField_RespondentName") ?? enumValue.ToString();
                case FilterInterviewsField.TelephoneNumber:
                    return LocalizationManager.Instance.GetString("SurveyList_FilterField_TelephoneNumber") ?? enumValue.ToString();
                case FilterInterviewsField.None:
                    return LocalizationManager.Instance.GetString("SurveyList_FilterField_None") ?? String.Empty;
                default:
                    return enumValue.ToString();
            }
        }

        /// <summary>
        /// Converts CATIProblemState enumeration value to user-friendly string.
        /// </summary>        
        /// <returns>user-friendly value</returns>
        public static string GetStringFromEnum(AgentTaskChoiceMode enumValue)
        {
            switch (enumValue)
            {
                case AgentTaskChoiceMode.Automatic:
                    return LocalizationManager.Instance.GetString("TaskChoiceDropDown_TaskChoiceAutomatic");
                case AgentTaskChoiceMode.Manual:
                    return LocalizationManager.Instance.GetString("TaskChoiceDropDown_TaskChoiceManualSelection");
                case AgentTaskChoiceMode.CampaignAssignment:
                    return LocalizationManager.Instance.GetString("TaskChoiceDropDown_TaskChoiceSurveySelection");
                case AgentTaskChoiceMode.Choice:
                    return LocalizationManager.Instance.GetString("TaskChoiceDropDown_TaskChoiceChoice");
                default:
                    return String.Empty;
            }
        }
    }
}
