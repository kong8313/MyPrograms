using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Console.Views.Controls;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using mshtml;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class GridQuestionHandler : BaseQuestionHandler, IQuestionHandler
    {
        private readonly ILegacySurveyPageInteractor _interactor;

        public GridQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers)
            : base(pageBrowser, predefinedAnswers)
        {
            _interactor = (ILegacySurveyPageInteractor) PageBrowser.SurveyPageInteractor;
        }

        protected List<IHTMLElement> GetSubQuestionsInputs()
        {
            var currentQuestionSubquestions = _interactor.CurrentQuestionSubQuestions;
            if (currentQuestionSubquestions == null || currentQuestionSubquestions.Count == 0)
            {
                return new List<IHTMLElement>();
            }

            var inputs = new List<IHTMLElement>();
            foreach (var subquestionInputs in currentQuestionSubquestions.Select(x => x.InputElements).ToArray())
            {
                inputs.AddRange(subquestionInputs);
            }

            return inputs;
        }

        void IQuestionHandler.SetAnswers()
        {
            var keys = GetKeysForNonOther();

            var subinputs = GetSubQuestionsInputs();

            foreach (var key in keys)
            {
                var input = subinputs.FirstOrDefault(x => x.id.Equals(key, StringComparison.OrdinalIgnoreCase));
                if (input != null && input.tagName.Equals("select", StringComparison.OrdinalIgnoreCase))
                {
                    SetAnswer(key, PredefinedAnswers[key]);
                }
                else
                {
                    SetAnswer(string.Format("{0}_{1}", key, PredefinedAnswers[key]), "true");
                }
            }

            SetOtherForNonEmpty();
        }
    }
}