﻿namespace Confirmit.CATI.Console.Services.CatiService
{
    public interface ICatiServiceHelper
    {
        event GetStateErrorEventHandler GetStateError;

        ProcessState GetState();

        void GetState(int attemptNumber, out ProcessState state);

        bool? IsInterviewScreenRecordingEnabled(int surveyId);
    }
}