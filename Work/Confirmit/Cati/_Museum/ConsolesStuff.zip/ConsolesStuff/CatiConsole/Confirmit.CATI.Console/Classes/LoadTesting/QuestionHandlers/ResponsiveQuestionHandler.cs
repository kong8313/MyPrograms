using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Views.Controls;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class ResponsiveQuestionHandler : BaseQuestionHandler, IQuestionHandler
    {
        private readonly CultureInfo _locale;
        private readonly IResponsiveSurveyPageInteractor _interactor;

        public ResponsiveQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers, CultureInfo locale)
            : base(pageBrowser, predefinedAnswers)
        {
            _locale = locale;
            _interactor = (IResponsiveSurveyPageInteractor)PageBrowser.SurveyPageInteractor;
        }

        void IQuestionHandler.SetAnswers()
        {
            try
            {
                var keys =
                    PredefinedAnswers.Keys.Where(
                        x => x.StartsWith($"{QuestionId}_") && !x.EndsWith("other")).ToList();

                var keysOther =
                    PredefinedAnswers.Keys.Where(
                        x => x.StartsWith($"{QuestionId}_") && x.EndsWith("other")).ToList();

                var key = PredefinedAnswers.Keys.FirstOrDefault(x => x.Equals(QuestionId));
                var questionType = GetQuestionType();

                if (keys.Any())
                {
                    foreach (var answer in keys)
                    {
                        var value = PredefinedAnswers[answer];
                        var precode = answer.Split('_')[1];

                        if (questionType == "Grid3d")
                        {
                            var innerQuestionId = $"{QuestionId}_{precode}";
                            var innerPrecode = answer.Split('_')[2];

                            PageBrowserUpdater.Run(() =>
                            _interactor.SetBoolValueForInnerQuestion(
                                QuestionId,
                                innerQuestionId,
                                innerPrecode,
                                value == "1"));
                        }
                        else if (questionType == "Multi")
                        {
                            PageBrowserUpdater.Run(() => _interactor.SetBoolValue(QuestionId, value == "1", precode));
                        }
                        else
                        {
                            PageBrowserUpdater.Run(() => _interactor.SetStringValue(QuestionId, value, precode));
                        }
                    }

                    ValueWasSet = true;

                    ProcessOtherAnswers(keysOther);
                }
                else if (key != null)
                {
                    var value = PredefinedAnswers[key];
                    if (questionType == "Date")
                    {
                        value = GetFormattedDate(value);
                    }

                    PageBrowserUpdater.Run(() => _interactor.SetStringValue(QuestionId, value));
                    ValueWasSet = true;

                    ProcessOtherAnswers(keysOther);
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
                ValueWasSet = false;
            }
        }

        private void ProcessOtherAnswers(List<string> keysOther)
        {
            if (keysOther.Any())
            {
                foreach (var other in keysOther)
                {
                    var precode = other.Split('_')[1];
                    PageBrowserUpdater.Run(() =>
                        _interactor.SetOtherValue(
                            QuestionId, precode, PredefinedAnswers[other]));
                }
            }
        }

        private string GetFormattedDate(string value)
        {
            var datePattern = "yyyy-MM-dd";

            var dateValue = DateTime.Parse(value, _locale);
            value = dateValue.ToString(datePattern);

            return value;
        }

        private string GetQuestionType()
        {
            var questionType = "";
            PageBrowserUpdater.Run(() =>
                {
                    questionType =
                        _interactor.GetQuestionType(QuestionId);
                });

            return questionType;
        }
    }
}