﻿using System;
using System.ComponentModel;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Services.CatiService;

namespace Confirmit.CATI.Console.Classes.CheckSpelling
{
    /// <summary>
    /// Provides asynchronious access for spell check service.
    /// </summary>
    public class SpellCheckService : ISpellCheckService
    {
        private readonly int languageId = 0;
        private readonly BackgroundWorker m_SpellCheckerWorker;        

        public SpellCheckService(int languageId)
        {
            this.languageId = languageId;

            m_SpellCheckerWorker = new BackgroundWorker();
            m_SpellCheckerWorker.DoWork += m_SpellCheckerWorker_DoWork;
            m_SpellCheckerWorker.RunWorkerCompleted += m_SpellCheckerWorker_RunWorkerCompleted;            
        }

        public event EventHandler<SpellCheckErrorEventArgs> SpellCheckError; 
        public event EventHandler<SpellCheckCompletedEventArgs> SpellCheckCompleted;

        /// <summary>
        /// Starts spell checking asynchroniously.
        /// </summary>
        /// <param name="textBlock">String containing several words.</param>        
        public void StartCheckSpelling(string textBlock)
        {
            if (m_SpellCheckerWorker.IsBusy == false)
            {
                m_SpellCheckerWorker.RunWorkerAsync(textBlock);
            }            
        }

        private void m_SpellCheckerWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            var textBlock = e.Argument as string;

            e.Result = CatiServiceManagerWrapper.CheckTextSpelling(languageId, textBlock);
        }

        private void m_SpellCheckerWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                var args = new SpellCheckErrorEventArgs { Error = e.Error };

                OnSpellCheckerError(args);
            }
            else
            {
                var args = new SpellCheckCompletedEventArgs { SpellErrors = (SpellError[])e.Result };

                OnSpellCheckerCompleted(args);
            }            
        }

        private void OnSpellCheckerError(SpellCheckErrorEventArgs args)
        {
            if (SpellCheckError != null)
            {
                SpellCheckError(this, args);
            }
        }                            

        private void OnSpellCheckerCompleted(SpellCheckCompletedEventArgs args)
        {
            if (SpellCheckCompleted != null)
            {
                SpellCheckCompleted(this, args);
            }
        }
    }
}
