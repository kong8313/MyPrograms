﻿using System;
using Confirmit.CATI.Console.Classes.User;

namespace Confirmit.CATI.Console.Services.CatiService
{
    public class AuthenticationData : IAuthenticationData
    {
        private Guid? _authenticationKey;
        public Guid AuthenticationKey
        {
            get
            {
                if (_authenticationKey != null)
                {
                    return _authenticationKey.Value;
                }

                return UserPassport.Instance.Properties.AuthenticationKey;
            }
        }

        private byte[] _encryptionKey;
        public byte[] EncryptionKey
        {
            get
            {
                if (_encryptionKey != null)
                {
                    return _encryptionKey;
                }

                return UserPassport.Instance.Properties.EncryptionKey;
            }
        }


        private byte[] _encryptionIv;
        public byte[] EncryptionIv
        {
            get
            {
                if (_encryptionIv != null)
                {
                    return _encryptionIv;
                }

                return UserPassport.Instance.Properties.EncryptionIV;
            }
        }

        private string _stationId;
        public string StationId
        {
            get
            {
                if (_stationId != null)
                {
                    return _stationId;
                }

                return ClientSettings.Default.StationId;
            }
        }
       
        public void SetCustomParameters(Guid authenticationKey, byte[] encryptionKey, byte[] encryptionIv, string stationId)
        {
            _authenticationKey = authenticationKey;
            _encryptionKey = encryptionKey;
            _encryptionIv = encryptionIv;
            _stationId = stationId;
        }
    }
}