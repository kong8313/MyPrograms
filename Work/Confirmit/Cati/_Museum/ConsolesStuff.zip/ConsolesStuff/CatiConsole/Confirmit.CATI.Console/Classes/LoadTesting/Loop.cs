﻿using System.Collections.Generic;

namespace Confirmit.CATI.Console.Classes.LoadTesting
{
    public class Loop
    {
        public Loop(string[] keys)
            : this()
        {
            Keys = keys;
        }

        public Loop()
        {
            Answers = new List<string[]>();
        }

        public string[] Keys { get; set; }

        public List<string[]> Answers { get; set; }

        public Dictionary<string, string> GetAnswers(int index)
        {
            var result = new Dictionary<string, string>();
            for (var i = 0; i < Keys.Length; i++)
            {
                result.Add(Keys[i], Answers[index][i]);
            }

            return result;
        }
    }
}
