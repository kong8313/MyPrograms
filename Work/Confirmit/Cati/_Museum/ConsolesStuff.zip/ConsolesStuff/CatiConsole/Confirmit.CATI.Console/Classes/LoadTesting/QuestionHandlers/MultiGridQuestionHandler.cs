using System.Collections.Generic;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class MultiGridQuestionHandler : BaseQuestionHandler, IQuestionHandler
    {
        public MultiGridQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers)
            : base(pageBrowser, predefinedAnswers)
        {
        }

        void IQuestionHandler.SetAnswers()
        {
            var keys = GetKeysForNonOther();

            foreach (var key in keys)
            {
                SetValueForMultiAnswer(key);
            }

            SetOtherForNonEmpty();
        }
    }
}