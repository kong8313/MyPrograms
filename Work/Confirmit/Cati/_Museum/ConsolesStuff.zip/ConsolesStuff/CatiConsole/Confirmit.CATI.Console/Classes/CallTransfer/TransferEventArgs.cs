﻿using System;
using Confirmit.CATI.Common.ConsoleService.Abstract;

namespace Confirmit.CATI.Console.Classes.CallTransfer
{
    internal class InternalTransferEventArgs : EventArgs
    {
        public string Resource;
    }

    internal class ExternalTransferEventArgs : EventArgs
    {
        public string Resource;
    }
}