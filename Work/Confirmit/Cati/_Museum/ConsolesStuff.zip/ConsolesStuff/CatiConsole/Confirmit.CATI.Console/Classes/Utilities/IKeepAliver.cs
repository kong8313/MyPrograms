﻿using System.Threading;
using Confirmit.CATI.Common.ConsoleService.Abstract;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public interface IKeepAliver
    {
        void StartKeepAliveThread(CatiConsolePropertiesContainer properties, SendOrPostCallback newMessageCallback, SendOrPostCallback logoutCallback, SendOrPostCallback saveKeepAliveDuration);
        void ClearResources();
    }
}