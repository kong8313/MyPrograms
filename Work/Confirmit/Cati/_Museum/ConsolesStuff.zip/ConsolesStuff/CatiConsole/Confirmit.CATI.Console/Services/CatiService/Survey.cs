﻿using System;
using System.Collections.Generic;

namespace Confirmit.CATI.Console.Services.CatiService
{
	/// <summary>
	/// Represents survey. It is wrapper for Survey class, which is declared 
	/// in CATI Web Service.
	/// </summary>
	public class Survey
	{
		#region Constructors

		/// <summary>
		/// Initializes new instance of Survey class and fills it with given 
		/// identifier and name.
		/// </summary>
		/// <param name="id">Survey identifier.</param>
		/// <param name="name">Survey name.</param>
		/// <param name="isRespondentsDynamicCreationAllowed"></param>
		public Survey(string id, string name, bool isRespondentsDynamicCreationAllowed)
		{
			Id = id;
			Name = name;
            IsRespondentsDynamicCreationAllowed = isRespondentsDynamicCreationAllowed;

		}

		/// <summary>
		/// Initializes new instance of Survey class and fills it with data from 
		/// CATI Web Service survey.
		/// </summary>
		/// <param name="survey"></param>
        public Survey(Confirmit.CATI.Common.ConsoleService.Abstract.Survey survey)
		{
			Id = survey.id;
			Name = survey.name;
            IsRespondentsDynamicCreationAllowed = survey.IsRespondentsDynamicCreationAllowed;
		}

		#endregion

		#region Properties

		/// <summary>
		/// Survey identifier.
		/// </summary>
		public string Id
		{
			get;
			set;
		}

		/// <summary>
		/// Survey name.
		/// </summary>
		public string Name
		{
			get;
			set;
		}

	    public bool IsRespondentsDynamicCreationAllowed { get; set; }
		#endregion

		#region Methods

		/// <summary>
		/// Determines whether the specified object is equal to the current object.
		/// </summary>
		/// <param name="obj">The object to compare.</param>
		/// <returns>true if the specified object is equal to the current object; otherwise, false.</returns>
		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}

			if (GetType() != obj.GetType())
			{
				return false;
			}

			Survey survey = (Survey)obj;
			return Equals(Id, survey.Id) && Equals(Name, survey.Name) && Equals(IsRespondentsDynamicCreationAllowed, survey.IsRespondentsDynamicCreationAllowed);
		}

		/// <summary>
		/// Serves as a hash function for a particular type. 
		/// </summary>
		/// <returns>A hash code.</returns>
		public override int GetHashCode()
		{
			if (String.IsNullOrEmpty(Id))
			{
				return 0;
			}
			else
			{
				return Id.GetHashCode();
			}
		}

		#endregion
	}

	/// <summary>
	/// Represents collection of Survey objects.
	/// </summary>
	public class SurveyCollection : List<Survey>
	{
		#region Constructors

		/// <summary>
		/// Initializes new instance of SurveyCollection class.
		/// </summary>
		public SurveyCollection()
		{
		}

		/// <summary>
		/// Initializes new instance of SurveyCollection class and fills it with given
		/// list of CATI Web Service surveys.
		/// </summary>
		/// <param name="surveys">Enumeration with CATI Web Service surveys.</param>
		/// <exception cref="ArgumentNullException">Survey enumeration is null.</exception>
        public SurveyCollection(IEnumerable<Confirmit.CATI.Common.ConsoleService.Abstract.Survey> surveys)
		{
			if (surveys == null)
			{
				throw new ArgumentNullException("surveys");
			}

            foreach (Confirmit.CATI.Common.ConsoleService.Abstract.Survey survey in surveys)
			{
				Add(new Survey(survey));
			}
		}

		#endregion

		#region Methods

		/// <summary>
		/// Determines whether the specified object is equal to the current object.
		/// </summary>
		/// <param name="obj">The object to compare.</param>
		/// <returns>true if the specified object is equal to the current object; otherwise, false.</returns>
		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}

			if (GetType() != obj.GetType())
			{
				return false;
			}

			SurveyCollection coll = (SurveyCollection)obj;
			if (Count != coll.Count)
			{
				return false;
			}

			bool result = true;

			for (int i = 0; i < Count; i++)
			{
				if (!Object.Equals(this[i], coll[i]))
				{
					result = false;
					break;
				}
			}

			return result;
		}

		/// <summary>
		/// Serves as a hash function for a particular type. 
		/// </summary>
		/// <returns>A hash code.</returns>
		public override int GetHashCode()
		{
			int result = 0;
			
			if (Count > 0)
			{
				result = this[0].GetHashCode();

				for (int i = 1; i < Count; i++)
				{
					result ^= this[i].GetHashCode();
				}
			}

			return result;
		}

		/// <summary>
		/// Determines whether specified objects are equal.
		/// </summary>
		/// <param name="first">First object.</param>
		/// <param name="second">Second object.</param>
		/// <returns>true, if objects are equal; otherwise false.</returns>
		public static bool operator ==(SurveyCollection first, SurveyCollection second)
		{
			return Object.Equals(first, second);
		}

		/// <summary>
		/// Determines whether specified objects are not equal.
		/// </summary>
		/// <param name="first">First object.</param>
		/// <param name="second">Second object.</param>
		/// <returns>true, if objects are not equal; otherwise false.</returns>
		public static bool operator !=(SurveyCollection first, SurveyCollection second)
		{
			return !Object.Equals(first, second);
		}

		#endregion
	}
}
