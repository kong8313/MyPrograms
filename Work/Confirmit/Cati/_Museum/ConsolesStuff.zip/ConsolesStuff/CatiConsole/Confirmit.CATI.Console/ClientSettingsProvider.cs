﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Configuration.Provider;
using System.Windows.Forms;
using System.Collections.Specialized;
using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Console.Shared.Log;
using Microsoft.Win32;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text.RegularExpressions;

namespace Confirmit.CATI.Console
{
    /// <summary>
    /// Represents settings provider for client settings.
    /// It is used for save settings to user-friendly place.
    /// </summary>
    public class ClientSettingsProvider : SettingsProvider
    {
        XmlDocument m_SettingsXml = null;
        const string m_SettingsRoot = "Settings";

        /// <summary>
        /// Initialize provider.
        /// Occurs on any value modification
        /// </summary>
        /// <param name="name"></param>
        /// <param name="config"></param>
        public override void  Initialize(string name, NameValueCollection config)
        {            
            base.Initialize("ClientSettingsProvider", config);            
         }

         /// <summary>
         /// Gets Application name
         /// </summary>
        public override string ApplicationName
        {
            get
            {
                if (Application.ProductName.Trim().Length > 0)
                {
                    return Application.ProductName;
                }
                else
                {
                    var fi = new FileInfo(Application.ExecutablePath);

                    return fi.Name.Substring(0, fi.Name.Length - fi.Extension.Length);
                }
            }
            set
            {
            }
        }

        public static string SettingsFilePath { get; set; }

        /// <summary>
        /// Represents XML document that contains settings 
        /// </summary>
        public XmlDocument SettingsXml
        {
            get
            {
                if (m_SettingsXml == null)
                {
                    m_SettingsXml = new XmlDocument();

                    XmlReader reader = null;
                    try
                    {
                        var xmlSettings = new XmlReaderSettings()
                        {
                            IgnoreComments = true,
                            IgnoreWhitespace = true,
                            IgnoreProcessingInstructions = true,
                        };
                        
                        reader = XmlReader.Create(SettingsFilePath, xmlSettings);
                        
                        m_SettingsXml.Load(reader);

                        reader.Close();
                    }
                    catch (Exception ex)
                    {
                        Logger.Write(ex);
                        var dec = m_SettingsXml.CreateXmlDeclaration("1.0", "utf-8", String.Empty);
                        
                        m_SettingsXml.AppendChild(dec);

                        var nodeRoot = m_SettingsXml.CreateNode(XmlNodeType.Element, m_SettingsRoot, "");
                        m_SettingsXml.AppendChild(nodeRoot);
                    }
                    finally
                    {
                        if (reader != null)
                        {
                            reader.Close();
                        }
                    }
                }

                return m_SettingsXml;
            }
        }

        /// <summary>
        /// Sets the values of the specified group of property settings.
        /// </summary>
        ///<remarks>
        ///Occurs when settings save method is called
        /// </remarks>
        public override void SetPropertyValues(SettingsContext context, SettingsPropertyValueCollection propvals)
        {
            foreach (SettingsPropertyValue propval in propvals)
            {
                SetValue(propval);
            }

            XmlWriter writer = null;

            try
            {
                var xmlSettings = new XmlWriterSettings()
                {
                    Indent = true,
                    CloseOutput = true
                };

                writer = XmlWriter.Create(SettingsFilePath, xmlSettings);

                SettingsXml.Save(writer);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                }
            }
        }
        /// <summary>
        /// Returns the collection of settings property values
        /// </summary>
        public override SettingsPropertyValueCollection GetPropertyValues(SettingsContext context, SettingsPropertyCollection props)
        {
            var values = new SettingsPropertyValueCollection();

            foreach (SettingsProperty setting in props)
            {
                var value = new SettingsPropertyValue(setting)
                                {
                                    IsDirty = false, 
                                    SerializedValue = GetValue(setting)
                                };
                values.Add(value);
            }
            return values;
        }

        /// <summary>
        /// Gets value from SettingsXML. 
        /// </summary>
        /// <param name="setting"></param>
        /// <returns></returns>
        private string GetValue(SettingsProperty setting)
        {
            try
            {
                string nodeValue = SettingsXml.SelectSingleNode(m_SettingsRoot + "/" + setting.Name).InnerText;
                return ClearValue(nodeValue);
            }
            catch (XPathException)
            {
                if (setting.DefaultValue != null)
                {
                    return setting.DefaultValue.ToString();
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }

            return String.Empty;
        }

        /// <summary>
        /// Sets value to SettingsXML
        /// </summary>
        /// <param name="propVal"></param>
        private void SetValue(SettingsPropertyValue propVal)
        {
   
            XmlElement settingNode = null;

            try
            {
                settingNode = (XmlElement)SettingsXml.SelectSingleNode(m_SettingsRoot + "/" + propVal.Name);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }

            //'Check to see if the node exists, if so then set its new value
            if (settingNode != null)
            {
                settingNode.InnerText = propVal.SerializedValue.ToString();
            }
            else
            {
                settingNode = SettingsXml.CreateElement(propVal.Name);
                settingNode.InnerText = propVal.SerializedValue.ToString();
                SettingsXml.SelectSingleNode(m_SettingsRoot).AppendChild(settingNode);
            }
        }

        /// <summary>
        /// Clear string from carriage-return, tabulation, whitespaces
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string ClearValue(string value)
        {
            return value.Trim();
        }
    }
}