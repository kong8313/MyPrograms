﻿using Confirmit.CATI.Common;
using Confirmit.CATI.Common.Exceptions;
using Confirmit.CATI.Common.Security;
using Confirmit.CATI.Common.WcfTools.ErrorServiceMessageHeader;
using Confirmit.CATI.Console.Classes.CheckSpelling;
using Confirmit.CATI.Console.Classes.LoadTesting;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Console.Classes.Sender;
using Confirmit.CATI.Console.Classes.Telephony;
using Confirmit.CATI.Console.Classes.Termination;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Services.CatiService.Exceptions;
using Confirmit.CATI.Console.Services.ConsoleAuthorizationService;
using Confirmit.CATI.Console.Services.ErrorReportingService;
using Confirmit.CATI.Console.Services.MonitoringService;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Resources;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.Classes.Login;
using Confirmit.CATI.Console.Views.Classes.SearchableGrid;
using Confirmit.CATI.Console.Views.Classes.StatusBar;
using Confirmit.CATI.Console.Views.Forms;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;
using ConfirmitDialerInterface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Common.WcfTools;
using Confirmit.CATI.Console.Classes.CallTransfer;
using ILogger = Confirmit.CATI.Common.ILogger;
using Survey = Confirmit.CATI.Console.Services.CatiService.Survey;
using Timer = System.Windows.Forms.Timer;

namespace Confirmit.CATI.Console.Presenters
{
    /// <summary>
    /// Represents presenter entity for MainForm, LoginForm, SurveyListControl.
    /// </summary>
    internal class PresenterMainForm : IMonitorable, IInterviewProperties
    {
        private readonly ConsoleAuthorizer _consoleAuthorizer = new ConsoleAuthorizer();
        private readonly IConsoleDescriptionProvider _consoleDescriptionProvider;
        private readonly IViewExtensionNumberForm _extensionNumberForm;
        private IViewWarmTransferForm _warmTransferForm;
        private readonly IGetStateStopwatch _getStateCycleElapsed;
        private readonly PresenterInterview _interviewBrowserPresenter;
        private readonly IViewOnABreakControl _onABreak;
        private readonly IEnvironmentValidator _environmentValidator;
        private readonly PresenterMessaging _presenterMessaging;
        private readonly PresenterTelephony _presenterTelephony;
        internal Stopwatch GetStateWsErrorElapsed = new Stopwatch();
        private int _currentInterviewId;
        private string _currentSoundFile;
        private string _currentSurveyId;
        private bool _disableTelephonyResultHanler;
        private Timer _interviewCycleTimer;
        private bool _isPredictiveMode;
        private bool _redoQuestionChanged;

        private string _lastUsedTransferTargetPhoneNumber;
        private string _lastUsedTransferTargetGroupName;

        private bool _waitForLogoutComplete;
        private readonly ICatiServiceManager _catiServiceManager;
        private readonly IAlerter _alerter;
        private ILogger _logger;
        private IKeepAliver _keepAliver;
        private IEventSender _eventSender;
        private ITaskChoiceRouter _taskChoiceRouter;
        private ICatiServiceHelper _catiServiceHelper;
        private IConsoleProperties _consoleProperties;
        private Dictionary<string, ConsoleSearchParameter[]> _interviewsSearchParameters;
        private List<BreakType> _breakTypes;

        private ConnectionQualityAnalyzer _connectionQualityAnalyzer;

        private CatiConsolePropertiesContainer CatiConsoleProperties => UserPassport.Instance.Properties.ConsoleProperties;

        private bool IsLogoutToolbarButtonEnabled => CatiConsoleProperties == null || CatiConsoleProperties.EnableLogoutToolbarButton;

        private bool IsTakeBreakToolbarButtonEnabled => CatiConsoleProperties == null || CatiConsoleProperties.EnableTakeBreakToolbarButton;

        private bool IsLogoutAfterFinishButtonEnabled => CatiConsoleProperties == null || CatiConsoleProperties.EnableLogoutAfterFinishToolbarButton;

        private List<BreakType> BreakTypes
        {
            get
            {
                if (_breakTypes == null)
                {
                    _breakTypes = CatiConsoleProperties.BreakTypes.OrderBy(x => x.Name).ToList();
                }

                return _breakTypes;
            }
        }

        /// <summary>
        /// Initializes new instance of PresenterMainForm class
        /// and fills it with the given data.
        /// </summary>
        /// <param name="presenterInterview">Interview page control presenter.</param>
        /// <param name="presenterTelephony">Telephony page control presenter.</param>
        /// <param name="presenterMessaging">Messanging page control presenter.</param>
        /// <param name="frmMain">Main form view interface.</param>
        /// <param name="frmLogin">Login form view interface.</param>
        /// <param name="frmChange">Change form view interface.</param>
        /// <param name="frmExtensionNumber">Extension number form view interface.</param>
        /// <param name="ctlSurveyList">Survey list control.</param>
        /// <param name="ctlStatusBar">Status bar control.</param>
        /// <param name="ctlOnABreak">OnABreak control view interface.</param>
        /// <param name="consoleDescriptionProvider">Console description provider</param>
        /// <param name="environmentValidator">OS and net framework validator</param>
        /// <param name="arguments">Coman Line arguments</param>
        /// <exception cref="ArgumentNullException">presenterInterview, frmMain,
        /// frmLogin or ctlSurveyList are null.</exception>
        public PresenterMainForm(
            PresenterInterview presenterInterview,
            PresenterTelephony presenterTelephony,
            PresenterMessaging presenterMessaging,
            IViewMainForm frmMain,
            IViewLoginForm frmLogin,
            IViewChangePasswordForm frmChange,
            IViewExtensionNumberForm frmExtensionNumber,
            IViewSurveyListControl ctlSurveyList,
            IViewStatusBar ctlStatusBar,
            IViewOnABreakControl ctlOnABreak,
            IConsoleDescriptionProvider consoleDescriptionProvider,
            IEnvironmentValidator environmentValidator,
            AutoPilotArguments arguments
            )
            : this(presenterInterview, presenterTelephony, presenterMessaging, frmMain, frmLogin, frmChange, frmExtensionNumber, ctlSurveyList, ctlStatusBar, ctlOnABreak, consoleDescriptionProvider, environmentValidator)
        {
            if (arguments != null)
            {
                InitializeAutoPilot(arguments);
            }
        }

        public PresenterMainForm(
            PresenterInterview presenterInterview,
            PresenterTelephony presenterTelephony,
            PresenterMessaging presenterMessaging,
            IViewMainForm frmMain,
            IViewLoginForm frmLogin,
            IViewChangePasswordForm frmChange,
            IViewExtensionNumberForm frmExtensionNumber,
            IViewSurveyListControl ctlSurveyList,
            IViewStatusBar ctlStatusBar,
            IViewOnABreakControl ctlOnABreak,
            IConsoleDescriptionProvider consoleDescriptionProvider,
            IEnvironmentValidator environmentValidator)
        {
            if (presenterInterview == null)
            {
                throw new ArgumentNullException("presenterInterview");
            }

            if (presenterTelephony == null)
            {
                throw new ArgumentNullException("presenterTelephony");
            }

            if (presenterMessaging == null)
            {
                throw new ArgumentNullException("presenterMessaging");
            }

            if (frmMain == null)
            {
                throw new ArgumentNullException("frmMain");
            }

            if (frmLogin == null)
            {
                throw new ArgumentNullException("frmLogin");
            }

            if (frmChange == null)
            {
                throw new ArgumentNullException("frmChange");
            }

            if (frmExtensionNumber == null)
            {
                throw new ArgumentNullException("frmExtensionNumber");
            }

            if (ctlSurveyList == null)
            {
                throw new ArgumentNullException("ctlSurveyList");
            }

            if (ctlStatusBar == null)
            {
                throw new ArgumentNullException("ctlStatusBar");
            }

            if (ctlOnABreak == null)
            {
                throw new ArgumentNullException("ctlOnABreak");
            }

            if (consoleDescriptionProvider == null)
            {
                throw new ArgumentNullException("consoleDescriptionProvider");
            }

            if (environmentValidator == null)
            {
                throw new ArgumentNullException("environmentValidator");
            }

            MainForm = frmMain;
            LoginForm = frmLogin;
            ChangePasswordForm = frmChange;
            _extensionNumberForm = frmExtensionNumber;
            _warmTransferForm = null;
            SurveyList = ctlSurveyList;
            StatusBar = ctlStatusBar;
            _onABreak = ctlOnABreak;
            _consoleDescriptionProvider = consoleDescriptionProvider;
            _environmentValidator = environmentValidator;
            _interviewBrowserPresenter = presenterInterview;
            _presenterTelephony = presenterTelephony;
            _presenterMessaging = presenterMessaging;
            SelectedSurveyIndex = 0;
            CurrentSurveyLanguageId = null;
            PreviousSurveyId = string.Empty;
            ConfirmOnExit = true;
            IsRestartInvoked = false;
            IsForcedLogoutInvoked = false;
            IsFirstInterviewTime = true;
            PreviousInterviewState = InterviewState.SELECTING;
            CurrentConsoleState = ConsoleState.Selecting;

            _lastUsedTransferTargetPhoneNumber = string.Empty;
            _lastUsedTransferTargetGroupName = string.Empty;

            _catiServiceManager = ServiceLocator.Resolve<ICatiServiceManager>();
            _alerter = ServiceLocator.Resolve<IAlerter>();
            _logger = ServiceLocator.Resolve<ILogger>();
            _keepAliver = ServiceLocator.Resolve<IKeepAliver>();
            _eventSender = ServiceLocator.Resolve<IEventSender>();
            _taskChoiceRouter = ServiceLocator.Resolve<ITaskChoiceRouter>();
            _catiServiceHelper = ServiceLocator.Resolve<ICatiServiceHelper>();
            _consoleProperties = ServiceLocator.Resolve<IConsoleProperties>();
            _getStateCycleElapsed = ServiceLocator.Resolve<IGetStateStopwatch>();
            _interviewsSearchParameters = new Dictionary<string, ConsoleSearchParameter[]>();

            InitEventHandlers();
        }


        /// <summary>
        /// Initializes event handlers.
        /// </summary>
        internal void InitEventHandlers()
        {
            MainForm.FormLoad += m_MainForm_FormLoad;
            MainForm.PreviousPage += m_MainForm_PreviousPage;
            MainForm.NextPage += m_MainForm_NextPage;
            MainForm.ShowAppointments += m_MainForm_ShowAppointments;
            MainForm.ShowRedialForm += m_MainForm_ShowRedialForm;
            MainForm.TerminateInterview += m_MainForm_TerminateInterview;
            MainForm.Logout += m_MainForm_Logout;
            MainForm.PendingBreak += m_MainForm_PendingBreak;
            MainForm.ChangeTaskChoice += m_MainForm_ChangeTaskChoice;
            MainForm.SelectedSurveyLanguageChanged += m_MainForm_SelectedSurveyLanguageChanged;
            MainForm.RedoDropDownOpening += m_MainForm_RedoDropDownOpening;
            MainForm.RedoDropDownOpen += m_MainForm_RedoDropDownOpen;
            MainForm.RedoDropDownClose += m_MainForm_RedoDropDownClose;
            MainForm.PendingLogout += m_MainForm_PendingLogout;
            MainForm.RedoQuestionChanged += m_MainForm_RedoQuestionChanged;
            MainForm.FormExiting += m_MainForm_FormExiting;
            MainForm.FastForward += m_MainForm_FastForward;
            MainForm.HangUp += m_MainForm_HangUp;
            MainForm.InternalCallTransfer += m_MainForm_InternalCallTransfer;
            MainForm.ExternalCallTransfer += m_MainForm_ExternalCallTransfer;
            MainForm.RefreshInterviewList += m_MainForm_RefreshInterviewList;
            MainForm.FormProcessCmdKey += m_MainForm_FormProcessCmdKey;
            MainForm.ShowInterviewerAppointments += m_MainForm_ShowAppointmentList;
            MainForm.ShowMessagingForm += m_MainForm_ShowMessagingForm;
            MainForm.StartPlayback += m_MainForm_StartPlayback;
            MainForm.PauseOrResumePlayback += m_MainForm_PauseOrResumePlayback;
            MainForm.StopPlayback += m_MainForm_StopPlayback;
            MainForm.ToggleInterviewerListensToPlaybackOrRespondent += m_MainForm_ToggleInterviewerListensToPlaybackOrRespondent;
            MainForm.SpellCheck += m_MainForm_SpellCheck;
            MainForm.FormActivated += m_MainForm_FormActivated;
            MainForm.CancelDialing += ExecuteHangUp;

            LoginForm.LoginClick += m_LoginForm_LoginClick;
            LoginForm.PasswordChangeClick += m_LoginForm_PasswordChangeClick;
            LoginForm.FormClose += m_LoginForm_FormClose;
            LoginForm.FormLoad += m_LoginForm_FormLoad;
            LoginForm.SetAsDefaultCompanyCheck += m_LoginForm_SetAsDefaultCompanyCheck;
            LoginForm.SetAsDefaultCompanyUncheck += m_LoginForm_SetAsDefaultCompanyUncheck;
            LoginForm.FormProcessCmdKey += m_MainForm_FormProcessCmdKey;

            ChangePasswordForm.ChangeClick += m_ChangePasswordForm_ChangeClick;

            _extensionNumberForm.OkClick += m_ExtensionNumberForm_OkClick;
            _extensionNumberForm.CancelClicking += m_ExtensionNumberForm_CancelClicking;
            _extensionNumberForm.ValidatingExtensionNumber += m_ExtensionNumberForm_ValidatingExtensionNumber;

            SurveyList.SurveySelectionChanged += m_SurveyList_SurveySelectionChanged;
            SurveyList.SurveySelected += m_SurveyList_SurveySelected;
            SurveyList.InterviewSelected += m_SurveyList_InterviewSelected;
            SurveyList.CreateInterview += m_SurveyList_CreateInterview;
            SurveyList.SplitterMoved += m_SurveyList_SplitterMoved;
            SurveyList.FormResize += m_SurveyList_FormResize;
            SurveyList.FilterInterviews += m_SurveyList_FilterInterviews;
            SurveyList.ResetAllFilters += m_SurveyList_ResetAllFilters;
            SurveyList.ColumnSortModeChanged += m_SurveyList_ColumnSortModeChanged;

            _onABreak.ContinueWorkClick += OnABreakContinueWorkClick;
            _onABreak.LogoutClick += OnABreakLogoutClick;

            _interviewBrowserPresenter.InterviewFinished += m_PresenterInterview_InterviewFinished;
            _interviewBrowserPresenter.InterviewLastPage += m_PresenterInterview_InterviewLastPage;
            _interviewBrowserPresenter.StartReview += m_PresenterInterview_StartReview;
            _interviewBrowserPresenter.StateChanged += _eventSender.ProcessEvents;
            _interviewBrowserPresenter.Dial += m_PresenterInterview_Dial;
            _interviewBrowserPresenter.Hangup += m_PresenterInterview_Hangup;
            _interviewBrowserPresenter.PlaybackFound += m_PresenterInterview_PlaybackFound;
            _interviewBrowserPresenter.PlaybackNotFound += m_PresenterInterview_PlaybackNotFound;
            _interviewBrowserPresenter.ForcedAppointment += m_PresenterInterview_ForcedAppointment;
            _interviewBrowserPresenter.StartCallTransfer += m_PresenterInterview_StartCallTransfer;
            _interviewBrowserPresenter.InternalTransfer += m_PresenterInterview_InternalTransfer;
            _interviewBrowserPresenter.ExternalTransfer += m_PresenterInterview_ExternalTransfer;

            StateChanged += _eventSender.ProcessEvents;
            LocalizationManager.Instance.CurrentCultureChanged += LocalizationManager_CurrentCultureChanged;
            UserPassport.Instance.MonitoringStarted += UserPassport_MonitoringStarted;

            _presenterTelephony.TelephonyResult += PresenterTelephonyTelephonyResult;
            _presenterTelephony.LoggedToDialerInEvent += m_PresenterTelephony_LoggedToDialerInEvent;
            _presenterTelephony.LoginToDialerErrorEvent += m_PresenterTelephony_LoginToDialerErrorEvent;
            _presenterTelephony.LogoutWhileLoginToDialerEvent += m_PresenterTelephony_LogoutWhileLoginToDialerEvent;

            _taskChoiceRouter.StartManualMode = StartManualMode;
            _taskChoiceRouter.StartAutomaticMode = StartAutomaticMode;
            _taskChoiceRouter.StartSurveyAssignmentMode = StartSurveyAssignmentMode;

            NewMessageDetected += _presenterMessaging.NewMessagesHandler;

            _catiServiceHelper.GetStateError += CatiServiceHelper_GetStateError;
        }

        public bool IsAutoPilotEnabled { get; set; }

        public AutoPilotArguments AutoPilotArguments { get; set; }

        /// <summary>
        /// Returns instance of IViewMainForm interface.
        /// </summary>
        public IViewMainForm MainForm { get; private set; }

        /// <summary>
        /// Returns instance of IViewLoginForm interface.
        /// </summary>
        public IViewLoginForm LoginForm { get; private set; }

        /// <summary>
        /// Returns instance of IViewLoginForm interface.
        /// </summary>
        public IViewChangePasswordForm ChangePasswordForm { get; private set; }

        /// <summary>
        /// Returns instance of IViewStatusBar interface.
        /// </summary>
        public IViewStatusBar StatusBar { get; private set; }

        /// <summary>
        /// Returns instance of IViewSurveyListControl interface.
        /// </summary>
        public IViewSurveyListControl SurveyList { get; private set; }

        public IViewNotificationForm NotificationForm { get; private set; }

        /// <summary>
        /// Gets/sets the instance of PresenterApointmentForm. This property
        /// returns presenter during appointment form showing, otherwise null.
        /// </summary>
        public PresenterAppointmentForm AppointmentFormPresenter { get; set; }

        /// <summary>
        /// Gets/sets the instance of PresenterSpellChecker.
        /// </summary>
        public PresenterSpellChecker SpellCheckPresenter { get; set; }

        /// <summary>
        /// Gets/sets index of selected survey in survey list.
        /// </summary>
        public int SelectedSurveyIndex { get; set; }

        /// <summary>
        /// Gets current task choice mode
        /// Automatic, SurveyAssignment, Manual
        /// </summary>
        public AgentTaskChoiceMode UserAssignmentMode
        {
            get
            {
                return UserPassport.Instance.Properties.UserAssignmentMode;
            }
            set
            {
                UserPassport.Instance.Properties.UserAssignmentMode = value;
            }
        }

        /// <summary>
        /// Gets or sets flag indicated there is dialer in the system
        /// </summary>
        /// <remarks>
        /// This flag initially is set on login.
        /// If during login to dialer operation error occurs flag will be set to false
        /// </remarks>
        public bool IsDialerInSystem { get; set; }

        /// <summary>
        /// Gets or sets flag indicated has system ask interviewer about extension number or not
        /// </summary>
        /// <remarks>
        /// This flag is initializated on login and depends on StationId value
        /// </remarks>
        public bool HasStationExtensionNumber { get; set; }

        /// <summary>
        /// Return true if close company is specified in config file
        /// </summary>
        public bool HasCloseCompany
        {
            get
            {
                return !String.IsNullOrEmpty(ClientSettings.Default.CloseCompanyAlias);
            }
        }

        /// <summary>
        /// Returns true if StationId is specified in client config file otherwise false
        /// </summary>
        public bool HasStationId
        {
            get
            {
                return !String.IsNullOrEmpty(ClientSettings.Default.StationId);
            }
        }

        /// <summary>
        /// Gets current survey id
        /// If automatic task choice mode returns null
        /// otherwise returns user selected survey id
        /// </summary>
        public string CurrentSurveyId
        {
            get
            {
                switch (UserAssignmentMode)
                {
                    case AgentTaskChoiceMode.Automatic:
                        {
                            return String.Empty;
                        }
                    case AgentTaskChoiceMode.CampaignAssignment:
                    case AgentTaskChoiceMode.Manual:
                        {
                            return _currentSurveyId;
                        }
                    default: return String.Empty;
                }
            }
        }

        /// <summary>
        /// Gets current interview id
        /// If automatic task choice mode returns null
        /// otherwise returns user selected survey id
        /// </summary>
        public int CurrentInterviewId
        {
            get
            {
                switch (UserAssignmentMode)
                {
                    case AgentTaskChoiceMode.Automatic:
                    case AgentTaskChoiceMode.CampaignAssignment:
                        {
                            return 0;
                        }
                    case AgentTaskChoiceMode.Manual:
                        {
                            return _currentInterviewId;
                        }
                    default: return 0;
                }
            }
        }

        /// <summary>
        /// Returns true if we start interview first time after login 
        /// otherwise return false
        /// </summary>
        public bool IsFirstInterviewTime { get; set; }

        /// <summary>
        /// Gets/sets identifier of currently selected language for surveys.
        /// </summary>
        public int? CurrentSurveyLanguageId { get; set; }

        /// <summary>
        /// Gets/sets survey identifier. This value is set just before interview start
        /// and is stored till new interview start.
        /// </summary>
        public string PreviousSurveyId { get; set; }

        /// <summary>
        /// Gets/sets list of survey languages which reflects language list in MainForm toolbar.
        /// </summary>
        public LanguageCollection StoredSurveyLanguages { get; set; }

        /// <summary>
        /// Gets/sets flag indicating that confirmation should be asked before application close.
        /// If value is false, application will be closed without confirmation.
        /// </summary>
        public bool ConfirmOnExit { get; set; }

        /// <summary>
        /// Gets/sets flag indicating that application restart has been already invoked.
        /// </summary>
        /// <remarks>
        /// It's used to prevent multiple call for application restart
        /// </remarks>
        public bool IsRestartInvoked { get; set; }

        /// <summary>
        /// Gets/sets flag indicating that forced logout has been already invoked.
        /// </summary>
        /// <remarks>
        /// It's used to prevent multiple call
        /// </remarks>
        public bool IsForcedLogoutInvoked { get; set; }

        /// <summary>
        /// Gets/sets flag inicating is current interview started during logout process or not.
        /// </summary>
        public bool IsInterviewStartedDuringLogout { get; set; }

        /// <summary>
        /// Returns true if current survey is in predictive mode
        /// otherwise false
        /// </summary>
        public bool IsPredictiveMode
        {
            get
            {
                return _isPredictiveMode;
            }
        }

        public PresenterInterview PresenterInterview
        {
            get
            {
                return _interviewBrowserPresenter;
            }
        }

        /// <summary>
        /// Stores interview state between two calls of DoGetStateAndAnalyze() method.
        /// </summary>
        internal InterviewState PreviousInterviewState { get; set; }

        /// <summary>
        /// Gets flag indicated is hang up button enabled for interviewer or not
        /// </summary>
        public bool IsHangUpEnabled
        {
            get
            {
                if (_presenterTelephony.IsCustomDialerUsed)
                {
                    return IsCallConnected;
                }

                return IsDialerInSystem && UserPassport.Instance.Properties.IsHangUpEnabled && IsCallConnected;
            }
        }

        public bool ShowRedialButton
        {
            get
            {
                if (UserPassport.Instance.Properties == null)
                {
                    return false;
                }

                return CatiConsoleProperties.ShowRedialButton;
            }
        }

        public bool ShowInternalCallTransferButton
        {
            get
            {
                if (UserPassport.Instance.Properties == null)
                {
                    return false;
                }

                return CatiConsoleProperties.ShowInternalCallTransferButton;
            }
        }

        public bool ShowExternalCallTransferButton
        {
            get
            {
                if (UserPassport.Instance.Properties == null)
                {
                    return false;
                }

                return CatiConsoleProperties.ShowExternalCallTransferButton;
            }
        }

        private bool IsCallConnected
        {
            get
            {
                if (CurrentInterviewProperties == null)
                {
                    return false;
                }

                return (CallOutcome)CurrentInterviewProperties.CallOutcome == CallOutcome.Connected;
            }
        }

        public bool IsRedialEnabled
        {
            get
            {
                return ShowRedialButton && CurrentInterviewProperties != null &&
                       (CallOutcome)CurrentInterviewProperties.CallOutcome != CallOutcome.NotDefined;
            }
        }

        public bool IsInternalCallTransferEnabled
        {
            get
            {
                return ShowInternalCallTransferButton && 
                    CurrentInterviewProperties != null && 
                    CurrentInterviewProperties.InternalTransferType != InternalTransferType.Off &&
                    IsCallConnected;
            }
        }

        public bool IsExternalCallTransferEnabled
        {
            get
            {
                return ShowExternalCallTransferButton && CurrentInterviewProperties != null &&
                       IsCallConnected;
            }
        }

        public bool IsPendingLogoutDuringInterviewEnabled
        {
            get
            {
                if (IsPredictiveMode && IsInterviewStartedDuringLogout)
                {
                    return false;
                }

                return true;
            }
        }

        private bool IsChangeTaskChoiceEnabled
        {
            get
            {
                // ChangeTaskChoice should not be available if an Open API dialer is being used
                // And it should be available if the Custom dialer is being used
                if (IsDialerInSystem && !_presenterTelephony.IsCustomDialerUsed)
                {
                    return false;
                }

                if (UserPassport.Instance.Properties.TaskChoicePermissions != null &&
                    TaskChoicePermissionsHelper.GetAllowed(UserPassport.Instance.Properties.TaskChoicePermissions.Value).Count > 1)
                {
                    return true;
                }

                return false;
            }
        }

        /// <summary>
        /// Gets flag indicated whether pause/resume playback button is enabled for interviewer or not
        /// </summary>
        public bool IsPauseResumePlaybackEnabled
        {
            get
            {
                return IsDialerInSystem && UserPassport.Instance.Properties.IsPauseResumePlaybackEnabled;
            }
        }

        public ConsoleState CurrentConsoleState { get; set; }

        public PresenterInterview InterviewBrowserPresenter
        {
            get
            {
                return _interviewBrowserPresenter;
            }
        }

        /// <summary>
        /// Gets flag indicated whether toggle voice source button is enabled for interviewer or not
        /// </summary>
        public bool IsToggleVoiceSourceSupported
        {
            get
            {
                return IsDialerInSystem && UserPassport.Instance.Properties.IsToggleVoiceSourceSupported;
            }
        }

        private bool CanCancelDial
        {
            get
            {
                return CatiConsoleProperties.EnableAbilityToCancelDial &&
                     _interviewBrowserPresenter.IsTelephonyPage &&
                     MainForm.IsDialCanellationButtonEnabled;
            }
        }

        private TransferOptions _currentTransferOptions { get; set; }

        /// <summary>
        /// Survey collection which reflects survey list in Survey list control.
        /// </summary>
        public SurveyCollection StoredSurveys { get; set; }

        /// <summary>
        /// Interview collection which reflects interview list in Survey list control.
        /// </summary>
        public DataTable StoredInterviews { get; set; }

        /// <summary>
        /// Redo question collection which reflects redo questions list in main form.
        /// </summary>
        public QuestionHistoryCollection StoredRedoQuestions { get; set; }

        /// <summary>
        /// Gets/sets properties object of current interview.
        /// This property returns current interview properties
        /// during interviewing. Outside of interviewing process
        /// it returns null.
        /// </summary>
        public InterviewProperties CurrentInterviewProperties { get; set; }

        /// <summary>
        /// Occurs when control changes it's state and this change should be
        /// reflected during monitoring.
        /// </summary>
        public event StateChangedEventHandler StateChanged;

        /// <summary>
        /// Occurs when new message(messages) for interviewer is detected on server
        /// </summary>
        private event EventHandler NewMessageDetected;

        void PresenterInterview_LastInterviewReturned(object sender, EventArgs e)
        {
            _logger.Log("Set pending logout for Automatic Interviewing", TraceEventType.Information);
            MainForm.IsLogoutAfterFinishingChecked = true;
            SetPendingLogout(true);
        }

        private void InitializeAutoPilot(AutoPilotArguments arguments)
        {
            MainForm.SetAutoPilotMode();
            AutoPilotArguments = arguments;
            IsAutoPilotEnabled = true;
        }

        private void RunAutoPilotProcess()
        {
            var lines = File.ReadLines(AutoPilotArguments.FileName);
            var otherLines = GetLoopsDataFromFiles();

            var provider = new PredefinedAnswersProvider(lines, otherLines, AutoPilotArguments.TimesToRepeat);
            provider.LastInterviewReturned += PresenterInterview_LastInterviewReturned;

            var autoPilotThread = new Thread(
                () =>
                {
                    try
                    {
                        PresenterInterview.RunAutoPilotProcess(
                            provider,
                            AutoPilotArguments.MinDelay,
                            AutoPilotArguments.MaxDelay,
                            AutoPilotArguments.Locale);
                    }
                    catch (Exception ex)
                    {
                        _alerter.Alert(ex, Strings.Message_CATIConsole);
                        _logger.Log(ex.ToString(), TraceEventType.Error);

                        MainForm.IsLogoutAfterFinishingChecked = true;
                        SetPendingLogout(true);
                        _interviewBrowserPresenter.TerminateInterviewFromAnotherThread((int)TerminationReasons.Terminate);
                    }
                });

            autoPilotThread.IsBackground = true;
            autoPilotThread.Start();
        }

        private IEnumerable<List<string>> GetLoopsDataFromFiles()
        {
            var result = new List<List<string>>();
            var directoryName = Path.GetDirectoryName(AutoPilotArguments.FileName);
            var fileNameWithoutExtension = Path.GetFileNameWithoutExtension(AutoPilotArguments.FileName);
            if (string.IsNullOrEmpty(directoryName) || string.IsNullOrEmpty(fileNameWithoutExtension))
            {
                return result;
            }

            var loopFiles = Directory.GetFiles(directoryName, string.Format("{0}_*.*", fileNameWithoutExtension));

            result.AddRange(loopFiles.Select(file => File.ReadLines(file).ToList()));

            return result;
        }

        /// <summary>
        /// Returns current state of monitorable object.
        /// </summary>
        /// <returns>Object state data.</returns>
        public BaseStateData GetState()
        {
            return new MonitoringInitialStateData
            {
                ControlName = "CatiInterviewerConsole",
                InterviewBrowserState = _interviewBrowserPresenter.GetState(),
                AppointmentFormState = AppointmentFormPresenter == null ? null : AppointmentFormPresenter.GetState(),
                OnABreakControlState = new OnABreakDialogShownInitialStateData
                {
                    StartTime = _onABreak.StartTime,
                    BreakInfo = _onABreak.BreakTypeInfo,
                    DisplayBreakType = !string.IsNullOrEmpty(_onABreak.BreakTypeInfo)
                },
                ConsoleState = CurrentConsoleState
            };
        }

        private void m_MainForm_FormLoad(object sender, EventArgs e)
        {
            InitLocalization();

            InitServerLogging();

            MainForm.ShowRedialButton(ShowRedialButton);
            MainForm.ShowInternalCallTransferButton(ShowInternalCallTransferButton);
            MainForm.ShowExternalCallTransferButton(ShowExternalCallTransferButton);

            StatusBar.Version = ApplicationManager.AssemblyVersion;

            if (IsAutoPilotEnabled)
            {
                MainForm.SetAutoPilotMode();
            }

            _logger.Log(string.Format("{0}. {1}: {2}",
                        Strings.Log_ConsoleIsStarted,
                        Strings.Log_ConsoleVersion,
                        ApplicationManager.AssemblyVersion),
                        TraceEventType.Information);

            if (!_environmentValidator.IsEnvironmentSupported() && !IsApplicationRestarted())
            {
                MainForm.ShowBlankForm();
                _alerter.Alert(
                    _environmentValidator.GetWarning(
                        LocalizationManager.Instance.GetString("ApplicationNotSupportedMessageTextTemplate"),
                        LocalizationManager.Instance.GetString("ApplicationNotSupportedOSVersionMessageTextTemplate"),
                        LocalizationManager.Instance.GetString("ApplicationNotSupportedNetVersionMessageTextTemplate")),
                    LocalizationManager.Instance.GetString("ApplicationNotSupportedMessageCaption"),
                    MessageTypes.Warning);
            }
            else if (!_environmentValidator.IsEnvironmentSupported())
            {
                SaveIsApplicationRestartedFlag(false);
            }

            if (!_environmentValidator.IsIeVersionSupported())
            {
                MainForm.ShowBlankForm();
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("ApplicationNotSupportedIEVersionMessageTextTemplate"),
                    LocalizationManager.Instance.GetString("ApplicationNotSupportedMessageCaption"),
                    MessageTypes.Warning);
            }

            if (CheckLicenseAgreements())
            {

                if (IsAutoPilotEnabled)
                {
                    PerformLoginForAutoPilot();
                }
                else
                {
                    MainForm.ShowLoginForm();
                }
            }
            else
            {
                MainForm.CloseForm();
            }
        }

        private void PerformLoginForAutoPilot()
        {
            LoginForm.LoginUser = AutoPilotArguments.UserName;
            LoginForm.LoginPassword = AutoPilotArguments.Password;
            LoginForm.LoginCompanyAlias = AutoPilotArguments.Company;
            BeginLoginProcess();
            if (LoginForm.IsLoggedIn)
            {
                RunAutoPilotProcess();
                Start();
            }
            else
            {
                ConfirmOnExit = false;
                MainForm.CloseForm();
            }
        }

        void m_MainForm_Logout(object sender, EventArgs e)
        {
            Logout(true, false);
        }

        private void m_LoginForm_LoginClick(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(LoginForm.LoginUser) ||
                String.IsNullOrEmpty(LoginForm.LoginPassword))
            {
                MessageBox.Show(
                    LocalizationManager.Instance.GetString("Error_BlankPasswordMessage"),
                    LocalizationManager.Instance.GetString("Allert_WarningCaption"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
            }
            else
            {
                BeginLoginProcess();
            }
        }

        private void ShowPasswordChangeDialog()
        {
            LoginForm.HideForm();
            ChangePasswordForm.Localize(LocalizationManager.Instance);
            if (!string.IsNullOrEmpty(LoginForm.LoginUser))
            {
                ChangePasswordForm.SetUserName(LoginForm.LoginUser);
            }

            if (!string.IsNullOrEmpty(LoginForm.LoginCompanyAlias))
            {
                ChangePasswordForm.SetCompanyAlias(LoginForm.LoginCompanyAlias);
            }

            MainForm.ShowChangePasswordForm();
            LoginForm.Clear();
            LoginForm.ShowForm();
        }

        private void m_LoginForm_PasswordChangeClick(object sender, EventArgs e)
        {
            ShowPasswordChangeDialog();
        }

        private void BeginLoginProcess()
        {
            try
            {
                if (HasCloseCompany)
                {
                    UserPassport.Instance.CompanyAlias = ClientSettings.Default.CloseCompanyAlias;
                }
                else
                {
                    UserPassport.Instance.CompanyAlias = LoginForm.LoginCompanyAlias;
                }

                if (String.IsNullOrEmpty(UserPassport.Instance.CompanyAlias))
                {
                    _alerter.Alert(
                         LocalizationManager.Instance.GetString("Warning_EmptyCompanyAlias"),
                         LocalizationManager.Instance.GetString("Allert_WarningCaption"),
                         MessageTypes.Warning);

                    return;
                }

                UserPassport.Instance.UserName = LoginForm.LoginUser;
                UserPassport.Instance.Password = LoginForm.LoginPassword;

                // That time without company id
                InitServerLogging();

                if (_consoleAuthorizer.IsLatestVersion() == false)
                {
                    _alerter.Alert(
                        LocalizationManager.Instance.GetString("NewVersionOfConsoleIsAvailable"),
                        LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                        MessageTypes.Information);

                    _logger.Log(
                        string.Format(Strings.Log_LoginWithOlderVersionVersion, ApplicationManager.AssemblyVersion),
                        TraceEventType.Information);

                    Application.Exit();
                    return;
                }

                // In case of any errors just returns 0 and does not throw exception(s)
                UserPassport.Instance.CompanyId = _consoleAuthorizer.AuthorizeAndReturnCompanyId(
                    UserPassport.Instance.UserName,
                    UserPassport.Instance.Password,
                    UserPassport.Instance.CompanyAlias,
                    ClientSettings.Default.StationId);

                if (UserPassport.Instance.CompanyId < 1)
                {
                    _alerter.Alert(
                    LocalizationManager.Instance.GetString("Error_WrongUserOrPasswordOrCompanyMessage"),
                        LocalizationManager.Instance.GetString("Allert_ErrorCaption"),
                        MessageTypes.Error
                    );

                    return;
                }

                // Now with company id
                InitServerLogging();

                Login(
                    UserPassport.Instance.UserName,
                    UserPassport.Instance.Password,
                    UserPassport.Instance.CompanyId);
            }
            catch (EndpointNotFoundException /*ex*/)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Error_ConnectionFailed"),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                    MessageTypes.Error
                );
            }
            catch (PasswordExpiredException)
            {
                if (DialogResult.No == _alerter.AlertConfirmation(LocalizationManager.Instance.GetString("Question_ExpiredPassword"), LocalizationManager.Instance.GetString("Alerter_ConsoleCaption")))
                {
                    return;
                }

                ShowPasswordChangeDialog();
            }
            catch (Exception ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
            }
        }

        private void m_LoginForm_FormClose(object sender, EventArgs e)
        {
            if (LoginForm.IsLoggedIn)
            {
                Start();
            }
            else
            {
                MainForm.CloseForm();
            }
        }

        /// <summary>
        /// Occurs when user on login form wants set specified company as default
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void m_LoginForm_SetAsDefaultCompanyCheck(object sender, EventArgs e)
        {
            if (HasCloseCompany == false)
            {
                ClientSettings.Default.DefaultCompanyAlias = LoginForm.LoginCompanyAlias;
                ClientSettings.Default.Save();
            }
        }

        void m_LoginForm_SetAsDefaultCompanyUncheck(object sender, EventArgs e)
        {
            if (HasCloseCompany == false)
            {
                ClientSettings.Default.DefaultCompanyAlias = String.Empty;
                ClientSettings.Default.Save();
            }
        }

        private void m_LoginForm_FormLoad(object sender, EventArgs e)
        {
            if (HasCloseCompany)
            {
                LoginForm.CompanyInputEnabled = false;
            }
            else
            {
                LoginForm.CompanyInputEnabled = true;
                LoginForm.LoginCompanyAlias = ClientSettings.Default.DefaultCompanyAlias;
            }

            if (HasStationId == false)
            {
                ShowStationIdForm();
            }
        }

        private void BeginChangingPasswordProcess()
        {
            try
            {
                if (string.IsNullOrEmpty(ChangePasswordForm.LoginUser) ||
                    string.IsNullOrEmpty(ChangePasswordForm.OldPassword) ||
                    string.IsNullOrEmpty(ChangePasswordForm.NewPassword) ||
                    string.IsNullOrEmpty(ChangePasswordForm.ConfirmPassword) ||
                    string.IsNullOrEmpty(ChangePasswordForm.LoginCompanyAlias))
                {
                    throw new ArgumentException(LocalizationManager.Instance.GetString("ChangePasswordForm_AllFieldsMustBeFilled"));
                }

                if (ChangePasswordForm.NewPassword != ChangePasswordForm.ConfirmPassword)
                {
                    throw new ArgumentException(LocalizationManager.Instance.GetString("ChangePasswordForm_NewAndConfirmPasswordsAreDifferentWarning"));
                }

                _consoleAuthorizer.ChangePersonPassword(
                    ChangePasswordForm.LoginUser,
                    ChangePasswordForm.OldPassword,
                    ChangePasswordForm.NewPassword,
                    ChangePasswordForm.LoginCompanyAlias,
                    ClientSettings.Default.StationId);

                ChangePasswordForm.CloseForm();
            }
            catch (EndpointNotFoundException)
            {
                _alerter.Alert(LocalizationManager.Instance.GetString("Error_ConnectionFailed"), LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"), MessageTypes.Error);
            }
            catch (InvalidInterviewerCredentialsException)
            {
                _alerter.Alert(LocalizationManager.Instance.GetString("Error_WrongUserOrPasswordMessage"), LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"), MessageTypes.Warning);
            }
            catch (TheSamePasswordException)
            {
                _alerter.Alert(LocalizationManager.Instance.GetString("Error_TheSamePasswordMessage"), LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"), MessageTypes.Warning);
            }
            catch (TooShortPasswordException)
            {
                _alerter.Alert(LocalizationManager.Instance.GetString("Error_TooShortPasswordMessage"), LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"), MessageTypes.Warning);
            }
            catch (PasswordDoesNotSatisfyRulesException)
            {
                _alerter.Alert(LocalizationManager.Instance.GetString("Error_PasswordDoesNotSatisfyRulesMessage"), LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"), MessageTypes.Warning);
            }
            catch (Exception ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
            }
        }

        private void m_ChangePasswordForm_ChangeClick(object sender, EventArgs e)
        {
            BeginChangingPasswordProcess();
        }

        void m_ExtensionNumberForm_OkClick(object sender, EventArgs e)
        {
            SetExtensionNumber();
        }

        private void SetExtensionNumber()
        {
            if (_extensionNumberForm.ExtensionNumberInputEnabled)
            {
                _presenterTelephony.ExtensionNumber = _extensionNumberForm.ExtensionNumber;

                ClientSettings.Default.ExtensionNumber = _extensionNumberForm.ExtensionNumber;
                ClientSettings.Default.Save();
            }
        }

        void m_ExtensionNumberForm_CancelClicking(object sender, CancelEventArgs e)
        {
            if (_alerter.AlertConfirmationOkCancel(
                        LocalizationManager.Instance.GetString("YouWillBeWorkWithoutDialer"),
                        LocalizationManager.Instance.GetString("Alerter_ConsoleCaption")
                    ) == DialogResult.Cancel)
            {
                e.Cancel = true;
            }
        }

        void m_ExtensionNumberForm_ValidatingExtensionNumber(object sender, CancelEventArgs e)
        {
            if (_extensionNumberForm.ExtensionNumberInputEnabled &&
                !new PhoneNumberValidator().Validate(_extensionNumberForm.ExtensionNumber))
            {
                _extensionNumberForm.AlertValidationError(
                      LocalizationManager.Instance.GetString("Error_InvalidExtensionNumber")
                );

                e.Cancel = true;
            }
        }

        private void WarmTransferForm_OnCompleteClick(object sender, EventArgs e)
        {
            try
            {
                _catiServiceManager.TransferComplete();

                var currentTransferOptions = _currentTransferOptions;

                CloseWarmTransferWindowIfNeeded();

                if (currentTransferOptions?.Type == ConsoleTransferType.ExternalWarm)
                {
                    MainForm.ShowInterviewPageControl(GetToolbarState());
                    _interviewBrowserPresenter.TerminateInterview((int) TerminationReasons.ExternalTransfer);
                }
                else if (currentTransferOptions?.Type == ConsoleTransferType.InternalWarm)
                {
                    _interviewBrowserPresenter.HasWrapUpBeenSent = true;
                    _interviewBrowserPresenter.FinishInterview();
                }
            }
            catch
            {
                MessageBox.Show(
                    LocalizationManager.Instance.GetString("Error_WarmTransferError"),
                    LocalizationManager.Instance.GetString("Allert_WarningCaption"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

        }

        private void WarmTransferForm_OnCancelClick(object sender, EventArgs e)
        {
            try
            {
                _catiServiceManager.TransferCancel();
                if(!_currentTransferOptions.AllowInterviewing)
                    _interviewBrowserPresenter.ContinueInterview();
                MainForm.ShowInterviewPageControl(GetToolbarState());
                CloseWarmTransferWindowIfNeeded();
            }
            catch
            {
                MessageBox.Show(
                    LocalizationManager.Instance.GetString("Error_WarmTransferError"),
                    LocalizationManager.Instance.GetString("Allert_WarningCaption"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void WarmTransferForm_OnMergeClick(object sender, EventArgs e)
        {
            _catiServiceManager.TransferSetConnectionState(TransferConnectionState.Conference);
        }

        private void WarmTransferForm_OnTalkPrivatelyWithRespondentClick(object sender, EventArgs e)
        {
            _catiServiceManager.TransferSetConnectionState(TransferConnectionState.TargetHold);
        }

        private void WarmTransferForm_OnTalkPrivatelyWithTransferTargetClick(object sender, EventArgs e)
        {
            _catiServiceManager.TransferSetConnectionState(TransferConnectionState.RespondentHold);
        }

        private void m_MainForm_PreviousPage(object sender, EventArgs e)
        {
            _interviewBrowserPresenter.GoPrevPage();
        }

        private void m_MainForm_NextPage(object sender, EventArgs e)
        {
            _interviewBrowserPresenter.GoNextPage();
        }

        private void m_SurveyList_SurveySelectionChanged(object sender, EventArgs e)
        {
            if (UserAssignmentMode == AgentTaskChoiceMode.Manual)
            {
                SelectedSurveyIndex = SurveyList.SelectedSurvey;
                Survey survey = StoredSurveys[SelectedSurveyIndex];
                var parameters = _interviewsSearchParameters.ContainsKey(survey.Id)
                    ? _interviewsSearchParameters[survey.Id]
                    : new ConsoleSearchParameter[0];

                LoadSurveyInterviewList(survey, parameters);
            }
        }

        private void m_SurveyList_SurveySelected(object sender, EventArgs e)
        {
            if (UserAssignmentMode == AgentTaskChoiceMode.CampaignAssignment &&
                StoredSurveys.Count > 0)
            {
                Survey survey = StoredSurveys[SurveyList.SelectedSurvey];
                _currentSurveyId = survey.Id;

                StartProcess();
            }
        }

        private void m_SurveyList_InterviewSelected(object sender, EventArgs e)
        {
            if (UserAssignmentMode == AgentTaskChoiceMode.Manual)
            {
                if (StoredInterviews.Rows.Count > 0)
                {
                    Cursor savedCursor = MainForm.Cursor;

                    try
                    {
                        MainForm.Cursor = Cursors.WaitCursor;

                        Survey survey = StoredSurveys[SelectedSurveyIndex];

                        _currentSurveyId = survey.Id;
                        _currentInterviewId = SurveyList.SelectedInterview;

                        if (IsFirstInterviewTime)
                        {
                            StartProcess();
                        }
                        else
                        {
                            StartInterviewProcess();
                        }
                    }
                    finally
                    {
                        MainForm.Cursor = savedCursor;
                    }
                }
            }
        }

        private void m_SurveyList_CreateInterview(object sender, EventArgs e)
        {
            if (UserAssignmentMode == AgentTaskChoiceMode.Manual)
            {
                Cursor savedCursor = MainForm.Cursor;

                try
                {
                    MainForm.Cursor = Cursors.WaitCursor;

                    Survey survey = StoredSurveys[SelectedSurveyIndex];

                    _currentSurveyId = survey.Id;
                    try
                    {
                        _currentInterviewId = _catiServiceManager.CreateNewInterview(survey.Id);
                    }
                    catch (CreateNewInterviewException)
                    {
                        _alerter.Alert(
                            LocalizationManager.Instance.GetString("Error_CannotCreateNewInterview"),
                            LocalizationManager.Instance.GetString("Allert_ErrorCaption"),
                            MessageTypes.Error
                        );

                        m_MainForm_RefreshInterviewList(sender, e);
                        return;
                    }

                    if (IsFirstInterviewTime)
                    {
                        StartProcess();
                    }
                    else
                    {
                        StartInterviewProcess();
                    }
                }
                finally
                {
                    MainForm.Cursor = savedCursor;
                }
            }
        }

        private void m_SurveyList_SplitterMoved(object sender, EventArgs e)
        {
            ResizeSurveyColumnWidth();
        }

        private void m_SurveyList_FormResize(object sender, EventArgs e)
        {
            ResizeSurveyColumnWidth();
        }

        private void m_SurveyList_FilterInterviews(object sender, EventArgs e)
        {
            if (UserAssignmentMode == AgentTaskChoiceMode.Manual)
            {
                ConsoleSearchParameter problemParameter;

                var list = SurveyList.SearchParameters;
                Survey survey = StoredSurveys[SelectedSurveyIndex];
                _interviewsSearchParameters[survey.Id] = list.ToArray();

                if (CheckFilter(list, out problemParameter) == false)
                {
                    _alerter.Alert(LocalizationManager.Instance.GetString("Alerter_InvalidSearchParameter", problemParameter.ColumnCaption),
                       LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                       MessageTypes.Error);

                    SurveyList.ActivateColumnFilter(problemParameter.ColumnName);

                    return;
                }

                foreach (var searchParameter in list)
                {
                    if (Type.GetType(searchParameter.ColumnTypeName) == typeof(decimal))
                    {
                        var doubleVal = double.Parse(searchParameter.Value);
                        searchParameter.Value = doubleVal.ToString(CultureInfo.InvariantCulture);
                    }
                }

                FillInterviewListBySurvey(false, list.ToArray());
            }
        }

        private void m_SurveyList_ResetAllFilters(object sender, EventArgs e)
        {
            Survey survey = StoredSurveys[SelectedSurveyIndex];
            _interviewsSearchParameters.Remove(survey.Id);

            FillInterviewListBySurvey(true, new ConsoleSearchParameter[0]);
        }

        private void m_SurveyList_ColumnSortModeChanged(object sender, ColumnSortModeChangedEventArgs e)
        {
            if (SurveyList.SortOrder != SortOrder.None)
            {
                SortInterviewList(e.ColumnIndex);
                SurveyList.BindInterviewList(StoredInterviews, false, false);
            }
        }

        private void LoadSurveyInterviewList(Survey survey, ConsoleSearchParameter[] parameters)
        {
            FillInterviewListBySurvey(true, parameters);

            SurveyList.EnableCreateNewButton(survey.IsRespondentsDynamicCreationAllowed);
        }

        void OnABreakLogoutClick(object sender, EventArgs e)
        {
            LogoutAfterBreak();
        }

        void OnABreakContinueWorkClick(object sender, EventArgs e)
        {
            ContinueWorkAfterBreak();
        }

        private void m_PresenterInterview_InterviewFinished(object sender, EventArgs e)
        {
            FinishInterview();
        }

        private void m_PresenterInterview_InterviewLastPage(object sender, EventArgs e)
        {
            try
            {
                if (CatiConsoleProperties.ForceUpdateToNewVersion && _consoleAuthorizer.IsLatestVersion() == false)
                {
                    _alerter.Alert(
                        LocalizationManager.Instance.GetString("NewVersionOfConsoleIsAvailable"),
                        LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                        MessageTypes.Information);

                    MainForm.IsLogoutAfterFinishingChecked = true;
                    Logout(false, false);
                }

                Wrapup();
                _interviewBrowserPresenter.HasWrapUpBeenSent = true;
            }
            catch (EndpointNotFoundException /*ex*/)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Error_ConnectionFailed"),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                    MessageTypes.Error
                );
            }
            catch (Exception ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
            }
        }

        private void m_PresenterInterview_StartReview(object sender, EventArgs e)
        {
            StartReviewing(CurrentInterviewProperties);
        }

        private void m_MainForm_ShowRedialForm(object sender, EventArgs e)
        {
            ShowRedialForm(Initiator.MainMenu);
        }

        private void ShowRedialForm(Initiator initiator)
        {
            if (CurrentInterviewProperties == null) return;

            _disableTelephonyResultHanler = true;

            var presenter = new PresenterRedialForm((IViewRedialForm)ViewFactory.GetView(FormViews.RedialView), _presenterTelephony);

            presenter.StateChanged += _eventSender.ProcessEvents;
            presenter.CancelClick += ExecuteHangUp;
            presenter.CallIsConnected += m_RedialForm_CallIsConnected;

            presenter.SetDialCanellationButtonVisibility(CatiConsoleProperties.EnableAbilityToCancelDial);

            presenter.ShowDialog(
                MainForm,
                initiator);

            _disableTelephonyResultHanler = false;

            presenter.StateChanged -= _eventSender.ProcessEvents;
            presenter.CancelClick -= ExecuteHangUp;
            presenter.CallIsConnected -= m_RedialForm_CallIsConnected;
        }

        private void m_RedialForm_CallIsConnected(object sender, EventArgs e)
        {
            MainForm.EnableTelephonyToolbar(true, true, GetToolbarState());
        }

        private void m_MainForm_ShowAppointments(object sender, EventArgs e)
        {
            ShowAppointmentForm(Initiator.MainMenu);
        }

        private void ShowAppointmentForm(Initiator initiator)
        {
            if (CurrentInterviewProperties != null)
            {
                CurrentInterviewProperties.RespondentTimezone =
                    _catiServiceManager.GetInterviewTimezone(CurrentInterviewProperties.SurveyId,
                                                            CurrentInterviewProperties.InterviewId);
                AppointmentFormPresenter =
                    new PresenterAppointmentForm(
                        (IViewAppointmentForm)ViewFactory.GetView(FormViews.AppointmentView)
                        );

                AppointmentFormPresenter.StateChanged += _eventSender.ProcessEvents;
                AppointmentFormPresenter.FormClose += AppointmentFormPresenter_FormClose;
                AppointmentFormPresenter.ShowInterviewerAppointmensForm += AppointmentFormPresenter_ShowInterviewerAppointmensForm;
                AppointmentFormPresenter.ShowDialog(
                    CurrentInterviewProperties.SurveyId,
                    CurrentInterviewProperties.InterviewId,
                    CurrentInterviewProperties.RespondentTimezone,
                    UserAssignmentMode,
                    CatiConsoleProperties.EnableAppointmensListToolbarButton,
                    MainForm,
                    initiator);
            }
        }

        private void AppointmentFormPresenter_ShowInterviewerAppointmensForm(object sender, EventArgs e)
        {
            ShowInterviewerAppointmentsForm();
        }

        private void AppointmentFormPresenter_FormClose(object sender, EventArgs e)
        {
            AppointmentFormCloseReasons reason = AppointmentFormPresenter.CloseResult;
            Initiator initiator = AppointmentFormPresenter.Initiator;
            bool logout = AppointmentFormPresenter.Logout;

            AppointmentFormPresenter.FormClose -= AppointmentFormPresenter_FormClose;
            AppointmentFormPresenter.StateChanged -= _eventSender.ProcessEvents;
            AppointmentFormPresenter = null;

            if (reason == AppointmentFormCloseReasons.Ok)
            {
                TerminateInterview(false, TerminationReasons.Appointment);

                if (logout)
                {
                    // setting pending logout flag
                    MainForm.IsLogoutAfterFinishingChecked = true;
                    SetPendingLogout(true);
                }
            }

            if (initiator == Initiator.Script)
            {
                MainForm.ShowInterviewPageControl(GetToolbarState());
                OnStateChanged(
                    new StateChangedEventArgs { MessageType = MonitoringMessageTypes.InterviewPageBrowserShownMessage },
                    UserPassport.Instance.MonitoringIdentity);
            }
        }


        private void m_MainForm_TerminateInterview(object sender, EventArgs e)
        {
            TerminateInterview(true, TerminationReasons.Terminate);
        }

        private void LocalizationManager_CurrentCultureChanged(object sender, EventArgs e)
        {
            LocalizeViews(LocalizationManager.Instance);
        }

        private void m_MainForm_SelectedSurveyLanguageChanged(object sender, EventArgs e)
        {
            if (CurrentInterviewProperties != null)
            {
                // interviewing in progress
                string currentLanguageName = CurrentSurveyLanguageId.HasValue ?
                                             StoredSurveyLanguages.GetLanguageNameByLanguageId(CurrentSurveyLanguageId.Value) :
                                             String.Empty;

                Language language = StoredSurveyLanguages[MainForm.SelectedSurveyLanguage];
                CurrentSurveyLanguageId = language.ID;
                _interviewBrowserPresenter.ChangeLanguage(language.ID);

                OnStateChanged(
                       new StateChangedEventArgs
                       {
                           MessageType = MonitoringMessageTypes.SelectedSurveyLanguageChangedMessage,
                           State = new SelectedSurveyLanguageChangedStateData
                           {
                               PreviousLanguageName = currentLanguageName,
                               NewLanguageName = language.Name
                           }
                       },
                       UserPassport.Instance.MonitoringIdentity
                   );
            }
        }

        private void UserPassport_MonitoringStarted(object sender, EventArgs e)
        {
            StartMonitoring();
        }

        private void m_MainForm_RedoDropDownOpening(object sender, EventArgs e)
        {
            UpdateAndBindRedoList();
        }

        void m_MainForm_RedoDropDownOpen(object sender, EventArgs e)
        {
            _redoQuestionChanged = false;

            OnStateChanged(
                       new StateChangedEventArgs
                       {
                           MessageType = MonitoringMessageTypes.RedoDropDownListOpenMessage
                       },
                       UserPassport.Instance.MonitoringIdentity
                   );
        }

        void m_MainForm_RedoDropDownClose(object sender, EventArgs e)
        {
            if (_redoQuestionChanged == false)
            {
                OnStateChanged(
                           new StateChangedEventArgs
                           {
                               MessageType = MonitoringMessageTypes.RedoDropDownListCloseMessage
                           },
                           UserPassport.Instance.MonitoringIdentity
                       );
            }
        }

        void m_MainForm_PendingLogout(object sender, EventArgs e)
        {
            SetPendingLogout(MainForm.IsLogoutAfterFinishingChecked);
        }

        private void m_MainForm_RedoQuestionChanged(object sender, EventArgs e)
        {
            RedoQuestion();
            _redoQuestionChanged = true;
        }

        private void m_MainForm_FormExiting(object sender, FormClosingEventArgs e)
        {
            e.Cancel = false;

            if (_waitForLogoutComplete)
            {
                e.Cancel = true;
                return;
            }

            if (ConfirmOnExit)
            {
                if (MainForm.IsSurveyListShown)
                {
                    e.Cancel = true;
                    if (DialogResult.OK == _alerter.AlertConfirmationOkCancel(
                            LocalizationManager.Instance.GetString("Message_QuitConsoleInSurveyListConfirmation"),
                            LocalizationManager.Instance.GetString("Alerter_ConsoleCaption")
                        )
                    )
                    {
                        /* user is in selecting mode and we ask him confirmation.
                         * If he confirms, we log him out; otherwise we do nothing.
                         */
                        Logout(true, false);
                    }
                }
                else if (CurrentInterviewProperties != null &&
                    DialogResult.Cancel == _alerter.AlertConfirmationOkCancel(
                    LocalizationManager.Instance.GetString("Message_QuitConsoleConfirmationMessage"),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption")))
                {
                    // do not close if dialog result was cancel
                    e.Cancel = true;
                }
                else
                {
                    if (LoginForm.IsLoggedIn)
                    {
                        try
                        {
                            FinishLogout();
                        }
                        catch (Exception ex)
                        {
                            _logger.Log(ex.ToString(), TraceEventType.Error);
                        }
                        // In case of the interview, current interview will be interrupted with ITS InterruptedBySystem = 26
                        // And it also work for all other states (no calls or waiting, logging in and so on )
                        _catiServiceManager.TerminateTask();
                        return;
                    }
                }
            }

            if (e.Cancel == false)
            {
                FinishLogout();
            }
        }

        private void m_MainForm_FastForward(object sender, EventArgs e)
        {
            if (CurrentInterviewProperties != null)
            {
                _interviewBrowserPresenter.FastForward();
            }
        }

        private void ExecuteHangUp(object sender, DialCancellationEventArgs e)
        {
            if (IsDialerInSystem)
            {
                if (!e.IsConfirmationDialogRequired ||
                    DialogResult.OK == _alerter.AlertConfirmationOkCancel(
                    LocalizationManager.Instance.GetString("Message_HangUpConfirmation"),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"))
                    )
                {
                    var initiatior = e.IsConfirmationDialogRequired ? Initiator.MainMenu : Initiator.DialCancellation;
                    _presenterTelephony.Hangup(initiatior);

                    OnStateChanged(
                        new StateChangedEventArgs
                        {
                            MessageType = MonitoringMessageTypes.HangupMessage,
                            State = null
                        },
                        UserPassport.Instance.MonitoringIdentity
                    );

                    MainForm.EnableTelephonyToolbar(false, true, GetToolbarState());
                }
            }
        }

        private void m_MainForm_HangUp(object sender, EventArgs e)
        {
            ExecuteHangUp(sender, new DialCancellationEventArgs
            {
                IsConfirmationDialogRequired = true
            });
        }

        private void m_PresenterInterview_InternalTransfer(object sender, InternalTransferEventArgs e)
        {
            if (InterviewBrowserPresenter.IsFirstInterviewPage)
            {
                InterviewBrowserPresenter.ContinueInterview();
                return;
            }

            string resource = e.Resource;

            if (String.IsNullOrEmpty(resource))
            {
                resource = RequestInternalTransferResource();
            }

            if (!String.IsNullOrEmpty(resource))
            {
                var option = new TransferOptions
                {
                    Type = CurrentInterviewProperties.InternalTransferType == InternalTransferType.Cold 
                            ? ConsoleTransferType.InternalCold 
                            : ConsoleTransferType.InternalWarm,
                    AllowInterviewing = false,
                    Resource = resource
                };
                StartTransfer(option);
            }
            else
            {
                InterviewBrowserPresenter.ContinueInterview();
            }
        }

        private void m_MainForm_InternalCallTransfer(object sender, EventArgs e)
        {
            string resource = RequestInternalTransferResource();
            if (resource != null)
            {
                var option = new TransferOptions
                {
                    Type = CurrentInterviewProperties.InternalTransferType == InternalTransferType.Cold
                        ? ConsoleTransferType.InternalCold
                        : ConsoleTransferType.InternalWarm,
                    AllowInterviewing = true,
                    Resource = resource
                };
                StartTransfer(option);
            }
        }

        private void m_PresenterInterview_ExternalTransfer(object sender, ExternalTransferEventArgs e)
        {
            string resource = e.Resource;

            if (String.IsNullOrEmpty(resource))
            {
                resource = RequestExternalTransferResource();
            }

            if (!String.IsNullOrEmpty(resource) )
            {
                var option = new TransferOptions
                {
                    Type = CurrentInterviewProperties.ExternalTransferType == ExternalTransferType.Cold
                        ? ConsoleTransferType.ExternalCold
                        : ConsoleTransferType.ExternalWarm,
                    AllowInterviewing = false,
                    Resource = resource
                };
                StartTransfer(option);
            }
            else
            {
                InterviewBrowserPresenter.ContinueInterview();
            }
        }

        private void m_MainForm_ExternalCallTransfer(object sender, EventArgs e)
        {
            string resource = RequestExternalTransferResource();
            if (resource != null)
            {
                var option = new TransferOptions
                {
                    Type = CurrentInterviewProperties.ExternalTransferType == ExternalTransferType.Cold
                        ? ConsoleTransferType.ExternalCold
                        : ConsoleTransferType.ExternalWarm,
                    AllowInterviewing = true,
                    Resource = resource
                };
                StartTransfer(option);
            }
        }


        private string RequestInternalTransferResource()
        {
            if (_catiServiceManager.GetInternalTransferTargets().Length == 0)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Alerter_InternalCallTransferIsNotPossibleMessage"),
                    LocalizationManager.Instance.GetString("Alerter_InternalCallTransferIsNotPossibleTitle"),
                    MessageTypes.Information);
                return null;
            }

            var presenter = new PresenterInternalCallTransferForm((IViewInternalCallTransferForm)ViewFactory.GetView(FormViews.InternalCallTransferView), CurrentInterviewProperties.InternalTransferType);

            presenter.LastUsedTransferTargetGroupName = _lastUsedTransferTargetGroupName;

            presenter.StateChanged += _eventSender.ProcessEvents;

            presenter.ShowDialog(MainForm, _catiServiceManager);

            _lastUsedTransferTargetGroupName = presenter.LastUsedTransferTargetGroupName;

            presenter.StateChanged -= _eventSender.ProcessEvents;

            return presenter.SelectedResource;
        }

        private string RequestExternalTransferResource()
        {
            if (_catiServiceManager.GetExternalTransferTargets().Length == 0)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Alerter_ExternalCallTransferIsNotPossibleMessage"),
                    LocalizationManager.Instance.GetString("Alerter_ExternalCallTransferIsNotPossibleTitle"),
                    MessageTypes.Information);
                return null;
            }

            var presenter = new PresenterExternalCallTransferForm((IViewExternalCallTransferForm)ViewFactory.GetView(FormViews.ExternalCallTransferView), CurrentInterviewProperties.ExternalTransferType);

            presenter.StateChanged += _eventSender.ProcessEvents;

            presenter.LastUsedTransferTargetPhoneNumber = _lastUsedTransferTargetPhoneNumber;

            presenter.ShowDialog(MainForm, _catiServiceManager);

            _lastUsedTransferTargetPhoneNumber = presenter.LastUsedTransferTargetPhoneNumber;

            presenter.StateChanged -= _eventSender.ProcessEvents;

            return presenter.SelectedResource;
        }

        private void m_MainForm_RefreshInterviewList(object sender, EventArgs e)
        {
            switch (UserAssignmentMode)
            {
                case AgentTaskChoiceMode.Manual:
                    _taskChoiceRouter.StartManualMode();
                    break;
                case AgentTaskChoiceMode.CampaignAssignment:
                    _taskChoiceRouter.StartSurveyAssignmentMode();
                    break;
            }
        }

        private void m_MainForm_StartPlayback(object sender, EventArgs e)
        {
            if (IsDialerInSystem)
            {
                if (!string.IsNullOrEmpty(_currentSoundFile))
                {
                    int timeOfPlayingInSeconds; // It is not used for now.
                    _presenterTelephony.StartPlayback(_currentSoundFile, out timeOfPlayingInSeconds);
                    OnStateChanged(
                        new StateChangedEventArgs
                        {
                            MessageType = MonitoringMessageTypes.StartPlaybackMessage,
                            State = new StartPlaybackData
                            {
                                FileName = _currentSoundFile
                            }
                        },
                        UserPassport.Instance.MonitoringIdentity);
                }
            }
        }

        private void m_MainForm_PauseOrResumePlayback(object sender, EventArgs e)
        {
            if (IsDialerInSystem)
            {
                _presenterTelephony.PauseOrResumePlayback();

                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.PauseOrResumePlaybackMessage,
                        State = null
                    },
                    UserPassport.Instance.MonitoringIdentity);
            }
        }

        private void m_MainForm_StopPlayback(object sender, EventArgs e)
        {
            if (IsDialerInSystem)
            {
                _presenterTelephony.StopPlayback();

                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.StopPlaybackMessage,
                        State = null
                    },
                    UserPassport.Instance.MonitoringIdentity);
            }
        }

        private void m_MainForm_ToggleInterviewerListensToPlaybackOrRespondent(object sender, EventArgs e)
        {
            if (IsDialerInSystem)
            {
                _presenterTelephony.ToggleInterviewerListensToPlaybackOrRespondent();

                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.ToggleInterviewerListensToPlaybackOrRespondentMessage,
                        State = null
                    },
                    UserPassport.Instance.MonitoringIdentity);
            }
        }

        void m_MainForm_PendingBreak(object sender, EventArgs e)
        {
            if (BreakTypes.Count == 1)
            {
                MainForm.SelectedBreakIndex = 0;
                MainForm.IsPendingBreakChecked = !MainForm.IsPendingBreakChecked;
            }

            MainForm.UpdatePendingBreakControls();

            SetPendingBreak();
        }

        void m_MainForm_ChangeTaskChoice(object sender, EventArgs e)
        {
            if (IsChangeTaskChoiceEnabled == false || UserPassport.Instance.Properties.TaskChoicePermissions == null)
            {
                return;
            }

            if (MainForm.IsSurveyListShown && MainForm.IsChangeTaskChoiceChecked)
            {
                MainForm.IsChangeTaskChoiceChecked = false;
                ChangeTaskChoiceAndStartSelectionProcess(UserPassport.Instance.Properties.TaskChoicePermissions.Value);
            }
        }

        private void m_MainForm_SpellCheck(object sender, EventArgs e)
        {
            ShowCheckSpellingForm();
        }


        private void m_MainForm_FormActivated(object sender, EventArgs e)
        {
            PresenterInterview.FocusActiveElement();
        }

        private void SpellCheckPresenter_SaveOnFormClosed(object sender, EventArgs e)
        {
            SpellCheckPresenter.SaveOnFormClosed -= SpellCheckPresenter_SaveOnFormClosed;
            PresenterInterview.UpdatePageTextBlocks(SpellCheckPresenter.TextBlocks);
        }

        private void m_MainForm_FormProcessCmdKey(object sender, ProcessCmdKeyEventArgs e)
        {
            if ((StatusBar.Mode == StatusBarModes.Interviewing || StatusBar.Mode == StatusBarModes.Reviewing) &&
                e.KeyData == Keys.F5)
            {
                _interviewBrowserPresenter.RefreshPage();
                e.Cancel = true;
                return;
            }

            if (e.KeyData == (Keys.Control | Keys.X) && StatusBar.Mode != StatusBarModes.LoginView && CanCancelDial)
            {
                MainForm.IsDialCanellationButtonEnabled = false;
                ExecuteHangUp(this, new DialCancellationEventArgs
                {
                    IsConfirmationDialogRequired = false
                });
            }

            if (StatusBar.Mode == StatusBarModes.Interviewing)
            {
                if (_interviewBrowserPresenter.IsTelephonyPage ||
                    _interviewBrowserPresenter.IsCatiMarkupAndKeyboardSupportDisabled)
                {
                    return;
                }
            }

            if (StatusBar.Mode == StatusBarModes.Interviewing)
            {
                switch (e.KeyData)
                {
                    case Keys.Control | Keys.Back:
                        if (MainForm.IsPreviousPageEnabled)
                        {
                            m_MainForm_PreviousPage(null, EventArgs.Empty);
                        }
                        e.Cancel = true;
                        return;
                    case Keys.Control | Keys.Enter:
                        if (MainForm.IsFastForwardEnabled)
                        {
                            m_MainForm_FastForward(null, EventArgs.Empty);
                        }
                        e.Cancel = true;
                        return;
                    case Keys.Control | Keys.X:
                        if (MainForm.IsTerminateEnabled)
                        {
                            m_MainForm_TerminateInterview(null, EventArgs.Empty);
                        }
                        e.Cancel = true;
                        return;
                    case Keys.Control | Keys.Q:
                        if (MainForm.IsLogoutAfterFinishingEnabled)
                        {
                            MainForm.IsLogoutAfterFinishingChecked = !MainForm.IsLogoutAfterFinishingChecked;
                            m_MainForm_PendingLogout(null, EventArgs.Empty);
                        }
                        e.Cancel = true;
                        return;
                    case Keys.Control | Keys.A:
                        if (MainForm.IsAppointmentsEnabled)
                        {
                            m_MainForm_ShowAppointments(null, EventArgs.Empty);
                        }
                        e.Cancel = true;
                        return;
                    case Keys.Control | Keys.H:
                        if (MainForm.IsHangUpEnabled)
                        {
                            m_MainForm_HangUp(null, EventArgs.Empty);
                        }
                        e.Cancel = true;
                        return;
                    case Keys.Control | Keys.B:
                        if (MainForm.IsPendingBreakEnabled)
                        {
                            SetPendingBreakWithShortCut();
                        }
                        e.Cancel = true;
                        return;
                    case Keys.F5:
                        _interviewBrowserPresenter.RefreshPage();
                        e.Cancel = true;
                        return;
                    case Keys.F7:
                        if (MainForm.IsCheckSpellingEnabled)
                        {
                            ShowCheckSpellingForm();
                        }
                        e.Cancel = true;
                        return;
                }
            }
            else if (StatusBar.Mode == StatusBarModes.Reviewing)
            {
                switch (e.KeyData)
                {
                    case Keys.Control | Keys.Back:
                        if (MainForm.IsPreviousPageEnabled)
                        {
                            m_MainForm_PreviousPage(null, EventArgs.Empty);
                        }
                        e.Cancel = true;
                        return;
                    case Keys.Control | Keys.Enter:
                        if (MainForm.IsFastForwardEnabled)
                        {
                            m_MainForm_FastForward(null, EventArgs.Empty);
                        }
                        e.Cancel = true;
                        return;
                    case Keys.Control | Keys.Q:
                        if (MainForm.IsLogoutAfterFinishingEnabled)
                        {
                            MainForm.IsLogoutAfterFinishingChecked = !MainForm.IsLogoutAfterFinishingChecked;
                            m_MainForm_PendingLogout(null, EventArgs.Empty);
                        }
                        e.Cancel = true;
                        return;
                    case Keys.Control | Keys.B:
                        if (MainForm.IsPendingBreakEnabled)
                        {
                            SetPendingBreakWithShortCut();
                        }
                        e.Cancel = true;
                        return;
                    case Keys.F5:
                        _interviewBrowserPresenter.RefreshPage();
                        e.Cancel = true;
                        return;
                    case Keys.F7:
                        if (MainForm.IsCheckSpellingEnabled)
                        {
                            ShowCheckSpellingForm();
                        }
                        e.Cancel = true;
                        return;
                }
            }
            else if (StatusBar.Mode == StatusBarModes.MainView)
            {
                switch (e.KeyData)
                {
                    case Keys.Control | Keys.B:
                        if (MainForm.IsPendingBreakEnabled)
                        {
                            SetPendingBreakWithShortCut();
                        }
                        e.Cancel = true;
                        return;
                }
            }
            else if (StatusBar.Mode == StatusBarModes.LoginView)
            {
                switch (e.KeyData)
                {
                    case Keys.Alt | Keys.S:
                        ShowStationIdForm();
                        e.Cancel = true;
                        return;
                }
            }
        }

        private void m_MainForm_ShowAppointmentList(object sender, EventArgs e)
        {
            ShowInterviewerAppointmentsForm();
        }

        private void m_PresenterInterview_Dial(object sender, DialEventArgs e)
        {
            if (IsDialerInSystem && _interviewBrowserPresenter.AllowTelephonyCommands)
            {
                string dialMessage = e.DialMessage;
                if (string.IsNullOrEmpty(dialMessage))
                {
                    dialMessage = $"{LocalizationManager.Instance.GetString("DialControl_Phone_Text")} {e.Phone}";
                }

                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.DialStartMessage,
                        State = new DialStartData
                        {
                            Message = dialMessage,
                            Phone = e.Phone
                        }
                    },
                    UserPassport.Instance.MonitoringIdentity
                );

                MainForm.IsDialCanellationButtonEnabled = true;
                MainForm.SetDialCanellationButtonVisibility(CatiConsoleProperties.EnableAbilityToCancelDial);
                MainForm.ShowDialControl();

                try
                {
                    _presenterTelephony.Dial(e.Phone, dialMessage);
                }
                catch (Exception ex)
                {
                    RestartAfterCommunicationError(ex);
                }
            }
            else
            {
                _interviewBrowserPresenter.SetDialStatusAndContinue((int)CallOutcome.NotAutomaticallyDialled);
            }
            CloseWarmTransferWindowIfNeeded();
        }

        private void m_PresenterInterview_Hangup(object sender, EventArgs e)
        {
            if (IsDialerInSystem && _interviewBrowserPresenter.AllowTelephonyCommands)
            {
                MainForm.ShowHangupControl();
                _presenterTelephony.Hangup(Initiator.Script);

                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.HangupMessage,
                        State = null
                    },
                    UserPassport.Instance.MonitoringIdentity
                );

                _interviewBrowserPresenter.ContinueInterview();
                MainForm.ShowInterviewPageControl(GetToolbarState());
                MainForm.EnableTelephonyToolbar(false, true, GetToolbarState());
            }
            else
            {
                _interviewBrowserPresenter.ContinueInterview();
            }
            CloseWarmTransferWindowIfNeeded(false);
        }

        private void m_PresenterInterview_PlaybackFound(object sender, PlaybackFoundEventArgs e)
        {
            if (IsDialerInSystem)
            {
                if (!string.IsNullOrEmpty(_currentSoundFile))
                {
                    if (e.SoundFile.Equals(_currentSoundFile))
                    {
                        // This page has the same sound file as the previous one. Just keep all things as is: 
                        // let the sound file continue playing if it has been playing.
                        return;
                    }
                    _presenterTelephony.StopPlayback(); // Just in case the previous file is still playing.    
                }

                ShowPlaybackToolbar(true);

                // We are here, so the question page has a sound file which differs from the previous one.
                _currentSoundFile = e.SoundFile;

                if (e.StartPlaybackAutomatically)
                {
                    int timeOfPlayingInSeconds; // It is not used for now.
                    _presenterTelephony.StartPlayback(_currentSoundFile, out timeOfPlayingInSeconds);
                }
            }
        }

        /// <summary>
        /// This question page does not contain a sound file, stop playing previous sound file if needed, reset sound file fields and return.
        /// </summary>
        private void m_PresenterInterview_PlaybackNotFound(object sender, EventArgs e)
        {
            if (IsDialerInSystem)
            {
                ShowPlaybackToolbar(false);
                if (!string.IsNullOrEmpty(_currentSoundFile))
                {
                    _presenterTelephony.StopPlayback();
                }

                _currentSoundFile = null;
            }
        }

        private void ShowPlaybackToolbar(bool isVisible)
        {
            MainForm.ShowPlaybackToolbar(isVisible, IsPauseResumePlaybackEnabled, IsToggleVoiceSourceSupported);
        }

        private void PresenterTelephonyTelephonyResult(object sender, TelephonyResultEventArgs e)
        {
            if (_disableTelephonyResultHanler)
            {
                return;
            }

            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.TelephonyCompleteMessage,
                    State = new TelephonyResultData
                    {
                        Status = e.Status
                    }
                },
                UserPassport.Instance.MonitoringIdentity
            );

            CurrentInterviewProperties.CallOutcome = e.Status;
            _interviewBrowserPresenter.SetDialStatusAndContinue(e.Status);

            MainForm.ShowInterviewPageControl(GetToolbarState());
        }

        /// <summary>
        /// Event handler for LoggedToDialerInEvent event
        /// Does start interviewing with previously saved surveyId and interviewId
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m_PresenterTelephony_LoggedToDialerInEvent(object sender, GetStateEventArgs e)
        {
            StartInterviewProcess();
        }

        /// <summary>
        /// Event handler for LoginToDialerErrorEvent
        /// Inform interviewer about timeout and asks about exit or retry
        /// </summary>
        void m_PresenterTelephony_LoginToDialerErrorEvent(object sender, GetStateEventArgs e)
        {
            LoginToDialerErrorEventHandler(e);
        }

        /// <summary>
        /// Event handler for LogoutWhileLoginToDialerEvent
        /// Informs interviewer about he was logged out and restarts console
        /// </summary>
        void m_PresenterTelephony_LogoutWhileLoginToDialerEvent(object sender, GetStateEventArgs e)
        {
            LogoutFromGetState();
        }

        private void m_PresenterInterview_ForcedAppointment(object sender, EventArgs e)
        {
            MainForm.ShowBlankForm();
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.BlankControlShownMessage
                },
                UserPassport.Instance.MonitoringIdentity);
            ShowAppointmentForm(Initiator.Script);
        }

        private void m_PresenterInterview_StartCallTransfer(object sender, StartCallTransferEventArgs e)
        {
            StartTransfer(e.Options);
        }

        private void StartTransfer(TransferOptions option)
        {
            MainForm.ShowProcessControl(LocalizationManager.Instance.GetString("Message_ProcessControl_Transfer"));

            try
            {
                _catiServiceManager.TransferStart(option);
            }
            catch (UserMessageException ex)
            {
                _alerter.Alert(
                    string.Format(LocalizationManager.Instance.GetString("Error_UnableToStartCallTransfer"), ex.Message),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                    MessageTypes.Error);
                return;
            }
            catch (Exception ex)
            {
                _alerter.Alert(
                    string.Format(LocalizationManager.Instance.GetString("Error_UnableToStartCallTransfer"), LocalizationManager.Instance.GetString("Error_InternalServerError")),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                    MessageTypes.Error);
                _logger.Log(ex);

                MainForm.ShowInterviewPageControl(GetToolbarState());
                if (!option.AllowInterviewing)
                    InterviewBrowserPresenter.ContinueInterview();

                return;
            }

            _currentTransferOptions = option;

            switch (option.Type)
            {
                case ConsoleTransferType.InternalCold:
                    _catiServiceManager.TransferComplete();
                    _interviewBrowserPresenter.HasWrapUpBeenSent = true;

                    _interviewBrowserPresenter.FinishInterview();
                    break;
                case ConsoleTransferType.ExternalCold:
                    _catiServiceManager.TransferComplete();

                    MainForm.ShowInterviewPageControl(GetToolbarState());

                    _interviewBrowserPresenter.TerminateInterview((int)TerminationReasons.ExternalTransfer);
                    break;
                case ConsoleTransferType.InternalWarm:
                case ConsoleTransferType.ExternalWarm:
                    StartOutgoingTransfer(option, CallTransferConfigurationConverter.GetDefaultTransferState(option));
                    break;
                default:
                    _logger.Log(new Exception($"Internal error: unknown type of transfer '{option.Type}'"));
                    return;
            }            
        }

        /// <summary>
        /// Event handler for CatiServiceHelper.GetStateError event.
        /// This event informs that error state was returned during last
        /// CatiServiceManager.GetState call. For now we should show
        /// message to user and restart application.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Event arguments.</param>
        void CatiServiceHelper_GetStateError(object sender, GetStateErrorEventArgs e)
        {
            if (e.ProblemState.IsProblem)
            {
                _logger.Log(
                    Strings.ResourceManager.GetString("Log_ProblemState", e.ProblemState.ToString()),
                    TraceEventType.Error
                );

                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Message_TelephonyProblem", e.ProblemState.Message),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                    MessageTypes.Error
                );

                RestartApplication();
            }
        }

        /// <summary>
        /// Event handler for case when interviewer tries close TaskChoice form without selection 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void taskChoiceForm_CancelClicking(object sender, CancelEventArgs e)
        {
            if (_alerter.AlertConfirmation(
                       LocalizationManager.Instance.GetString("Alerter_YouWillBeWorkInFirstAllowedMode"),
                       LocalizationManager.Instance.GetString("Alerter_ConsoleCaption")
                   ) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        /// <summary>
        /// Logs into Web Service.
        /// </summary>
        /// <param name="user">User name.</param>
        /// <param name="password">User password.</param>
        /// /// <param name="companyId">Company Id.</param>
        public void Login(string user, string password, int companyId)
        {
            try
            {
                var stationId = IsAutoPilotEnabled ? AutoPilotArguments.StationId : ClientSettings.Default.StationId;

                UserProperties props = _catiServiceManager.Login(
                    stationId, user, password, companyId,
                    _consoleDescriptionProvider.GetConsoleDescription());

                LoginForm.IsLoggedIn = true;
                LoginForm.Clear();
                LoginForm.CloseForm();

                UserPassport.Instance.Properties = props;

                IsDialerInSystem = props.ConnectedToDialer || _presenterTelephony.IsCustomDialerUsed;
                HasStationExtensionNumber = props.HasStationExtensionNumber;

                InitServerLogging();

                MainForm.ShowRedialButton(ShowRedialButton);
                MainForm.ShowInternalCallTransferButton(ShowInternalCallTransferButton);
                MainForm.ShowExternalCallTransferButton(ShowExternalCallTransferButton);

                StatusBar.Mode = StatusBarModes.MainView;
                StatusBar.UserName = UserPassport.Instance.UserName;

                _connectionQualityAnalyzer = new ConnectionQualityAnalyzer(
                    CatiConsoleProperties.KeepAliveCallsToSave,
                    CatiConsoleProperties.GoodConnectionThresholdMs,
                    CatiConsoleProperties.NormalConnectionThresholdMs);

                _keepAliver.StartKeepAliveThread(CatiConsoleProperties, NewMessageFromKeepAlive, LogoutFromKeepAlive, SaveKeepAliveDuration);
            }
            catch (CatiInvalidInstanceException)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Error_CannotLoginToSpecifiedInstance"),
                    LocalizationManager.Instance.GetString("Allert_ErrorCaption"),
                    MessageTypes.Error
                );
            }
            catch (CatiServiceException ex)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Error_GeneralCatiWSException", ex.Error, ex.Message),
                    LocalizationManager.Instance.GetString("Allert_ErrorCaption"),
                    MessageTypes.Error
                );
            }
            catch (UserAlreadyLoggedInException)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Error_UserAlreadyLoggenIn"),
                    LocalizationManager.Instance.GetString("Allert_ErrorCaption"),
                    MessageTypes.Error
                );
            }
            catch (NotSupportedOsException)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Error_NotSupportedOs"),
                    LocalizationManager.Instance.GetString("Allert_ErrorCaption"),
                    MessageTypes.Error
                );
            }
            /*
             * TODO: This exception is thrown in PersonLoginProcessor class in CreateOrUpdateTask and FillDialerInfo methods
             * TODO: Need to use a specific exceptions instead of UserMessageException
            */
            catch (UserMessageException ex)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString(ex.MessageKey),
                    LocalizationManager.Instance.GetString("Allert_ErrorCaption"),
                    MessageTypes.Error
                    );
            }
            catch (WebException ex)//network errors
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString(
                        "Error_CouldntConnectToServer",
                        ex.Message
                    ),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                    MessageTypes.Error
                );
            }
            catch (InvalidOperationException ex) //occurs in particular if web service response is incorrect 
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
            }
            catch (Exception ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
            }
        }

        /// <summary>
        /// Starts processing after successful login.
        /// </summary>
        internal void Start()
        {
            try
            {
                MainForm.BindBreakTypes(BreakTypes);

                if (UserPassport.Instance.Properties.AlreadyLoggedIn == false)
                {
                    if (UserPassport.Instance.Properties.TaskChoicePermissions == null)
                    {
                        StartSelectionProcess();
                    }
                    else
                    {
                        SelectTaskChoiceAndStartSelectionProcess(UserPassport.Instance.Properties.TaskChoicePermissions.Value);
                    }
                }
                else
                {
                    ContinuePendingProcess();
                }
            }
            catch (Exception ex)
            {
                _logger.Log(ex);
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
            }
        }

        private void SelectTaskChoiceAndStartSelectionProcess(TaskChoicePermissions permissions)
        {
            var allowedChoices = TaskChoicePermissionsHelper.GetAllowed(permissions);

            AgentTaskChoiceMode mode = TaskChoicePermissionsHelper.GetFirstAllowed(permissions);

            if (allowedChoices.Count > 1)
            {
                var taskChoiceForm = (IViewSelectTaskChoiceForm)ViewFactory.GetView(FormViews.TaskChoiceView);
                taskChoiceForm.Localize(LocalizationManager.Instance);

                taskChoiceForm.BindTaskChoiceList(allowedChoices);

                taskChoiceForm.CancelClicking += taskChoiceForm_CancelClicking;

                if (taskChoiceForm.Show(MainForm) == DialogResult.OK)
                {
                    mode = (AgentTaskChoiceMode)taskChoiceForm.SelectedTaskChoice;
                }
            }

            UpdatePersonMode(mode);

            StartSelectionProcess();
        }

        private void ChangeTaskChoiceAndStartSelectionProcess(TaskChoicePermissions permissions)
        {
            var allowedChoices = TaskChoicePermissionsHelper.GetAllowed(permissions);

            var taskChoiceForm = (IViewSelectTaskChoiceForm)ViewFactory.GetView(FormViews.TaskChoiceView);
            taskChoiceForm.Localize(LocalizationManager.Instance);

            taskChoiceForm.BindTaskChoiceList(allowedChoices);

            if (taskChoiceForm.Show(MainForm) == DialogResult.OK)
            {
                var mode = (AgentTaskChoiceMode)taskChoiceForm.SelectedTaskChoice;
                UpdatePersonMode(mode);
            }

            StartSelectionProcess();
        }

        /// <summary>
        /// Starts interviewing in survey assignment mode. In this mode user
        /// could choose only survey.
        /// </summary>
        public void StartSurveyAssignmentMode()
        {
            SurveyCollection surveys = new SurveyCollection();
            try
            {
                surveys = _catiServiceManager.GetSurveys();
            }
            catch (Exception ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
            }

            StoredSurveys = surveys;
            _interviewsSearchParameters.Clear();

            if (IsAutoPilotEnabled &&
                (string.IsNullOrEmpty(UserPassport.Instance.Properties.AutomaticSurveyName) && StoredSurveys.Count > 1))
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Exception_UnsupportedSurveySelectionConfigForAutopilot"),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                    MessageTypes.Error
                    );

                Logout(false, false);
                return;
            }

            if (!String.IsNullOrEmpty(UserPassport.Instance.Properties.AutomaticSurveyName))
            {
                if (!StoredSurveys.Select(x => x.Id).Contains(UserPassport.Instance.Properties.AutomaticSurveyName))
                {
                    var message = LocalizationManager.Instance.GetString("Alerter_AutomaticSurveyIsClosedYouWillBeLoggedOut", UserPassport.Instance.Properties.AutomaticSurveyName);
                    _logger.Log(message, TraceEventType.Information);

                    _alerter.Alert(
                        message,
                        LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                        MessageTypes.Information
                    );

                    Logout(false, false);
                    return;
                }

                _currentSurveyId = UserPassport.Instance.Properties.AutomaticSurveyName;
                StartProcess();
            }
            else if (StoredSurveys.Count == 1)
            {
                _currentSurveyId = StoredSurveys[0].Id;
                StartProcess();
            }
            else
            {
                BindAndShowSurveyList(0, false);
            }

            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.InterviewSelectingStartMessage
                },
                UserPassport.Instance.MonitoringIdentity
            );
        }

        /// <summary>
        /// Checks if two given surveys are the same.
        /// </summary>
        /// <param name="first">First survey.</param>
        /// <param name="second">Second survey.</param>
        /// <returns>true, if surveys are equal; otherwise false.</returns>
        internal bool IsSameSurveyList(SurveyCollection first, SurveyCollection second)
        {
            return first == second;
        }

        /// <summary>
        /// Starts interviewing in manual mode. In this mode user
        /// could choose survey and interview.
        /// </summary>
        public void StartManualMode()
        {
            if (IsAutoPilotEnabled)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Exception_UnsupportedTaskChoiceForAutopilot"),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                    MessageTypes.Error
                    );

                Logout(false, false);
                return;
            }

            var surveys = new SurveyCollection();

            try
            {
                surveys = _catiServiceManager.GetSurveys();
            }
            catch (Exception ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
            }

            if (!IsSameSurveyList(StoredSurveys, surveys))
            {
                SelectedSurveyIndex = 0;
                StoredSurveys = surveys;
                _interviewsSearchParameters.Clear();
            }

            BindAndShowSurveyList(SelectedSurveyIndex, true);

            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.InterviewSelectingStartMessage
                },
                UserPassport.Instance.MonitoringIdentity
            );
        }

        /// <summary>
        /// Binds SurveyList control with list of surveys.
        /// </summary>
        /// <param name="surveyIndex">Selected survey index in survey list.</param>
        /// <param name="enableInterviewList">Enable/disable interview list.</param>
        internal void BindAndShowSurveyList(int surveyIndex, bool enableInterviewList)
        {
            if (StoredSurveys.Count == 0)
            {
                SurveyList.ShowMessageSurveyList(LocalizationManager.Instance.GetString("Message_EmptySurveyList_Text"));
                enableInterviewList = false;
                SurveyList.EnableCreateNewButton(false);
            }
            else
            {
                BindSurveyList(StoredSurveys);
                SurveyList.SelectedSurvey = surveyIndex;
                SurveyList.EnableCreateNewButton(StoredSurveys[surveyIndex].IsRespondentsDynamicCreationAllowed);
            }

            SurveyList.EnableInterviewList(enableInterviewList);
            MainForm.ShowSurveyListControl(GetToolbarState());
        }

        /// <summary>
        /// Clears resources which have been allocated during last session.
        /// </summary>
        public void ClearResources()
        {
            /*ega*/
            var oldWaitCursor = Application.UseWaitCursor;
            try
            {
                Application.UseWaitCursor = true;
                _eventSender.Dispose();
            }
            finally
            {
                Application.UseWaitCursor = oldWaitCursor;
            }

            _keepAliver.ClearResources();

            StopInterviewCycleTimer();
            AsyncOperationInvoker.Instance.ClearResources();

            _catiServiceManager.Release();
            _consoleAuthorizer.Release();
            Logger.Release();

            CurrentInterviewProperties = null;
            IsFirstInterviewTime = true;
            CurrentSurveyLanguageId = null;
            PreviousSurveyId = String.Empty;

            MainForm.ClearVisualState();

            StoredSurveys = new SurveyCollection();
            StoredInterviews = new DataTable();
            StoredRedoQuestions = new QuestionHistoryCollection();
            _interviewsSearchParameters.Clear();
        }

        /// <summary>
        /// Forced logout. Restart application.
        /// </summary>
        private void LogoutFromKeepAlive(object stateData)
        {
            bool isLoggedIn = LoginForm.IsLoggedIn;

            FinishLogout();
            MainForm.ShowBlankForm();
            _logger.Log(Strings.Log_UserLoggedOutFromKeepAlive, TraceEventType.Information);

            if (isLoggedIn)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Alerter_YouWasLoggedOutBySystem"),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                    MessageTypes.Error
                    );
            }

            RestartApplication();
        }

        /// <summary>
        /// Is called after each KeepAlive
        /// </summary>
        /// <param name="keepAliveDuration"></param>
        private void SaveKeepAliveDuration(object keepAliveDuration)
        {
            var currentDuration = Convert.ToInt64(keepAliveDuration);

            var quality = _connectionQualityAnalyzer.AddCallAndAnalyzeConnection(currentDuration);

            MainForm.UpdateConnectionIndicator(quality);
        }

        /// <summary>
        /// Is Called when new messages for interviewer are detected 
        /// </summary>
        /// <param name="stateData"></param>
        private void NewMessageFromKeepAlive(object stateData)
        {
            if (NewMessageDetected != null)
            {
                NewMessageDetected(this, EventArgs.Empty);
            }
        }

        /// <summary>
        /// Starts processing of interview selection.
        /// In "Manual" mode we show survey list and interview list
        /// In "Survey assignment" mode we show survey list
        /// In "Automatic" mode we process automatically
        /// </summary>
        internal void StartSelectionProcess()
        {
            switch (UserAssignmentMode)
            {
                case AgentTaskChoiceMode.Automatic:
                    _taskChoiceRouter.StartAutomaticMode();
                    break;
                case AgentTaskChoiceMode.CampaignAssignment:
                    _taskChoiceRouter.StartSurveyAssignmentMode();
                    break;
                case AgentTaskChoiceMode.Manual:
                    _taskChoiceRouter.StartManualMode();
                    break;
                default:
                    throw new NotSupportedException(
                             Strings.ResourceManager.GetString("Exception_UnsupportedTaskChoice", UserAssignmentMode));
            }
        }

        /// <summary>
        /// Starts interviewing in automatic mode.
        /// </summary>
        public void StartAutomaticMode()
        {
            StartProcess();
        }

        /// <summary>
        /// Terminates current interview with confirmation.
        /// </summary>
        /// <param name="showConfirmationDialog">If flag is true, we should show
        /// confirmation dialog.</param>
        /// <param name="reason">Reason, why we terminate interview.</param>
        /// <returns>true, if interview is terminated; otherwise false.</returns>
        public bool TerminateInterview(bool showConfirmationDialog, TerminationReasons reason)
        {
            if (showConfirmationDialog)
            {
                OnStateChanged(
                   new StateChangedEventArgs
                   {
                       MessageType = MonitoringMessageTypes.InterviewTerminateDialogShownMessage
                   },
                   UserPassport.Instance.MonitoringIdentity
               );
            }

            bool result = false;

            if (showConfirmationDialog == false ||
                (_alerter.AlertConfirmation(
                    LocalizationManager.Instance.GetString("Error_TerminateInterviewConfirmationMessage"),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption")
                    ) == DialogResult.Yes)
                )
            {
                _interviewBrowserPresenter.TerminateInterview((int)reason);
                result = true;
            }

            if (showConfirmationDialog)
            {
                OnStateChanged(
                   new StateChangedEventArgs
                   {
                       MessageType = MonitoringMessageTypes.InterviewTerminateDialogCloseMessage
                   },
                   UserPassport.Instance.MonitoringIdentity
               );
            }

            return result;
        }

        /// <summary>
        /// Initializes localization according setting in config file.
        /// </summary>
        private void InitLocalization()
        {
            if (String.IsNullOrEmpty(Properties.Settings.Default.Culture))
            {
                LocalizeViews(LocalizationManager.Instance);
            }
            else
            {
                try
                {
                    CultureInfo culture = new CultureInfo(Properties.Settings.Default.Culture);
                    LocalizationManager.Instance.CurrentCulture = culture;
                }
                catch (Exception /*ex*/)
                {
                    // as we don't recognize given culture, so we should use default
                    LocalizeViews(LocalizationManager.Instance);
                    /*ega
                     * TODO: log message
                     */
                }
            }
        }

        /// <summary>
        /// Localizes views according current localization settings.
        /// </summary>
        /// <param name="manager">Manager providing localization info.</param>
        private void LocalizeViews(ILocalizationManager manager)
        {
            LoginForm.Localize(manager);
            ChangePasswordForm.Localize(manager);
            MainForm.Localize(manager);
            SurveyList.Localize(manager);
            StatusBar.Localize(manager);
            _onABreak.Localize(manager);
        }

        /// <summary>
        /// Fills interview list by interviews         
        /// </summary>
        /// <remarks>
        /// If filterField is specified filtered interview list is binded
        /// </remarks>
        /// <param name="fullRebuild">If true header and data will be fully rebuilt </param>
        /// <param name="parameters">Search parameters</param>
        private void FillInterviewListBySurvey(bool fullRebuild, ConsoleSearchParameter[] parameters)
        {
            if (UserAssignmentMode == AgentTaskChoiceMode.Manual)
            {
                if (StoredSurveys.Count == 0) return;

                Survey survey = StoredSurveys[SelectedSurveyIndex];

                try
                {
                    StoredInterviews = _catiServiceManager.GetInterviews(survey.Id, parameters);
                    // if we rebuild interview list (for example user has changed survey)
                    // we do not need sorting (default sorting is performed)
                    if (fullRebuild == false && SurveyList.SortedColumnIndex != -1)
                    {
                        SortInterviewList(SurveyList.SortedColumnIndex);
                    }

                    FormatTimeColumns();
                }
                catch (Exception ex)
                {
                    _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));

                    StoredInterviews = new DataTable();
                }

                SurveyList.BindInterviewList(StoredInterviews, fullRebuild, true);
                SurveyList.BindSearchParameters(parameters);
                SurveyList.Localize(LocalizationManager.Instance);
                SurveyList.EnableInterviewList(true);
            }
        }

        private void FormatTimeColumns()
        {
            if (!StoredInterviews.Columns.Contains("TimeToCall"))
            {
                return;
            }

            var dtCloned = StoredInterviews.Clone();
            dtCloned.Columns["TimeToCall"].DataType = typeof(string);
            dtCloned.Columns["RespondentTime"].DataType = typeof(string);
            foreach (DataRow row in StoredInterviews.Rows)
            {
                dtCloned.ImportRow(row);
            }
            StoredInterviews = dtCloned;

            var localizationManager = LocalizationManager.Instance;
            var respondentTimeString = localizationManager.GetString("SurveyList_RespondentTime_TimeToCallTooltip");

            foreach (DataRow row in StoredInterviews.Rows)
            {
                row["TimeToCall"] = DateTimeManager.ParseDateTime(row["TimeToCall"], false);
                row["RespondentTime"] = string.Format("{0}: {1}", respondentTimeString, DateTimeManager.ParseDateTime(row["RespondentTime"], true));
            }
        }

        /// <summary>
        /// Binds survey list with specified values.
        /// </summary>
        /// <param name="surveys">Survey to bind.</param>
        private void BindSurveyList(SurveyCollection surveys)
        {
            string[] surveyNames = new string[surveys.Count];
            for (int i = 0; i < surveyNames.Length; i++)
            {
                surveyNames[i] = SurveyNameFormatter.FormatSurveyName(surveys[i].Id, surveys[i].Name); //String.Format("{0} ({1})", surveys[i].Name, surveys[i].Id);
            }

            SurveyList.BindSurveyList(surveyNames);
        }

        /// <summary>
        /// Binds survey languages list with specified values.
        /// </summary>
        /// <param name="languages">Languages to bind.</param>
        internal void BindSurveyLanguageList(LanguageCollection languages)
        {
            List<string> langs = new List<string>();

            foreach (Language lang in languages)
            {
                langs.Add(lang.Name);
            }

            MainForm.BindSurveyLanguageList(langs.ToArray());
        }

        /// <summary>
        /// Gets redo questions list from Confirmit Web service and binds it 
        /// to main form.
        /// </summary>
        internal void UpdateAndBindRedoList()
        {
            if (CurrentInterviewProperties != null &&
                !String.IsNullOrEmpty(CurrentInterviewProperties.SecurityId))
            {
                Cursor old = MainForm.Cursor;
                MainForm.Cursor = Cursors.WaitCursor;

                try
                {
                    StoredRedoQuestions = _catiServiceManager.GetInterviewHistory(
                        CurrentInterviewProperties.SurveyId,
                        new Uri(CurrentInterviewProperties.InterviewURL).Query,
                        CurrentSurveyLanguageId.HasValue ? CurrentSurveyLanguageId.Value : 0
                    );

                }
                catch (Exception ex)
                {
                    _logger.Log(ex);
                    StoredRedoQuestions = new QuestionHistoryCollection();
                }
                finally
                {
                    MainForm.Cursor = old;
                }

                BindRedoList(StoredRedoQuestions);
            }
        }

        /// <summary>
        /// Updates given survey languages list and binds it to UI.
        /// </summary>
        /// <param name="surveyId"></param>
        /// <param name="languageVariableValue"></param>
        internal void UpdateAndBindSurveyLanguages(string surveyId, int? languageVariableValue)
        {
            try
            {
                if (PreviousSurveyId != surveyId)
                {
                    StoredSurveyLanguages = _catiServiceManager.GetSurveyLanguages(surveyId);
                    BindSurveyLanguageList(StoredSurveyLanguages);
                    PreviousSurveyId = surveyId;
                }

                if (languageVariableValue != null)
                {
                    CurrentSurveyLanguageId = languageVariableValue;
                }

                if (CurrentSurveyLanguageId.HasValue &&
                    StoredSurveyLanguages.ContainsLanguage(CurrentSurveyLanguageId.Value))
                {
                    // survey contains previous selected language, so we should choose it in UI
                    MainForm.SelectedSurveyLanguage = StoredSurveyLanguages.IndexOf(CurrentSurveyLanguageId.Value);
                }
                else
                {
                    // survey doesn't contain previous selected language, so we should choose default language
                    // for this survey
                    Language defaultLang = StoredSurveyLanguages.GetDefaultLanguage();
                    if (defaultLang != null)
                    {
                        CurrentSurveyLanguageId = defaultLang.ID;
                        MainForm.SelectedSurveyLanguage = StoredSurveyLanguages.IndexOf(defaultLang);
                    }
                    else
                    {
                        // there is no default language for survey. This situation shouldn't be. In any case
                        // we select first language.
                        _logger.Log(Strings.ResourceManager.GetString(
                            "Log_NoDefaultLanguageForSurvey",
                            surveyId
                            ), TraceEventType.Error);

                        CurrentSurveyLanguageId = StoredSurveyLanguages[0].ID;
                        MainForm.SelectedSurveyLanguage = 0;
                    }
                }
            }
            catch (Exception /*ex*/)
            {
                // suppress any messages to user and continue start interview with default language
                StoredSurveyLanguages = new LanguageCollection();
                CurrentSurveyLanguageId = null;
                BindSurveyLanguageList(StoredSurveyLanguages);
            }
        }

        /// <summary>
        /// Do call to WS.SetPendingLogout
        /// </summary>
        internal void SetPendingLogout(bool logout)
        {
            try
            {
                _catiServiceManager.SetPendingLogout(logout);

                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.PendingLogoutMessage,
                        State = new PendingLogoutStateData
                        {
                            ControlName = "MainForm",
                            Enabled = logout
                        }
                    },
                    UserPassport.Instance.MonitoringIdentity
                );

                 EnablePendingBreakToolbarButton(!logout);
            }
            catch (Exception ex)
            {
                EnablePendingBreakToolbarButton(!MainForm.IsLogoutAfterFinishingEnabled);

                _logger.Log(ex);
            }
        }

        private void SetPendingBreakWithShortCut()
        {
            if (BreakTypes.Count == 1)
            {
                MainForm.ClickPendingBreak();
            }
            else
            {
                MainForm.ShowPendingBreakDropdown();
            }
        }

        /// <summary>
        /// Notifies backend that user is going on a break.       
        /// </summary>
        /// <remarks>
        /// If Pending logout has been already previously checked, Pending break should be checked.
        /// If there are no active interview begin to wait for 'Break' state.
        /// </remarks>
        private void SetPendingBreak()
        {
            var isChecked = MainForm.IsPendingBreakChecked;

            var breakType = isChecked ? BreakTypes[MainForm.SelectedBreakIndex.Value].Id : (int?) null;

            try
            {
                if (_catiServiceManager.SetPendingBreakStatus(isChecked, breakType))
                {
                    EnablePendingLogoutToolbarButton(!isChecked);

                    if (isChecked && CurrentInterviewProperties == null)
                    {
                        WaitBreakStateAndShowOnABreakDialog();
                    }
                }
                else
                {
                    UncheckPendingBreak();
                }
            }
            catch (Exception)
            {
                UncheckPendingBreak();
            }

            OnStateChanged(new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.PendingBreakMessage,
                State = new PendingBreakStateData { ControlName = "MainForm", Enabled = MainForm.IsPendingBreakChecked }
            },
                    UserPassport.Instance.MonitoringIdentity);
        }

        private void UncheckPendingBreak()
        {
            MainForm.IsPendingBreakChecked = false;
            MainForm.SelectedBreakIndex = null;
            MainForm.UpdatePendingBreakControls(true);
            EnablePendingLogoutToolbarButton(true);
        }

        /// <summary>
        /// Binds redo list with values taken from Confirmit Web service.
        /// </summary>
        /// <param name="questions">Collection of questions to bind.</param>
        internal void BindRedoList(QuestionHistoryCollection questions)
        {
            if (questions == null)
            {
                throw new ArgumentNullException("questions");
            }

            var names = new string[questions.Count];
            for (var i = 0; i < names.Length; i++)
            {
                names[i] =
                    String.IsNullOrEmpty(questions[i].QuestionName) ? questions[i].QuestionId : questions[i].QuestionName;
            }

            MainForm.BindRedoList(names);
        }

        /// <summary>
        /// Redo question selected by user.
        /// </summary>
        internal void RedoQuestion()
        {
            if (MainForm.SelectedRedoQuestion >= 0 &&
                CurrentInterviewProperties != null)
            {
                try
                {
                    QuestionHistory question = StoredRedoQuestions[MainForm.SelectedRedoQuestion];

                    OnStateChanged(
                        new StateChangedEventArgs
                        {
                            MessageType = MonitoringMessageTypes.RedoQuestionMessage,
                            State = new RedoQuestionStateData
                            {
                                ControlName = "MainForm",
                                QuestionId = question.QuestionId
                            }
                        },
                        UserPassport.Instance.MonitoringIdentity
                    );

                    InterviewBrowserPresenter.Navigate(
                        GenerateQuestionRedoUrl(question, CurrentInterviewProperties)
                    );
                }
                catch (Exception ex)
                {
                    _logger.Log(ex);
                    _alerter.Alert(
                        LocalizationManager.Instance.GetString("Error_QuestionCouldntBeRedone"),
                        LocalizationManager.Instance.GetString("Alerter_Caption"),
                        MessageTypes.Error
                    );
                }
            }
        }

        /// <summary>
        /// Generates url which is used to open redo page for specific question.
        /// </summary>
        /// <param name="question">Question history entry.</param>
        /// <param name="interviewProperties">Interview properties.</param>
        /// <returns>Valid uri.</returns>
        internal Uri GenerateQuestionRedoUrl(QuestionHistory question, InterviewProperties interviewProperties)
        {
            UriBuilder result = new UriBuilder(interviewProperties.InterviewURL);
            if (question.UrlQuery.Length > 0)
            {
                // remove leading '?' in query string
                result.Query = question.UrlQuery.Remove(0, 1);
            }

            return result.Uri;
        }

        /// <summary>
        /// Starts monitoring.
        /// </summary>
        private void StartMonitoring()
        {
            SendOrPostCallback callback = delegate
            {
                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.MonitoringInitialMessage,
                        State = GetState()
                    },
                    UserPassport.Instance.MonitoringIdentity
                );

                InterviewBrowserPresenter.CheckBrowserFeatures();
            };

            MainForm.SynchronizationContext.Post(callback, null);
        }

        /// <summary>
        /// Stops monitoring.
        /// <remarks>
        /// This method is called during log out finishing.
        /// We should send monitoring MonitoringEndMessage message in order to
        /// stop deferred monitoring. This message is ignored in a case of 
        /// live monitoring.
        /// </remarks>
        /// </summary>
        private void StopMonitoring()
        {
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.MonitoringEndMessage,
                    State = null
                },
                UserPassport.Instance.MonitoringIdentity);
        }

        /// <summary>
        /// Starts deferred monitoring session.
        /// Function creates new deferred session identifier
        /// and sends InterviewStartMessage.
        /// </summary>
        internal void StartDeferredMonitoring()
        {
            var identity = new DeferredIdentity
            {
                DeferredRecordId = CurrentInterviewProperties.DeferredRecordId,
                InterviewId = CurrentInterviewProperties.InterviewId,
                SurveyId = CurrentInterviewProperties.ProjectId
            };

            UserPassport.Instance.MonitoringIdentity.DeferredIdentity = identity;

            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.InterviewStartMessage,
                    State = new InterviewStartStateData
                    {
                        InterviewID = CurrentInterviewProperties.InterviewId,
                        IsJumpingSupported = true
                    }
                },
                UserPassport.Instance.MonitoringIdentity
            );
        }

        /// <summary>
        /// Stops deferred monitoring session.
        /// </summary>
        private void StopDeferredMonitoring()
        {
            UserPassport.Instance.MonitoringIdentity.DeferredIdentity = null;
        }

        /// <summary>
        /// Fires StateChanged event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        /// <param name="sessionId">Session id.</param>
        internal void OnStateChanged(StateChangedEventArgs e, MonitoringIdentity sessionId)
        {
            if (StateChanged != null)
            {
                StateChanged(this, e, sessionId);
            }
        }

        /// <summary>
        /// Initializes listener which sends log to Backend service.
        /// </summary>
        public void InitServerLogging()
        {
            if (_consoleProperties.EnableServerLog)
            {
                Logger.InitWsListener(
                    UserPassport.Instance.CompanyAlias,
                    UserPassport.Instance.Properties == null ? new byte[0] : UserPassport.Instance.Properties.EncryptionKey,
                    ClientErrorSource.ConsoleError,
                    new ConsoleInfoProvider(UserPassport.Instance, this, ClientSettings.Default.StationId, _consoleDescriptionProvider),
                    new LoginPasswordAuthenticationDataProvider(
                        UserPassport.Instance.UserName,
                        UserPassport.Instance.Password,
                        UserPassport.Instance.CompanyId),
                    new MessageHeaderAccessor(),
                    new CatiConsoleErrorSender());
            }
        }

        /// <summary>
        /// Resizes "Survey name" column in survey list control in order that 
        /// column's width become same as width of survey list.
        /// </summary>
        private void ResizeSurveyColumnWidth()
        {
            SurveyList.SetSurveyColumnWidth(SurveyList.SurveyListClientSize.Width);
        }

        /// <summary>
        /// Checks if user accepted license agreements.
        /// </summary>
        /// <returns>true, if user accepted; otherwise false.</returns>
        private bool CheckLicenseAgreements()
        {
            bool result = true;
            if (!ApplicationManager.HasLicenseAgreementBeenShown)
            {
                using (IViewLicenseForm licenseForm = (IViewLicenseForm)ViewFactory.GetView(FormViews.LincenseView))
                {
                    licenseForm.DocumentText = CommonResources.license;
                    licenseForm.Localize(LocalizationManager.Instance);
                    MainForm.ShowBlankForm();
                    if (DialogResult.OK == licenseForm.Show())
                    {
                        try
                        {
                            ApplicationManager.SaveLicenseAgreement();
                        }
                        catch (Exception ex)
                        {
                            _logger.Log(ex);
                            result = false;
                        }
                    }
                    else
                    {
                        result = false;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Updates current person mode, 
        /// uses when interviewer is allowed to choose one        
        /// </summary>
        /// <param name="mode">PersonMode</param>
        private void UpdatePersonMode(AgentTaskChoiceMode mode)
        {
            UserPassport.Instance.Properties.UpdateUserAssignmentMode(mode);

            try
            {
                _catiServiceManager.UpdatePersonMode(mode);
            }
            catch (Exception ex)
            {
                RestartAfterCommunicationError(ex);
            }
        }

        /// <summary>
        /// Checks all search parameters for matching filter parameter type and specified filter value
        /// </summary>
        /// <param name="list">List of SearchParameters</param>        
        /// <param name="errorParameter">Parameter where mismatching has been found</param>
        /// <returns>Returns first problem column name</returns>
        private bool CheckFilter(IEnumerable<ConsoleSearchParameter> list, out ConsoleSearchParameter errorParameter)
        {
            errorParameter = null;

            foreach (ConsoleSearchParameter parameter in list)
            {
                if (parameter == null) return false;

                var type = Type.GetType(parameter.ColumnTypeName);
                if (type == null)
                {
                    return false;
                }

                TypeConverter converter = TypeDescriptor.GetConverter(type);

                try
                {
                    converter.ConvertFrom(parameter.Value);
                }
                catch
                {
                    errorParameter = parameter;

                    return false;
                }

                if (DataValidationManager.IsStringValid(parameter.Value) == false)
                {
                    errorParameter = parameter;

                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Sorts StoredInterviews list by given column.
        /// </summary>
        /// <param name="columnIndex">Sort column index.</param>
        private void SortInterviewList(int columnIndex)
        {
            StringBuilder order = new StringBuilder(StoredInterviews.Columns[columnIndex].ColumnName);
            if (SurveyList.SortOrder == SortOrder.Ascending)
            {
                order.Append(" ASC");
            }
            else
            {
                order.Append(" DESC");
            }
            DataRow[] rows = StoredInterviews.Select(String.Empty, order.ToString());
            DataTable newData = StoredInterviews.Clone();
            foreach (DataRow row in rows)
            {
                newData.ImportRow(row);
            }
            StoredInterviews = newData;
        }

        private void ShowCheckSpellingForm()
        {
            if (CurrentSurveyLanguageId.HasValue)
            {
                SpellCheckPresenter = new PresenterSpellChecker((ISpellCheckerView)ViewFactory.GetView(FormViews.SpellCheckerView),
                                                                new SpellCheckService(CurrentSurveyLanguageId.Value),
                                                                _interviewBrowserPresenter.GetPageTextBlocks());

                SpellCheckPresenter.SaveOnFormClosed += SpellCheckPresenter_SaveOnFormClosed;

                OnStateChanged(
                     new StateChangedEventArgs { MessageType = MonitoringMessageTypes.CheckSpellingFormShownMessage },
                     UserPassport.Instance.MonitoringIdentity);

                SpellCheckPresenter.ShowDialog(MainForm);

                OnStateChanged(
                      new StateChangedEventArgs
                      {
                          MessageType = MonitoringMessageTypes.CheckSpellingFormClosedMessage,
                          State = new CheckSpellingFormClosedStateData { ConsoleState = PresenterInterview.GetConsoleState() }
                      },
                      UserPassport.Instance.MonitoringIdentity);
            }
        }

        /// <summary>
        /// Method begins work.
        /// </summary>
        /// <remarks>
        /// In the automatic mode should be called at once
        /// In the survey assignment mode should be called after survey selected
        /// In the manual mode should be called after interview selected
        /// </remarks>
        public void StartProcess()
        {
            IsFirstInterviewTime = false;

            if (IsDialerInSystem &&
                (UserPassport.Instance.Properties.AlreadyLoggedIn == false || UserPassport.Instance.Properties.IsLoggedToDialer() == false))
            {
                LoginToDialer(CurrentSurveyId);
            }
            else
            {
                StartInterviewProcess();
            }
        }

        /// <summary>
        /// Begin works after connect to dialer is finished
        /// </summary>
        /// <remarks>
        /// It is called from LoggedToDialerInEvent event handler
        /// </remarks>
        public void StartInterviewProcess()
        {
            try
            {
                _catiServiceManager.StartInterview(CurrentSurveyId, CurrentInterviewId);
            }
            catch (ManualUserInPredictiveModeException)
            {
                ProcessPredictiveDialingIsUnAvailableInManualModeException();
            }
            catch (PredictiveSurveyWithoutDialerException)
            {
                ProcessPredictiveSurveyWithoutDialerException();
            }
            catch (Exception /*ex*/)
            {
                ForcedLogout();
                return;
            }

            StartInterviewCycle();

            OnStateChanged(
                  new StateChangedEventArgs
                  {
                      MessageType = MonitoringMessageTypes.GettingInterviewStartMessage
                  },
                  UserPassport.Instance.MonitoringIdentity
            );
        }

        /// <summary>
        /// Start work when 
        /// user has been already working in system
        /// </summary>
        public void ContinuePendingProcess()
        {
            ProcessState state;

            try
            {
                state = _catiServiceHelper.GetState();
                if (state == null)
                {
                    // in a case of any problem, reported during GetState()
                    // null is returned. So we should do nothing in such case.
                    return;
                }
            }
            catch (Exception /*ex*/)
            {
                ForcedLogout();
                return;
            }

            if (state.interviewerLoginState == LoginState.LOGGED_IN ||
                state.interviewerLoginState == LoginState.PENDING_LOGOUT ||
                state.interviewerLoginState == LoginState.PENDING_BREAK)
            {
                _isPredictiveMode = UserPassport.Instance.Properties.CheckPredictiveModeAfterAbnornalTermination();

                if (state.InterviewState == InterviewState.SELECTING)
                {
                    // user was interrupted during selection process. So we should start selection again.
                    switch (UserAssignmentMode)
                    {
                        case AgentTaskChoiceMode.CampaignAssignment:
                            _taskChoiceRouter.StartSurveyAssignmentMode();
                            break;
                        case AgentTaskChoiceMode.Manual:
                            _taskChoiceRouter.StartManualMode();
                            break;
                        case AgentTaskChoiceMode.Automatic:
                            StartInterviewCycle();
                            break;
                        default:
                            throw new NotSupportedException(
                                Strings.ResourceManager.GetString("Exception_UnsupportedTaskChoice", UserAssignmentMode));
                    }
                }
                else
                {
                    _currentSurveyId = state.InterviewProperties.SurveyId;
                    _currentInterviewId = state.InterviewProperties.InterviewId;

                    // user was interrupted during interview or openend review. so we should
                    // start process again.
                    if (Uri.IsWellFormedUriString(state.InterviewProperties.InterviewURL, UriKind.Absolute) &&
                        (state.InterviewState == InterviewState.INTERVIEWING ||
                         state.InterviewState == InterviewState.OUTGOING_TRANSFER ||
                        state.InterviewState == InterviewState.OPENEND_REVIEW)
                    )
                    {
                        _alerter.Alert(
                            LocalizationManager.Instance.GetString("Message_ContinueInterruptedProcess"),
                            LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                            MessageTypes.Information
                        );

                        switch (state.InterviewState)
                        {
                            case InterviewState.INTERVIEWING:
                                StartInterviewing(state.InterviewProperties);
                                break;
                            case InterviewState.OUTGOING_TRANSFER:
                                _currentTransferOptions = state.TransferOptions;
                                StartInterviewing(state.InterviewProperties);
                                StartOutgoingTransfer(state.TransferOptions, state.TransferState);
                                break;
                            case InterviewState.OPENEND_REVIEW:
                            default:
                                StartReviewing(state.InterviewProperties);
                                break;
                        }
                    }
                    else
                    {
                        StartInterviewCycle();
                    }
                }
            }
            else if (state.interviewerLoginState == LoginState.BREAK)
            {
                ShowOnABreakControl();
            }
            else
            {
                _logger.Log(Strings.Log_NOT_LOGGED_IN_StateDuringContinueProcessAfterLogin, TraceEventType.Error);
                ForcedLogout();
            }
        }

        /// <summary>
        /// Method is responsible for interviewing cycle
        /// </summary>
        /// <remarks> </remarks>
        internal void StartInterviewCycle()
        {
            StartInterviewCycleTimer();
        }

        internal bool IsInterviewCycleStarted()
        {
            return _interviewCycleTimer != null;
        }

        /// <summary>
        /// Function gets state using WS.GetState
        /// And analyse delivered state
        /// </summary>
        internal void DoGetStateAndAnalyse()
        {
            ProcessState state;

            try
            {
                state = _catiServiceHelper.GetState();

                GetStateWsErrorElapsed.Reset();

                if (state == null)
                {
                    // in a case of any problem, reported during GetState()
                    // null is returned. So we should do nothing in such case.
                    return;
                }
            }
            catch (Exception /*ex*/)
            {
                MainForm.ShowProcessControl(
                    LocalizationManager.Instance.GetString("Message_ProcessControl_GettingInterview"),
                    IsLogoutToolbarButtonEnabled,
                    IsTakeBreakToolbarButtonEnabled
                    );

                if (GetStateWsErrorElapsed.IsRunning == false)
                {
                    GetStateWsErrorElapsed.Start();
                }
                else if (DoesGetStateWsErrorTimeoutExpire())
                {
                    ForcedLogout();
                }

                return;
            }

            InterviewState previousState = PreviousInterviewState;
            PreviousInterviewState = state.InterviewState;
            var interviewProperties = state.InterviewProperties;

            if (interviewProperties.IsNewSurvey && (interviewProperties.ProjectId > 0))
            {
                _currentSurveyId = interviewProperties.SurveyId;
            }

            if (state.interviewerLoginState == LoginState.LOGGED_IN ||
               ( state.interviewerLoginState == LoginState.PENDING_LOGOUT ||
                 state.interviewerLoginState == LoginState.PENDING_BREAK ) && 
               ( state.InterviewState == InterviewState.INTERVIEWING ||
                 state.InterviewState == InterviewState.OUTGOING_TRANSFER ||
                 state.InterviewState == InterviewState.INCOMING_TRANSFER))
            { 
                if (state.InterviewState == InterviewState.INTERVIEWING)
                {
                    if (Uri.IsWellFormedUriString(interviewProperties.InterviewURL, UriKind.Absolute))
                    {
                        StopInterviewCycleTimer();
                        StartInterviewing(interviewProperties);
                    }
                    else
                    {
                        MainForm.ShowProcessControl(
                            StringHelper.GetStringFromEnum(state.InterviewState),
                            IsLogoutToolbarButtonEnabled,
                            IsTakeBreakToolbarButtonEnabled
                            );
                    }
                }
                else if (state.InterviewState == InterviewState.SELECTING)
                {
                    StopInterviewCycleTimer();

                    if (UserAssignmentMode == AgentTaskChoiceMode.Manual)
                    {
                        if (state.CallOutcome == CallOutcome.Blacklist)
                        {
                            _alerter.Alert(
                                        LocalizationManager.Instance.GetString("Message_Blacklist"),
                                        LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                                        MessageTypes.Information
                                        );
                        }
                        _taskChoiceRouter.StartManualMode();
                    }
                    else
                    {
                        _logger.Log(
                                Strings.ResourceManager.GetString(
                                "Log_IncorrectStateForTaskChoice",
                                state.InterviewState,
                                UserAssignmentMode
                                ),
                                TraceEventType.Error
                        );

                        _alerter.Alert(
                            LocalizationManager.Instance.GetString("Alerter_InterviewStateIsNotAllowedConsoleWillBeRestarted"),
                            LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                            MessageTypes.Information
                        );

                        Logout(true, false);
                    }
                }
                else if (state.InterviewState == InterviewState.WAITING)
                {
                    if ((IsPredictiveMode && IsDialerInSystem) == false)
                    {
                        //In Predictive case we shouldn't show timeout form because dialer can connect to respondent 
                        //while user is staying in the dialog. And if interviewer selects 'Cancel' connect will be broken.
                        if (previousState != InterviewState.WAITING)
                        {
                            // first WAITING occurance, start timer
                            RestartGetStateCycleElapsed();
                        }
                        else
                        {
                            // check if WAITING timer expired
                            if (DoesWaitingTimeoutExpire())
                            {
                                if (_alerter.AlertRetryConfirmation(
                                    LocalizationManager.Instance.GetString("Alerter_WaitingRetryOrLogout"),
                                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption")) == DialogResult.Retry)
                                {
                                    RestartGetStateCycleElapsed();
                                }
                                else
                                {
                                    Logout(true, false);
                                    return;
                                }
                            }
                        }

                        if (state.CallOutcome == CallOutcome.Blacklist)
                        {
                            if (UserAssignmentMode == AgentTaskChoiceMode.Automatic || UserAssignmentMode == AgentTaskChoiceMode.CampaignAssignment)
                            {
                                try
                                {
                                    _catiServiceManager.StartInterview(CurrentSurveyId, CurrentInterviewId);
                                }
                                // ReSharper disable once EmptyGeneralCatchClause
                                catch
                                {
                                    // we suppress any exception and continue cycle
                                }
                            }
                        }
                    }

                    MainForm.ShowProcessControl(
                        StringHelper.GetStringFromEnum(state.InterviewState),
                        IsLogoutToolbarButtonEnabled,
                        IsTakeBreakToolbarButtonEnabled
                        );
                }
                else if (state.InterviewState == InterviewState.NO_CALLS)
                {
                    if (previousState != InterviewState.NO_CALLS)
                    {
                        // first NO_CALLS occurance, start timer
                        RestartGetStateCycleElapsed();
                    }
                    else
                    {
                        // check if NO_CALLS timer expired
                        if (DoesNoCallsTimeoutExpire())
                        {
                            if (IsAutoPilotEnabled)
                            {
                                Logout(false, false);
                                return;
                            }

                            if (_alerter.AlertRetryConfirmation(
                                LocalizationManager.Instance.GetString("Alerter_NoCallsRetryOrLogout"),
                                LocalizationManager.Instance.GetString("Alerter_ConsoleCaption")) == DialogResult.Retry)
                            {
                                RestartGetStateCycleElapsed();
                            }
                            else
                            {
                                Logout(true, false);
                                return;
                            }
                        }
                    }

                    if (UserAssignmentMode == AgentTaskChoiceMode.Automatic ||
                        UserAssignmentMode == AgentTaskChoiceMode.CampaignAssignment)
                    {
                        try
                        {
                            _catiServiceManager.StartInterview(CurrentSurveyId, CurrentInterviewId);
                        }
                        // ReSharper disable once EmptyGeneralCatchClause
                        catch
                        {
                            // we suppress any exception and continue cycle
                        }
                    }
                    else
                    {
                        _logger.Log(Strings.Log_NOCALLS_StateInManualMode, TraceEventType.Error);
                        ForcedLogout();
                        return;
                    }
                    MainForm.ShowProcessControl(
                        StringHelper.GetStringFromEnum(state.InterviewState),
                        IsLogoutToolbarButtonEnabled,
                        IsTakeBreakToolbarButtonEnabled
                        );
                }
                else if (state.InterviewState == InterviewState.OUTGOING_TRANSFER)
                {
                    if (CurrentInterviewProperties == null)
                    {
                        StartInterviewing(state.InterviewProperties);
                    }
                    StartOutgoingTransfer(state.TransferOptions, state.TransferState);
                }
                else if (state.InterviewState == InterviewState.INCOMING_TRANSFER)
                {
                    StartIncomingTransfer(interviewProperties, state);
                }
                else
                {
                    MainForm.ShowProcessControl(
                        StringHelper.GetStringFromEnum(state.InterviewState),
                        IsLogoutToolbarButtonEnabled,
                        IsTakeBreakToolbarButtonEnabled);
                }
            }
            else if (state.interviewerLoginState == LoginState.BREAK)
            {
                StopInterviewCycleTimer();
                ShowOnABreakControl();
            }
            else if (state.interviewerLoginState == LoginState.NOT_LOGGED_IN)
            {
                CloseWarmTransferWindowIfNeeded();
                LogoutFromGetState();
            }            
            else
            {
                _logger.Log(string.Format(Strings.Log_IncorrectStateDuringGetStateOperation, state), TraceEventType.Error);
                MainForm.ShowProcessControl(
                    LocalizationManager.Instance.GetString("Message_ProcessControl_GettingInterview"),
                    IsLogoutToolbarButtonEnabled,
                    IsTakeBreakToolbarButtonEnabled
                    );
            }
        }

        private void CloseWarmTransferWindowIfNeeded(bool enableAllExceptRedial = true)
        {
            if (_warmTransferForm != null)
            {
                StopInterviewCycleTimer();
                _warmTransferForm.CloseForm();

                MainForm.EnableTelephonyToolbar(enableAllExceptRedial, true, GetToolbarState());
            }

            _warmTransferForm = null;
            _currentTransferOptions = null;
        }

        private void CreateWarmTransferForm()
        {
            if (_warmTransferForm != null)
            {
                return;
            }
            
            _warmTransferForm = (IViewWarmTransferForm)ViewFactory.GetView(FormViews.WarmTransferView);
            _warmTransferForm.Localize(LocalizationManager.Instance);

            _warmTransferForm.OnCompleteClick += WarmTransferForm_OnCompleteClick;
            _warmTransferForm.OnCancelClick += WarmTransferForm_OnCancelClick;
            _warmTransferForm.OnMergeClick += WarmTransferForm_OnMergeClick;
            _warmTransferForm.OnTalkPrivatelyWithRespondentClick += WarmTransferForm_OnTalkPrivatelyWithRespondentClick;
            _warmTransferForm.OnTalkPrivatelyWithTransferTargetClick += WarmTransferForm_OnTalkPrivatelyWithTransferTargetClick;

            MainForm.EnableTelephonyToolbar(false, false, GetToolbarState());
        }

        /// <summary>
        /// Calls GetState() and checks if the state is logged out (or logging out)
        /// </summary>
        /// <returns></returns>
        private bool IsLoggedOutState()
        {
            ProcessState state = null;

            CatiServiceRetryManager.Invoke(counter => _catiServiceHelper.GetState(counter, out state), false);

            if (state == null)
            {
                // in a case of any problem, reported during GetState() null is returned.
                throw new InternalErrorException("GetState result is [null]");
            }

            return (
                (state.interviewerLoginState == LoginState.PENDING_LOGOUT) ||
                (state.interviewerLoginState == LoginState.LOGGING_OUT) ||
                (state.interviewerLoginState == LoginState.NOT_LOGGED_IN));
        }

        /// <summary>
        /// Process interviewer logout from console while it occurs during GetState calling
        /// </summary>
        private void LogoutFromGetState()
        {
            if (LoginForm.IsLoggedIn)
            {
                _alerter.Alert(LocalizationManager.Instance.GetString("Alerter_YouWasLoggedOutBySystem"),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                    MessageTypes.Information
                );
            }

            ConfirmLogout();
            FinishLogout();
            RestartApplication();
        }

        /// <summary>
        /// Returns true, if WAITING timeout has expired.
        /// </summary>
        /// <returns>true, if timeout has expired; otherwise false.</returns>
        private bool DoesWaitingTimeoutExpire()
        {
            return (_getStateCycleElapsed.ElapsedMilliseconds / 1000 > Properties.Settings.Default.WaitingTimeout);
        }

        /// <summary>
        /// Returns true, if we receive NO_CALLS status from Cati WS more than 
        /// defined timeout value (now 1 minute).
        /// </summary>
        /// <returns>true, if timeout has expired; ohterwise false.</returns>
        internal bool DoesNoCallsTimeoutExpire()
        {
            return (_getStateCycleElapsed.ElapsedMilliseconds / 1000 > UserPassport.Instance.Properties.ConsoleProperties.NoCallsTimeout);
        }

        /// <summary>
        /// Returns true, if calls to web service have finished with exception
        /// during 'GetStateWSErrorTimeout' timeout.        
        /// </summary>
        /// <returns>true, if timeout has expired; ohterwise false.</returns>
        internal bool DoesGetStateWsErrorTimeoutExpire()
        {
            return (GetStateWsErrorElapsed.ElapsedMilliseconds / 1000 > _consoleProperties.GetStateWsErrorTimeout);
        }

        /// <summary>
        /// Method is responsible for login to dialer
        /// Shows form for extension number entering,
        /// Calls WS.LoginToDialer,
        /// Shows process screen
        /// </summary>
        /// <param name="surveyId"></param>
        internal void LoginToDialer(string surveyId)
        {
            if (_presenterTelephony.IsCustomDialerUsed)
            {
                StartLoginToDialer(surveyId);
            }
            else
            {
                bool extensionNumberInputEnabled = true;

                if (HasStationExtensionNumber)
                {
                    extensionNumberInputEnabled = false;
                    _presenterTelephony.ExtensionNumber = String.Empty;
                    _extensionNumberForm.ExtensionNumber = ClientSettings.Default.StationId;
                }
                else
                {
                    if (IsAutoPilotEnabled)
                    {
                        _presenterTelephony.ExtensionNumber = AutoPilotArguments.ExtensionNumber;
                    }

                    if (new PhoneNumberValidator().Validate(ClientSettings.Default.ExtensionNumber))
                    {
                        _extensionNumberForm.ExtensionNumber = ClientSettings.Default.ExtensionNumber;
                    }
                    else
                    {
                        _extensionNumberForm.ExtensionNumber = String.Empty;
                        SetExtensionNumber();
                    }
                }

                _extensionNumberForm.ExtensionNumberInputEnabled = extensionNumberInputEnabled;

                _extensionNumberForm.Localize(LocalizationManager.Instance);

                LoginToDiallerResult result = IsAutoPilotEnabled
                        ? LoginToDiallerResult.LoginToDialler
                        : MainForm.ShowExtensionNumberForm();

                switch (result)
                {
                    case LoginToDiallerResult.LoginToDialler:
                        StartLoginToDialer(surveyId);
                        break;
                    case LoginToDiallerResult.SkipLoginToDialler:
                        RefuseLoginToDialer();
                        break;
                    case LoginToDiallerResult.Logout:
                        Logout(true, false);
                        break;
                    default:
                        _logger.Log(
                            Strings.ResourceManager.GetString("Log_UnsupportedLoginToDialerResult", result),
                            TraceEventType.Error);
                        RefuseLoginToDialer();
                        break;
                }
            }
        }

        /// <summary>
        /// Refuses log in to dialer and starts interview without dialer in system.
        /// </summary>
        private void RefuseLoginToDialer()
        {
            IsDialerInSystem = false;
            StartInterviewProcess();
        }

        /// <summary>
        /// Starts log in to dialer process for given survey.
        /// </summary>
        /// <param name="surveyId">Confirmit survey identifier (e.g. 'p00000000').</param>
        private void StartLoginToDialer(string surveyId)
        {
            MainForm.ShowProcessControl(LocalizationManager.Instance.GetString("Message_ProcessControl_LoginToDialer"), false, false);
            _presenterTelephony.LoginToDialer(surveyId, out _isPredictiveMode);
        }

        private void StartIncomingTransfer(InterviewProperties interviewProperties, ProcessState state)
        {
            CurrentInterviewProperties = interviewProperties;

            MainForm.ShowInternalTransferControl(
                LocalizationManager.Instance,
                state.InterviewProperties.SurveyName,
                state.TransferState.Respondent.Resource,
                state.TransferState.Initiator.Resource,
                state.InterviewProperties.InterviewId.ToString());
        }

        private void StartOutgoingTransfer(TransferOptions option, ConsoleTransferState state)
        {
            CreateWarmTransferForm();

            _warmTransferForm.ShowForm(state);

            if(!IsInterviewCycleStarted())
                StartInterviewCycle();

            if (option.AllowInterviewing)
            {
                MainForm.ShowInterviewPageControl(GetToolbarState());
            }
            else
            {
                MainForm.ShowProcessControl(LocalizationManager.Instance.GetString("Message_ProcessControl_Transfer"));
            }
        }

        /// <summary>
        /// Starts interviewing.
        /// </summary>
        /// <param name="interviewProp">Contains information about current interview</param>
        public void StartInterviewing(InterviewProperties interviewProp)
        {
            _waitForLogoutComplete = false;

            if (interviewProp == null)
            {
                _logger.Log(
                    Strings.ResourceManager.GetString(
                        "Log_ArgumentNullInMethod",
                        "interviewProperties",
                        "PresenterMainForm.StartInterviewing"
                    ),
                    TraceEventType.Error
                );
                ForcedLogout();
                return;
            }

            UpdateAndBindSurveyLanguages(interviewProp.SurveyId, interviewProp.LanguageVariableValue);

            CurrentInterviewProperties = interviewProp;
            CurrentConsoleState = ConsoleState.Interviewing;

            if (interviewProp.IsNewSurvey)
            {
                ShowSurveySwitchedNotification();
            }

            InitServerLogging();

            StartDeferredMonitoring();

            MainForm.ShowInterviewPageControl(GetToolbarState());

            SpecifyMainFormStyle(interviewProp);

            if (IsAutoPilotEnabled == false)
            {
                PresenterInterview.StartInterview(CurrentInterviewProperties, CurrentSurveyLanguageId);
            }
            else
            {
                try
                {
                    PresenterInterview.StartInterviewAutomatically(CurrentInterviewProperties, CurrentSurveyLanguageId);
                }
                catch (Exception ex)
                {
                    _logger.Log(ex.ToString(), TraceEventType.Error);
                    ConfirmLogout();
                    FinishLogout();
                    MainForm.CloseForm();
                }
            }
        }

        private string GetDefaultTitle()
        {
            return LocalizationManager.Instance.GetString("MainForm_Caption");
        }

        private void SpecifyMainFormStyle(InterviewProperties interviewProp)
        {
            var title = GetDefaultTitle();
            var color = MainForm.DefaultControlColor;

            if (interviewProp.IsInboundCall)
            {
                color = Color.YellowGreen;
            }

            if (interviewProp.IsTestMode)
            {
                title = LocalizationManager.Instance.GetString("MainForm_Caption_TestMode");
                color = Color.Gold;
            }

            MainForm.SpecifyMainFormStyle(title, color, interviewProp.IsInboundCall, interviewProp.IsTestMode);
            PresenterInterview.HighlightEnterZone(color);
        }

        /// <summary>
        /// Starts reviewing. 
        /// Method takes given interview properties, sets it's value to current
        /// interview properties and starts reviewing process.
        /// </summary>
        /// <param name="interviewProperties"></param>
        public void StartReviewing(InterviewProperties interviewProperties)
        {
            if (interviewProperties == null)
            {
                _logger.Log(
                    Strings.ResourceManager.GetString(
                        "Log_ArgumentNullInMethod",
                        "interviewProperties",
                        "PresenterMainForm.StartReviewing"
                    ),
                    TraceEventType.Error
                );
                ForcedLogout();
                return;
            }

            try
            {
                // sends review starting notification to Fusion
                _catiServiceManager.SendFusionReviewFlag();
                CloseWarmTransferWindowIfNeeded();
            }
            catch (Exception ex)
            {
                RestartAfterCommunicationError(ex);
                return;
            }

            CurrentInterviewProperties = interviewProperties;
            CurrentConsoleState = ConsoleState.Reviewing;

            MainForm.ShowInterviewPageControl(GetToolbarState());
            MainForm.EnableTelephonyToolbar(false, false, GetToolbarState());

            _interviewBrowserPresenter.StartInterviewReview(CurrentInterviewProperties, CurrentSurveyLanguageId);
        }

        /// <summary>
        /// Sends wrap-up notification to Fusion. In a case of exceptions fuction initializes 
        /// logout process.
        /// </summary>
        private void Wrapup(string its = null)
        {
            try
            {
                MainForm.DisableToolbars();
                if (_warmTransferForm != null)
                {
                    WarmTransferForm_OnCancelClick(this, new EventArgs());
                }

                bool lookUpForNewCalls = !IsUserGoingToChangeTaskChoice();

                var details = new CompletedInterviewDetails
                {
                    Status = _interviewBrowserPresenter.Status,

                    // Its always has to be defined
                    Its = its ?? _interviewBrowserPresenter.Its ?? _interviewBrowserPresenter.Status,

                    InterviewDuration = _interviewBrowserPresenter.InterviewDuration
                };

                _catiServiceManager.WrapUp(CurrentInterviewProperties.InterviewId, lookUpForNewCalls, details);
            }
            catch (Exception ex)
            {
                RestartAfterCommunicationError(ex);
            }
        }

        private bool IsUserGoingToChangeTaskChoice()
        {
            if (IsChangeTaskChoiceEnabled)
            {
                if (MainForm.IsChangeTaskChoiceChecked)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Finish current interview. 
        /// Shows selection screen or start new interview
        /// </summary>
        internal void FinishInterview()
        {
            MainForm.SpecifyMainFormStyle(GetDefaultTitle(), MainForm.DefaultControlColor, false, false);
            PresenterInterview.HighlightEnterZone(MainForm.DefaultControlColor);

            StopDeferredMonitoring();

            if (_interviewBrowserPresenter.HasWrapUpBeenSent == false)
            {
                /*For some reason WrapUp hasn't beeen sent to backend. 
                  It can lead to improper behaviour of the system. */

                _logger.Log(Strings.ResourceManager.GetString("Log_WrapUpHasnotBeenSent",
                             CurrentInterviewProperties.SurveyId,
                             CurrentInterviewProperties.InterviewId,
                             UserPassport.Instance.GetUserIdentityString()), TraceEventType.Error);
            }

            CurrentInterviewProperties = null;
            CurrentConsoleState = ConsoleState.Selecting;

            if (IsAutoPilotEnabled && MainForm.IsLogoutAfterFinishingChecked)
            {
                Logout(false, false);
            }
            else if (IsAutoPilotEnabled == false && MainForm.IsLogoutAfterFinishingChecked)
            {
                Logout(true, true);
            }
            else if (MainForm.IsPendingBreakChecked)
            {
                WaitBreakStateAndShowOnABreakDialog();
            }
            else
            {
                if (!LoginForm.IsLoggedIn)
                {
                    return;
                }

                if (IsUserGoingToChangeTaskChoice())
                {
                    MainForm.IsChangeTaskChoiceChecked = false;
                    if (UserPassport.Instance.Properties.TaskChoicePermissions != null)
                        ChangeTaskChoiceAndStartSelectionProcess(UserPassport.Instance.Properties.TaskChoicePermissions.Value);
                }
                else
                {
                    try
                    {
                        AgentTaskChoiceMode actualMode = _catiServiceManager.GetPersonMode();

                        if (UserAssignmentMode != actualMode)
                        {
                            _logger.Log(
                                Strings.ResourceManager.GetString("Log_PersonModeHasBeenChangedDuringInterview",
                                    UserAssignmentMode,
                                    actualMode),
                                TraceEventType.Information
                                );
                        }

                        if (UserAssignmentMode == AgentTaskChoiceMode.Manual &&
                            actualMode != AgentTaskChoiceMode.Manual)
                        {
                            UserAssignmentMode = actualMode;
                        }
                    }
                    // ReSharper disable once EmptyGeneralCatchClause
                    catch
                    {
                        // we suppress any exception in that method and continue with current person mode
                    }

                    //FinishInterview event can occured during pending logout.
                    if (UserAssignmentMode == AgentTaskChoiceMode.Manual)
                    {
                        // State can be set to logged out depending on IsReloginNeededOnCampaignChange setting.
                        if (IsLoggedOutState())
                        {
                            LogoutFromGetState();
                            return;
                        }

                        _taskChoiceRouter.StartManualMode();
                    }
                    else
                    {
                        StartInterviewCycle();
                    }
                }
            }
        }

        /// <summary>
        /// Method is responsible for logout in error case.
        /// WS.PendingLogout method will be called.
        /// </summary>
        internal void ForcedLogout()
        {
            _alerter.Alert(LocalizationManager.Instance.GetString("Alerter_ErrorOccursYourWillBeAutomaticalyLoggedOut"),
                   LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                   MessageTypes.Error);

            Logout(true, false);
        }

        private void RestartAfterCommunicationError(Exception ex)
        {
            if (ExceptionsClassifier.IsCommunicationError(ex) == false)
            {
                ForcedLogout();
            }
            else
            {
                FinishLogout();
                RestartApplication();
            }
        }
        /// <summary>
        /// Method is responsible for logout
        /// </summary>
        /// <param name="restartApplication">Restart application after logout.</param>
        /// <param name="onlyWaitLoggedOut">If true method WS.SetPendingLogout shouldn't be called</param>
        internal void Logout(bool restartApplication, bool onlyWaitLoggedOut)
        {
            if (IsAutoPilotEnabled)
            {
                PresenterInterview.StopAutoPilotProcess();
                restartApplication = false;
            }

            if (LoginForm.IsLoggedIn)
            {
                LoginForm.IsLoggedIn = false;

                //We should be sure that timer is stoped because we can do logout while interviewing cycle.
                StopInterviewCycleTimer();

                object[] list = { restartApplication };

                MainForm.ShowProcessControl(LocalizationManager.Instance.GetString("Message_ProcessControl_Logout"), false, false);

                try
                {
                    if (onlyWaitLoggedOut)
                    {
                        AsyncOperationInvoker.Instance.Execute(null, args => LogoutHandler(args, list));
                    }
                    else
                    {
                        _waitForLogoutComplete = true;
                        AsyncOperationInvoker.Instance.Execute(() => _catiServiceManager.SetPendingLogout(true), args => LogoutHandler(args, list));
                    }
                }
                catch (Exception ex)
                {
                    _logger.Log(ex);

                    _alerter.Alert(LocalizationManager.Instance.GetString("Alerter_YouWasNotSuccessfullyLoggedOut"),
                       LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                       MessageTypes.Error
                    );

                    FinishLogout();

                    if (restartApplication)
                    {
                        RestartApplication();
                    }
                    else
                    {
                        MainForm.CloseForm();
                    }
                }

                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.PendingLogoutStartMessage
                    },
                    UserPassport.Instance.MonitoringIdentity
                );
            }
        }

        private void LogoutHandler(GetStateEventArgs e, object[] additionalParams)
        {
            bool restartApplication = additionalParams.Length == 1 ? (bool)additionalParams[0] : true;
            bool isLoggedOut = e.State != null ? (e.State.interviewerLoginState == LoginState.NOT_LOGGED_IN) : false;

            if (e.State != null &&
                e.State.InterviewState == InterviewState.INTERVIEWING &&
                Uri.IsWellFormedUriString(e.State.InterviewProperties.InterviewURL, UriKind.Absolute))
            {
                LoginForm.IsLoggedIn = true;
                AsyncOperationInvoker.Instance.ClearResources();

                if (e.State.interviewerLoginState == LoginState.PENDING_LOGOUT &&
                    MainForm.IsLogoutAfterFinishingChecked == false)
                {
                    /*Button IsLogoutAfterFinishingChecked isn't checked for logout while "wait" state. 
                     If new interview is going to be started the button must be checked.
                     Additionaly for predictive mode the button should be disabled, otherwise user can uncheck it 
                     but the dialer already has started logout process.*/
                    MainForm.IsLogoutAfterFinishingChecked = true;
                }
                IsInterviewStartedDuringLogout = true;

                StartInterviewing(e.State.InterviewProperties);
            }
            else
            {
                if (e.State == null || isLoggedOut || e.Exception != null)
                {
                    if (e.State == null || e.Exception != null)
                    {
                        _alerter.Alert(LocalizationManager.Instance.GetString("Alerter_YouWasNotSuccessfullyLoggedOut"),
                           LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                           MessageTypes.Error);
                    }

                    if (isLoggedOut)
                    {
                        ConfirmLogout();
                    }

                    //It's used here for immediate timer stop
                    AsyncOperationInvoker.Instance.ClearResources();

                    FinishLogout();

                    if (restartApplication)
                    {
                        RestartApplication();
                    }
                    else
                    {
                        MainForm.CloseForm();
                    }
                }
            }
        }

        /// <summary>
        /// Method is responsible for logout completion.
        /// Stops monitoring. Clear resources.
        /// </summary>
        internal void FinishLogout()
        {
            if (IsForcedLogoutInvoked == false)
            {
                IsForcedLogoutInvoked = true;

                _logger.Log(
                    Strings.ResourceManager.GetString("Log_UserLoggedOutMessage", StatusBar.UserName),
                    TraceEventType.Information
                    );

                LoginForm.IsLoggedIn = false;
                StopMonitoring();
                ClearResources();
            }

            _waitForLogoutComplete = false;
        }

        internal void ContinueWorkAfterBreak()
        {
            try
            {
                _catiServiceManager.ContinueWorkAfterBreak();
            }
            catch (Exception ex)
            {
                RestartAfterCommunicationError(ex);
                return;
            }

            MainForm.ShowProcessControl(
                LocalizationManager.Instance.GetString("Message_ProcessControl_GettingInterview"),
                IsLogoutToolbarButtonEnabled,
                IsTakeBreakToolbarButtonEnabled
                );

            CurrentConsoleState = ConsoleState.Selecting;

            OnStateChanged(new StateChangedEventArgs { MessageType = MonitoringMessageTypes.OnABreakDialogClosedMessage },
                           UserPassport.Instance.MonitoringIdentity);

            if (UserAssignmentMode == AgentTaskChoiceMode.Manual)
            {
                _taskChoiceRouter.StartManualMode();
            }
            else if (UserAssignmentMode == AgentTaskChoiceMode.CampaignAssignment && String.IsNullOrEmpty(_currentSurveyId))
            {
                _taskChoiceRouter.StartSurveyAssignmentMode();
            }
            else
            {
                StartInterviewProcess();
            }
        }

        private void LogoutAfterBreak()
        {
            OnStateChanged(new StateChangedEventArgs { MessageType = MonitoringMessageTypes.OnABreakDialogClosedMessage },
                           UserPassport.Instance.MonitoringIdentity);

            Logout(true, false);
        }

        /// <summary>
        /// Waits for 'Break' state and shows 'OnABreak' dialog.
        /// </summary>
        /// <remarks>
        /// If new interview is obtained while waiting for the 'Break' state 
        /// the interview must be started.
        /// It can occurs if user initiate 'Pending break' while 'NO CALLS' or for predictive mode.
        /// </remarks>
        internal void WaitBreakStateAndShowOnABreakDialog()
        {
            //To be sure that timers are stoped.
            StopInterviewCycleTimer();
            AsyncOperationInvoker.Instance.ClearResources();

            EnablePendingBreakToolbarButton(false);
            EnablePendingLogoutToolbarButton(true);

            MainForm.ShowProcessControl(LocalizationManager.Instance.GetString("WaitForBreakState_Message_Text"), false, false);

            AsyncOperationInvoker.Instance.Execute(
                null,
                delegate(GetStateEventArgs args)
                {
                    if (args.State != null && args.State.InterviewState == InterviewState.INTERVIEWING &&
                        Uri.IsWellFormedUriString(args.State.InterviewProperties.InterviewURL, UriKind.Absolute))
                    {
                        AsyncOperationInvoker.Instance.ClearResources();

                        EnablePendingBreakToolbarButton(true);

                        StartInterviewing(args.State.InterviewProperties);
                    }
                    else if (args.State != null && args.State.interviewerLoginState == LoginState.BREAK)
                    {
                        AsyncOperationInvoker.Instance.ClearResources();
                        ShowOnABreakControl();
                    }
                    else
                    {
                        if (args.State == null || args.Exception != null)
                        {
                            ForcedLogout();
                        }
                    }
                });
        }

        /// <summary>
        /// Method was called if time out occured while login to dialer
        /// 
        /// The cases are:
        ///   BackendTelephonyProvider.LoginToDialer
        ///    	Login() exception
        ///    	  e.Exception != null
        ///    	  e.State == null
        ///      
        ///   AsyncOperationInvoker.m_Timer_Tick()
        ///    	GetState() timeout and exception
        ///    	  e.Exception != null
        ///    	  e.State == null
        ///    	  
        ///    	Successful GetState()  
        ///    	  e.Exception == null
        ///    	  e.State != null
        ///    	  
        ///    	Timeout  
        ///    	  e.Exception == null
        ///    	  e.State == null
        /// </summary>
        internal void LoginToDialerErrorEventHandler(GetStateEventArgs e)
        {
            MainForm.ShowBlankForm();

            if (e.Exception == null)
            {
                if (e.State == null)
                {
                    // It means timeout is reached on waiting for the 'logged in' event from dialer
                    AlertAndStartProcess("Alerter_LoginToDialerTimeout", "Alerter_ErrorTimeout");
                }
                else
                {
                    // Some error was returned via GetState()
                    AlertAndStartProcess("Alerter_LoginToDialerError", "Alerter_DialerLoginError");
                }

                return;
            }

            // e.Exception is NOT null

            if (e.Exception is ManualUserInPredictiveModeException)
            {
                IsFirstInterviewTime = true;
                ProcessPredictiveDialingIsUnAvailableInManualModeException();
            }
            else if (e.Exception is SurveyInManualDialingModeException)
            {
                ProcessSurveyInManualDialingModeException();
            }
            else if (e.Exception is LoginToInactiveDialerException)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Alerter_LoginToInactiveDialerError", ((LoginToInactiveDialerException)e.Exception).DialerId),
                    LocalizationManager.Instance.GetString("Alerter_DialerLoginError"),
                    MessageTypes.Error
                );
                StartProcess();
            }
                else
            {
                // Some other 'exception'
                AlertAndStartProcess("Alerter_LoginToDialerError", "Alerter_DialerLoginError");
            }

        }

        private void AlertAndStartProcess(string messageId, string captionId)
        {
            _alerter.Alert(
                LocalizationManager.Instance.GetString(messageId),
                LocalizationManager.Instance.GetString(captionId),
                MessageTypes.Warning);

            StartProcess();
        }

        internal void StartInterviewCycleTimer()
        {
            int interval = Properties.Settings.Default.InterviewingGetStateInterval;
            _interviewCycleTimer = new Timer();
            _interviewCycleTimer.Tick += m_InterviewCycleTimer_Tick;
            _interviewCycleTimer.Interval = interval * 1000;
            _interviewCycleTimer.Start();

            RestartGetStateCycleElapsed();

            // we emulate timer tick immediately in order to reduce gap between the interviews
            m_InterviewCycleTimer_Tick(_interviewCycleTimer, EventArgs.Empty);
        }

        public void StopInterviewCycleTimer()
        {
            if (_interviewCycleTimer == null) return;

            _interviewCycleTimer.Stop();
            _interviewCycleTimer.Tick -= m_InterviewCycleTimer_Tick;
            _interviewCycleTimer.Dispose();
            _interviewCycleTimer = null;

            _getStateCycleElapsed.Reset();
        }

        /// <summary>
        /// Restartes GetState cycle elipsed time counter.
        /// </summary>
        internal void RestartGetStateCycleElapsed()
        {
            _getStateCycleElapsed.Restart();
        }

        /// <summary>
        /// Interview cycle timer tick handler
        /// Calls DoGetStateAndAnalyse for get state and analyze it
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m_InterviewCycleTimer_Tick(object sender, EventArgs e)
        {
            if (!_interviewCycleTimer.Enabled)
            {
                return;
            }

            _interviewCycleTimer.Enabled = false;

            DoGetStateAndAnalyse();

            if (_interviewCycleTimer != null)
            {
                //inside DoGetStateAndAnalyse method we timer can be stopped
                _interviewCycleTimer.Enabled = true;
            }
        }

        /// <summary>
        /// Confirms logout by calling CatiWS method.
        /// For now we suppress any exceptions during this call.
        /// </summary>
        internal void ConfirmLogout()
        {
            try
            {
                _catiServiceManager.ConfirmLogout();
            }
            catch (Exception ex)
            {
                // for now we suppress any exception from logout confirmation
                _logger.Log(ex);
            }
        }

        /// <summary>
        /// Restarts application by calling IViewMainForm.RestartAppliction method.
        /// For forced restart we suppress confirmation.
        /// </summary>
        internal void RestartApplication()
        {
            CloseWarmTransferWindowIfNeeded();

            if (IsAutoPilotEnabled)
            {
                MainForm.CloseForm();
            }
            else if (IsRestartInvoked == false)
            {
                IsRestartInvoked = true;
                ConfirmOnExit = false;
                SaveIsApplicationRestartedFlag(true);
                MainForm.RestartApplication();
            }
        }

        private bool DisplayBreakType(out string breakInfo)
        {
            var displayBreakType = BreakTypes.Count > 1;
            breakInfo = null;

            if (displayBreakType)
            {
                var breakType = MainForm.SelectedBreakIndex != null
                    ? BreakTypes[MainForm.SelectedBreakIndex.Value]
                    : null;
                breakInfo = breakType != null ? $"{breakType.Name} ({breakType.Description})" : null;
            }

            return displayBreakType;
        }

        /// <summary>
        /// Uncheckes PendingBreak button and shows 'OnABreak' control. 
        /// </summary>
        private void ShowOnABreakControl()
        {
            CurrentConsoleState = ConsoleState.InterviewerOnABreak;
            
            var displayBreakType = DisplayBreakType(out var breakInfo);

            UncheckPendingBreak();

            _onABreak.StartTime = DateTime.UtcNow;
            
            MainForm.ShowOnABreakControl();
            MainForm.ShowBreakDetails(displayBreakType, breakInfo);
            
            OnStateChanged(new StateChangedEventArgs
                           {
                               MessageType = MonitoringMessageTypes.OnABreakDialogShownMessage,
                               State = new OnABreakDialogShownInitialStateData
                               {
                                   StartTime = _onABreak.StartTime,
                                   BreakInfo = breakInfo,
                                   DisplayBreakType = displayBreakType
                               }
                           },
                           UserPassport.Instance.MonitoringIdentity);
        }

        /// <summary>
        /// Opens form with interviewer appointmens list
        /// </summary>
        private void ShowInterviewerAppointmentsForm()
        {
            AppointmentCollection interviewerAppointmens;

            try
            {
                interviewerAppointmens = _catiServiceManager.GetInterviewerAppointments();
            }
            catch (Exception)
            {
                _alerter.Alert(LocalizationManager.Instance.GetString("Alerter_AppointmentListCannotBeOpened"),
                    LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"),
                    MessageTypes.Error);
                return;
            }

            if (interviewerAppointmens != null)
            {
                var appointments = InterviewerAppointmentManager.PrepareAppointmentsForBinding(interviewerAppointmens, TimeZoneInfo.Local);

                using (var form =
                      (IViewInterviewerAppointmentsForm)ViewFactory.GetView(FormViews.InterviewerAppointmensView))
                {
                    form.Localize(LocalizationManager.Instance);
                    form.Bind(appointments.ToArray());

                    OnStateChanged(
                        new StateChangedEventArgs { MessageType = MonitoringMessageTypes.AppointmentsListFormShownMessage },
                        UserPassport.Instance.MonitoringIdentity);

                    form.Show();

                    OnStateChanged(
                        new StateChangedEventArgs
                        {
                            MessageType = MonitoringMessageTypes.AppointmentsListFormClosedMessage,
                            State = new AppointmentListFormClosedStateData { ConsoleState = PresenterInterview.GetConsoleState() }
                        },
                        UserPassport.Instance.MonitoringIdentity);
                }
            }
        }

        private void ShowSurveySwitchedNotification()
        {
            if (NotificationForm != null)
            {
                NotificationForm.Close();
            }

            NotificationForm = new NotificationForm
            {
                Message = CurrentInterviewProperties.SurveyName,
                Title = string.Format(Strings.SeamlessSurveySwitching_Notification, CurrentInterviewProperties.SurveyId),
                DismissTimeout = ClientSettings.Default.SurveyChangeNotificationShowTime
            };

            NotificationForm.Localize(LocalizationManager.Instance);
            NotificationForm.AdjustLocation();

            NotificationForm.Show(MainForm);
        }

        /// <summary>
        /// Opens station identifier form
        /// </summary>
        private void ShowStationIdForm()
        {
            var stationIdForm = (IViewStationIdForm)ViewFactory.GetView(FormViews.StationIdView);

            stationIdForm.StationId = ClientSettings.Default.StationId;
            stationIdForm.Localize(LocalizationManager.Instance);

            stationIdForm.ValidatingStationId += stationIdForm_ValidatingStationId;

            if (stationIdForm.Show(LoginForm) == DialogResult.OK)
            {
                ClientSettings.Default.StationId = stationIdForm.StationId;
                ClientSettings.Default.Save();
            }
        }

        /// <summary>
        /// StationIdForm validating event handler
        /// </summary>
        ///<remarks>
        /// StationId has to have valid format:
        /// First up to 8 characters, next optional up 6 digits, ended optional letter "L"
        /// </remarks>
        void stationIdForm_ValidatingStationId(object sender, CancelEventArgs e)
        {
            var stationIdForm = ((IViewStationIdForm)sender);
            var message = new StationIdValidator().Validate(stationIdForm.StationId, e);
            if (string.IsNullOrEmpty(message) == false)
            {
                stationIdForm.AlertValidationError(message);
            }
        }

        /// <summary>
        /// Handler for PredictiveDialingIsUnAvailableInManualModeException exception
        /// </summary>
        /// <remarks>
        /// Exception occurs when user tries login to dialer in manul mode for predictive survey
        /// Or when user already logged in to dialer tries start new interview for predictive survey
        /// </remarks>
        private void ProcessPredictiveDialingIsUnAvailableInManualModeException()
        {
            _alerter.Alert(
                  LocalizationManager.Instance.GetString("Error_PredicitveDialingIsAvailableInSurveyAssignmentModeOnlyMessage"),
                  LocalizationManager.Instance.GetString("Allert_ErrorCaption"),
                  MessageTypes.Error
              );

            if (UserAssignmentMode == AgentTaskChoiceMode.Manual)
            {
                _taskChoiceRouter.StartManualMode();
            }
            else
            {
                _logger.Log(Strings.Log_PredictiveDialingIsUnAvailableInManualModeExceptionInNonManualMode, TraceEventType.Error);
                ForcedLogout();
            }
        }

        /// <summary>
        /// Handles case when exception 'SurveyInManualDialingModeException' occurs on attempt to login into dialer
        /// </summary>
        /// <remarks>
        /// Exception occurs when user tries logging into dialer with survey and that survey has Manual dialling mode
        /// </remarks>
        private void ProcessSurveyInManualDialingModeException()
        {
            var result = DialogResult.OK;

            if (IsAutoPilotEnabled == false)
            {
                result = _alerter.AlertConfirmationOkCancel(
                    LocalizationManager.Instance.GetString(
                        "Alerter_LoginToDialerSurveyInManualModeWorkWithoutDialerOrLogoutConfirmation"),
                    LocalizationManager.Instance.GetString("Alerter")
                    );
            }

            switch (result)
            {
                case DialogResult.OK:
                    IsDialerInSystem = false;
                    StartProcess();
                    break;
                case DialogResult.Cancel:
                    Logout(true, false);
                    break;
                default:
                    throw new InvalidOperationException();
            }
        }

        /// <summary>
        /// Handler for  ProcessPredictiveSurveyWithoutDialerException exception
        /// </summary>
        /// <remarks>
        /// Exception occurs when user tries to start interview in non manual mode for predictive survey without dialer        
        /// </remarks>
        private void ProcessPredictiveSurveyWithoutDialerException()
        {
            _alerter.Alert(
                  LocalizationManager.Instance.GetString("Error_PredictiveSurveyWithoutDialerIsAvailableInManualModeOnlyMessage"),
                  LocalizationManager.Instance.GetString("Allert_ErrorCaption"),
                  MessageTypes.Error
              );

            _logger.Log(Strings.Log_PredictiveSurveyWithoutDialerIsAvailableInManualModeOnlyException, TraceEventType.Error);
            ForcedLogout();
        }

        /// <summary>
        /// Opens messaging form
        /// </summary>
        void m_MainForm_ShowMessagingForm(object sender, EventArgs e)
        {
            _presenterMessaging.ShowDialog(MainForm);
        }

        internal ToolbarState GetToolbarState()
        {
            InterviewModes currentMode;

            switch (CurrentConsoleState)
            {
                case ConsoleState.Interviewing:
                    currentMode = InterviewModes.Interviewing;
                    break;
                case ConsoleState.Reviewing:
                    currentMode = InterviewModes.Reviewing;
                    break;
                default:
                    currentMode = InterviewModes.Selecting;
                    break;
            }

            return new ToolbarState
            {
                Mode = currentMode,
                IsPreviousPageEnabled = CatiConsoleProperties.EnablePreviousPageToolbarButton,
                IsNextPageEnabled = CatiConsoleProperties.EnableNextPageToolbarButton,
                IsAppointmentEnabled = CatiConsoleProperties.EnableAppointmentToolbarButton,
                IsRedoEnabled = CatiConsoleProperties.EnableRedoToolbarButton,
                IsFastForwardEnabled = CatiConsoleProperties.EnableFastForwardToolbarButton,
                IsCheckSpellingEnabled = CatiConsoleProperties.EnableCheckSpellingToolbarButton,
                IsHangUpEnabled = IsHangUpEnabled && CatiConsoleProperties.EnableHangUpToolbarButton,
                IsRedialEnabled = IsRedialEnabled && CatiConsoleProperties.EnableRedialToolbarButton,
                IsInternalCallTransferEnabled = IsInternalCallTransferEnabled && CatiConsoleProperties.EnableInternalCallTransferButton,
                IsExternalCallTransferEnabled = IsExternalCallTransferEnabled && CatiConsoleProperties.EnableExternalCallTransferButton,
                IsPendingLogoutEnabled = IsPendingLogoutDuringInterviewEnabled && CatiConsoleProperties.EnableLogoutAfterFinishToolbarButton,
                IsTerminateEnabled = CatiConsoleProperties.EnableTerminateToolbarButton,
                IsTakeBreakEnabled = CatiConsoleProperties.EnableTakeBreakToolbarButton,
                IsChangeTaskChoiceEnabled = IsChangeTaskChoiceEnabled && CatiConsoleProperties.EnableChangeTaskChoiceToolbarButton,
                IsMessageFormEnabled = CatiConsoleProperties.EnableMessageFormToolbarButton,
                IsAppointmensListEnabled = CatiConsoleProperties.EnableAppointmensListToolbarButton,
                IsRefreshEnabled = CatiConsoleProperties.EnableRefreshToolbarButton,
                IsLogoutEnabled = CatiConsoleProperties.EnableLogoutToolbarButton
            };
        }

        private void SaveIsApplicationRestartedFlag(bool isRestarted)
        {
            Properties.Settings.Default.IsApplicationRestarted = isRestarted;
            Properties.Settings.Default.Save();
        }

        private bool IsApplicationRestarted()
        {
            return Properties.Settings.Default.IsApplicationRestarted;
        }

        private void EnablePendingBreakToolbarButton(bool isEnabled)
        {
            if (!IsTakeBreakToolbarButtonEnabled) return;

            MainForm.IsPendingBreakEnabled = isEnabled;
        }

        private void EnablePendingLogoutToolbarButton(bool isEnabled)
        {
            if (!IsLogoutAfterFinishButtonEnabled) return;

            MainForm.IsLogoutAfterFinishingEnabled = isEnabled;
        }
    }
}
