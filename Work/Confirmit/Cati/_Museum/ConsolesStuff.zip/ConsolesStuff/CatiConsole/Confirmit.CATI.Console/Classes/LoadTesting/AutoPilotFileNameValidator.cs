﻿using System.IO;
using Confirmit.CATI.Console.Resources;

namespace Confirmit.CATI.Console.Classes.LoadTesting
{
    public interface IAutoPilotFileNameValidator
    {
        void ValidateFileName(string fileName);
    }

    public class AutoPilotFileNameValidator : IAutoPilotFileNameValidator
    {
        public void ValidateFileName(string fileName)
        {
            if (File.Exists(fileName) == false)
            {
                throw new AutopilotArgumentException(
                    string.Format(Strings.Autopilot_FileNotExists_Error,
                    fileName));
            }
        }
    }
}
