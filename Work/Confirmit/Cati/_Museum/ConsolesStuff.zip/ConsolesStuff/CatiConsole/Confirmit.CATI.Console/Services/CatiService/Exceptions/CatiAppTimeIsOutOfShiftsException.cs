﻿using System;
using Confirmit.CATI.Common;

namespace Confirmit.CATI.Console.Services.CatiService.Exceptions
{
    /// <summary>
    /// Occurs when appointment time is out of any shift.
    /// </summary>
    internal class CatiAppTimeIsOutOfShiftsException : CatiServiceException
    {
        #region Constructors

        /// <summary>
        /// Initializes new instance of CatiAppTimeIsOutOfShiftsException.
        /// </summary>
        public CatiAppTimeIsOutOfShiftsException()
            : base()
        {
            Error = CATIErrorCodes.AppTimeIsOutOfShifts;
        }

        /// <summary>
        /// Initializes new instance of CatiAppTimeIsOutOfShiftsException class and fills if with given data.
        /// </summary>
        /// <param name="message">Message.</param>
        /// <param name="innerException">Inner exception.</param>
        public CatiAppTimeIsOutOfShiftsException(string message, Exception innerException)
            : base(message, innerException)
        {
            Error = CATIErrorCodes.AppTimeIsOutOfShifts;
        }

        #endregion
    }
}
