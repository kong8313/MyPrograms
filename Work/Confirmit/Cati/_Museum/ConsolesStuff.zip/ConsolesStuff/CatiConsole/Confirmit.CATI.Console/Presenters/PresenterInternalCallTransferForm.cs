﻿using System;
using Confirmit.CATI.Console.Classes.Localization;
using System.Windows.Forms;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.CallTransfer;
using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;
using Confirmit.CATI.Common;

namespace Confirmit.CATI.Console.Presenters
{
    internal class PresenterInternalCallTransferForm
    {
        public PresenterInternalCallTransferForm(IViewInternalCallTransferForm internalCallTransferForm, InternalTransferType transferType)
        {
            InternalCallTransferForm = internalCallTransferForm ?? throw new ArgumentNullException(nameof(internalCallTransferForm));
            TransferType = transferType == InternalTransferType.Cold ? ConsoleTransferType.InternalCold : ConsoleTransferType.InternalWarm;


            _alerter = ServiceLocator.Resolve<IAlerter>();

            InitEventHandlers();
            InitLocalization();
        }

        public event EventHandler<EventArgs> TransferStart;
        public event StateChangedEventHandler StateChanged;
        public string SelectedResource { get; private set; } = null;

        private IViewInternalCallTransferForm InternalCallTransferForm { get; }

        private ConsoleTransferType TransferType { get; }

        public string LastUsedTransferTargetGroupName { get; set; }

        private IAlerter _alerter;
        private ICatiServiceManager _catiServiceManager;
        private bool _isTransferPossible;

        public void ShowDialog(IWin32Window parent, ICatiServiceManager catiServiceManager)
        {
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.InternalCallTransferFormShownMessage,
                    State = null
                },
                UserPassport.Instance.MonitoringIdentity
            );

            _catiServiceManager = catiServiceManager;
            var timer = new Timer
            {
                Interval = 2000
            };

            timer.Tick += (s, a) => RefreshTargets();

            try
            {
                InitLocalization();

                RefreshTargets();

                InternalCallTransferForm.SelectRow(LastUsedTransferTargetGroupName);

                timer.Start();

                InternalCallTransferForm.Show(parent);

                timer.Stop();

                LastUsedTransferTargetGroupName = InternalCallTransferForm.Selected?.Name;

                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.InternalCallTransferFormClosedMessage,
                        State = new InternalCallTransferFormClosedStateData { ConsoleState = ConsoleState.Interviewing }
                    },
                    UserPassport.Instance.MonitoringIdentity);
            }
            catch (Exception ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
            }
        }

        private void RefreshTargets()
        {
            var targets = _catiServiceManager.GetInternalTransferTargets();

            _isTransferPossible = targets.Length != 0;

            InternalCallTransferForm.UpdateFormData(targets);

            InternalCallTransferForm.EnableTransferButton(_isTransferPossible);
        }

        private void LocalizationManager_CurrentCultureChanged(object sender, EventArgs e)
        {
            LocalizeViews(LocalizationManager.Instance);
        }

        private void InitEventHandlers()
        {
            InternalCallTransferForm.CallTransferStart += InternalCallTransferForm_OnTransferStart;
            LocalizationManager.Instance.CurrentCultureChanged += LocalizationManager_CurrentCultureChanged;
        }

        private void InternalCallTransferForm_OnTransferStart(object sender, EventArgs args)
        {
            if (!_isTransferPossible)
            {
                return;
            }

            SelectedResource = InternalCallTransferForm.Selected.Name;

            InternalCallTransferForm.Hide();

            TransferStart?.Invoke(this, args);
        }

        private void InitLocalization()
        {
            LocalizeViews(LocalizationManager.Instance);
        }

        private void LocalizeViews(ILocalizationManager manager)
        {
            InternalCallTransferForm.Localize(manager, TransferType);
        }

        private void OnStateChanged(StateChangedEventArgs e, MonitoringIdentity sessionId)
        {
            StateChanged?.Invoke(this, e, sessionId);
        }
    }
}
