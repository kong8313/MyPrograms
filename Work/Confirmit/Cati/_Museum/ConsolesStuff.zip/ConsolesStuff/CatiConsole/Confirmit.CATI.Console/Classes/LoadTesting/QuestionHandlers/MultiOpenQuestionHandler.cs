using System.Collections.Generic;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class MultiOpenQuestionHandler : BaseQuestionHandler, IQuestionHandler
    {
        public MultiOpenQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers) : base(pageBrowser, predefinedAnswers)
        {
        }

        void IQuestionHandler.SetAnswers()
        {
            SetOpenTextValueForNonEmpty();

            SetOtherForNonEmpty();
        }
    }
}