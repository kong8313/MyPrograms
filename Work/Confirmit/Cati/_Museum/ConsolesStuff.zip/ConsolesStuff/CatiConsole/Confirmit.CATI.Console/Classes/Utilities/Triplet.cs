﻿namespace Confirmit.CATI.Console.Classes.Utilities
{
    /// <summary>
    /// Class represents utility class which is used to store three related onjects.
    /// </summary>
    /// <typeparam name="TFirst">The type of first object.</typeparam>
    /// <typeparam name="TSecond">The type of second object.</typeparam>
    /// <typeparam name="TThird">The type of third object.</typeparam>
    public class Triplet<TFirst, TSecond, TThird>
    {
        #region Constructors

        /// <summary>
        /// Initializes new instance of Triplet class.
        /// </summary>
        public Triplet() { }

        /// <summary>
        /// Initializes new instance of Triplet class and fills it with given data.
        /// </summary>
        /// <param name="first">First object.</param>
        /// <param name="second">Second object.</param>
        /// <param name="third">Third object.</param>
        public Triplet(TFirst first, TSecond second, TThird third)
        {
            First = first;
            Second = second;
            Third = third;
        }

        #endregion

        #region Properties

        /// <summary>
        /// First item.
        /// </summary>
        public TFirst First
        {
            get;
            set;
        }

        /// <summary>
        /// Second item.
        /// </summary>
        public TSecond Second
        {
            get;
            set;
        }

        /// <summary>
        /// Third item.
        /// </summary>
        public TThird Third
        {
            get;
            set;
        }

        #endregion
    }
}
