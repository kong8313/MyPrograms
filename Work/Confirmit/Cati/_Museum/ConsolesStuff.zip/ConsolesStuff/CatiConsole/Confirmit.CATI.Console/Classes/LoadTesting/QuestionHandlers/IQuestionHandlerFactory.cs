using Confirmit.CATI.Console.Views.Classes.Interview;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public interface IQuestionHandlerFactory
    {
        IQuestionHandler Create();
    }
}