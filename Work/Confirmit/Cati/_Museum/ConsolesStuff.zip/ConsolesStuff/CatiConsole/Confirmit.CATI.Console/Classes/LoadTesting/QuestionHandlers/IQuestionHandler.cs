namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public interface IQuestionHandler
    {
        void SetAnswers();

        bool ValueWasSet { get; }
    }
}