using System.Globalization;

namespace Confirmit.CATI.Console.Classes.LoadTesting
{
    public class AutoPilotArguments
    {
        public string UserName { get; set; }

        public string Password { get; set; }

        public int MinDelay { get; set; }

        public int MaxDelay { get; set; }

        public string FileName { get; set; }

        public int TimesToRepeat { get; set; }

        public string Company { get; set; }

        public string StationId { get; set; }

        public string ExtensionNumber { get; set; }

        public CultureInfo Locale { get; set; }
    }
}