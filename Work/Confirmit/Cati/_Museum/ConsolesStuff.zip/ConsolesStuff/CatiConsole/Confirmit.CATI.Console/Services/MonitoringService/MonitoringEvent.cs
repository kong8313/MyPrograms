﻿using System;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;

namespace Confirmit.CATI.Console.Services.MonitoringService
{
    /// <summary>
    /// Represents monitorinfg event. It is wrapper for StateEventInfo class of Monitoring Web Service.
    /// </summary>
    public class MonitoringEvent
    {
        #region Properties

        /// <summary>
        /// Company identifier.
        /// </summary>
        public int CompanyId 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// Interview identifier.
        /// </summary>
        public int InterviewerId 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// Time of state event in UTC.
        /// </summary>
        public DateTime TimeStamp 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// Monitoring event type.
        /// </summary>
        public MonitoringMessageTypes MessageType 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// Serialiazed monitoring state data.
        /// </summary>
        public byte[] Data 
        { 
            get; 
            set; 
        }

        #endregion

        #region Methods

        /// <summary>
        /// Converts current object to Monitoring Web Service event object.
        /// </summary>
        /// <returns>Monitoring Web Service event object.</returns>
        public StateEventInfo ToStateEventInfo()
        {
            return new StateEventInfo
            {
                //Identity = new IdentityObject
                //{
                //    CompanyID = CompanyId,
                //    InterviewerID = InterviewerId
                //},
                MessageType = MessageType,
                State = Data,
                TimeStamp = TimeStamp
            };      
        }

        /// <summary>
        /// Converts current object to Monitoring Web Service event object.
        /// </summary>
        /// <returns>Monitoring Web Service event object.</returns>
        public static explicit operator StateEventInfo(MonitoringEvent obj)
        {
            return obj.ToStateEventInfo();
        }

        #endregion
    }

    /// <summary>
    /// Contains extension methods for MonitoringEvent class.
    /// </summary>
    public static class MonitoringEventExtensions
    {
        /// <summary>
        /// Converts MonitoringEvent array to StateEventInfo array.
        /// </summary>
        /// <param name="obj">Monitiring events to convert.</param>
        /// <returns>StateEventInfo array.</returns>
        public static StateEventInfo[] ToStateEventInfoArray(this MonitoringEvent[] obj)
        {
            StateEventInfo[] result = new StateEventInfo[obj.Length];
            for (int i = 0; i < result.Length; i++)
            {
                result[i] = (StateEventInfo)obj[i];
            }

            return result;
        }
    }
}
