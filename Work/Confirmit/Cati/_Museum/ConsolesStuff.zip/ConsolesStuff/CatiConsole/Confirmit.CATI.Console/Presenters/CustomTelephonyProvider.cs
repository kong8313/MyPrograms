﻿using System;
using System.Threading;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Classes.Telephony;
using Confirmit.CATI.Console.LightweightTelephony;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Shared.Exceptions;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.Console.Presenters
{
    public class CustomTelephonyProvider : ITelephonyProvider
    {
        private readonly ICustomDialer m_CustomDialer;
        private readonly SynchronizationContext m_SynchronizationContext;
        private const int m_CustomErrorStatus = (int)CustomCallOutcome.Error;

        public CustomTelephonyProvider(string path, string typeName)
        {
            m_SynchronizationContext = SynchronizationContext.Current;

            try
            {
                var obj = AppDomain.CurrentDomain.CreateInstanceFrom(path, typeName);
                m_CustomDialer = (ICustomDialer)obj.Unwrap();
            }
            catch (Exception ex)
            {
                throw new CustomDialerInitializationException(LocalizationManager.Instance.GetString("Message_UnableToInitializeCustomDialer"), ex);
            }
        }

        public bool IsCustomDialer
        {
            get { return  true; }
        }

        /// <summary>
        /// Occurs when we receive telephony command result status.
        /// </summary>
        public event TelephonyResultEventHandler TelephonyResult;

        /// <summary>
        /// Occurs when console logged in to dialer 
        /// </summary>
        /// <remarks>
        /// Initially method LoginToDialer is called
        /// Event occurs when GetState returns Logged_In state
        /// </remarks>
        public event EventHandler<GetStateEventArgs> LoggedToDialerInEvent;

        /// <summary>
        /// Occurs when interviewer is logged out by system
        /// </summary>
        /// <remarks>
        /// Initially method LoginToDialer is called
        /// Event occurs when GetState returns Not_Logged_In state for interviewer
        /// </remarks>
        public event EventHandler<GetStateEventArgs> LogoutWhileLoginToDialerEvent;

        /// <summary>
        /// Occurs when timeout for command LoginToDialer is expired
        /// </summary>
        public event EventHandler<GetStateEventArgs> LoginToDialerErrorEvent;        

        void CustomDialerCallStatusChanged(object sender, CallStatusChangedEventArgs e)
        {
            m_CustomDialer.CallStatusChanged -= CustomDialerCallStatusChanged;

            var result = new TelephonyResultEventArgs {Status = (int) e.CustomCallStatus};

            m_SynchronizationContext.Post(r => OnTelephonyResult(result), null);            
        }

        public void Dial(string phone, string message)
        {
            m_CustomDialer.CallStatusChanged += CustomDialerCallStatusChanged;
          
            try
            {
                m_CustomDialer.Dial(phone);                
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
                OnTelephonyResult(new TelephonyResultEventArgs { Status = m_CustomErrorStatus });
            }
        }

        public void Redial(string phone, string message)
        {
            m_CustomDialer.CallStatusChanged += CustomDialerCallStatusChanged;

            try
            {
                m_CustomDialer.Dial(phone);
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
                OnTelephonyResult(new TelephonyResultEventArgs { Status = m_CustomErrorStatus });
            }
        }

        public bool Hangup(Initiator initiator)
        {
            try
            {
                m_CustomDialer.HangUp();
                return true;
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
                OnTelephonyResult(new TelephonyResultEventArgs { Status = m_CustomErrorStatus });
            }

            return false;
        }

        public void LoginToDialer(string number, string surveyId, out bool isPredictiveMode)
        {
            isPredictiveMode = false;
            OnLoggedToDialerInEvent(new GetStateEventArgs());            
        }        

        public void StartPlayback(string soundFile, out int timeOfPlayingInSeconds)
        {            
            throw new NotSupportedException();
        }

        public void PauseOrResumePlayback()
        {
            throw new NotSupportedException();
        }

        public void StopPlayback()
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Fires TelephonyResult event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnTelephonyResult(TelephonyResultEventArgs e)
        {
            if (TelephonyResult != null)
            {
                TelephonyResult(this, e);
            }
        }

        private void OnLoggedToDialerInEvent(GetStateEventArgs e)
        {
            e.Cancel = true;
            if (LoggedToDialerInEvent != null)
            {
                LoggedToDialerInEvent(this, e);
            }
        }

        private void OnLoginToDialerErrorEvent(GetStateEventArgs e)
        {
            e.Cancel = true;
            if (LoginToDialerErrorEvent != null)
            {
                LoginToDialerErrorEvent(this, e);
            }
        }

        private void OnLogoutWhileLoginToDialerEvent(GetStateEventArgs e)
        {
            e.Cancel = true;
            if (LogoutWhileLoginToDialerEvent != null)
            {
                LogoutWhileLoginToDialerEvent(this, e);
            }
        }
    }
}
