﻿using System;

namespace Confirmit.CATI.Console.Classes.LoadTesting
{
    class AutopilotArgumentException : Exception
    {
        public AutopilotArgumentException(string message)
            : base(message)
        {
        }
    }
}
