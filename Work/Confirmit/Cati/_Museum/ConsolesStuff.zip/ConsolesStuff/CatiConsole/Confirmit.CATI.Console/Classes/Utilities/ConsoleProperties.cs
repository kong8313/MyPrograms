namespace Confirmit.CATI.Console.Classes.Utilities
{
    public class ConsoleProperties : IConsoleProperties
    {
        public int GetStateWsErrorTimeout { get { return Properties.Settings.Default.GetStateWSErrorTimeout; } }

        public bool EnableServerLog { get { return Properties.Settings.Default.EnableServerLog; } }
    }
}