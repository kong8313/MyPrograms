using System;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public interface ITaskChoiceRouter
    {
        Action StartManualMode { get; set; }
        Action StartSurveyAssignmentMode { get; set; }
        Action StartAutomaticMode { get; set; }
    }
}