﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using Confirmit.CATI.Common.ConsoleService.Abstract;

namespace Confirmit.CATI.Console.Classes.CallTransfer
{
    internal class CallTransferConfigurationConverter
    {
        private TransferOptions MapCatiCallTransferConfigurationToTransferOptions(CatiCallTransferConfiguration configuration)
        {
            if (configuration.Type != CatiCallTransferType.InternalCold)
            {
                throw new ArgumentOutOfRangeException(nameof(configuration.Type));
            }

            return new TransferOptions
            {
                Resource = string.IsNullOrEmpty(configuration.TransferTarget) ? null : configuration.TransferTarget,
                AllowInterviewing = true,
                Type = ConsoleTransferType.InternalCold
            };
        }

        public TransferOptions ConvertJsonToTransferOptions(string json)
        {
            using (var memoryStream = new MemoryStream(Encoding.Unicode.GetBytes(json)))
            {
                var jsonSerializer = new DataContractJsonSerializer(typeof(CatiCallTransferConfiguration));
                var configuration = (CatiCallTransferConfiguration) jsonSerializer.ReadObject(memoryStream);

                return MapCatiCallTransferConfigurationToTransferOptions(configuration);
            }
        }

        public static ConsoleTransferState GetDefaultTransferState(TransferOptions transferOptions)
        {
            var transferState = new ConsoleTransferState
            {
                Target = new TransferParticipant
                {
                    DialingState = DialingState.Dialing,
                    DialingStateOutcome = DialingStateOutcome.NotDefined,
                    ParticipantType = transferOptions.Type == ConsoleTransferType.ExternalWarm ? ParticipantType.External : ParticipantType.Agent,
                    Resource = transferOptions.Resource
                },

                Respondent = new TransferParticipant
                {
                    DialingState = DialingState.Connected,
                    DialingStateOutcome = DialingStateOutcome.NotDefined,
                    ParticipantType = ParticipantType.Agent,
                }
            };

            return transferState;
        }
    }

    [DataContract]
    public class CatiCallTransferConfiguration
    {
        [DataMember(Name = "Type")]
        public CatiCallTransferType Type { get; set; }

        [DataMember(Name = "TransferTarget")]
        public string TransferTarget { get; set; }
    }

    public enum CatiCallTransferType
    {
        InternalCold = 0
    }
}
