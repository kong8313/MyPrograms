using System.Collections.Generic;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class GridSliderQuestionHandler : BaseQuestionHandler, IQuestionHandler
    {
        public GridSliderQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers)
            : base(pageBrowser, predefinedAnswers)
        {
        }

        void IQuestionHandler.SetAnswers()
        {
            var keys = GetKeysForNonOther();

            foreach (var key in keys)
            {
                if (string.IsNullOrEmpty(key) == false)
                {
                    FireClick(string.Format("{0}_{1}", key, PredefinedAnswers[key]));
                }
            }

            SetOtherForNonEmpty();
        }
    }
}