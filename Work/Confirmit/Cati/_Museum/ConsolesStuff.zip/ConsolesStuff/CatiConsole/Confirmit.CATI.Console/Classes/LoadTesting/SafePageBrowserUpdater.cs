﻿using System;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Classes.LoadTesting
{
    public class SafePageBrowserUpdater
    {
        private readonly UserControl _control;

        public SafePageBrowserUpdater(UserControl control)
        {
            _control = control;
        }

        public void Run(Action action)
        {
            if (_control.InvokeRequired)
            {
                _control.Invoke((MethodInvoker)(() => action()));
            }
            else
            {
                action.Invoke();
            }
        }
    }
}
