using System.Diagnostics;

namespace Confirmit.CATI.Console.Services.CatiService
{
    public class GetStateStopwatch : IGetStateStopwatch
    {
        private readonly Stopwatch _stopwatch;

        public GetStateStopwatch()
        {
            _stopwatch = new Stopwatch();
        }

        public long ElapsedMilliseconds
        {
            get { return _stopwatch.ElapsedMilliseconds; }
        }

        public void Reset()
        {
            _stopwatch.Reset();
        }

        public void Start()
        {
            _stopwatch.Start();
        }

        public void Restart()
        {
            Reset();
            Start();
        }
    }
}