﻿using System;
using System.Collections.Generic;

namespace Confirmit.CATI.Console.Services.CatiService
{
	/// <summary>
	/// Represents appointment. It is wrapper for Appointment class, which is declared 
	/// in CATI Web Service.
	/// </summary>
	public class Appointment
	{
		#region Constructors

		/// <summary>
		/// Constructs new instance of Appointment class and fills it with
		/// given data.
		/// </summary>
		/// <param name="appointment">CATI Web Service appointment.</param>
        public Appointment(Confirmit.CATI.Common.ConsoleService.Abstract.Appointment appointment)
		{
			if (appointment == null)
			{
				throw new ArgumentNullException("appointment");
			}

			Id = appointment.id;
            InterviewId = appointment.InterviewId;
            ProjectID = appointment.projectID;
            ProjectName = appointment.projectName;
			ContactName = appointment.contactName;
			AppointmentTime = appointment.time;
			ExpirationTime = appointment.expirationTime;
            
            if (appointment.appointmentTimeZone != null)
            {
                Timezone = new Timezone(appointment.appointmentTimeZone);
            }
		}

		/// <summary>
		/// Constructs new instance of Appointment class and fills it with
		/// given data.
		/// </summary>
		/// <param name="id">Appointment identifier.</param>
		/// <param name="contactName">Contact name.</param>
		/// <param name="appointmentTime">Appointment time.</param>
		/// <param name="expirationTime">Expiration time.</param>
		public Appointment(
			int id,            
			string contactName,
			DateTime appointmentTime,
			DateTime? expirationTime
		)
		{
			Id = id;
			ContactName = contactName;
			AppointmentTime = appointmentTime;
			ExpirationTime = expirationTime;            
		}

		#endregion

		#region Properties

		/// <summary>
		/// Appointment identifier.
		/// </summary>
		public int Id 
		{ 
			get; 
			set; 
		}

        /// <summary>
        /// Appointment interview identifier.
        /// </summary>
        public int InterviewId
        {
            get;
            set;
        }

		/// <summary>
		/// Contact name.
		/// </summary>
		public string ContactName 
		{ 
			get; 
			set; 
		}
		
		/// <summary>
		/// Appointment time.
		/// </summary>
		public DateTime AppointmentTime 
		{ 
			get; 
			set; 
		}

		/// <summary>
		/// Expiration time. Null means "Never expires".
		/// </summary>
		public DateTime? ExpirationTime
		{
			get;
			set;
		}

        /// <summary>
        /// Project ID
        /// </summary>
        public string ProjectID
        {
            get;
            set;
        }

        /// <summary>
        /// Project Name
        /// </summary>
        public string ProjectName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets respondent time zone info.
        /// </summary>
        public Timezone Timezone
        {
            get;
            set;
        }

		#endregion

		#region Methods

		/// <summary>
		/// Converts current object to CATI Web Service appointment object.
		/// </summary>
		/// <returns>CATI Web Service object.</returns>
        public Confirmit.CATI.Common.ConsoleService.Abstract.Appointment ToWSAppointment()
		{
            return new Confirmit.CATI.Common.ConsoleService.Abstract.Appointment
            { 
				id = Id, 
				contactName = ContactName, 
				time = AppointmentTime, 
				expirationTime = ExpirationTime               
			};
		}

		/// <summary>
		/// Converts current object to CATI Web Service appointment object.
		/// </summary>
		/// <returns>CATI Web Service object.</returns>
        public static explicit operator Confirmit.CATI.Common.ConsoleService.Abstract.Appointment(Appointment appointment)
		{
			return appointment.ToWSAppointment();
		}

		#endregion
	}

    /// <summary>
    /// Represents collection of appointments.
    /// </summary>
    public class AppointmentCollection : List<Appointment>
    {
        #region Constructors

        /// <summary>
        /// Initializes new instance of AppointmentCollection class.
        /// </summary>
        public AppointmentCollection()
        {
        }

        /// <summary>
        /// Initializes new instance of AppointmentCollection class and fills it with given
        /// list of CATI Web Service appointments.
        /// </summary>
        /// <param name="appointments">Enumeration with CATI Web Service appointments.</param>
        /// <exception cref="ArgumentNullException">Appointments enumeration is null.</exception>
        public AppointmentCollection(IEnumerable<Confirmit.CATI.Common.ConsoleService.Abstract.Appointment> appointments)
        {
            if (appointments == null)
            {
                throw new ArgumentNullException("appointments");
            }

            foreach (Confirmit.CATI.Common.ConsoleService.Abstract.Appointment app in appointments)
            {                
                Add(new Appointment(app));
            }
        }

        #endregion
    }
}
