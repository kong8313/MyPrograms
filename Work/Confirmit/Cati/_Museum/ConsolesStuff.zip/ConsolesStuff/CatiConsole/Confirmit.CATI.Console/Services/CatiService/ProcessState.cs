﻿using System;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.Encryption;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.TelephonyProblemStates.ProblemState;
using ConfirmitDialerInterface;

namespace Confirmit.CATI.Console.Services.CatiService
{        
    /// <summary>
    /// Class represent current state
    /// </summary>
    /// <remarks>
    /// It is based on web service State class
    /// </remarks>
    public class ProcessState
    {
        #region Constructors

        /// <summary>
        /// Initializes new instance of ProcessStae class
        /// </summary>
        public  ProcessState()
        {
        }

        /// <summary>
        /// Initializes new instance of ProcessStae class and fills it
        /// with data from WS.State class.
        /// </summary>
        public ProcessState(State state, byte[] encryptionKey, byte[] encriptionIv, string stationId)
        {
            if (state == null)
            {
                throw new ArgumentNullException("state");
            }

            InterviewProperties = new InterviewProperties(
                DecryptInterviewUrl(state.interviewURL, encryptionKey, encriptionIv),
                state.surveyId,
                state.surveyDescription,
                state.interviewId,
                state.projectId,
                state.isSurveyRecorded,
                state.respondentTimezone, 
                state.deferredRecordId,
                state.callOutcome,
                state.languageVariableValue,
                state.isNewSurvey,
                state.callType,
                state.externalTransferType,
                state.internalTransferType);

            interviewerLoginState = (LoginState)state.interviewerLoginState;
            LoginToDialerState = (LoginState)state.interviewerLoginToDialerState;
            CallOutcome = (CallOutcome)state.callOutcome;
            InterviewState = (InterviewState)state.interviewState;
            Problems = new CatiProblemStateFactory(new CatiProblemStateInfo(stationId))
                .GetState(state.problemState);
            BreakStartTime = state.breakStartTime;
            CallType = state.callType;
            TransferState = state.transferState;
            TransferOptions = state.transferOptions;
        }

        /// <summary>
        /// Returns string that represent current state
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return String.Format("State: LoginState {0}, LoginToDialerState {1}, InterviewState {2}, CallOutcome {3}, ProblemState '{4}', SurveyId {5}, InterviewId {6} CallType {7}",
                interviewerLoginState,
                LoginToDialerState,
                InterviewState,
                CallOutcome,
                Problems,
                InterviewProperties.SurveyId,
                InterviewProperties.InterviewId,
                CallType
            );
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets/sets current state of interview
        /// </summary>
        public InterviewState InterviewState
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets CallOutcome
        /// </summary>
        public CallOutcome CallOutcome
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets login to dialer state
        /// </summary>
        public LoginState LoginToDialerState
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets login to system state
        /// </summary>
        public LoginState interviewerLoginState
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets InterviewProperties
        /// </summary>
        public InterviewProperties InterviewProperties
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets problems state.
        /// </summary>
        public CatiProblemState Problems
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets interviewer break start time.
        /// </summary>
        public DateTime? BreakStartTime
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets call type.
        /// </summary>
        public CallTypes CallType
        {
            get;
            set;
        }

        public ConsoleTransferState TransferState
        {
            get;
            set;
        }

        public TransferOptions TransferOptions
        {
            get;
            set;
        }

        #endregion

        private string DecryptInterviewUrl(string interviewUrl, byte[] encryptionKey, byte[] encriptionIv)
        {
            // we may receive null or empty string from GetState() as url
            // because url is generated only in Interviewing state
            if (string.IsNullOrEmpty(interviewUrl))
            {
                return interviewUrl;
            }

            string result;
            try
            {
                using (var encryptor = new CatiSymmetricEncryptor())
                {
                    encryptor.Key = encryptionKey;
                    encryptor.IV = encriptionIv;
                    result = encryptor.DecryptString(interviewUrl);
                    encryptor.Clear();
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
                throw;
            }

            return result;
        }
    }
}
