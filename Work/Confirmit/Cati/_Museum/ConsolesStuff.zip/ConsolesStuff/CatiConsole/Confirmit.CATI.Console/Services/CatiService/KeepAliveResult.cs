﻿using System;

namespace Confirmit.CATI.Console.Services.CatiService
{
    /// <summary>
    /// Represents results on KeepAlive method. It's just wrapper for CATI Web Service
    /// KeepAlive results.
    /// </summary>
    public class KeepAliveResult
    {
        /// <summary>
        /// Initializes new instance of KeepAliveResult class and fills it with given value.
        /// </summary>
        /// <param name="result">CATI Web Service KeepAlive results.</param>
        public KeepAliveResult(Common.ConsoleService.KeepAliveResult result)
        {
            UserId = result.m_interviwerSID;
            IsMonitoring = result.m_isMonitored;
            MonitoringSessionId = result.m_monitoringSessionID;
            NewMessage = result.m_NewMessage;
        }

        /// <summary>
        /// User identifier.
        /// </summary>
        public int UserId 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// Gets/sets flag is console in monitoring state.
        /// </summary>
        public bool IsMonitoring 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// Gets/sets monitoring session identifier.
        /// </summary>
        public long MonitoringSessionId
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets flag is new messages for interviewer
        /// If true there are new messages for interviewer
        /// </summary>
        public bool NewMessage
        {
            get;
            set;
        }

        /// <summary>
        /// Returns object string representation.
        /// </summary>
        /// <returns>String.</returns>
        public override string ToString()
        {
            return String.Format(
                "KeepAlive: InterviewerId {0}, IsMonitored {1}, MonitoringSessionId {2}",
                UserId,
                IsMonitoring,
                MonitoringSessionId);
        }
    }
}
