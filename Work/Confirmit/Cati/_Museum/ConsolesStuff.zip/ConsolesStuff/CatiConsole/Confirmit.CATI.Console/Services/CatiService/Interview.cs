﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Confirmit.CATI.Common.ConsoleService.Abstract;

namespace Confirmit.CATI.Console.Services.CatiService
{
	/// <summary>
	/// Represents interview. It is wrapper for InterviewControlData class, which is declared 
	/// in CATI Web Service.
	/// </summary>
	public class Interview
	{
		#region Constructors

		/// <summary>
		/// Initializes new instance of Interview class and fills it with data from
		/// Cati Web Service InterviewControlData object.
		/// </summary>
		/// <param name="interview">CATI Web Service InterviewControlData.</param>
		public Interview(InterviewControlData interview)
		{
			SurveyId = interview.surveyId;
			InterviewId = interview.interviewId;
			RespondentName = interview.respondentName;
			RespondentPhone = interview.respondentPhone;
			Status = interview.status;
            StatusName = interview.statusName;
		}

		public Interview(
			string surveyId,
			int interviewId,
			string respondentName,
			string respondentPhone,
			int status,
            string statusName
		)
		{
			SurveyId = surveyId;
			InterviewId = interviewId;
			RespondentName = respondentName;
			RespondentPhone = respondentPhone;
			Status = status;
            StatusName = statusName;
		}

		#endregion

		#region Properties

		/// <summary>
		/// Survey identifier.
		/// </summary>
		public string SurveyId
		{
			get;
			set;
		}

		/// <summary>
		/// Interview identifier.
		/// </summary>
		public int InterviewId 
		{ 
			get; 
			set; 
		}

		/// <summary>
		/// Respondent name.
		/// </summary>
		public string RespondentName 
		{ 
			get; 
			set; 
		}

		/// <summary>
		/// Respondent phone.
		/// </summary>
		public string RespondentPhone 
		{ 
			get; 
			set; 
		}

		/// <summary>
		/// Status.
		/// </summary>
		public int Status 
		{ 
			get; 
			set; 
		}

        /// <summary>
        /// Status name.
        /// </summary>
        public string StatusName 
        { 
            get; 
            set; 
        }

		#endregion
	}

	/// <summary>
	/// Represents collection of interviews.
	/// </summary>
	public class InterviewCollection : List<Interview>
	{
		#region Constructors

		/// <summary>
		/// Initializes new instance of InterviewCollection class.
		/// </summary>
		public InterviewCollection()
			: base()
		{
		}

		/// <summary>
		/// Initializes new instance of InterviewCollection class and fills it with given
		/// list of CATI Web Service interviews.
		/// </summary>
		/// <param name="interviews">Enumeration with CATI Web Service interviews.</param>
		/// <exception cref="ArgumentNullException">Interview enumeration is null.</exception>
		public InterviewCollection(IEnumerable<InterviewControlData> interviews)
		{
			if (interviews == null)
			{
				throw new ArgumentNullException("interviews");
			}

			foreach (InterviewControlData interview in interviews)
			{
				Add(new Interview(interview));
			}
		}

		#endregion

        #region Methods

        /// <summary>
        /// Sort collection by specified field
        /// </summary>
        /// <param name="propertyName">Field for sorting</param>
        /// <param name="sortDirection">Sort direction</param>
        public void Sort(string  propertyName, ListSortDirection sortDirection)
        {
            if (string.IsNullOrEmpty(propertyName))
            {
                throw new ArgumentException("propertyName");
            }

            PropertyDescriptor property = TypeDescriptor.GetProperties(typeof(Interview)).Find(propertyName, true);

            if (property == null)
            {
                throw new NotSupportedException(propertyName);
            }

            if (property.PropertyType.GetInterface("IComparable") != null)
            {
                this.Sort((a, b) => ((sortDirection == ListSortDirection.Ascending) ? 1 : -1) *
                                    (property.GetValue(a) as IComparable).CompareTo(property.GetValue(b)));
            }
            else
            {
                this.Sort((a, b) => ((sortDirection == ListSortDirection.Ascending) ? 1 : -1) *
                                    property.GetValue(a).ToString().CompareTo(property.GetValue(b).ToString()));                           
            }                                                    
        }

        #endregion
        
    }
}
