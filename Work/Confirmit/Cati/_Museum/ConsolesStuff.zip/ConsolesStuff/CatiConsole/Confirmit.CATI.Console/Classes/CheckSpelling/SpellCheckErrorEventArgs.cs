﻿using System;

namespace Confirmit.CATI.Console.Classes.CheckSpelling
{
    public class SpellCheckErrorEventArgs : EventArgs
    {
        public Exception Error
        { 
            get; 
            set;            
        }
    }
}