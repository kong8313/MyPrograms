﻿using Confirmit.CATI.Common;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using System;
using ConfirmitDialerInterface;

namespace Confirmit.CATI.Console.Services.CatiService
{
    /// <summary>
    /// Represents set of user properties. These properies are taken during CATI
    /// Web Service log in process. It contains user mode and list of CATI Console
    /// properties.
    /// </summary>
    public class UserProperties : IUserProperties
    {
        #region Fields
        
        private bool m_IsCurrentPredictive;
        private object _authenticationKeyLocker = new object();

        #endregion

        #region Constructors

        /// <summary>
        /// We close default constructor.
        /// </summary>
        protected UserProperties()
        {
        }

        /// <summary>
        /// Initializes new instance of UserProperties class and fills it with mode
        /// and console properties.
        /// </summary>
        /// <param name="mode">User mode.</param>
        /// <param name="connectedToDialer">Flag indicates that we are already connected to dialer.</param>
        /// <param name="properties">Array of CATI Console properties.</param>
        public UserProperties(AgentTaskChoiceMode mode, bool connectedToDialer, CatiConsolePropertiesContainer properties)
        {
            UserAssignmentMode = mode;
            ConnectedToDialer = connectedToDialer;
            ConsoleProperties = properties;
        }

        /// <summary>
        /// Initializes new instance of UserProperties class and fills it with given data.
        /// </summary>
        /// <param name="mode">User mode.</param>
        /// <param name="connectedToDialer">Flag indicates that we are already connected to dialer.</param>
        /// <param name="alreadyLoggedIn">Flag indicates that current user already logged in.</param>
        /// <param name="properties">Console properies.</param>
        public UserProperties(AgentTaskChoiceMode mode, bool connectedToDialer, bool alreadyLoggedIn, CatiConsolePropertiesContainer properties)
            : this(mode, connectedToDialer, properties)
        {
            AlreadyLoggedIn = alreadyLoggedIn;
        }

        /// <summary>
        /// Initializes new instance of UserProperties class and fills it with given data.
        /// </summary>
        /// <param name="mode">User mode.</param>
        /// <param name="connectedToDialer">Flag indicates that we are already connected to dialer.</param>
        /// <param name="alreadyLoggedIn">Flag indicates that current user already logged in.</param>
        /// <param name="isPauseResumePlaybackEnabled">Indicates whether pause/resume playback action is available for interviewer</param>
        /// <param name="interviewerId">Interview identifier.</param>
        /// <param name="currentIsPredictive">Flag indicates that current survey is predictive</param>
        /// <param name="currentLoggedInToDialerState">LoggedInToDialer state</param>
        /// <param name="hasExtensionNumber"></param>
        /// <param name="isHangUpEnabled">True if hang up action is available for interviewer otherwise false</param>
        /// <param name="autoSurveyName">Confirmit name (e.g. 'p0000000') of user automatic survey.</param>
        /// <param name="authenticationKey"></param>
        /// <param name="properties">Console properies.</param>
        public UserProperties(
            AgentTaskChoiceMode mode,
            bool connectedToDialer,
            bool alreadyLoggedIn,
            int currentLoggedInToDialerState,
            bool currentIsPredictive,
            bool hasExtensionNumber,
            bool isHangUpEnabled,
            bool isPauseResumePlaybackEnabled,
            bool isToggleVoiceSourceSupported,
            int interviewerId,
            string autoSurveyName,
            TaskChoicePermissions? taskChoicePermissions,
            Guid authenticationKey,
            byte[] encryptionKey,
            byte[] encryptionIV,
            CatiConsolePropertiesContainer properties
           )
            : this(mode, connectedToDialer, alreadyLoggedIn, properties)
        {
            InterviewerId = interviewerId;
            LoginToDialerState = (LoginState)currentLoggedInToDialerState;
            m_IsCurrentPredictive = currentIsPredictive;
            HasStationExtensionNumber = hasExtensionNumber;
            IsHangUpEnabled = isHangUpEnabled;
            AutomaticSurveyName = autoSurveyName;
            TaskChoicePermissions = taskChoicePermissions;
            AuthenticationKey = authenticationKey;
            IsPauseResumePlaybackEnabled = isPauseResumePlaybackEnabled;
            EncryptionKey = encryptionKey;
            EncryptionIV = encryptionIV;
            IsToggleVoiceSourceSupported =
                isToggleVoiceSourceSupported;        }

        #endregion

        #region Properties

        public LoginState LoginToDialerState { get; private set; }

        /// <summary>
        /// Gets interviewer identifier.
        /// </summary>
        public int InterviewerId { get; private set; }

        /// <summary>
        /// Gets flag indicated that user has been working already in system
        /// </summary>
        /// <remarks>
        /// It is used for determine do 'fresh' login 
        /// or continue interviewing process
        /// </remarks>
        public bool AlreadyLoggedIn { get; private set; }

        /// <summary>
        /// Gets user user.
        /// </summary>
        public bool ConnectedToDialer { get; private set; }

        /// <summary>
        /// Gets flag indicated has system extension number or not, 
        /// if hasn't interviwer will be asked about it.        
        /// </summary>
        public bool HasStationExtensionNumber { get; private set; }

        /// <summary>
        /// True if hang up action is available for interviewer otherwise false,
        /// it depends on dialer type.
        /// </summary>
        public bool IsHangUpEnabled { get; private set; }

        /// <summary>
        /// Gets/sets interviewer task choice mode.
        /// </summary>
        public AgentTaskChoiceMode UserAssignmentMode { get; set; }

        /// <summary>
        /// Gets task choice permissions for interviewer
        /// </summary>
        public TaskChoicePermissions? TaskChoicePermissions { get; private set; }

        /// <summary>
        /// Gets CATI Console properties associated with current user.
        /// </summary>
        public CatiConsolePropertiesContainer ConsoleProperties { get; private set; }

        /// <summary>
        /// Gets automatic survey name (e.g. 'p0000000') in survey assignment mode.
        /// </summary>
        public string AutomaticSurveyName { get; private set; }

        /// <summary>
        /// Gets or sets the authentication key for interviewer session used to access console state service.
        /// </summary>
        public Guid AuthenticationKey
        {
            get; 
            private set;
        }

        public byte[] EncryptionKey { get; private set; }

        public byte[] EncryptionIV { get; private set; }

        /// <summary>
        /// Gets a value indicating whether Pause/Resume playback action is available for interviewer otherwise false,
        /// it depends on dialer type.
        /// </summary>
        public bool IsPauseResumePlaybackEnabled { get; private set; }

        /// <summary>
        /// Gets a value indicating whether toggle voice source action is available for interviewer otherwise false,
        /// it depends on dialer type.
        /// </summary>
        public bool IsToggleVoiceSourceSupported { get; private set; }

        #endregion

        #region Methods

        /// <summary>
        /// Updates user assignment mode
        /// </summary>
        /// <param name="newMode"></param>
        public void UpdateUserAssignmentMode(AgentTaskChoiceMode newMode)
        {
            UserAssignmentMode = newMode;
        }

        public void UpdateAuthenticationKey(Guid authenticationKey)
        {
            lock(_authenticationKeyLocker)
            {
                AuthenticationKey = authenticationKey;
            }
        }

        /// <summary>
        /// Method returns true if current survey mode is predictive
        /// </summary>        
        /// <remarks>
        /// Used to restore state after abnormal console termination
        /// </remarks>
        public bool CheckPredictiveModeAfterAbnornalTermination()
        {
            return IsLoggedToDialer() && m_IsCurrentPredictive;
        }

        /// <summary>
        /// Methods identifiers if current user logged in to dialer.
        /// </summary>
        /// <returns>true, if user is logged in; otherwise false.</returns>
        public bool IsLoggedToDialer()
        {
            return LoginToDialerState == LoginState.LOGGED_IN || LoginToDialerState == LoginState.LOGGING_OUT;
        }

        #endregion

    }
}
