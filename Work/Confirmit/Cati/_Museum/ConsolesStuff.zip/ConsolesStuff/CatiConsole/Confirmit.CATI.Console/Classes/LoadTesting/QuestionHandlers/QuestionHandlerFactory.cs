using System;
using System.Collections.Generic;
using System.Globalization;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Controls;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class QuestionHandlerFactory : IQuestionHandlerFactory
    {
        private readonly Dictionary<string, string> _predefinedAnswers;
        private readonly IViewInterviewPageBrowser _pageBrowser;
        private readonly CultureInfo _locale;

        public QuestionHandlerFactory(
            Dictionary<string, string> predefinedAnswers,
            IViewInterviewPageBrowser pageBrowser, 
            CultureInfo locale)
        {
            _predefinedAnswers = predefinedAnswers;
            _pageBrowser = pageBrowser;
            _locale = locale;
        }

        public IQuestionHandler Create()
        {
            if (_pageBrowser.IsResponsiveSurvey)
            {
                return new ResponsiveQuestionHandler(_pageBrowser, _predefinedAnswers, _locale);
            }

            return GetLegacyQuestionHandler();
        }

        private IQuestionHandler GetLegacyQuestionHandler()
        {
            var currentQuestionType = ((ILegacySurveyPageInteractor) _pageBrowser.SurveyPageInteractor).CurrentQuestionType;
            switch (currentQuestionType)
            {
                case QuestionType.DatePicker:
                    return new DateQuestionHandler(_pageBrowser, _predefinedAnswers, _locale);
                case QuestionType.Open:
                    return new OpenQuestionHandler(_pageBrowser, _predefinedAnswers);
                case QuestionType.Simple:
                    return new SimpleQuestionHandler(_pageBrowser, _predefinedAnswers);
                case QuestionType.SearchableMulti:
                    return new SearchableMultiQuestionHandler(_pageBrowser, _predefinedAnswers);
                case QuestionType.Multi:
                    return new MultiQuestionHandler(_pageBrowser, _predefinedAnswers);
                case QuestionType.CaptureOrder:
                case QuestionType.MultiOpen:
                    return new MultiOpenQuestionHandler(_pageBrowser, _predefinedAnswers);
                case QuestionType.Info:
                    return new InfoQuestionHandler(_pageBrowser, _predefinedAnswers);
                case QuestionType.Ranking:
                case QuestionType.RankedOrder:
                    return new RankingQuestionHandler(_pageBrowser, _predefinedAnswers);
                case QuestionType.GridSlider:
                case QuestionType.GridBars:
                case QuestionType.CardSort:
                    return new GridSliderQuestionHandler(_pageBrowser, _predefinedAnswers);
                case QuestionType.Grid:
                    return new GridQuestionHandler(_pageBrowser, _predefinedAnswers);
                case QuestionType.Grid3D:
                    return new Grid3DQuestionHandler(_pageBrowser, _predefinedAnswers);
                default:
                    throw new Exception(string.Format(Strings.Autopilot_QuestionTypeIsNotSupported_Error, currentQuestionType));
            }
        }
    }
}