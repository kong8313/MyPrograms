﻿using Confirmit.CATI.Console.Services.CatiService;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    internal interface IInterviewProperties
    {
        InterviewProperties CurrentInterviewProperties { get; }
    }
}
