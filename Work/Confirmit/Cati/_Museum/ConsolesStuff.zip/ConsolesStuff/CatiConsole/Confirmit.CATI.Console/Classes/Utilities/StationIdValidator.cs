﻿using System;
using System.ComponentModel;
using System.Text.RegularExpressions;
using Confirmit.CATI.Console.Classes.Localization;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    internal class StationIdValidator
    {
        public string Validate(string stationId, CancelEventArgs e)
        {
            const string validMask = @"^[a-zA-Z]{1,8}\d{0,6}L?$";

            if (String.IsNullOrEmpty(stationId) || Regex.IsMatch(stationId, validMask))
            {
                return string.Empty;
            }

            e.Cancel = true;
            return LocalizationManager.Instance.GetString("Error_InvalidStationNumber");
        }
    }
}
