﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyDescription("CATI Interviewer Console application allows CATI person interviewing")]
[assembly: AssemblyTitle("CATI Console")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("b806d36d-ed09-41f6-9141-731e453654e4")]
[assembly: InternalsVisibleTo("Confirmit.CATI.Console.UnitTests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b900a6faa24e303228ff621eb394983c9471ccf803a1caaf380d3b87b4744f1ad5bf1889b9b3ee7ac5cee6a3f10d42e7fbb3f858f8d7140426469d35d847faddcda0efbc3366fc52779195ff64ff4b02633cb1c8a7ef02e00a48357b54970a35c26088e51d35919b7f111fa1ad5ce539f17e2fb323d0660e4220500416347bc8")]
