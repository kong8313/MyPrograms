﻿using System;
using System.Text.RegularExpressions;
using Confirmit.CATI.Common;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.Console.Services.CatiService
{
	/// <summary>
	/// Represents interview properties which could be used during
	/// interview startup.
	/// </summary>
	public class InterviewProperties
    {
        private string _interviewUrl = String.Empty;
        private string _securityId = String.Empty;

        public InterviewProperties()
        {

        }

        /// <summary>
        /// Initializes new instance of InterviewProperties class and fills it
        /// with data from InterviewStartupParameters class.
        /// </summary>
        /// <param name="interviewURL">Confirmit interview url.</param>
        /// <param name="surveyId">Confirmit project identifier (e.g. p1234567).</param>
        /// <param name="surveyName">Confirmit project name (e.g. 'test project').</param>
        /// <param name="interviewId">Interview identifier.</param>
        /// <param name="projectId">Backend survey identifier.</param>
        /// <param name="isRecording">IsRecording flag of interview survey.</param>
        /// <param name="respondentTimezone">Respondent time zone.</param>
        /// <param name="deferredRecordId">Deferred record Id</param>
        /// <param name="callOutcome">Call outcome</param>
        /// <param name="languageVariableValue">Value of language variable</param>
        /// <param name="isNewSurvey">Determines if user is switched to new survey</param>
        /// <param name="callType">Call type: outbound or inbound</param>
        public InterviewProperties(
            string interviewURL, 
            string surveyId, 
            string surveyName, 
            int interviewId, 
            int projectId, 
            bool isRecording, 
            Common.ConsoleService.Abstract.Timezone respondentTimezone, 
            int deferredRecordId,
            int callOutcome, 
            int? languageVariableValue,
            bool isNewSurvey,
            CallTypes callType,
            ExternalTransferType externalTransferType,
            InternalTransferType internalTransferType)
		{
			InterviewURL = interviewURL;
			SurveyId = surveyId;
            SurveyName = surveyName;
			InterviewId = interviewId;
            ProjectId = projectId;
            IsSurveyRecorded = isRecording;
            Has500ErrorOccured = false;
	        DeferredRecordId = deferredRecordId;
            CallOutcome = callOutcome;
	        LanguageVariableValue = languageVariableValue;
	        IsNewSurvey = isNewSurvey;
		    IsInboundCall = callType == CallTypes.Inbound;
            ExternalTransferType = externalTransferType;
            InternalTransferType = internalTransferType;

            if (respondentTimezone != null)
            {
                RespondentTimezone = new Timezone(respondentTimezone);
            }
		}

		/// <summary>
		/// Gets/sets URL to interview.
		/// </summary>
		public string InterviewURL
		{
            get
            {
                return _interviewUrl;
            }

            set
            {
                if (_interviewUrl == value)
                {
                    // The same URL, there is nothing to do
                    return;
                }

                _interviewUrl = value;

                if (String.IsNullOrEmpty(_interviewUrl))
                {
                    // null, there is nothing to do
                    return;
                }

                // A new URL

                var regEx = new Regex("[\\?&]__sid__=(?<sid>[^&#]*)");

                var match = regEx.Match(_interviewUrl);

                if (match != Match.Empty)
                {
                    if (!String.IsNullOrEmpty(match.Groups["sid"].Value))
                    {
                        _securityId = match.Groups["sid"].Value;
                    }
                    else
                    {
                        Logger.Write(Strings.Log_CouldntParseInterviewUrl, MessageTypes.Error);
                    }
                }
                else
                {
                    Logger.Write(Strings.Log_CouldntParseInterviewUrl, MessageTypes.Error);
                }
            }
		}

		/// <summary>
		/// Gets/sets Confirmit survey identifier (e.g. p1234567).
        /// </summary>
        public string SurveyId { get; set; }

        /// <summary>
        /// Gets/sets Confirmit survey name (e.g. 'test project').
        /// </summary>
        public string SurveyName { get; set; }

        public int ProjectId { get; set; }

        public int InterviewId { get; set; }

        public Timezone RespondentTimezone { get; set; }

        /// <summary>
        /// Gets confirmit respondent security identifier. This value is taken from interview
        /// url. If url couldn't be parsed, string is empty.
        /// </summary>
        public string SecurityId
        {
            get
            {
                return _securityId;
            }
        }

        public bool IsSurveyRecorded { get; set; }

        public bool Has500ErrorOccured { get; set; }

        public int DeferredRecordId { get; set; }

	    public int CallOutcome { get; set; }

        public int? LanguageVariableValue { get; set; }

        public bool IsNewSurvey { get; set; }

        public bool IsInboundCall { get; set; }

        public ExternalTransferType ExternalTransferType;

        public InternalTransferType InternalTransferType;

        public bool IsTestMode
        {
            get { return SurveyName.EndsWith("#test", StringComparison.InvariantCultureIgnoreCase); }
        }
    }
}
