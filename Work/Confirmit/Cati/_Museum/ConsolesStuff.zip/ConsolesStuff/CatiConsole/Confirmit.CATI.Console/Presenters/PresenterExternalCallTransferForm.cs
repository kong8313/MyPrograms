﻿using System;
using System.Windows.Forms;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.CallTransfer;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;

namespace Confirmit.CATI.Console.Presenters
{
    internal class PresenterExternalCallTransferForm
    {
        public PresenterExternalCallTransferForm(IViewExternalCallTransferForm externalCallTransferForm, ExternalTransferType transferType)
        {
            ExternalCallTransferForm = externalCallTransferForm ?? throw new ArgumentNullException(nameof(externalCallTransferForm));
            TransferType = transferType == ExternalTransferType.Cold ? ConsoleTransferType.ExternalCold : ConsoleTransferType.ExternalWarm;

            _alerter = ServiceLocator.Resolve<IAlerter>();

            InitEventHandlers();
            InitLocalization();
        }

        public event EventHandler<EventArgs> TransferStart;
        public event StateChangedEventHandler StateChanged;
        public string SelectedResource { get; private set; } = null;

        private IViewExternalCallTransferForm ExternalCallTransferForm { get; }

        private ConsoleTransferType TransferType { get; }

        public string LastUsedTransferTargetPhoneNumber { get; set; }

        private IAlerter _alerter;
        private ICatiServiceManager _catiServiceManager;

        public void ShowDialog(IWin32Window parent, ICatiServiceManager catiServiceManager)
        {
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.ExternalCallTransferFormShownMessage,
                    State = null
                },
                UserPassport.Instance.MonitoringIdentity
            );

            _catiServiceManager = catiServiceManager;

            try
            {
                InitLocalization();

                RefreshTargets();

                ExternalCallTransferForm.SelectRow(LastUsedTransferTargetPhoneNumber);

                ExternalCallTransferForm.Show(parent);

                LastUsedTransferTargetPhoneNumber = ExternalCallTransferForm.Selected.TelephoneNumber;

                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.ExternalCallTransferFormClosedMessage,
                        State = new ExternalCallTransferFormClosedStateData { ConsoleState = ConsoleState.Interviewing }
                    },
                    UserPassport.Instance.MonitoringIdentity);
            }
            catch (Exception ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
            }
        }

        private void RefreshTargets()
        {
            var targets = _catiServiceManager.GetExternalTransferTargets();

            ExternalCallTransferForm.UpdateFormData(targets);
        }

        private void LocalizationManager_CurrentCultureChanged(object sender, EventArgs e)
        {
            LocalizeViews(LocalizationManager.Instance);
        }

        private void InitEventHandlers()
        {
            ExternalCallTransferForm.CallTransferStart += ExternalCallTransferForm_OnTransferStart;
            LocalizationManager.Instance.CurrentCultureChanged += LocalizationManager_CurrentCultureChanged;
        }

        private void ExternalCallTransferForm_OnTransferStart(object sender, EventArgs args)
        {
            var target = ExternalCallTransferForm.Selected?.TelephoneNumber;

            if (String.IsNullOrEmpty(target))
            {
                _alerter.Alert("Please select target", LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"), MessageTypes.Warning);
                return;
            }

            ExternalCallTransferForm.Hide();

            SelectedResource = target;

            TransferStart?.Invoke(this, args);
        }

        private void InitLocalization()
        {
            LocalizeViews(LocalizationManager.Instance);
        }

        private void LocalizeViews(ILocalizationManager manager)
        {
            ExternalCallTransferForm.Localize(manager, TransferType);
        }

        private void OnStateChanged(StateChangedEventArgs e, MonitoringIdentity sessionId)
        {
            StateChanged?.Invoke(this, e, sessionId);
        }
    }
}