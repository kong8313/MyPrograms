﻿using System;
using System.IO;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    /// <summary>
    /// Contains extensions to Stream class.
    /// </summary>
    internal static class StreamExtensions
    {
        /// <summary>
        /// Copies all content of source stream to target stream.
        /// </summary>
        /// <param name="source">Source stream.</param>
        /// <param name="target">Target stream.</param>
        public static void CopyTo(this Stream source, Stream target)
        {
            if (target == null)
            {
                throw new ArgumentNullException("source");
            }

            if (!source.CanRead)
            {
                throw new NotSupportedException("Exception_SourceStreamNotReadable");
            }

            if (!target.CanWrite)
            {
                throw new NotSupportedException("Exception_TargetStreamNotWritable");
            }

            if (source.CanSeek)
            {
                source.Seek(0, SeekOrigin.Begin);
            }

            int size;
            int bufferSize = 1024;
            byte[] buffer = new byte[bufferSize];
            while ((size = source.Read(buffer, 0, bufferSize)) != 0)
            {
                target.Write(buffer, 0, size);
            }
        }
    }
}
