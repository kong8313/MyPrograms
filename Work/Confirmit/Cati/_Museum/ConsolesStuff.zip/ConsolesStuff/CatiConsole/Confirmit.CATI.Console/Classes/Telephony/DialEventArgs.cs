﻿using System;

namespace Confirmit.CATI.Console.Classes.Telephony
{
    /// <summary>
    /// Delegate for Dial event.
    /// </summary>
    /// <param name="sender">Sender object.</param>
    /// <param name="e">Dial event arguments.</param>
    internal delegate void DialEventHandler(object sender, DialEventArgs e);

    /// <summary>
    /// Contains arguments of Dial event.
    /// </summary>
    internal class DialEventArgs : EventArgs
    {
        #region Properties

        /// <summary>
        /// Gets/sets dial message.
        /// </summary>
        public string DialMessage
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets phone number.
        /// </summary>
        public string Phone
        {
            get;
            set;
        }

        #endregion
    }
}
