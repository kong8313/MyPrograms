﻿using System;
using System.Threading;
using System.Globalization;
using System.Resources;
using System.Reflection;
using Confirmit.CATI.Console.Views.Classes.Localization;

namespace Confirmit.CATI.Console.Classes.Localization
{
	/// <summary>
	/// Represents class which manages application current culture and
	/// resources.
	/// </summary>
	internal class LocalizationManager : ILocalizationManager
	{
		#region Fields

		private static LocalizationManager m_Instance = null;
		private static string m_ResourceFileBaseName = "Confirmit.CATI.Console.Resources.CatiInterviewerConsoleUITexts";

		#endregion

		#region Constructors

		/// <summary>
		/// Initialiazes new instance of LocalizationManager class.
		/// </summary>
		protected LocalizationManager()
		{
		}

		#endregion

		#region Properties

		/// <summary>
		/// Returns instance of LocalizationManager class.
		/// </summary>
		public static LocalizationManager Instance
		{
			get
			{
				if (m_Instance == null)
				{
					m_Instance = new LocalizationManager();
				}

				return m_Instance;
			}
		}

		#endregion

		#region ILocalizationManager Members

		/// <summary>
		/// Gets/sets the current application culture. 
		/// </summary>
		public CultureInfo CurrentCulture
		{
			get
			{
                return Thread.CurrentThread.CurrentCulture;
			}
			set
			{
                bool isNew = !Object.Equals(value, Thread.CurrentThread.CurrentCulture);
                Thread.CurrentThread.CurrentCulture = value;
			    Thread.CurrentThread.CurrentUICulture = value;

				if (isNew)
				{
					OnCurrentCultureChanged(EventArgs.Empty);
				}
			}
		}

		/// <summary>
		/// Occurs when application culture is changed.
		/// </summary>
		public event EventHandler<EventArgs> CurrentCultureChanged;

		/// <summary>
		/// Returns the value of the specified String resource.
		/// </summary>
		/// <param name="name">The name of the resource to get.</param>
		/// <returns>The value of the resource localized for the caller's current culture settings. 
		/// If a match is not possible, null is returned.
		/// </returns>
		public string GetString(string name)
		{
			ResourceManager manager = new ResourceManager(
				m_ResourceFileBaseName, 
				Assembly.GetExecutingAssembly()
			);

			return manager.GetString(name);
		}

		/// <summary>
		/// Returns the value of the specified String resource formated with specified
		/// arguments.
		/// </summary>
		/// <param name="name">The name of the resource to get.</param>
		/// <param name="args">An Object array containing zero or more objects to format.</param>
		/// <returns>The value of the resource localized for the caller's current culture settings. 
		/// If a match is not possible, null is returned.
		/// </returns>
		public string GetString(string name, params object[] args)
		{
			ResourceManager manager = new ResourceManager(
				m_ResourceFileBaseName,
				Assembly.GetExecutingAssembly()
			);

			return String.Format(manager.GetString(name), args);
		}

		#endregion

		#region Methods

		/// <summary>
		/// Fires CurrentCultureChanged event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnCurrentCultureChanged(EventArgs e)
		{
			if (CurrentCultureChanged != null)
			{
				CurrentCultureChanged(this, e);
			}
		}

		#endregion
	}
}
