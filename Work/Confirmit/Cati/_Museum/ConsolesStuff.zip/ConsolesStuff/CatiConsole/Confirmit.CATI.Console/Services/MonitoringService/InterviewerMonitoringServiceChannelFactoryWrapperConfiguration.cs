﻿using System.Collections.Generic;
using System.ServiceModel.Description;

using Confirmit.CATI.Common.SideBySide;
using Confirmit.CATI.Common.WcfTools;
using Confirmit.CATI.Common.WcfTools.ConsoleMessageHeader;

namespace Confirmit.CATI.Console.Services.MonitoringService
{
    /// <summary>
    /// ChannelFactoryWrapper configuration for interviewer monitoring web service.
    /// </summary>
    public class InterviewerMonitoringServiceChannelFactoryWrapperConfiguration : IChannelFactoryWrapperConfiguration
    {
        #region Implementation of IChannelFactoryWrapperConfiguration

        private readonly int _companyId;
        private readonly string _userName;
        private readonly string _password;

        /// <summary>
        /// Initializes a new instance of the <see cref="InterviewerMonitoringServiceChannelFactoryWrapperConfiguration"/> class.
        /// </summary>
        /// <param name="companyId">The company ID.</param>
        /// <param name="userName">User login name.</param>
        /// <param name="password">User password.</param>
        public InterviewerMonitoringServiceChannelFactoryWrapperConfiguration(int companyId, string userName, string password)
        {
            _companyId = companyId;
            _userName = userName;
            _password = password;
        }

        /// <summary>
        /// Gets the name of the endpoint configuration (in config file).
        /// </summary>
        public string EndpointConfigurationName
        {
            get
            {
                return "MonitoringServiceEndpoint";
            }
        }

        public string AdjustEndpointUri(string originalUrl)
        {
            return new SideBySideManager().AddSideBySideNameToBackendWCFServiceUrl(originalUrl) + _companyId;
        }

        public bool UseLogicalAddressReplacementForHttps()
        {
            return true;
        }

        /// <summary>
        /// Gets the endpoint behaviors to add.
        /// <see langword="null"/> means do not add any behaviors.
        /// </summary>
        public IEnumerable<IEndpointBehavior> EndpointBehaviors
        {
            get
            {
                return new[]
                {
                    new AuthorizationMessageHeaderBehavior(_userName, _password)
                };
            }
        }

        /// <summary>
        /// Gets the caching strategy used by the channel factory wrapper.
        /// </summary>
        public CachingStrategy CachingStrategy
        {
            get
            {
                return CachingStrategy.FactoryAndChannels;
            }
        }

        /// <summary>
        /// Gets a value indicating whether all method calls and their timings should be logged.
        /// </summary>
        public bool LogAllCalls
        {
            get
            {
                return Properties.Settings.Default.EnableWfcCallsLog;
            }
        }

        /// <summary>
        /// Gets a value indicating whether all exceptions thrown during method calls execution should be logged.
        /// </summary>
        public bool LogExceptions
        {
            get
            {
                return true;
            }
        }
        
        public bool KeepAliveEnabled => false;

        /// <summary>
        /// Initializes the client credentials (login / password).
        /// </summary>
        /// <param name="credentials">The client credentials object to set.</param>
        public void InitializeClientCredentials(ClientCredentials credentials)
        {
        }

        #endregion
    }
}