﻿using Confirmit.CATI.Common;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.Sender;
using Confirmit.CATI.Console.Presenters;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Views.Forms;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public class ServiceLocatorRegistry : IServiceLocatorRegistry
    {
        public void RegisterTypes(IServiceRegistrator serviceRegistrator)
        {
            serviceRegistrator.RegisterSingleton<IViewMainForm, MainForm>();
            serviceRegistrator.Register<IAlerter, Alerter>();
            serviceRegistrator.Register<ILogger, Logger>();
            serviceRegistrator.Register<IKeepAliver, KeepAliver>();
            serviceRegistrator.RegisterSingleton<IEventSender, EventSender>();
            serviceRegistrator.Register<ITelephonyProvider, BackendTelephonyProvider>();
            serviceRegistrator.Register<ITaskChoiceRouter, TaskChoiceRouter>();
            serviceRegistrator.RegisterSingleton<ICatiServiceManager, CatiServiceManager>();
            serviceRegistrator.RegisterSingleton<IAuthenticationData, AuthenticationData>();
            serviceRegistrator.RegisterSingleton<ICatiServiceHelper, CatiServiceHelper>();
            serviceRegistrator.Register<IInitializeApplication, InitializeApplication>();
            serviceRegistrator.Register<IGetStateStopwatch, GetStateStopwatch>();
            serviceRegistrator.Register<IConsoleProperties, ConsoleProperties>();
        }
    }
}
