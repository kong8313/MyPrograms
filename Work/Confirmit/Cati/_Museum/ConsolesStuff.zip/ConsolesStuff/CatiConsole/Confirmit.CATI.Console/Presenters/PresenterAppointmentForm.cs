﻿using System;
using System.ComponentModel;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Console.Classes.User;
using System.Windows.Forms;
using System.Globalization;
using System.Collections.Generic;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Services.CatiService.Exceptions;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;

using ConfirmitDialerInterface;
using Appointment = Confirmit.CATI.Console.Services.CatiService.Appointment;
using Timezone = Confirmit.CATI.Console.Services.CatiService.Timezone;

namespace Confirmit.CATI.Console.Presenters
{
	/// <summary>
	/// Represents presenter entity for AppointmentForm.
	/// </summary>
	internal class PresenterAppointmentForm : IMonitorable
	{
	    private string m_SurveyId;
		private int m_InterviewId;
		private Timezone m_RespondentTimezone;
		private Timer m_Timer = null;
        private AgentTaskChoiceMode m_UserAssignmentMode;
        private bool m_EditExistent = false;
	    private IAlerter _alerter;

	    /// <summary>
		/// Initializes new instance of PresenterAppointmentForm class and fills it with
		/// given data.
		/// </summary>
		/// <param name="appointmentForm"></param>
		public PresenterAppointmentForm(IViewAppointmentForm appointmentForm)
		{
			if (appointmentForm == null)
			{
				throw new ArgumentNullException("appointmentForm");
			}

			AppointmentForm = appointmentForm;
			Logout = false;
		    Initiator = Initiator.MainMenu;

	        _alerter = ServiceLocator.Resolve<IAlerter>();

            InitEventHandlers();
			InitTimer();
			InitLocalization();
		}

	    /// <summary>
		/// Occurs when appointment form is closed.
		/// </summary>
		public event EventHandler<EventArgs> FormClose;

        /// <summary>
        /// Occurs when user opens interviewer appointments form.
        /// </summary>
        public event EventHandler<EventArgs> ShowInterviewerAppointmensForm;

	    /// <summary>
		/// Retruns instance of IViewAppointmentForm interface.
		/// </summary>
		internal IViewAppointmentForm AppointmentForm 
		{ 
			get; 
			set; 
		}

		/// <summary>
		/// Gets/sets appointment.
		/// </summary>
		public Appointment Appointment
		{
			get;
			set;
		}

		/// <summary>
		/// Flag indicates that we should log out after appointment creation.
		/// </summary>
		public bool Logout
		{
			get;
			set;
		}

        /// <summary>
        /// Gets/sets reason why user close form.
        /// </summary>
        public AppointmentFormCloseReasons CloseResult
        {
            get;
            set;
        }

        public Initiator Initiator
        {
            get; 
            private set; 
        }

        private void AppointmentForm_OkClick(object sender, EventArgs e)
        {
            try
            {
                FillAppointmentObject();
                SaveAppointment();
                AppointmentForm.CloseForm(DialogResult.OK);

                Logout = AppointmentForm.Logout;
            }
            catch (CatiAppContradictsExclusionShiftsException ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Allert_ErrorCaption"));
            }
            catch (CatiAppTimeIsOutOfShiftsException ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Allert_ErrorCaption"));
            }
            catch (CatiServiceException ex)
            {
                _alerter.Alert(
                    LocalizationManager.Instance.GetString("Error_GeneralCatiWSException", ex.Error, ex.Message),
                    LocalizationManager.Instance.GetString("Allert_ErrorCaption"),
                    MessageTypes.Error
                );
            }
            catch (Exception ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Allert_ErrorCaption"));
            }
            finally
            {
                if (!Logout)
                {
                    AppointmentForm.FormResult = FormCloseReasons.None;
                }
            }
        }		

		private void AppointmentForm_ValidatingAppointmentTime(object sender, CancelEventArgs e)
		{
			DateTime dt;

			if (String.IsNullOrEmpty(AppointmentForm.AppointmentTime))
			{
				AppointmentForm.AlertValidationError(
					AppointmentValidationControls.AppointmentTime,
					LocalizationManager.Instance.GetString("Error_TimeCantBeEmptyMessage")
				);

				e.Cancel = true;
			}
			// try parse time as current culture short time format
			else if (
				!TryParseTime(AppointmentForm.AppointmentTime, out dt)
			)
			{
				AppointmentForm.AlertValidationError(
					AppointmentValidationControls.AppointmentTime,
					LocalizationManager.Instance.GetString("Error_WrongTimeFormatMessage")
				);
				e.Cancel = true;
			}
		}

		private void AppointmentForm_ValidatingExpirationTime(object sender, CancelEventArgs e)
		{
			DateTime dt;

			if (String.IsNullOrEmpty(AppointmentForm.ExpirationTime))
			{
				AppointmentForm.AlertValidationError(
					AppointmentValidationControls.ExpirationTime,
					LocalizationManager.Instance.GetString("Error_TimeCantBeEmptyMessage")
				);

				e.Cancel = true;
			}
			// try parse time as current culture short time format
			else if (
				!TryParseTime(AppointmentForm.ExpirationTime, out dt)
			)
			{
				AppointmentForm.AlertValidationError(
					AppointmentValidationControls.ExpirationTime,
					LocalizationManager.Instance.GetString("Error_WrongTimeFormatMessage")
				);
				e.Cancel = true;
			}
		}

		private void AppointmentForm_ValidatingExpirationDate(object sender, CancelEventArgs e)
		{
			if (AppointmentForm.ExpirationDate.Date < DateTime.Now.Date)
			{
				AppointmentForm.AlertValidationError(
					AppointmentValidationControls.ExpirationDate,
					LocalizationManager.Instance.GetString("Error_ElderDateMessage")
				);
				e.Cancel = true;
			}
		}

		private void AppointmentForm_ValidatingAppointmentDate(object sender, CancelEventArgs e)
		{
			if (AppointmentForm.AppointmentDate.Date < DateTime.Now.Date)
			{
				AppointmentForm.AlertValidationError(
					AppointmentValidationControls.AppointmentDate,
					LocalizationManager.Instance.GetString("Error_ElderDateMessage")
				);
				e.Cancel = true;
			}
		}

		private void AppointmentForm_NeverExpireChanged(object sender, EventArgs e)
		{
			AppointmentForm.EnableExpirationTimeControls(!AppointmentForm.NeverExpire);

			OnStateChanged(
				new StateChangedEventArgs
				{
					MessageType = MonitoringMessageTypes.AppointmentFormExpireChangedMessage,
					State = new CheckControlStateData
					{
						ControlName = ((Control)sender).Name,
						Checked = AppointmentForm.NeverExpire
					}
				},
                UserPassport.Instance.MonitoringIdentity
			);
		}

        void AppointmentForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            CloseResult = ConvertFormCloseReason(AppointmentForm.FormResult);

            if (Initiator == Initiator.Script && CloseResult != AppointmentFormCloseReasons.Ok)
            {
                e.Cancel = true;
            }
        }

		private void AppointmentForm_FormClose(object sender, EventArgs e)
		{
			OnStateChanged(
				new StateChangedEventArgs
				{
					MessageType = MonitoringMessageTypes.AppointmentFormCloseMessage,
					State = new AppointmentCloseStateData
					{
						ControlName = "AppointmentForm",
						CloseReason = CloseResult
					}
				},
                UserPassport.Instance.MonitoringIdentity
			);

            OnFormClose(EventArgs.Empty);
		}

	    void AppointmentForm_ShowInterviewerAppointmens(object sender, EventArgs e)
        {
            OnShowInterviewerAppointmens(EventArgs.Empty);  
        }

		private void m_Timer_Tick(object sender, EventArgs e)
		{
			DateTime now = DateTime.Now;

			AppointmentForm.RespondentTime = 
				TimezoneConverter.ConvertTimeFromUtc(
					m_RespondentTimezone, 
					now.ToUniversalTime()
				).ToLongTimeString();
			AppointmentForm.InterviewerTime = now.ToLongTimeString();
		}

		private void LocalizationManager_CurrentCultureChanged(object sender, EventArgs e)
		{
			LocalizeViews(LocalizationManager.Instance);
		}

		private void AppointmentForm_AppointmentDateChanged(object sender, EventArgs e)
		{
			OnStateChanged(
				new StateChangedEventArgs
				{
					MessageType = MonitoringMessageTypes.AppointmentFormAppointmentDateChangedMessage,
					State = new DateControlStateData(((Control)sender).Name, AppointmentForm.AppointmentDate)
                },
                UserPassport.Instance.MonitoringIdentity
			);
		}

		private void AppointmentForm_AppointmentTimeChanged(object sender, EventArgs e)
		{
			OnStateChanged(
				new StateChangedEventArgs
				{
					MessageType = MonitoringMessageTypes.AppointmentFormAppointmentTimeChangedMessage,
					State = new TextControlStateData(((Control)sender).Name, AppointmentForm.AppointmentTime)
                },
                UserPassport.Instance.MonitoringIdentity
			);
		}

		private void AppointmentForm_ExpirationDateChanged(object sender, EventArgs e)
		{
			OnStateChanged(
				new StateChangedEventArgs
				{
					MessageType = MonitoringMessageTypes.AppointmentFormExpirationDateChangedMessage,
					State = new DateControlStateData(((Control)sender).Name, AppointmentForm.ExpirationDate)
                },
                UserPassport.Instance.MonitoringIdentity
			);
		}

		private void AppointmentForm_ExpirationTimeChanged(object sender, EventArgs e)
		{
			OnStateChanged(
				new StateChangedEventArgs
				{
					MessageType = MonitoringMessageTypes.AppointmentFormExpirationTimeChangedMessage,
					State = new TextControlStateData(((Control)sender).Name, AppointmentForm.ExpirationTime)
                },
                UserPassport.Instance.MonitoringIdentity
			);
		}

		private void AppointmentForm_LogoutChanged(object sender, EventArgs e)
		{
			OnStateChanged(
				new StateChangedEventArgs
				{
					MessageType = MonitoringMessageTypes.AppointmentFormLogoutChangedMessage,
					State = new CheckControlStateData
					{
						ControlName = ((Control)sender).Name,
						Checked = AppointmentForm.Logout
					}
                },
                UserPassport.Instance.MonitoringIdentity
			);
		}

        private void AppointmentForm_AllowAppointmentsOutsideShiftChanged(object sender, EventArgs e)
		{
			OnStateChanged(
				new StateChangedEventArgs
				{
                    MessageType = MonitoringMessageTypes.AppointmentFormAllowAppointmentsOutsideShiftChangedMessage,
					State = new CheckControlStateData
					{
						ControlName = ((Control)sender).Name,
						Checked = AppointmentForm.AllowAppointmentsOutsideShifts
					}
                },
                UserPassport.Instance.MonitoringIdentity
			);
		}

        private CatiConsolePropertiesContainer CatiConsoleProperties
        {
            get { return UserPassport.Instance.Properties.ConsoleProperties; }
        }

        /// <summary>
        /// Handles ValidatingForm event of Appointment form. It is cancellable event.
        /// If there are errors during validation, we set cancel flag to true.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">Cancellable event arguments.</param>
		private void AppointmentForm_ValidatingForm(object sender, CancelEventArgs e)
		{
			DateTime appointment;
            DateTime? dt;

            try
            {
                appointment = GetAppointmentTime(true);
            }
            catch(ArgumentException)//this time doesn't exist in this time zone
            {
                AppointmentForm.AlertValidationError(AppointmentValidationControls.AppointmentTime,
                    LocalizationManager.Instance.GetString("Error_InvalidTimeForSpecificTimeZone")
                );

                e.Cancel = true;
                return;
            }

            try
            {
                dt = GetExpirationTime(true);
            }
            catch(ArgumentException)//this time doesn't exist in this time zone
            {
                AppointmentForm.AlertValidationError(AppointmentValidationControls.ExpirationTime,
                    LocalizationManager.Instance.GetString("Error_InvalidTimeForSpecificTimeZone")
                );

                e.Cancel = true;
                return;
            }

            DateTime utcNow = DateTime.UtcNow;

            if (appointment < utcNow)
			{
				AppointmentForm.AlertValidationError(AppointmentValidationControls.AppointmentTime,
                    LocalizationManager.Instance.GetString("Error_DateElderThanRespondentNow")
				);
				e.Cancel = true;
			}

            if (dt.HasValue && dt.Value <= appointment)
			{
				AppointmentForm.AlertValidationError(AppointmentValidationControls.ExpirationTime,
					LocalizationManager.Instance.GetString("Error_ExpirationElderThanAppointment")
				);
				e.Cancel = true;
			}
		}

	    /// <summary>
		/// Occurs when control changes it's state and this change should be
		/// reflected during monitoring.
		/// </summary>
        public event StateChangedEventHandler StateChanged;

        /// <summary>
        /// Returns current state of monitorable object.
        /// </summary>
        /// <returns>Object state data.</returns>
        public BaseStateData GetState()
        {
            return new AppointmentInitialStateData
            {
                AppointmentDate = AppointmentForm.AppointmentDate,
                AppointmentTime = AppointmentForm.AppointmentTime,
                ControlName = "AppointmentForm",
                ExpirationDate = AppointmentForm.ExpirationDate,
                ExpirationTime = AppointmentForm.ExpirationTime,
                Logout = AppointmentForm.Logout,
                NeverExpire = AppointmentForm.NeverExpire,
                CurrentInterviewerTime = DateTime.Now,
                CurrentRespondentTime = (m_RespondentTimezone == null ? 
                    DateTime.Now :
                    TimezoneConverter.ConvertTimeFromUtc(m_RespondentTimezone, DateTime.UtcNow)
                ),
                ShowAppointmentsOutsidePermittedShiftTime = CatiConsoleProperties.EnableAbilityToCreateAppointmensOutsideOfThePermittedShiftTimes
            };
        }

	    public void ShowDialog(
            string surveyId, int interviewId, Timezone respondentTimezone, AgentTaskChoiceMode assignmentMode, bool showLinkToInterviewerAppointments, IWin32Window parent, Initiator initiator)
		{
			m_SurveyId = surveyId;
			m_InterviewId = interviewId;
			m_RespondentTimezone = respondentTimezone;
            m_UserAssignmentMode = assignmentMode;
            Initiator = initiator;

			try
			{
                AppointmentForm.ShowLinkToInterviewerAppointments = showLinkToInterviewerAppointments;
                AppointmentForm.ShowAppointmentsOutsidePermittedShiftTime = CatiConsoleProperties.EnableAbilityToCreateAppointmensOutsideOfThePermittedShiftTimes;

				Appointment = CatiServiceManagerWrapper.GetAppointment(m_SurveyId, m_InterviewId);

                m_EditExistent = (Appointment != null);
                InitLocalization();

				AppointmentForm.SuppressEvents = true;
				FillAppointmentForm();
				AppointmentForm.SuppressEvents = false;

			    OnStateChanged(
					new StateChangedEventArgs
					{
						MessageType = MonitoringMessageTypes.AppointmentFormInitialMessage,
						State = GetState()
                    },
                    UserPassport.Instance.MonitoringIdentity
				);

			    if (Initiator == Initiator.Script)
			    {
			        AppointmentForm.ControlBox = false;
			        AppointmentForm.HideCancelButton();
			    }

			    AppointmentForm.Show(parent);
			}
			catch (Exception ex)
			{
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
			}
		}

		/// <summary>
		/// Fills appointment form with the data, taken from Appointment property of
		/// current presenter.
		/// </summary>
		private void FillAppointmentForm()
		{
			string[] time = GeneratePredefinedTimeList();
			AppointmentForm.BindAppointmentTimeList(time);
			AppointmentForm.BindExpirationTimeList(time);
            
            if (Appointment == null)
			{
				AppointmentForm.AppointmentDate = DateTime.Now;
				AppointmentForm.AppointmentTime = String.Empty;
				AppointmentForm.ExpirationDate = DateTime.Now;
				AppointmentForm.ExpirationTime = String.Empty;
				AppointmentForm.NeverExpire = true;
				AppointmentForm.EnableExpirationTimeControls(false);
			}
			else
			{
                DateTime appointmentTime = TimezoneConverter.ConvertTimeFromUtc(
					m_RespondentTimezone,
					Appointment.AppointmentTime
				);

				AppointmentForm.AppointmentDate = appointmentTime.Date;
				AppointmentForm.AppointmentTime = appointmentTime.ToShortTimeString();
				if (Appointment.ExpirationTime == null)
				{
					AppointmentForm.ExpirationDate = DateTime.Now;
					AppointmentForm.ExpirationTime = String.Empty;
					AppointmentForm.NeverExpire = true;
					AppointmentForm.EnableExpirationTimeControls(false);
				}
				else
				{
                    DateTime expirationTime = TimezoneConverter.ConvertTimeFromUtc(
							m_RespondentTimezone,
							Appointment.ExpirationTime.Value
					);
					AppointmentForm.ExpirationDate = expirationTime.Date;
					AppointmentForm.ExpirationTime = expirationTime.ToShortTimeString();
					AppointmentForm.NeverExpire = false;
					AppointmentForm.EnableExpirationTimeControls(true);
				}
			}
		}

		/// <summary>
		/// Fills Appointment property with data taken from appointment form.
		/// </summary>
		private void FillAppointmentObject()
		{
			Appointment = new Appointment(
				0,
				String.Empty,
				GetAppointmentTime(true),
				GetExpirationTime(true)
			);
		}

		/// <summary>
		/// Returns full appointment date and time. Data are taken from appointment form.
		/// We return date in UTC.
		/// </summary>
		/// <param name="convertToGMT">If true, function converts date and time to GMT;
		/// otherwise returns local date and time.</param>
		/// <returns>Appointment time.</returns>
		private DateTime GetAppointmentTime(bool convertToGMT)
		{
			DateTime dt;
			TryParseTime(AppointmentForm.AppointmentTime, out dt);
			DateTime result = AppointmentForm.AppointmentDate.Date.Add(dt.TimeOfDay);

			if (convertToGMT)
			{
				return TimezoneConverter.ConvertTimeToUtc(m_RespondentTimezone, result);
			}
			else
			{
				return result;
			}
		}

		/// <summary>
		/// Returns full expiration date and time. Data are taken from appointment form.
		/// If flag "Never expire" is set, returns null. We return date in UTC.
		/// </summary>
		/// <param name="convertToUtc">If true, function converts date and time to GMT;
		/// otherwise returns local date and time.</param>
		/// <returns>Null or expiration time.</returns>
		private DateTime? GetExpirationTime(bool convertToGMT)
		{
			if (AppointmentForm.NeverExpire)
			{
				return null;
			}
			else
			{
				DateTime dt;
				TryParseTime(AppointmentForm.ExpirationTime, out dt);

				DateTime result = AppointmentForm.ExpirationDate.Date.Add(dt.TimeOfDay);

				if (convertToGMT)
				{
                    return TimezoneConverter.ConvertTimeToUtc(m_RespondentTimezone, result);
				}
				else
				{
					return result;
				}
			}
		}

        /// <summary>
        /// Saves appointment.
        /// </summary>
        private void SaveAppointment()
        {
            CatiServiceManagerWrapper.SetAppointment(
                this.m_SurveyId,
                this.m_InterviewId, 
                this.Appointment,
                this.AppointmentForm.AllowAppointmentsOutsideShifts);
        }

        /// <summary>
        /// Initializes event handlers.
        /// </summary>
        private void InitEventHandlers()
        {
            AppointmentForm.OkClick += AppointmentForm_OkClick;
            AppointmentForm.ValidatingAppointmentDate += AppointmentForm_ValidatingAppointmentDate;
            AppointmentForm.ValidatingAppointmentTime += AppointmentForm_ValidatingAppointmentTime;
            AppointmentForm.ValidatingExpirationDate += AppointmentForm_ValidatingExpirationDate;
            AppointmentForm.ValidatingExpirationTime += AppointmentForm_ValidatingExpirationTime;
            AppointmentForm.NeverExpireChanged += AppointmentForm_NeverExpireChanged;
            AppointmentForm.FormClose += AppointmentForm_FormClose;
            AppointmentForm.FormClosing += AppointmentForm_FormClosing;
            AppointmentForm.ShowInterviewerAppointmens += AppointmentForm_ShowInterviewerAppointmens;
            AppointmentForm.AppointmentDateChanged += AppointmentForm_AppointmentDateChanged;
            AppointmentForm.AppointmentTimeChanged += AppointmentForm_AppointmentTimeChanged;
            AppointmentForm.ExpirationDateChanged += AppointmentForm_ExpirationDateChanged;
            AppointmentForm.ExpirationTimeChanged += AppointmentForm_ExpirationTimeChanged;
            AppointmentForm.LogoutChanged += AppointmentForm_LogoutChanged;
            AppointmentForm.ValidatingForm += AppointmentForm_ValidatingForm;
            AppointmentForm.AllowAppointmentsOutsideShiftChanged += AppointmentForm_AllowAppointmentsOutsideShiftChanged;
            LocalizationManager.Instance.CurrentCultureChanged += LocalizationManager_CurrentCultureChanged;
        }

		/// <summary>
		/// Initialiazes timer object which is used for respondent and interviewer showing.
		/// </summary>
		private void InitTimer()
		{
			m_Timer = new Timer();
			m_Timer.Interval = 1000;
			m_Timer.Tick += new EventHandler(m_Timer_Tick);
			m_Timer.Start();
		}

		/// <summary>
		/// Generates list of predefined time values for time selection controls.
		/// For now function generates time from 00:00 with 30 min step.
		/// </summary>
		/// <returns></returns>
		private string[] GeneratePredefinedTimeList()
		{
			DateTime tmp = new DateTime(2008, 11, 12, 0, 0, 0);
			TimeSpan step = new TimeSpan(0,30,0);
			List<string> result = new List<string>();

			while (tmp.Day != 13)
			{
				result.Add(tmp.ToShortTimeString());
				tmp = tmp.Add(step);
			}

			return result.ToArray();
		}

		/// <summary>
		/// Fires FormClose event.
		/// </summary>
		/// <param name="e">Event arguments.</param>
		private void OnFormClose(EventArgs e)
		{
			if (FormClose != null)
			{
				FormClose(this, e);
			}
		}

        /// <summary>
        /// Fires ShowInterviewerAppointmensForm event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnShowInterviewerAppointmens(EventArgs e)
        {
            if (ShowInterviewerAppointmensForm != null)
            {
                ShowInterviewerAppointmensForm(this, e);
            }
        }

		/// <summary>
		/// Fires StateChanged event.
		/// </summary>
		/// <param name="e"></param>
		private void OnStateChanged(StateChangedEventArgs e, MonitoringIdentity sessionId)
		{
			if (StateChanged != null)
			{
				StateChanged(this, e, sessionId);
			}
		}

		/// <summary>
		/// Initializes localization according setting in config file.
		/// </summary>
		private void InitLocalization()
		{
			LocalizeViews(LocalizationManager.Instance);

            if (m_EditExistent)
            {
                AppointmentForm.DialogDescription = LocalizationManager.Instance.GetString("AppointmentForm_TitleDescriptionExistentAppointment");
            }
            else
            {
                AppointmentForm.DialogDescription = LocalizationManager.Instance.GetString("AppointmentForm_TitleDescription");
            }  
		}

		/// <summary>
		/// Localizes views according current localization settings.
		/// </summary>
		/// <param name="manager">Manager providing localization info.</param>
		private void LocalizeViews(ILocalizationManager manager)
		{
			AppointmentForm.Localize(manager);
		}

		/// <summary>
		/// Converts the specified string representation of a time to its DateTime equivalent.
		/// </summary>
		/// <param name="time">A string containing a time to convert.</param>
		/// <param name="date">When this method returns, contains the DateTime value equivalent 
		/// to time contained in time string, if the conversion succeeded, or MinValue if the 
		/// conversion failed. The conversion fails if the s parameter is null reference
		/// , or does not contain a valid string representation of a date and time. 
		/// This parameter is passed uninitialized.</param>
		/// <returns>true if the s parameter was converted successfully; otherwise, false.</returns>
		private bool TryParseTime(string time, out DateTime date)
		{
			return DateTime.TryParseExact(
				time,
				"t",
				CultureInfo.CurrentCulture,
				DateTimeStyles.None,
				out date
			);
		}

		/// <summary>
		/// Converts appointment form close reason from form view type to monitoring type.
		/// </summary>
		/// <param name="reason">Form view close reason.</param>
		/// <returns>Monitoring type close reason.</returns>
        private AppointmentFormCloseReasons ConvertFormCloseReason(FormCloseReasons reason)
        {
            AppointmentFormCloseReasons result = AppointmentFormCloseReasons.Ok;

            if (reason == FormCloseReasons.Cancel || reason == FormCloseReasons.None)
            {
                result = AppointmentFormCloseReasons.Cancel;
            }

            return result;
		}
	}
}
