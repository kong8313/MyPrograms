﻿using System;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Classes.Telephony;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Console.Shared.Resources;

using ConfirmitDialerInterface;

namespace Confirmit.CATI.Console.Presenters
{
    /// <summary>
    /// Represents presenter entity for DialContol and HangupControl.
    /// </summary>
    internal class PresenterTelephony
    {
        private const int CustomErrorStatus = (int)CallOutcome.Error;

        private IViewDialControl m_DialView;
        private IViewHangupControl m_HangupView;
        private readonly ITelephonyProvider m_TelephonyProvider;

        /// <summary>
        /// Constructs new instance of PresenterTelephony class and fills it with the given data.
        /// </summary>
        /// <param name="dialView">Dial view interface.</param>
        /// <param name="hangupView">Hang up view interface.</param>
        /// <param name="telephonyProvider"></param>
        public PresenterTelephony(IViewDialControl dialView, IViewHangupControl hangupView, ITelephonyProvider telephonyProvider)
        {
            if (dialView == null)
            {
                throw new ArgumentNullException("dialView");
            }

            if (hangupView == null)
            {
                throw new ArgumentNullException("hangupView");
            }

            m_DialView = dialView;
            m_HangupView = hangupView;
            m_TelephonyProvider = telephonyProvider;

            InitEventHandlers();
        }

        public bool IsCustomDialerUsed
        {
            get 
            { 
                return m_TelephonyProvider.IsCustomDialer;
            }
        }

        public string ExtensionNumber
        {
            get;
            set;
        }

        /// <summary>
        /// Occurs when we recieve telephony command result status.
        /// </summary>
        public event TelephonyResultEventHandler TelephonyResult
        {
            add { m_TelephonyProvider.TelephonyResult += value; }
            remove { m_TelephonyProvider.TelephonyResult -= value; }
        }

        /// <summary>
        /// Occurs when console logged in to dialer 
        /// </summary>
        /// <remarks>
        /// Initially method LoginToDialer is called
        /// Event occurs when GetState returns Logged_In state
        /// </remarks>
        public event EventHandler<GetStateEventArgs> LoggedToDialerInEvent
        {
            add { m_TelephonyProvider.LoggedToDialerInEvent += value; }
            remove { m_TelephonyProvider.LoggedToDialerInEvent -= value; }
        }

        /// <summary>
        /// Occurs when interviewer is logged out by system
        /// </summary>
        /// <remarks>
        /// Initially method LoginToDialer is called
        /// Event occurs when GetState returns Not_Logged_In state for interviewer
        /// </remarks>
        public event EventHandler<GetStateEventArgs> LogoutWhileLoginToDialerEvent
        {
            add { m_TelephonyProvider.LogoutWhileLoginToDialerEvent += value; }
            remove { m_TelephonyProvider.LogoutWhileLoginToDialerEvent -= value; }
        }

        /// <summary>
        /// Occurs when timeout for command LoginToDialer is expired
        /// </summary>
        public event EventHandler<GetStateEventArgs> LoginToDialerErrorEvent
        {
            add { m_TelephonyProvider.LoginToDialerErrorEvent += value; }
            remove { m_TelephonyProvider.LoginToDialerErrorEvent -= value; }
        }

        private void LocalizationManager_CurrentCultureChanged(object sender, EventArgs e)
        {
            LocalizeViews(LocalizationManager.Instance);
        }
         
        /// <summary>
        /// Initializes dialing process.
        /// </summary>
        /// <param name="phone">Phone number.</param>
        /// <param name="message">Dial message.</param>
        public void Dial(string phone, string message)
        {
            m_TelephonyProvider.Dial(phone, message);

            m_DialView.Phone = phone;
            m_DialView.Message = message;
            m_DialView.HangupMessage = LocalizationManager.Instance.GetString("DialControl_HangupDialing_Text");
        }

        public void Redial(string phone, string message)
        {
            m_TelephonyProvider.Redial(phone, message);

            m_DialView.Phone = phone;

            if (String.IsNullOrEmpty(message) == false)
            {
                m_DialView.Message = message;
            }
            else
            {
                m_DialView.Message = String.Format(
                       "{0} {1}",
                       LocalizationManager.Instance.GetString("DialControl_Phone_Text"),
                       phone);
            }

            m_DialView.HangupMessage = LocalizationManager.Instance.GetString("DialControl_HangupDialing_Text");
        }

        /// <summary>
        /// Initializes hang up process.
        /// </summary>
        public int Hangup(Initiator initiator)
        {
            int result = CustomErrorStatus;

            try
            {
                Logger.Write(Strings.ResourceManager.GetString("Log_HangUpInvokedFrom", initiator), 
                    MessageTypes.Information);

                if (m_TelephonyProvider.Hangup(initiator))
                {
                    result = (int)CallOutcome.Completed;
                }
                else
                {
                    Logger.Write( Strings.Log_HangUpReturnFalse, MessageTypes.Warning );
                }
            }
            catch (Exception /*ex*/)
            {
                // exception occurs. Suppress it and return custom error
            }

            return result;
        }

        /// <summary>
        /// Starts playback sound file.
        /// </summary>
        /// <param name="soundFile"></param>
        /// <param name="timeOfPlayingInSeconds"></param>
        public void StartPlayback(string soundFile, out int timeOfPlayingInSeconds)
        {
            timeOfPlayingInSeconds = 0;
            try
            {
                m_TelephonyProvider.StartPlayback(soundFile, out timeOfPlayingInSeconds);
            }
            catch (Exception)
            {
                Logger.Write(
                    Strings.ResourceManager.GetString("Log_PlaySoundFileFailed", soundFile), MessageTypes.Warning);
            }
        }

        /// <summary>
        /// Pauses or resumes playback sound file.
        /// </summary>
        public void PauseOrResumePlayback()
        {
            try
            {
                m_TelephonyProvider.PauseOrResumePlayback();
            }
            catch (Exception)
            {
                // Exception occured. Log it and continue, the operation crash is not critical.
                Logger.Write( Strings.Log_PauseResumePlayingFileFailed, MessageTypes.Warning );
            }
        }

        /// <summary>
        /// Stops playback sound file.
        /// </summary>
        public void StopPlayback()
        {
            try
            {
                m_TelephonyProvider.StopPlayback();
            }
            catch (Exception)
            {
                // Exception occured. Log it and continue, the operation crash is not critical.
                Logger.Write( Strings.Log_StopPlayingFileFailed, MessageTypes.Warning );
            }
        }

        /// <summary>
        /// Switchs agent from hear respondent to hear playing and back.
        /// </summary>
        public void ToggleInterviewerListensToPlaybackOrRespondent()
        {
            try
            {
                CatiServiceManagerWrapper.ToggleInterviewerListensToPlaybackOrRespondent();
                Logger.Write(Strings.ToggleInterviewerListensToPlaybackOrRespondentCalled, MessageTypes.Information);
            }
            catch (Exception ex)
            {
                // Exception occured. Log it and continue, the operation crash is not critical.
                Logger.Write(
                    Strings.ResourceManager.GetString("Log_ToggleInterviewerListensToPlaybackOrRespondentFailed", ex), MessageTypes.Warning);
            }
        }

        /// <summary>
        /// Calls web service LoginToDialer method.
        /// </summary>
        /// <param name="surveyId">Survey id for LoginToDialer method</param>
        /// <param name="isPredictiveMode"></param>
        public void LoginToDialer(string surveyId, out bool isPredictiveMode)
        {
            m_TelephonyProvider.LoginToDialer(ExtensionNumber, surveyId, out isPredictiveMode);
        }
        
        /// <summary>
        /// Initializes event handlers.
        /// </summary>
        private void InitEventHandlers()
        {
            LocalizationManager.Instance.CurrentCultureChanged += LocalizationManager_CurrentCultureChanged;
        }

        /// <summary>
        /// Localizes views according current localization settings.
        /// </summary>
        /// <param name="localizationManager">Manager providing localization info.</param>
        private void LocalizeViews(LocalizationManager localizationManager)
        {
            m_DialView.Localize(localizationManager);
            m_HangupView.Localize(localizationManager);
        }
    }
}
