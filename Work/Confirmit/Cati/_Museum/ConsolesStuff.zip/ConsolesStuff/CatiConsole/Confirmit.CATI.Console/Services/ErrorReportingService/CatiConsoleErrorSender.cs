﻿using Confirmit.CATI.Common;
using Confirmit.CATI.Common.Contracts.ErrorReportingService;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.Console.Services.ErrorReportingService
{
    public class CatiConsoleErrorSender : IErrorSender
    {
        public void SendErrorMessage(IErrorReportingService serviceInstance, string companyAlias, ClientErrorSource source, string errorMessage, byte[] hash)
        {
            serviceInstance.SendConsoleErrorMessage(companyAlias, source, errorMessage, hash);
        }
    }
}
