﻿using System;
using Confirmit.TelephonyProblemStates.ProblemState;

namespace Confirmit.CATI.Console.Services.CatiService
{
    /// <summary>
    /// Delegate for GetStateError event;
    /// </summary>
    /// <param name="sender">Sender object.</param>
    /// <param name="e">Event arguments.</param>
    public delegate void GetStateErrorEventHandler(object sender, GetStateErrorEventArgs e);

    /// <summary>
    /// Represents arguments of GetStateError event.
    /// </summary>
    public class GetStateErrorEventArgs : EventArgs
    {
        #region Constructors

        /// <summary>
        /// Initializes new instance of GetStateErrorEventArgs class.
        /// </summary>
        public GetStateErrorEventArgs()
        {
        }

        /// <summary>
        /// Initializes new instance of GetStateErrorEventArgs class and fills it with given data.
        /// </summary>
        /// <param name="state">Problem state returned by GetState method.</param>
        public GetStateErrorEventArgs(CatiProblemState state)
        {
            ProblemState = state;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Problem state returned by GetState method.
        /// </summary>
        public CatiProblemState ProblemState 
        { 
            get; 
            set; 
        }

        #endregion
    }
}
