using System;
using Confirmit.CATI.Console.Presenters;

namespace Confirmit.CATI.Console
{
    internal class TelephonyProviderFactory
    {
        public ITelephonyProvider Create()
        {
            if (string.IsNullOrEmpty(ClientSettings.Default.CustomDialerPath) ||
                string.IsNullOrEmpty(ClientSettings.Default.CustomDialerType))
            {
                return new BackendTelephonyProvider();
            }
            else
            {
                return new CustomTelephonyProvider(ClientSettings.Default.CustomDialerPath, ClientSettings.Default.CustomDialerType);
            }
        }
    }
}