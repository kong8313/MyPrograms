﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public interface IInitializeApplication
    {
        void InitClientSettings();

        void InitLogging(string logPostfix);
    }
}
