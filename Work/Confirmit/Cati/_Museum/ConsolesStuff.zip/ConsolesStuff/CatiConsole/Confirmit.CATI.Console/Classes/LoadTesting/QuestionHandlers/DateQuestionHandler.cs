using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class DateQuestionHandler : BaseQuestionHandler, IQuestionHandler
    {
        private readonly CultureInfo _locale;

        public DateQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers, CultureInfo locale)
            : base(pageBrowser, predefinedAnswers)
        {
            _locale = locale;
        }

        void IQuestionHandler.SetAnswers()
        {
            var key = PredefinedAnswers.Keys.FirstOrDefault(x => x.Equals(QuestionId));

            if (string.IsNullOrEmpty(key))
            {
                throw new KeyNotFoundException(string.Format(Strings.Autopilot_NoAnswersFound_Error, QuestionId));
            }

            try
            {
                SetAnswer(key, TryToHandleAsDateTime(PredefinedAnswers[key]));
            }
            catch (FormatException)
            {
                throw new FormatException(string.Format(Strings.Autopilot_DateQuestionWrongLocale_Error, QuestionId));
            }
        }

        private string TryToHandleAsDateTime(string value)
        {
            var datePattern = string.Empty;
            PageBrowserUpdater.Run(() => { datePattern = PageBrowser.GetDatePickerDatePattern(); });

            if (string.IsNullOrEmpty(datePattern))
            {
                return value;
            }

            var dateValue = DateTime.Parse(value, _locale);
            value = dateValue.ToString(datePattern);

            return value;
        }
    }
}