using System;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Resources;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public class DateTimeManager
    {
        public static readonly DateTime DefaultTimeInShiftInUtc = new DateTime(1899, 12, 30, 0, 0, 0);

        public static string ParseDateTime(object value, bool convertToUtcFromLocalTimezone)
        {
            var dateTime = DateTime.Parse((string) value);

            string dataTimeValue;
            var dateTimeInUtc = TimeZoneInfo.ConvertTimeToUtc(dateTime, TimeZoneInfo.Local);

            if (dateTimeInUtc == DefaultTimeInShiftInUtc)
            {
                dataTimeValue = Strings.Now;
            }
            else
            {
                if (convertToUtcFromLocalTimezone)
                {
                    dateTime = dateTimeInUtc;
                }

                dataTimeValue = dateTime.ToString("g", LocalizationManager.Instance.CurrentCulture);                
            }

            return dataTimeValue;
        }
    }
}