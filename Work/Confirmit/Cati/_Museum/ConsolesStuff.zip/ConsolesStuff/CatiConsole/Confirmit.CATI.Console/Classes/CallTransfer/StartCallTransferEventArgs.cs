﻿using System;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.CallTransfer
{
    internal class StartCallTransferEventArgs : EventArgs
    {
        public TransferOptions Options { get; set; }
    }
}
