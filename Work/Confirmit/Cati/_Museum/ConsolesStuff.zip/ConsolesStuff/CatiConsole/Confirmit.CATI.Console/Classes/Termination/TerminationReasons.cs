﻿namespace Confirmit.CATI.Console.Classes.Termination
{
    /// <summary>
    /// Represents reasons why user terminate interview.
    /// </summary>
    internal enum TerminationReasons
    {
        /// <summary>
        /// Terminate interview after appointment.
        /// </summary>
        Appointment = 1,

        /// <summary>
        /// Terminate interview.
        /// </summary>
        Terminate = 6,

        /// <summary>
        /// Terminate interview after external call transfer.
        /// </summary>
        ExternalTransfer = 1011
    }
}
