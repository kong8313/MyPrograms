﻿using System;

namespace Confirmit.CATI.Console.Classes.Telephony
{
    /// <summary>
    /// Delegate for TelephonyResult event.
    /// </summary>
    /// <param name="sender">Sender object.</param>
    /// <param name="e">Event arguments.</param>
    /// <returns></returns>
    public delegate void TelephonyResultEventHandler(object sender, TelephonyResultEventArgs e);

    /// <summary>
    /// Contains arguments for TelephonyResult event.
    /// </summary>
    public class TelephonyResultEventArgs : EventArgs
    {
        #region Properties

        /// <summary>
        /// Gets/sets result status of telephony command.
        /// </summary>
        public int Status
        {
            get;
            set;
        }

        #endregion
    }
}
