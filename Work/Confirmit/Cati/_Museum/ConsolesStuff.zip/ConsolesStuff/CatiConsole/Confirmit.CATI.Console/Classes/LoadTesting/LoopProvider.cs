using System.Collections.Generic;
using System.Linq;

namespace Confirmit.CATI.Console.Classes.LoadTesting
{
    public class LoopProvider
    {
        private readonly List<Loop> _loop = new List<Loop>();
        private string _questionIdRequestedAtFirst = string.Empty;
        private int _currentLoopItem;
        private Loop _currentLoop = new Loop();

        public LoopProvider(List<Loop> loopAnswers)
        {
            if (loopAnswers != null)
            {
                _loop = loopAnswers;
            }
        }

        public bool IsLoopExists
        {
            get
            {
                return _loop != null && _loop.Any();
            }
        }

        public Dictionary<string, string> GetLoopItemByQuestionId(string questionId)
        {
            var result = new Dictionary<string, string>();
            var loop = _loop.FirstOrDefault(
                x => x.Keys.Any(
                    z =>
                        z.Equals(questionId) ||
                        z.StartsWith(questionId + "_")));

            if (loop == null)
            {
                return result;
            }

            if (_currentLoop.Equals(loop) == false)
            {
                _questionIdRequestedAtFirst = string.Empty;
                _currentLoopItem = 0;
                _currentLoop = loop;
            }

            // Case occures if we jump to next item of loop
            if (_questionIdRequestedAtFirst.Equals(questionId))
            {
                _currentLoopItem++;
            }

            result = loop.GetAnswers(_currentLoopItem);

            // we set this once when we are trying to get loop item 
            // for paticular loop by questioId first time
            if (string.IsNullOrEmpty(_questionIdRequestedAtFirst))
            {
                _questionIdRequestedAtFirst = questionId;
            }

            return result;
        }
    }
}