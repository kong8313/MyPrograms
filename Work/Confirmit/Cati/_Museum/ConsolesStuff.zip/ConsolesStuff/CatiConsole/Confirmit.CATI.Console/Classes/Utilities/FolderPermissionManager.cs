﻿using System;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public static class FolderPermissionManager
    {
        /// <summary>
        /// Add "Full control" access permission for built in 'Users' group
        /// </summary>
        /// <remarks>
        /// Permissions are inherited by subfolders and files
        /// </remarks>        
        /// <param name="folder">Path to folder in the system</param>
        /// <param name="logException">If true exception will be logged othewise false</param>
        public static void SetFullControlForStandardUsers(string folder, bool logException)
        {
            try
            {
                var directoryInfo = new DirectoryInfo(folder);

                DirectorySecurity directorySecurity = directoryInfo.GetAccessControl();

                var allUsersSid = new SecurityIdentifier(WellKnownSidType.BuiltinUsersSid, null);

                //access to this folder and subfolders
                var ruleFullAccessToContainers = new FileSystemAccessRule(allUsersSid,
                                                     FileSystemRights.FullControl,
                                                     InheritanceFlags.ContainerInherit,
                                                     PropagationFlags.None,
                                                     AccessControlType.Allow);

                //access to objects in the folder
                var ruleFullAccessToObjects = new FileSystemAccessRule(allUsersSid,
                                                     FileSystemRights.FullControl,
                                                     InheritanceFlags.ObjectInherit,
                                                     PropagationFlags.None,
                                                     AccessControlType.Allow);

                directorySecurity.AddAccessRule(ruleFullAccessToContainers);
                directorySecurity.AddAccessRule(ruleFullAccessToObjects);

                directoryInfo.SetAccessControl(directorySecurity);

            }
            catch (Exception ex)
            {
                if (logException)
                {
                    Logger.Write(ex);
                }
            }
        }
    }
}
