﻿using System;
using Confirmit.CATI.Common.ConsoleService.Abstract;

namespace Confirmit.CATI.Console.Classes.CheckSpelling
{
    public class SpellCheckCompletedEventArgs : EventArgs
    {
        public SpellError[] SpellErrors
        {
            get;
            set;
        }
    }
}