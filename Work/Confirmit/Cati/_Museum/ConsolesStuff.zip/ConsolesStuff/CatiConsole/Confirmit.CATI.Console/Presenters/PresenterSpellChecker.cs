﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Common.Exceptions;
using Confirmit.CATI.Console.Classes.CheckSpelling;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Console.Views.Classes.SpellChecking;
using System.Windows.Forms;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Console.Classes.Localization;

namespace Confirmit.CATI.Console.Presenters
{
    /// <summary>
    /// Represents Presenter for SpellChecker form.
    /// </summary>
    public class PresenterSpellChecker
    {
        private ISpellCheckerView spellCheckerView;
        private ISpellCheckService spellCheckService;

        public PresenterSpellChecker(ISpellCheckerView spellCheckerView, 
                                     ISpellCheckService spellCheckService, 
                                     IEnumerable<QuestionTextBlock> textBlocks)
        {          

            this.spellCheckerView = spellCheckerView;
            this.spellCheckService = spellCheckService;
            TextBlocks = textBlocks.ToList();

            Errors = new List<SpellError>();
            IgnoreWords = new List<String>();
            
            InitEventHandlers();
        } 

        /// <summary>
        /// Occurs when spell check is complete and all changes should be saved.
        /// </summary>
        public event EventHandler SaveOnFormClosed; 

        #region Properties
        
        /// <summary>
        /// Gets/sets collection of text blocks
        /// </summary>
        public List<QuestionTextBlock> TextBlocks
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets/sets current text block (question/subquestion text)
        /// </summary>
        private string CurrentTextBlock
        {
            get
            {
                return TextBlocks[CurrentTextBlockIndex].Value;
            }
            set
            {
                TextBlocks[CurrentTextBlockIndex].Value = value;
            }
        }
        
        private List<SpellError> Errors
        {
            get;
            set;
        }

        private List<String> IgnoreWords
        {
            get;
            set;
        }

        private int CurrentTextBlockIndex
        {
            get;
            set;
        }

        private int CurrentErrorIndex
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets index of the current word in the text.
        /// </summary>
        private int CurrentWordIndex
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets current misspelled word
        /// </summary>
        private string CurrentMisspelledWord
        {
            get;
            set;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Shows spell checker dialog.
        /// </summary>
        public void ShowDialog(IWin32Window parent)
        {
            InitLocalization();
            spellCheckerView.Show(parent);
        }
        
        public void StartWork()
        {
            if (TextBlocks.Count() > 0)
            {
                CurrentTextBlockIndex = 0;
                HandleTextBlock();
            }
            else
            {
                spellCheckerView.ShowCompletionScreen();
            }
        }

        /// <summary>
        /// Starts text block validation by user.
        /// </summary>
        /// <remarks>
        /// This method will be called for each text block.
        /// </remarks>
        private void StartUserValidation()
        {
            if (Errors.Count > 0)
            {
                NavigateToFirstError();
            }
            else
            {
                NavigateToNextTextBlock();
            }
        }

        /// <summary>
        /// Initializes localization according setting in config file.
        /// </summary>
        private void InitLocalization()
        {            
            spellCheckerView.Localize(LocalizationManager.Instance);
        }

        private void InitEventHandlers()
        {            
            spellCheckerView.IgnoreWord += spellCheckerView_IgnoreWord;
            spellCheckerView.IgnoreAllWords += spellCheckerView_IgnoreAllWords;
            spellCheckerView.DeleteWord += spellCheckerView_DeleteWord;
            spellCheckerView.ChangeWord += spellCheckerView_ChangeWord;
            spellCheckerView.ChangeAllWords += spellCheckerView_ChangeAllWords;

            spellCheckerView.FormLoaded += spellCheckerView_Loaded;
            spellCheckerView.FormClose += spellCheckerView_FormClose;
            spellCheckService.SpellCheckError += spellCheckService_SpellCheckError;
            spellCheckService.SpellCheckCompleted += spellCheckService_SpellCheckCompleted;
        }        

        private void NavigateToNextTextBlock()
        {
            if (CurrentTextBlockIndex < TextBlocks.Count - 1)
            {
                IgnoreWords.Clear();
                CurrentTextBlockIndex++;
                HandleTextBlock();
            }
            else
            {
                spellCheckerView.ShowCompletionScreen();
            }
        }        

        /// <summary>
        /// Handles curretn text block.
        /// </summary>
        private void HandleTextBlock()
        {
            spellCheckerView.ShowLoadingScreen();
            spellCheckService.StartCheckSpelling(CurrentTextBlock);
        }

        private void NavigateToFirstError()
        {
            CurrentErrorIndex = 0;
            CurrentWordIndex = 0;

            HandleError(CurrentErrorIndex);
        }

        private void NavigateToNextError()
        {
            if (CurrentErrorIndex < Errors.Count - 1)
            {
                CurrentErrorIndex++;
                HandleError(CurrentErrorIndex);
            }
            else
            {
                NavigateToNextTextBlock();
            }
        }

        /// <summary>
        /// Handlers specified by index error
        /// </summary>
        /// <param name="errorIndex">Index of error in the Errors collection</param>
        private void HandleError(int errorIndex)
        {
            if (errorIndex < 0 || errorIndex >= Errors.Count)
            {
                throw new ArgumentOutOfRangeException("errorIndex");
            }

            var error = Errors[errorIndex];

            if (ShouldWordBeIgnored(error.MisspelledWord))
            {
                NavigateToNextError();
            }
            else
            {
                CurrentMisspelledWord = error.MisspelledWord;

                CurrentWordIndex = TextModifier.GetWordIndex(CurrentTextBlock, CurrentMisspelledWord, CurrentWordIndex);

                spellCheckerView.InitTextBlock(CurrentTextBlock,
                                               CurrentWordIndex,
                                               CurrentMisspelledWord,
                                               error.Suggestions,
                                               error.ErrorType == ErrorType.RepeatedWord);
            }                       
        }

        /// <summary>
        /// Checks is the word present in IgnoreWords list or not.
        /// </summary>
        /// <param name="word">Word for check.</param>
        /// <returns>True if specified word is present in IgnoreWords list.</returns>
        private bool ShouldWordBeIgnored(string word)
        {
            return IgnoreWords.Contains(word);
        }

        private void OnSaveOnFormClosed(EventArgs args)
        {
            if (SaveOnFormClosed != null)
            {
                SaveOnFormClosed(this, args);
            }
        }              

        #endregion

        #region Event handlers

        private void spellCheckerView_Loaded(object sender, EventArgs e)
        {
            StartWork();
        }

        private void spellCheckerView_FormClose(object sender, EventArgs e)
        {
            if (spellCheckerView.FormResult == FormCloseReasons.Ok)
            {
                OnSaveOnFormClosed(EventArgs.Empty);
            }
        }

        private void spellCheckService_SpellCheckError(object sender, SpellCheckErrorEventArgs e)
        {
            var errorMessage = LocalizationManager.Instance.GetString("Error_CheckSpellingServiceCommunicationError");

            if (e.Error is SpellCheckerLanguageIsNotSupportedException)
            {
                errorMessage = LocalizationManager.Instance.GetString("Error_CheckSpellingLanguageIsNotSupported");
            }

            spellCheckerView.ShowErrorScreen(errorMessage);
        }        

        private void spellCheckService_SpellCheckCompleted(object sender, SpellCheckCompletedEventArgs e)
        {
            Errors = e.SpellErrors.ToList();
            StartUserValidation();
        }       

        private void spellCheckerView_IgnoreWord(object sender, EventArgs e)
        {
            MoveWordIndexToNextWord();
            NavigateToNextError();
        }

        private void spellCheckerView_IgnoreAllWords(object sender, EventArgs e)
        {
            IgnoreWords.Add(CurrentMisspelledWord);
            MoveWordIndexToNextWord();            
            NavigateToNextError();
        }        

        private void MoveWordIndexToNextWord()
        {
            CurrentWordIndex = TextModifier.GetFirstWordIndexFromPosition(CurrentTextBlock, CurrentWordIndex);
        }

        private void spellCheckerView_ChangeWord(object sender, ChangeEventArgs e)
        {
            CurrentTextBlock = TextModifier.ChangeWord(CurrentTextBlock, CurrentMisspelledWord, e.SuggestedWord, CurrentWordIndex);
            NavigateToNextError();
        }

        private void spellCheckerView_ChangeAllWords(object sender, ChangeEventArgs e)
        {
            var suggestedWord = e.SuggestedWord;

            CurrentTextBlock = TextModifier.ChangeAllWords(CurrentTextBlock, CurrentMisspelledWord, suggestedWord);
            IgnoreWords.Add(CurrentMisspelledWord);

            NavigateToNextError();
        }        

        private void spellCheckerView_DeleteWord(object sender, EventArgs e)
        {
            CurrentTextBlock = TextModifier.DeleteWord(CurrentTextBlock, CurrentMisspelledWord, CurrentWordIndex);

            NavigateToNextError();
        }

        #endregion                  
    }
}