﻿using System;

using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Common.ServiceLocation;

namespace Confirmit.CATI.Console.Services.CatiService
{
    /// <summary>
    /// Represents intermediate level between application and Fusion Web Service.
    /// </summary>
    public static class CatiServiceManagerWrapper
    {
        private static readonly ICatiServiceManager _catiServiceManager;

        static CatiServiceManagerWrapper()
        {
            _catiServiceManager = ServiceLocator.Resolve<ICatiServiceManager>();
        }

        /// <summary>
        /// Returns apointment for given interview.
        /// </summary>
        /// <param name="surveyId">Survey identifier.</param>
        /// <param name="interviewId">Interview identifier.</param>
        /// <returns>Appointment if exists; otherwise null.</returns>
        public static Appointment GetAppointment(string surveyId, int interviewId)
        {
            return _catiServiceManager.GetAppointment(surveyId, interviewId);
        }

        /// <summary>
        /// Returns all apointments for current interviewer.
        /// </summary>
        public static SupervisorMessageCollection GetMessages()
        {
            return _catiServiceManager.GetMessages();
        }

        /// <summary>
        /// Returns all spelling errors for specified text block.
        /// </summary>
        public static SpellError[] CheckTextSpelling(int languageId, string textBlock)
        {
            return _catiServiceManager.CheckTextSpelling(languageId, textBlock);
        }

        /// <summary>
        /// Saves given appointment to given interview. If given appointment is null,
        /// removes previous saved appointment.
        /// </summary>
        /// <param name="surveyId">Survey identifier.</param>
        /// <param name="interviewId">Interview identifier.</param>
        /// <param name="appointment">Appointment to save.</param>
        /// <param name="allowOutsideShift">Flag indicates whether we should check
        /// that appointment belongs to some existing shift.</param>
        public static void SetAppointment(
            string surveyId,
            int interviewId,
            Appointment appointment,
            bool allowOutsideShift)
        {
            _catiServiceManager.SetAppointment(surveyId, interviewId, appointment, allowOutsideShift);
        }

        /// <summary>
        /// Notifies Web Service that client is still connected.
        /// </summary>
        public static KeepAliveResult KeepAlive()
        {
            return _catiServiceManager.KeepAlive();
        }

        /// <summary>
        /// Switchs agent from hear respondent to hear playing and back.
        /// </summary>
        public static void ToggleInterviewerListensToPlaybackOrRespondent()
        {
            _catiServiceManager.ToggleInterviewerListensToPlaybackOrRespondent();
        }

        /// <summary>
        /// Sends monitoring events to Monitoring service.
        /// </summary>
        /// <param name="companyId">Company identifier.</param>
        /// <param name="interviewerId">Interviewer identifier.</param>
        /// <param name="monitoringIdentity">Monitoring session identity object.</param>
        /// <param name="packet"></param>
        public static void SaveLiveMonitoringEvents(int companyId,
            int interviewerId,
            MonitoringIdentity monitoringIdentity,
            byte[] packet)
        {
            _catiServiceManager.SaveLiveMonitoringEvents(companyId, interviewerId, monitoringIdentity, packet);
        }

        /// <summary>
        /// Sends monitoring events to Monitoring service.
        /// </summary>
        /// <param name="companyId">Company identifier.</param>
        /// <param name="interviewerId">Interviewer identifier.</param>
        /// <param name="monitoringIdentity">Monitoring session identity object.</param>
        /// <param name="packet"></param>
        /// <param name="hasFinishedMessage">if the packet contains one of the finishing events</param>
        /// <param name="firstEventUtc">Utc time of the fist event in the packet</param>
        public static void SaveDeferredMonitoringEvents(int companyId,
            int interviewerId,
            MonitoringIdentity monitoringIdentity,
            byte[] packet,
            bool hasFinishedMessage,
            DateTime firstEventUtc)
        {
            _catiServiceManager.SaveDeferredMonitoringEvents(companyId, interviewerId, monitoringIdentity, packet, hasFinishedMessage, firstEventUtc);
        }

        public static void RemoveRecordIfEmpty(int deferredRecordId)
        {
            _catiServiceManager.RemoveRecordIfEmpty(deferredRecordId);
        }
    }
}
