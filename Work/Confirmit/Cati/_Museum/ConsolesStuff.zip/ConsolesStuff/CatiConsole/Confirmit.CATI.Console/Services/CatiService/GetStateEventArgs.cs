﻿using System;
using System.ComponentModel;

namespace Confirmit.CATI.Console.Services.CatiService
{
    /// <summary>
    /// Delegate for GetState event.
    /// </summary>
    /// <param name="e">CancelEventArgs.</param>
    /// <remarks>
    /// If e.Cancel will be set to true, execution will be finished.
    /// </remarks>
    internal delegate void GetStateEventHandler(GetStateEventArgs e);

    /// <summary>
    /// Class contains State of interviewing process
    /// </summary>
    /// <remarks>
    /// Method WS.GetState returns that state
    /// </remarks>
    public class GetStateEventArgs : CancelEventArgs
    {
        /// <summary>
        /// Gets/sets current state.
        /// </summary>
        public ProcessState State
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets exception object which may occur during GetState call.
        /// </summary>
        public Exception Exception
        {
            get;
            set;
        }
    }
}
