using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Views.Controls;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using mshtml;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    class SimpleQuestionHandler : BaseQuestionHandler, IQuestionHandler
    {
        private readonly ILegacySurveyPageInteractor _interactor;

        public SimpleQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers) : base(pageBrowser, predefinedAnswers)
        {
            _interactor = (ILegacySurveyPageInteractor) PageBrowser.SurveyPageInteractor;
        }

        protected IList<IHTMLElement> GetCurrentQuestionInputs()
        {
            return _interactor.CurrentQuestionInputs;
        }

        void IQuestionHandler.SetAnswers()
        {
            var answerKey = PredefinedAnswers.Keys.FirstOrDefault(x => x.Equals(QuestionId));

            if (string.IsNullOrEmpty(answerKey))
            {
                throw new KeyNotFoundException(string.Format(Strings.Autopilot_NoAnswersFound_Error, QuestionId));
            }

            var input =
                GetCurrentQuestionInputs()
                    .FirstOrDefault(x => x.id.Equals(answerKey, StringComparison.OrdinalIgnoreCase));

            if (input != null)
            {
                SetAnswer(answerKey, PredefinedAnswers[answerKey]);
            }
            else
            {
                SetAnswer(string.Format("{0}_{1}", answerKey, PredefinedAnswers[answerKey]), "true");
            }

            var otherAnswerKey = PredefinedAnswers.Keys.FirstOrDefault(x => x.Equals(string.Format("{0}_{1}_other", answerKey, PredefinedAnswers[answerKey])));
            
            if (string.IsNullOrEmpty(otherAnswerKey) == false)
            {
                SetAnswer(string.Format("{0}", otherAnswerKey), PredefinedAnswers[otherAnswerKey]);
            }
        }
    }
}