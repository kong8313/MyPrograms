﻿using System;
using System.Linq;
using System.Xml.Linq;
using System.Collections.Generic;
using Confirmit.CATI.Common;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.Console.Services.CatiService
{
    /// <summary>
    /// Represents different utilities from Cati WS.
    /// </summary>
    internal static class CatiServiceUtilities
    {
        /// <summary>
        /// Parses inner xml of SoapException thrown by Cati WS.
        /// This xml contains error code and error description.
        /// </summary>
        /// <param name="description">Inner xml of exception.</param>
        /// <param name="error">Returns corresponding error code.</param>
        /// <param name="errorDescription">Returns error description.</param>
        /// <returns>true, if parameters were parsed; otherwise false.</returns>
        public static bool ParseSoapError(string xml, out CATIErrorCodes error, out string errorDescription)
        {
            bool result = false;
            error = CATIErrorCodes.InternalError;
            errorDescription = String.Empty;

            if (!String.IsNullOrEmpty(xml))
            {
                try
                {
                    XDocument doc = XDocument.Parse(xml);
                    IEnumerable<string> errorCodes =
                        from item in doc.Root.Attributes() where item.Name.LocalName == "customCode" select item.Value;

                    foreach (string err in errorCodes)
                    {
                        int tmp;
                        if (Int32.TryParse(err, out tmp))
                        {
                            if (Enum.IsDefined(typeof(CATIErrorCodes), tmp))
                            {
                                error = (CATIErrorCodes)tmp;
                                result = true;
                                break;
                            }
                        }
                    }

                    if (result)
                    {
                        foreach (string details in
                            from item in doc.Root.Attributes() where item.Name.LocalName == "customDetails" select item.Value)
                        {
                            errorDescription = details;
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Write(ex);
                }
            }

            return result;
        }
    }
}
