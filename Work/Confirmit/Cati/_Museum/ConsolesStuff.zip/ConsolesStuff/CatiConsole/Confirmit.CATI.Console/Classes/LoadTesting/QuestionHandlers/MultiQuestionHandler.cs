using System;
using System.Collections.Generic;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class MultiQuestionHandler : BaseQuestionHandler, IQuestionHandler
    {
        public MultiQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers) : base(pageBrowser, predefinedAnswers)
        {
        }

        void IQuestionHandler.SetAnswers()
        {
            var keys = GetKeysForNonOther();

            foreach (var key in keys)
            {
                int valueInt;
                try
                {
                    valueInt = Convert.ToInt32(PredefinedAnswers[key]);
                    if (valueInt == 0)
                    {
                        continue;
                    }
                }
                catch (Exception ex)
                {
                    Logger.Write(ex);
                    continue;
                }

                SetAnswer(string.Format("{0}", key), Convert.ToBoolean(valueInt).ToString());
            }

            SetOtherForNonEmpty();
        }
    }
}