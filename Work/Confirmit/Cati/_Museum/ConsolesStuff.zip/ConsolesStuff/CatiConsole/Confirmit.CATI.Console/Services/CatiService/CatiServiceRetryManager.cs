﻿using System;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Common.Exceptions;
using System.ServiceModel;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.Console.Services.CatiService
{
    /// <summary>
    /// Helps to repeat call to web service in case unexpected exception occurs
    /// </summary>
    public static class CatiServiceRetryManager
    {
        /// <summary>
        /// Invokes given method. 
        /// If exception occurs and it is not 'CatiException' call of method will be repeated.
        /// </summary>
        /// <param name="method"></param>
        /// <param name="repeatOnUserConfirmation">If true user will be notified about communication error, 
        /// and will be asked to repeat invocation.</param>
        public static void Invoke(Action<int> method, bool repeatOnUserConfirmation)
        {
            int attemptNumber = 1;
            int userRepeatAttempt = 1;
            
            do
            {
                try
                {
                    method(attemptNumber);
                    break;
                }                
                catch(Exception ex)
                {
                    if (ExceptionsClassifier.IsCommunicationError(ex) == false)
                    {
                        throw;
                    }

                    if (attemptNumber <= Properties.Settings.Default.CatiServiceRetryLimit * userRepeatAttempt)
                    {
                        attemptNumber++;
                        Thread.Sleep(Properties.Settings.Default.CatiServiceRetrySleepTimeout);
                    }
                    else
                    {
                        if (repeatOnUserConfirmation && DoesUserWantToRepeat())
                        {
                            userRepeatAttempt++;
                        }
                        else
                        {
                            throw;    
                        }
                        
                    }
                }
            }
            while (true);
        }

        private static bool DoesUserWantToRepeat()
        {
            return ServiceLocator.Resolve<IAlerter>().AlertRetryConfirmation(
                LocalizationManager.Instance.GetString("Alerter_CommunicationErrorRetryConformation"),
                LocalizationManager.Instance.GetString("Alerter_ConsoleCaption")) == DialogResult.Retry;
        }
    }
}
