﻿using System;
using Confirmit.CATI.Common;

namespace Confirmit.CATI.Console.Services.CatiService.Exceptions
{
    /// <summary>
    /// Occurs when user enters invalid Cati company aliase.
    /// </summary>
    internal class CatiInvalidInstanceException : CatiServiceException
    {
        #region Constructors

        /// <summary>
        /// Initializes new instance of CatiInvalidInstanceException.
        /// </summary>
        public CatiInvalidInstanceException()
            : base()
        {
            Error = CATIErrorCodes.InvalidFusionInstance;
        }

        /// <summary>
        /// Initializes new instance of CatiInvalidInstanceException and fills if with given data..
        /// </summary>
        /// <param name="innerException">Inner exception.</param>
        public CatiInvalidInstanceException(Exception innerException)
            : base(String.Empty, innerException)
        {
            Error = CATIErrorCodes.InvalidFusionInstance;
        }

        /// <summary>
        /// Initializes new instance of CatiInvalidInstanceException class and fills if with given data.
        /// </summary>
        /// <param name="message">Message.</param>
        /// <param name="innerException">Inner exception.</param>
        public CatiInvalidInstanceException(string message, Exception innerException)
            : base(message, innerException)
        {
            Error = CATIErrorCodes.InvalidFusionInstance;
        }

        #endregion
    }
}
