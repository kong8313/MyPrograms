using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class OpenQuestionHandler : BaseQuestionHandler, IQuestionHandler
    {
        public OpenQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers)
            : base(pageBrowser, predefinedAnswers)
        {
        }

        void IQuestionHandler.SetAnswers()
        {
            var key = PredefinedAnswers.Keys.FirstOrDefault(x => x.Equals(QuestionId));

            if (string.IsNullOrEmpty(key))
            {
                throw new KeyNotFoundException(string.Format(Strings.Autopilot_NoAnswersFound_Error, QuestionId));
            }

            SetAnswer(key, PredefinedAnswers[key]);
        }
    }
}