﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.CallTransfer;
using Confirmit.CATI.Console.Classes.LoadTesting;
using Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers;
using Confirmit.CATI.Console.Classes.Localization;
using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Console.Classes.Telephony;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Resources;
using Confirmit.CATI.Console.Shared.Utilities;
using Confirmit.CATI.Console.Views.Classes.ExtendedWebBrowser;
using Confirmit.CATI.Console.Views.Classes.Interview;
using Confirmit.CATI.Console.Views.Classes.Localization;
using Confirmit.CATI.Console.Views.Classes.SpellChecking;
using Confirmit.CATI.Console.Views.Classes.StatusBar;
using Confirmit.CATI.Console.Views.Classes.Utilities;
using Confirmit.CATI.Console.Views.Controls;
using Confirmit.CATI.Console.Views.Interfaces;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;
using ConfirmitDialerInterface;
using Timer = System.Windows.Forms.Timer;

namespace Confirmit.CATI.Console.Presenters
{
    internal class PresenterInterview : IMonitorable
    {
        private readonly IKeyboardSupport _keyboardSupport;
        private readonly IViewInterviewPageBrowser _viewInterviewPageBrowser;
        private readonly IViewKeyboardInput _viewKeyboardInput;
        private readonly IViewStatusBar _viewStatusBar;
        private readonly IButtonsStateProvider _buttonsStateProvider;
        private Timer _timer;

        private static readonly ManualResetEvent WaitForPageLoadManualResetEvent = new ManualResetEvent(false);
        private PredefinedAnswersProvider _predefinedAnswersProvider;
        private LoopProvider _loopProvider;
        private PredefinedAnswers _predefinedAnswers = new PredefinedAnswers();
        private bool _quitAutoPilot;
        private IAlerter _alerter;
        private Dictionary<BrowserFeature, string> _warningMessages = new Dictionary<BrowserFeature, string>();
        private bool _isScreenRecordingEnabled;
        private bool _extendedLoggingEnabled;

        public PresenterInterview(
            IViewInterviewPageBrowser viewInterviewPageBrowser,
            IKeyboardSupport keyboardSupport,
            IViewStatusBar statusBar,
            IButtonsStateProvider buttonsStateProvider
            )
        {
            if (viewInterviewPageBrowser == null)
            {
                throw new ArgumentNullException("viewInterviewPageBrowser");
            }

            if (keyboardSupport == null)
            {
                throw new ArgumentNullException("keyboardSupport");
            }

            _viewInterviewPageBrowser = viewInterviewPageBrowser;
            _viewStatusBar = statusBar;
            _buttonsStateProvider = buttonsStateProvider;
            _viewKeyboardInput = viewInterviewPageBrowser.ViewKeyboardInput;
            _keyboardSupport = keyboardSupport;
            AllowTelephonyCommands = true;

            _alerter = ServiceLocator.Resolve<IAlerter>();

            InitTimer();
            InitEventHandlers();
            InitInterviewPageBrowser();
            LocalizeViews(LocalizationManager.Instance);
        }

        private void ViewInterviewPageBrowserSubmitOtherValue(object sender, EventArgs e)
        {
            _viewKeyboardInput.SetFocus();
        }

        /// <summary>
        /// Gets or sets current interviewing process mode
        /// </summary>
        private InterviewModes InterviewMode
        {
            get;
            set;
        }

        /// <summary>
        /// Return true if loaded page is first interview page
        /// </summary>
        public bool IsFirstInterviewPage { get; set; }

        public bool HasWrapUpBeenSent { get; set; }

        /// <summary>
        /// Gets a value indicating whether dialing is enabled from Confimit script.
        /// </summary>
        public bool AllowTelephonyCommands { get; private set; }

        /// <summary>
        /// Gets a flag indicating whether current page is a hang up telephony page or not.
        /// </summary>
        public bool IsTelephonyDialPage
        {
            get
            {
                return _viewInterviewPageBrowser.TelephonyPage == TelephonyPageType.Dial;
            }
        }


        /// <summary>
        /// Gets a flag indicating whether current page is a hang up telephony page or not.
        /// </summary>
        public bool IsTelephonyHangUpPage
        {
            get
            {
                return _viewInterviewPageBrowser.TelephonyPage == TelephonyPageType.Hangup;
            }
        }

        /// <summary>
        /// Gets a flag indicating whether current page a telephony page or not.
        /// </summary>
        public bool IsTelephonyPage => _viewInterviewPageBrowser.IsPageInteractorInitialized
                                       && _viewInterviewPageBrowser.TelephonyPage != TelephonyPageType.None;

        public bool IsCatiMarkupAndKeyboardSupportDisabled
        {
            get
            {
                return _viewInterviewPageBrowser.DisableCatiMarkupAndKeyboardSupport;
            }
        }

        public string Status
        {
            get { return _viewInterviewPageBrowser.Status; }
        }

        public string Its
        {
            get { return _viewInterviewPageBrowser.Its; }
        }

        public int InterviewDuration
        {
            get { return _viewInterviewPageBrowser.InterviewDuration; }
        }

        /// <summary>
        /// Gets/sets flag indicating is dial-page has been processed or not.
        /// </summary>
        /// <remarks>
        /// It's used to detect time when postback from dial-page has been submmited to server.
        /// </remarks>
        public bool IsDialPageProcessed { get; set; }

        /// <summary>
        /// Gets/sets properties of current interview.
        /// </summary>
        internal InterviewProperties CurrentInterviewProperties { get; set; }

        /// <summary>
        /// Occurs when control changes it's state and this change should be
        /// reflected during monitoring.
        /// </summary>
        public event StateChangedEventHandler StateChanged;

        /// <summary>
        /// Returns current state of monitorable object.
        /// </summary>
        /// <returns>Object state data.</returns>
        public BaseStateData GetState()
        {
            return new InterviewingInitialStateData
            {
                KeyboardInputValue = _viewInterviewPageBrowser.ViewKeyboardInput.InputValue,
                PageContent = GetPageContent(),
                ActiveQuestionIndex = CurrentInterviewProperties != null ? _viewInterviewPageBrowser.CurrentQuestionIndex : -1,
                InterviewId = CurrentInterviewProperties != null ? CurrentInterviewProperties.InterviewId : -1,
                SurveyId = CurrentInterviewProperties != null ? CurrentInterviewProperties.SurveyId : String.Empty,
                SurveyName = CurrentInterviewProperties != null ? CurrentInterviewProperties.SurveyName : String.Empty,
                ConsoleState = GetConsoleState(),
                IsNewSurvey = CurrentInterviewProperties != null && CurrentInterviewProperties.IsNewSurvey,
                IsInboundCall = CurrentInterviewProperties != null && CurrentInterviewProperties.IsInboundCall,
                IsTestMode = CurrentInterviewProperties != null && CurrentInterviewProperties.SurveyName.EndsWith("#test", StringComparison.InvariantCultureIgnoreCase)
            };
        }

        /// <summary>
        /// Start new interview
        /// </summary>
        /// <param name="interviewProp">InterviewProperties contains survey id, interview id, url to page</param>
        /// <param name="languageId">Language identifier. This parameter should be added to Confirmit URL
        /// in order to start interview in given language. If it is null, we should do nothing.</param>
        public void StartInterview(InterviewProperties interviewProp, int? languageId)
        {
            InterviewMode = InterviewModes.Interviewing;
            Uri uri;

            Logger.Write(
                String.Format("Interview url before decode '{0}'.", interviewProp.InterviewURL),
                MessageTypes.Information
            );

            try
            {
                uri = new Uri(interviewProp.InterviewURL);
                if (languageId.HasValue)
                {
                    uri = AddQueryToUri(uri, String.Format("l={0}", languageId.Value));
                }
            }
            catch (UriFormatException ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
                return;
            }

            HasWrapUpBeenSent = false;
            IsFirstInterviewPage = true;
            _isScreenRecordingEnabled = false;

            _viewStatusBar.SurveyName = SurveyNameFormatter.FormatSurveyName(interviewProp.SurveyId, interviewProp.SurveyName);
            _viewStatusBar.InterviewName = interviewProp.InterviewId.ToString(CultureInfo.InvariantCulture);
            CurrentInterviewProperties = interviewProp;

            _timer.Start();
            _viewStatusBar.Mode = StatusBarModes.Interviewing;

            Logger.Write(
                String.Format("Interview url after decode '{0}'.", uri),
                MessageTypes.Information
            );

            _viewInterviewPageBrowser.Navigate(uri);
            
        }

        public void StartInterviewAutomatically(InterviewProperties interviewProp, int? languageId)
        {
            StartInterview(interviewProp, languageId);
            _predefinedAnswers = _predefinedAnswersProvider.GetNextInterviewAnswers();
            _loopProvider = new LoopProvider(_predefinedAnswers.Loops);
        }


        /// <summary>
        /// Start interview review
        /// </summary>
        /// <param name="interviewProp">Contains info about current interview</param>
        /// <param name="languageId">Language identifier. This parameter should be added to Confirmit URL
        /// in order to start interview in given language. If it is null, we should do nothing.</param>
        public void StartInterviewReview(InterviewProperties interviewProp, int? languageId)
        {
            InterviewMode = InterviewModes.Reviewing;
            _viewStatusBar.CurrentState = LocalizationManager.Instance.GetString("Message_OpenEndReview");

            Uri uri;
            try
            {
                uri = new Uri(interviewProp.InterviewURL);

                // removing __resume parameter
                string query = uri.Query;
                if (query.Length > 0)
                {
                    // removing leading '?'
                    query = query.Remove(0, 1);
                }
                query = query.Replace("__resume=1&", "");
                UriBuilder tmp = new UriBuilder(uri);
                tmp.Query = query;
                uri = tmp.Uri;

                uri = AddQueryToUri(uri, "__reviewing=1");
                if (languageId.HasValue)
                {
                    uri = AddQueryToUri(uri, String.Format("l={0}", languageId.Value));
                }
            }
            catch (UriFormatException ex)
            {
                _alerter.Alert(ex, LocalizationManager.Instance.GetString("Alerter_ConsoleCaption"));
                return;
            }

            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.InterviewReviewStartMessage,
                    IsScreenRecordingEnabled = _isScreenRecordingEnabled
                },
                UserPassport.Instance.MonitoringIdentity
            );

            IsFirstInterviewPage = true;
            CurrentInterviewProperties = interviewProp;
            _viewStatusBar.SurveyName = SurveyNameFormatter.FormatSurveyName(interviewProp.SurveyId, interviewProp.SurveyName);
            _viewStatusBar.InterviewName = interviewProp.InterviewId.ToString(CultureInfo.InvariantCulture);
            _viewStatusBar.Mode = StatusBarModes.Reviewing;
            _viewInterviewPageBrowser.Navigate(uri);
        }

        public void FocusActiveElement()
        {
            _viewInterviewPageBrowser.FocusActiveElement();
        }

        /// <summary>
        /// Refreshes current page. 
        /// Prevents refresh for dial page.
        /// </summary>
        public void RefreshPage()
        {
            if (IsRefreshPageAllowed())
            {
                _viewInterviewPageBrowser.RefreshPage();
            }
        }

        /// <summary>
        /// Returns true if user can invoke page refresh otherwise false.
        /// </summary>        
        public bool IsRefreshPageAllowed()
        {
            return (IsTelephonyDialPage == false || (IsTelephonyDialPage && IsDialPageProcessed)) &&
                    _viewInterviewPageBrowser.IsOkPage == false && _viewInterviewPageBrowser.IsConfirmitInternalErrorPage == false;
        }

        /// <summary>
        /// Emulate next button click
        /// </summary>
        public void GoNextPage()
        {
            _viewInterviewPageBrowser.DoNextPage();
        }

        /// <summary>
        /// Emulate previous button click
        /// </summary>
        public void GoPrevPage()
        {
            _viewInterviewPageBrowser.DoPrevPage();
        }

        /// <summary>
        /// Opens given uri.
        /// </summary>
        /// <param name="uri"></param>
        public void Navigate(Uri uri)
        {
            _viewInterviewPageBrowser.Navigate(uri);
        }

        /// <summary>
        /// Returns all text blocks on the current page.
        /// </summary>
        public IEnumerable<QuestionTextBlock> GetPageTextBlocks()
        {
            return _viewInterviewPageBrowser.GetPageTextBlocks();
        }

        /// <summary>
        /// Updates all text blocks on the current page.
        /// </summary>
        public void UpdatePageTextBlocks(IEnumerable<QuestionTextBlock> textblocks)
        {
            _viewInterviewPageBrowser.UpdatePageTextBlocks(textblocks);
        }

        /// <summary>
        /// Occurs when interview is finished.
        /// </summary>
        public event EventHandler<EventArgs> InterviewFinished;

        /// <summary>
        /// Occurs when we recieve intervew last page with "Ok" button.
        /// </summary>
        public event EventHandler<EventArgs> InterviewLastPage;

        /// <summary>
        /// Occurs when dialing command is recieved.
        /// </summary>
        public event DialEventHandler Dial;

        /// <summary>
        /// Occurs when hang up command is recieved. 
        /// </summary>
        public event EventHandler<EventArgs> Hangup;

        /// <summary>
        /// Occurs when start openend review page is recieved.
        /// </summary>
        public event EventHandler<EventArgs> StartReview;

        /// <summary>
        /// Occurs when a page was parsed and playback command was found
        /// </summary>
        public event PlaybackFoundEventHandler PlaybackFound;

        /// <summary>
        /// Occurs when a page was parsed and playback command was found
        /// </summary>
        public event EventHandler<EventArgs> PlaybackNotFound;

        public event EventHandler ForcedAppointment;

        public event EventHandler<StartCallTransferEventArgs> StartCallTransfer;

        public event EventHandler<InternalTransferEventArgs> InternalTransfer;
        public event EventHandler<ExternalTransferEventArgs> ExternalTransfer;

        private void ViewInterviewPageBrowserBeforeNavigate(object sender, CustomBeforeNavigateEventArgs e)
        {
            if (!_viewInterviewPageBrowser.IsPageInteractorInitialized) return;
            if (_viewInterviewPageBrowser.IsConfirmitInternalErrorPage && e.NavigateData.PostData != null)
            {
                _viewInterviewPageBrowser.ReadOnly = true;
                OnInterviewLastPage(EventArgs.Empty);
            }
        }

        /// <summary>
        /// Occurs in InterviewPageBrowser on page completed before parsing
        /// </summary>
        void ViewInterviewPageBrowserDocumentCompleting(object sender, CancelEventArgs e)
        {
            bool isServicePage = false;
            IsDialPageProcessed = false;

            _viewInterviewPageBrowser.ReadOnly = false;

            _viewInterviewPageBrowser.EnableKeyboardSupport(!_viewInterviewPageBrowser.DisableCatiMarkupAndKeyboardSupport);

            if (_viewInterviewPageBrowser.IsNavigationError)
            {
                /* In a case of navigation error we log error page for debugging
                 and show our error page. It is done in handler of 'NavigateError' event  */
                isServicePage = true;
            }
            else if (_viewInterviewPageBrowser.IsConfirmitServicePage)
            {
                // if confirmit returns service page, it means that survey is
                // launching now. So we show our message and suggest him to
                // try again later.
                Logger.Write(Strings.Log_ConfirmitServicePage, MessageTypes.Warning);
                _viewInterviewPageBrowser.ShowErrorPage(
                    LocalizationManager.Instance.GetString("Error_ConfirmitServiceError"));
                isServicePage = true;
            }
            else if (_viewInterviewPageBrowser.IsPredefinedErrorPage)
            {
                // send our error page to monitoring server
                OnStateChanged(
                    GetArgsForPageCompletedEvent(),
                    UserPassport.Instance.MonitoringIdentity);
                isServicePage = true;
            }
            else if (_viewInterviewPageBrowser.Is500ErrorPage)
            {
                Logger.Write(Strings.Log_Http500ErrorPage, MessageTypes.Error);
                OnStateChanged(
                    GetArgsForPageCompletedEvent(),
                    UserPassport.Instance.MonitoringIdentity);
                isServicePage = true;
                if (CurrentInterviewProperties.Has500ErrorOccured == false)
                {
                    CurrentInterviewProperties.Has500ErrorOccured = true;
                    RefreshPage();
                }
            }
            else if (_viewInterviewPageBrowser.IsEndInterviewServicePage)
            {
                if (_extendedLoggingEnabled)
                {
                    Logger.Write(string.Format(Strings.Log_ConfirmitServicePageWithPageType, "EofPage"), MessageTypes.Information);
                }

                FinishInterview();

                isServicePage = true;
            }
            else if (_viewInterviewPageBrowser.IsOkPage)
            {
                // We want to stop playback in the end of the interview before WrapUp (it also call logout if logout pending)
                OnPlaybackNotFound(e);

                if (_viewInterviewPageBrowser.IsConfirmitInternalErrorPage)
                {
                    if (_extendedLoggingEnabled)
                    {
                        Logger.Write(string.Format(Strings.Log_ConfirmitServicePageWithPageType, "InternalErrorPage"), MessageTypes.Information);
                    }

                    _viewInterviewPageBrowser.Status = ((int)CallOutcome.SurveyScriptError).ToString();
                    // do nothing
                    OnStateChanged(
                        GetArgsForPageCompletedEvent(),
                        UserPassport.Instance.MonitoringIdentity);
                    isServicePage = true;
                }
                else
                {
                    if (_extendedLoggingEnabled)
                    {
                        Logger.Write(string.Format(Strings.Log_ConfirmitServicePageWithPageType, "OkPage"), MessageTypes.Information);
                    }

                    _viewInterviewPageBrowser.ReadOnly = true;
                    // we received Ok page. We should generate InterviewLastPage event and suppress further processing
                    OnInterviewLastPage(EventArgs.Empty);

                    _viewInterviewPageBrowser.ContinueInterview();
                    isServicePage = true;
                }
            }
            else if (_viewInterviewPageBrowser.IsOpenendReviewStartPage)
            {
                if (_extendedLoggingEnabled)
                {
                    Logger.Write(string.Format(Strings.Log_ConfirmitServicePageWithPageType, "OpenendReviewPage"), MessageTypes.Information);
                }

                // we recieved opendend review page, so we should generate start review event and suppress further processing
                CurrentInterviewProperties.Has500ErrorOccured = false;
                OnStartReview(EventArgs.Empty);
                isServicePage = true;
            }
            else if (InterviewMode == InterviewModes.Interviewing)
            {
                CurrentInterviewProperties.Has500ErrorOccured = false;

                if (_viewInterviewPageBrowser.ContainsScreenRecordingEnabledFlag)
                {
                    _isScreenRecordingEnabled = true;
                }

                if (_viewInterviewPageBrowser.TelephonyPage == TelephonyPageType.Dial)
                {
                    // if we recieve telephony page we should suppress further page
                    // processing and DocumentCompleted notification.
                    OnDial(
                        new DialEventArgs
                        {
                            DialMessage = _viewInterviewPageBrowser.DialMessage,
                            Phone = _viewInterviewPageBrowser.DialPhone
                        }
                    );
                    isServicePage = true;
                }
                else if (_viewInterviewPageBrowser.TelephonyPage == TelephonyPageType.Hangup)
                {
                    // if we recieve telephony page we should suppress further page
                    // processing and DocumentCompleted notification.
                    OnHangup(EventArgs.Empty);
                    isServicePage = true;
                }
                else if (_viewInterviewPageBrowser.TelephonyPage == TelephonyPageType.InternalTransfer)
                {
                    OnInternalTransfer(new InternalTransferEventArgs()
                    {
                        Resource = _viewInterviewPageBrowser.TransferResource,
                    });
                }
                else if (_viewInterviewPageBrowser.TelephonyPage == TelephonyPageType.ExternalTransfer)
                {
                    OnExternalTransfer(new ExternalTransferEventArgs()
                    {
                        Resource = _viewInterviewPageBrowser.TransferResource,
                    });
                }
                else if (_viewInterviewPageBrowser.ContainsForcedAppointment)
                {
                    OnForcedAppointment(EventArgs.Empty);
                }
                else if (_viewInterviewPageBrowser.ContainsCallTransferConfiguration)
                {
                    OnStartCallTransfer(new StartCallTransferEventArgs
                    {
                        Options = new CallTransferConfigurationConverter().ConvertJsonToTransferOptions(_viewInterviewPageBrowser.CallTransferConfiguration)
                    });

                    isServicePage = true;
                }                
                else {
                    // Confirmit doesn't render "Allow dialing" flag for telephony pages
                    // so it is safe to get "Allow dialing" flag in else block.
                    bool allowFlag;

                    if (_viewInterviewPageBrowser.CheckAndGetTelephonyFlag(out allowFlag))
                    {
                        AllowTelephonyCommands = allowFlag;
                        ContinueInterview();
                        isServicePage = true;

                        Logger.Write(
                            String.Format(Strings.Log_TelephonyFlagReceived, allowFlag),
                            MessageTypes.Information);
                    }

                }

                
            }

            if (isServicePage)
            {
                e.Cancel = true;
                OnPlaybackNotFound(e);
            }
        }

        private StateChangedEventArgs GetArgsForPageCompletedEvent()
        {
            return new StateChangedEventArgs
            {
                MessageType = MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage,
                State = new DocumentCompletedStateData
                {
                    PageContent = GetPageContent()
                },
                IsScreenRecordingEnabled = _isScreenRecordingEnabled
            };
        }

        /// <summary>
        /// Occurs in InterviewPageBrowser on document completed after parsing
        /// </summary>
        void ViewInterviewPageBrowserDocumentCompleted(object sender, EventArgs e)
        {
            if (!_viewInterviewPageBrowser.IsResponsiveSurvey)
            {
                _viewInterviewPageBrowser.ExecuteJavaScript(HtmlMonitoringAdapter.GetUpdateHtmlScript(string.Empty));
            }

            if (IsFirstInterviewPage)
            {
                if (InterviewMode == InterviewModes.Interviewing)
                {
                    _viewInterviewPageBrowser.LogSurveyLayoutType();
                }

                if (InterviewMode == InterviewModes.Reviewing &&
                    _viewInterviewPageBrowser.HasOpenEndQuestion == false)
                {
                    _viewInterviewPageBrowser.FastForward();
                    return;
                }

                OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.InterviewInitialMessage,
                        State = GetState(),
                        IsScreenRecordingEnabled = _isScreenRecordingEnabled
                    },
                    UserPassport.Instance.MonitoringIdentity
                );

                IsFirstInterviewPage = false;
            }
            else
            {
                OnStateChanged(
                    GetArgsForPageCompletedEvent(),
                    UserPassport.Instance.MonitoringIdentity
                );
            }

            HandleSoundInfo();

            if (IsCatiMarkupAndKeyboardSupportDisabled)
            {
                FocusActiveElement();
            }
            else
            {
                _viewKeyboardInput.SetFocus();
            }

            WaitForPageLoadManualResetEvent.Set();
        }

        public void StopAutoPilotProcess()
        {
            _quitAutoPilot = true;
            WaitForPageLoadManualResetEvent.Set();
        }

        public void RunAutoPilotProcess(PredefinedAnswersProvider provider, int minDelay, int maxDelay, CultureInfo locale)
        {
            _predefinedAnswersProvider = provider;
            var pageBrowserUpdater = new SafePageBrowserUpdater((UserControl)_viewInterviewPageBrowser);

            while (true)
            {
                WaitForPageLoadManualResetEvent.WaitOne();
                if (_quitAutoPilot)
                {
                    return;
                }

                var delay = new Random().Next(minDelay, maxDelay);

                Thread.Sleep(delay);

                var currenQuestionLast = false;
                var currentQuestionId = "";
                pageBrowserUpdater.Run(() =>
                {
                    currenQuestionLast = _viewInterviewPageBrowser.IsCurrentQuestionLast;
                    currentQuestionId = _viewInterviewPageBrowser.CurrentQuestionId;
                });

                if (string.IsNullOrEmpty(currentQuestionId) == false)
                {
                    var answersToPass = _predefinedAnswers.Answers;
                    
                    if (_loopProvider.IsLoopExists)
                    {
                        var loopItem = _loopProvider.GetLoopItemByQuestionId(currentQuestionId);
                        if (loopItem != null && loopItem.Any())
                        {
                            answersToPass = loopItem;
                        }
                    }
                    var questionHandler = new QuestionHandlerFactory(answersToPass, _viewInterviewPageBrowser, locale)
                        .Create();

                    questionHandler.SetAnswers();

                    if (questionHandler.ValueWasSet == false)
                    {
                        throw new Exception(string.Format(Strings.Autopilot_NoAnswersFound_Error,
                            currentQuestionId));
                    }
                }

                pageBrowserUpdater.Run(() => _viewInterviewPageBrowser.DoNextQuestion());

                if (currenQuestionLast == false)
                {
                    continue;
                }

                pageBrowserUpdater.Run(() => { _viewInterviewPageBrowser.DoNextPage(); });
                    
                WaitForPageLoadManualResetEvent.Reset();
            }
        }

        void ViewInterviewPageBrowserAnswerValueChanged(object sender, AnswerElementValueChangedEventArgs e)
        {
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.InterviewPageBrowserAnswerValueChangedMessage,
                    State = new AnswerEnteredStateData
                    {
                        ControlName = sender.ToString(),
                        ElementId = e.ElementId,
                        ElementValue = e.ElementValue
                    },
                    IsScreenRecordingEnabled = _isScreenRecordingEnabled
                },
                UserPassport.Instance.MonitoringIdentity
            );
        }

        void ViewInterviewPageBrowserResponsiveQuestionChanged(object sender, AnswerElementValueChangedEventArgs e)
        {
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.InterviewPageBrowserResponsiveQuestionChangedMessage,
                    State = new AnswerEnteredStateData
                    {
                        ControlName = sender.ToString(),
                        ElementId = e.ElementId,
                        ElementValue = e.ElementValue
                    },
                    IsScreenRecordingEnabled = _isScreenRecordingEnabled
                },
                UserPassport.Instance.MonitoringIdentity
            );
        }

        /// <summary>
        /// If user changes answer for dynamic question, whole page should be sent into the player console.
        /// </summary>
        void ViewInterviewPageBrowserDynamicQuestionAnswerValueChanged(object sender, EventArgs e)
        {
            OnStateChanged(
                    GetArgsForPageCompletedEvent(),
                    UserPassport.Instance.MonitoringIdentity
                );
        }

        void ViewInterviewPageBrowserPagePartiallyChanged(object sender, PagePartiallyChangedEventArgs e)
        {
            OnStateChanged(
                    new StateChangedEventArgs
                    {
                        MessageType = MonitoringMessageTypes.InterviewPageBrowserPagePartiallyChangedMessage,
                        State = new PagePartiallyChangedStateData
                        {
                            ElementId = e.ElementId,
                            ElementOuterHtml = e.NewOuterHtml,
                            ActiveElementId = e.ActiveElementId
                        },
                        IsScreenRecordingEnabled = _isScreenRecordingEnabled
                    },
                    UserPassport.Instance.MonitoringIdentity
                );
        }

        /// <summary>
        /// Handler for case when question is dynamically loaded via ajax depenging on previous question's answer
        /// </summary>
        void ViewInterviewPageBrowserAjaxQuestionLoaded(object sender, EventArgs e)
        {
            OnStateChanged(
                    GetArgsForPageCompletedEvent(),
                    UserPassport.Instance.MonitoringIdentity
                );
        }

        void ViewInterviewPageBrowserQuestionSelected(object sender, QuestionSelectedEventArgs e)
        {
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage,
                    State = new QuestionSelectedStateData
                    {
                        QuestionId = e.QuestionId,
                        QuestionTitle = e.QuestionTitle,
                        QuestionText = e.QuestionText,
                        QuestionIndex = e.QuestionIndex,
                        SubQuestionIndex = e.SubQuestionIndex,
                        IsSubQuestion = e.IsSubQuestion,
                        QuestionType = (int)e.QuestionType
                    },
                    IsScreenRecordingEnabled = _isScreenRecordingEnabled
                },
                UserPassport.Instance.MonitoringIdentity
            );

            _viewStatusBar.QuestionName = _viewInterviewPageBrowser.CurrentQuestionTitle;
        }

        private void ViewInterviewPageBrowserSubQuestionSelected(object sender, QuestionSelectedEventArgs e)
        {
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage,
                    State = new QuestionSelectedStateData
                    {
                        QuestionIndex = e.QuestionIndex,
                        SubQuestionIndex = e.SubQuestionIndex
                    },
                    IsScreenRecordingEnabled = _isScreenRecordingEnabled
                },
                UserPassport.Instance.MonitoringIdentity
            );
        }

        void KeyboardSupport_KeyButtonDown(object sender, PreviewKeyDownEventArgs e)
        {
            ProcessKeyboardInput(e);
        }

        void ViewInterviewPageBrowserOkClick(object sender, EventArgs e)
        {
            PreviewKeyDownEventArgs arg = new PreviewKeyDownEventArgs(Keys.Enter);
            _viewKeyboardInput.SetFocus();
            ProcessKeyboardInput(arg);
        }

        void m_ViewInterviewPageBrowser_KeyboardInputControl_ValueChanded(object sender, EventArgs e)
        {
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.InterviewPageBrowserKeyboardInputControlValueChangedMessage,
                    State = new TextControlStateData(((Control)sender).Name, _viewInterviewPageBrowser.ViewKeyboardInput.InputValue),
                    IsScreenRecordingEnabled = _isScreenRecordingEnabled
                },
                UserPassport.Instance.MonitoringIdentity
            );
        }

        void ViewInterviewPageBrowserRefusedAnswerSelected(object sender, PredefinedAnswerSelectedEventArgs e)
        {
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.SetRefusedAnswerMessage,
                    IsScreenRecordingEnabled = _isScreenRecordingEnabled
                },
                UserPassport.Instance.MonitoringIdentity);

            if (e.NavigateToNextQuestion)
            {
                NavigateToNextQuestion();
            }
        }

        void ViewInterviewPageBrowserDefaultAnswerSelected(object sender, PredefinedAnswerSelectedEventArgs e)
        {
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.SetDefaultAnswerMessage,
                    IsScreenRecordingEnabled = _isScreenRecordingEnabled
                },
                UserPassport.Instance.MonitoringIdentity);

            if (e.NavigateToNextQuestion)
            {
                NavigateToNextQuestion();
            }
        }

        private void ViewInterviewPageBrowserNavigateError(object sender, NavigateErrorEventArgs e)
        {
            /* Handling of navigation errors must be located here, because if page contains IFrames, 'DocumentComplete' event might not be fired at all. 
               For example it happens when communication error occures during loading page into IFrame  */
            var pageContent = _viewInterviewPageBrowser.GetPageContent();

            Logger.Write(Strings.ResourceManager.GetString("Log_NavigationError", 
                                                            e.Status, 
                                                            e.Url,
                                                            pageContent.Length.ToString("N0"),
                                                            e.PageLoadTime.TotalMilliseconds.ToString("N0")),
                                                            MessageTypes.Error);

            Logger.WriteFile(pageContent, ApplicationManager.ApplicationUserSpecificPath);

            _viewInterviewPageBrowser.ShowErrorPage(LocalizationManager.Instance.GetString("Error_NavigationError"));
        }

        private void Instance_CurrentCultureChanged(object sender, EventArgs e)
        {
            LocalizeViews(LocalizationManager.Instance);
        }

        /// <summary>
        /// Fires StateChanged event.
        /// </summary>
        /// <param name="e">Data for StateChanged event</param>
        /// <param name="sessionId">Session Id</param>
        internal void OnStateChanged(StateChangedEventArgs e, MonitoringIdentity sessionId)
        {
            if (StateChanged != null)
            {
                StateChanged(this, e, sessionId);
            }
        }

        /// <summary>
        /// Initializes event handlers.
        /// </summary>
        internal void InitEventHandlers()
        {
            _viewInterviewPageBrowser.DocumentCompleted += ViewInterviewPageBrowserDocumentCompleted;
            _viewInterviewPageBrowser.DocumentCompleting += ViewInterviewPageBrowserDocumentCompleting;
            _viewInterviewPageBrowser.AnswerValueChanged += ViewInterviewPageBrowserAnswerValueChanged;
            _viewInterviewPageBrowser.ResponsiveQuestionChanged += ViewInterviewPageBrowserResponsiveQuestionChanged;
            _viewInterviewPageBrowser.DynamicQuestionAnswerValueChanged += ViewInterviewPageBrowserDynamicQuestionAnswerValueChanged;
            _viewInterviewPageBrowser.PagePartiallyChanged += ViewInterviewPageBrowserPagePartiallyChanged;
            _viewInterviewPageBrowser.AjaxQuestionLoaded += ViewInterviewPageBrowserAjaxQuestionLoaded;
            _viewInterviewPageBrowser.QuestionSelected += ViewInterviewPageBrowserQuestionSelected;
            _viewInterviewPageBrowser.SubQuestionSelected += ViewInterviewPageBrowserSubQuestionSelected;
            _viewInterviewPageBrowser.OkClick += ViewInterviewPageBrowserOkClick;
            _viewInterviewPageBrowser.ViewKeyboardInput.ValueChanged += m_ViewInterviewPageBrowser_KeyboardInputControl_ValueChanded;
            _viewInterviewPageBrowser.DefaultAnswerSelected += ViewInterviewPageBrowserDefaultAnswerSelected;
            _viewInterviewPageBrowser.RefusedAnswerSelected += ViewInterviewPageBrowserRefusedAnswerSelected;
            _viewInterviewPageBrowser.NavigateError += ViewInterviewPageBrowserNavigateError;
            _viewInterviewPageBrowser.BeforeNavigate += ViewInterviewPageBrowserBeforeNavigate;
            _viewInterviewPageBrowser.SubmitOtherValue += ViewInterviewPageBrowserSubmitOtherValue;
            _keyboardSupport.KeyButtonDown += KeyboardSupport_KeyButtonDown;
            LocalizationManager.Instance.CurrentCultureChanged += Instance_CurrentCultureChanged;
        }

        private void FillWarningMessagesCollection(ILocalizationManager manager)
        {
           _warningMessages[BrowserFeature.MutationObserver] = manager.GetString("ProblemWithQuestionDisplaying");
        }

        private void LocalizeViews(ILocalizationManager manager)
        {
            _viewInterviewPageBrowser.Localize(manager);

            FillWarningMessagesCollection(manager);
        }

        /// <summary>
        /// Initializes _viewInterviewPageBrowser
        /// </summary>
        internal void InitInterviewPageBrowser()
        {
            _viewInterviewPageBrowser.PageUpdateMonitoringDelay = Properties.Settings.Default.PageUpdateMonitoringDelay;
            _viewInterviewPageBrowser.MouseClickAnswerMonitoringDelay = Properties.Settings.Default.MouseClickAnswerMonitoringDelay;
            _viewInterviewPageBrowser.ExtendedLoggingEnabled = _extendedLoggingEnabled = Properties.Settings.Default.EnabledExtendedBrowserOperationsLogging;
        }

        /// <summary>
        /// Initialiazes timer object which is used for respondent and interviewer showing.
        /// </summary>
        private void InitTimer()
        {
            _timer = new Timer { Interval = 1000 };
            _timer.Tick += m_Timer_Tick;
        }

        internal void ProcessKeyboardInput(PreviewKeyDownEventArgs e)
        {
            if (_viewInterviewPageBrowser.ReadOnly)
            {
                return;
            }

            if (IsTelephonyPage ||
                IsCatiMarkupAndKeyboardSupportDisabled)
            {
                /* suppress keyboard input for telephony pages and 
                   in case keyboard support is disabled by hidden parameter on the page */
                return;
            }

            if (CurrentInterviewProperties == null)
            {
                // suppress keyboard input if there is no interview
                return;
            }

            bool isEndPage = _viewInterviewPageBrowser.IsEndInterviewPageLoaded;

            if (isEndPage)
            {
                switch (e.KeyCode)
                {
                    case Keys.Enter:
                    case Keys.PageDown:
                        if (_buttonsStateProvider == null || _buttonsStateProvider.IsNextPageEnabled)
                        {
                            if (_extendedLoggingEnabled)
                            {
                                Logger.Write(string.Format(Strings.Log_KeyboardAction, "FinishInterview"), MessageTypes.Information);
                            }

                            _viewInterviewPageBrowser.FinishInterview();
                        }
                        break;
                }
                return;
            }

            if (e.Control && e.KeyCode == Keys.Enter)
            {
                // we shouldn't process Ctrl+Enter combination here because it doesn't
                // correspond to answers input but to interviewing process itself
                if (_buttonsStateProvider == null || _buttonsStateProvider.IsFastForwardEnabled)
                {
                    if (_extendedLoggingEnabled)
                    {
                        Logger.Write(string.Format(Strings.Log_KeyboardAction, "FastForward"), MessageTypes.Information);
                    }

                    _viewInterviewPageBrowser.FastForward();
                }
                return;
            }

            if (_viewInterviewPageBrowser.ShouldNavigationBeIgnored)
            {
                switch (e.KeyCode)
                {
                    case Keys.Enter:
                    case Keys.Up:
                    case Keys.Down:
                    case Keys.Left:
                    case Keys.Right:
                    case Keys.PageUp:
                    case Keys.PageDown:
                    case Keys.Home:
                    case Keys.End:
                        return;
                }
            }

            if (!_viewKeyboardInput.IsFocused)
            {
                switch (e.KeyCode)
                {
                    case Keys.Left:
                    case Keys.Right:
                    case Keys.Home:
                    case Keys.End:
                    case Keys.Enter:
                        if (_viewInterviewPageBrowser.HasCurrentQuestionAnswersWithFocusedOtherField) return;
                        break;
                }
            }

            switch (e.KeyCode)
            {
                case Keys.Enter:
                    if (_viewKeyboardInput.HasInputValue)
                    {
                        _viewInterviewPageBrowser.ProcessEnterData(_viewKeyboardInput.InputValue);

                        OnStateChanged(
                            new StateChangedEventArgs
                            {
                                MessageType = MonitoringMessageTypes.InterviewPageBrowserProcessKeyboardInputMessage,
                                State = new ProcessKeyboardInputStateData { InputValue = _viewKeyboardInput.InputValue },
                                IsScreenRecordingEnabled = _isScreenRecordingEnabled
                            },
                            UserPassport.Instance.MonitoringIdentity
                        );
                    }
                    else//if the the text box is empty, move to the next question; if it is last question move to next page.
                    {
                        if (_viewInterviewPageBrowser.IsCurrentQuestionLast)
                        {
                            if (_buttonsStateProvider == null || _buttonsStateProvider.IsNextPageEnabled)
                            {
                                if (_extendedLoggingEnabled)
                                {
                                    Logger.Write(string.Format(Strings.Log_KeyboardAction, "NextPage"), MessageTypes.Information);
                                }
                                _viewInterviewPageBrowser.DoNextPage();
                            }
                        }
                        else
                        {
                            _viewInterviewPageBrowser.DoNextQuestion();
                        }
                        _viewKeyboardInput.SetFocus();
                    }
                    _viewKeyboardInput.Clear();
                    break;
                case Keys.Up://highlight the previous question
                    _viewInterviewPageBrowser.DoPreviousQuestion();
                    _viewKeyboardInput.SetFocus();
                    break;
                case Keys.Down://highlight the next question  
                    _viewInterviewPageBrowser.DoNextQuestion();
                    _viewKeyboardInput.SetFocus();
                    break;
                case Keys.PageUp:
                    if (_buttonsStateProvider == null || _buttonsStateProvider.IsPreviousPageEnabled)
                    {
                        if (_extendedLoggingEnabled)
                        {
                            Logger.Write(string.Format(Strings.Log_KeyboardAction, "PrevPage"), MessageTypes.Information);
                        }
                        _viewInterviewPageBrowser.DoPrevPage();
                        _viewKeyboardInput.Clear();
                        _viewKeyboardInput.SetFocus();
                    }
                    break;
                case Keys.PageDown:
                    if (_buttonsStateProvider == null || _buttonsStateProvider.IsNextPageEnabled)
                    {
                        if (_extendedLoggingEnabled)
                        {
                            Logger.Write(string.Format(Strings.Log_KeyboardAction, "NextPage"), MessageTypes.Information);
                        }
                        _viewInterviewPageBrowser.DoNextPage();
                        _viewKeyboardInput.Clear();
                        _viewKeyboardInput.SetFocus();
                    }
                    break;
                case Keys.Tab:
                    if (e.Shift)//highlight the previous question 
                    {
                        _viewInterviewPageBrowser.DoPreviousQuestion();
                        _viewKeyboardInput.SetFocus();
                    }
                    else //highlight the next question
                    {
                        _viewInterviewPageBrowser.DoNextQuestion();
                        _viewKeyboardInput.SetFocus();
                    }
                    break;

                case Keys.Home:
                    if (e.Control)
                    {
                        // highlight the first sub question (if exist) of the first question of the page 
                        _viewInterviewPageBrowser.DoFirstQuestionFirstSubQuestion();
                        _viewKeyboardInput.SetFocus();
                    }
                    else
                    {
                        // highlight the first sub question (if exist) of the current question
                        _viewInterviewPageBrowser.DoFirstSubQuestion();
                        _viewKeyboardInput.SetFocus();
                    }

                    break;
                case Keys.End:
                    if (e.Control)
                    {
                        // highlight the last sub question (if exist) of the last question of the page 
                        _viewInterviewPageBrowser.DoLastQuestionLastSubQuestion();
                        _viewKeyboardInput.SetFocus();
                    }
                    else //highlight the last sub question (if exist) of the current question 
                    {
                        _viewInterviewPageBrowser.DoLastSubQuestion();
                        _viewKeyboardInput.SetFocus();
                    }
                    break;
                case Keys.F2:
                    // if current question is open question: focus to TextArea or Input textbox of current question 
                    _viewInterviewPageBrowser.DoEditQuestion();
                    break;
                case Keys.Insert://If the user hits Insert, the keyboard entry box should be focused.
                case Keys.Escape:
                    //focus to Keyboard input control
                    _viewKeyboardInput.SetFocus();
                    break;
                case Keys.D:
                    if (e.Control)
                    {
                        _viewInterviewPageBrowser.SetDefaultAnswer();
                    }
                    break;
                case Keys.R:
                    if (e.Control)
                    {
                        _viewInterviewPageBrowser.SetRefusedAnswer();
                    }
                    break;
            }
        }

        /// <summary>
        /// Fires InterviewFinished event.
        /// </summary>
        /// <param name="eventArgs">Event arguments.</param>
        private void OnInterviewFinished(EventArgs eventArgs)
        {
            if (InterviewFinished != null)
            {
                InterviewFinished(this, eventArgs);
            }
        }

        /// <summary>
        /// Fires InterviewLastPage event.
        /// </summary>
        /// <param name="eventArgs">Event arguments.</param>
        private void OnInterviewLastPage(EventArgs eventArgs)
        {
            if (InterviewLastPage != null)
            {
                InterviewLastPage(this, eventArgs);
            }
        }

        /// <summary>
        /// Fires Dial event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnDial(DialEventArgs e)
        {
            if (Dial != null)
            {
                Dial(this, e);
            }
        }

        /// <summary>
        /// Fires Hangup event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnHangup(EventArgs e)
        {
            if (Hangup != null)
            {
                Hangup(this, e);
            }
        }

        /// <summary>
        /// Fires PlaybackNotFound event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnPlaybackNotFound(EventArgs e)
        {
            if (PlaybackNotFound != null)
            {
                PlaybackNotFound(this, e);
            }
        }

        private void OnForcedAppointment(EventArgs e)
        {
            if (ForcedAppointment != null)
            {
                ForcedAppointment(this, e);
            }
        }

        private void OnInternalTransfer(InternalTransferEventArgs e)
        {
            InternalTransfer?.Invoke(this, e);
        }

        private void OnExternalTransfer(ExternalTransferEventArgs e)
        {
            ExternalTransfer?.Invoke(this, e);
        }

        //Will be Removed
        private void OnStartCallTransfer(StartCallTransferEventArgs e)
        {
            StartCallTransfer?.Invoke(this, e);
        }

        /// <summary>
        /// Handles sound info of the current page.
        /// </summary>
        private void HandleSoundInfo()
        {
            if (_viewInterviewPageBrowser.HasSoundInfo)
            {
                if (PlaybackFound != null)
                {
                    PlaybackFound(
                        this,
                        new PlaybackFoundEventArgs
                        {
                            SoundFile = _viewInterviewPageBrowser.SoundFileName,
                            StartPlaybackAutomatically = _viewInterviewPageBrowser.StartPlaybackAutomatically
                        });
                }
            }
            else
            {
                OnPlaybackNotFound(null);
            }
        }

        /// <summary>
        /// Fires StartReview event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnStartReview(EventArgs e)
        {
            if (StartReview != null)
            {
                StartReview(this, e);
            }
        }

        private void m_Timer_Tick(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;

            _viewStatusBar.RespondentTime =
                TimezoneConverter.ConvertTimeFromUtc(
                    CurrentInterviewProperties.RespondentTimezone,
                    now.ToUniversalTime()
                ).ToLongTimeString();
            _viewStatusBar.InterviewerTime = now.ToLongTimeString();
        }

        /// <summary>
        /// Terminate current interview with specified status.
        /// </summary>
        /// <param name="terminationStatus">Termination status.</param>
        public void TerminateInterview(int terminationStatus)
        {
            _viewInterviewPageBrowser.TerminateInterview(terminationStatus);
        }

        public void TerminateInterviewFromAnotherThread(int terminationStatus)
        {
            var pageBrowserUpdater = new SafePageBrowserUpdater((UserControl)_viewInterviewPageBrowser);
            pageBrowserUpdater.Run(() => _viewInterviewPageBrowser.TerminateInterview(terminationStatus));
        }

        /// <summary>
        /// Do fast forward for current interview.
        /// </summary>
        public void FastForward()
        {
            _viewInterviewPageBrowser.FastForward();
        }

        /// <summary>
        /// Changes language of current interview. Function sets given value to "l" parameter in current page DOM.
        /// </summary>
        /// <param name="languageId">Language indentifier.</param>
        public void ChangeLanguage(int languageId)
        {
            _viewInterviewPageBrowser.ChangeLanguage(languageId);
        }

        /// <summary>
        /// Prepare page content from WebBrowser
        /// Changes relative pathes to absolute
        /// </summary>
        /// <remarks>
        /// Style sheet paths have following format:
        /// LINK id=ss__cs rel=stylesheet type=text/css href="stylesheet.aspx?pid=p625401542"
        /// Some images have absolute source path
        /// IMG SRC="http://survey.boomer.firmglobal.net/wix/http://www.confirmit.com/App_Themes/Confirmit/Img/logo.jpg"
        /// </remarks>
        /// <returns></returns>
        private string GetPageContent()
        {
            string pageContent = _viewInterviewPageBrowser.GetPageContent();

            if (String.IsNullOrEmpty(pageContent)) return String.Empty;

            //remove insignificant spaces
            pageContent = Regex.Replace(pageContent, @"(?<=[>])\s+(?=[<])", "");

            string hostName = _viewInterviewPageBrowser.Uri.Host;
            string scheme = _viewInterviewPageBrowser.Uri.Scheme;

            if (String.Compare(hostName, "localhost", StringComparison.OrdinalIgnoreCase) == 0)
            {
                hostName = Dns.GetHostName();
                scheme = "http";
            }

            pageContent = LinkRepairer.Repair(pageContent, hostName, scheme);

            return pageContent;
        }

        /// <summary>
        /// Sets dial status and continue interviewing.
        /// </summary>
        /// <param name="dialStatus">Dial status.</param>
        public void SetDialStatusAndContinue(int dialStatus)
        {
            _viewInterviewPageBrowser.DialStatus = dialStatus;
            _viewInterviewPageBrowser.ContinueInterview();
            IsDialPageProcessed = true;
        }

        /// <summary>
        /// Continues current interview.
        /// </summary>
        public void ContinueInterview()
        {
            _viewInterviewPageBrowser.ContinueInterview();
        }

        /// <summary>
        /// Adds parameter to Uri
        /// </summary>
        /// <param name="originalUri">original Url</param>
        /// <param name="queryToAppend">query to append</param>
        /// <returns>modified Uri</returns>
        internal Uri AddQueryToUri(Uri originalUri, string queryToAppend)
        {
            if (originalUri == null)
            {
                throw new ArgumentNullException("originalUri");
            }

            var builder = new UriBuilder(originalUri);
            if (builder.Query.Length > 1)
                builder.Query = builder.Query.Substring(1) + "&" + queryToAppend;
            else
                builder.Query = queryToAppend;

            return builder.Uri;
        }

        /// <summary>
        /// Navigates to next question. 
        /// If current question is last one on page goes to next page.
        /// </summary>
        private void NavigateToNextQuestion()
        {
            if (_viewInterviewPageBrowser.IsCurrentQuestionLast)
            {
                _viewInterviewPageBrowser.DoNextPage();
            }
            else
            {
                _viewInterviewPageBrowser.DoNextQuestion();
            }
        }

        /// <summary>
        /// Returns current state
        /// </summary>        
        public ConsoleState GetConsoleState()
        {
            switch (InterviewMode)
            {
                case InterviewModes.Interviewing:
                    return ConsoleState.Interviewing;
                case InterviewModes.Reviewing:
                    return ConsoleState.Reviewing;
                default:
                    return ConsoleState.Selecting;

            }
        }

        /// <summary>
        /// Clears stored interview resources and fires InterviewFinished event.
        /// </summary>
        internal void FinishInterview()
        {
            OnStateChanged(
                new StateChangedEventArgs
                {
                    MessageType = MonitoringMessageTypes.InterviewFinishMessage,
                    IsScreenRecordingEnabled = _isScreenRecordingEnabled
                },
                UserPassport.Instance.MonitoringIdentity
            );

            _timer.Stop();
            CurrentInterviewProperties = null;
            _viewStatusBar.Mode = StatusBarModes.MainView;
            InterviewMode = InterviewModes.Selecting;
            AllowTelephonyCommands = true;

            _viewInterviewPageBrowser.LoadContentSync("<html><body /></html>");

            OnInterviewFinished(EventArgs.Empty);
        }

        public void HighlightEnterZone(Color color)
        {
            _viewInterviewPageBrowser.HighlightEnterZone(color);
        }

        public void CheckBrowserFeatures()
        {
            _viewInterviewPageBrowser.CheckBrowserFeatures();
        }
    }
}
