using System;
using System.IO;
using Confirmit.CATI.Common;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public class InitializeApplication : IInitializeApplication
    {
        private readonly ILogger _logger;

        public InitializeApplication(ILogger logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Creates working directory and client settings file.
        /// </summary>
        /// <remarks>
        /// If user works locally 
        /// - settings file is situated in common location
        /// - log file is situated in user-specific location
        /// If user works remotely
        /// - settings file is situated in user-specific location
        /// - log file is situated in user-specific location
        /// </remarks>
        public void InitClientSettings()
        {
            try
            {
                if (ApplicationManager.IsTerminalServerSession == false)
                {
                    ClientSettingsProvider.SettingsFilePath = ApplicationManager.ClientSettingsCommonFilePath;

                    bool directoryNotExistent = !Directory.Exists(ApplicationManager.ApplicationCommonPath);

                    if (directoryNotExistent)
                    {
                        Directory.CreateDirectory(ApplicationManager.ApplicationCommonPath);
                    }

                    FolderPermissionManager.SetFullControlForStandardUsers(ApplicationManager.ApplicationCommonPath, directoryNotExistent);

                    if (Directory.Exists(ApplicationManager.ApplicationUserSpecificPath) == false)
                    {
                        Directory.CreateDirectory(ApplicationManager.ApplicationUserSpecificPath);
                    }

                    if (File.Exists(ApplicationManager.OldLicenseAgreementFilePath))
                    {
                        File.Copy(ApplicationManager.OldLicenseAgreementFilePath, ApplicationManager.LicenseAgreementFilePath);
                    }

                    if (File.Exists(ApplicationManager.ClientSettingsCommonFilePath) == false)
                    {
                        //It is used for mark settings as modified, otherwise they will not be saved.
                        ClientSettings.Default.DefaultCompanyAlias = ClientSettings.Default.DefaultCompanyAlias;
                        ClientSettings.Default.Save();
                    }
                }
                else
                {
                    ClientSettingsProvider.SettingsFilePath = ApplicationManager.ClientSettingsUserProfileFilePath;

                    if (Directory.Exists(ApplicationManager.ApplicationUserSpecificPath) == false)
                    {
                        Directory.CreateDirectory(ApplicationManager.ApplicationUserSpecificPath);

                        if (File.Exists(ApplicationManager.ClientSettingsCommonFilePath))
                        {
                            File.Copy(ApplicationManager.ClientSettingsCommonFilePath,
                                ApplicationManager.ClientSettingsUserProfileFilePath);

                            ClientSettings.Default.StationId = String.Empty;
                            ClientSettings.Default.Save();
                        }
                    }

                    if (File.Exists(ApplicationManager.OldLicenseAgreementFilePath))
                    {
                        File.Copy(ApplicationManager.OldLicenseAgreementFilePath, ApplicationManager.LicenseAgreementFilePath);
                    }

                    if (File.Exists(ApplicationManager.ClientSettingsUserProfileFilePath) == false)
                    {
                        //It is used for mark settings as modified, otherwise they will not be saved.
                        ClientSettings.Default.DefaultCompanyAlias = ClientSettings.Default.DefaultCompanyAlias;
                        ClientSettings.Default.Save();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Log(ex);
            }
        }

        /// <summary>
        /// Initializes logging sub-system.
        /// </summary>
        /// <param name="logPostfix"></param>
        public void InitLogging(string logPostfix)
        {
            if (Properties.Settings.Default.EnableErrorLog)
            {
                Logger.InitFileListener(ApplicationManager.GetLogFilePath(logPostfix), Properties.Settings.Default.MaxLogFileSize);
            }
        }
    }
}