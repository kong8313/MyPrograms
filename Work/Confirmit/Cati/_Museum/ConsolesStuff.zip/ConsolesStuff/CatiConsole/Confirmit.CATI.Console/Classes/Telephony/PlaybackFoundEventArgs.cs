﻿using System;

namespace Confirmit.CATI.Console.Classes.Telephony
{
    /// <summary>
    /// Delegate for PlaybackFound event.
    /// </summary>
    /// <param name="sender">Sender object.</param>
    /// <param name="e">Dial event arguments.</param>
    internal delegate void PlaybackFoundEventHandler(object sender, PlaybackFoundEventArgs e);

    /// <summary>
    /// Contains arguments of PlaybackFound event.
    /// </summary>
    internal class PlaybackFoundEventArgs : EventArgs
    {
        #region Properties

        /// <summary>
        /// Gets/sets SoundFile name
        /// </summary>
        public string SoundFile
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets StartPlaybackAutomatically.
        /// </summary>
        public bool StartPlaybackAutomatically
        {
            get;
            set;
        }

        #endregion
    }
}