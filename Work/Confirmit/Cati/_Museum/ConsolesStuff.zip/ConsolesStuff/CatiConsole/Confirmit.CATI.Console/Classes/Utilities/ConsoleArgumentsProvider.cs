﻿using System;
using System.Deployment.Application;
using System.Linq;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    class ConsoleArgumentsProvider
    {
        public string[] GetArguments()
        {
            if (ApplicationDeployment.IsNetworkDeployed)
            {
                var activationData = AppDomain.CurrentDomain.SetupInformation.ActivationArguments.ActivationData;
                if (activationData != null && activationData.Length >= 1)
                {
                    return activationData[0].Split(new[] { ";", "," }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(x => x.Trim())
                        .Where(y => !String.IsNullOrEmpty(y))
                        .ToArray();
                }
            }
            else
            {
                var args = Environment.GetCommandLineArgs();
                if (args.Length > 1)
                {
                    return args;
                }
            }

            return null;
        }
    }
}
