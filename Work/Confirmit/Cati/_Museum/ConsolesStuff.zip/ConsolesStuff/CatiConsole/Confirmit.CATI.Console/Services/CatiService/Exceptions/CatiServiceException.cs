﻿using System;
using Confirmit.CATI.Common;

namespace Confirmit.CATI.Console.Services.CatiService.Exceptions
{
    /// <summary>
    /// Represents basic class for all CatiWS specific exceptions.
    /// </summary>
    internal class CatiServiceException : ApplicationException
    {
        #region Constructors

        /// <summary>
        /// Initializes new instance of CatiServiceException class.
        /// </summary>
        public CatiServiceException()
        {
            Error = CATIErrorCodes.InternalError;
        }

        /// <summary>
        /// Initializes new instance of CatiServiceException class and fills if with given data.
        /// </summary>
        /// <param name="message">Message.</param>
        /// <param name="innerException">Inner exception.</param>
        public CatiServiceException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes new instance of CatiServiceException class and fills if with given data.
        /// </summary>
        /// <param name="error">CatiWS error code.</param>
        /// <param name="message">Message.</param>
        /// <param name="innerException">Inner exception.</param>
        public CatiServiceException(CATIErrorCodes error, string message, Exception innerException)
            : base(message, innerException )
        {
            Error = error;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets/sets CatiWS error code.
        /// </summary>
        public CATIErrorCodes Error
        {
            get;
            set;
        }

        #endregion
    }
}
