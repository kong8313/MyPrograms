﻿using System;
using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Console.Services.CatiService;

namespace Confirmit.CATI.Console.Classes.User
{
    /// <summary>
    /// Contains user specific data. For instance, user name and identifier, company identifier
    /// and so on.
    /// </summary>
    public class UserPassport
    {
        private static UserPassport m_Instance = null;

        private bool m_IsMonitored = false;
        private MonitoringIdentity m_Identity = new MonitoringIdentity();

        /// <summary>
        /// Initialiazes new instance of UserPassport class.
        /// </summary>
        protected UserPassport()
        {
        }

        public static UserPassport Instance
        {
            get
            {
                if (m_Instance == null)
                {
                    m_Instance = new UserPassport();
                }

                return m_Instance;
            }
        }

        /// <summary>
        /// User login name.
        /// </summary>
        public string UserName 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// User identifier.
        /// </summary>
        public int UserId 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// User password.
        /// </summary>
        public string Password
        {
            get;
            set;
        }

        /// <summary>
        /// Company alias.
        /// </summary>
        public string CompanyAlias
        {
            get;
            set;             
        }

        /// <summary>
        /// Company identifier.
        /// </summary>
        public int CompanyId 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// User properties which is returned during login process.
        /// </summary>
        public IUserProperties Properties 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// Gets/sets value indicating monitoring status of user.
        /// </summary>
        public bool IsMonitored
        {
            get
            {
                return m_IsMonitored || MonitoringIdentity.DeferredIdentity != null;
            }
        }

        /// <summary>
        /// Returns true if this user is on-line monitored.
        /// </summary>
        public bool IsOnLineMonitored
        {
            get
            {
                return m_IsMonitored;
            }
        }

        /// <summary>
        /// Gets/sets monitoring session identity.
        /// </summary>
        public MonitoringIdentity MonitoringIdentity
        {
            get
            {
                return m_Identity;
            }
        }

        /// <summary>
        /// Occurs when monitoring is started.
        /// </summary>
        public event EventHandler<EventArgs> MonitoringStarted;

        /// <summary>
        /// Occurs when monitoring is going to be stopped.
        /// </summary>
        public event EventHandler<EventArgs> MonitoringStoping;

        /// <summary>
        /// Gets user identity in format 'companyID':'FusionPersonName'.
        /// </summary>
        /// <returns>User identity.</returns>
        public string GetUserIdentityString()
        {
            return String.Format("{0}:{1}", CompanyId, UserName);
        }

        /// <summary>
        /// Sets monitoring options and fires corresponding events.
        /// </summary>
        /// <param name="isMonitoring">Monitoring flag.</param>
        /// <param name="sessionId">Monitoring session identifier.</param>
        /// <remarks>If monitoring flag is changing it's previuos state,
        /// we should fire monitoring start event or monitoring end event.
        /// If session identifier is changing, we should stop monitoring
        /// with previous session identifier and start monitoring with new one.</remarks>
        public void SetMonitoringOptions(bool isMonitoring, long sessionId)
        {
            bool isNewMonitoringFlag = (m_IsMonitored != isMonitoring);

            if (isNewMonitoringFlag)
            {
                if (m_IsMonitored)
                {
                    OnMonitoringStoping(EventArgs.Empty);
                }

                lock (this)
                {
                    m_IsMonitored = isMonitoring;
                }

                if (m_IsMonitored)
                {
                    OnMonitoringStarted(EventArgs.Empty);
                }

                lock (m_Identity)
                {
                    m_Identity.MonitoringSessionId = sessionId;
                }
            }
            else if (m_Identity.MonitoringSessionId != sessionId)
            {
                OnMonitoringStoping(EventArgs.Empty);

                lock (this)
                {
                    m_IsMonitored = false;
                }

                lock (m_Identity)
                {
                    m_Identity.MonitoringSessionId = sessionId;
                }

                lock (this)
                {
                    m_IsMonitored = true;
                }

                OnMonitoringStarted(EventArgs.Empty);
            }
        }

        /// <summary>
        /// Fires MonitoringStarted event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnMonitoringStarted(EventArgs e)
        {
            if (MonitoringStarted != null)
            {
                MonitoringStarted(this, e);
            }
        }

        /// <summary>
        /// Fires MonitoringStoping event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnMonitoringStoping(EventArgs e)
        {
            if (MonitoringStoping != null)
            {
                MonitoringStoping(this, e);
            }
        }
    }
}
