﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Confirmit.CATI.Console.Services.CatiService;

namespace Confirmit.CATI.Console.Classes.Messaging
{
    /// <summary>
    /// Manager is responsible for messaging
    /// Receives messages in anisochronous mode
    /// </summary>
    internal class MessagingManager
    {
        #region Members

        private static MessagingManager m_Instance = null;        
        private BackgroundWorker m_MessageDownloadWorker = null;
        private Queue<SupervisorMessage> m_Messages = new Queue<SupervisorMessage>();

        #endregion
        
        #region Events

        /// <summary>
        /// Occurs when new messages are downloaded
        /// </summary>
        public event EventHandler MessagesReceived;

        #endregion        

        #region Properties

        /// <summary>
        /// Gets single instance of MessagingManager
        /// </summary>
        public static MessagingManager Instance
        {
            get
            {
                lock (typeof(MessagingManager))
                {
                    if (m_Instance == null)
                    {
                        m_Instance = new MessagingManager();
                    }
                }
                return m_Instance;
            }
        }

        #endregion

        #region Constructors

        private MessagingManager()
        {
            m_MessageDownloadWorker = new BackgroundWorker();
            m_MessageDownloadWorker.DoWork += new DoWorkEventHandler(m_MessageDownloadWorker_DoWork);
            m_MessageDownloadWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(m_MessageDownloadWorker_RunWorkerCompleted);
        }

        #endregion
                
        #region Methods

        /// <summary>
        /// Starts messages downloading
        /// </summary>
        public void StartDownload()
        {
            if (m_MessageDownloadWorker.IsBusy == false)
            {
                m_MessageDownloadWorker.RunWorkerAsync();
            }
        }

        /// <summary>
        /// Returns all already received messages
        /// Messages are deleted from message queue
        /// </summary>
        /// <returns></returns>
        public List<SupervisorMessage> GetMessages()
        {
            List<SupervisorMessage> messages = new List<SupervisorMessage>();

            lock (m_Messages)
            {
                while (m_Messages.Count > 0)
                {
                    messages.Add(m_Messages.Dequeue());
                }
            }
            return messages;
        }

        /// <summary>
        /// Returns last received message
        /// Message is not deleted from message queue
        /// </summary>
        /// <returns></returns>
        public SupervisorMessage GetLastMessage()
        {
            SupervisorMessage lastMessage = null;            

            lock (m_Messages)
            {
                if (m_Messages.Count > 0)
                {
                    lastMessage = m_Messages.Last();
                }                
            }

            return lastMessage;
        }


        #endregion

        #region Event handlers

        private void m_MessageDownloadWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (MessagesReceived != null)
            {
                MessagesReceived(this, EventArgs.Empty);
            }
        }

        private void m_MessageDownloadWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            SupervisorMessageCollection messages = new SupervisorMessageCollection();

            try
            {
                messages = CatiServiceManagerWrapper.GetMessages();
            }
            catch
            {
                //probably we should suppress any exception from GetMessages
            }

            lock (m_Messages)
            {
                foreach (SupervisorMessage msg in messages)
                {
                    m_Messages.Enqueue(msg);
                }
            }
        }

        #endregion               
    }
}
