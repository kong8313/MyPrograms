using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Views.ViewInterfaces;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class BaseQuestionHandler : IQuestionHandler
    {
        protected readonly Dictionary<string, string> PredefinedAnswers;
        protected readonly IViewInterviewPageBrowser PageBrowser;
        protected string QuestionId;
        protected readonly SafePageBrowserUpdater PageBrowserUpdater;

        public BaseQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers)
        {
            PageBrowser = pageBrowser;
            PredefinedAnswers = predefinedAnswers;
            PageBrowserUpdater = new SafePageBrowserUpdater((UserControl)pageBrowser);
            PageBrowserUpdater.Run(() =>
                {
                    QuestionId = PageBrowser.CurrentQuestionId;
                });
        }

        public void SetAnswers()
        {
            throw new NotImplementedException();
        }

        public bool ValueWasSet { get; set; }

        protected void SetAnswer(string elementId, string value)
        {
            try
            {
                PageBrowserUpdater.Run(() => PageBrowser.SetAnswer(elementId, value));
                ValueWasSet = true;
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
                ValueWasSet = false;
            }
        }

        

        protected void FireClick(string elementId)
        {
            try
            {
                PageBrowserUpdater.Run(() => PageBrowser.FireClickEventByElementId(elementId));
                ValueWasSet = true;
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
                ValueWasSet = false;
            }
        }

        protected void SetQuestionAnswered()
        {
            ValueWasSet = true;
        }

        protected void SetValueForMultiAnswer(string key)
        {
            var valueInt = Convert.ToInt32(PredefinedAnswers[key]);
            if (valueInt == 0)
            {
                return;
            }

            SetAnswer(string.Format("{0}", key), Convert.ToBoolean(valueInt).ToString());
        }

        protected void SetOtherForNonEmpty()
        {
            var keysOther = GetKeysForOther();

            foreach (var keyother in keysOther)
            {
                if (string.IsNullOrEmpty(PredefinedAnswers[keyother]))
                {
                    continue;
                }

                SetAnswer(string.Format("{0}", keyother), PredefinedAnswers[keyother]);
            }
        }

        protected void SetOpenTextValueForNonEmpty()
        {
            var keys = GetKeysForNonOther();

            foreach (var key in keys)
            {
                if (string.IsNullOrEmpty(PredefinedAnswers[key]))
                {
                    continue;
                }

                SetAnswer(key, PredefinedAnswers[key]);
            }
        }

        protected string[] GetKeysForOther()
        {
            var keysOther =
                PredefinedAnswers.Keys.Where(
                    x => x.StartsWith(string.Format("{0}_", QuestionId)) && x.EndsWith("other")).ToArray();

            return keysOther;
        }

        protected string[] GetKeysForNonOther()
        {
            var keys =
                PredefinedAnswers.Keys.Where(
                    x => x.StartsWith(string.Format("{0}_", QuestionId)) && x.EndsWith("other") == false).ToArray();
            return keys;
        }
    }
}