using Confirmit.CATI.Common.ConsoleService.Abstract;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public interface IConsoleDescriptionProvider
    {
        ConsoleDescription GetConsoleDescription();
        string GetConsoleDescriptionText();
    }
}