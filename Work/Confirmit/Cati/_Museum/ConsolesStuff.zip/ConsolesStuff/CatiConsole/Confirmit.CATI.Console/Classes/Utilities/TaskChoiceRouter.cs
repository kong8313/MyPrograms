using System;
using Confirmit.CATI.Console.Presenters;

namespace Confirmit.CATI.Console.Classes.Utilities
{
    public class TaskChoiceRouter : ITaskChoiceRouter
    {
        public Action StartManualMode { get; set; }
        public Action StartSurveyAssignmentMode { get; set; }
        public Action StartAutomaticMode { get; set; }
    }
}