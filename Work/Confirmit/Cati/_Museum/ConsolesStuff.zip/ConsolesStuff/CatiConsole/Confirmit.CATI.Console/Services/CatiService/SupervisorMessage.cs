﻿using System;
using System.Collections.Generic;
using Confirmit.CATI.Common.ConsoleService.Abstract;

namespace Confirmit.CATI.Console.Services.CatiService
{
    /// <summary>
    /// Represents supervisor message
    /// </summary>
    public class SupervisorMessage
    {
        #region Constructors

		/// <summary>
		/// Constructs new instance of Appointment class and fills it with
		/// given data.
		/// </summary>
        /// <param name="message">CATI Web Service appointment.</param>
        public SupervisorMessage(Messages message)
		{
			if (message == null)
			{
				throw new ArgumentNullException("message");
			}

			Body =  message.Body;
            CreateTime = message.CreateTime.Value;
            SupervisorName = message.SupervisorName;            
		}		

		#endregion

        #region Properties

        /// <summary>
        /// Message body
        /// </summary>
        public string Body
        {
            get;
            set;
        }

        /// <summary>
        /// Message creation time in UTC format
        /// </summary>
        public DateTime CreateTime
        {
            get;
            set;
        }

        /// <summary>
        /// Surpervisor name 
        /// </summary>
        public string SupervisorName
        {
            get;
            set;
        }

        #endregion
    }
    /// <summary>
    /// Represents collection of appointments.
    /// </summary>
    public class SupervisorMessageCollection : List<SupervisorMessage>
    {
        #region Constructors

        /// <summary>
        /// Initializes new instance of AppointmentCollection class.
        /// </summary>
        public SupervisorMessageCollection()
        {
        }

        /// <summary>
        /// Initializes new instance of AppointmentCollection class and fills it with given
        /// list of CATI Web Service appointments.
        /// </summary>
        /// <param name="messages">Enumeration with CATI Web Service appointments.</param>
        /// <exception cref="ArgumentNullException">Appointments enumeration is null.</exception>
        public SupervisorMessageCollection(IEnumerable<Messages> messages)
        {
            if (messages == null)
            {
                throw new ArgumentNullException("messages");
            }

            foreach (Messages msg in messages)
            {
                Add(new SupervisorMessage(msg));
            }
        }

        #endregion
    }
}
