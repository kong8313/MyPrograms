﻿using System;
using Confirmit.CATI.Common;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Common.Exceptions;
using Confirmit.CATI.Console.Shared.Resources;

namespace Confirmit.CATI.Console.Services.CatiService
{
    /// <summary>
    /// Represents helper class for Cati web service. It is wrapper of CatiServiceManager.
    /// It calls methods of CatiServiceManager and adds useful functionality to them.
    /// </summary>
    public class CatiServiceHelper : ICatiServiceHelper
    {
        private readonly ICatiServiceManager _catiServiceManager;

        public CatiServiceHelper(ICatiServiceManager catiServiceManager)
        {
            _catiServiceManager = catiServiceManager;
        }

        /// <summary>
        /// Event occurs when GetState method returns error state.
        /// </summary>
        public event GetStateErrorEventHandler GetStateError;

        /// <summary>
        /// Returns current state of CatiWS. If CatiWS.GetState() reports problem state
        /// function fires GetStateError event and returns null.
        /// If Interviewer is not logged in (<see cref="InterviewerNotLoggedInException"/> exception is thrown) - 
        /// sets not logged in state.
        /// </summary>
        /// <returns>State object or null.</returns>
        public ProcessState GetState()
        {
            ProcessState state;

            try
            {
                state = _catiServiceManager.GetState();
            }
            catch (InterviewerNotLoggedInException)
            {
                state = new ProcessState {interviewerLoginState = LoginState.NOT_LOGGED_IN};
            }

            Logger.Write(state.ToString(), MessageTypes.Information);

            if (state.Problems.IsProblem)
            {
                OnGetStateError(new GetStateErrorEventArgs(state.Problems));
                state = null;
            }

            return state;
        }

        public void GetState(int attemptNumber, out ProcessState state)
        {
            if (attemptNumber > 1)
            {
                Logger.Write(
                    Strings.ResourceManager.GetString("Log_AttemptToCallMethod", attemptNumber, "GetState"),
                    MessageTypes.Error);
            }

            state = GetState();
        }

        public bool? IsInterviewScreenRecordingEnabled(int surveyId)
        {
            return _catiServiceManager.IsInterviewScreenRecordingEnabled(surveyId);
        }

        /// <summary>
        /// Fires GetStateError event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        private void OnGetStateError(GetStateErrorEventArgs e)
        {
            if (GetStateError != null)
            {
                GetStateError(this, e);
            }
        }
    }
}
