using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Console.Resources;

namespace Confirmit.CATI.Console.Classes.LoadTesting
{
    public class AutoPilotArgumentsParser
    {
        private const string UserNameArgument = "UserName";
        private const string PasswordArgument = "Password";
        private const string MinDelayArgument = "MinDelay";
        private const string MaxDelayArgument = "MaxDelay";
        private const string FileNameArgument = "FileName";
        private const string TimesToRepeatArgument = "TimesToRepeat";
        private const string StationId = "StationId";
        private const string Company = "Company";
        private const string ExtensionNumber = "ExtensionNumber";
        private const string Locale = "Locale";

        private const int DefaultTimesToRepeat = 1;

        private readonly CultureInfo _defaultLocale = new CultureInfo("en-US");

        private readonly IAutoPilotFileNameValidator _fileNameValidator;

        public AutoPilotArgumentsParser()
        {
            _fileNameValidator = new AutoPilotFileNameValidator();
        }

        public AutoPilotArgumentsParser(IAutoPilotFileNameValidator fileNameValidator)
        {
            _fileNameValidator = fileNameValidator;
        }

        public AutoPilotArguments ParseArguments(string[] args)
        {
            if (args == null)
            {
                return null;
            }

            args = args.Where(x => string.IsNullOrEmpty(x) == false).ToArray();
            if (args.Length == 0)
            {
                return null;
            }

            var arguments = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            PutArgumentsToDictionary(args, arguments);

            AutoPilotArguments autoPilotArgs;
            try
            {
                autoPilotArgs = new AutoPilotArguments
                {
                    UserName = arguments[UserNameArgument],
                    Password = arguments[PasswordArgument],
                    MinDelay = (int) GetIntArgument(arguments[MinDelayArgument], MinDelayArgument),
                    MaxDelay = (int) GetIntArgument(arguments[MaxDelayArgument], MaxDelayArgument),
                    FileName = arguments[FileNameArgument],
                    ExtensionNumber = arguments[ExtensionNumber],
                    StationId = GetStationIdArgument(arguments[StationId]),
                    Company = arguments[Company],
                    Locale = arguments.ContainsKey(Locale) ? GetLocaleArgument(arguments[Locale]) : _defaultLocale,
                    TimesToRepeat =
                        arguments.ContainsKey(TimesToRepeatArgument)
                            ? GetTimeToRepeatArgument(arguments[TimesToRepeatArgument])
                            : DefaultTimesToRepeat
                };

                _fileNameValidator.ValidateFileName(autoPilotArgs.FileName);
            }
            catch (KeyNotFoundException)
            {
                throw new AutopilotArgumentException(Strings.Autopilot_NotAllArgumentsSupplied_Error);
            }
            catch (CultureNotFoundException)
            {
                throw new AutopilotArgumentException(Strings.Autopilot_Locale_Argument_Is_Not_Valid);
            }

            if (autoPilotArgs.MinDelay > autoPilotArgs.MaxDelay)
            {
                throw new AutopilotArgumentException(Strings.Autopilot_MinDelay_Error);
            }

            return autoPilotArgs;
        }

        private CultureInfo GetLocaleArgument(string s)
        {
            return string.IsNullOrEmpty(s) ? _defaultLocale : new CultureInfo(s);
        }

        private string GetStationIdArgument(string stationId)
        {
            var message = new StationIdValidator().Validate(stationId, new CancelEventArgs());
            if (string.IsNullOrEmpty(message) == false)
            {
                throw new AutopilotArgumentException(message);
            }

            return stationId;
        }

        private static void PutArgumentsToDictionary(IEnumerable<string> comandLineArguments, Dictionary<string, string> arguments)
        {
            foreach (var argument in comandLineArguments)
            {
                var splittedArguments = argument.Split('=');

                if (splittedArguments.Length == 2)
                {
                    arguments[splittedArguments[0].Trim()] = splittedArguments[1].Trim();
                }
            }
        }

        private int GetTimeToRepeatArgument(string value)
        {
            int timesToRepeat;
            return int.TryParse(value, out timesToRepeat) && timesToRepeat > 0 ? timesToRepeat : DefaultTimesToRepeat;
        }

        private UInt32 GetIntArgument(string argumentValue, string argumentName)
        {
            UInt32 value;
            if (UInt32.TryParse(argumentValue, out value))
            {
                return value;
            }

            throw new AutopilotArgumentException(
                string.Format(Strings.Autopilot_SuppliedValueNotValidInteger_Error, argumentValue,
                argumentName));
        }
    }
}