﻿using Confirmit.CATI.Console.Classes.Monitoring;

namespace Confirmit.CATI.Console.Classes.Sender
{
    public interface IEventSender
    {
        void Dispose();
        void ProcessEvents(object sender, StateChangedEventArgs e, MonitoringIdentity sessionId);
    }
}