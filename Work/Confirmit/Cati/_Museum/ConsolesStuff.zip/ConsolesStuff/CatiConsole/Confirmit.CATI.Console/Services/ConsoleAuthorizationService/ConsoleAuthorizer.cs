﻿using Confirmit.CATI.Common.Contracts.ConsoleAuthorizationService;
using Confirmit.CATI.Common.WcfTools;
using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Console.Shared.Log;

namespace Confirmit.CATI.Console.Services.ConsoleAuthorizationService
{
    /// <summary>
    /// Represents intermediate level between application and ConsoleAuthorization WCF Service.
    /// </summary>
    internal class ConsoleAuthorizer
    {
        private readonly ChannelFactoryWrapper<IConsoleAuthorizationService> channelFactoryWrapper =
           new ChannelFactoryWrapper<IConsoleAuthorizationService>(
               new ConsoleAuthorizationServiceChannelFactoryWrapperConfiguration(),
               new Logger());

        public int AuthorizeAndReturnCompanyId(string userName, string password, string companyAlias, string stationId)
        {
            return channelFactoryWrapper.Execute(
                service => service.AuthorizeAndReturnCompanyId(userName, password, companyAlias, stationId));
        }

        public bool IsLatestVersion()
        {
            return channelFactoryWrapper.Execute(service => service.IsLatestVersion(ApplicationManager.AssemblyVersion));
        }

        public void ChangePersonPassword(string userName, string oldPassword, string newPassword, string companyAlias, string stationId)
        {
            channelFactoryWrapper.Execute(service => service.ChangePersonPassword(userName, oldPassword, newPassword, companyAlias, stationId));
        }

        public void Release()
        {
            channelFactoryWrapper.Release();
        }
    }
}
