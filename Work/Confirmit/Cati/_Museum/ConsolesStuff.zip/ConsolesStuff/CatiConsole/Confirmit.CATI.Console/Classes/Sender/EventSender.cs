﻿using System;
using System.Threading;
using System.Collections.Generic;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Console.Classes.Utilities;
using Confirmit.CATI.Console.Resources;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.Monitoring.Common.Serialization;
using Confirmit.CATI.Monitoring.Common.StateData;

namespace Confirmit.CATI.Console.Classes.Sender
{
    /// <summary>
    /// Represents class which is responsible in sending monitoring messages 
    /// to monitoring service.
    /// </summary>
    public class EventSender : IDisposable, IEventSender
    {
        private readonly Thread _sendThread;
        private readonly AutoResetEvent _objectEnqueued;
        private int _numFinishedInterviews;
        private readonly ManualResetEvent _nothingToSend;
        private readonly Queue<Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>> _eventsQueue;
        private volatile bool _terminateThread;
        private StateEventInfo _firstEventForDeferredMonitoring;
        private InterviewingInitialStateData _initialStateForDeferredMonitoring;
        private readonly ICatiServiceHelper _catiServiceHelper;


        /// <summary>
        /// Initializes new instance of EventSender class.
        /// </summary>
        public EventSender()
        {
            _eventsQueue = new Queue<Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>>();
            _terminateThread = false;
            _numFinishedInterviews = 0;
            _objectEnqueued = new AutoResetEvent(false);
            _nothingToSend = new ManualResetEvent(false);
            _sendThread = new Thread(SendEvents) { IsBackground = true };
            _sendThread.Start();
            _catiServiceHelper = ServiceLocator.Resolve<ICatiServiceHelper>();
        }

        private const int MaxFinishedInterviews = int.MaxValue/2;

        /// <summary>
        /// Finish sending events to the server.
        /// </summary>
        public void Dispose()
        {
            //force sending all evetns in the queue
            Interlocked.Exchange(ref _numFinishedInterviews, MaxFinishedInterviews);
            _nothingToSend.Reset();
            _objectEnqueued.Set();

            if (!_nothingToSend.WaitOne(Properties.Settings.Default.MonitoringEventsFinishTimeoutMs))
            {
                Logger.Write(string.Format(Strings.Log_MonitoringLostEvents, Count()), MessageTypes.Error);
            }
            
            //force thread termination
            _terminateThread = true;
            Interlocked.Exchange(ref _numFinishedInterviews, MaxFinishedInterviews);
            _objectEnqueued.Set();
            if (!_sendThread.Join(Properties.Settings.Default.MonitoringEventsFinishTimeoutMs))
            {
                Logger.Write(string.Format(Strings.Log_MonitoringThreadNotFinished, Properties.Settings.Default.MonitoringEventsFinishTimeoutMs), MessageTypes.Error);
            }
        }

        /// <summary>
        /// Handles StateChanged event, creates monitoring message according this event
        /// and places it into sending queue.
        /// </summary>
        /// <param name="sender">Sender object.</param>
        /// <param name="e">State changed arguments.</param>
        /// <param name="sessionId">Monitoring session identifier.</param>
        public void ProcessEvents(object sender, StateChangedEventArgs e, MonitoringIdentity sessionId)
        {
            if (UserPassport.Instance.IsMonitored && (sessionId!=null) && (e!=null))
            {
                var val = new Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity>(DateTime.UtcNow, e, sessionId.Clone());
                Enqueue(val);

                if (e.MessageType.IsFinishedMessage())
                {
                    Interlocked.Increment(ref _numFinishedInterviews);
                }

                // If the user is on-line monitored, events will be sent immediatedly. 
                // In other case, they will be send at the end of interview or on a user logout or in some configurable period.
                if (UserPassport.Instance.IsOnLineMonitored || e.MessageType.IsFinishedMessage())
                {
                    _objectEnqueued.Set();
                }
            }
        }

        /// <summary>
        /// The function is responsible of sending events to the monitoring service. It takes events from 
        /// the internal queue and send them to the service.
        /// </summary>
        /// <remarks>We send events using packages. Each package should contain events with the same
        /// session identifier. Packages are sent at the end of interview or on a user logout or 
        /// after a configurable time (2 hours by default). It may happend that a single interview may be sent in some pieces.
        /// If it is a super long interview >2 hours it may be sent in several pieces due to timeout.
        /// Now we do not check the size of the packet. We hope that after compression it will be small enough.</remarks>
        private void SendEvents()
        {
            do
            {
                try
                {
                    _objectEnqueued.WaitOne(Properties.Settings.Default.MonitoringEventsSendDelayMs);
                    int numFinishedInterviews = Interlocked.Exchange(ref _numFinishedInterviews, 0);
                    numFinishedInterviews = (numFinishedInterviews == 0) ? 1 : numFinishedInterviews;

                    if (_terminateThread)
                    {
                        break;
                    }

                    var packetterLive = new StateEventInfoPacketter();
                    var packetterDeferred = new StateEventInfoPacketter();

                    while ((Count() > 0) && (numFinishedInterviews > 0))
                    {
                        numFinishedInterviews--;
                        
                        #if DEBUG
                        if (numFinishedInterviews>0)
                        {
                            Logger.Write(String.Format("Monitoring:Debug: numFinishedInterviews={0}", numFinishedInterviews), MessageTypes.Information);                                
                        }  
                        #endif

                        MonitoringIdentity monitoringIdentity = null;
                        DateTime firstEventUtc = DateTime.MaxValue;
                        var eventListForDeferredMonitoring = new List<StateEventInfo>();
                        bool hasFinishedMessage = false;
                        
                        var eventListForLiveMonitoring = GetEventsToSend(ref firstEventUtc, ref eventListForDeferredMonitoring, ref hasFinishedMessage, ref monitoringIdentity);

                        if (UserPassport.Instance.IsOnLineMonitored && eventListForLiveMonitoring.Count > 0)
                        {
                            packetterLive.AddToPacket(eventListForLiveMonitoring);

                            CatiServiceManagerWrapper.SaveLiveMonitoringEvents(
                                UserPassport.Instance.CompanyId,
                                UserPassport.Instance.Properties.InterviewerId,
                                monitoringIdentity,
                                packetterLive.GetPacketBytes());
                        }

                        if (eventListForDeferredMonitoring.Count > 0)
                        {
                            // It is too expensive to log every event for the on-line monitoring. 
                            // So, we log only for the deferred monitoring.
                            if (!UserPassport.Instance.IsOnLineMonitored)
                            {
                                Logger.Write(string.Format(Strings.Log_TotalSize, packetterDeferred.GetPacketSize(), eventListForLiveMonitoring.Count), MessageTypes.Information);
                            }

                            packetterDeferred.AddToPacket(eventListForDeferredMonitoring);

                            CatiServiceManagerWrapper.SaveDeferredMonitoringEvents(
                                UserPassport.Instance.CompanyId,
                                UserPassport.Instance.Properties.InterviewerId,
                                monitoringIdentity,
                                packetterDeferred.GetPacketBytes(),
                                hasFinishedMessage,
                                firstEventUtc);
                        }

                        if (hasFinishedMessage && monitoringIdentity.DeferredIdentity != null)
                        {
                            CatiServiceManagerWrapper.RemoveRecordIfEmpty(monitoringIdentity.DeferredIdentity.DeferredRecordId);
                        }

                        packetterLive.ClearStream();
                        packetterDeferred.ClearStream();

                    } //while ((Count() > 0)&& (numFinishedInterviews>0))

                    if (Count()==0) 
                    {
                        _nothingToSend.Set();
                    }
                }
                catch (Exception e)
                {
                    Logger.Write(e);
                }

                // If there're some events and _terminateThread is true the events in the queue will be lost!
                // Also, since it is a backgroud thread, it can lost events in the queue when the application is terminated.
            } while (!_terminateThread);//do
                
        }

        /// <summary>
        /// Get events from the queue that belong to one sessions
        /// </summary>
        /// <param name="firstEventUtc">The first event timestamp for live monitoring</param>
        /// <param name="eventListForDeferredMonitoring">The first event timestamp for deferred monitoring</param>
        /// <param name="hasFinishedMessage">True if there's one of finishing events</param>
        /// <param name="monitoringIdentity">The session for the events</param>
        /// <returns></returns>
        public List<StateEventInfo> GetEventsToSend(ref DateTime firstEventUtc, ref List<StateEventInfo> eventListForDeferredMonitoring, ref bool hasFinishedMessage, ref MonitoringIdentity monitoringIdentity)
        {
            Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity> item;
            Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity> tmp;
            var eventListForLiveMonitoring = new List<StateEventInfo>();
            bool isScreenRecordingEnabledForInterview = false;
            bool? isScreenRecordingEnabledForSurvey = null;
            bool isStartMessagesForDeferredMonitoringSet = false;

            do
            {
                item = Dequeue();
                monitoringIdentity = item.Third;

                //TODO: Really speaking, we don't need to serialize State, it is better if it is serialized as an object
                //because it will be serialized as a part of anoher object and compression is implemented for the entire stream.
                var stateEventInfo = GetStateEventInfo(item);

                if (stateEventInfo.TimeStamp < firstEventUtc)
                {
                    firstEventUtc = stateEventInfo.TimeStamp;
                }

                eventListForLiveMonitoring.Add(stateEventInfo);
                PrepareStartMessagesForDeferredMonitoring(item, stateEventInfo);

                if (monitoringIdentity.DeferredIdentity != null && isScreenRecordingEnabledForSurvey == null)
                {
                    isScreenRecordingEnabledForSurvey =
                        _catiServiceHelper.IsInterviewScreenRecordingEnabled(monitoringIdentity.DeferredIdentity.SurveyId);
                }

                if (item.Second.IsScreenRecordingEnabled && isScreenRecordingEnabledForInterview == false)
                {
                    isScreenRecordingEnabledForInterview = true;
                }

                if (isScreenRecordingEnabledForInterview && isScreenRecordingEnabledForSurvey == false && !isStartMessagesForDeferredMonitoringSet)
                {
                    SetStartMessagesForDeferredMonitoring(ref firstEventUtc, eventListForDeferredMonitoring, item, stateEventInfo, ref isStartMessagesForDeferredMonitoringSet);
                }

                if (isScreenRecordingEnabledForSurvey == true || isScreenRecordingEnabledForInterview)
                {
                    eventListForDeferredMonitoring.Add(stateEventInfo);
                }

                hasFinishedMessage = hasFinishedMessage || stateEventInfo.MessageType.IsFinishedMessage();

                if (Count() == 0)
                {
                    break;
                }

                tmp = Peek();
            }
            while (monitoringIdentity.Equals(tmp.Third));

            return (eventListForLiveMonitoring);
        }

        internal StateEventInfo GetStateEventInfo(Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity> item)
        {
            return new StateEventInfo
            {
                MessageType = item.Second.MessageType,
                State = SerializationManager.Serialize(item.Second.MessageType, item.Second.State),
                TimeStamp = item.First
            };
        }

        private void PrepareStartMessagesForDeferredMonitoring(Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity> item, StateEventInfo stateEventInfo)
        {
            switch (item.Second.MessageType)
            {
                case MonitoringMessageTypes.InterviewStartMessage:
                    _firstEventForDeferredMonitoring = stateEventInfo;
                    break;
                case MonitoringMessageTypes.InterviewInitialMessage:
                    _initialStateForDeferredMonitoring = (InterviewingInitialStateData) item.Second.State;
                    break;
            }
        }

        private void SetStartMessagesForDeferredMonitoring(ref DateTime firstEventUtc,
            IList<StateEventInfo> eventListForDeferredMonitoring,
            Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity> item, StateEventInfo stateEventInfo,
            ref bool isStartMessagesForDeferredMonitoringSet)
        {
            // if we got consent for screen recording then we should add InterviewStartMessage and InterviewInitialMessage
            // for deferred record.
            // InterviewStartMessage was saved previously and we just insert it with proper time
            // InterviewInitialMessage will be created from nearest last InterviewPageBrowserPageCompletedMessage 
            if (item.Second.MessageType != MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage)
            {
                return;
            }

            firstEventUtc = stateEventInfo.TimeStamp.AddMilliseconds(-2);
            _firstEventForDeferredMonitoring.TimeStamp = firstEventUtc;
            eventListForDeferredMonitoring.Insert(0, _firstEventForDeferredMonitoring);

            _initialStateForDeferredMonitoring.PageContent = ((DocumentCompletedStateData) item.Second.State).PageContent;
            stateEventInfo.TimeStamp = stateEventInfo.TimeStamp.AddMilliseconds(-1);
            stateEventInfo.State =
                SerializationManager.Serialize(MonitoringMessageTypes.InterviewInitialMessage,
                    _initialStateForDeferredMonitoring);
            stateEventInfo.MessageType = MonitoringMessageTypes.InterviewInitialMessage;

            isStartMessagesForDeferredMonitoringSet = true;
        }


        /// <summary>
        /// Returns count of elements in queue.
        /// </summary>
        /// <returns>Count of elements.</returns>
        internal int Count()
        {
            lock (_eventsQueue)
            {
                return _eventsQueue.Count;
            }
        }

        /// <summary>
        /// Enqueue value.
        /// </summary>
        /// <param name="val">Value to enqueue.</param>
        internal void Enqueue(Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity> val)
        {
            lock (_eventsQueue)
            {
                _eventsQueue.Enqueue(val);
            }
        }

        /// <summary>
        /// Dequeue value.
        /// </summary>
        /// <returns>Value.</returns>
        internal Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity> Dequeue()
        {
            lock (_eventsQueue)
            {
                return _eventsQueue.Dequeue();
            }
        }

        /// <summary>
        /// Returns the object at the beginning of the event queue without removing it.
        /// </summary>
        /// <returns>The object at the beginning of the event queue.</returns>
        private Triplet<DateTime, StateChangedEventArgs, MonitoringIdentity> Peek()
        {
            lock (_eventsQueue)
            {
                return _eventsQueue.Peek();
            }
        }

    }
}
