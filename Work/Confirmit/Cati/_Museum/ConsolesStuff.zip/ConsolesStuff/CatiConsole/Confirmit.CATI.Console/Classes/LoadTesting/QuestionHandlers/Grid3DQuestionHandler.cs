using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Console.Views.Controls;
using Confirmit.CATI.Console.Views.ViewInterfaces;
using mshtml;

namespace Confirmit.CATI.Console.Classes.LoadTesting.QuestionHandlers
{
    public class Grid3DQuestionHandler : BaseQuestionHandler, IQuestionHandler
    {
        private readonly ILegacySurveyPageInteractor _interactor;

        public Grid3DQuestionHandler(IViewInterviewPageBrowser pageBrowser, Dictionary<string, string> predefinedAnswers)
            : base(pageBrowser, predefinedAnswers)
        {
            _interactor = (ILegacySurveyPageInteractor) PageBrowser.SurveyPageInteractor;
        }

        void IQuestionHandler.SetAnswers()
        {
            var keys = GetKeysForNonOther();

            foreach (var key in keys)
            {
                var valueInt = Convert.ToInt32(PredefinedAnswers[key]);
                if (valueInt == 0)
                {
                    continue;
                }

                SetAnswer(string.Format("{0}", key), Convert.ToBoolean(valueInt).ToString());
            }

            SetOtherForNonEmpty();

            SetValuesForSubQuestions();
        }

        protected void SetValuesForSubQuestions()
        {
            var inputs = GetSubQuestionsInputs();

            foreach (var input in inputs)
            {
                var count = inputs.Count(x => x.getAttribute("name") == input.getAttribute("name"));
                var key = input.getAttribute("name");
                if (count == 1)
                {
                    if (input.getAttribute("type") == "checkbox" || input.getAttribute("type") == "radio")
                    {
                        SetValueForMultiAnswer(key);
                    }
                    else
                    {
                        SetAnswer(key, PredefinedAnswers[key]);
                    }
                }
                else
                {
                    SetAnswer(string.Format("{0}_{1}", key, PredefinedAnswers[key]), "true");
                }
            }
        }

        protected List<IHTMLElement> GetSubQuestionsInputs()
        {
            var currentQuestionSubquestions = _interactor.CurrentQuestionSubQuestions;
            if (currentQuestionSubquestions == null || currentQuestionSubquestions.Count == 0)
            {
                return new List<IHTMLElement>();
            }

            var inputs = new List<IHTMLElement>();
            foreach (var subquestionInputs in currentQuestionSubquestions.Select(x => x.InputElements).ToArray())
            {
                inputs.AddRange(subquestionInputs);
            }

            return inputs;
        }
    }
}