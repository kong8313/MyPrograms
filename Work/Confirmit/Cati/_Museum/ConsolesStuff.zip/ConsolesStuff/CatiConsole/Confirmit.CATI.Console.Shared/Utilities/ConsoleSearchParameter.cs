﻿namespace Confirmit.CATI.Console.Shared.Utilities
{
    /// <summary>
    /// Represents search parameter
    /// </summary>
    public class ConsoleSearchParameter
    {
        /// <summary>
        /// Gets/sets name of column
        /// </summary>
        public string ColumnName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets caption of column
        /// </summary>
        public string ColumnCaption
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets full type name of search argument
        /// </summary>
        public string ColumnTypeName
        {
            get;
            set;
        }

        /// <summary>
        /// Search value
        /// </summary>
        public string Value
        {
            get;
            set;
        }
    }
}
