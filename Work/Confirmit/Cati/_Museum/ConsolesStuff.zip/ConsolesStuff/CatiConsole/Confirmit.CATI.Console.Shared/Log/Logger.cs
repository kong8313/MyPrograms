﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

using Confirmit.CATI.Common;
using Confirmit.CATI.Common.WcfTools;
using Confirmit.CATI.Common.WcfTools.ErrorServiceMessageHeader;
using Confirmit.CATI.Console.Shared.Resources;

namespace Confirmit.CATI.Console.Shared.Log
{
	/// <summary>
	/// Represents logger class for CATI Console.
	/// </summary>
	public class Logger : ILogger
    {
        #region Constructors

        static Logger()
        {
            IsEnabled = false;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets/sets value indicating that logging is enabled.
        /// </summary>
        private static bool IsEnabled
        {
            get;
            set;
        }

        #endregion

        #region Methods

        /// <summary>
		/// Writes exception to console log as error.
		/// </summary>
		/// <param name="ex">Exception to log.</param>
		public static void Write(Exception ex)
		{
            Write(ex.ToString(), MessageTypes.Error);
		}

        /// <summary>
        /// Writes exception to console log with th specified severity.
        /// </summary>
        /// <param name="ex">Exception to log.</param>
        /// <param name="type">Severity.</param>
	    public static void Write(Exception ex, MessageTypes type)
        {
            Write(ex.ToString(), type);
        }

		/// <summary>
		/// Writes message to console log.
		/// </summary>
		/// <param name="message">Message to log.</param>
		public static void Write(string message, MessageTypes type)
		{
			Trace.WriteLine(
				String.Format(FormatStringFromType(type), Now(), message)
			);
		}

        /// <summary>
        /// Writes message to console log.
        /// </summary>
        /// <param name="message">Message to log.</param>
        public static void WriteToTheFileTraceListenerOnly(string message, MessageTypes type)
        {
            var listener = Trace.Listeners.OfType<CatiTraceListener>().FirstOrDefault();

            if (listener != null)
            {
                listener.WriteLine(
                    String.Format(FormatStringFromType(type), Now(), message));
            }
        }
        
        /// <summary>
		/// Returns format string which corresponds to given message type.
		/// </summary>
		/// <param name="type">Message type.</param>
		/// <returns>Formta string.</returns>
		private static string FormatStringFromType(MessageTypes type)
		{
			string result = String.Empty;

			switch(type)
			{
				case MessageTypes.Error:
					result = LogResources.Log_ErrorFormat;
					break;
				case MessageTypes.Information:
                    result = LogResources.Log_NotificationFormat;
					break;
				case MessageTypes.Warning:
                    result = LogResources.Log_WarningFormat;
					break;
			}

			return result;
		}

		/// <summary>
		/// Retruns string respesentation of DateTime.Now.
		/// </summary>
		/// <returns>Date as string.</returns>
		private static string Now()
		{
			return DateTime.UtcNow.ToString();
		}

        public static void InitFileListener(string logFilePath, long maxFileSize)
        {
            Trace.AutoFlush = true;
            CatiTraceListener listener = new CatiTraceListener(logFilePath, maxFileSize);
            Trace.Listeners.Add(listener);
            IsEnabled = true;
        }

        public static void InitWsListener(
            string companyAlias,
            byte[] hashSecretKey,
            ClientErrorSource source,
            ILogInfoProvider infoProvider,
            ILoginPasswordAuthenticationDataProvider authenticationDataProvider,
            IMessageHeaderAccessor messageHeaderAccessor,
            IErrorSender errorSender)
        {
            Trace.AutoFlush = true;

            WsReportingTraceListener listener = Trace.Listeners.OfType<WsReportingTraceListener>().FirstOrDefault();

            if (listener == null)
            {
                listener = new WsReportingTraceListener(
                    companyAlias, hashSecretKey, source, infoProvider, authenticationDataProvider, messageHeaderAccessor, errorSender);
                Trace.Listeners.Add(listener);
            }
            else
            {
                listener.Reconfigure(companyAlias, hashSecretKey, infoProvider, authenticationDataProvider);
            }

            IsEnabled = true;
        }

        /// <summary>
        /// Writes stream into file with uniquely generated name in the 
        /// specified folder.
        /// </summary>
        /// <param name="stream">File stream to write.</param>
        /// <param name="folder">Folder to save file.</param>
        public static void WriteFile(MemoryStream stream, string folder)
        {
            if (IsEnabled)
            {
                try
                {
                    File.WriteAllBytes(GenerateStorageFileName(folder), stream.ToArray());
                }
                catch (Exception ex)
                {
                    Write(ex);
                }
            }
        }

        /// <summary>
        /// Writes string into file with uniquely generated name in the 
        /// specified folder.
        /// </summary>
        /// <param name="content">String to write.</param>
        /// <param name="folder">Folder to save file.</param>
        public static void WriteFile(string content, string folder)
        {
            if (IsEnabled)
            {
                try
                {
                    File.WriteAllText(GenerateStorageFileName(folder), content);
                }
                catch (Exception ex)
                {
                    Write(ex);
                }
            }
        }

        /// <summary>
        /// Generates file path which is used by WriteFile() functions.
        /// </summary>
        /// <param name="folder">Log files folder.</param>
        /// <returns>File name with full path.</returns>
        private static string GenerateStorageFileName(string folder)
        {
            return String.Format(
                "{0}{1}{2}-{3}.logfile", 
                folder, 
                Path.DirectorySeparatorChar, 
                DateTime.UtcNow.ToString("yyyyMMdd-HHmmss.ffff"), 
                Path.GetRandomFileName()
            );
        }

        /// <summary>
        /// Logs the specified message with the specified severity in the console log.
        /// </summary>
        /// <param name="text">The message to log.</param>
        /// <param name="severity">The severity.</param>
        void ILogger.Log(string text, TraceEventType severity)
        {
            switch (severity)
            {
                case TraceEventType.Critical:
                case TraceEventType.Error:
                    Write(text, MessageTypes.Error);
                    break;
                case TraceEventType.Warning:
                    Write(text, MessageTypes.Warning);
                    break;
                default:
                    Write(text, MessageTypes.Information);
                    break;
            }
        }

	    void ILogger.Log(Exception ex)
	    {
            Write(ex.ToString(), MessageTypes.Error);
        }

	    /// <summary>
        /// Releases all resources allocated by logger class.
        /// </summary>
        public static void Release()
        {
            WsReportingTraceListener listener = Trace.Listeners.OfType<WsReportingTraceListener>().FirstOrDefault();
            if (listener != null)
            {
                Trace.Listeners.Remove(listener);
                listener.Release();
            }
        }

        #endregion
    }
}
