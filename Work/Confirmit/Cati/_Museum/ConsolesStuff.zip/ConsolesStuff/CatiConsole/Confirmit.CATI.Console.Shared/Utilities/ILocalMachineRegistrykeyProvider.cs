﻿using Microsoft.Win32;

namespace Confirmit.CATI.Console.Shared.Utilities
{
    public interface ILocalMachineRegistryKeyProvider
    {
        RegistryKey OpenSubKey(string path);
    }
}