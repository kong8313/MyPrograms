﻿using Microsoft.Win32;

namespace Confirmit.CATI.Console.Shared.Utilities
{
    public class LocalMachineRegistryKeyProvider : ILocalMachineRegistryKeyProvider
    {
        public RegistryKey OpenSubKey(string path)
        {
            return Registry.LocalMachine.OpenSubKey(path);
        }
    }
}