﻿namespace Confirmit.CATI.Console.Shared.Log
{
    public interface ILogInfoProvider
    {
        string GetInfo();
    }
}
