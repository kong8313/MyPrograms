﻿using System;

namespace Confirmit.CATI.Console.Shared.Exceptions
{
    /// <summary>
    /// Represents exception which occurs if error page comes.
    /// </summary>
    public class InvalidPageException : CATIConsoleException
    {
        public InvalidPageException( string message ) : 
			base( message )
		{
		}

        public InvalidPageException(string message, Exception innerException) :
			base( message, innerException )
		{
		}
    }
}
