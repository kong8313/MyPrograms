﻿namespace Confirmit.CATI.Console.Shared.Utilities
{
    public enum ConnectionQuality
    {
        Good,
        Normal,
        Poor,
        No
    }
}