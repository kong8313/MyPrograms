﻿using System;
using System.Resources;

namespace Confirmit.CATI.Console.Shared.Resources
{
    /// <summary>
    /// Contains extension methods for System.ResourceManager class.
    /// </summary>
    public static class ResourceManagerExtensions
    {
        /// <summary>
        /// Returns value of specified string resource formatted with specified arguments.
        /// Method gets string resource from resource manager and passes it as format string
        /// to String.Format method.
        /// </summary>
        /// <param name="manager">Resource manager, extension parameter.</param>
        /// <param name="name">The name of resource to get.</param>
        /// <param name="args">Objects to format.</param>
        /// <returns>Formatted string; otherwise null.</returns>
        public static string GetString(this ResourceManager manager, string name, params object[] args)
        {
            string format = manager.GetString(name);
            if (String.IsNullOrEmpty(format))
            {
                return format;
            }
            else
            {
                return String.Format(format, args);
            }
        }
    }
}
