﻿using System.Diagnostics;
using System.IO;

namespace Confirmit.CATI.Console.Shared.Log
{
    public class CatiTraceListener : TextWriterTraceListener
    {
        public CatiTraceListener(string path, long maxFileSize)
            : base(new LogFileStream(path, maxFileSize))
        {
            Writer = TextWriter.Synchronized(Writer);
        }
    }
}
