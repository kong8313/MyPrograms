﻿using System;

namespace Confirmit.CATI.Console.Shared.Exceptions
{
	/// <summary>
	/// Represents base class for all exceptions in CATI Console.
	/// </summary>
	[Serializable]
	public class CATIConsoleException : ApplicationException
	{
        public CATIConsoleException()
        { 
        }

        public CATIConsoleException( string message ) : 
			base( message )
		{
		}

         public CATIConsoleException(string message, Exception innerException) :
			base( message, innerException )
		{
		}
	}
}
