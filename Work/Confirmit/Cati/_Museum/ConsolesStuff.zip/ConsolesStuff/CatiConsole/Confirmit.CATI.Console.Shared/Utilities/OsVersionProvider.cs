﻿using System;
using Confirmit.CATI.Console.Shared.Log;
using Microsoft.Win32;

namespace Confirmit.CATI.Console.Shared.Utilities
{
    public class OsVersionProvider : IOsVersionProvider
    {
        public Version GetVersion()
        {
            try
            {
                using (RegistryKey regkey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion", false))
                {
                    if (regkey == null)
                    {
                        throw new Exception("No access to information about OS version in registry");
                    }

                    var currentBuild = (string) regkey.GetValue("CurrentBuild");
                    if (regkey.GetValue("CurrentMajorVersionNumber") != null)
                    {
                        var currentMajorVersionNumber = (int) regkey.GetValue("CurrentMajorVersionNumber");
                        var currentMinorVersionNumber = (int) regkey.GetValue("CurrentMinorVersionNumber");

                        return new Version(string.Format("{0}.{1}.{2}.0", currentMajorVersionNumber, currentMinorVersionNumber, currentBuild));
                    }

                    var currentVersion = (string) regkey.GetValue("CurrentVersion");
                    return new Version(string.Format("{0}.{1}.0", currentVersion, currentBuild));
                }
            }
            catch (Exception ex)
            {
                Logger.Write("Getting information about OS version from registry has failed. Return a dummy version 9.9.9.9. Original error message stack:\r\n" + ex, MessageTypes.Error);
                return new Version(9, 9, 9, 9);
            }
        }
    }
}