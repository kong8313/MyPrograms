﻿using System;

namespace Confirmit.CATI.Console.Shared.Exceptions
{
	/// <summary>
	/// Represents exception which occurs if we couldn't find setting in configuration file.
	/// </summary>
	[Serializable]
	public class SettingNotFoundException : CATIConsoleException
	{
		/*ega
		 * TODO
		 * Add imlementation
		 */
	}
}
