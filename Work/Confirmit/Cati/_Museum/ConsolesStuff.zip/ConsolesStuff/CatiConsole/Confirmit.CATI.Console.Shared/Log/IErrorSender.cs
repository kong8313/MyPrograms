﻿using Confirmit.CATI.Common;
using Confirmit.CATI.Common.Contracts.ErrorReportingService;

namespace Confirmit.CATI.Console.Shared.Log
{
    public interface IErrorSender
    {
        void SendErrorMessage(IErrorReportingService serviceInstance, string companyAlias, ClientErrorSource source, 
                              string errorMessage, byte[] hash);
    }
}
