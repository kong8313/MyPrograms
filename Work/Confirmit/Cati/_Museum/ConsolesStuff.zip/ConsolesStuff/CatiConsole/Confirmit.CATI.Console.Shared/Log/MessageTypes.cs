﻿namespace Confirmit.CATI.Console.Shared.Log
{
	public enum MessageTypes
	{
		/// <summary>
		/// Information message.
		/// </summary>
		Information = 1,

		/// <summary>
		/// Warning message.
		/// </summary>
		Warning = 2,

		/// <summary>
		/// Error message.
		/// </summary>
		Error = 3
	}
}