using System;
using System.Diagnostics;
using System.IO;
using Microsoft.Win32;

namespace Confirmit.CATI.Console.Shared.Utilities
{
    /// <summary> 
    /// 'WebBrowser' control runs rendering in IE7 Standards Mode by default. 
    /// To make it work in modern rendering mode registry value 'FEATURE_BROWSER_EMULATION' must be initialized.
    /// For more details see here
    /// http://msdn.microsoft.com/en-us/library/ee330730%28VS.85%29.aspx#browser_emulation
    /// </summary>
    public class BrowserRenderingModeConfigurator
    {
        private const string KeyPath = @"Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION";

        private static string ApplicationFullName
        {
            get
            {
                return Process.GetCurrentProcess().MainModule.ModuleName;    
            }            
        }
     
        private static int GetEmulationValue()
        {            
            var mshtmlPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "mshtml.dll");
            var versionInfo = FileVersionInfo.GetVersionInfo(mshtmlPath);

            switch (versionInfo.FileMajorPart)
            {
                case 11:
                    //Internet Explorer 11. Webpages containing standards-based !DOCTYPE directives are displayed in IE10 Standards mode.
                    return 11000; 
                case 10:
                    //Internet Explorer 10. Webpages containing standards-based !DOCTYPE directives are displayed in IE10 Standards mode.
                    return 10000; 
                 case 9:
                    //Internet Explorer 9. Webpages containing standards-based !DOCTYPE directives are displayed in IE9 mode.
                    return 9000;
                 case 8:
                    //Webpages containing standards-based !DOCTYPE directives are displayed in IE8 mode.
                    return 8000;
            }

            return 0;
        }

        public static void Setup(bool browserEmulation)
        {
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(KeyPath, true) ?? Registry.CurrentUser.CreateSubKey(KeyPath))
                {
                    if (browserEmulation == false && key.GetValue(ApplicationFullName) != null)
                    {
                        key.DeleteValue(ApplicationFullName);
                    }
                    else if (browserEmulation)
                    {
                        key.SetValue(ApplicationFullName, GetEmulationValue());
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Logger.Write(ex);
            }
        }
    }
}