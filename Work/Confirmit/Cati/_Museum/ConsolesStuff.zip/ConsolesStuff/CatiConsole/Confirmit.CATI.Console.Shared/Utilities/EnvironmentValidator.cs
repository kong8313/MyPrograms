﻿using System;
using System.Linq;
using System.Net.Configuration;
using Confirmit.CATI.Common.ConsoleService.Abstract;

namespace Confirmit.CATI.Console.Shared.Utilities
{
    public class EnvironmentValidator : IEnvironmentValidator
    {
        private readonly IOsVersionProvider _osVersionProvider;
        private readonly ILocalMachineRegistryKeyProvider _localMachineRegistryKeyProvider;

        public EnvironmentValidator(IOsVersionProvider osVersionProvider, ILocalMachineRegistryKeyProvider localMachineRegistryKeyProvider)
        {
            _osVersionProvider = osVersionProvider;
            _localMachineRegistryKeyProvider = localMachineRegistryKeyProvider;
        }

        public bool IsEnvironmentSupported()
        {
            return IsNetVersionSupported() && IsOsVersionSupported();
        }

        public DotNetVersion GetDotNetVersion()
        {
            var dotNetVersion = new DotNetVersion();
            
            var clientKey = @"Software\Microsoft\NET Framework Setup\NDP\v4\Client";
            var fullKey = @"Software\Microsoft\NET Framework Setup\NDP\v4\Full";

            using (var key = _localMachineRegistryKeyProvider.OpenSubKey(clientKey) ?? _localMachineRegistryKeyProvider.OpenSubKey(fullKey))
            {
                if (key == null)
                {
                    throw new Exception(string.Format("Cannot open HKLM\\{0} and HKLM\\{1}", clientKey, fullKey));
                }

                dotNetVersion.Release = key.GetValueNames().Any(x => x == "Release") ? key.GetValue("Release").ToString() : "0";
                dotNetVersion.Servicing = key.GetValue("Servicing").ToString();
                dotNetVersion.Version = key.GetValue("Version").ToString();
            }

            return dotNetVersion;
        }

        public string GetWarning(string allMessageFormatWarning, string osMessageFormatWarning, string netVersionWarning)
        {
            string warning = string.Empty; 
            if(!IsOsVersionSupported())
            {
                warning += string.Format(osMessageFormatWarning + "\r\n", GetOsFriendlyName());
            }

            if(!IsNetVersionSupported())
            {
                warning += netVersionWarning + "\r\n";
            }

            return string.Format(allMessageFormatWarning, warning);
        }

        private string GetOsFriendlyName()
        {
            string currentVersionKey = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion";
            using (var key = _localMachineRegistryKeyProvider.OpenSubKey(currentVersionKey))
            {
                if (key == null)
                {
                    throw new Exception(string.Format("Cannot open HKLM\\{0}", currentVersionKey));
                }

                return key.GetValue("ProductName").ToString();
            }
        }

        private bool IsOsVersionSupported()
        {
            if (IsOsLessThenWindows7Sp1() || IsOsWindows8())
            {
                return false;
            }

            return true;
        }

        private bool IsOsLessThenWindows7Sp1()
        {
            var win7Sp1Version = new Version(6, 1, 7601);

            return _osVersionProvider.GetVersion() < win7Sp1Version;
        }

        private bool IsOsWindows8()
        {
            var win8Version = new Version(6, 2);
            var currentVersion = new Version(_osVersionProvider.GetVersion().Major, _osVersionProvider.GetVersion().Minor);

            return currentVersion == win8Version;
        }

        private bool IsNetVersionSupported()
        {
            const int releaseNumberOfNetFramework462 = 394802;

            DotNetVersion dotNetVersion = GetDotNetVersion();

            int currentReleaseNumber = Convert.ToInt32(dotNetVersion.Release);

            return currentReleaseNumber >= releaseNumberOfNetFramework462;
        }

        public bool IsIeVersionSupported()
        {
            var ls = new[] { "svcVersion", "svcUpdateVersion", "Version", "W2kVersion" };

            int maxVer = 0;
            foreach (var l in ls)
            {
                var objVal = Microsoft.Win32.Registry.GetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer", l, "0");
                var strVal = Convert.ToString(objVal);

                var iPos = strVal.IndexOf('.');
                if (iPos > 0)
                {
                    strVal = strVal.Substring(0, iPos);
                }

                if (int.TryParse(strVal, out var res))
                {
                    maxVer = Math.Max(maxVer, res);
                }
            }

            return maxVer >= 11;
        }
    }
}
