﻿using System;

namespace Confirmit.CATI.Console.Shared.Exceptions
{
    /// <summary>
    /// Represents exception which occurs if the custom dialer cannot initialize
    /// </summary>
    public class CustomDialerInitializationException : CATIConsoleException
    {
        public CustomDialerInitializationException( string message, Exception innerException ) : 
			base( message, innerException )
        {
        }
    }
}
