﻿using System;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Shared.Log
{

    /// <summary>
    /// Represents class which alerts users with message boxes.
    /// </summary>
    public class Alerter : IAlerter
    {
        /// <summary>
        /// Notifies user about occured exception. Automatically cuts long messages.
        /// </summary>
        /// <param name="ex">Exception.</param>
        /// <param name="caption">Caption.</param>
        public void Alert(Exception ex, string caption)
        {
            Alert(ex, caption, true);
        }

        /// <summary>
        /// Notifies user about occured exception. If exception message is too long and
        /// cutLongMessage is set to true, exception message will be cutted.
        /// </summary>
        /// <param name="ex">Exception.</param>
        /// <param name="caption">Caption.</param>
        /// <param name="cutLongMessage">If true, exception message will be cutted for long
        /// messages.</param>
        public void Alert(Exception ex, string caption, bool cutLongMessage)
        {
            const int messageLength = 1500;

            string message =
                (cutLongMessage && ex.Message.Length > messageLength ? ex.Message.Substring(0, messageLength) + "..." : ex.Message);

            ShowMessageBox(
                message,
                caption,
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );
        }

        /// <summary>
        /// Notifies user of custom message of custom type.
        /// </summary>
        /// <param name="message">Message to show.</param>
        /// <param name="caption">Caption.</param>
        /// <param name="messageType">Message type.</param>
        public void Alert(string message, string caption, MessageTypes messageType)
        {
            ShowMessageBox(
                message,
                caption,
                MessageBoxButtons.OK,
                IconFromType(messageType)
            );
        }

        /// <summary>
        /// Returns message box icon for given message type.
        /// </summary>
        /// <param name="type">Message type.</param>
        /// <returns>Icon.</returns>
        private static MessageBoxIcon IconFromType(MessageTypes type)
        {
            var result = MessageBoxIcon.Information;

            switch (type)
            {
                case MessageTypes.Warning: result = MessageBoxIcon.Warning; break;
                case MessageTypes.Error: result = MessageBoxIcon.Error; break;
            }
            return result;
        }

        /// <summary>
        /// Shows confirmation dialog to user.
        /// </summary>
        /// <param name="message">Confirmation message.</param>
        /// <param name="caption">Caption.</param>
        /// <returns>DialogResult result.</returns>
        public DialogResult AlertConfirmation(string message, string caption)
        {
            return ShowMessageBox(
                message,
                caption,
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );
        }

        /// <summary>
        /// Shows confirmation dialog to user.
        /// </summary>
        /// <param name="message">Confirmation message.</param>
        /// <param name="caption">Caption.</param>
        /// <returns>DialogResult result.</returns>
        public DialogResult AlertConfirmationOkCancel(string message, string caption)
        {
            return ShowMessageBox(
                message,
                caption,
                MessageBoxButtons.OKCancel,
                MessageBoxIcon.Question
            );
        }

        /// <summary>
        /// Shows confirmation dialog to user.
        /// </summary>
        /// <param name="message">Confirmation message.</param>
        /// <param name="caption">Caption.</param>
        /// <returns>Retry or cancel result</returns>
        public DialogResult AlertRetryConfirmation(string message, string caption)
        {
            return ShowMessageBox(
                message,
                caption,
                MessageBoxButtons.RetryCancel,
                MessageBoxIcon.Question
            );
        }

        /// <summary>
        /// Do preparation for message
        /// </summary>
        /// <remarks>
        /// It is necessary because strings from resources has additional slash.
        /// </remarks>
        private static string PrepareMessage(string message)
        {
            if (String.IsNullOrEmpty(message) == false)
            {
                message = message.Replace("\\n", "\n");
                message = message.Replace("\\r", "\r");
            }
            return message;
        }

        private DialogResult ShowMessageBox(string message, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            Form mainForm = null;
            DialogResult result = DialogResult.None;

            if (Application.OpenForms.Count > 0)
            {
                mainForm = Application.OpenForms[0];
            }

            if ((mainForm != null) && (mainForm.InvokeRequired))
            {
                mainForm.Invoke(
                    new Action(() =>
                    result = MessageBox.Show(
                        mainForm,
                        PrepareMessage(message),
                        caption,
                        buttons,
                        icon,
                        MessageBoxDefaultButton.Button1,
                        (MessageBoxOptions)0x40000)));

                return result;
            }

            result = MessageBox.Show(
                mainForm,
                PrepareMessage(message),
                caption,
                buttons,
                icon,
                MessageBoxDefaultButton.Button1,
                (MessageBoxOptions)0x40000);

            return result;
        }
    }
}
