﻿using Confirmit.CATI.Common.ConsoleService.Abstract;

namespace Confirmit.CATI.Console.Shared.Utilities
{
    public interface IEnvironmentValidator
    {
        bool IsEnvironmentSupported();

        bool IsIeVersionSupported();

        DotNetVersion GetDotNetVersion();

        string GetWarning(string allMessageFormatWarning, string osMessageFormatWarning, string netVersionWarning);
    }
}