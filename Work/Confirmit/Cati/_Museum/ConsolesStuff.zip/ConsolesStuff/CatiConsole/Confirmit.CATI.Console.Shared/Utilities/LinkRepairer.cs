﻿using System;
using System.Text.RegularExpressions;

namespace Confirmit.CATI.Console.Shared.Utilities
{
    /// <summary>
    /// Repairs links to images and css-files.
    /// Links can be as absolute as relative. For relative links server name prefix must be added.
    /// </summary>
    public class LinkRepairer
    {
        public static string Repair(string pageContent, string hostName, string scheme)
        {
            if (scheme?.ToLowerInvariant() == "about")
            {
                return pageContent;
            }

            if (scheme?.ToLowerInvariant() != "http" && scheme?.ToLowerInvariant() != "https")
            {
                throw new ArgumentOutOfRangeException(nameof(scheme), scheme, "Only 'http' and 'https' scheme is supported");
            }

            string result = pageContent;

            string commonPrefix = $"{scheme}://{hostName}/";
            string linkToClientUtilPrefix = $"{scheme}://{hostName}";
            string linkNotToClientUtilPrefix = $"{scheme}://{hostName}/wix/";
            
            //change <LINK href=" to <LINK href="http://hostname/wix/
            result = Regex.Replace(result, @"(?<=[<]LINK.*?)HREF=[""](?=[^\/cf_clientutil].*?[>])", @"HREF=""" + linkNotToClientUtilPrefix, RegexOptions.IgnoreCase);

            //change <LINK href=" to <LINK href="http://hostname/
            //link to cf_clientutil contains "wix"
            result = Regex.Replace(result, @"(?<=[<]LINK.*?)HREF=[""](?=[\/cf_clientutil].*?[>])", @"HREF=""" + linkToClientUtilPrefix, RegexOptions.IgnoreCase);

            //change <img src="/  to <img src="http://hostname/
            result = Regex.Replace(result, @"(?<=[<]IMG.{0,100}?)SRC\=[""][/]", @"SRC=""" + commonPrefix, RegexOptions.IgnoreCase);

            //change <script src="/  to <script src="http://hostname/
            result = Regex.Replace(result, @"(?<=[<]SCRIPT.*?)SRC\=[""][/]", @"SRC=""" + commonPrefix, RegexOptions.IgnoreCase);

            return result;            
        }
    }
}
