﻿using System.Collections.Generic;
using System.Linq;

namespace Confirmit.CATI.Console.Shared.Utilities
{
    public class ConnectionQualityAnalyzer
    {
        private readonly List<long> _calls;

        private int _keepAliveCallsToSave;
        private int _goodConnectionThresholdMs;
        private int _normalConnectionThresholdMs;

        public ConnectionQualityAnalyzer(
            int keepAliveCallsToSave,
            int goodConnectionThresholdMs,
            int normalConnectionThresholdMs)
        {
            _calls = new List<long>();

            _keepAliveCallsToSave = keepAliveCallsToSave;
            _goodConnectionThresholdMs = goodConnectionThresholdMs;
            _normalConnectionThresholdMs = normalConnectionThresholdMs;
        }

        private void AddNewCall(long callDuration)
        {
            _calls.Add(callDuration);

            if (_calls.Count > _keepAliveCallsToSave)
            {
                _calls.RemoveAt(0);
            }
        }

        private long GetAverageCallDuration()
        {
            var timeoutDuration = _normalConnectionThresholdMs + _calls.Count;
            var calls = _calls.Select(c => c != 0 ? c : timeoutDuration).ToList();

            var avg = calls.Aggregate(calls.First(), (current, next) => (current + next) / 2);

            return avg;
        }

        private bool IsConnectionLost()
        {
            return _calls.Count >= 2 && _calls[_calls.Count - 1] == 0 && _calls[_calls.Count - 2] == 0;
        }

        public ConnectionQuality AddCallAndAnalyzeConnection(long lastCallDurations)
        {
            AddNewCall(lastCallDurations);

            if (IsConnectionLost())
            {
                return ConnectionQuality.No;
            }

            var avg = GetAverageCallDuration();

            if (avg <= _goodConnectionThresholdMs)
            {
                return ConnectionQuality.Good;
            }

            if (avg > _goodConnectionThresholdMs && avg <= _normalConnectionThresholdMs)
            {
                return ConnectionQuality.Normal;
            }

            return ConnectionQuality.Poor;
        }
    }
}
