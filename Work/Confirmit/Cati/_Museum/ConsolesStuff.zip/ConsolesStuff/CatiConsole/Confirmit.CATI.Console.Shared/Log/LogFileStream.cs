﻿using System;
using System.IO;

namespace Confirmit.CATI.Console.Shared.Log
{
    public sealed class LogFileStream : FileStream
    {
        private long m_MaxFileLength;
        
        #region Constructors

        public LogFileStream(string path, long maxFileLength)
            : base(path, FileMode.OpenOrCreate, FileAccess.Write)
        {
            m_MaxFileLength = maxFileLength;
            Seek(0, SeekOrigin.End);
        } 

        #endregion

        #region Methods

        /// <summary>
        /// 
        /// </summary>
        public override void Write(byte[] array, int offset, int count)
        {
            lock (this)
            {
                int actualCount = Math.Min(count, array.GetLength(0));

                base.Write(array, offset, count);

                if (Position >= m_MaxFileLength)
                {
                    Backup();
                    SetLength(0);
                }
            }
        }
        /// <summary>
        /// Does copy of current log file
        /// </summary>
        private void Backup()
        {
            string backupFileName = string.Format("{0}.backup", Name);
            File.Copy(Name, backupFileName, true);
        } 

        #endregion
    }
}
