﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Console.Shared.Log;
using Confirmit.CATI.Console.Shared.Resources;

namespace Confirmit.CATI.Console.Shared.Utilities
{
    static public class UnhandledExceptionsHandler
    {
        static public void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            var appName = GetAppNameAndVersion();

            Logger.Write(String.Format(
                LogResources.UnhandledExceptionText,
                appName,
                e.ExceptionObject,
                e.IsTerminating,
                sender), MessageTypes.Error);
        }

        static public void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            Logger.Write(e.Exception);
        }

        public static string GetAppNameAndVersion()
        {
            try
            {
                var assembly = Assembly.GetExecutingAssembly();
                var attributes = (AssemblyTitleAttribute)Attribute.GetCustomAttribute(assembly,
                    typeof(AssemblyTitleAttribute), false);
                var versionInfo = FileVersionInfo.GetVersionInfo(assembly.Location);
                return $"{attributes?.Title} {versionInfo?.FileVersion}";
            }
            catch
            {
                return "";
            }
        }

    }
}
