﻿using System;

namespace Confirmit.CATI.Console.Shared.Utilities
{
    /// <summary>
    /// Represents formating utility for survey name.
    /// </summary>
    public static class SurveyNameFormatter
    {
        #region Methods

        /// <summary>
        /// Formats survey name according our standard "survey name (p0000000)".
        /// </summary>
        /// <param name="surveyId">Confirmit survey identifier (e.g. 'p0000000').</param>
        /// <param name="surveyName">Confirmit survey name.</param>
        /// <returns>Formatted survey name.</returns>
        public static string FormatSurveyName(string surveyId, string surveyName)
        {
            string result = String.Empty;

            if (String.IsNullOrEmpty(surveyName))
            {
                result = surveyId;
            }
            else
            {
                result = surveyName + " (" + surveyId + ')';
            }

            return result;
        }

        #endregion
    }
}
