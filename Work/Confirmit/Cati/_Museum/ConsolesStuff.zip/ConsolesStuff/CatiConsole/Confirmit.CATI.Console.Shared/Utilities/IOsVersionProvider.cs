﻿using System;

namespace Confirmit.CATI.Console.Shared.Utilities
{
    public interface IOsVersionProvider
    {
        Version GetVersion();
    }
}