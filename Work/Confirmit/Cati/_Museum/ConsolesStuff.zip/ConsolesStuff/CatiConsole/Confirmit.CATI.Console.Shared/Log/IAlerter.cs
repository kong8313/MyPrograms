﻿using System;
using System.Windows.Forms;

namespace Confirmit.CATI.Console.Shared.Log
{
    public interface IAlerter
    {
        void Alert(Exception ex, string caption);
        void Alert(string message, string caption, MessageTypes messageType);
        void Alert(Exception ex, string caption, bool cutLongMessage);
        DialogResult AlertConfirmation(string message, string caption);
        DialogResult AlertConfirmationOkCancel(string message, string caption);
        DialogResult AlertRetryConfirmation(string message, string caption);
    }
}