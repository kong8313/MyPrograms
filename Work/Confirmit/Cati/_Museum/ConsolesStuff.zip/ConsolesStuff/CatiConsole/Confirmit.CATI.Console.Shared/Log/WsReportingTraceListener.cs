﻿using System;
using System.Diagnostics;
using System.Text;
using System.Threading;

using Confirmit.CATI.Common;
using Confirmit.CATI.Common.Contracts.ErrorReportingService;
using Confirmit.CATI.Common.Encryption;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Common.WcfTools;
using Confirmit.CATI.Common.WcfTools.ErrorServiceMessageHeader;

namespace Confirmit.CATI.Console.Shared.Log
{
    /// <summary>
    /// Sends client errors via web service to log on the server side.
    /// </summary>
    public class WsReportingTraceListener : TraceListener
    {
        private readonly ChannelFactoryWrapper<IErrorReportingService> _channelFactoryWrapper;
        private readonly ErrorReportingServiceChannelFactoryWrapperConfiguration _errorServiceConfiguration;
        private readonly IErrorSender _sender;
        private ILogInfoProvider _additionalInfoProvider;

        private const int MaxRetryCount = 3;
        private const string ErrorIndicator = ": Error: ";

        private readonly ClientErrorSource _source;
        private string _companyAlias;
        private byte[] _hashSecretKey;
        private ILoginPasswordAuthenticationDataProvider _authenticationDataProvider;

        public WsReportingTraceListener(
            string companyAlias,
            byte[] hashSecretKey,
            ClientErrorSource source,
            ILogInfoProvider infoProvider,
            ILoginPasswordAuthenticationDataProvider authenticationDataProvider,
            IMessageHeaderAccessor messageHeaderAccessor,
            IErrorSender sender)
        {
            _additionalInfoProvider = infoProvider;
            _companyAlias = companyAlias;
            _hashSecretKey = hashSecretKey;
            _source = source;
            _sender = sender;
            _authenticationDataProvider = authenticationDataProvider;
            _errorServiceConfiguration = new ErrorReportingServiceChannelFactoryWrapperConfiguration(_authenticationDataProvider, messageHeaderAccessor);
            _channelFactoryWrapper = new ChannelFactoryWrapper<IErrorReportingService>(
                _errorServiceConfiguration,
                new Logger());
        }

        public void Reconfigure(
            string companyAlias,
            byte[] hashSecretKey,
            ILogInfoProvider infoProvider,
            ILoginPasswordAuthenticationDataProvider authenticationDataProvider)
        {
            _additionalInfoProvider = infoProvider;
            _companyAlias = companyAlias;
            _hashSecretKey = hashSecretKey;
            _errorServiceConfiguration.UpdateAuthenticationDataProvider(authenticationDataProvider);
        }

        /// <summary>
        /// Releases all resources allocated by this instance of trace listener.
        /// </summary>
        public void Release()
        {
            _channelFactoryWrapper.Release();
        }

        #region Overrides of TraceListener

        /// <summary>
        /// Sends a message to the server.
        /// </summary>
        /// <param name="message">A message to send.</param>
        public override void WriteLine(string message)
        {
            Write(message);
        }

        /// <summary>
        /// Sends a message to the server.
        /// </summary>
        /// <param name="message">A message to send.</param>
        public override void Write(string message)
        {
            if (IsErrorMessage(message, out message) == false)
            {
                return;
            }

            DateTime now = DateTime.Now;
            var additionalInfo = _additionalInfoProvider.GetInfo();

            ThreadPool.QueueUserWorkItem(
                delegate
                    {
                        try
                        {
                            SendMessage2ErrorsReportingService(message, additionalInfo, now);
                        }
                        catch (Exception)
                        {
                            // Black hole might swallow everything!
                        }
                    });
        }

        #endregion

        /// <summary>
        /// Indicates that given message is error message.
        /// </summary>
        /// <param name="message">Input message.</param>
        /// <param name="resultMessage">Resulting error message.</param>
        /// <returns>true, if it is error message; otherwise false.</returns>
        private static bool IsErrorMessage(string message, out string resultMessage)
        {
            bool result = false;
            resultMessage = null;

            if (!String.IsNullOrEmpty(message) && message.Contains(ErrorIndicator))
            {
                result = true;
                int index = message.IndexOf(ErrorIndicator) + ErrorIndicator.Length;
                resultMessage = message.Substring(index);
            }

            return result;
        }

        private void SendMessage2ErrorsReportingService(string message, string additionalInfo, DateTime occurrenceTime)
        {
            StringBuilder additional = new StringBuilder(additionalInfo);
            additional.AppendLine();
            additional.AppendFormat("Local time: {0}\r\nUUID: {1}", occurrenceTime.ToString("dd/MM/yyyy HH:mm:ss.fff"), Guid.NewGuid());

            message += Environment.NewLine + "----------" + Environment.NewLine + additional;

            // compute hash to make sure message is sent by the client that knows secret key
            var hasher = new CatiSecretKeyHasher();
            var messageHash = hasher.ComputeHash(_hashSecretKey, _companyAlias, _source, message);

            bool success = false;
            int retryCount = 0;

            do
            {
                try
                {
                    if (retryCount > 0)
                    {
                        var messageWithRetryCount = string.Format("{0}\r\nRetry Count: {1}\r\n", message, retryCount);

                        _channelFactoryWrapper.Execute(x => _sender.SendErrorMessage(x, _companyAlias, _source, messageWithRetryCount, messageHash));
                    }
                    else
                    {
                        _channelFactoryWrapper.Execute(x => _sender.SendErrorMessage(x, _companyAlias, _source, message, messageHash));
                    }

                    success = true;
                }
                catch (Exception ex)
                {
                    // we log only first occurence of problem
                    Logger.WriteToTheFileTraceListenerOnly(
                        string.Format("Exception thrown while loggin error with errors reporting service:\r\nException:\r\n{0}",
                        ex),
                        MessageTypes.Error);

                    retryCount++;
                    Thread.Sleep(500);
                }
            }
            while (!success && retryCount < MaxRetryCount);
        }
    }
}
