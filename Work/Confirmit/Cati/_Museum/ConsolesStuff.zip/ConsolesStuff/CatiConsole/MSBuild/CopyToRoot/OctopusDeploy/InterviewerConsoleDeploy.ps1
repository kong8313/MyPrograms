﻿try
{
    . "Installation\InitialInitializations.ps1"

    # Load external C# dll's
    [Reflection.Assembly]::LoadFile("$installLocation\Installation\ConsoleInstallation.dll")

	$OctopusActionPackageNuGetPackageVersion = Get-NormalizedVersion -Version $OctopusActionPackageNuGetPackageVersion

    Write-Host "Start custom actions"
    $installationFacade = new-object ConsoleInstallation.InstallationFacade($logger)
    $clientsDeploymentSetupEngine = new-object ConsoleInstallation.ClientsDeploymentSetupEngine($logger)

    # Make some dependent parameters
    $consoleAliasAsUrl = $clientsDeploymentSetupEngine.ReturnAsUrl($CatiConsoleParametersInterviewerVirtualDirectoryName)
    $consoleDeploymentManifestUrl = "http://$CatiConsoleParametersDeploymentServerName/$consoleAliasAsUrl/CatiInterviewerConsole.application"
    $consoleDeploymentUrl = "http://$CatiConsoleParametersDeploymentServerName/$consoleAliasAsUrl"
    $mageFilePath = [System.IO.Path]::Combine($installLocation, "Installation\mage.exe")

    $productVersionWithUnderbar = $OctopusActionPackageNuGetPackageVersion.Replace(".", "_")
    $consoleVersionFolder = [System.IO.Path]::Combine($installLocation, "Application Files\CatiInterviewerConsole_$productVersionWithUnderbar")
    $consoleManifestPath = [System.IO.Path]::Combine($consoleVersionFolder, "CatiInterviewerConsole.exe.manifest")
    $consoleApplicationPath = [System.IO.Path]::Combine($installLocation, "CatiInterviewerConsole.application")
    $consoleConfigDeployFilePath = [System.IO.Path]::Combine($consoleVersionFolder, "CatiInterviewerConsole.exe.config.deploy")

    if($CatiConsoleParametersInstallConfirmitBrandedPage -ne $null -and  $CatiConsoleParametersInstallConfirmitBrandedPage.ToLower() -eq 'true')
    {
	    $CatiConsoleParametersInstallConfirmitBrandedPage = $true
    }
    else
    {
	    $CatiConsoleParametersInstallConfirmitBrandedPage = $false
    }
    Write-Host "Cati.Console.Parameters.InstallConfirmitBrandedPage=$CatiConsoleParametersInstallConfirmitBrandedPage"

    Write-Host "Dependent parameters list"
    Write-Host "Console Alias As Url=$consoleAliasAsUrl"
    Write-Host "Console Deployment Manifest Url=$consoleDeploymentManifestUrl"
    Write-Host "Console Deployment Url=$consoleDeploymentUrl"
    Write-Host "Mage File Path=$mageFilePath"
    Write-Host "Product Version With Underbar=$productVersionWithUnderbar"
    Write-Host "Console Version Folder=$consoleVersionFolder"
    Write-Host "Console Manifest Path=$consoleManifestPath"
    Write-Host "Console Application Path=$consoleApplicationPath"
    Write-Host "Console Config Deploy File Path=$consoleConfigDeployFilePath"

    # Start installation actions
    Write-Host "Call ConfigureInterviewerConsoleXmlFiles"
    $installationFacade.ConfigureInterviewerConsoleXmlFiles($consoleConfigDeployFilePath, $consoleApplicationPath, $consoleManifestPath, $CatiConsoleParametersCatiServerName, 
        $consoleDeploymentManifestUrl, "CatiInterviewerConsole.application", $CatiConsoleParametersEnvironmentName)

    Write-Host "Call CreateVirtualDirectories"
    $installationFacade.ConfigureVirtualDirectories($consoleAliasAsUrl, $installLocation)

    Write-Host "Call SetupDefaultPage"
    $installationFacade.SetupDefaultPage($installLocation, $OctopusActionPackageNuGetPackageVersion, $CatiConsoleParametersInstallConfirmitBrandedPage, $true)

    Write-Host "Call GetCertificate"
    [System.Security.Cryptography.X509Certificates.X509Certificate2] $signingCertificate = $installationFacade.GetCertificate($CatiConsoleCertificatePath, $CatiConsoleCertificatePassword)

    Write-Host "Call GetMageCertificateArguments"
    $mageCertificateArguments = $installationFacade.GetMageCertificateArguments($CatiConsoleCertificatePath, $CatiConsoleCertificatePassword)

    Write-Host "Call SignClickOnceFiles"
    $installationFacade.SignClickOnceFiles($mageFilePath, $mageCertificateArguments, $consoleVersionFolder,
        $consoleApplicationPath, $consoleManifestPath, $OctopusActionPackageNuGetPackageVersion, $CatiConsoleParametersEnvironmentName, $true)

    Write-Host "Call SignSetupExe"
    $installationFacade.SignSetupExe($signingCertificate, $installLocation, $consoleDeploymentUrl)

    Write-Host "Custom actions have done"
}
catch [Exception]
{ 
    "Failed to run package script:"
    $_.Exception.Message
    $_.Exception.StackTrace
    Exit -1
}