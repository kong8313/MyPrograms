﻿try
{
    . "Installation\InitialInitializations.ps1"

    # Load external C# dll's
    [Reflection.Assembly]::LoadFile("$installLocation\Installation\ConsoleInstallation.dll")

    $OctopusActionPackageNuGetPackageVersion = Get-NormalizedVersion -Version $OctopusActionPackageNuGetPackageVersion

    Write-Host "Start custom actions"
    $installationFacade = new-object ConsoleInstallation.InstallationFacade($logger)
    $clientsDeploymentSetupEngine = new-object ConsoleInstallation.ClientsDeploymentSetupEngine($logger)

    # Make some dependent parameters
    $consoleAliasAsUrl = $clientsDeploymentSetupEngine.ReturnAsUrl($CatiConsoleParametersMonitoringVirtualDirectoryName)
    $consoleDeploymentManifestUrl = "http://$CatiConsoleParametersDeploymentServerName/$consoleAliasAsUrl/CatiSupervisorPlayer.application"
    $consoleDeploymentUrl = "http://$CatiConsoleParametersDeploymentServerName/$consoleAliasAsUrl"
    $mageFilePath = [System.IO.Path]::Combine($installLocation, "Installation\mage.exe")

    $productVersionWithUnderbar = $OctopusActionPackageNuGetPackageVersion.Replace(".", "_")
    $consoleVersionFolder = [System.IO.Path]::Combine($installLocation, "Application Files\CatiSupervisorPlayer_$productVersionWithUnderbar")
    $consoleManifestPath = [System.IO.Path]::Combine($consoleVersionFolder, "CatiSupervisorPlayer.exe.manifest")
    $consoleApplicationPath = [System.IO.Path]::Combine($installLocation, "CatiSupervisorPlayer.application")
    $consoleConfigDeployFilePath = [System.IO.Path]::Combine($consoleVersionFolder, "CatiSupervisorPlayer.exe.config.deploy")

    if($CatiConsoleParametersInstallConfirmitBrandedPage -ne $null -and  $CatiConsoleParametersInstallConfirmitBrandedPage.ToLower() -eq 'true')
    {
	    $CatiConsoleParametersInstallConfirmitBrandedPage = $true
    }
    else
    {
	    $CatiConsoleParametersInstallConfirmitBrandedPage = $false
    }
    Write-Host "Cati.Console.Parameters.InstallConfirmitBrandedPage=$CatiConsoleParametersInstallConfirmitBrandedPage"

    Write-Host "Dependent parameters list"
    Write-Host "Console Alias As Url=$consoleAliasAsUrl"
    Write-Host "Console Deployment Manifest Url=$consoleDeploymentManifestUrl"
    Write-Host "Console Deployment Url=$consoleDeploymentUrl"
    Write-Host "Mage File Path=$mageFilePath"
    Write-Host "Product Version With Underbar=$productVersionWithUnderbar"
    Write-Host "Console Version Folder=$consoleVersionFolder"
    Write-Host "Console Manifest Path=$consoleManifestPath"
    Write-Host "Console Application Path=$consoleApplicationPath"
    Write-Host "Console Config Deploy File Path=$consoleConfigDeployFilePath"

    # Start installation actions
    Write-Host "Call ConfigureMonitoringConsoleXmlFiles"
    $installationFacade.ConfigureMonitoringConsoleXmlFiles($consoleConfigDeployFilePath, $consoleApplicationPath, $consoleManifestPath, $CatiConsoleParametersCatiServerName, 
        $consoleDeploymentManifestUrl, "CatiSupervisorPlayer.application", $CatiConsoleParametersEnvironmentName)

    Write-Host "Call CreateVirtualDirectories"
    $installationFacade.ConfigureVirtualDirectories($consoleAliasAsUrl, $installLocation)

    Write-Host "Call SetupDefaultPage"
    $installationFacade.SetupDefaultPage($installLocation, $OctopusActionPackageNuGetPackageVersion, $CatiConsoleParametersInstallConfirmitBrandedPage, $false)

    Write-Host "Call GetCertificate"
    [System.Security.Cryptography.X509Certificates.X509Certificate2] $signingCertificate = $installationFacade.GetCertificate($CatiConsoleCertificatePath, $CatiConsoleCertificatePassword)

    Write-Host "Call GetMageCertificateArguments"
    $mageCertificateArguments = $installationFacade.GetMageCertificateArguments($CatiConsoleCertificatePath, $CatiConsoleCertificatePassword)

    Write-Host "Call SignClickOnceFiles"
    $installationFacade.SignClickOnceFiles($mageFilePath, $mageCertificateArguments, $consoleVersionFolder, 
        $consoleApplicationPath, $consoleManifestPath, $OctopusActionPackageNuGetPackageVersion, $CatiConsoleParametersEnvironmentName, $false)

    Write-Host "Call SignSetupExe"
    $installationFacade.SignSetupExe($signingCertificate, $installLocation, $consoleDeploymentUrl)

    Write-Host "Custom actions have done"
}
catch [Exception]
{ 
    "Failed to run package script:"
    $_.Exception.Message
    $_.Exception.StackTrace
    Exit -1
}