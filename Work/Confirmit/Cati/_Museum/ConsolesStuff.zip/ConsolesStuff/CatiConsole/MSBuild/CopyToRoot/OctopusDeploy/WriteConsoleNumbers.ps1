function UpdateSystemSettingsValue($connectionString, $settingName, $settingValue)
{
    $query = "UPDATE [dbo].[BvSystemSettings] SET [Value] = @Value WHERE [SystemName] = @Name"

    $conn = New-Object System.Data.SqlClient.SQLConnection
    $conn.ConnectionString=$connectionString
    $conn.Open()
    $cmd = New-Object system.Data.SqlClient.SqlCommand($query, $conn)
    $cmd.Parameters.Add("@Value", $settingValue) | Out-Null
    $cmd.Parameters.Add("@Name", $settingName) | Out-Null
    $cmd.ExecuteNonQuery() | Out-Null
    $conn.Close()
}

function Get-NormalizedVersion {
	param (
        [Parameter(Mandatory=$true)] [string] [ValidateNotNullOrEmpty()] $Version
    )
	
    $arr = $Version.Split('.')
    $major = $arr[0]
    $minor = $arr[1]
    $build = $arr[2]

    if($build -like "*-*"){
        $arr = $build.Split('-')
        $normalBuild = $arr[0]
    }
    else {
        $normalBuild = $build
    }

	return "$major.$minor.$normalBuild.0"
}

$connectionString = "Server={0};Database=ConfirmitCATIV15;UID={1};PWD={2}" -f $CatiDatabaseServerName, $ConfirmitDatabaseUserSystemAdminName, $ConfirmitDatabaseUserSystemAdminPassword

$OctopusActionPackageNuGetPackageVersion = Get-NormalizedVersion -Version $OctopusActionPackageNuGetPackageVersion

Write-Host "Set interviewer console number in $OctopusActionPackageNuGetPackageVersion"
UpdateSystemSettingsValue $connectionString 'Setup.InterviewerConsoleVersion' $OctopusActionPackageNuGetPackageVersion

Write-Host "Set monitoring console number in $OctopusActionPackageNuGetPackageVersion"
UpdateSystemSettingsValue $connectionString 'Setup.MonitoringConsoleVersion' $OctopusActionPackageNuGetPackageVersion
