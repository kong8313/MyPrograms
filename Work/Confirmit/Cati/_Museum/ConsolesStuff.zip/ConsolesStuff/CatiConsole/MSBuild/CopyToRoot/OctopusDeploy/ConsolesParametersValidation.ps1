﻿. "Installation\PreDeployFunctions.ps1"
. "Installation\InitialInitializations.ps1"

[Reflection.Assembly]::LoadFile("$installLocation\Installation\ConsoleInstallation.dll")

$settings = @{
    'Cati.Console.Parameters.InterviewerVirtualDirectoryName' = $CatiConsoleParametersInterviewerVirtualDirectoryName
    'Cati.Console.Parameters.MonitoringVirtualDirectoryName' = $CatiConsoleParametersMonitoringVirtualDirectoryName
    'Cati.Console.Parameters.DeploymentServerName' = $CatiConsoleParametersDeploymentServerName
    'Cati.Console.Parameters.CatiServerName' = $CatiConsoleParametersCatiServerName
    'Cati.Console.Parameters.EnvironmentName' = $CatiConsoleParametersEnvironmentName
    'Cati.Console.Certificate.Path' = $CatiConsoleCertificatePath
    'Cati.Console.Certificate.Password' = $CatiConsoleCertificatePassword
} 

PrintAllParameter $settings
VerifyAllParameterAssignment $settings

# Vefity that required parameters have a value and that boolean and integer parameters have a correct value
VerifyStringParameter 'Cati.Console.Parameters.InterviewerVirtualDirectoryName' $CatiConsoleParametersInterviewerVirtualDirectoryName
VerifyStringParameter 'Cati.Console.Parameters.MonitoringVirtualDirectoryName' $CatiConsoleParametersMonitoringVirtualDirectoryName
VerifyStringParameter 'Cati.Console.Parameters.DeploymentServerName' $CatiConsoleParametersDeploymentServerName
VerifyStringParameter 'Cati.Console.Parameters.CatiServerName' $CatiConsoleParametersCatiServerName
VerifyStringParameter 'Cati.Console.Parameters.EnvironmentName' $CatiConsoleParametersEnvironmentName

$prereqChecker = new-object Confirmit.CATI.Installation.Common.PrereqChecker
$confirmitCatiValidator = new-object Confirmit.CATI.Installation.Common.ConfirmitCATIValidator
$certificateEngine = new-object Confirmit.CATI.Installation.Common.CertificateEngine(new-object Confirmit.CATI.Installation.Common.DialogService)
$installationVerifier = new-object ConsoleInstallation.InstallationVerifier($logger, $prereqChecker, $confirmitCatiValidator, $certificateEngine)

# Start verification
$catiConnectionString = "Data Source=$CatiDatabaseServerName;Initial Catalog=ConfirmitCATIV15;User ID=$ConfirmitDatabaseUserSystemAdminName;Password=$ConfirmitDatabaseUserSystemAdminPassword;Connect Timeout=120;Max Pool Size=4096"
$consoleParameters = new-object ConsoleInstallation.ConsoleParameters
$consoleParameters.CatiConnectionString = $catiConnectionString
$consoleParameters.InterviewerAliasName = $CatiConsoleParametersInterviewerVirtualDirectoryName
$consoleParameters.MonitoringAliasName = $CatiConsoleParametersMonitoringVirtualDirectoryName
$consoleParameters.DeploymentServerName = $CatiConsoleParametersDeploymentServerName
$consoleParameters.CatiServerName = $CatiConsoleParametersCatiServerName
$consoleParameters.EnvironmentName = $CatiConsoleParametersEnvironmentName
$consoleParameters.CertificatePath = $CatiConsoleCertificatePath
$consoleParameters.CertificatePassword = $CatiConsoleCertificatePassword

Write-Host "Call VerifyConsoleParameters"
$installationVerifier.VerifyConsoleParameters($consoleParameters)

FinishVerification