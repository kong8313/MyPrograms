﻿using System.Collections.Generic;
using System.Xml.Serialization;
using Confirmit.CATI.LoadTestUtility.Enums;

namespace Confirmit.CATI.LoadTestUtility
{
    [XmlRoot("TestConfiguration")]
    public class TestConfigurationXmlModel
    {
        [XmlElement("TotalSurvey")]
        public int TotalSurvey;

        public class DialerScenario
        {
            [XmlElement("CallsCountPerInterviewer")]
            public string CallsCountPerInterviewer;

            public class OutcomeList
            {
                [XmlAttribute("CallOutcome")]
                public string CallOutcome;

                [XmlAttribute("ProcessingTime")]
                public string ProcessingTime;

                [XmlAttribute("DistributionWeight")]
                public string DistributionWeight;
            }

            [XmlArray("OutcomeLists")]
            public List<OutcomeList> OutcomeLists;
        }

        [XmlArray("DialerScenarios")]
        public List<DialerScenario> DialerScenarios;

        public class LoadInterval
        {
            public LoadInterval()
            {
                Duration = 1;// 1 min
                ReloginTimeoutOnFrozenState = 15;// 15 min
                LoginDelay = "1s";//sec

            }
        [XmlAttribute("TotalAutoInterviewers")]
            public string TotalAutoInterviewers;

            [XmlAttribute("TotalSAInterviewers")]
            public string TotalSAInterviewers;

            [XmlAttribute("TotalCGInterviewers")]
            public string TotalCGInterviewers;

            [XmlAttribute("Duration")]
            public int Duration;

            [XmlAttribute("ReloginTimeoutOnFrozenState")]
            public int ReloginTimeoutOnFrozenState;

            [XmlAttribute("LoginDelay")]
            public string LoginDelay;
        }

        [XmlArray("LoadScenario")]
        public List<LoadInterval> LoadScenario;

        public class CallGroup
        {
            [XmlAttribute("Name")]
            public string Name;

            [XmlAttribute("ITS")]
            public string Its;
        }

        [XmlArray("CallGroups"), XmlArrayItem("CallGroup")]
        public List<CallGroup> CallGroups;

        public class InterviewScenario
        {
            public class InterviewScenarioAction
            {
                [XmlAttribute("Type")]
                public InterviewScenarioActionType Type;

                [XmlAttribute("Param")]
                public string Param;
            }

            [XmlAttribute("Name")]
            public string Name;

            [XmlAttribute("Weight")]
            public int Weight;

            [XmlArray("Actions"), XmlArrayItem("Action")]
            public List<InterviewScenarioAction> Actions;
        }        

        public class SurveyScenario
        {
            public class SurveyQuota
            {
                [XmlAttribute("Name")]
                public string Name;

                [XmlAttribute("Balancing")]
                public bool Balancing;

                [XmlAttribute("UpdateCounter")]
                public bool UpdateCounter;

                [XmlAttribute("TargetFunc")]
                public QuotaTargetFunc TargetFunc;

                [XmlAttribute("TargetArg")]
                public int TargetArg;

                [XmlAttribute("BalancingFields")]
                public string BalancingFields;

                [XmlAttribute("PromotionThreshold")]
                public int PromotionThreshold;

                [XmlAttribute("Clustering")]
                public bool Clustering;

                [XmlAttribute("LiveThreshold")]
                public int LiveThreshold;
            }

            public class SurveyAction
            {
                [XmlAttribute("Action")]
                public EnumAction Action;

                [XmlAttribute("Param")]
                public string Param;

                [XmlArray("Actions")]
                public List<SurveyAction> Actions;

                [XmlAttribute("LineNumber")]
                public int LineNumber;
            }

            [XmlAttribute("Name")]
            public string Name;

            [XmlAttribute("Enable")]
            public bool Enable;

            [XmlAttribute("Schema")]
            public string SchemaPath;

            [XmlArray("TestActions")]
            public List<SurveyAction> TestActions;

            [XmlArray("PrepareActions")]
            public List<SurveyAction> PrepareActions;

            [XmlArray("Quotas"), XmlArrayItem("Quota")]
            public List<SurveyQuota> Quotas;

            [XmlAttribute("InterviewScenarios")]
            public string InterviewScenarios;
        }

        [XmlArray("SurveyScenarios")]
        public List<SurveyScenario> SurveyScenarios;

        [XmlArray("InterviewScenarios"), XmlArrayItem("Scenario")]
        public List<InterviewScenario> InterviewScenarios;
    }
}
