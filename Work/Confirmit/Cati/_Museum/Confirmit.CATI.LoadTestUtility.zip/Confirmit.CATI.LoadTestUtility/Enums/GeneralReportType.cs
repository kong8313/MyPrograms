﻿namespace Confirmit.CATI.LoadTestUtility.Enums
{
    public enum GeneralReportType
    {
        SurveyProductivity,

        InterviewerProductivity
    }
}
