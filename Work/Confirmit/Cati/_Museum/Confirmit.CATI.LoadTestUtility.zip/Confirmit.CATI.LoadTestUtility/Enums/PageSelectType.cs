﻿namespace Confirmit.CATI.LoadTestUtility.Enums
{
    public enum PageSelectType
    {
        First,

        Last,

        Random
    }
}
