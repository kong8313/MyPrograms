using System.Xml.Serialization;

namespace Confirmit.CATI.LoadTestUtility.Enums
{
    public enum InterviewScenarioActionType
    {
        [XmlEnum("Interviewing")]
        Interviewing,
        [XmlEnum("SetBreak")]
        SetBreak,
        [XmlEnum("SetAppointment")]
        SetAppointment,
        [XmlEnum("Complete")]
        Complete,
        [XmlEnum("Sleep")]
        Sleep,
        [XmlEnum("ResetBreak")]
        ResetBreak
    }
}