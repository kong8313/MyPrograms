﻿using System.Xml.Serialization;

namespace Confirmit.CATI.LoadTestUtility.Enums
{
    public enum EnumAction
    {
        [XmlEnum("OpenSurvey")]
        OpenSurvey,
                    
        [XmlEnum("CloseSurvey")]
        CloseSurvey,

        [XmlEnum("LaunchSurvey")]
        LaunchSurvey,

        [XmlEnum("AddSample")]
        AddSample,
                    
        [XmlEnum("SyncRespondentData")]
        SyncRespondentData,
                    
        [XmlEnum("Sleep")]
        Sleep,
                    
        [XmlEnum("OpenCells")]
        OpenCells,
                    
        [XmlEnum("CloseCells")]
        CloseCells,
                    
        [XmlEnum("MoveCalls")]
        MoveCalls,

        [XmlEnum("MoveAndRescheduleCalls")]
        MoveAndRescheduleCalls,

        [XmlEnum("ActivateCalls")]
        ActivateCalls,

        [XmlEnum("ChangeCallsPriority")]
        ChangeCallsPriority,

        [XmlEnum("ChangeCallsShiftType")]
        ChangeCallsShiftType,

        [XmlEnum("AssignCalls")]
        AssignCalls,

        [XmlEnum("GeneralReport")]
        GeneralReport,

        [XmlEnum("Sync")]
        Sync,

        [XmlEnum("ExecSql")]
        ExecSql,

        [XmlEnum("SetEvent")]
        SetEvent,

        [XmlEnum("ResetEvent")]
        ResetEvent,

        [XmlEnum("GetCallsPage")]
        GetCallsPage,

        [XmlEnum("CreateFilter")]
        CreateFilter,
        [XmlEnum("OptimisticFcdTest")]
        OptimisticFcdTest
    }
}