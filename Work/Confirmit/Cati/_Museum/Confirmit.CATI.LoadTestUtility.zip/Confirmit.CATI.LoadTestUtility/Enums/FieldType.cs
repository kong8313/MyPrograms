namespace Confirmit.CATI.LoadTestUtility.Enums
{
    public enum FieldType
    {
        Normal,
        Background
    }
}