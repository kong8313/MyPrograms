using System.Xml.Serialization;

namespace Confirmit.CATI.LoadTestUtility.Enums
{
    public enum QuotaTargetFunc
    {
        [XmlEnum("TargetArg")]
        TargetArg,
        [XmlEnum("MaxCounterPlusTargetArg")]
        MaxCounterPlusTargetArg,
        [XmlEnum("CounterPlusTargetArg")]
        CounterPlusTargetArg
    }
}