﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

using Confirmit.CATI.Core.DAL.Generated.Entity.Table;
using Confirmit.CATI.LoadTestUtility.ActionParameters;

namespace Confirmit.CATI.LoadTestUtility
{
    public class TestConfigurationReader
    {
        private readonly string _configPath;
        private readonly string _folderPath;
        private readonly RunAction _executionMode;
        private readonly RoleType _role;

        public TestConfigurationReader(string[] agrs)
        {
            _configPath = agrs[0];
            _folderPath = Path.GetDirectoryName(Path.GetFullPath(agrs[0]));
            _executionMode = (RunAction)Enum.Parse(typeof(RunAction), agrs[1]);
            _role = (RoleType)Enum.Parse(typeof(RoleType), agrs[2]);
        }

        public TestConfiguration Load()
        {
            var xs = new XmlSerializer(typeof(TestConfigurationXmlModel));
            using (StreamReader sr = File.OpenText(_configPath))
            {
                // xs.Serialize(sr, new TestConfiguration());
                return Parse((TestConfigurationXmlModel)xs.Deserialize(sr));
            }
        }

        private TestConfiguration Parse(TestConfigurationXmlModel model)
        {
            var scenarios = model.SurveyScenarios.Select(ParseSurveyScenario).ToArray();
            
            return new TestConfiguration
                {
                    AdministratorsCount = model.TotalSurvey,
                    Role = _role,
                    LoadScenario = model.LoadScenario.Select(ParseLoadInterval).ToArray(),
                    ExecutionMode = _executionMode,
                    CallGroups = ParseCallGroups(model.CallGroups),
                    AllSurveyScenarios = scenarios,
                    SurveyScenarios = scenarios.Where(x => x.Enable).ToArray(),
                    DialerScenarios = ParseDialerScenario(model.DialerScenarios)
                };
        }

        private TestConfiguration.DialerScenario[] ParseDialerScenario(IEnumerable<TestConfigurationXmlModel.DialerScenario> dialerScenarios)
        {
            return dialerScenarios.Select(dialerScenario => new TestConfiguration.DialerScenario
            {
                CallsCountPerInterviewer = dialerScenario.CallsCountPerInterviewer, 
                OutcomeLists = PaseOutcomeLists(dialerScenario.OutcomeLists)
            }).ToArray();
        }

        private TestConfiguration.DialerScenario.OutcomeList[] PaseOutcomeLists(IEnumerable<TestConfigurationXmlModel.DialerScenario.OutcomeList> outcomeLists)
        {
            return outcomeLists.Select(outcomeList => new TestConfiguration.DialerScenario.OutcomeList
            {
                CallOutcome = outcomeList.CallOutcome, 
                DistributionWeight = outcomeList.DistributionWeight, 
                ProcessingTime = outcomeList.ProcessingTime
            }).ToArray();
        }

        private Dictionary<BvCallGroupEntity, BvCallGroupConditionEntity[]> ParseCallGroups(IEnumerable<TestConfigurationXmlModel.CallGroup> callGroups)
        {
            var result = new Dictionary<BvCallGroupEntity, BvCallGroupConditionEntity[]>();

            if (callGroups == null)
                return result;

            foreach (var callGroup in callGroups)
            {
                var conditions = callGroup.Its.Split(new[] { ',' }).Select(
                    x => new BvCallGroupConditionEntity { ConditionValue = int.Parse(x), ConditionPriority = 5 }).
                    ToArray();

                result.Add(new BvCallGroupEntity { Name = callGroup.Name }, conditions);
            }

            return result;
        }

        private TestConfiguration.SurveyScenario ParseSurveyScenario(TestConfigurationXmlModel.SurveyScenario scenario)
        {
            var schemaPath = Path.Combine(_folderPath, scenario.SchemaPath);

            if (!File.Exists(schemaPath))
            {
                OnError("Survey scenario with name '{0}' contains wrong path to schema file '{1}'. File not exists", scenario.Name, schemaPath);
            }

            var schema = new SurveySchemaReader().Load(schemaPath);

            return new TestConfiguration.SurveyScenario
                {
                    Name = scenario.Name,
                    Enable = scenario.Enable,
                    SchemaPath = schemaPath,
                    Schema = schema,
                    Quotas = scenario.Quotas.Select(ParseSurveyQuota).ToArray(),
                    Actions = _executionMode == RunAction.Preparation
                        ? scenario.PrepareActions.Select(ParseSurveyAction).ToArray()
                        : scenario.TestActions.Select(ParseSurveyAction).ToArray()
                };
        }

        private TestConfiguration.SurveyScenario.SurveyAction ParseSurveyAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action)
        {
            return new TestConfiguration.SurveyScenario.SurveyAction
                {
                    Action = action.Action,
                    Param = action.Param,

                };
        }

        private TestConfiguration.SurveyScenario.SurveyQuota ParseSurveyQuota(TestConfigurationXmlModel.SurveyScenario.SurveyQuota quota)
        {
            return new TestConfiguration.SurveyScenario.SurveyQuota
                {
                    Name = quota.Name,
                    Balancing = quota.Balancing,
                    UpdateCounter = quota.UpdateCounter,
                    TargetFunc = quota.TargetFunc,
                    TargetArg = quota.TargetArg,
                    BalancingFields = quota.BalancingFields.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries),
                    PromotionThreshold = quota.PromotionThreshold,
                    Clustering = quota.Clustering,
                    LiveThreshold = quota.LiveThreshold
                };
        }

        private TestConfiguration.LoadInterval ParseLoadInterval(TestConfigurationXmlModel.LoadInterval interval)
        {
            return new TestConfiguration.LoadInterval
                {
                    TotalAutoInterviewers = new RandomIntParam(interval.TotalAutoInterviewers),
                    TotalSAInterviewers = new RandomIntParam(interval.TotalSAInterviewers),
                    TotalCGInterviewers = new RandomIntParam(interval.TotalCGInterviewers),
                    Duration = interval.Duration,
                    ReloginTimeoutOnFrozenState = interval.ReloginTimeoutOnFrozenState,
                    LoginDelay = NamedParams.ToRandomTimeSpan(interval.LoginDelay)
                };
        }

        private void OnError(string format, params object[] args)
        {
            throw new Exception(String.Format(format, args));
        }
    }
}
