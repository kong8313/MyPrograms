﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Web;
using Confirmit.CATI.Core.AuthoringService;
using Confirmit.CATI.Core.DAL.Framework;
using Confirmit.CATI.Core.DAL.Generated.Entity.Adapter;
using Confirmit.CATI.Core.DAL.Generated.Entity.Table;
using Confirmit.CATI.Core.Misc;
using Confirmit.CATI.Core.Misc.CP;
using Confirmit.CATI.Core.Repositories;
using Confirmit.CATI.Core.Repositories.Interfaces;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Core.ServiceRegistration;
using Confirmit.CATI.Core.Services;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Scenarios;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.LoadTestUtility.ActivityEvents;
using System.Text;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Core.Misc.ConfirmitClientKey;
using Confirmit.CATI.Core.SupervisorService;
using Confirmit.CATI.IntegrationTests.Framework.ServiceLocatorRegistry;
using Confirmit.CATI.LoadTestUtility.WorkflowServices;
using Confirmit.CATI.Supervisor.Core.CallCenters;
using Confirmit.CATI.Supervisor.Core.Surveys;
using Confirmit.Security.Crypto.Web;
using ConfirmitDialerInterface;

namespace Confirmit.CATI.LoadTestUtility
{
    internal class Program
    {
        internal static int CompanyId { get; set; }

        internal static int CallCenterId { get; set; }

        public static void Main(string[] args)
        {
            try
            {
                Logger.InitWsListener(0);

                if (args.Length < 3)
                {
                    Logger.Error(@"Invalid param list");
                    ShowHelp();
                    return;
                }

                Logger.Info("Read configuration {0}...", args[0]);
                TestConfiguration config = new TestConfigurationReader(args).Load();

                var scenario = new UtilityScenarioParser(args[0], args[1]).Parse();
                ShowConfig(scenario);

                Logger.Info("Initialize perfomance counters...");
                PerformanceCounters.Initialize();

                Logger.Info("Initialize service locator...");

                InitializeServiceLocator();

                Logger.Info("Initialize core...");
                InitializeCore();

                CallCenterId = new CallCenterRepository().Default.ID;

                new StartLoadTestEvent(args[0], GetAreaDescription()).Finish();

                Logger.Info("Initialize person ...");
                var autoInterviewers = new InterviewerManager(config.AdministratorsCount, AgentTaskChoiceMode.Automatic, true, false);
                var surveyAssignInterviewers = new InterviewerManager(config.AdministratorsCount, AgentTaskChoiceMode.CampaignAssignment, false, false);
                var callGroupInterviewers = new InterviewerManager(config.AdministratorsCount, AgentTaskChoiceMode.CampaignAssignment, false, true);

                Logger.Info("Create call groups");

                CreateCallGroups(config.CallGroups);

                Logger.Info("Run data thread");
                var dataThread = new DataUpdateThread();
                dataThread.Start();
                AdministratorWorkflowService[] admins;

                if (config.Role == RoleType.Master)
                {
                    Logger.Info("Run admins threads...");
                    admins = new AdministratorWorkflowService[config.AdministratorsCount];

                    for (int index = 0; index < admins.Length; index++)
                    {
                        var surveyScenario = scenario.SurveyScenarios[index % scenario.SurveyScenarios.Count];

                        admins[index] = new AdministratorWorkflowService(
                            scenario,
                            surveyScenario,
                            autoInterviewers.InterviewersGroup[index % autoInterviewers.InterviewersGroup.Length],
                            surveyAssignInterviewers.InterviewersGroup[index % surveyAssignInterviewers.InterviewersGroup.Length],
                            callGroupInterviewers.InterviewersGroup[index % callGroupInterviewers.InterviewersGroup.Length],
                            index);
                        admins[index].Start();
                    }
                }
                else
                {
                    admins = new AdministratorWorkflowService[0];

                    for (int index = 0; index < config.AdministratorsCount; index++)
                    {
                        var surveyScenario = scenario.SurveyScenarios[index % scenario.SurveyScenarios.Count];
                        BvSurveyEntity survey = BvSurveyAdapter.GetByCondition("[Description] = @Description\r\n", new SqlParameter("@Description", index.ToString(CultureInfo.InvariantCulture))).Single();
                        if (survey == null)
                        {
                            throw new Exception(string.Format("No survey with decsription '{0}' was found", index));
                        }

                        SurveyTools.OpenSurveyContext(
                            survey.Name,
                            surveyScenario,
                            autoInterviewers.InterviewersGroup[index % autoInterviewers.InterviewersGroup.Length],
                            surveyAssignInterviewers.InterviewersGroup[index % surveyAssignInterviewers.InterviewersGroup.Length],
                            callGroupInterviewers.InterviewersGroup[index % callGroupInterviewers.InterviewersGroup.Length]);
                    }
                }

                if (config.ExecutionMode == RunAction.Preparation)
                {
                    do
                    {
                        Thread.Sleep(TimeSpan.FromSeconds(1));
                    }
                    while (admins.Any(admin => admin.IsProcessRunning));
                }
                else
                {
                    Logger.Info("Run interviewer threads...");
                    int currentLoadScenarioId = 0;

                    do
                    {
                        TestConfiguration.LoadInterval interval = config.LoadScenario[currentLoadScenarioId];

                        autoInterviewers.OverregulateActiveUserCount(interval.TotalAutoInterviewers, interval);
                        surveyAssignInterviewers.OverregulateActiveUserCount(interval.TotalSAInterviewers, interval);
                        callGroupInterviewers.OverregulateActiveUserCount(interval.TotalCGInterviewers, interval);

                        for (int i = 0; i < interval.Duration * 60; i++)
                        {
                            if (admins.Length == 0 || admins.Any(admin => admin.IsProcessRunning))
                            {
                                Thread.Sleep(TimeSpan.FromSeconds(1));
                            }
                            else
                            {
                                break;
                            }
                        }

                        currentLoadScenarioId = (currentLoadScenarioId + 1) % config.LoadScenario.Length;
                    }
                    while (admins.Length == 0 || admins.Any(admin => admin.IsProcessRunning));

                    // logout all persons
                    autoInterviewers.OverregulateActiveUserCount(RandomIntParam.Zero, config.LoadScenario[currentLoadScenarioId]);
                    surveyAssignInterviewers.OverregulateActiveUserCount(RandomIntParam.Zero, config.LoadScenario[currentLoadScenarioId]);
                    callGroupInterviewers.OverregulateActiveUserCount(RandomIntParam.Zero, config.LoadScenario[currentLoadScenarioId]);
                }

                Logger.Info("End admin thread. Stop data thread");
                Logger.Flush();

                dataThread.Stop();
                dataThread.Wait(TimeSpan.FromSeconds(60));
            }
            catch (Exception ex)
            {
                Logger.Error("Exception: {0}", ex.ToString());
            }

            Logger.Info("End execution");
            Logger.Flush();
        }

        private static void ShowConfig(UtilityScenario config)
        {
            foreach (var scenario in config.SurveyScenarios)
            {
                Logger.Warn(
                    scenario.Enabled
                        ? String.Format("           Scenario '{0} is enabled", scenario.Name)
                        : String.Format("WARNING!!! Scenario '{0} is disabled", scenario.Name));

                SurveyScenarioTools.ShowScenarioInfo(scenario);
            }
        }

        private static void CreateCallGroups(Dictionary<BvCallGroupEntity, BvCallGroupConditionEntity[]> callGroups)
        {
            var service = ServiceLocator.Resolve<ICallGroupService>();
            var repository = ServiceLocator.Resolve<ICallGroupRepository>();

            foreach (var group in callGroups)
            {
                var callGroup = group.Key;
                repository.Insert(callGroup);
                service.SetListOfCondition(callGroup.Id, group.Value);
            }
        }

        private static void InitializeServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            IServicesRegistryInitializer serviceRegistryInitializer = new ServicesRegistryInitializer(serviceLocator);
            serviceRegistryInitializer.RegisterRegistries(serviceRegistryInitializer.GetRegistries());
            ServiceLocator.Register<ISupervisorNameProvider, HttpContextSupervisorNameProvider>();
            ServiceLocator.Register<ISupervisorServiceClient, SupervisorServiceClient>();
            ServiceLocator.Register<IAuthenticationData, AuthenticationData>();
            ServiceLocator.RegisterSingleton<ICallCenterProvider, TestCallCenterProvider>();
            ServiceLocator.Register<IConfirmitClientKeyProvider, LoadTestUtilityConfirmitClientKeyProvider>();
        }

        internal static string GetAreaDescription()
        {
            var sb = new StringBuilder();

            sb.AppendFormat("BE Url={0}\r\n", AppConfiguration.MultimodeWebServiceURL);
            sb.AppendFormat("BE Sql={0}\r\n", DatabaseEngines.Backend.ConnectionString);
            sb.AppendFormat("CF Sql={0}\r\n", DatabaseEngines.Confirmit.ConnectionString);

            return sb.ToString();
        }

        internal static void InitializeCore()
        {
            CompanyId = AppConfiguration.CompanyID;

            Logger.InitWsListener(CompanyId);

            SimulatedHttpRequest.SetHttpContextWithSimulatedRequest("MyHost", "MyBlog");

            HttpContext.Current.User = new SupervisorPrincipal(
                    "userName",
                    "clientKey",
                    CompanyId.ToString(CultureInfo.InvariantCulture),
                    "Load test company",
                    Tabs.None,
                    false, false, false);

            var backendInstance = ServiceLocator.Resolve<IBackendInstanceFactory>().Create(
                CompanyId,
                HostType.Supervisor);
            HttpContext.Current.Items["BackendInstance"] = backendInstance;

            BackendInstance.Current.ConnectionString = DatabaseEngines.Backend.ConnectionString;
            BackendInstance.Current.ConfirmlogConnectionString = AppConfiguration.ConnectionStringToConfirmLog;

            UpdateSystemSetting(DatabaseEngines.DefaultDatabase, "Setup.EncryptedConfirmConnectionString", EncryptionUsingMachineKey.Encrypt(DataProtection.All, AppConfiguration.ConnectionStringToConfirm));
            UpdateSystemSetting(DatabaseEngines.DefaultDatabase, "Setup.EncryptedConfirmlogConnectionString", EncryptionUsingMachineKey.Encrypt(DataProtection.All, AppConfiguration.ConnectionStringToConfirmLog));
        }

        private static void UpdateSystemSetting(DatabaseEngine databaseEngine, string settingName, string value)
        {
            databaseEngine.ExecuteNonQuery(string.Format("exec BvSpSystemSetting_Update '{0}', '{1}'", settingName, value), CommandType.Text);
        }

        private static void ShowHelp()
        {
            System.Console.WriteLine(@"using:");
            System.Console.WriteLine(@"    {0} configFile action roleType", Path.GetFileName(Assembly.GetExecutingAssembly().Location));
            System.Console.WriteLine(@"action: Preparation or Test");
            System.Console.WriteLine(@"roleType: Master or Slave");
        }
    }
}
