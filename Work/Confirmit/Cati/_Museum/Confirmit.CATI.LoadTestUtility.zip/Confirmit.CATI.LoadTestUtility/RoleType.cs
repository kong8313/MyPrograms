﻿namespace Confirmit.CATI.LoadTestUtility
{
    public enum RoleType
    {
        Master,
        Slave
    }
}
