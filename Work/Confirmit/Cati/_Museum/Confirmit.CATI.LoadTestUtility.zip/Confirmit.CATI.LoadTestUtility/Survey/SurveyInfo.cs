﻿using System.Collections.Generic;

using Confirmit.CATI.LoadTestUtility.Quota;
using Confirmit.CATI.LoadTestUtility.Scenarios;

namespace Confirmit.CATI.LoadTestUtility.Survey
{
    public class SurveyInfo
    {
        public int Sid;

        public string ProjectId;

        public string Name;

        public string[] Tables;

        public SurveyScenario Scenario;

        public Dictionary<string, string> FieldToTableMap;

        public SurveyQuotasCache QuotasCache;

        public int AutoGroup;

        public int SaGroup;

        public int CgGroup;
    }
}
