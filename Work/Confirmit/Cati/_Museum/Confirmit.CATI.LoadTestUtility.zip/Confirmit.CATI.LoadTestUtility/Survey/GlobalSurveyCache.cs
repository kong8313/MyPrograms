﻿using System.Collections.Generic;
using System.Linq;

namespace Confirmit.CATI.LoadTestUtility.Survey
{
    class GlobalSurveyCache
    {
        static private readonly Dictionary<string, SurveyInfo> SurveyQuotasCache = new Dictionary<string, SurveyInfo>();

        public static void RegistrySurveyQuotas(string projectId, SurveyInfo cache)
        {
            lock (SurveyQuotasCache)
            {
                SurveyQuotasCache.Add(projectId, cache);
            }
            
        }

        public static SurveyInfo Get(string projectId)
        {
            lock (SurveyQuotasCache)
            {
                return SurveyQuotasCache[projectId];
            }
        }

        public static SurveyInfo[] GetSnapshotList()
        {
            lock(SurveyQuotasCache)
            {
                return SurveyQuotasCache.Values.ToArray();
            }
        }
    }
}
