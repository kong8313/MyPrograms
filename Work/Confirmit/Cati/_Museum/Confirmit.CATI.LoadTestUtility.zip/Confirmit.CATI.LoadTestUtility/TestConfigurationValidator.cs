﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Confirmit.CATI.LoadTestUtility.Enums;

namespace Confirmit.CATI.LoadTestUtility
{
    public class TestConfigurationValidator
    {
        private TestConfiguration Config { get; set; }

        private string ConfigPath { get; set; }

        public List<string> Errors = new List<string>();

        public TestConfigurationValidator(TestConfiguration config, string path)
        {
            Config = config;
            ConfigPath = path;

        }

        public bool Validate()
        {
            Errors.Clear(); 
            
            foreach (var survey in Config.AllSurveyScenarios)
            {
                ValidateSurvey(survey);
            }

            if (Config.SurveyScenarios.Length == 0)
            {
                OnError("There aren't any enabled surveys in configuration file");
                return false;
            }


            return Errors.Count <= 0;
        }

        private void ValidateSurvey(TestConfiguration.SurveyScenario survey)
        {
            foreach (var quota in survey.Quotas)
            {
                ValidateSurveyQuota(survey, quota);
            }
        }

        private void ValidateSurveyQuota(TestConfiguration.SurveyScenario survey, TestConfiguration.SurveyScenario.SurveyQuota quota)
        {
            SurveySchema.QuotaInfo schemaQuota;
            if (!survey.Schema.Quotas.TryGetValue(quota.Name, out schemaQuota))
            {
                this.OnError("quota '{0}\\{1}' not found is survey schema", survey.Name, quota.Name);
            }

            if (!schemaQuota.IsFcd && !schemaQuota.IsCati)
            {
                this.OnError("quota '{0}\\{1}' isn't cati", survey.Name, quota.Name);
            }

            var unknownFields = quota.BalancingFields.Where(x => !schemaQuota.Fields.Any(f => f == x)).ToArray();

            if (unknownFields.Length > 0)
            {
                this.OnError(
                    "quota '{0}\\{1}' contains following fields which aren't presented in survey schema: {2}",
                    survey.Name,
                    quota.Name,
                    String.Join(",", unknownFields));
            }
        }

        private void OnError( string format, params object[] args )
        {
            Errors.Add(String.Format(format, args));
        }
    }
}
