﻿namespace Confirmit.CATI.LoadTestUtility.Quota
{
    internal class MatchingQuotaCells
    {
    }
}
