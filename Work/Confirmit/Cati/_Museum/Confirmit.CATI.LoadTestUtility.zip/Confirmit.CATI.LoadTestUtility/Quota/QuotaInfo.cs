using System.Collections.Generic;
using Confirmit.CATI.LoadTestUtility.Scenarios;

namespace Confirmit.CATI.LoadTestUtility.Quota
{
    public class QuotaInfo
    {
        public SurveyScenario.QuotaConfig Config { get; set; }

        public int QuotaId { get; set; }

        public string[] Fields { get; set; }

        public CellStateInfo[] Cells { get; set; }

        public Dictionary<string, CellStateInfo> CellsByKey { get; set; }
    }
}