using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Core.Services.Interfaces;

namespace Confirmit.CATI.LoadTestUtility.Quota
{
    public class CellStateInfo
    {
        public CellStateInfo(int quotaId, int cellId, IEnumerable<string> values)
        {
            this.QuotaId = quotaId;
            this.CellId = cellId;
            this.Values = values.ToArray();
            this.Key = CreateKey(Values.Select( x => x.ToString()));

            Counter = 0;
            Limit = 1;
            State = QuotaCellState.PessimisticallyOpened;
            IsLocked = false;
        }

        public static string CreateKey( IEnumerable<string> data)
        {
            return String.Join(",", data.Select(x => x ?? "N").ToArray());
        }

        public int QuotaId { get; private set; }
        public int CellId { get; private set; }
        public string[] Values { get; private set; }

        public string Key { get; private set; }

        public int Counter { get; set; }
        public int Limit { get; set; }
        public QuotaCellState State { get; set; }
        public bool IsLocked { get; set; }
    }
}