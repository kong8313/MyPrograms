﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Common.Random;
using Confirmit.CATI.Core.Services.Interfaces;
using Confirmit.CATI.LoadTestUtility.Scenarios;

namespace Confirmit.CATI.LoadTestUtility.Quota
{
    public class SurveyQuotasCache
    {
        public Dictionary<int, QuotaInfo> Quotas { get; private set; }

        public string[] Fields { get; private set; }

        public bool ShouldBeQuotaCountersUpdated { get; private set; }

        public SurveyQuotasCache(SurveyScenario scenario, IEnumerable<QuotaInfo> quotaInfos)
        {
            Quotas = quotaInfos.ToDictionary(quota => quota.QuotaId);
            Fields = quotaInfos.SelectMany(x => x.Fields).Distinct().ToArray();
            ShouldBeQuotaCountersUpdated = quotaInfos.Any(x => x.Config.UpdateCounter);

        }

        public List<CellStateInfo> GetRandomCellsWithLock(int count, QuotaCellState state)
        {
            var result = new List<CellStateInfo>();
            lock( this.Quotas )
            {
                var availableCells = this.Quotas.SelectMany(quota => quota.Value.Cells).Where(cell => cell.State == state && cell.IsLocked == false).ToArray();

                int n = availableCells.Length;
                count = Math.Min(count, n);
                while (count > 0)
                {
                    n--;
                    int index = Randomizer.Next(n);
                    var cell = availableCells[index];
                    result.Add(cell);
                    cell.IsLocked = true;

                    // swap to elements
                    var temp = availableCells[n];
                    availableCells[n] = availableCells[index];
                    availableCells[index] = temp;

                    count--;
                }
            }

            return result;
        }

        public void UnlockCells(List<CellStateInfo> cells, QuotaCellState state)
        {
            foreach (var cell in cells)
            {
                UnlockCell(cell, state);
            }
        }

        public void UnlockCell(CellStateInfo cell, QuotaCellState state)
        {
            cell.IsLocked = false;
            cell.State = state;
        }

        public void IncrementCounters(Dictionary<string, string> data)
        {
            foreach( var quota in this.Quotas)
            {
                CellStateInfo cell;

                if (TryGetCell(quota.Value, data, out cell))
                {
                    cell.Counter++;
                }
            }
        }

        private bool TryGetCell( QuotaInfo quota, Dictionary<string, string> data, out CellStateInfo cell)
        {
            var quotaData = quota.Fields.Select(fieldName => data[fieldName]).ToArray();
            var key = CellStateInfo.CreateKey(quotaData);

            return quota.CellsByKey.TryGetValue(key, out cell);
        }
    }
}
