﻿using System;
using System.Data;
using System.Linq;

using Confirmit.CATI.Core.Threading;
using Confirmit.CATI.LoadTestUtility.ActivityEvents;
using Confirmit.CATI.LoadTestUtility.Survey;

namespace Confirmit.CATI.LoadTestUtility
{
    public class DataUpdateThread : PeriodicalThread
    {
        public DataUpdateThread()
            : base("UpdateDataThread")
        {
        }

        public override TimeSpan StopTimeout
        {
            get
            {
                return TimeSpan.FromSeconds(30);
            }
        }

        public override TimeSpan SleepTimeout
        {
            get
            {
                return TimeSpan.FromSeconds(60);
            }
        }

        private bool isFirst = true;

        protected override void DoWork(object parameter)
        {
            if( this.isFirst )
            {
                Program.InitializeCore();
                this.isFirst = false;
            }

            var caches = GlobalSurveyCache.GetSnapshotList();
            foreach (var surveyInfo in caches)
            {
                foreach( var quota in surveyInfo.QuotasCache.Quotas.Values.Where(x => x.Config.UpdateCounter ))
                {
                    QuotaTools.RecalculateTargets(quota);
                    var evt = new UpdateQuotaCountersEvent(surveyInfo, quota);
                    QuotaTools.UpdateQuotaCountersInDb(surveyInfo.ProjectId, quota);
                    QuotaTools.UpdateQuotaLimitsInCf(surveyInfo, quota);
                    evt.Finish();
                }
            }
        }
    }
}
