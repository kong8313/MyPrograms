﻿using System.Collections.Generic;
using System.Threading;
using Confirmit.CATI.Core.DAL.Generated.Entity.Adapter;
using Confirmit.CATI.Core.DAL.Generated.Entity.Table;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.LoadTestUtility.WorkflowServices;
using System.Linq;

using ConfirmitDialerInterface;

namespace Confirmit.CATI.LoadTestUtility
{
    internal class InterviewerManager
    {
        public int[] InterviewersGroup { get; private set; }

        public AgentTaskChoiceMode PersonMode { get; private set; }

        public bool UseCallGroup { get; private set; }

        private List<InterviewerWorkflowService> Interviewers = new List<InterviewerWorkflowService>();

        public InterviewerManager(int groupCount, AgentTaskChoiceMode personMode, bool useCatiGroup, bool useCallGroup)
        {
            PersonMode = personMode;
            UseCallGroup = useCallGroup;
            int catiInterviewers = BackendTools.GetInterviewGroup();
            IEnumerable<int> groups;

            if (groupCount == 0)
                groups = BvPersonGroupAdapter.GetAll()
                                             .Where(x => x.Name.StartsWith(NameMaker.PersonModePrefix(personMode)))
                                             .Select(x => x.SID);
            else
                groups = Enumerable.Range(0, groupCount).Select(x => BackendTools.CreatePersonGroup(
                    NameMaker.PersonGroupName(personMode, x, useCallGroup), catiInterviewers ));

            if (useCatiGroup)
                groups = groups.Union(new[] { catiInterviewers }); 

            InterviewersGroup = groups.ToArray();
        }

        public void OverregulateActiveUserCount(RandomIntParam count, TestConfiguration.LoadInterval interval)
        {
            lock (this)
            {
                //
                // Add new interviewers, if needs
                //
                if (count.MaxValue > Interviewers.Count)
                {
                    for (int index = Interviewers.Count; index < count.MaxValue; index++)
                    {
                        Interviewers.Add(new InterviewerWorkflowService(index, InterviewersGroup[index % InterviewersGroup.Length], PersonMode, UseCallGroup));
                    }
                }

                var loginPerson = count.Value;

                //
                // activate required quantity of interviewers
                //

                for (int index = 0; index < Interviewers.Count; index++)
                {
                    bool isStateChanged;
                    if (index < loginPerson)
                    {
                        isStateChanged = Interviewers[index].OnActivate(interval);
                    }
                    else
                    {
                        isStateChanged = Interviewers[index].OnDeactivateBegin();
                    }

                    if (isStateChanged)
                    {
                        Thread.Sleep(interval.LoginDelay.Value);
                    }
                }

                for (int index = loginPerson; index < Interviewers.Count; index++)
                {
                    Interviewers[index].OnDeactivateEnd();
                }
            }
        }
    }
}
