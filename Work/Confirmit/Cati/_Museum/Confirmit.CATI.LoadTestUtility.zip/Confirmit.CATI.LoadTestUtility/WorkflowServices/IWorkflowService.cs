namespace Confirmit.CATI.LoadTestUtility.WorkflowServices
{
    public interface IWorkflowService
    {
        void Process();
    }
}