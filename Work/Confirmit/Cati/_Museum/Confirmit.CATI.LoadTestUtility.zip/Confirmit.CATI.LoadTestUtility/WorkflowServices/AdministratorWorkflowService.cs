﻿using System;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Threading;
using Confirmit.CATI.Core.DAL.Generated.Entity.Adapter;
using Confirmit.CATI.Core.DAL.Generated.Entity.Table;
using Confirmit.CATI.LoadTestUtility.Scenarios;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.WorkflowServices
{
    internal class AdministratorWorkflowService : IWorkflowService
    {
        private readonly UtilityScenario _config;

        private readonly SurveyScenario _scenario;

        private readonly int _autoGroup;
        private readonly int _saGroup;
        private readonly int _cgGroup;
        private readonly int _adminId;

        private Thread _thread;

        public bool IsProcessRunning { get; private set; }

        public AdministratorWorkflowService(UtilityScenario config, SurveyScenario scenario, int autoGroup, int saGroup, int cgGroup, int adminId)
        {
            _config = config;
            _scenario = scenario;
            _autoGroup = autoGroup;
            _saGroup = saGroup;
            _cgGroup = cgGroup;
            _adminId = adminId;
            IsProcessRunning = false;
        }

        public void Start()
        {
            lock (this)
            {
                if (_thread != null)
                {
                    return;
                }
                
                _thread = new Thread(ProcessThread);
                _thread.Name = $"Admin:{_scenario.Name}";
                IsProcessRunning = true;
                _thread.Start();
            }
        }

        public void ProcessThread()
        {
            try
            {
                Program.InitializeCore();
                
                Process();
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Error("Administrator thread failed. Exception detailes: {0}", ex);
            }
            finally
            {
                IsProcessRunning = false;
            }
        }

        public void Process()
        {
            SurveyContext context;
            if (_config.ExecutionMode == RunAction.Preparation)
            {
                context = SurveyTools.CreateSurveyContext(
                    _scenario,
                    _autoGroup,
                    _saGroup,
                    _cgGroup,
                    _adminId.ToString(CultureInfo.InvariantCulture));
            }
            else
            {
                try
                {
                    BvSurveyEntity survey = BvSurveyAdapter.GetByCondition("[Description] = @Description\r\n", new SqlParameter("@Description", _adminId.ToString(CultureInfo.InvariantCulture))).Single();

                    context = SurveyTools.OpenSurveyContext(
                        survey.Name,
                        _scenario,
                        _autoGroup,
                        _saGroup,
                        _cgGroup);
                }
                catch (Exception ex)
                {
                    throw new Exception($"No survey with decsription '{_adminId}' was found or there are two or more such surveys", ex);
                }
            }

            var name = String.Format("Survey {0} ({1})", context.ProjectId, context.Scenario.Name);
            using (Logger.Sub(name))
            {
                _scenario.Execute(context);
            }
        }
    }
}
