using System;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Threading;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.Common.Contracts.ConsoleAuthorizationService;
using Confirmit.CATI.Common.SideBySide;
using Confirmit.CATI.Common.Random;
using Confirmit.CATI.Core.ManagementService;
using Confirmit.CATI.Core.Repositories.Interfaces;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Console.Classes.User;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Core.SystemSettings;
using Confirmit.CATI.LoadTestUtility.Scenarios;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Services;
using Confirmit.CATI.LoadTestUtility.Survey;
using Confirmit.CATI.LoadTestUtility.Tools;

using ConfirmitDialerInterface;

using InterviewControlData = Confirmit.CATI.Core.ManagementService.InterviewControlData;
using MonitoringService = Confirmit.CATI.LoadTestUtility.Tools.MonitoringService;
using TimeoutException = System.ServiceProcess.TimeoutException;

namespace Confirmit.CATI.LoadTestUtility.WorkflowServices
{
    public class InterviewerWorkflowService : IWorkflowService
    {
        // Thread control fields
        private Thread Thread { get; set; }

        private int RotationIndex { get; set; }

        // Pesron info
        private UserInfo User { get; set; }

        // Load interval info
        private TestConfiguration.LoadInterval LoadInterval { get; set; }
        
        // Console state
        private string SelectedProjectId { get; set; }

        private IConsoleAuthorizationService ConsoleAuthorizationService { get; set; }

        private readonly ISystemSettingRepository _systemSettingRepository;
        private readonly ICatiServiceManager _catiServiceManager;
        private readonly IAuthenticationData _authenticationData;

        private MonitoringService monitoring;

        public InterviewerWorkflowService(int id, int parentGroup, AgentTaskChoiceMode mode, bool useCallGroup)
        {
            _systemSettingRepository = ServiceLocator.Resolve<ISystemSettingRepository>();
            _authenticationData = ServiceLocator.Resolve<IAuthenticationData>();
            _catiServiceManager = new CatiServiceManager(_authenticationData);

            RotationIndex = id;

            int callGroupId = 0;
            if( useCallGroup )
            {
                var groups = ServiceLocator.Resolve<ICallGroupRepository>().GetAllGroups();
                if (groups.Count > 0)
                {
                    callGroupId = groups[Randomizer.Next(groups.Count)].Id;
                }
                else
                {
                    throw new Exception("Call groups is not configured");
                }
            }

            var login = NameMaker.PersonName(mode, id, callGroupId);
            var password = login;

            User = new UserInfo
                            {
                                Index = id,
                                Login = login,
                                Password = password,
                                TaskChoice = mode,
                                UsedCallGroupId = callGroupId,
                                Sid = BackendTools.CreatePerson(login, password, mode, new[] {parentGroup})
                            };

            State = ActiveState.Stoped; 
        }

        public enum ActiveState
        {
            Stoped = 0,
            PendingActivate = 1,
            Activated = 2,
            PendingStop = 3
        }

        public ActiveState State { get; private set; }

        internal bool OnActivate(TestConfiguration.LoadInterval interval)
        {
            lock (this)
            {
                LoadInterval = interval;

                if (State != ActiveState.Stoped)
                {
                    return false;
                }

                State = ActiveState.PendingActivate;

                Thread = new Thread(ProcessThread);
                Thread.Name = $"Person:{User.Login}";
                Thread.Start();

                Trace.TraceInformation("{0}: Person is activating", User.Login);
                return true;
            }
        }

        internal bool OnDeactivateBegin()
        {
            lock (this)
            {
                if (State != ActiveState.Activated)
                {
                    return false;
                }

                State = ActiveState.PendingStop;

                Trace.TraceInformation("{0}: Person is deactivating", User.Login);

                return true;
            }
        }

        internal void OnDeactivateEnd()
        {
            lock (this)
            {
                if (State != ActiveState.PendingStop)
                {
                    return;
                }

                if (!Thread.Join(TimeSpan.FromMinutes(100)))
                {
                    Thread.Abort();
                    Thread = null;
                }

                Trace.TraceInformation("{0}: Person has deactivated", User.Login);
            }
        }

        internal void ProcessThread()
        {
            using (Logger.Sub(User.Login))
            {
                PerformanceCounters.NumberOfActiveInterviewersPerformanceCounter.Increment();
                try
                {
                    Trace.TraceInformation("Person has activated");

                    Program.InitializeCore();

                    Process();
                }
                catch (Exception ex)
                {
                    Trace.TraceError("Thread failed. Exception detailes: {0}", ex);
                }

                this.Thread = null;
                State = ActiveState.Stoped;

                PerformanceCounters.NumberOfActiveInterviewersPerformanceCounter.Decrement();
            }
        }

        public void Process()
        {
            try
            {
                CreateServicesAndLogin();

                using (var interviewTimer = new InterviewTimingsStopwatch())
                {
                    ProcessState state;

                    StartInterviewIfNeed();

                    State = ActiveState.Activated;

                    while (State == ActiveState.Activated)
                    {
                        KeepAlive();

                        state = WaitNoCallsOrInterviewingState();

                        switch (state.InterviewState)
                        {
                            case InterviewState.INTERVIEWING:
                                {
                                    interviewTimer.OnStartInterview();

                                    var context = new InterviewContext
                                                      {
                                                          MonitoringService = monitoring,
                                                          Duration = TimeSpan.Zero,
                                                          InterviewerWorkflowService = this,
                                                          InterviewTimingsStopwatch = interviewTimer,
                                                          Survey = GlobalSurveyCache.Get(state.InterviewProperties.SurveyId),
                                                          State = state,
                                                          User = User
                                                      };

                                    var scenario = GetInterviewScenario(context);

                                    using (
                                        Logger.Sub(String.Format("IS={0},PID={1},IID={2}", scenario.Name,
                                                                 state.InterviewProperties.ProjectId, state.InterviewProperties.InterviewId)))
                                    {

                                        Logger.Info("Interview ( PID={0}, ID={1}, WT={2}) was started",
                                                    state.InterviewProperties.ProjectId,
                                                    state.InterviewProperties.InterviewId,
                                                    interviewTimer.Elapsed);

                                        //At this state we consider an interview is started.
                                        monitoring.InterviewState = state;
                                        monitoring.SendInterviewStartMessage();

                                        scenario.Execute(context);
                                    }
                                }

                                break;

                            case InterviewState.NO_CALLS:
                                //XXX
                                Thread.Sleep(TimeSpan.FromSeconds(15));

                                StartInterviewIfNeed();
                                break;
                            default:
                                throw new Exception("unexpected interview state");
                        }
                    }

                    _catiServiceManager.SetPendingLogout(true);

                    state = WaitNoCallsOrInterviewingState();

                    if (state.InterviewState == InterviewState.INTERVIEWING)
                    {
                        CompleteInterview(state, interviewTimer, TimeSpan.Zero, "complete");
                    }

                    WaitState(x => x.interviewerLoginState == (int) LoginState.NOT_LOGGED_IN);
                    _catiServiceManager.ConfirmLogout();
                    SelectedProjectId = null;
                }
            }
            catch (Exception e)
            {
                Trace.TraceError("{0}: {1}", User.Login, e);
               
                throw;
            }

            Logger.Info("Person logouted from CATI Console");
        }

        private InterviewScenario GetInterviewScenario(InterviewContext context)
        {
            var weight = Randomizer.Next(context.Survey.Scenario.InterviewScenarioWeight);

            InterviewScenario last = null;
            foreach( var scenario in context.Survey.Scenario.InterviewScenarios )
            {
                last = scenario;
                weight -= scenario.Weight;
                if (weight < 0)
                    return scenario;
            }

            return last;
        }

        public void CompleteInterview(ProcessState state, InterviewTimingsStopwatch interviewTimer, TimeSpan growDuration, string status)
        {
            var timings = interviewTimer.OnStopInterview();

            _catiServiceManager.WrapUp(state.InterviewProperties.InterviewId, true, new CompletedInterviewDetails
            {
                InterviewDuration =  (int)growDuration.TotalSeconds, 
                Status = status,
                Its = status.Any(char.IsDigit) ? status : null
            });
            IncrementQuotasCounters(state);

            SendMonitoringInterviewFinishMessageIfNeed();

            SendContralData(state, growDuration, timings.TotalTime, status);

            Logger.Info("Interview ( PID={0}, ID={1}, TT={2}, IT={3}({4}), WT={5}) was finished.",
                state.InterviewProperties.ProjectId,
                state.InterviewProperties.InterviewId,
                timings.TotalTime,
                timings.InterviewwingTime,
                growDuration,
                timings.WaitingTime);

            PerformanceCounters.RateOfCompletedInterviewsPerSecondPerformanceCounter.Increment();
        }

        private void IncrementQuotasCounters(ProcessState state)
        {
            var cache = GlobalSurveyCache.Get(state.InterviewProperties.SurveyId);
            if (cache.QuotasCache.ShouldBeQuotaCountersUpdated)
            {
                var data = BackendTools.GetInterviewFields(cache.Sid, state.InterviewProperties.InterviewId, cache.QuotasCache.Fields);
                cache.QuotasCache.IncrementCounters(data);
            }
        }

        private ProcessState WaitNoCallsOrInterviewingState()
        {
            return WaitState(
                x =>
                x.InterviewState == InterviewState.NO_CALLS ||
                x.InterviewState == InterviewState.INTERVIEWING);
        }

        private void SendMonitoringInterviewFinishMessageIfNeed()
        {
            monitoring.SendInterviewFinish();
        }

        private void CreateServicesAndLogin()
        {
            string extensionNumber = DialerExtensionProvider.GetExtensionNumber(User.Sid);
            string stationId = DialerExtensionProvider.GetStationId(User.Sid);
                        
            ConsoleAuthorizationService = CreateConsoleAuthorizationService();

            monitoring = new MonitoringService(_catiServiceManager)
            {
                UserId = User.Sid
            };

            var consoleDescriptor = new ConsoleDescription
            {
                ConsoleVersion = GetInterviewerConsoleVersion(),
                OperatingSystemVersion = "7.0"
            };

            var userProperties = _catiServiceManager.Login(stationId, User.Login, User.Password, Program.CompanyId, consoleDescriptor);

            UserPassport.Instance.Properties = userProperties;

            _authenticationData.SetCustomParameters(userProperties.AuthenticationKey, userProperties.EncryptionKey, userProperties.EncryptionIV, string.Empty);

            Logger.Info("Person has logined to CATI console");

            switch (userProperties.UserAssignmentMode)
            {
                case AgentTaskChoiceMode.CampaignAssignment:
                    var surveys = _catiServiceManager.GetSurveys();
                    while (surveys.Count == 0)
                    {
                        Logger.Info("Person with SA\\GC mode doesn't have any opened surveys");
                        Thread.Sleep(TimeSpan.FromSeconds(5));
                        surveys = _catiServiceManager.GetSurveys();
                    }

                    SelectedProjectId = surveys[RotationIndex % surveys.Count].Id;
                    Logger.Info("Person has selected survey '{0}'", SelectedProjectId);
                    break;
            }

            if (userProperties.ConnectedToDialer)
            {
                bool isPredicive;
                switch (userProperties.LoginToDialerState)
                {
                    case LoginState.NOT_LOGGED_IN:

                        _catiServiceManager.LoginToDialer(extensionNumber, SelectedProjectId, out isPredicive);
                        WaitState(
                            x =>
                            x.LoginToDialerState == LoginState.LOGGED_IN ||
                            x.LoginToDialerState == LoginState.NOT_LOGGED_IN);
                        if (isPredicive)
                        {
                            _catiServiceManager.StartInterview(SelectedProjectId, 0);
                        }
                        break;
                    case LoginState.LOGGING_IN:

                        WaitState(
                            x =>
                            x.LoginToDialerState == LoginState.LOGGED_IN ||
                            x.LoginToDialerState == LoginState.NOT_LOGGED_IN);
                        break;

                    case LoginState.LOGGED_IN:
                        break;
                    case LoginState.LOGGING_OUT:

                        WaitState(x => x.LoginToDialerState == LoginState.NOT_LOGGED_IN);
                        _catiServiceManager.LoginToDialer(extensionNumber, SelectedProjectId, out isPredicive);
                        WaitState(
                            x =>
                            x.LoginToDialerState == LoginState.LOGGED_IN ||
                            x.LoginToDialerState == LoginState.NOT_LOGGED_IN);
                        if (isPredicive)
                        {
                            _catiServiceManager.StartInterview(SelectedProjectId, 0);
                        }
                        break;
                    default:
                        throw new Exception(string.Format("{0} is invalid login to dialer state.", userProperties.LoginToDialerState));
                }
            }
        }

        private string GetInterviewerConsoleVersion()
        {
            return _systemSettingRepository.Get(SystemSettingConstants.Setup.InterviewerConsoleVersion, 0);
        }

        private void StartInterviewIfNeed()
        {
            var state = WaitState(
                x =>
                x.InterviewState == InterviewState.SELECTING ||
                x.InterviewState == InterviewState.NO_CALLS ||
                x.InterviewState == InterviewState.INTERVIEWING);

            if (state.InterviewState == InterviewState.INTERVIEWING)
            {
                return;
            }

            switch (User.TaskChoice)
            {
                case AgentTaskChoiceMode.Automatic:
                    _catiServiceManager.StartInterview(null, 0);
                    break;
                case AgentTaskChoiceMode.CampaignAssignment:
                    _catiServiceManager.StartInterview(SelectedProjectId, 0);
                    break;
            }
        }

        private void KeepAlive()
        {
            var result = _catiServiceManager.KeepAlive();
            
            if (result.NewMessage)
            {
                var messages = _catiServiceManager.GetMessages();
                
                foreach (var message in messages)
                {
                    Logger.Info("Person received following message.\r\n" + 
                        "    Body: {0}\r\n" +
                        "    CreateTime: {1}\r\n" + "SupervisorName: {2}",
                        message.Body,
                        message.CreateTime,
                        message.SupervisorName);
                }
            }
        }

        private IConsoleAuthorizationService CreateConsoleAuthorizationService()
        {
            var factory = new ChannelFactory<IConsoleAuthorizationService>("ConsoleAuthorizationServiceEndpoint");

            var listeningUri = new Uri(ServiceLocator.Resolve<ISideBySideManager>().AddSideBySideNameToBackendWCFServiceUrl(factory.Endpoint.Address.ToString()));
            var logicalUri = new Uri("urn://" + listeningUri.Host + listeningUri.PathAndQuery);

            factory.Endpoint.Address = new EndpointAddress(logicalUri);
            factory.Endpoint.Behaviors.Add(new ClientViaBehavior(listeningUri));

            factory.Open();

            return factory.CreateChannel();
        }

        private void SendContralData(ProcessState state, TimeSpan growDuration, TimeSpan totalDuration, string status)
        {
            var history = new InterviewHistoryData
                {
                    appointmentID = 0,
                    grossDuration = (int)totalDuration.TotalSeconds,

                    // TODO:should be growDuration,but we store only this param( in sec ) to our DB
                    interviewerID = User.Sid,
                    interviewID = state.InterviewProperties.InterviewId,
                    netDuration = (int)(totalDuration - growDuration).TotalSeconds,
                    projectID = state.InterviewProperties.SurveyId,
                    respondentPhone = "0123456789",
                    roleID = 2,
                    status = status,
                    time = DateTime.UtcNow,
                    totalDuration = (int)totalDuration.TotalSeconds,
                };

            var control = new InterviewControlData
                {
                    interviewerID = User.Sid, 
                    interviewID = state.InterviewProperties.InterviewId, 
                    lastCallTime = DateTime.UtcNow, 
                    projectID = state.InterviewProperties.SurveyId, 
                    respondentName = "test respondent", 
                    respondentPhone = "0123456789", 
                    roleID = 2, 
                    status = status, 
                    totalDuration = 0
                };

            ManagementServices.SaveInterviewHistoryAndControlData(history, control);
        }

        private ProcessState WaitState(Func<ProcessState, bool> condition)
        {
            TimeSpan timeout = TimeSpan.FromMinutes(this.LoadInterval.ReloginTimeoutOnFrozenState);
            var utcNow = DateTime.UtcNow;
            DateTime deadline = timeout.TotalMilliseconds != 0 ? DateTime.UtcNow + timeout : DateTime.MaxValue;
            ProcessState state = _catiServiceManager.GetState();

            while (DateTime.UtcNow < deadline)
            {
                if (condition(state))
                {
                    return state;
                }

                Thread.Sleep(TimeSpan.FromSeconds(1));

                state = _catiServiceManager.GetState();
            }

            PerformanceCounters.NumberOfReloginsByTimeoutPerformanceCounter.Increment();

            State = ActiveState.PendingStop;

            throw new TimeoutException(
                String.Format(
                    "{0}: Person finish interviewing on frozen state. Current State is : interviewState = {1}, surveyId = {2}, interviewId = {3}, utcnow = {4}, deadline = {5}",
                    User.Login,
                    state.InterviewState,
                    state.InterviewProperties.SurveyId,
                    state.InterviewProperties.InterviewId,
                    utcNow,
                    deadline));
        }

        public class UserInfo
        {
            public int Index { get; set; }

            public string Login { get; set; }

            public string Password { get; set; }

            public int Sid { get; set; }

            public AgentTaskChoiceMode TaskChoice { get; set; }

            public int UsedCallGroupId { get; set; }
        }
    }
}
