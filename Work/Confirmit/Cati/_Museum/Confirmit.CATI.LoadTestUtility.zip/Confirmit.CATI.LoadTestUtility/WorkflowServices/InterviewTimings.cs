﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace Confirmit.CATI.LoadTestUtility.WorkflowServices
{
    public class InterviewTimingsStopwatch : IDisposable
    {
        public class InterviewTimings
        {
            public TimeSpan WaitingTime;
            public TimeSpan InterviewwingTime;
            public TimeSpan TotalTime;
        }

        private readonly Stopwatch _timer;

        private TimeSpan _startInterviewTimespan;
        private TimeSpan _finishInterviewTimespan;
        private bool _isWaitInterview;

        
        public InterviewTimingsStopwatch()
        {
            _timer = Stopwatch.StartNew();
            _isWaitInterview = true;
            PerformanceCounters.NumberOfInterviewersInWaitingStatePerformanceCounter.Increment();
        }

        

        public void OnStartInterview()
        {
            _startInterviewTimespan = _timer.Elapsed;
            PerformanceCounters.AverageOfWaitingTimeOfInterviewDurationPerformanceCounter.IncrementBy(_startInterviewTimespan);
            if (_isWaitInterview)
            {
                _isWaitInterview = false;
                PerformanceCounters.NumberOfInterviewersInWaitingStatePerformanceCounter.Decrement();
                PerformanceCounters.NumberOfInterviewersInInterviewingStatePerformanceCounter.Increment();
            }
        }

        public InterviewTimings OnStopInterview()
        {
            _finishInterviewTimespan = _timer.Elapsed;
            _timer.Restart();

            var interviewingTime = _finishInterviewTimespan - _startInterviewTimespan;

            PerformanceCounters.AverageOfInterviewingTimeOfInterviewDurationPerformanceCounter.IncrementBy(interviewingTime);

            if (!_isWaitInterview)
            {
                _isWaitInterview = true;
                PerformanceCounters.NumberOfInterviewersInWaitingStatePerformanceCounter.Increment();
                PerformanceCounters.NumberOfInterviewersInInterviewingStatePerformanceCounter.Decrement();
            }

            return new InterviewTimings
                {
                    WaitingTime = _startInterviewTimespan,
                    TotalTime = _finishInterviewTimespan,
                    InterviewwingTime = interviewingTime,
                };
        }

        public TimeSpan Elapsed 
        { 
            get
            {
                return this._timer.Elapsed;
            }
        }

        public void Dispose()
        {
            if( _isWaitInterview)
            {
                PerformanceCounters.NumberOfInterviewersInWaitingStatePerformanceCounter.Decrement();
            }
            else
            {
                PerformanceCounters.NumberOfInterviewersInInterviewingStatePerformanceCounter.Decrement();
            }
        }
    }
}
