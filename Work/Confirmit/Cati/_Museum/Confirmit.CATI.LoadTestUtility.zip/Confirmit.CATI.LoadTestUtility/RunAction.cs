﻿namespace Confirmit.CATI.LoadTestUtility
{
    public enum RunAction
    {
        Test,
        Preparation
    }
}