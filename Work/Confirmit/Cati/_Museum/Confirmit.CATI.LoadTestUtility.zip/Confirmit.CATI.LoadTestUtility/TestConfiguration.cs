﻿using System.Collections.Generic;
using System.Xml.Serialization;
using Confirmit.CATI.Core.DAL.Generated.Entity.Table;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Enums;

namespace Confirmit.CATI.LoadTestUtility
{
    [XmlRoot("TestConfiguration")]
    public class TestConfiguration
    {
        public class LoadInterval
        {
            public RandomIntParam TotalAutoInterviewers;

            public RandomIntParam TotalSAInterviewers;

            public RandomIntParam TotalCGInterviewers;

            public int Duration;

            public int ReloginTimeoutOnFrozenState;

            public RandomTimeSpanParam LoginDelay;
        }

        public class InterviewScenario
        {
            public class InterviewScenarioAction
            {
            }
        }

        public class SurveyScenario
        {
            public class SurveyQuota
            {
                public string Name { get; set; }

                public bool Balancing { get; set; }

                public bool UpdateCounter { get; set; }

                public QuotaTargetFunc TargetFunc { get; set; }

                public int TargetArg { get; set; }

                public string[] BalancingFields { get; set; }

                public int PromotionThreshold { get; set; }

                public bool Clustering;

                public int LiveThreshold;
            }

            public class SurveyAction
            {
                public override string ToString()
                {
                    return string.Format("{{ Action: {0}, Param: \"{1}\" }}", this.Action, this.Param);
                }

                public EnumAction Action { get; set; }

                public string Param { get; set; }

                public bool IsAsync { get; set; }

                public InterviewScenario[] InterviewScenarios { get; set; }
            }

            public string Name { get; set; }

            public bool Enable { get; set; }

            public string SchemaPath { get; set; }

            public SurveySchema Schema { get; set; }

            public SurveyQuota[] Quotas { get; set; }

            public SurveyAction[] Actions { get; set; }
        }

        public class DialerScenario
        {
            public string CallsCountPerInterviewer { get; set; }

            public class OutcomeList
            {
                public string CallOutcome { get; set; }

                public string ProcessingTime { get; set; }

                public string DistributionWeight { get; set; }
            }

            public OutcomeList[] OutcomeLists { get; set; }
        }

        public int AdministratorsCount { get; set; }

        public RoleType Role { get; set; }

        public RunAction ExecutionMode { get; set; }

        public SurveyScenario[] SurveyScenarios { get; set; }

        public Dictionary<BvCallGroupEntity, BvCallGroupConditionEntity[]> CallGroups;

        public SurveyScenario[] AllSurveyScenarios { get; set; }

        public LoadInterval[] LoadScenario { get; set; }

        public DialerScenario[] DialerScenarios { get; set; }
    }
}
