﻿using Confirmit.CATI.LoadTestUtility.Survey;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility
{
    internal class TestDataInitializer
    {
        private const string TelephoneNumberTableName = "TestTelephoneNumberTable";

        public static int InitializeSampleBatch(SurveyInfo survey, string path, out int count)
        {
            int batchId = SurveyTools.NewBatchId();

            count = BackendTools.CreateSampleBatch(DatabaseEngines.Survey(survey.ProjectId), survey, batchId, path);

            return batchId;
        }
    }
}
