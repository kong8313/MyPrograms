﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Xml;

using Confirmit.CATI.LoadTestUtility.Enums;

using ConfirmitDialerInterface;

namespace Confirmit.CATI.LoadTestUtility
{
    public class SurveySchemaReader
    {
        public  SurveySchema Load(string path)
        {
            var doc = new XmlDocument();
            try
            {
                doc.Load(path);
            }
            catch (Exception ex)
            {
                throw new Exception(String.Format("Can't load schema '{0}'. Exception:{1}", path, ex));
            }

            var fields = GetFieldsFromSchema(doc);
            return new SurveySchema
                {
                    Project = GetProjectInfoFromSchema(doc),
                    FieldsList = fields.ToList(),
                    Fields = Enumerable.ToDictionary(fields, x => x.Name),
                    Quotas = Enumerable.ToDictionary(GetQuotasFromSchema(doc), x => x.Name)
                };
        }

        private static string GetAttributeValue(XmlNode node, string attributeName, string defaultValue)
        {
            if (node.Attributes != null)
            {
                var attribute = node.Attributes[attributeName];
                return attribute != null ? attribute.Value : defaultValue;
            }

            return defaultValue;
        }

        private static SurveySchema.ProjectInfo GetProjectInfoFromSchema(XmlDocument doc)
        {
            var node = doc.SelectSingleNode("Project/ProjectInfo");

            return new SurveySchema.ProjectInfo
                {
                    DialingMode = (DialingMode)Enum.Parse(typeof(DialingMode), GetAttributeValue(node, "DialMode", "Manual")),
                    EnableInterviewRecording = Boolean.Parse(GetAttributeValue(node, "EnableInterviewRecording", "false")),
                    EnableOpenedReviewRecording = Boolean.Parse(GetAttributeValue(node, "EnableOpenedReviewRecording", "false")),
                };
        }

        private static IEnumerable<SurveySchema.QuotaInfo> GetQuotasFromSchema(XmlDocument doc)
        {
            return
                doc.SelectNodes("//Quotas/Quota").Cast<XmlNode>().Select(node =>
                                                                         new SurveySchema.QuotaInfo
                                                                             {
                                                                                 Name = node.SelectSingleNode("./Name").InnerText,
                                                                                 IsFcd = Boolean.Parse(GetAttributeValue(node, "IsCatiQuota", "false")),
                                                                                 IsCati = Boolean.Parse(GetAttributeValue(node, "IsShownInCatiSupervisor", "false")),
                                                                                 IsOptimistic = Boolean.Parse(GetAttributeValue(node, "IsOptimisticQuota", "false")),
                                                                                 Fields = node.SelectNodes("./Forms/Form").Cast<XmlNode>().Select(answer => answer.SelectSingleNode("./Name").InnerText).ToArray()
                                                                             });
        }

        private static IEnumerable<SurveySchema.FieldInfo> GetFieldsFromSchema(XmlDocument doc)
        {
            return
                doc.SelectNodes("//Single").Cast<XmlNode>().Select(node =>
                                                                   new SurveySchema.FieldInfo
                                                                       {
                                                                           Name = node.SelectSingleNode("./Name").InnerText,
                                                                           Type = (FieldType)Enum.Parse(typeof(FieldType), GetAttributeValue(node, "VariableType", "Normal")),
                                                                           Precodes = node.SelectNodes("./SingleAnswers/Answer").Cast<XmlNode>().Select(answer => answer.Attributes["Precode"].Value).ToArray()
                                                                       });
        }
    }
}
