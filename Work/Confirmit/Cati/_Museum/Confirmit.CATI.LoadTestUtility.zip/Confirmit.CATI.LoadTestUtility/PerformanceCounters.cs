﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using Confirmit.CATI.Common.PerformanceCounters;
using PerformanceCounter = Confirmit.CATI.Common.PerformanceCounters.PerformanceCounter;

namespace Confirmit.CATI.LoadTestUtility
{
    static class PerformanceCounters
    {
        public static readonly PerformanceCounter NumberOfReloginsByTimeoutPerformanceCounter = new PerformanceCounter("NumberOfReloginsByTimeoutCounter", "", PerformanceCounterType.NumberOfItems32);
        public static readonly PerformanceCounter NumberOfActiveInterviewersPerformanceCounter = new PerformanceCounter("NumberOfActiveInterviewersCounter", "", PerformanceCounterType.NumberOfItems32);

        public static readonly PerformanceCounter NumberOfInterviewersInWaitingStatePerformanceCounter = new PerformanceCounter("NumberOfInterviewersInWaitingStateCounter", "", PerformanceCounterType.NumberOfItems32);
        public static readonly PerformanceCounter NumberOfInterviewersInInterviewingStatePerformanceCounter = new PerformanceCounter("NumberOfInterviewersInInterviewingStateCounter", "", PerformanceCounterType.NumberOfItems32);


        public static readonly PerformanceCounter AverageOfWaitingTimeOfInterviewDurationPerformanceCounter = new PerformanceCounter("AverageOfWaitingTimeOfInterviewDurationCounter(sec)", "", PerformanceCounterType.AverageTimer32);
        public static readonly PerformanceCounter AverageOfInterviewingTimeOfInterviewDurationPerformanceCounter = new PerformanceCounter("AverageOfInterviewingTimeOfInterviewDurationCounter(sec)", "", PerformanceCounterType.AverageTimer32);

        public static readonly PerformanceCounter RateOfCompletedInterviewsPerSecondPerformanceCounter = new PerformanceCounter("RateOfCompletedInterviewsPerSecondCounter", "", PerformanceCounterType.RateOfCountsPerSecond32);
        public static readonly PerformanceCounter RateOfAppointmentPerSecondPerformanceCounter = new PerformanceCounter("RateOfAppointmentPerSecondCounter", "", PerformanceCounterType.RateOfCountsPerSecond32);

        public static readonly PerformanceCounter RateOfActiveQuestionUpdatePerSecondPerformanceCounter = new PerformanceCounter("RateOfActiveQuestionUpdatePerSecondCounter", "", PerformanceCounterType.RateOfCountsPerSecond32);
        public static readonly PerformanceCounter AverageOfActiveQuestionUpdateDurationPerformanceCounter = new PerformanceCounter("AverageOfActiveQuestionUpdateDurationCounter(sec)", "", PerformanceCounterType.AverageTimer32);

        public static readonly PerformanceCounter RateOfGetStateCountsPerSecondPerformanceCounter = new PerformanceCounter("RateOfGetStateCountsPerSecondCounter", "", PerformanceCounterType.RateOfCountsPerSecond32);
        public static readonly PerformanceCounter AverageOfGetStateDurationPerformanceCounter = new PerformanceCounter("AverageOfGetStateDurationCounter(sec)", "", PerformanceCounterType.AverageTimer32);

        public static readonly PerformanceCounter RateOfWrapUpCountsPerSecondPerformanceCounter = new PerformanceCounter("RateOfWrapUpCountsPerSecondCounter", "", PerformanceCounterType.RateOfCountsPerSecond32);
        public static readonly PerformanceCounter AverageOfWrapUpDurationPerformanceCounter = new PerformanceCounter("AverageOfWrapUpDurationCounter(sec)", "", PerformanceCounterType.AverageTimer32);

        private static PerformanceCounter[] _mPerformanceCounters = new[]
                                                  {
                                                      NumberOfReloginsByTimeoutPerformanceCounter,
                                                      NumberOfActiveInterviewersPerformanceCounter,

                                                      NumberOfInterviewersInWaitingStatePerformanceCounter,
                                                      NumberOfInterviewersInInterviewingStatePerformanceCounter,
                                                      
                                                      AverageOfWaitingTimeOfInterviewDurationPerformanceCounter,
                                                      AverageOfInterviewingTimeOfInterviewDurationPerformanceCounter,
                                                      
                                                      RateOfCompletedInterviewsPerSecondPerformanceCounter,
                                                      RateOfAppointmentPerSecondPerformanceCounter,

                                                      RateOfActiveQuestionUpdatePerSecondPerformanceCounter,
                                                      AverageOfActiveQuestionUpdateDurationPerformanceCounter,
                                                      
                                                      RateOfGetStateCountsPerSecondPerformanceCounter,
                                                      AverageOfGetStateDurationPerformanceCounter,
                                                      
                                                      RateOfWrapUpCountsPerSecondPerformanceCounter,
                                                      AverageOfWrapUpDurationPerformanceCounter
                                                  };

        public static void Initialize()
        {
            new PerformanceCategoryCreator().Initialize(
                "Confirmit.CATI.LoadTestUtility",
                "Load test utility performance counters",
                _mPerformanceCounters,
                PerformanceCounterCategoryType.SingleInstance,
                true);
        }
    }
}
