﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Common.Random;
using Confirmit.CATI.Console.Classes.Monitoring;
using Confirmit.CATI.Console.Services.CatiService;
using Confirmit.CATI.Console.Services.MonitoringService;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Confirmit.CATI.Monitoring.Common.Serialization;
using Confirmit.CATI.Monitoring.Common.StateData;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    public class MonitoringService
    {
        private readonly ICatiServiceManager _catiServiceManager;
        
        public MonitoringService(ICatiServiceManager catiServiceManager)
        {
            _catiServiceManager = catiServiceManager;

            ConinueSendingAnswers = true;
        }

        private int _deferredRecordId;
        private readonly List<StateEventInfo> _events = new List<StateEventInfo>();

        #region Simulation

        private const int MaxKeyboardInputValue = 1000;
        private const int MinPageContentSize = 1000;
        private const int MaxPageContentSize = 10000;

        private const string ValidChars =
            @"QWERTYUIOP[]ASDFGHJKL;'\ZXCVBNM,./qwertyuiop[]asdfghjkl;'\zxcvbnm,./{}:""|<>?;`1234567890-=~!@#$%^&*()_+";

        private string CreateRandomString(int size)
        {
            if (size <= 0) return "";
            var ca = new Char[size];

            var l = ValidChars.Length-1;
            for(int i=0; i<size; i++)
            {
                int j = Randomizer.Next(0, l);
                ca[i] = ValidChars[j];
            }
            return (ca.ToString());
        }

        private string GetRandomStringWithRandomSize(int maxSize)
        {
            return GetRandomStringWithRandomSize(1, maxSize);            
        }

        public string GetRandomStringWithRandomSize(int minSize, int maxSize)
        {
            int c = Randomizer.Next(minSize, maxSize);
            string s = CreateRandomString(c);
            return s;
        }

        private string GetViewKeyboardInputValue()
        {
            return GetRandomStringWithRandomSize(MaxKeyboardInputValue);
        }

        private string GetPageContent()
        {
            return GetRandomStringWithRandomSize(MinPageContentSize, MaxPageContentSize);
        }


        #endregion

        public ProcessState InterviewState { get; set; }
        public int UserId { get; set; }

        public bool ConinueSendingAnswers { get; set; }

        private void SendEventsToServer()
        {
            try
            {
                var packetter = new StateEventInfoPacketter();
                packetter.AddToPacket(_events);
                var monitoringIdentity = new MonitoringIdentity
                {
                    MonitoringSessionId = 0,
                    DeferredIdentity = new DeferredIdentity
                    {
                        DeferredRecordId = _deferredRecordId,
                        InterviewId = InterviewState.InterviewProperties.InterviewId,
                        SurveyId = InterviewState.InterviewProperties.ProjectId
                    }
                };
                var packetBytes = packetter.GetPacketBytes();
                _catiServiceManager.SaveLiveMonitoringEvents(
                    Program.CompanyId,
                    UserId,
                    monitoringIdentity,
                    packetBytes);
                _catiServiceManager.SaveDeferredMonitoringEvents(
                    Program.CompanyId,
                    UserId,
                    monitoringIdentity,
                    packetBytes,
                    _events.Any(x => x.MessageType.IsFinishedMessage()), //eventInfo.MessageType.IsFinishedMessage(),
                    _events.Min(x => x.TimeStamp)  //eventInfo.TimeStamp, 
                );

                Logger.Info("{0} events have been sent. The packet size is {1}.", _events.Count, packetter.GetPacketSize());
            }
            finally 
            {                
                _events.Clear();
            }
        }

        private void SendEvent(BaseStateData ev, MonitoringMessageTypes messageType)
        {
            var eventInfo = new StateEventInfo
            {
                MessageType = messageType,
                State = ev==null?null:SerializationManager.Serialize(messageType, ev),
                TimeStamp = DateTime.UtcNow
            };

            _events.Add(eventInfo);
        }
        
        private static ConsoleState GetConsoleState(ProcessState state)
        {
            switch (state.InterviewState)
            {
                case Common.InterviewState.INTERVIEWING:
                    return ConsoleState.Interviewing;

                case Common.InterviewState.OPENEND_REVIEW:
                    return ConsoleState.Reviewing;

                default:
                    return ConsoleState.Selecting;
            }
        }

        public void SendInterviewingInitial(int deferredRecordId)
        {
            _deferredRecordId = deferredRecordId;

            if (!InterviewState.InterviewProperties.IsSurveyRecorded)
            {
                return;
            }

            var ev = new InterviewingInitialStateData
            {
                KeyboardInputValue = GetViewKeyboardInputValue(),
                PageContent = GetPageContent(),
                ActiveQuestionIndex = Randomizer.Next(0, 1000),
                InterviewId = InterviewState.InterviewProperties.InterviewId,
                SurveyId = InterviewState.InterviewProperties.SurveyId,
                SurveyName = InterviewState.InterviewProperties.SurveyName,
                ConsoleState = GetConsoleState(InterviewState)
            };

            SendEvent(ev, MonitoringMessageTypes.InterviewInitialMessage);
        }


        public void SendInterviewStartMessage()
        {
            if (!InterviewState.InterviewProperties.IsSurveyRecorded)
            {
                return;
            }

            var ev = new InterviewStartStateData
            {
                InterviewID = InterviewState.InterviewProperties.InterviewId
            };

            SendEvent(ev, MonitoringMessageTypes.InterviewStartMessage);
        }

        public void SendQuestionSelected(int questionIndex)
        {
            if (!InterviewState.InterviewProperties.IsSurveyRecorded)
            {
                return;
            }

            var ev = new QuestionSelectedStateData
            {
                QuestionIndex = questionIndex,
                SubQuestionIndex = -1
            };

            SendEvent(ev, MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage);

        }


        public void SendAnswerEntered(string element, string value)
        {
            if (!InterviewState.InterviewProperties.IsSurveyRecorded)
            {
                return;
            }

            var ev = new AnswerEnteredStateData
            {
                ControlName = GetType().Name,
                ElementId = element,
                ElementValue = value
            };

            SendEvent(ev, MonitoringMessageTypes.InterviewPageBrowserAnswerValueChangedMessage);
        }

        public void SendDocumentCompleted()
        {
            if (!InterviewState.InterviewProperties.IsSurveyRecorded)
            {
                return;
            }

            var ev = new DocumentCompletedStateData
            {
                PageContent = GetPageContent()
            };

            SendEvent(ev, MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage);
        }

        public void StartAnswering()
        {            

        }

        public void SendInterviewFinish()
        {
            if (!InterviewState.InterviewProperties.IsSurveyRecorded)
            {
                return;
            }

            SendEvent(null, MonitoringMessageTypes.InterviewFinishMessage);
            SendEventsToServer();
        }

    }
}
