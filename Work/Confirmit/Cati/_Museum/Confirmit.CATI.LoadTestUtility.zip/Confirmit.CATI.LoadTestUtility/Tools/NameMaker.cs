﻿using System;

using Confirmit.CATI.Common.SideBySide;
using Confirmit.CATI.Common.ServiceLocation;

using ConfirmitDialerInterface;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    internal class NameMaker
    {
        public static string UniquePrefix
        {
            get
            {
                return Environment.MachineName;
            }
        }

        public static string PersonModePrefix(AgentTaskChoiceMode mode)
        {
            switch (mode)
            { 
                case AgentTaskChoiceMode.Automatic:
                    return "A";
                case AgentTaskChoiceMode.Choice:
                    return "C";
                case AgentTaskChoiceMode.Manual:
                    return "M";
                case AgentTaskChoiceMode.CampaignAssignment:
                    return "S";
                default:
                    return "U";
            }
        }

        public static string PersonGroupName(AgentTaskChoiceMode mode, int index, bool useCallGroup)
        {
            return String.Format(
                "{0} {1} {2}",
                PersonModePrefix(mode),
                useCallGroup ? "G" : "",
                index);
        }

        public static string PersonName(AgentTaskChoiceMode mode, int index, int? callDeliveryGroupId)
        {
            return String.Format(
                "{0} {1} {2} {3}",
                UniquePrefix,
                PersonModePrefix(mode),
                index,
                callDeliveryGroupId != null ? String.Format("(CDG: {0}", callDeliveryGroupId) : "");
        }        

        public static string SurveyName(string projectId, string scenarioName)
        {
            return String.Format(
                "{0} {1}",
                projectId,
                scenarioName);
        }

        internal static string ProjectId(int projectId)
        {
            return "p" + projectId.ToString("D8");
        }

        internal static string QuestionName(int questionNumber)
        {
            return "q" + questionNumber;
        }

        internal static string CfDatabaseName(string projectId)
        {
            return "survey_" + projectId;
        }

        internal static string QuotaTableName( int quotaId)
        {
            return String.Format("quota_{0}", quotaId);
        }
        
        internal static string ReplicatedDataName(int syrveySid)
        {
            return String.Format("BvReplicatedData_{0}", syrveySid);
        }

        internal static string ServiceName( int companyId )
        {
            string branchName = ServiceLocator.Resolve<ISideBySideManager>().SideBySideName; 
            return String.Format("Confirmit.CATI.Backend.{0}${1}", branchName, companyId);
        }

        public static string DatabaseName(int companyId)
        {
            return String.Format("ConfirmitCATIV15_{0}", companyId);
        }
    }
}
