using System;
using System.Collections.Generic;
using System.Threading;

namespace Confirmit.CATI.LoadTestUtility.Survey
{
    internal class SyncObject
    {
        private string Name;

        private TimeSpan Duration;

        private int MaxWaiters;

        private static Dictionary<string, int> Waiters = new Dictionary<string, int>();

        public SyncObject(string name, TimeSpan duration, int maxWaiters)
        {
            Name = name;
            Duration = duration;
            MaxWaiters = maxWaiters;
        }

        public bool Wait()
        {
            bool isOwner;
            using( var syncEvent = new EventWaitHandle(false, EventResetMode.ManualReset, Name, out isOwner) )
            {
                int countWaiters = IncrementWaiters();

                // week up other threads, if max count of waiters is achieved
                if (countWaiters >= MaxWaiters)
                {
                    syncEvent.Set();
                }

                //wait event. If event was created in current thread, then we wait only duration time
                if (isOwner)
                {
                    if( !syncEvent.WaitOne(Duration) )
                    {
                        syncEvent.Set();
                    }

                }
                else
                {
                    syncEvent.WaitOne();
                }

                DecrementWaiters();
            }
            return isOwner;
        }

        private void DecrementWaiters()
        {
            lock (Waiters)
            {
                Waiters[this.Name]--;
            }
        }

        private int IncrementWaiters()
        {
            int count = 0;
            lock (Waiters)
            {
                if (Waiters.TryGetValue(Name, out count))
                {
                    Waiters[Name] = ++count;
                }
                else
                {
                    Waiters.Add(Name, ++count);
                }
            }
            return count;
        }
    }
}