﻿using System;
using System.Linq;
using Confirmit.CATI.Common.Random;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    static class TimeoutRandomizer
    {
        /// <summary>
        /// Generate random timeouts. They sum should be equal "duration" value
        /// </summary>
        /// <param name="duration">Sum duration of sleep timeouts</param>
        /// <param name="timeoutsCount">Count of timeouts</param>
        /// <returns></returns>
        public static TimeSpan[] Generate(TimeSpan duration, int timeoutsCount)
        {
            double[] sleepTimeOuts = Enumerable.Range(1, timeoutsCount).Select(x => Randomizer.NextDouble()).ToArray();
            var sum = sleepTimeOuts.Sum();

            if (sum == 0)
            {
                return sleepTimeOuts.Select(x => TimeSpan.FromMilliseconds(duration.TotalMilliseconds/timeoutsCount)).ToArray();
            }

            double factor = duration.TotalMilliseconds/sum;

            return sleepTimeOuts.Select(x => TimeSpan.FromMilliseconds(x*factor)).ToArray();
        }

    }
}
