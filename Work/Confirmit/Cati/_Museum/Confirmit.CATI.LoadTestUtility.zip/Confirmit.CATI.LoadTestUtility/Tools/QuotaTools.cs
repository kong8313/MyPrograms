using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Confirmit.CATI.Core.AuthoringService;
using Confirmit.CATI.Core.DAL.Framework;
using Confirmit.CATI.Core.Services.Interfaces;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Quota;
using Confirmit.CATI.LoadTestUtility.Scenarios;
using Confirmit.CATI.LoadTestUtility.Survey;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.Supervisor.Core.Confirmit;

static internal class QuotaTools
{
    internal static QuotaInfo[] GetQuotaInfo(string projectId, int surveySid, SurveyScenario scenario)
    {
        var query = "SELECT * FROM quotas WHERE iscati <> 0";

        return SelectQuery(query, projectId, reader =>
                {
                    var quotaId = (int)reader["quotaid"];
                    var quotaName = (string)reader["quotaName"];
                    var tableName = (string)reader["tableName"];

                    var fields = GetQuotaFields(projectId, quotaId).ToArray();
                    var cells = GetQuotaCells(projectId, tableName, quotaId, fields).ToArray();
                    
                    var config = scenario.Quotas.FirstOrDefault(x => x.Name == quotaName);
                    if( config == null )
                    {
                        config = new SurveyScenario.QuotaConfig
                            { Name = quotaName, BalancingFields = new string[]{}, TargetFunc = QuotaTargetFunc.TargetArg };
                    }
                    
                    return new QuotaInfo 
                    { 
                        QuotaId = quotaId, 
                        Fields = fields, 
                        Cells = cells, 
                        CellsByKey = cells.ToDictionary(x => CellStateInfo.CreateKey(x.Values)),
                        Config = config
                    };
                }).ToArray();
    }

    private static IEnumerable<CellStateInfo> GetQuotaCells(string projectId, string tableName, int quotaId, string[] fields)
    {
        var query = $"SELECT * FROM {tableName}";
        return SelectQuery(query, projectId, reader =>
                {
                    var values = fields.Select(field => (string)reader[field]);
                    return new CellStateInfo(quotaId, (int)reader["quotaId"], values);
                });
    }

    private static IEnumerable<string> GetQuotaFields(string projectId, int quotaId)
    {
        var query = $"SELECT * FROM quota_field WHERE quotaid = {quotaId}";

        return SelectQuery(query, projectId, reader => (string)reader["fieldname"]);
    }

    private static IEnumerable<T> SelectQuery<T>(string query, string projectId, Func<IDataRecord, T> selector)
    {
        using (var reader = DatabaseEngines.Survey(projectId).ExecuteReader(query, CommandType.Text))
        {
            while (reader.Read())
            {
                yield return selector(reader);
            }
        }
    }

    internal static void UpdateQuotaLimitsInCf(SurveyInfo survey, QuotaInfo quota)
    {
        QuotaList quotaList = QuotaManager.GetQuotaList(survey.ProjectId, quota.Config.Name);
        foreach (var cell in quota.Cells)
        {
            var row = quotaList.QuotaRows.SingleOrDefault(x => x.QuotaRowId == cell.CellId);
            if (row != null)
            {
                //row.Counter
                row.Target = cell.Limit;
            }
        }
        QuotaManager.UpdateQuotaList(survey.ProjectId, quota.Config.Name, quotaList);

        //QuotaManager.SynchronizeQuota(survey.ProjectId, quota.Config.Name);
    }

    internal static void UpdateQuotaCountersInDb(string projectId, QuotaInfo quota)
    {
        //create data table
        var table = new DataTable();
        var columns = quota.Fields.Select(x => new DataColumn(x, typeof(string))).ToArray();
        table.Columns.AddRange(columns);
        table.Columns.Add(new DataColumn("Counter", typeof(int)));
        table.Columns.Add(new DataColumn("Limit", typeof(int)));
        //create rows
        foreach (var cell in quota.Cells)
        {
            var counters = new object[] { cell.Counter, cell.State == QuotaCellState.PessimisticallyOpened ? cell.Limit : cell.Counter };
            var recordData = cell.Values.Concat(counters).ToArray();
            table.Rows.Add(recordData);
        }

        var databaseEngine = DatabaseEngines.Survey(projectId);
        using (var connectionScope = new ConnectionScope(databaseEngine.ConnectionString))
        {
            BackendTools.CreateTableInDb(databaseEngine, table, "#temp");

            var whereClause = BackendTools.JoinString(" AND ", "[quota].[{0}] = [#temp].[{0}]", quota.Fields);

            var query = $@"
                UPDATE [quota]
                SET [quota].Counter = #temp.Counter,
                    [quota].Limit = #temp.Limit
                FROM [{NameMaker.QuotaTableName(quota.QuotaId)}] as [quota], #temp
                WHERE {whereClause}";

            databaseEngine.ExecuteNonQuery(query, CommandType.Text);
        }
    }

    public static void RecalculateTargets(QuotaInfo quota)
    {
        switch( quota.Config.TargetFunc )
        {
            case QuotaTargetFunc.TargetArg:
                foreach (var cell in quota.Cells)
                {
                    cell.Limit = quota.Config.TargetArg;
                }
                break;
            case QuotaTargetFunc.MaxCounterPlusTargetArg:
                var max = quota.Cells.Max(x => x.Counter);
                foreach (var cell in quota.Cells)
                {
                    cell.Limit = max + quota.Config.TargetArg;
                }
                break;
            case QuotaTargetFunc.CounterPlusTargetArg:
                foreach (var cell in quota.Cells)
                {
                    cell.Limit = cell.Counter + quota.Config.TargetArg;
                }
                break;

        }
    }
}