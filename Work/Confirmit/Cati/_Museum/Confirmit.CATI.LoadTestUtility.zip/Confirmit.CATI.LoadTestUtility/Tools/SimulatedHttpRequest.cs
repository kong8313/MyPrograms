﻿using System;
using System.IO;
using System.Web;
using System.Web.Hosting;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    /// <summary>
    /// Used to simulate an HttpRequest.
    /// </summary>
    public class SimulatedHttpRequest : SimpleWorkerRequest
    {
        private readonly string host;

        public SimulatedHttpRequest(
            string appVirtualDir, string appPhysicalDir, string page, string query, TextWriter output, string host)
            : base(appVirtualDir, appPhysicalDir, page, query, output)
        {
            if (string.IsNullOrEmpty(host))
            {
                throw new ArgumentNullException("host", @"Host cannot be null nor empty.");
            }

            this.host = host;
        }

        public static void SetHttpContextWithSimulatedRequest(string host, string application)
        {
            string appVirtualDir = "/";
            string appPhysicalDir = @"c:\projects\SubtextSystem\Subtext.Web\";
            string page = application.Replace("/", string.Empty) + "/default.aspx";
            string query = string.Empty;
            TextWriter output = null;

            var workerRequest = new SimulatedHttpRequest(
                appVirtualDir, appPhysicalDir, page, query, output, host);
            HttpContext.Current = new HttpContext(workerRequest);
        }

        public override string GetServerName()
        {
            return this.host;
        }

        public override string MapPath(string virtualPath)
        {
            return Path.Combine(this.GetAppPath(), virtualPath);
        }
    }
}