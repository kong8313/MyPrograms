﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    public class ArrayTools
    {
        public static IEnumerable<T> EnumerateCollectionInTime<T>(IList<T> collection, TimeSpan duration)
        {
            TimeSpan[] sleepTimeouts = TimeoutRandomizer.Generate(duration, collection.Count);
            for (int i = 0; i < collection.Count; i++)
            {
                Thread.Sleep(sleepTimeouts[i]);
                yield return collection[i];
            }
        }

    }
}
