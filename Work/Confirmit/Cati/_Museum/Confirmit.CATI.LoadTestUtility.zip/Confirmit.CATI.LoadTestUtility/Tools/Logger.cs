﻿using Confirmit.CATI.Common;
using Confirmit.CATI.LoadTestUtility.Tools.Listeners;
using System;
using System.Diagnostics;
using System.Linq;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    public class Logger : ILogger, IDisposable
    {
        private const string Separator = ": ";
        private string ParentPrefix { get; set; }
        [ThreadStatic]
        private static string _prefix = "";
        [ThreadStatic]
        public static string NewLine = Environment.NewLine + new String(' ', _prefix.Length + Separator.Length);

        static Logger()
        {
            SetupPrefix("");
        }

        public Logger(string prefix)
        {
            ParentPrefix = _prefix;
            SetupPrefix(prefix);
        }

        private static void SetupPrefix(string prefix)
        {
            _prefix = prefix;
            NewLine = Environment.NewLine + new String(' ', _prefix.Length + Separator.Length);
        }

        public static Logger Sub(string subPrefix)
        {
            return new Logger(_prefix + "\\" + subPrefix);
        }

        public static void Info(string format, params object[] args)
        {
            Trace.TraceInformation(Format(format, args));
            Flush();
        }

        public static void InfoRaw(string format)
        {
            Trace.TraceInformation(_prefix + format);
            Flush();
        }

        public static void Warn(string format, params object[] args)
        {
            Trace.TraceWarning(Format(format, args));
            Flush();
        }

        public static void Error(string format, params object[] args)
        {
            Trace.TraceError(Format(format, args));
            Flush();
        }

        public static Exception Exception(string format, params object[] args)
        {
            return new Exception(Format(format, args));
        }

        public static void Flush()
        {
            Trace.Flush();
        }

        private static string Format(string format, params object[] args)
        {
            return FormatRaw(string.Format(format, args));
        }

        private static string FormatRaw(string format)
        {
            return _prefix + Separator + format;
        }

        public void Dispose()
        {
            if (ParentPrefix != null)
            {
                SetupPrefix(ParentPrefix);
                ParentPrefix = null;
            }
        }

        public static void InitWsListener(int companyId)
        {
            if( !AppConfiguration.EnableWsLogging )
                return;

            var listener = Trace.Listeners.OfType<WsReportingTraceListener>().FirstOrDefault();

            if (listener == null)
            {
                listener = new WsReportingTraceListener(companyId, new Logger(""))
                               {
                                   Filter = new EventTypeFilter(SourceLevels.Error)
                               };

                Trace.Listeners.Add(listener);
            }
        }

        void ILogger.Log(string text, TraceEventType severity)
        {
            switch (severity)
            {
                case TraceEventType.Critical:
                case TraceEventType.Error:
                    Error(text);
                    break;
                case TraceEventType.Warning:
                    Warn(text);
                    break;
                default:
                    Info(text);
                    break;
            }
        }

        public void Log(Exception ex)
        {
            Error(ex.ToString());
        }

        public static void WriteToAllButWsTraceListener(string message)
        {
            foreach (TraceListener listener in Trace.Listeners)
            {
                if (listener is WsReportingTraceListener || 
                    listener is JsonTextWriterTraceListener)
                    continue;

                listener.WriteLine(message);
            }
        }
    }
}
