﻿using System;
using System.Diagnostics;
using System.IO;

namespace Confirmit.CATI.LoadTestUtility.Tools.Listeners
{
    public class JsonWriterTraceListener : JsonTextWriterTraceListener
    {
        private TextWriterTraceListener _workingListener;

        private void InitializeIfNeeded()
        {
            if (_workingListener != null)
                return;

            var filepath = base.Attributes["FileName"] as string;
            filepath = filepath.Replace("%datetime%", GetDateTimeFormattedForFileName());

            CreateDirectoryIfNeeded(filepath);

            _workingListener = new TextWriterTraceListener(filepath);
        }

        private void CreateDirectoryIfNeeded(string fullFileName)
        {
            var directoryName = Path.GetDirectoryName(fullFileName);

            if (!Directory.Exists(directoryName))
            {
                Directory.CreateDirectory(directoryName);
            }
        }

        private string GetDateTimeFormattedForFileName()
        {
            return string.Format("{0:yyyyMMdd}T{0:HHmmss.fffzzz}", DateTime.Now).Replace(":", string.Empty);
        }

        protected override string[] GetSupportedAttributes()
        {
            return new[] { "FileName"};
        }

        public override void Write(string message)
        {
            InitializeIfNeeded();

            _workingListener.Write(message);
        }

        public override void WriteLine(string message)
        {
            InitializeIfNeeded();
            _workingListener.WriteLine(message);
        }
        public override void Close()
        {
            _workingListener.Close();
        }
        public override void Flush()
        {
            _workingListener.Flush();
        }
    }
}
