﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using Confirmit.CATI.Common;
using Confirmit.CATI.Common.Contracts.ErrorReportingService;
using Confirmit.CATI.Common.WcfTools;
using System.Linq;

namespace Confirmit.CATI.LoadTestUtility.Tools.Listeners
{
    public class WsReportingTraceListener : TraceListener
    {
        private readonly int _companyId;
        private const int MaxRetryCount = 3;        
        private const int ThreadSleepTimeout = 1000;
        private const int MaxMessagesCountToSend = 100;

        private readonly Thread _thread;

        private readonly ConcurrentQueue<ErrorMessage> _errorsQueue = new ConcurrentQueue<ErrorMessage>();
        
        private readonly ChannelFactoryWrapper<IErrorReportingService> _channelFactoryWrapper;
        private readonly ErrorReportingServiceChannelFactoryWrapperConfiguration _errorServiceConfiguration;        
                                      
        public WsReportingTraceListener(int companyId, ILogger logger)
        {
            _companyId = companyId;

            _errorServiceConfiguration = new ErrorReportingServiceChannelFactoryWrapperConfiguration();
            _channelFactoryWrapper = new ChannelFactoryWrapper<IErrorReportingService>(_errorServiceConfiguration, logger);

            _thread = new Thread(ThreadProc)
            {
                IsBackground = true
            };

            _thread.Start();
        }     
           
        public void Release()
        {
            _channelFactoryWrapper.Release();
        }

        public override void TraceEvent(TraceEventCache eventCache, string source, TraceEventType eventType, int id, string message)
        {         
            if ((Filter == null) || Filter.ShouldTrace(eventCache, source, eventType, id, message, null, null, null))
            {
                EnqueueMessage(message);
            }
        }

        public override void WriteLine(string o)
        {
            /* Do nothing */
        }

        public override void Write(string o)
        {
            /* Do nothing */
        }     

        private void EnqueueMessage(string message)
        {                        
            var localTime = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss.fff");

            message += Environment.NewLine + "----------" + Environment.NewLine;
            message += String.Format("Local time: {0}\r\nUUID: {1}", localTime, Guid.NewGuid());            

            _errorsQueue.Enqueue(new ErrorMessage(_companyId, message));            
        }

        private void ThreadProc(object parameter)
        {
            do
            {
                try
                {
                    SendErrorsToErrorReportingService();
                }
                catch (Exception ex)
                {
                    Logger.WriteToAllButWsTraceListener(string.Format("Error during error sending thread execution: {0}", ex));
                }

                Thread.Sleep(ThreadSleepTimeout);
            }
            while (true);
        }

        private void SendErrorsToErrorReportingService()
        {       
            bool success = false;

            int retryCount = 0;

            do
            {
                try
                {
                    var messages = GetAvailableMessages();

                    if (messages.Any())
                    {
                        if (retryCount > 0)
                        {
                            messages = UpdateMessageWithRetryInformation(messages, retryCount);
                        }
                        _channelFactoryWrapper.Execute(x => x.SendLoadUtilityErrorMessages(messages));
                    }
                    success = true;
                }
                catch (Exception ex)
                {
                    Logger.WriteToAllButWsTraceListener(String.Format("Exception thrown while loggin error with errors reporting service:\r\nException:\r\n{0}", ex));

                    retryCount++;
                    Thread.Sleep(500);
                }
            }
            while (!success && retryCount < MaxRetryCount);
        }

        private IEnumerable<ErrorMessage> UpdateMessageWithRetryInformation(IEnumerable<ErrorMessage> errorMessages, int retryCount)
        {
            return (from message in errorMessages
                    let messageText = string.Format("{0}\r\nRetry Count: {1}\r\n", message.Message, retryCount)
                    select
                    new ErrorMessage(message.CompanyId, messageText));
        }


        private IEnumerable<ErrorMessage> GetAvailableMessages()
        {
            var result = new List<ErrorMessage>();

            for (var i = 0; i < MaxMessagesCountToSend; i++)
            {
                ErrorMessage item;                

                if (_errorsQueue.TryDequeue(out item))
                {
                    result.Add(item);
                }
            }

            return result;
        }
    }
}
