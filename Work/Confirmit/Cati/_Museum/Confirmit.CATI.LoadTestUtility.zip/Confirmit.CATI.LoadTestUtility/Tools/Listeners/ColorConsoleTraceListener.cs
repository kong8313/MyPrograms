﻿using System;
using System.Diagnostics;

namespace Confirmit.CATI.LoadTestUtility.Tools.Listeners
{
    public class ColorConsoleTraceListener : TraceListener
    {
        private static readonly string Paragrath = "\n" + new String(' ', DateTime.Now.ToString().Length + 4);

        public override void Write(string message)
        {
            System.Console.Write(message);
        }

        public override void WriteLine(string message)
        {

            System.Console.WriteLine(DateTime.Now + " " + message.Replace("\n", Paragrath));
        }
        public void ColorWriteLine(ConsoleColor color, string message)
        {
            var savedColor = System.Console.ForegroundColor;
            System.Console.ForegroundColor = color;
            WriteLine(message);
            System.Console.ForegroundColor = savedColor;

        }

        public override void TraceEvent(TraceEventCache eventCache, string source, TraceEventType eventType, int id, string message, params object[] args)
        {
            TraceEvent(eventCache, source, eventType, id, String.Format(message, args));
        }

        public override void TraceEvent(TraceEventCache eventCache, string source, TraceEventType eventType, int id, string message)
        {
            switch( eventType)
            {
                case TraceEventType.Warning:
                    ColorWriteLine(ConsoleColor.Yellow, " W " + message);
                    break;
                case TraceEventType.Error:
                    ColorWriteLine(ConsoleColor.Red, " E " + message);
                    break;
                default:
                    WriteLine("   " + message);
                    break;

            }
            
        }
    }
}
