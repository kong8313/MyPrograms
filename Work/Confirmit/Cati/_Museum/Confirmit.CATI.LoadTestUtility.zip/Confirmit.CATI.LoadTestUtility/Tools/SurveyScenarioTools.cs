﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

using Confirmit.CATI.LoadTestUtility.Enums;
using System.Diagnostics;
using Confirmit.CATI.LoadTestUtility.Scenarios;
using ConfirmitDialerInterface;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    public class SurveyScenarioTools
    {
       
        public static void ShowScenarioInfo(SurveyScenario scenario)
        {
            var info = new StringBuilder();
            //project
            
            info.Append("Project = \r\n{\r\n");
            info.AppendFormat("\tDialingMode                 = {0}\r\n", scenario.SchemaInfo.Project.DialingMode);
            info.AppendFormat("\tEnableInterviewRecording    = {0}\r\n", scenario.SchemaInfo.Project.EnableInterviewRecording);
            info.AppendFormat("\tEnableOpenedReviewRecording = {0}\r\n", scenario.SchemaInfo.Project.EnableOpenedReviewRecording);
            info.Append("},\r\n");

            //fields
            
            info.Append("Variables = \r\n{\r\n");
            foreach (var fieldInfo in scenario.SchemaInfo.Fields)
            {
                info.AppendFormat("\t{0,-20} {1,-15} {2}\r\n", fieldInfo.Value.Name, fieldInfo.Value.Type, String.Join(",", fieldInfo.Value.Precodes));
            }

            info.Append("},\r\n");
            
            //quotas
            
            info.Append("Quotas = \r\n{\r\n");
            foreach (var quotaInfo in scenario.SchemaInfo.Quotas)
            {
                info.AppendFormat(
                    "\t{0,-20} {1,-5} {2}\r\n",
                    quotaInfo.Value.Name,
                    (quotaInfo.Value.IsFcd || quotaInfo.Value.IsCati ? "C" : "") + (quotaInfo.Value.IsOptimistic ? "O" : ""),
                    String.Join(",", quotaInfo.Value.Fields));
            }
            info.Append("},\r\n");
            Logger.InfoRaw(info.ToString());
        }
    }
}
