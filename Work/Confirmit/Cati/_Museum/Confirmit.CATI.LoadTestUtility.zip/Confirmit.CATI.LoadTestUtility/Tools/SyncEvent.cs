using System.Collections.Generic;
using System.Threading;

namespace Confirmit.CATI.LoadTestUtility
{
    public class SyncEvent
    {
        public string Name { get; private set; }

        private static readonly Dictionary<string, ManualResetEvent> Events = new Dictionary<string, ManualResetEvent>(); 

        public SyncEvent(string name)
        {
            Name = name;
        }

        public void Wait()
        {
            GetEvent(Name).WaitOne();
        }

        public void Set()
        {
            GetEvent(Name).Set();
        }

        public void Reset()
        {
            GetEvent(Name).Reset();
        }

        private static ManualResetEvent GetEvent(string name)
        {
            lock( Events)
            {
                ManualResetEvent @event = null;
                if( !Events.TryGetValue(name, out @event ) )
                {
                    @event = new ManualResetEvent(false);
                    Events.Add(name, @event);
                }
                return @event;
            }
        }
    }
}