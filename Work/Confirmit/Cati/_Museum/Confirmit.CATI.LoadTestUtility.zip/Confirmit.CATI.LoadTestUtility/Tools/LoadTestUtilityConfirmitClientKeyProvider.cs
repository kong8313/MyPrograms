﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Confirmit.CATI.Core.Misc.ConfirmitClientKey;
using Confirmit.CATI.LoadTestUtility.Services;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    public class LoadTestUtilityConfirmitClientKeyProvider : IConfirmitClientKeyProvider
    {
        private DateTime _refreshTime = DateTime.MinValue;
        private string clientKey = null;
        private readonly object locker = new Object();
        public string Get()
        {
            lock (locker)
            {
                if (clientKey == null || _refreshTime < DateTime.Now)
                {
                    _refreshTime = DateTime.Now.AddMinutes(15);
                    clientKey = ConfirmitServices.Key;
                }
            }

            return clientKey;
        }
    }
}
