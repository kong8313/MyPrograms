﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Confirmit.CATI.Common.Random;
using Confirmit.CATI.Core.DAL.Generated.Entity.Adapter;
using Confirmit.CATI.Core.DAL.Generated.Entity.Table;
using Confirmit.CATI.Core.Paging;
using Confirmit.CATI.Core.Repositories.Interfaces;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.Supervisor.Classes.CallManagement;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    public static class CallManagerTools
    {
        public static int GetTotalPageCount(CallManagerParam callManagerParam, int surveySID)
        {
            var pagingArgs = new PagingArgs(1, callManagerParam.PageSize, "InterviewID", false);
            int totalCallsCount;
            CallHelper.GetCallsPage(surveySID, null, GetTimezoneId(), callManagerParam.FilterMode, pagingArgs, out totalCallsCount, ShowTimeMode.Interviewer, false);
            return (int)Math.Ceiling((decimal)totalCallsCount / callManagerParam.PageSize);
        }

        public static int[] GetPersonOrGroupIds(int saGroup)
        {
            List<BvMembershipEntity> membershipEntitys = BvMembershipAdapter.GetByCondition("ContainerSID=" + saGroup);
            var personOrGroupIds = new int[membershipEntitys.Count + 1];
            personOrGroupIds[0] = saGroup;

            for (int i = 0; i < membershipEntitys.Count; i++)
            {
                personOrGroupIds[i + 1] = membershipEntitys[i].ObjectSID;
            }

            return personOrGroupIds;
        }

        /// <summary>
        /// Return random DateTime? value
        /// 50% - null
        /// 50% - UtcNow minus random value from 0 to 10
        /// </summary>
        /// <returns></returns>
        public static DateTime? GetRandomTimeToCallValue()
        {
            if (Randomizer.Next(0, 2) == 0)
            {
                return null;
            }

            return DateTime.UtcNow.AddSeconds(Randomizer.Next(-10, 1));
        }


        public static void AddInterviewIdsToList(List<int> interviewIds, CallManagerParam callManagerParam, int surveySID, int pageIndex)
        {
            var pagingArgs = new PagingArgs(pageIndex, callManagerParam.PageSize, "InterviewID", false);
            int tempCallsCnt;
            DataTable calls = CallHelper.GetCallsPage(surveySID, null, GetTimezoneId(), callManagerParam.FilterMode, pagingArgs, out tempCallsCnt, ShowTimeMode.Interviewer, false);

            for (int j = 0; j < calls.Rows.Count; j++)
            {
                interviewIds.Add(Convert.ToInt32(calls.Rows[j]["InterviewID"].ToString()));
            }
        }

        /// <summary>
        /// Get page indexes to move calls from these pages
        /// </summary>
        /// <param name="pageCount">All page count to move</param>
        /// <param name="totalCount">All page count in survey</param>
        /// <param name="pageSelectType">Page select type: first pages, last pages or random pages</param>
        /// <returns></returns>
        public static int[] GetPageIndexes(int pageCount, int totalCount, PageSelectType pageSelectType)
        {
            int minPageCnt = Math.Min(pageCount, totalCount);

            switch (pageSelectType)
            {
                case PageSelectType.First:
                    return Enumerable.Range(1, minPageCnt).ToArray();
                case PageSelectType.Last:
                    return Enumerable.Range(totalCount - minPageCnt + 1, minPageCnt).OrderByDescending(x => x).ToArray();
                case PageSelectType.Random:
                    return Enumerable.Range(1, totalCount).OrderBy(x => Randomizer.Next()).Take(minPageCnt).ToArray();
                default:
                    throw new Exception("Unknown pageSelectType: " + pageSelectType);
            }
        }

        public static int GetTimezoneId()
        {
            return ServiceLocator.Resolve<ICallCenterRepository>().Get(Program.CallCenterId).LocalTimezoneId;
        }
    }
}
