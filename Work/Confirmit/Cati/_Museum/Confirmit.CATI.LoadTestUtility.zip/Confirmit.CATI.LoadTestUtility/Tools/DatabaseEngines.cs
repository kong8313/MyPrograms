﻿using System.Data.SqlClient;

using Confirmit.CATI.Core.DAL.Framework;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    internal class DatabaseEngines
    {
        private static DatabaseEngine _backend;
        private static DatabaseEngine _defaultDatabase;
        private static DatabaseEngine _confirmit;

        internal static DatabaseEngine Backend
        {
            get
            {
                if (_backend == null)
                {
                    var scsb = new SqlConnectionStringBuilder(AppConfiguration.ConnectionStringToBE)
                        {
                            InitialCatalog = "ConfirmitCATIV15_" + Program.CompanyId 
                        };
                    _backend = new DatabaseEngine(scsb.ToString());
                }

                return _backend;
            }
        }

        internal static DatabaseEngine DefaultDatabase
        {
            get
            {
                if (_defaultDatabase == null)
                {
                    _defaultDatabase = new DatabaseEngine(AppConfiguration.ConnectionStringToBE);
                }

                return _defaultDatabase;
            }
        }

        internal static DatabaseEngine Confirmit
        {
            get
            {
                if (_confirmit == null)
                {
                    _confirmit = new DatabaseEngine(AppConfiguration.ConnectionStringToCF);
                }

                return _confirmit;
            }
        }

        public static DatabaseEngine Survey(string projectId)
        {
            var scsb = new SqlConnectionStringBuilder(Confirmit.ConnectionString)
            {
                InitialCatalog = NameMaker.CfDatabaseName(projectId)
            };

            return new DatabaseEngine(scsb.ConnectionString);
        }
    }
}
