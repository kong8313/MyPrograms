﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

using Confirmit.CATI.Core.ActivityLogging;
using Confirmit.CATI.LoadTestUtility.Quota;
using Confirmit.CATI.LoadTestUtility.Survey;

namespace Confirmit.CATI.LoadTestUtility.ActivityEvents
{
    [Serializable]
    public class UpdateQuotaCoutersEventParameters : ManagementActivityEventDetails
    {
        public class CellInfo
        {
            public int CellId { get; set; }

            public int Counter { get; set; }

            public int Limit { get; set; }
        }
        public int QuotaId { get; set; }
        [XmlArray("Cells")]
        [XmlArrayItem("Cell")]
        public CellInfo[] Cells { get; set; }
    }

    public enum LoadTestManagementEvent 
    {
        UpdateQuotaCouters = 10001,
        StartLoadTest      = 10002
    }

    public class UpdateQuotaCountersEvent : ManagementActivityEvent<UpdateQuotaCoutersEventParameters>
    {
        public UpdateQuotaCountersEvent(
            SurveyInfo survey, 
            QuotaInfo quota):
            base(ManagementEventCategory.System, (ManagementEvent)LoadTestManagementEvent.UpdateQuotaCouters)
        {
            var cellinfo =
                quota.Cells.Select(
                    x =>
                    new UpdateQuotaCoutersEventParameters.CellInfo { CellId = x.CellId, Counter = x.Counter, Limit = x.Limit }).ToArray();

            ObjectId = survey.Sid;
            ObjectName = survey.ProjectId;
            Details = new UpdateQuotaCoutersEventParameters { QuotaId = quota.QuotaId, Cells = cellinfo };
        }
    }
}
