﻿ALTER DATABASE [{DBName}] MODIFY FILE ( NAME = N'ConfirmitCATIV15', SIZE = 2048MB )

ALTER DATABASE [{DBName}] MODIFY FILE ( NAME = N'ConfirmitCATIV15_Log', SIZE = 2048MB )

ALTER DATABASE [{DBName}] SET RECOVERY SIMPLE WITH NO_WAIT

USE [{DBName}]
exec BvSpSystemSetting_Update 'CacheCalls.InterviewsCountPerPerson', '300'
