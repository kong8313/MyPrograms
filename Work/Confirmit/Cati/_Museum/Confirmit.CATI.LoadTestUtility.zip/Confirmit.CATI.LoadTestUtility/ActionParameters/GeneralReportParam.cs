﻿using System;
using System.Linq;

using Confirmit.CATI.LoadTestUtility.Enums;

namespace Confirmit.CATI.LoadTestUtility.ActionParameters
{
    public struct GeneralReportParam
    {
        private GeneralReportType _reportType;
        private int _timeSpanMinutes;

        public GeneralReportType ReportType
        {
            get
            {
                return _reportType;
            }
        }

        public int TimeSpanMinutes
        {
            get
            {
                return _timeSpanMinutes;
            }
        }

        public GeneralReportParam(string param)
        {
            var paramToValues = param.Replace(" ", string.Empty).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(x => x.Split('=')).ToDictionary(x => x[0], y => y[1]);

            if (paramToValues.Count != 2)
            {
                throw new Exception(string.Format("GeneralReportParam action is failed. 'param' property is wrong: {0}", param));
            }

            switch (paramToValues["Type"])
            {
                case "SurveyProductivity":
                    _reportType = GeneralReportType.SurveyProductivity;
                    break;
                case "InterviewerProductivity":
                    _reportType = GeneralReportType.InterviewerProductivity;
                    break;
                default:
                    throw new Exception(string.Format("General report call is failed. Unknown 'Type' property: {0}", paramToValues["Type"]));
            }

            _timeSpanMinutes = int.Parse(paramToValues["TimeSpan"]);
        }
    }
}
