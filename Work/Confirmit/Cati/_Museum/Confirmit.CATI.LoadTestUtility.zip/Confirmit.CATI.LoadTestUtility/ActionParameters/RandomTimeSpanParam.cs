﻿using System;
using System.Linq;
using Confirmit.CATI.Common.Random;

namespace Confirmit.CATI.LoadTestUtility.ActionParameters
{
    public struct RandomTimeSpanParam
    {
        private readonly int _minMilliseconds;
        private readonly int _maxMilliseconds;

        public RandomTimeSpanParam(TimeSpan min, TimeSpan max)
        {
            this._minMilliseconds = (int)min.TotalMilliseconds;
            this._maxMilliseconds = (int)max.TotalMilliseconds;
        }

        public TimeSpan Value
        {
            get
            {
                var ms = Randomizer.Next(this._minMilliseconds, this._maxMilliseconds);

                return TimeSpan.FromMilliseconds(ms);
            }
        }
    }
}
