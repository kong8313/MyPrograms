﻿using System.Linq;
using Confirmit.CATI.Common.Random;

namespace Confirmit.CATI.LoadTestUtility.ActionParameters
{
    public class RandomIntParam
    {
        public int MinValue { get; private set; }
        public int MaxValue { get; private set; }

        public static RandomIntParam Zero = new RandomIntParam(0,0);

        public RandomIntParam(int min, int max)
        {
            MinValue = min;
            MaxValue = max;
        }

        public RandomIntParam(string str)
        {
            if (string.IsNullOrEmpty(str))
            {
                MinValue = 0;
                MaxValue = 0;
                return;
            }

            var bounds = str.Split('-').Select(int.Parse).ToArray();

            MinValue = bounds[0];
            MaxValue = bounds.Length > 1 ? bounds[1] : bounds[0];
        }

        public int Value
        {
            get
            {
                return Randomizer.Next(MinValue, MaxValue);
            }
        }

        public override string ToString()
        {
            return string.Format("{0}-{1}", MinValue, MaxValue);
        }
    }
}
