﻿using System;

namespace Confirmit.CATI.LoadTestUtility.ActionParameters
{
    public struct IntParam
    {
        private int _value;

        public int Value
        {
            get
            {
                return _value;
            }
        }

        public IntParam(string str)
        {
            if (string.IsNullOrEmpty(str))
            {
                _value = 0;
                return;
            }

            _value = Convert.ToInt32(str);
        }

        public override string ToString()
        {
            return string.Format("{0}", _value);
        }
    }
}
