﻿using System.Linq;

namespace Confirmit.CATI.LoadTestUtility.ActionParameters
{
    class GetCallsPageParam : CallManagerParam
    {
        public string[] OutputColumns;
        public string OrderColumn;

        public GetCallsPageParam(string param) : base(param)
        {
            OutputColumns = AsString("OutputColumns").Split(';').ToArray();
            if (OutputColumns.Length == 1 && string.IsNullOrEmpty(OutputColumns[0]))
                OutputColumns = new string[0];
            OrderColumn = AsString("OrderColumn");
        }
    }
}
