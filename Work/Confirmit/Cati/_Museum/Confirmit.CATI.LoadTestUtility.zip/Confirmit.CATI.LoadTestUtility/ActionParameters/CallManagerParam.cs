﻿using System;
using System.Linq;
using Confirmit.CATI.Common;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.Supervisor.Core.Surveys;

namespace Confirmit.CATI.LoadTestUtility.ActionParameters
{
    public class CallManagerParam : NamedParams
    {
        public CallStates FilterMode { get; private set; }
        public PageSelectType PageSelectType{ get; private set; }
        public int PageCount{ get; private set; }
        public int PageSize{ get; private set; }
        public TimeSpan Duration { get; private set; }
        public string FilterName { get; set; }

        public CallManagerParam(string param) : base(param)
        {
            FilterMode = AsEnum<CallStates>("FilterMode");
            PageCount = AsInt("PageCount");
            PageSize = AsInt("PageSize");
            PageSelectType = AsEnum<PageSelectType>("PageSelectType");
            Duration = AsTimeSpan("Duration");
            FilterName = AsString("FilterName");
        }
    }
}
