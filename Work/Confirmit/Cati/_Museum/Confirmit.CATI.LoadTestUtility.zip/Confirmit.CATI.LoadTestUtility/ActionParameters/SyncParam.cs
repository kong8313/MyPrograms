﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Confirmit.CATI.LoadTestUtility.ActionParameters
{
    public class SyncParam : BaseNamedParams
    {
        public enum ExecMode
        {
            Single,
            Multiple
        }

        public string Name { get; private set; }

        public ExecMode Mode { get; private set; }

        public int MaxWaiters { get; private set; }

        public TimeSpan Duration { get; private set; }

        public SyncParam( string param ) : base(param)
        {
            Name = GetNamedParams("Name");
            Mode = (ExecMode)Enum.Parse(typeof(ExecMode), GetNamedParams("Mode", "Multiple"));
            MaxWaiters = Int32.Parse(GetNamedParams("MaxWaiters", "0"));
            Duration = TimeSpan.FromMinutes(Int32.Parse(GetNamedParams("Duration", "0")));
        }
    }
}
