﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Confirmit.CATI.LoadTestUtility.ActionParameters
{
    public class BaseNamedParams
    {
        private Dictionary<string, string> NamedParams;
        public BaseNamedParams(string param)
        {
            NamedParams = param.Split(',').Select(x => x.Split(new[] { '=' }, StringSplitOptions.RemoveEmptyEntries)).ToDictionary(
                items => items[0].Trim(), items => items[1].Trim());
        }

        public string GetNamedParams(string name )
        {
            return NamedParams[name];
        }

        public string GetNamedParams(string name, string defaultValue )
        {
            string result;
            if( NamedParams.TryGetValue(name, out result))
            {
                return result;
            }

            return defaultValue;
        }
    }
}
