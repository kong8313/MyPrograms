﻿using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.Common;
using Confirmit.CATI.Core.DAL.Generated.Entity.Table;
using Confirmit.CATI.Core.Repositories;
using Confirmit.CATI.Core.Services.FilterServiceImplementation;

namespace Confirmit.CATI.LoadTestUtility.ActionParameters
{
    public class Filter
    {
        public static void Create(int surveySid, NamedParams param)
        {
            var bvFiltersEntity = new BvFiltersEntity();
            bvFiltersEntity.Name = param.AsString("FilterName")+surveySid;
            bvFiltersEntity.AndOrOperator =
                (byte)(AndOrOperator)Enum.Parse(typeof(AndOrOperator), param.AsString("AndOrOperator"), true /*ignore case*/);
            var filterId = FilterRepository.Insert(bvFiltersEntity);

            var fields = param.AsString("Conditions").Split(';').Select(condition => ParseCondition(filterId, condition)).ToList();

            FilterService.SetFields(filterId, fields);
        }

        private static BvFilterFieldsEntity ParseCondition(int filterId, string str)
        {
            var parts = str.Split('@');

            return new BvFilterFieldsEntity
                {
                    Column = parts[0],
                    Table = GetTableTypeByColumnName(parts[0]),
                    FilterSID = filterId,
                    Sign = (int) Enum.Parse(typeof (FilterOperator), parts[1]),
                    Type = GetColumnTypeByColumnName(parts[0]),
                    Value = parts[2],
                };
        }

        private static int GetTableTypeByColumnName(string columnName)
        {
            switch (columnName)
            {
                case "TelephoneNumber":
                case "TransientState":
                case "LastCallTime":
                    return (int)TableTypes.Interview;
                case "Priority":
                    return (int) TableTypes.Call;
                default:
                    return (int)TableTypes.CFVariables;
            }
        }

        private static int GetColumnTypeByColumnName(string columnName)
        {
            switch (columnName)
            {
                case "LastCallTime":
                    return (int) VariableTypes.Date;
                case "TelephoneNumber":
                    return (int) VariableTypes.String;
                case "TransientState":
                case "Priority":
                    return (int)VariableTypes.Integer;
                default:
                    return (int)VariableTypes.String;
            }
        }
    }
}
