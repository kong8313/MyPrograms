﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Confirmit.CATI.LoadTestUtility.ConfirmitAuthoring;
using Confirmit.CATI.LoadTestUtility.ConfirmitLogOn;
using Confirmit.CATI.LoadTestUtility.ConfirmitSurveyDeployer;

namespace Confirmit.CATI.LoadTestUtility.Services
{
    class ConfirmitServices
    {
        private static volatile Authoring authoringService;
        public static Authoring Authoring
        {
            get
            {
                if (authoringService == null)
                {
                    lock (typeof(ConfirmitServices))
                    {
                        if( authoringService == null)
                            authoringService = new Authoring();
                    }
                }
                return authoringService;
            }
        }

        private static volatile LogOn logOnService;
        public static LogOn LogOn
        {
            get
            {
                if (logOnService == null)
                {
                    lock (typeof(ConfirmitServices))
                    {
                        if (logOnService == null)
                        {
                            logOnService = new LogOn();
                        }
                    }
                }
                return logOnService;
            }
        }

        private volatile static string key;
        public static string Key
        {
            get
            {
                if( key == null )
                {
                    lock( typeof( ConfirmitServices))
                    {
                        if( key == null)
                        {
                            key = LogOn.LogOnUser(AppConfiguration.ConfirmitLogin, AppConfiguration.ConfirmitPassword);
                        }
                    }
                }
                return key;
            }
        }

        private static volatile SurveyDeployer surveyDeployerService;
        public static SurveyDeployer SurveyDeployer
        {
            get
            {
                if (surveyDeployerService == null)
                {
                    lock (typeof(ConfirmitServices))
                    {
                        if (surveyDeployerService == null)
                        {
                            surveyDeployerService = new SurveyDeployer();
                        }
                    }
                }
                return surveyDeployerService;
            }
        }

    }
}
