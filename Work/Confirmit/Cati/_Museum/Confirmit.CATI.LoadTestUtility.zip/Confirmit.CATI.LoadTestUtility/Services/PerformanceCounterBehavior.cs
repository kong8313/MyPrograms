using System;
using System.Diagnostics;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;

namespace Confirmit.CATI.LoadTestUtility.Services
{
    internal class PerformanceCounterBehavior : IEndpointBehavior, IClientMessageInspector
    {
        public void Validate(ServiceEndpoint endpoint)
        {
        }

        public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
        {
        }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
        {
            clientRuntime.MessageInspectors.Add(this);
        }

        public object BeforeSendRequest(ref Message request, IClientChannel channel)
        {
            return Tuple.Create(request.Headers.Action, Stopwatch.StartNew());
        }

        public void AfterReceiveReply(ref Message reply, object correlationState)
        {
            var tuple = (Tuple<string, Stopwatch>) correlationState;
            switch (tuple.Item1)
            {
                case @"http://www.confirmit.com/ConsoleStateService/05/27/2010/ConsoleStateService/GetState":
                    PerformanceCounters.RateOfGetStateCountsPerSecondPerformanceCounter.Increment();
                    PerformanceCounters.AverageOfGetStateDurationPerformanceCounter.IncrementBy(tuple.Item2.Elapsed);
                    break;
                case @"http://www.confirmit.com/ConsoleService/04/24/2009/ConsoleService/WrapUp":
                    PerformanceCounters.RateOfWrapUpCountsPerSecondPerformanceCounter.Increment();
                    PerformanceCounters.AverageOfWrapUpDurationPerformanceCounter.IncrementBy(tuple.Item2.Elapsed);
                    break;
            }
        }
    }
}