﻿using System;
using System.Net;
using System.ServiceModel;
using Confirmit.CATI.Common.SideBySide;
using Confirmit.CATI.Core.ManagementService;
using Confirmit.CATI.Common.ServiceLocation;

namespace Confirmit.CATI.LoadTestUtility.Services
{
    internal class ManagementServices
    {
        private static IManagementService _multimodeService;

        internal static IManagementService Multimode
        {
            get
            {
                if (_multimodeService != null && ((ICommunicationObject)_multimodeService).State == CommunicationState.Opened)
                {
                    return _multimodeService;
                }

                RecreateService();

                return _multimodeService;
            }
        }

        private static void RecreateService()
        {
            string url = ServiceLocator.Resolve<ISideBySideManager>().AddSideBySideNameToBackendWCFServiceUrl(AppConfiguration.MultimodeWebServiceURL + Program.CompanyId);

            if (_multimodeService != null)
            {
                ((ICommunicationObject)_multimodeService).Abort();
                _multimodeService = null;

                var servicePoint = ServicePointManager.FindServicePoint(new Uri(url));
                servicePoint.CloseConnectionGroup("");
            }

            var binding = new BasicHttpBinding
            {
                CloseTimeout = TimeSpan.FromMinutes(30),
                ReceiveTimeout = TimeSpan.FromMinutes(30),
                SendTimeout = TimeSpan.FromMinutes(30),
                OpenTimeout = TimeSpan.FromMinutes(30)
            };

            var endpointAddress = new EndpointAddress(url);

            var factory = new ChannelFactory<IManagementService>(binding, endpointAddress);
            _multimodeService = factory.CreateChannel();
        }

        private static void SafeCall(Action action)
        {
            try
            {
                action();
            }
            catch
            {
                RecreateService();
                action();
            }
        }


        private static T SafeCall<T>(Func<T> call)
        {
            try
            {
                return call();
            }
            catch
            {
                RecreateService();
                return call();
            }
        }

        internal static void SaveInterviewHistoryAndControlData(InterviewHistoryData historyData, InterviewControlData controlData)
        {
            SafeCall(() => Multimode.SaveInterviewHistoryAndControlData(historyData, controlData));
        }

        internal static void OnQuotaCellsChanged(string cfProjectId, int cfQuotaId, int[] openedCfCellIds, int[] closedCfCellIds, int[] optimisticallyClosedCfCellIds)
        {
            SafeCall(() => Multimode.OnQuotaCellsChanged(cfProjectId, cfQuotaId, openedCfCellIds, closedCfCellIds, optimisticallyClosedCfCellIds));
        }

        internal static void AddSample(string projectdID, int batchID, int mode, int recordsCount)
        {
            SafeCall(() => Multimode.AddSample(projectdID, batchID, mode, recordsCount));
        }

        internal static int AddSampleGetState(int batchId)
        {
            string stateDescription;

            return SafeCall(() => Multimode.AddSampleGetState(batchId, out stateDescription));
        }
    }
}
