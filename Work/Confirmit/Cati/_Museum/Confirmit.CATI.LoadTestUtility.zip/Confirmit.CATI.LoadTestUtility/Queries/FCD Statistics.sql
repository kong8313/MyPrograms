/**************************************************************************************************************/
/**************************************************************************************************************/
/**************************************************************************************************************/
/*                                      BASE QUERY															  */
/**************************************************************************************************************/
/**************************************************************************************************************/
/**************************************************************************************************************/
--StartInterview duration
IF NOT EXISTS( select * from sys.indexes WHERE name = 'IX_BvStatisticLog' )
BEGIN
	CREATE UNIQUE INDEX IX_BvStatisticLog on BvStatisticLog ( EventTypeID, StartTime, ID )
END

select t.*, d.*  
	into #tInterStat
	from (
select sl.ID, sl.EventTypeID, sl.StartTime, sl.ObjectSID as PersonSID, 
		( SELECT TOP(1) sl1.StartTime
				FROM BvStatisticLog sl1 
				WHERE sl1.EventTypeID = 21/*DeliveryCall*/ AND
				  sl1.StartTime > sl.StartTime AND sl.ObjectSID = sl1.ObjectSID ORDER BY sl1.StartTime ) as StartCDTime,
		( SELECT TOP(1) sl1.FinishTime
				FROM BvStatisticLog sl1 
				WHERE sl1.EventTypeID = 21/*DeliveryCall*/ AND
				  sl1.StartTime > sl.StartTime AND sl.ObjectSID = sl1.ObjectSID ORDER BY sl1.StartTime ) as FinishCDTime,
		( SELECT TOP(1) sl1.Param1
				FROM BvStatisticLog sl1 
				WHERE sl1.EventTypeID = 21/*DeliveryCall*/ AND
				  sl1.StartTime > sl.StartTime AND sl.ObjectSID = sl1.ObjectSID ORDER BY sl1.StartTime ) as SurveySID,
		( SELECT TOP(1) sl1.Param2
				FROM BvStatisticLog sl1 
				WHERE sl1.EventTypeID = 21/*DeliveryCall*/ AND
				  sl1.StartTime > sl.StartTime AND sl.ObjectSID = sl1.ObjectSID ORDER BY sl1.StartTime ) as interviewID
		
			FROM BvStatisticLog sl WHERE EventTypeID = 40/*StartInterview*/ OR EventTypeID = 41/*OnWrapUp*/
		) t
		left join TestDataTable d
		on t.interviewID = d.DataId
		WHERE interviewID IS NOT NULL
		ORDER BY t.PersonSID, t.StartTime 
		

/*
public enum StatisticLogEventType : int
    {
        CreateSurvey = 1,
        DeleteSurvey = 2,
        OpenSurvey = 3,
        CloseSurvey = 4,
        AddSample = 5,
        OnQuotaCellChanged = 10,
        OnQuotaUpdate = 11,
        OnQuotaCellsChanged = 12,
        ActivateCall = 20,
        DeliveryCall = 21,
        CreatePerson = 30,
        DeletePerson = 31,
        LoginPerson = 32,
        LogoutPerson = 33,
        StartInterview = 40,
        WrapUp = 41,
        SendControlData = 42,
        SetPendingLogout = 43

    }
   */

--start date of first interview
--start date of last interview
--count started interviews
--min CallDeliveryDuration duration in ms
--max CallDeliveryDuration duration in ms
--avg CallDeliveryDuration duration in ms
--min Startinterview/OnWrapUp duration in ms
--max Startinterview/OnWrapUp duration in ms
--avg Startinterview/OnWrapUp duration in ms
select	MIN(StartTime) as FirstInterviewStart,
		MAX(StartTime) as LastInterviewStart,
		COUNT(*) as TotalStartInterview,
		MIN( DATEDIFF( ms, StartCDTime, FinishCDTime )) as MinCallDeliveryTime,
		MAX( DATEDIFF( ms, StartCDTime, FinishCDTime )) as MaxCallDeliveryTime,
		AVG( DATEDIFF( ms, StartCDTime, FinishCDTime )) as AvgCallDeliveryTime,
		MIN( DATEDIFF( ms, StartTime, FinishCDTime )) as MinStartInterview,
		MAX( DATEDIFF( ms, StartTime, FinishCDTime )) as MaxStartInterview,
		AVG( DATEDIFF( ms, StartTime, FinishCDTime )) as AvgStartInterview
	from #tInterStat where interviewID IS NOT NULL


-- select top N of max Call delivery times
select * FROM (
select TOP(10) StartTime, FinishCDTime, PersonSID as InterviewerID, CDTime FROM( 
		SELECT *, DATEDIFF( ms, StartTime, FinishCDTime ) as CDTime
		FROM #tInterStat ) t ORDER BY t.CDTime DESC ) t2 ORDER BY StartTime

/**************************************************************************************************************/
/**************************************************************************************************************/
/**************************************************************************************************************/
/*                                      CHECK CALL DELIVERING ON QUOTAS										  */
/**************************************************************************************************************/
/**************************************************************************************************************/
/**************************************************************************************************************/	
--deploy colosing/opening cells 

create table #CellsInfo
(
	SurveySID INT NOT NULL,
	QuotaId INT NOT NULL,
	CellID INT NOT NULL,
	ChangeDate DATETIME NOT NULL,
	State BIT NOT NULL
);

INSERT INTO #CellsInfo(SurveySID, QuotaId, CellID, ChangeDate, State ) 
	SELECT ObjectSID, CAST( Param1 AS INT ), CAST( Param2 AS INT), FinishTime, CASE WHEN Param3Max = 'False' THEN 0 ELSE 1 END
		FROM BvStatisticLog WHERE EventTypeID = 10 AND FinishTime IS NOT NULL
		
DECLARE crClosedCells CURSOR FOR 
	SELECT ObjectSID, FinishTime, CAST( Param1 AS INT ), Param2, Param3Max 
		FROM BvStatisticLog 
			WHERE EventTypeID = 12/*OnQuotaCellsChanged*/ AND FinishTime IS NOT NULL

DECLARE @SurveySID INT
DECLARE @FinishTime DATETIME
DECLARE @QuotaID INT
DECLARE @OpenedCells NVARChAR(MAX)
DECLARE @ClosedCells NVARChAR(MAX)

OPEN crClosedCells

FETCH NEXT FROM crClosedCells INTO @SurveySID, @FinishTime, @QuotaID, @OpenedCells, @ClosedCells

WHILE (@@FETCH_STATUS = 0)
BEGIN
	INSERT INTO #CellsInfo(SurveySID, QuotaId, CellID, ChangeDate, State ) 
		SELECT @SurveySID, @QuotaID, Item, @FinishTime, 1 FROM  dbo.utilSplitNumbers(@OpenedCells, ',')
	
	INSERT INTO #CellsInfo(SurveySID, QuotaId, CellID, ChangeDate, State ) 
		SELECT @SurveySID, @QuotaID, Item, @FinishTime, 0 FROM  dbo.utilSplitNumbers(@ClosedCells, ',')

	FETCH NEXT FROM crClosedCells INTO @SurveySID, @FinishTime, @QuotaID, @OpenedCells, @ClosedCells
END

CLOSE crClosedCells
DEALLOCATE crClosedCells

CREATE UNIQUE INDEX CellsInfoIndex on #CellsInfo ( SurveySID, QuotaId, CellID, ChangeDate )

	select i.*, 
		/*First quota*/
		q1.quotaid as Cell1,
		ISNULL( (select TOP(1) State from #CellsInfo 
					where SurveySID = i.SurveySID AND 
							QuotaId = 1 AND 
							CellID = q1.quotaid AND 
							ChangeDate < i.FinishCDTime 
						ORDER BY ChangeDate DESC ), 1 ) as Cell1State,
		( select TOP(1) ChangeDate from #CellsInfo 
					where SurveySID = i.SurveySID AND 
							QuotaId = 1 AND 
							CellID = q1.quotaid AND 
							ChangeDate < i.FinishCDTime 
						ORDER BY ChangeDate DESC ) as PrevCell1ChangeDate,
		( select TOP(1) ChangeDate from #CellsInfo 
					where SurveySID = i.SurveySID AND 
							QuotaId = 1 AND 
							CellID = q1.quotaid AND 
							ChangeDate >= i.FinishCDTime 
						ORDER BY ChangeDate ASC ) as NextCell1ChangeDate,
		/*Second quota*/
		q2.quotaid as Cell2,
		ISNULL( (select TOP(1) State from #CellsInfo 
					where SurveySID = i.SurveySID AND 
							QuotaId = 2 AND 
							CellID = q2.quotaid AND 
							ChangeDate < i.FinishCDTime 
						ORDER BY ChangeDate DESC ), 1 ) as Cell2State,
		( select TOP(1) ChangeDate from #CellsInfo 
					where SurveySID = i.SurveySID AND 
							QuotaId = 2 AND 
							CellID = q2.quotaid AND 
							ChangeDate < i.FinishCDTime 
						ORDER BY ChangeDate DESC ) as PrevCell2ChangeDate,
		( select TOP(1) ChangeDate from #CellsInfo 
					where SurveySID = i.SurveySID AND 
							QuotaId = 2 AND 
							CellID = q2.quotaid AND 
							ChangeDate >= i.FinishCDTime 
						ORDER BY ChangeDate ASC ) as NextCell2ChangeDate
		into #tInterviewInfo
		from #tInterStat i
		LEFT JOIN [testsurvey_CO-OSL-DEVB28_p00000006].[dbo].quota_1 q1
		on ( i.q1 IS NULL OR i.q1 = q1.q1 ) AND ( i.q2 IS NULL OR i.q2 = q1.q2 ) AND ( i.q3 IS NULL OR i.q3 = q1.q3 )
		LEFT JOIN [testsurvey_CO-OSL-DEVB28_p00000006].[dbo].quota_2 q2
		on ( i.q3 IS NULL OR i.q3 = q2.q3 ) AND ( i.q4 IS NULL OR i.q4 = q2.q4 )
		order by i.StartTime

CREATE UNIQUE INDEX InterviewInfo2 on #tInterviewInfo ( ID, Cell1, Cell2 )

-- check call on quotas( show delivered calls with closing quota cells )
select 'call was delivered on closing by quotas', * from #tInterStat s where 
	NOT EXISTS( SELECT 1 FROM #tInterviewInfo i WHERE s.ID = i.ID AND i.Cell1State = 1 AND i.Cell2State = 1 )
/*
select * from #CellsInfo

SELECT ID, COUNT(*) FROM #tInterviewInfo GROUP BY ID HAVING COUNT(*) < 12
SELECT ID , ( SELECT  COUNT(*) FROM #tInterviewInfo i2 WHERE i1.ID = i2.ID AND ( NextCell1ChangeDate IS NULL AND NextCell2ChangeDate IS NULL ) ) FROM #tInterviewInfo i1 GROUP BY ID
SELECT * FROM #tInterviewInfo WHERE ID = 8751
select * from #tInterStat WHERE ID = 8751
select * from BvStatisticLog WHERE EventTypeID = 21 AND Param1 = 68 AND Param2 = 23
UPDATE BvStatisticLog SET StartTime = '2009-10-20 13:14:08.590',
						  FinishTime = '2009-10-20 13:14:09.590'
						  WHERE EventTypeID = 21 AND Param1 = 68 AND Param2 = 23

select * from BvStatisticLog WHERE EventTypeID = /*OnQuotaCellChanged */10 AND Param1 = 2 AND Param2 = 11 AND ObjectSID = 68
UPDATE BvStatisticLog 
		SET StartTime = '2009-10-20 13:13:08.590'/*2009-10-20 13:17:15.860*/,
			FinishTime = '2009-10-20 13:13:09.590'/*2009-10-20 13:17:16.387*/
		WHERE EventTypeID = /*OnQuotaCellChanged */10 AND Param1 = 2 AND Param2 = 11 AND ObjectSID = 68*/
/**************************************************************************************************************/
/**************************************************************************************************************/
/**************************************************************************************************************/
/*                                      show Statistics per minutes											  */
/**************************************************************************************************************/
/**************************************************************************************************************/
/**************************************************************************************************************/	

--DECLARE @FinishTime DATETIME 
DECLARE @StartTime DATETIME = 
		( SELECT DATEADD( s, - DATEPART( s, MIN(StartTime) ), 
				 DATEADD( ms, - DATEPART( ms, MIN(StartTime) ), MIN(StartTime) ) ) FROM BvStatisticLog )
SET @FinishTime = 
		( SELECT DATEADD( s, 60 - DATEPART( s, MAX(FinishTime) ), 
				 DATEADD( ms, - DATEPART( ms, MAX(FinishTime) ), MAX(FinishTime) ) ) FROM BvStatisticLog );

WITH di( StartTime, FinishTime ) AS
(
	SELECT	@StartTime, DATEADD( MI, 1, @StartTime )
	UNION ALL
	SELECT FinishTime, DATEADD( mi, 1, FinishTime ) 
		FROM di
			WHERE DATEADD( mi, 1, StartTime ) < @FinishTime
)
SELECT *,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime ) as TotalOperation,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 1) as CreateSurveys,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 2) as DeleteSurveys,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 3) as OpenSurveys,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 4) as CloseSurveys,
        --AddSample = 5,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 5) as AddSample,
        --OnQuotaCellChanged = 10,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 10) as OnQuotaCellChanged,
        --OnQuotaUpdate = 11,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 11) as OnQuotaUpdate,
        --OnQuotaCellsChanged = 12,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 12) as OnQuotaCellsChanged,
        --ActivateCall = 20,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 20) as ActivateCall,
        --DeliveryCall = 21,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 21) as DeliveryCallTotal,
	( SELECT AVG(DATEDIFF(ms, sl.StartTime, sl.FinishTime )) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 21) as AvgDeliveryCallTotal,
	( SELECT MAX(DATEDIFF(ms, sl.StartTime, sl.FinishTime )) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 21) as MaxDeliveryCallTotal,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 21 AND sl.Param2 IS NOT NULL) as DeliveryCallOk,
	( SELECT AVG(DATEDIFF(ms, sl.StartTime, sl.FinishTime )) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 21 AND sl.Param2 IS NOT NULL) as AvgDeliveryCallOk,
	( SELECT MAX(DATEDIFF(ms, sl.StartTime, sl.FinishTime )) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 21 AND sl.Param2 IS NOT NULL) as MaxDeliveryCallOk,
        --CreatePerson = 30,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 30) as CreatePerson,
        --DeletePerson = 31,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 31) as DeletePerson,
        --LoginPerson = 32,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 32) as LoginPerson,
        --LogoutPerson = 33,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 33) as LogoutPerson,
        --StartInterview = 40,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 40) as StartInterview,
        --WrapUp = 41,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 41) as WrapUp,
        --SendControlData = 42,
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 42) as SendControlData,
        --SetPendingLogout = 43
	( SELECT COUNT(*) FROM BvStatisticLog sl 
		WHERE sl.StartTime <= di.FinishTime AND sl.FinishTime >= di.StartTime AND sl.EventTypeID = 43) as SetPendingLogout
FROM di OPTION (MAXRECURSION 0);

DROP TABLE #tInterStat
DROP TABLE #CellsInfo
DROP TABLE #tInterviewInfo

/*
SELECT COUNT(*) FROM BvStatisticLog sl WHERE sl.StartTime >= '2009-10-14 16:08:00.000' AND sl.FinishTime <= '2009-10-14 16:07:00.000'
select * from BvStatisticLog
	
SELECT * FROM BvStatisticLog WHERE ID = 40993
select * from BvStatisticLog where FinishTime = '2009-10-12 15:19:44.887'


UPDATE BvStatisticLog SET Param2 = '31,605,649,224,246,56,212,887,377' WHERE ID = 40993
select * from BvStatisticLog where ObjectSID = 188 AND EventTypeID = 12 

select SurveySID, State, COUNT(*) from #CellsInfo GROUP BY SurveySID, State


	
SELECT DATEPART(

select * from BvStatisticLog where ObjectSID = 52


select * from BvStatisticLog WHERE EventTypeID = 10/*OnQuotaCellChanged*/ AND ObjectSID = 331
select *, LEN( Param2), LEN( Param3Max) from BvStatisticLog 
WHERE EventTypeID = 12/*OnQuotaCellsChanged*/ AND ObjectSID = 331 
	OR EventTypeID = 5
		
	select EventTypeID, StartTime, COUNT(StartTime) FROM BvStatisticLog GROUP BY EventTypeID, StartTime
		HAVING COUNT(StartTime) > 1 


	select EventTypeID from (
	select EventTypeID, StartTime, COUNT(StartTime) as cnt FROM BvStatisticLog 
		GROUP BY EventTypeID,ObjectSID,StartTime 
		HAVING COUNT(StartTime) > 1 ) as t
		GROUP BY EventTypeID ORDER BY EventTypeID 
		
	SELECT EventTypeID FROM BvStatisticLog GROUP BY EventTypeID ORDER BY EventTypeID 

select i.StartTime, i.FinishTime, i.Param1 as SID, i.Param2 as IID, q1.quotaid from 
	( SELECT * FROM BvStatisticLog i
		WHERE i.EventTypeID = 21/*DeliveryCall*/ AND i.Param1/*SSID*/ = 331 AND i.Param2/*IID*/ IS NOT NULL ) i
	left join TestDataTable td
	ON i.ID = td.DataId 
	LEFT JOIN [testsurvey_CO-OSL-DEVB28_p00000007].[dbo].quota_1 q1
	ON ( td.q1 = q1.q1 OR td.q1 IS NULL ) AND ( td.q2 = q1.q2 OR td.q2 IS NULL ) AND ( td.q3 = q1.q3 OR td.q3 IS NULL )
		

DECLARE @CountDatas INT 
SELECT @CountDatas = COUNT(*) FROM TestDataTable

select 
	StartTime, 
	FinishTime, 
	ObjectSID as PersonSID, 
	Param1/*SurveySID*/ as SurveySID, 
	Param2/*IID*/ as IID,
	(Param2/*IID*/ ) % @CountDatas as DataID
from BvStatisticLog where EventTypeID = 21/*DeliveryCall*/ and Param2/*IID*/ IS NOT NULL


DECLARE @CountDatas INT 
SELECT @CountDatas = COUNT(*) FROM TestDataTable

select * from BvInterview as i
	INNER JOIN BvReplicatedData_331 as r
		ON i.ID = r.respid
	INNER JOIN TestDataTable t
		ON ( i.ID % @CountDatas ) = t.DataId
	where SurveySID = 331 AND ( r.q1 <> t.q1 or r.q2 <> t.q2 or r.q3 <> t.q3 or r.q4 <> t.q4 )

select i.ID* from BvReplicatedData_331 where respid = 1
*/