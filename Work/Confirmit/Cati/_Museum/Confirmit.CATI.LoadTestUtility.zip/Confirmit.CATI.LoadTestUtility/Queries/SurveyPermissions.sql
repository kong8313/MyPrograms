insert into BvUserSurveyPermission
select 'administrator' as UserName, SID as SurveySID from BvSurvey