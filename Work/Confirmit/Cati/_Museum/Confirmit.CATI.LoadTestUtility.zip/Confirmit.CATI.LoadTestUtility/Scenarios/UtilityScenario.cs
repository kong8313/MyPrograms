﻿using System.Collections.Generic;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;

namespace Confirmit.CATI.LoadTestUtility.Scenarios
{
    public class UtilityScenario : Scenario<UtilityContext>
    {
        public UtilityScenario() : base("@Utility"){}

        public int AdministratorsCount;

        public RunAction ExecutionMode;

        public List<SurveyScenario> SurveyScenarios = new List<SurveyScenario>();

        public List<InterviewScenario> InterviewScenarios = new List<InterviewScenario>(); 
    }
}
