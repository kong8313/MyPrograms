﻿using System;
using System.Collections.Generic;
using Confirmit.CATI.LoadTestUtility.Scenarios.Actions;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios
{
    public class Scenario<TContext> : List<IScenarioAction<TContext>>
    {
        public string Name { get; private set; }

        public Scenario(string name)
        {
            Name = name;
        }

        public void  Execute(TContext context)
        {
            foreach( var action in this)
 	        {
                Logger.Info("Execute {0} ( {1} )", action.Name, action.Info );
 	            try
 	            {
                    action.Execute(context);
                    Logger.Info("Completed {0} ( {1} )", action.Name, action.Info);
 	            }
 	            catch (Exception ex)
 	            {
                    Logger.Error("Action {0} ( {1} ) failed with {2}", action.Name, action.Info, ex);
 	            }
 	            
 	        }
        }
    }
}
