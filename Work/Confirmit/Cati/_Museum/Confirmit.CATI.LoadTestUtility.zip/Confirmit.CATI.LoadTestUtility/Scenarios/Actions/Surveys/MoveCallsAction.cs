﻿using Confirmit.CATI.Common.Random;
using Confirmit.CATI.Core.Batch;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.Supervisor.Core.Surveys;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class MoveCallsAction : BaseCallManagerAction
    {
        public MoveCallsAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action):base(action)
        {
        }

        public static MoveCallsAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new MoveCallsAction(action);
        }

        protected override void Execute(SurveyContext context, BatchParameters batchParameters)
        {
            var randomIts = Randomizer.Next(31, 121);

            Logger.Info("MoveCalls parameters: randomIts = {0}", randomIts);

            var operationEntity = CallManager.MoveCalls(context.Sid, randomIts, batchParameters);

            ExecuteAsyncOperation(context, operationEntity);
        }
    }
}
