﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions
{
    public interface IInterviewAction : IScenarioAction<InterviewContext>
    {
        
    }
}
