﻿using System;
using Confirmit.CATI.Common.Random;
using Confirmit.CATI.Core.Batch;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.Supervisor.Core.Surveys;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class ActivateCallsAction : BaseCallManagerAction
    {
        public ActivateCallsAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action)
            : base(action)
        {
        }

        public static ActivateCallsAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new ActivateCallsAction(action);
        }

        protected override void Execute(SurveyContext context, BatchParameters batchParameters)
        {
            var personOrGroupIds = CallManagerTools.GetPersonOrGroupIds(context.SaGroup);
            const int shiftTypeId = -1;
            var priority = Randomizer.Next(1, int.MaxValue);
            var personOrGroupId = personOrGroupIds[Randomizer.Next(0, personOrGroupIds.Length)];
            DateTime? timeToCall = CallManagerTools.GetRandomTimeToCallValue();

            var operation = CallManager.ActivateCalls(context.Sid, priority, Param.FilterMode, new []{personOrGroupId}, shiftTypeId, null, timeToCall, false, batchParameters);

            ExecuteAsyncOperation(context, operation);
        }
    }
}
