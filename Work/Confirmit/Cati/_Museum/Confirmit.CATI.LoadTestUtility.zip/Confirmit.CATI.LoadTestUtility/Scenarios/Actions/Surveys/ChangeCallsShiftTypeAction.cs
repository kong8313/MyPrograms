﻿using Confirmit.CATI.Common;
using Confirmit.CATI.Core.Batch;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.Supervisor.Core.Surveys;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class ChangeCallsShiftTypeAction : BaseCallManagerAction
    {
        public ChangeCallsShiftTypeAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action)
            : base(action)
        {
        }

        public static ChangeCallsShiftTypeAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new ChangeCallsShiftTypeAction(action);
        }

        protected override void Execute(SurveyContext context, BatchParameters batchParameters)
        {
            const int shiftTypeId = -1;
            Logger.Info("ChangeCallsShiftType parameters: shiftTypeId = {0}", shiftTypeId);

            CallManager.ChangeShiftTypeOfCalls(context.Sid, shiftTypeId, batchParameters);
        }
    }
}
