﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Confirmit.CATI.Common;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Interviews
{
    public class CompleteAction : BaseInterviewAction
    {
        public class CompleteParam : NamedParams
        {
            public string Status;

            public CompleteParam(string param)
                : base(param)
            {
                Status = AsString("Status");
            }
        }

        public CompleteParam Params { get; set; }

        public CompleteAction(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action) : base(action) { }

        public static CompleteAction Parse(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action, ParseContext context)
        {
            return new CompleteAction(action)
                       {
                           Params = new CompleteParam(action.Param)
                       };
        }

        public override void Execute(InterviewContext context)
        {
            context.InterviewerWorkflowService.CompleteInterview(context.State, context.InterviewTimingsStopwatch, context.Duration, Params.Status);
        }
    }
}
