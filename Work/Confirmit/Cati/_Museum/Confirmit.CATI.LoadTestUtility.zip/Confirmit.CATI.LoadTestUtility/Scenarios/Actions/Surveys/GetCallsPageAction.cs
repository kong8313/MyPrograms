﻿using System;
using System.Diagnostics;
using System.Linq;
using Confirmit.CATI.Core.ActivityLogging;
using Confirmit.CATI.Core.Paging;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.Supervisor.Classes.CallManagement;
using Confirmit.CATI.Supervisor.Core.Surveys;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class GetCallsPageAction : BaseSurveyAction
    {
        private GetCallsPageParam param;
        public CallManagerParam Param
        {
            get
            {
                return param;
            }
        }

        public GetCallsPageAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action)
        {
            param = new GetCallsPageParam(action.Param);
        }

        public static GetCallsPageAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new GetCallsPageAction(action);
        }

        public override void Execute(SurveyContext context)
        {
            var pagingArgs = new PagingArgs
                {
                    PageIndex = CallManagerTools.GetPageIndexes(1, 5, Param.PageSelectType).Single(),
                    PageSize = Param.PageSize,
                    SortField = param.OrderColumn,
                    SearchParameters = new SearchParameterCollection()
                };

            int totalCount;
            
            var filterId = GetFilterIdByName(context, Param.FilterName + context.Sid);

            var evt = new ViewCallListEvent(
                    context.Sid,
                    context.Name,
                    filterId,
                    Param.FilterMode.ToString(),
                    "",
                    pagingArgs,
                    "1",
                    Enumerable.Empty<string>());

            try
            {
                var res = CallHelper.GetCallsPage(context.Sid, filterId, CallManagerTools.GetTimezoneId(), Param.FilterMode, pagingArgs, out totalCount,
                                                  ShowTimeMode.Interviewer, false, param.OutputColumns);
                evt.ObjectId = res.Rows.Count;
            }
            catch(Exception ex)
            {
                Trace.TraceError(ex.ToString());
                evt.ObjectId = -1;
            }

            evt.Finish();
        }
    }
}
