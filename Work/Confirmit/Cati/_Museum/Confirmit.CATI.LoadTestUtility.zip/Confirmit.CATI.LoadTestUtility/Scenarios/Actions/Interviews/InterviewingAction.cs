﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Text;
using System.Threading;
using Confirmit.CATI.Common.Random;
using Confirmit.CATI.Core.DAL.Generated.Procedure.Adapter;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Interviews
{
    public class InterviewingAction : BaseInterviewAction
    {
        public class InterviewingParam : NamedParams
        {
            public int Answers;
            public RandomTimeSpanParam Duration;

            public InterviewingParam(string param):base(param)
            {
                Answers = AsInt("Answers");
                Duration = AsRandomTimeSpan("Duration");
            }
        }

        public InterviewingParam Params { get; set; }

        public InterviewingAction(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action):base(action){}

        public static InterviewingAction Parse(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action, ParseContext context)
        {
            return new InterviewingAction(action)
                       {
                           Params = new InterviewingParam(action.Param)
                       };
        }

        public override void Execute(InterviewContext context)
        {
            //At this stage we've got a first page.
            context.MonitoringService.SendInterviewingInitial(context.State.InterviewProperties.DeferredRecordId);

            InsertInterviewRecords(context.State.InterviewProperties.SurveyId, context.State.InterviewProperties.InterviewId, context.Survey.Tables);

            var fields = context.Survey.Scenario.SchemaInfo.FieldsList;

            TimeSpan duration = Params.Duration.Value;
            TimeSpan answerDuration = duration;

            if (fields.Count > 0)
            {
                answerDuration = TimeSpan.FromMilliseconds(duration.TotalMilliseconds / fields.Count);

                for (int index = 0; index < Params.Answers; index++)
                {
                    var field = fields[index%fields.Count];
                    ShowQuestion(context, field, index + 1);

                    EnterAnswer(context, field, DateTime.UtcNow + answerDuration);

                    UpdateAnswer(context, field);
                }
            }
            else
            {
                Thread.Sleep(duration);
            }

            FinishInterview(context, answerDuration, duration);
        }

        private void ShowQuestion(InterviewContext context, SurveySchema.FieldInfo field, int index)
        {
            context.MonitoringService.SendQuestionSelected(index);
            
            var sw = Stopwatch.StartNew();
            
            BvSpTask_UpdateActiveQuestionAdapter.ExecuteNonQuery(
                context.State.InterviewProperties.SurveyId, context.User.Sid, field.Name, DateTime.UtcNow);
            
            PerformanceCounters.AverageOfActiveQuestionUpdateDurationPerformanceCounter.IncrementBy(sw.Elapsed);
            PerformanceCounters.RateOfActiveQuestionUpdatePerSecondPerformanceCounter.Increment();
        }

        private void EnterAnswer(InterviewContext context, SurveySchema.FieldInfo field, DateTime finishUtcTime)
        {
            //Simulate some answers

            context.MonitoringService.StartAnswering();
            do
            {
                var answer = field.Precodes[context.State.InterviewProperties.InterviewId % field.Precodes.Length];
                context.MonitoringService.SendAnswerEntered(field.Name, answer);

                int timeout = Randomizer.Next(10, 100);
                if (!Wait(timeout, finishUtcTime))
                {
                    break;
                }
            }
            while (true);
        }

        private bool Wait(int timeout, DateTime deadTime)
        {
            int estimatedTime = (int)(deadTime - DateTime.UtcNow).TotalMilliseconds;

            if (timeout > estimatedTime)
            {
                Wait(estimatedTime);
                return false;
            }

            Wait(timeout);
            return true;
        }

        private void Wait(int timeout)
        {
            if (timeout < 0) return;
            Thread.Sleep(timeout);
        }

        private void UpdateAnswer(InterviewContext context, SurveySchema.FieldInfo field)
        {
            context.MonitoringService.SendDocumentCompleted();
            var precode = field.Precodes[context.State.InterviewProperties.InterviewId % field.Precodes.Length];
            UpdateQuestion(context.State.InterviewProperties.SurveyId, context.State.InterviewProperties.InterviewId, context.Survey.FieldToTableMap[field.Name], field.Name, precode);
            //Trace.TraceInformation("{0}: Person answered on question with name = '{1}'", this.User.Login, field.Name);
        }

        public static void InsertInterviewRecords(string projectId, int interviewId, string[] tables)
        {
            var query = new StringBuilder(@"
insert into response_control( respid, its ) VALUES(@respId, 16)
declare @responseId INT = @@IDENTITY");

            foreach (var table in tables)
            {
                query.AppendFormat("\r\n insert into [{0}]( responseid, respid ) VALUES( @responseId, @respId)", table);
            }
            DatabaseEngines.Survey(projectId).ExecuteNonQuery(query.ToString(),
                CommandType.Text,
                new SqlParameter("respId", interviewId));
        }

        public static void UpdateQuestion(string projectId, int interviewId, string table, string field, string precode)
        {
            DatabaseEngines.Survey(projectId).ExecuteNonQuery(
                String.Format("UPDATE [{0}] SET [{1}] = @precode WHERE respId = @respId", table, field),
                CommandType.Text,
                new SqlParameter("@precode", precode),
                new SqlParameter("@respId", interviewId));
        }

        private void FinishInterview(InterviewContext context, TimeSpan answer, TimeSpan duration)
        {
            DatabaseEngines.Survey(context.State.InterviewProperties.SurveyId).ExecuteNonQuery(
@"UPDATE respondent 
    SET CallAttemptCount = ISNULL( CallAttemptCount, 0 ) + 1,
        AnswerDuration = @AnswerDuration, 
        InterviewDuration = @InterviewDuration
    WHERE respid = @respid",
               CommandType.Text,
               new SqlParameter("@AnswerDuration", (int)answer.TotalMilliseconds),
               new SqlParameter("@InterviewDuration", (int)duration.TotalMilliseconds),
               new SqlParameter("@respid", context.State.InterviewProperties.InterviewId));
        }
    }
}
