﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

using Confirmit.CATI.Common;
using Confirmit.CATI.Core.AsyncOperations.Framework;
using Confirmit.CATI.Core.Batch;
using Confirmit.CATI.Core.DAL.Generated.Entity.Table;
using Confirmit.CATI.Core.Repositories;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public abstract class BaseCallManagerAction : BaseSurveyAction
    {
        protected string strParam;
        public TimeSpan Duration { get; protected set; }
        public EnumAction Operation { get; protected set; }

        protected abstract void Execute(SurveyContext context, BatchParameters batchParameters);

        public virtual CallManagerParam Param
        {
            get
            {
                return new CallManagerParam(strParam);
            }
        }

        public BaseCallManagerAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action)
            : base(action)
        {
            strParam = action.Param;
            Operation = action.Action;
        }

        public override void Execute(SurveyContext context)
        {
            if (!String.IsNullOrEmpty(Param.FilterName))
            {
                var filterId = GetFilterIdByName(context, Param.FilterName + context.Sid);
                var batchParameters = new FilteredBatchParameters( context.Sid, filterId, 1, Param.FilterMode, null);
                Execute(context, batchParameters);
            }
            else
            {
                foreach( var batch in GetSelectBatches(context))
                {
                    if (batch.Length <= 0)
                    {
                        Logger.Info("Operation {0} ignored, because no interviews on {1} view", Operation, Param.FilterMode);
                        return;
                    }

                    var batchParameters = new SelectedBatchParameters(batch);
                    Execute(context, batchParameters);
                }
            }
        }

        protected void ExecuteAsyncOperation(SurveyContext context, BvAsyncOperationQueueEntity operation)
        {
            operation = new AsyncOperationAwaiter().Await(operation);

            switch( (AsyncOperationState)operation.State)
            {
                case AsyncOperationState.Completed:
                    Logger.Info(String.Format("operation '{0}' is completed", operation.Title));
                    break;
                case AsyncOperationState.PartiallyCompleted:
                    Logger.Warn(String.Format("operation '{0}' is partially completed", operation.Title));
                    break;
                case AsyncOperationState.Aborted:
                    Logger.Warn(String.Format("operation '{0}' is aborted", operation.Title));
                    break;
                case AsyncOperationState.Failed:
                    Logger.Error(String.Format("operation '{0}' is failed", operation.Title));
                    break;
                default:
                    Logger.Error(String.Format("operation '{0}' is completed which unknown state {1}", operation.Title, operation.State));
                    break;
            }
        }
        
        private IEnumerable<int[]> GetSelectBatches(SurveyContext context)
        {
            int[] pageIndexes = GetPageIndexes(context.Sid);

            List<int> interviewIds;
            if (Duration > TimeSpan.Zero)
            {
                foreach (var index in ArrayTools.EnumerateCollectionInTime(pageIndexes, Duration))
                {
                    interviewIds = new List<int>();
                    CallManagerTools.AddInterviewIdsToList(interviewIds, Param, context.Sid, index);

                    yield return interviewIds.ToArray();
                }
            }
            else
            {
                interviewIds = new List<int>();
                foreach (int pageIndex in pageIndexes)
                {
                    CallManagerTools.AddInterviewIdsToList(interviewIds, Param, context.Sid, pageIndex);
                }

                yield return interviewIds.ToArray();
            }
        }

        private int[] GetPageIndexes(int sid)
        {
            int totalPageCount = CallManagerTools.GetTotalPageCount(Param, sid);
            return CallManagerTools.GetPageIndexes(Param.PageCount, totalPageCount, Param.PageSelectType);

        }
    }
}
