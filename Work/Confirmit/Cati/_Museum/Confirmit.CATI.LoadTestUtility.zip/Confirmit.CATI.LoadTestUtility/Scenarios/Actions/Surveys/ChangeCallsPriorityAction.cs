﻿using Confirmit.CATI.Common.Random;
using Confirmit.CATI.Core.Batch;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.Supervisor.Core.Surveys;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class ChangeCallsPriorityAction : BaseCallManagerAction
    {
        public ChangeCallsPriorityAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action)
            : base(action)
        {
        }

        public static ChangeCallsPriorityAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new ChangeCallsPriorityAction(action);
        }

        protected override void Execute(SurveyContext context, BatchParameters batchParameters)
        {
            var priority = Randomizer.Next(1, int.MaxValue);
            
            Logger.Info("ChangeCallsPriority parameters: priority = {0}", priority);

            var operation = CallManager.ChangeCallsPriority(context.Sid, priority, batchParameters);
            
            ExecuteAsyncOperation(context, operation);
        }

    }
}
