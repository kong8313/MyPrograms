﻿using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class SetEventAction : BaseSurveyAction
    {
        public SyncEvent Event { get; private set; }

        public SetEventAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action):base(action){}

        public static SetEventAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new SetEventAction(action)
                       {
                           Event = new SyncEvent(action.Param)
                       };

        }

        public override void Execute(SurveyContext context)
        {
            Event.Set();
        }
    }
}
