﻿using System;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    class OpenCellsAction : BaseChangeCellsAction
    {
        public OpenCellsAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action)
        {
        }

        public static OpenCellsAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new OpenCellsAction(action)
                       {
                           Params = new BaseChangeCellsParam(action.Param),
                           IsOpen = true
                       };
        }
    }
}
