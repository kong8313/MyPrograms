﻿using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class ResetEventAction : BaseSurveyAction
    {
        public ResetEventAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action) { }

        public SyncEvent Event { get; private set; }

        public static ResetEventAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new ResetEventAction(action)
                       {
                           Event = new SyncEvent(action.Param)
                       };

        }

        public override void Execute(SurveyContext context)
        {
            Event.Reset();
        }
    }
}
