﻿using System;
using System.Threading;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class SleepAction : BaseSurveyAction
    {
        public SleepAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action) { }

        public RandomIntParam Timeout;

        public static SleepAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new SleepAction(action)
                       {
                           Timeout = new RandomIntParam(action.Param)
                       };

        }

        public override void Execute(SurveyContext context)
        {
            var timeout = Timeout.Value;
            Logger.Info("Sleep to {0} minutes", timeout);
            Thread.Sleep(TimeSpan.FromMinutes(timeout));
            Logger.Info("Wake up after {0} minutes of sleep", timeout);
        }
    }
}
