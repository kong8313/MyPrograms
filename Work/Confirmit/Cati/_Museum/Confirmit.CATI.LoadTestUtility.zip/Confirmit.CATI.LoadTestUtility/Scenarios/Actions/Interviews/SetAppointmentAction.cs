﻿using System;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Interviews
{
    public class SetAppointmentAction : BaseInterviewAction
    {
        public class SetAppointmentParam : NamedParams
        {
            public RandomTimeSpanParam Time;

            public SetAppointmentParam(string param)
                : base(param)
            {
                Time = AsRandomTimeSpan("Time");
            }
        }

        public SetAppointmentParam Params { get; private set; }

        public SetAppointmentAction(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action) : base(action) { }

        public static SetAppointmentAction Parse(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action, ParseContext context)
        {
            return new SetAppointmentAction(action)
                       {
                           Params = new SetAppointmentParam(action.Param)
                       };
        }

        public override void Execute(InterviewContext context)
        {
            PerformanceCounters.RateOfAppointmentPerSecondPerformanceCounter.Increment();
            var time = Params.Time.Value;
            context.ConsoleService.SetInterviewAppointmentList(
                context.State.InterviewProperties.SurveyId, 
                context.State.InterviewProperties.InterviewId, 
                new[]{ new Appointment
                           {
                              projectID = context.State.InterviewProperties.SurveyId,
                              InterviewId = context.State.InterviewProperties.InterviewId,
                              contactName = "contactName",
                              expirationTime = null,
                              projectName = context.State.InterviewProperties.SurveyId,
                              state = 0,
                              appointmentTimeZone = null,
                              id = 0,
                              time = DateTime.UtcNow + time
                           }},
                true );
            Logger.Info("Set appointemt in: {0}", time);
        }
    }
}
