﻿using System;
using System.Threading;
using Confirmit.CATI.Common;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Services;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class AddSampleAction : BaseSurveyAction
    {
        public AddSampleAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action) { }

        public string Path;

        public static AddSampleAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new AddSampleAction(action)
            {
                Path = context.ResolvePath(action.Param)
            };
        }

        public override void Execute(SurveyContext context)
        {
            Logger.Info("Preparing sample batch from file '{0}' ...", Path);
            var batchId = TestDataInitializer.InitializeSampleBatch(context, Path, out var count);

            Logger.Info("Adding sample batch with size {0} ...", count);
            ManagementServices.AddSample(context.ProjectId, batchId, (int)SchedulingMode.Simple, count);

            ProcessSampleAsyncResult state;
            do
            {
                state = (ProcessSampleAsyncResult)ManagementServices.AddSampleGetState(batchId);
                Thread.Sleep(TimeSpan.FromSeconds(2));
            }
            while (state == ProcessSampleAsyncResult.InProgress);

            if (state != ProcessSampleAsyncResult.Success)
            {
                Logger.Exception("Add sample  failed. AddSampleAsyncResult is {0}", state);
            }

            Logger.Info("Sample with {0} records was added", count);
        }
    }
}
