﻿using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Core.SupervisorService;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    class OpenSurveyAction : BaseSurveyAction
    {
        public OpenSurveyAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action)
            : base(action)
        {
        }

        public override void Execute(SurveyContext context)
        {
            ServiceLocator.Resolve<ISupervisorServiceClient>().OpenSurvey(context.Sid);
        }

        public static OpenSurveyAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new OpenSurveyAction(action);
        }
    }
}
