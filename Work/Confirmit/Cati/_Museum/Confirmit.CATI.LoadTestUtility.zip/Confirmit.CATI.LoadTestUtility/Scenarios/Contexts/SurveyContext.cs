﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Confirmit.CATI.LoadTestUtility.Survey;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Contexts
{
    public class SurveyContext : SurveyInfo
    {
    }
}
