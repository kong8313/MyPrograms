﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Contexts
{
    public class UtilityContext
    {
    }
}
