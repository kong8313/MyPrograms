﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;

namespace Confirmit.CATI.LoadTestUtility.Scenarios
{
    public class SurveyScenario : Scenario<SurveyContext>
    {
        public class QuotaConfig
        {
            public string Name { get; set; }

            public bool Balancing { get; set; }

            public bool UpdateCounter { get; set; }

            public QuotaTargetFunc TargetFunc { get; set; }

            public int TargetArg { get; set; }

            public string[] BalancingFields { get; set; }

            public int PromotionThreshold { get; set; }

            public bool Clustering;

            public int LiveThreshold;
        }

        public SurveyScenario(string name) : base(name) { }

        public bool Enabled { get; set; }

        public string SchemaXml { get; set; }

        public SurveySchema SchemaInfo { get; set; }

        public QuotaConfig[] Quotas { get; set; }

        public InterviewScenario[] InterviewScenarios { get; set; }

        public int InterviewScenarioWeight { get; set; }
    }
}
