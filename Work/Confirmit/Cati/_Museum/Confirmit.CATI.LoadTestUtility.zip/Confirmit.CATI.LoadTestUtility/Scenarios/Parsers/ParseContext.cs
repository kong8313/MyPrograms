using System.IO;
using System.Linq;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Parsers
{
    public class ParseContext
    {
        public string ConfigPath { get; set; }

        public string FolderPath { get; set; }

        public TestConfigurationXmlModel Config { get; set; }

        public UtilityScenario Scenario { get; set; }

        public string ResolvePath(string path)
        {
            if (File.Exists(path))
                return Path.GetFullPath(path);
            
            var configRelatedPath = Path.Combine(FolderPath, path);

            if (File.Exists(configRelatedPath))
                return Path.GetFullPath(configRelatedPath);

            throw Logger.Exception("Can't resolve {0} path. File not found.", path);
        }

        internal InterviewScenario ResolveInterviewScenario(string name)
        {
            var scenario = Scenario.InterviewScenarios.SingleOrDefault(x => x.Name == name);

            if (scenario == null)
                throw Logger.Exception("interview scenarion with name {0} isn'not found", name);

            return scenario;
        }
    }
}