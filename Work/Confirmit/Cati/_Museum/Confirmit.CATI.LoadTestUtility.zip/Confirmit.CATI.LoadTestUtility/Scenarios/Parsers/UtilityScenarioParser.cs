﻿using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Serialization;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Parsers
{
    public class UtilityScenarioParser
    {
        public string ConfigPath { get; private set; }
        public string FolderPath { get; private set; }
        private readonly RunAction _executionMode;

        public UtilityScenarioParser(string path, string executionMode)
        {
            ConfigPath = path;
            FolderPath = Path.GetDirectoryName(Path.GetFullPath(path));
            _executionMode = (RunAction)Enum.Parse(typeof(RunAction), executionMode);
        }

        public UtilityScenario Parse()
        {
            TestConfigurationXmlModel config;
            var xs = new XmlSerializer(typeof(TestConfigurationXmlModel));
            var text = File.ReadAllText(ConfigPath);

            text = AddLineNumberAttributesToXmlElements(text);

            using (var sr = new StringReader(text))
            {
                config = (TestConfigurationXmlModel)xs.Deserialize(sr);
            }

            var context = new ParseContext
            {
                ConfigPath = ConfigPath,
                FolderPath = FolderPath,
                Config = config
            }; 
            
            var scenario = new UtilityScenario
            {
                AdministratorsCount = config.TotalSurvey,
                ExecutionMode = _executionMode
            };

            context.Scenario = scenario;

            foreach (var interview in config.InterviewScenarios)
            {
                scenario.InterviewScenarios.Add(new InterviewScenarioParser(interview, context).Parse());
            }

            foreach (var survey in config.SurveyScenarios)
            {
                scenario.SurveyScenarios.Add(new SurveyScenarioParser(survey, context).Parse(_executionMode));
            }

            return scenario;
        }

        private string AddLineNumberAttributesToXmlElements(string text)
        {
            var regex = new Regex(@"\<\w+\s");
            return regex.Replace(text, (match) =>
            {
                //@"\1 LineNumber=""1"" "
                return String.Format( "{0} LineNumber=\"{1}\" ",  match.Value, text.Substring(0, match.Index).Count(x => x == '\n') + 1);
            });
        }
    }
}
