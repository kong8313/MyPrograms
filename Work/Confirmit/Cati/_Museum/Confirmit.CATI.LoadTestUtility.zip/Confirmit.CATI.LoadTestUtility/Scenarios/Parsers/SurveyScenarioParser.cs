using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Actions;
using Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Parsers
{
    public class SurveyScenarioParser
    {
        public TestConfigurationXmlModel.SurveyScenario Survey { get; set; }
        public ParseContext Context;

        public SurveyScenarioParser(TestConfigurationXmlModel.SurveyScenario survey, ParseContext context)
        {
            Survey = survey;
            Context = context;
        }

        public SurveyScenario Parse(RunAction executionMode)
        {
            var schemaPath = Context.ResolvePath(Survey.SchemaPath);
            var schema = new SurveySchemaReader().Load(schemaPath);
            var interviewScenarios = Survey.InterviewScenarios != null ?  
                                        Survey.InterviewScenarios.Split(',').Select(x => Context.ResolveInterviewScenario(x)).ToArray() :
                                        new[]{ InterviewScenario.GetDefault(Context.Config, schema) };


            var scenario = new SurveyScenario(Survey.Name)
                               {
                                   Enabled = Survey.Enable,
                                   SchemaXml = File.ReadAllText(schemaPath),
                                   SchemaInfo = schema,
                                   Quotas = Survey.Quotas.Select(ParseSurveyQuota).ToArray(),
                                   InterviewScenarios = interviewScenarios,
                                   InterviewScenarioWeight = interviewScenarios.Sum(x => x.Weight)
                               };

            ParseActions(scenario, executionMode == RunAction.Test ? Survey.TestActions : Survey.PrepareActions, Context);

            return scenario;

        }

        SurveyScenario.QuotaConfig ParseSurveyQuota( TestConfigurationXmlModel.SurveyScenario.SurveyQuota quota)
        {
            return new SurveyScenario.QuotaConfig
                {
                    Name = quota.Name,
                    Balancing = quota.Balancing,
                    UpdateCounter = quota.UpdateCounter,
                    TargetFunc = quota.TargetFunc,
                    TargetArg = quota.TargetArg,
                    BalancingFields = quota.BalancingFields.Split(new[]{','}, StringSplitOptions.RemoveEmptyEntries),
                    PromotionThreshold = quota.PromotionThreshold,
                    Clustering = quota.Clustering,
                    LiveThreshold = quota.LiveThreshold
                };
        }


        private static Dictionary<EnumAction, Func<TestConfigurationXmlModel.SurveyScenario.SurveyAction, ParseContext, BaseSurveyAction>> ActionFactories = 
            new Dictionary<EnumAction, Func<TestConfigurationXmlModel.SurveyScenario.SurveyAction, ParseContext, BaseSurveyAction>>()
                {
                    {EnumAction.OpenSurvey, OpenSurveyAction.Parse},
                    {EnumAction.CloseSurvey, CloseSurveyAction.Parse},
                    {EnumAction.LaunchSurvey, LaunchSurveyAction.Parse},
                    {EnumAction.AddSample, AddSampleAction.Parse},
                    {EnumAction.SyncRespondentData, SyncRespondentDataAction.Parse},
                    {EnumAction.Sleep, SleepAction.Parse},
                    {EnumAction.CloseCells, CloseCellsAction.Parse},
                    {EnumAction.OpenCells, OpenCellsAction.Parse},
                    {EnumAction.MoveCalls, MoveCallsAction.Parse},
                    {EnumAction.MoveAndRescheduleCalls, MoveAndRescheduleCallsAction.Parse},
                    {EnumAction.ChangeCallsPriority, ChangeCallsPriorityAction.Parse},
                    {EnumAction.ChangeCallsShiftType, ChangeCallsShiftTypeAction.Parse},
                    {EnumAction.ActivateCalls, ActivateCallsAction.Parse},
                    {EnumAction.AssignCalls, AssignCallsAction.Parse},
                    {EnumAction.GeneralReport, GeneralReportAction.Parse},
                    {EnumAction.Sync, SyncAction.Parse},
                    {EnumAction.ExecSql, ExecSqlAction.Parse},
                    {EnumAction.SetEvent, SetEventAction.Parse},
                    {EnumAction.ResetEvent, ResetEventAction.Parse},
                    {EnumAction.GetCallsPage, GetCallsPageAction.Parse},
                    {EnumAction.CreateFilter, CreateFilterAction.Parse},
                    {EnumAction.OptimisticFcdTest, OptimisticFcdTestAction.Parse},
                };

        public static void ParseActions(Scenario<SurveyContext> scenario, List<TestConfigurationXmlModel.SurveyScenario.SurveyAction> actions, ParseContext context)
        {
            foreach (var actionInfo in actions)
            {
                if( !ActionFactories.ContainsKey(actionInfo.Action))
                {
                    Logger.Error("Wrong action type of action:{0}", actionInfo);
                    continue;
                }

                Logger.Info("Parse action: {0}, Params={1}, Line={2}", actionInfo.Action, actionInfo.Param, actionInfo.LineNumber);
                ISurveyAction action = ActionFactories[actionInfo.Action](actionInfo, context);
                scenario.Add(action);
            }
        }
    }
}