﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Actions;
using Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Interviews;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;

namespace Confirmit.CATI.LoadTestUtility.Scenarios
{
    public class InterviewScenario : Scenario<InterviewContext>
    {
        static public InterviewScenario GetDefault(TestConfigurationXmlModel config, SurveySchema schema)
        {
            var scenrio = new InterviewScenario("@Default");
            var interval = config.LoadScenario.First();
            var interviewingParams = $"Answers={schema.FieldsList.Count},Duration=4s-8s";
            var completeParams = "status=13";
            scenrio.AddRange(new BaseInterviewAction[]
            {
                new InterviewingAction(
                    new TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction()
                    {
                        Type = InterviewScenarioActionType.Interviewing, 
                        Param = interviewingParams
                    })
                    {
                        Params = new InterviewingAction.InterviewingParam(interviewingParams)
                    },
                new CompleteAction(
                    new TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction()
                    {
                        Type = InterviewScenarioActionType.Complete,
                        Param = completeParams
                    })
                    {
                        Params = new CompleteAction.CompleteParam(completeParams)
                    }

            });

            return scenrio;
        }

        public int Weight { get; set; }

        public InterviewScenario(string name) : base(name)
        {
            
        }
    }
}
