﻿using System;
using System.IO;

using Confirmit.CATI.Core.ActivityLogging;

namespace Confirmit.CATI.LoadTestUtility.ActivityEvents
{
    [Serializable]
    public class StartLoadTestEventParameters : ManagementActivityEventDetails
    {
        public string Area;
        public string Config;
    }

    public class StartLoadTestEvent : ManagementActivityEvent<StartLoadTestEventParameters>
    {
        public StartLoadTestEvent(string configFile, string area) :
            base(ManagementEventCategory.System, (ManagementEvent)LoadTestManagementEvent.StartLoadTest)
        {
            ObjectId = 0;
            ObjectName = Path.GetFileName(configFile);
            Details = new StartLoadTestEventParameters 
            {
                Config = File.ReadAllText(configFile),
                Area = area
            };
        }
    }
}
