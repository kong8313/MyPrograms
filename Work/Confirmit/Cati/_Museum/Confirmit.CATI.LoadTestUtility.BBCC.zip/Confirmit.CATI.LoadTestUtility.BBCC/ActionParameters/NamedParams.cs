using System;
using System.Collections.Generic;
using System.Linq;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.ActionParameters
{
    public class NamedParams
    {
        public Dictionary<string, string> Params = new Dictionary<string,string>();

        public NamedParams(string param)
        {
            if (String.IsNullOrEmpty(param))
                return;

            Params = param.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                            .Select(x => x.Split('='))
                            .ToDictionary(x => x[0].Trim().ToLower(), y => y[1].Trim());
        }

        private string GetParam(string name)
        {
            return Params[name.ToLower()];
        }

        private string GetParamOrDefault(string name, string defaultValue)
        {
            if (Params.TryGetValue(name.ToLower(), out var value))
            {
                return value;
            }

            return defaultValue;
        }

        protected int AsInt(string name)
        {
            return Int32.Parse(GetParam(name));
        }

        

        public bool AsBool(string  name)
        {
            return bool.Parse(GetParam(name));
        }

        public T AsEnum<T>(string name)
        {
            return (T)Enum.Parse(typeof(T), GetParam(name));
        }

        public string AsString( string name)
        {
            return GetParamOrDefault(name, null);
        }

        public TimeSpan AsTimeSpan( string name)
        {
            return ToTimeSpan(GetParam(name));
        }

        public static TimeSpan ToTimeSpan(string param)
        {
            try
            {
                switch (param.Last())
                {
                    case 's':
                        return TimeSpan.FromSeconds(Int32.Parse(param.Substring(0, param.Length - 1)));
                    case 'm':
                        return TimeSpan.FromMinutes(Int32.Parse(param.Substring(0, param.Length - 1)));
                    case 'h':
                        return TimeSpan.FromHours(Int32.Parse(param.Substring(0, param.Length - 1)));
                    default:
                        return TimeSpan.FromSeconds(Int32.Parse(param.Substring(0, param.Length - 0)));
                }
            }
            catch (Exception ex)
            {
                throw new Logger().Exception("Invalid duration format: {0} : {1}", param, ex);
            }
        }

        public static RandomTimeSpanParam ToRandomTimeSpan(string param)
        {
            try
            {
                var args = param.Split('-');
                if (args.Length == 1)
                {
                    var val = ToTimeSpan(args[0]);
                    return new RandomTimeSpanParam(val, val);
                }

                if (args.Length == 2)
                {
                    return new RandomTimeSpanParam(ToTimeSpan(args[0]), ToTimeSpan(args[1]));
                }
            }
            catch (Exception ex)
            {
                throw new Logger().Exception("Invalid random duration format: {0} ; {1}", param, ex);
            }

            throw new Logger().Exception("Invalid random duration format: {0}", param);
        }

        public RandomTimeSpanParam AsRandomTimeSpan(string name)
        {
            var param = GetParam(name);
            return ToRandomTimeSpan(param);
        }

        
    }
}