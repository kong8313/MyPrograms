using System;
using System.Linq;
using System.Threading;
using Confirmit.CATI.Common.Random;
using Confirmit.CATI.Core.ManagementService;
using Confirmit.CATI.Core.Repositories.Interfaces;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.LoadTestUtility.Scenarios;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Services;
using Confirmit.CATI.LoadTestUtility.Survey;
using Confirmit.CATI.LoadTestUtility.Tools;

using ConfirmitDialerInterface;

using InterviewControlData = Confirmit.CATI.Core.ManagementService.InterviewControlData;
using MonitoringService = Confirmit.CATI.LoadTestUtility.Tools.MonitoringService;
using Confirmit.CATI.LoadTestUtility.CatiInterviewerApi;
using System.Threading.Tasks;
using SocketIOClient;
using SocketIOClient.JsonSerializer;
using System.Text.Json.Serialization;
using System.Text.Json;
using Confirmit.CATI.Core.Misc;

namespace Confirmit.CATI.LoadTestUtility.WorkflowServices
{
    public class InterviewerWorkflowService
    {
        // Thread control fields
        private Task ExecutionTask { get; set; }

        private int RotationIndex { get; set; }

        // Person info
        private UserInfo User { get; set; }

        // Load interval info
        private TestConfiguration.LoadInterval LoadInterval { get; set; }
        
        // Console state
        private string SelectedProjectId { get; set; }

        private readonly IInterviewerApiClient _interviewerApiClient;

        private MonitoringService _monitoring;
        private InterviewTimingsStopwatch _interviewTimer;

        private int _processedInterviewId;
        private int _processedEtag = -1;
        private bool _isTelephonyConfigured = false;
        private readonly SemaphoreSlim _selectSurveySemaphoreSlim = new SemaphoreSlim(1, 1);
        private readonly SemaphoreSlim _interviewingSemaphoreSlim = new SemaphoreSlim(1, 1);
        private readonly SemaphoreSlim _configureTelephonySemaphoreSlim = new SemaphoreSlim(1, 1);
        
        private readonly Logger _logger;
        
        public class UserInfo
        {
            public int Index { get; set; }

            public string Login { get; set; }

            public string Password { get; set; }

            public int Sid { get; set; }

            public AgentTaskChoiceMode TaskChoice { get; set; }

            public int UsedCallGroupId { get; set; }
        }

        private enum ActiveState
        {
            Stoped = 0,
            PendingActivate = 1,
            Activated = 2,
            PendingStop = 3
        }

        class AuthInfo
        {
            [JsonPropertyName("protocolVersion")]
            public string ProtocolVersion { get; set; }

            [JsonPropertyName("token")]
            public string Token { get; set; }
        }

        private SocketIO _client;

        private ActiveState State { get; set; }
        CancellationTokenSource _tokenSource;

        public InterviewerWorkflowService(int id, int parentGroup, AgentTaskChoiceMode mode, bool useCallGroup)
        {
            _interviewerApiClient = ServiceLocator.Resolve<IInterviewerApiClient>();

            RotationIndex = id;

            int callGroupId = 0;
            if( useCallGroup )
            {
                var groups = ServiceLocator.Resolve<ICallGroupRepository>().GetAllGroups();
                if (groups.Count > 0)
                {
                    callGroupId = groups[Randomizer.Next(groups.Count)].Id;
                }
                else
                {
                    throw new Exception("Call groups is not configured");
                }
            }

            var login = NameMaker.PersonName(mode, id, callGroupId);
            var password = login;

            User = new UserInfo
            {
                Index = id,
                Login = login,
                Password = password,
                TaskChoice = mode,
                UsedCallGroupId = callGroupId,
                Sid = BackendTools.CreatePerson(login, password, mode, new[] {parentGroup})
            };

            State = ActiveState.Stoped;
            _logger = new Logger(login);
            _interviewerApiClient.SetLogger(_logger);
        }
       
        internal bool OnActivate(TestConfiguration.LoadInterval interval)
        {
            lock (this)
            {
                LoadInterval = interval;

                if (State != ActiveState.Stoped)
                {
                    _logger.Info($"Return from OnActivate because State is {State}");
                    return false;
                }

                State = ActiveState.PendingActivate;

                _tokenSource = new CancellationTokenSource();                
                ExecutionTask = new TaskFactory().StartNew(ProcessThread, _tokenSource.Token);

                _logger.Info("{0}: Person is activating", User.Login);
                return true;
            }
        }

        internal bool OnDeactivateBegin()
        {
            lock (this)
            {
                if (State != ActiveState.Activated)
                {
                    _logger.Info($"Return from OnDeactivateBegin because State is {State}");
                    return false;
                }

                State = ActiveState.PendingStop;

                _logger.Info("{0}: Person is deactivating", User.Login);
                return true;
            }
        }

        internal void OnDeactivateEnd()
        {
            lock (this)
            {
                if (State != ActiveState.PendingStop)
                {
                    _logger.Info($"Return from OnDeactivateEnd because State is {State}");
                    return;
                }

                if (!ExecutionTask.Wait(TimeSpan.FromSeconds(1)))
                {
                    _tokenSource.Cancel();
                    ExecutionTask.Dispose();
                    ExecutionTask = null;
                }

                _logger.Info("{0}: Person has been deactivated", User.Login);
            }
        }

        private async Task ProcessThread()
        {
            PerformanceCounters.NumberOfActiveInterviewersPerformanceCounter.Increment();
            try
            {
                _logger.Info("Person has activated");                    

                await LoginAndStartWebSocketObservation();
            }
            catch (Exception ex)
            {
                _logger.Error("Thread failed at ProcessThread. Exception details: {0}", ex);
            }
        }

        private async Task LoginAndStartWebSocketObservation()
        {
            string stationId = DialerExtensionProvider.GetStationId(User.Sid);

            _monitoring = new MonitoringService(_interviewerApiClient, _logger)
            {
                UserId = User.Sid
            };

            var bearerToken = await _interviewerApiClient.Login(Program.CompanyAlias, User.Login, User.Password, stationId);
            await StartWebSocketObservation(bearerToken);
        }
        

        private async Task StartWebSocketObservation(string bearerToken)
        {
            Uri url = new Uri(AppConfiguration.InterviewerApiBaseUrl);
            var baseAddress = url.Scheme + "://" + url.Authority;

            _client = new SocketIO(baseAddress, new SocketIOOptions
            {
                Path = "/catiinterviewer/api/sockets/notifications",
                EIO = 3
            });

            _client.OnConnected += async (sender, e) =>
            {
                // Emit a string
                await _client.EmitAsync("authentication", new AuthInfo
                {
                    ProtocolVersion = "1",
                    Token = bearerToken
                });
            };

            var jsonSerializer = new SystemTextJsonSerializer
            {
                OptionsProvider = () =>
                    new JsonSerializerOptions
                    {
                        Converters = { new JsonStringEnumConverter() },
                        PropertyNameCaseInsensitive = true
                    }
            };
            _client.JsonSerializer = jsonSerializer;

            _client.On("Console.StateChanged", ConsoleStateChanged);
            _client.On("authenticated", (response) => 
            {
                State = ActiveState.Activated;
                _logger.Info($"Person '{User.Login}' has logged into BBCC");
            });
            _client.On("unauthorized", Unauthorized);

            await _client.ConnectAsync();

            _interviewTimer = new InterviewTimingsStopwatch();
        }

        private async Task StopWebSocketObservation()
        {
            if (_client.Connected)
            {
                await _client.DisconnectAsync();
            }
        }

        private void ConsoleStateChanged(SocketIOResponse response)
        {
            new TaskFactory().StartNew(() => ConsoleStateChangedAsync(response));
        }

        private void Unauthorized(SocketIOResponse response)
        {
            new TaskFactory().StartNew(UnauthorizedAsync);
        }

        private async Task UnauthorizedAsync()
        {
            try
            {
                await StopWebSocketObservation();
                SelectedProjectId = null;
                ExecutionTask = null;
                State = ActiveState.Stoped;
                _processedInterviewId = 0;
                _processedEtag = -1;
                _isTelephonyConfigured = false;

                PerformanceCounters.NumberOfActiveInterviewersPerformanceCounter.Decrement();

                _logger.Info($"Person '{User.Login}' has logged out from BBCC");
            }
            catch (Exception ex)
            {
                _logger.Error("Thread failed at UnauthorizedAsync. Exception details: {0}", ex);
            }
        }

        private async Task ConsoleStateChangedAsync(SocketIOResponse response)
        {
            try
            {
                SocketConsoleState currentState = response.GetValue<SocketConsoleState>();

                if (State != ActiveState.Activated)
                {
                    _logger.Info($"Ignore ConsoleStateChangedAsync action with {currentState.Operation.Type} operation type because State is not Activated");
                    return;
                }
                
                if (_processedEtag == currentState.Etag)
                {
                    _logger.Info($"Ignore ConsoleStateChangedAsync action with {currentState.Operation.Type} operation type because processed etag {currentState.Etag} is the same");
                    return;
                }

                _processedEtag = currentState.Etag;
                
                _logger.Info($"Process {currentState.Operation.Type} action with {_processedEtag} etag");

                switch (currentState.Operation.Type)
                {
                    case SocketOperationType.SelectingSurvey:
                        await _selectSurveySemaphoreSlim.WaitAsync();

                        try
                        {
                            if (SelectedProjectId != null)
                            {
                                _logger.Info("Skip action because a project id has been already selected");
                                return;
                            }

                            var surveys = await _interviewerApiClient.GetSurveys();
                            while (surveys.Count == 0)
                            {
                                const int waitTimeInSecForClosedSurvey = 5;
                                _logger.Info($"Person with SA\\GC mode doesn't have any opened surveys. Wait {waitTimeInSecForClosedSurvey} seconds");
                                Thread.Sleep(TimeSpan.FromSeconds(waitTimeInSecForClosedSurvey));
                                surveys = await _interviewerApiClient.GetSurveys();
                            }

                            SelectedProjectId = surveys[RotationIndex % surveys.Count].ProjectId;
                            await _interviewerApiClient.SelectSurvey(SelectedProjectId);

                            _logger.Info($"Person has selected survey '{SelectedProjectId}'");
                        }
                        finally
                        {
                            _selectSurveySemaphoreSlim.Release();
                        }
                        break;
                    case SocketOperationType.Interviewing:
                        await _interviewingSemaphoreSlim.WaitAsync();

                        try
                        {
                            var info = VerifyStateCorrectness(currentState);
                            if (!string.IsNullOrEmpty(info))
                            {
                                _logger.Info(info);
                                break;
                            }
                            
                            if (_processedInterviewId == currentState.Operation.InterviewId)
                            {
                                _logger.Info($"Skip action because interview {_processedInterviewId} has been already passed");
                                break;
                            }
                            
                            _processedInterviewId = currentState.Operation.InterviewId;
                            _logger.Info($"Start processing of interview with id '{_processedInterviewId}'");
                        }
                        finally
                        {
                            _interviewingSemaphoreSlim.Release();
                        }

                        var etag = currentState.Commands.Single(x => x.Name == "CommitInterviewStart").ETag;
                        await _interviewerApiClient.CommitInterviewStart(etag);

                        _interviewTimer.OnStartInterview();

                        var context = new InterviewContext
                        {
                            MonitoringService = _monitoring,
                            Duration = TimeSpan.Zero,
                            InterviewerWorkflowService = this,
                            InterviewTimingsStopwatch = _interviewTimer,
                            Survey = GlobalSurveyCache.Get(SelectedProjectId),
                            State = currentState,
                            User = User
                        };

                        var scenario = GetInterviewScenario(context);

                        _logger.Info($"Interview ( IS={scenario.Name}, PID={SelectedProjectId}, IID={_processedInterviewId}, WT={_interviewTimer.Elapsed}) was started");

                        //At this state we consider an interview is started.
                        _monitoring.InterviewState = currentState;
                        _monitoring.SendInterviewStartMessage(currentState.Operation.Recording.Id);

                        if (!BackendInstance.IsInitialized)
                        {
                            Program.InitializeBackendInstanceCurrent();
                        }

                        scenario.Execute(context, _logger);

                        if (State != ActiveState.Activated)
                        {
                            await _interviewerApiClient.SetPendingLogout();
                        }
                        break;
                    case SocketOperationType.ConfiguringTelephony:
                        await _configureTelephonySemaphoreSlim.WaitAsync();

                        try
                        {
                            if (_isTelephonyConfigured)
                            {
                                _logger.Info("Skip action because telephony has been already configured");
                                return;
                            }

                            _isTelephonyConfigured = true;
                            _logger.Info("Configuring telephony");
                        }
                        finally
                        {
                            _configureTelephonySemaphoreSlim.Release();
                        }

                        var telEvent = new ConfigureTelephonyEvent
                        {
                            ExtensionNumber = DialerExtensionProvider.GetStationId(User.Sid),
                            Disable = false
                        };

                        await _interviewerApiClient.ConfigureTelephony(telEvent);
                        break;
                    case SocketOperationType.NoCalls:
                        const int waitTimeInSecForNoCalls = 15;
                        _logger.Info($"Wait {waitTimeInSecForNoCalls} seconds because no calls");
                        await Task.Delay(TimeSpan.FromSeconds(waitTimeInSecForNoCalls));
                        break;
                    default:
                        if (currentState.Operation.Type != SocketOperationType.Waiting)
                        {
                            _logger.Info($"Unhandled operation type: {currentState.Operation.Type}");
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                _logger.Error("Thread failed at ConsoleStateChangedAsync. Exception details: {0}", ex);
            }
        }

        private string VerifyStateCorrectness(SocketConsoleState currentState)
        {
            if (currentState == null)
            {
                return $"Skip action because CurrentState object for interview {_processedInterviewId} has not been specified";
            }
            
            if (currentState.Operation == null)
            {
                return $"Skip action because Operation object for interview {_processedInterviewId} has not been specified";
            }
            
            if (currentState.Operation.Recording == null)
            {
                return $"Skip action because Recording object for interview {_processedInterviewId} has not been specified";
            }

            if (string.IsNullOrEmpty(currentState.Operation.ProjectId))
            {
                return $"Skip action because ProjectId for interview {_processedInterviewId} has not been specified";
            }

            if (currentState.Commands == null)
            {
                return $"Skip action because Commands object for interview {_processedInterviewId} has not been specified";
            }

            var commitInterviewStartCommand = currentState.Commands.SingleOrDefault(x => x.Name == "CommitInterviewStart");
            if (commitInterviewStartCommand == null)
            {
                return $"Skip action because Commands object for interview {_processedInterviewId} does not contain CommitInterviewStart command";
            }

            return string.Empty;
        }

        private InterviewScenario GetInterviewScenario(InterviewContext context)
        {
            var weight = Randomizer.Next(context.Survey.Scenario.InterviewScenarioWeight);

            InterviewScenario last = null;
            foreach( var scenario in context.Survey.Scenario.InterviewScenarios )
            {
                last = scenario;
                weight -= scenario.Weight;
                if (weight < 0)
                    return scenario;
            }

            return last;
        }

        public async Task CompleteInterview(int interviewId, string etag, InterviewTimingsStopwatch interviewTimer, TimeSpan growDuration, string status)
        {
            if (State != ActiveState.Activated)
            {
                _logger.Info($"Ignore CompleteInterview action because State is not Activated");
                return;
            }
            
            var timings = interviewTimer.OnStopInterview();
            
            await _interviewerApiClient.CompleteInterview(status, etag);

            IncrementQuotasCounters(interviewId);

            await SendMonitoringInterviewFinishMessageIfNeed();

            SendControlData(interviewId, growDuration, timings.TotalTime, status);

            _logger.Info($"Interview ( PID={SelectedProjectId}, IID={interviewId}, TT={timings.TotalTime}, IT={timings.InterviewwingTime}({growDuration}), WT={timings.WaitingTime}) was finished.");

            PerformanceCounters.RateOfCompletedInterviewsPerSecondPerformanceCounter.Increment();
        }

        private void IncrementQuotasCounters(int interviewId)
        {
            if (State != ActiveState.Activated)
            {
                _logger.Info($"Ignore IncrementQuotasCounters action because State is not Activated");
                return;
            }
            
            var cache = GlobalSurveyCache.Get(SelectedProjectId);
            if (cache.QuotasCache.ShouldBeQuotaCountersUpdated)
            {
                var data = BackendTools.GetInterviewFields(cache.Sid, interviewId, cache.QuotasCache.Fields);
                cache.QuotasCache.IncrementCounters(data);
            }
        }

        private async Task SendMonitoringInterviewFinishMessageIfNeed()
        {
            if (State != ActiveState.Activated)
            {
                _logger.Info($"Ignore SendMonitoringInterviewFinishMessageIfNeed action because State is not Activated");
                return;
            }
            
            await _monitoring.SendInterviewFinish();
        }

        private void SendControlData(int interviewId, TimeSpan growDuration, TimeSpan totalDuration, string status)
        {
            if (State != ActiveState.Activated)
            {
                _logger.Info($"Ignore SendControlData action because State is not Activated");
                return;
            }
            
            var history = new InterviewHistoryData
                {
                    appointmentID = 0,
                    grossDuration = (int)totalDuration.TotalSeconds,

                    // TODO:should be growDuration,but we store only this param( in sec ) to our DB
                    interviewerID = User.Sid,
                    interviewID = interviewId,
                    netDuration = (int)(totalDuration - growDuration).TotalSeconds,
                    projectID = SelectedProjectId,
                    respondentPhone = "0123456789",
                    roleID = 2,
                    status = status,
                    time = DateTime.UtcNow,
                    totalDuration = (int)totalDuration.TotalSeconds,
                };

            var control = new InterviewControlData
                {
                    interviewerID = User.Sid, 
                    interviewID = interviewId, 
                    lastCallTime = DateTime.UtcNow, 
                    projectID = SelectedProjectId, 
                    respondentName = "test respondent", 
                    respondentPhone = "0123456789", 
                    roleID = 2, 
                    status = status, 
                    totalDuration = 0
                };

            ManagementServices.SaveInterviewHistoryAndControlData(history, control);
        }
    }
}
