﻿using System;
using System.Data.SqlClient;
using System.Configuration;

namespace Confirmit.CATI.LoadTestUtility
{
    internal class AppConfiguration
    {
        public static string MultimodeWebServiceURL
        {
            get
            {
                return ConfigurationManager.AppSettings["MultimodeWebServiceURL"];
            }
        }

        public static string InterviewerApiBaseUrl
        {
            get
            {
                return ConfigurationManager.AppSettings["InterviewerApiBaseUrl"];
            }
        }

        public static bool EnableWsLogging
        {
            get
            {
                return Boolean.Parse(ConfigurationManager.AppSettings["EnableWsLogging"]);
            }
        }

        public static string ConnectionStringToBE
        {
            get
            {
                return ConfigurationManager.AppSettings["ConnectionStringToBE"];
            }
        }

        public static string ConnectionStringToCF
        {
            get
            {
                return ConfigurationManager.AppSettings["ConnectionStringToCF"];
            }
        }

        private static string connectionStringToConfirm;
        public static string ConnectionStringToConfirm
        {
            get
            {
                if (connectionStringToConfirm == null)
                {
                    var sb = new SqlConnectionStringBuilder(ConfigurationManager.AppSettings["ConnectionStringToCF"]);
                    sb.InitialCatalog = "confirm";
                    connectionStringToConfirm = sb.ToString();
                }

                return connectionStringToConfirm;
            }
        }

        private static string connectionStringToConfirmLog;
        public static string ConnectionStringToConfirmLog
        {
            get
            {
                if (connectionStringToConfirmLog == null)
                {
                    var sb = new SqlConnectionStringBuilder(ConfigurationManager.AppSettings["ConnectionStringToCF"]);
                    sb.InitialCatalog = "confirmlog";
                    connectionStringToConfirmLog = sb.ToString();
                }

                return connectionStringToConfirmLog;
            }
        }

        public static int CompanyID
        {
            get
            {
                return Int32.Parse(ConfigurationManager.AppSettings["CompanyID"]);
            }
        }

        public static string CompanyAlias
        {
            get
            {
                return ConfigurationManager.AppSettings["CompanyAlias"];
            }
        }

        public static bool ReCreateCompanyIfExists
        {
            get
            {
                return Boolean.Parse(ConfigurationManager.AppSettings["ReCreateCompanyIfExists"]);
            }
        }

        public static int StartSurveyBatchID
        {
            get
            {
                return Int32.Parse(ConfigurationManager.AppSettings["StartSurveyBatchID"]);
            }
        }

        public static string SampleFileName
        {
            get
            {
                return ConfigurationManager.AppSettings["SampleFileName"];
            }
        }

        public static string StationIdMask
        {
            get
            {
                return ConfigurationManager.AppSettings["StationIdMask"];
            }
        }

        public static string StationIdResourcesRange
        {
            get
            {
                return ConfigurationManager.AppSettings["StationIdResourcesRange"];
            }
        }

        public static TimeSpan StateServiceSessionLiveSpan
        {
            get
            {
                return TimeSpan.Parse( ConfigurationManager.AppSettings["StateServiceSessionLiveSpan"] );
            }
        }

        public static string ConfirmitLogin
        {
            get
            {
                return ConfigurationManager.AppSettings["ConfirmitLogin"];
            }
        }

        public static string ConfirmitPassword
        {
            get
            {
                return ConfigurationManager.AppSettings["ConfirmitPassword"];
            }
        }        
    }
}
