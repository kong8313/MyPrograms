﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;

using Confirmit.CATI.Core.Repositories;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Core.Services;
using Confirmit.CATI.Core.Services.Interfaces;
using Confirmit.CATI.LoadTestUtility.ConfirmitSurveyDeployer;
using Confirmit.CATI.LoadTestUtility.Quota;
using Confirmit.CATI.LoadTestUtility.Scenarios;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Services;
using Confirmit.CATI.LoadTestUtility.Survey;
using ConfirmitDialerInterface;
using DatabaseType = Confirmit.CATI.LoadTestUtility.ConfirmitSurveyDeployer.DatabaseType;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    public class SurveyTools
    {
        private static int _topBatchId;

        static SurveyTools()
        {
            _topBatchId = AppConfiguration.StartSurveyBatchID;
        }

        private static string SetNewSchemaName(string schemaXml, string newName)
        {
            const string searchStr = " Name=\"";
            int first = schemaXml.IndexOf(searchStr, StringComparison.Ordinal);
            int second = schemaXml.IndexOf("\"", first + searchStr.Length, StringComparison.Ordinal);
            return schemaXml.Substring(0, first + searchStr.Length) + newName + schemaXml.Substring(second);
        }

        public static void LaunchSurvey(string projectId, GenerateDbOptions generateDbOptions)
        {
            var confirmitKey = ConfirmitServices.Key;

            var taskId = ConfirmitServices.SurveyDeployer.LaunchSurvey(
                confirmitKey,
                projectId,
                DatabaseType.Production,
                generateDbOptions,
                GenerateWiOptions.WiNet);

            TaskStatus state;
            while (true)
            {
                state = ConfirmitServices.SurveyDeployer.GetTaskStatus(confirmitKey, taskId);
                if (state != TaskStatus.Queue && state != TaskStatus.Executing)
                {
                    break;
                }
                Thread.Sleep(TimeSpan.FromMilliseconds(500));
            }

            if (state != TaskStatus.Complete)
            {
                var log = ConfirmitServices.SurveyDeployer.GetTaskLogEntries(confirmitKey, taskId);
                var info = String.Join(
                    Environment.NewLine,
                    log.Select(
                        x =>
                        x.Description +
                        (String.IsNullOrEmpty(x.ExceptionMessage) ? "" : Environment.NewLine + x.ExceptionMessage)).
                        ToArray());
                throw new Exception($"LaunchSurvey task isn't completed, state = {state}, Log:\r\n{info}");
            }
        }

        public static SurveyContext CreateSurveyContext(
            SurveyScenario scenario,
            int autoGroup,
            int saGroup,
            int cgGroup,
            string threadId)
        {
            string schemaXml = SetNewSchemaName(scenario.SchemaXml, threadId);

            var projectId = ConfirmitServices.Authoring.ImportSurvey(ConfirmitServices.Key, schemaXml);

            /* Should work, but doesn't, because an error in Confirmit. Need to wait some time and try use this code again instead of changing in SchemaXml
            var schema = ConfirmitServices.Authoring.GetProjectInfo(confirmitKey, projectId);
            ((ProjectInfo)schema.Root.Nodes[0]).Name = threadId;
            ConfirmitServices.Authoring.Update(confirmitKey, projectId, schema);*/

            var surveyName = NameMaker.SurveyName(projectId, scenario.Name);

            LaunchSurvey(projectId, GenerateDbOptions.CreateNewDatabase);

            var survey = SurveyRepository.GetByName(projectId);
            int surveyId = survey.SID;

            var quotaInfos = QuotaTools.GetQuotaInfo(survey.ProjectId, surveyId, scenario);

            var quotaBalancingService = ServiceLocator.Resolve<IQuotaBalancingService>();
            var balancingConfiguration = quotaBalancingService.GetQuotaBalancingConfiguration(surveyId);
            foreach (var quotaInfo in quotaInfos)
            {
                if (quotaInfo.Config.UpdateCounter)
                {
                    QuotaTools.RecalculateTargets(quotaInfo);
                    QuotaTools.UpdateQuotaCountersInDb(survey.ProjectId, quotaInfo);
                }

                if (quotaInfo.Config.Balancing)
                {
                    balancingConfiguration.Quotas.Single(x => x.QuotaId == quotaInfo.QuotaId).IsEnabled = true;
                    foreach (var field in quotaInfo.Config.BalancingFields)
                    {
                        balancingConfiguration.Fields.Single(x => x.FieldName.Equals(field, StringComparison.OrdinalIgnoreCase)).IsEnabled = true;
                    }
                }

                if (quotaInfo.Config.Clustering)
                {
                    var config = new QuotaClusteringConfiguration()
                                 {
                                     QuotaName = quotaInfo.Config.Name,
                                     LiveThreshod = quotaInfo.Config.LiveThreshold
                                 };
                    ServiceLocator.Resolve<IQuotaClusteringConfigurationService>().Configure(surveyId, config);
                }
            }

            quotaBalancingService.SetQuotaBalancingConfiguration(surveyId, balancingConfiguration);

            //
            // Asingn interviewer groups
            //
            if (scenario.SchemaInfo.Project.DialingMode != DialingMode.Predictive)
            {
                AssignmentService.AssignResourceToSurvey(surveyId, autoGroup, Program.CallCenterId);
                AssignmentService.AssignResourceToSurvey(surveyId, cgGroup, Program.CallCenterId);
                AssignmentService.AssignResourceToSurvey(surveyId, BackendTools.GetInterviewGroup(), Program.CallCenterId);
            }

            AssignmentService.AssignResourceToSurvey(surveyId, saGroup, Program.CallCenterId);

            DatabaseEngines.Survey(survey.ProjectId).ExecuteNonQuery(
@"
if not exists( select 1 from sys.columns where object_id = object_id('respondent') AND name = 'batchid')
begin
	alter table respondent add [batchid] int
end
if not exists( select 1 from sys.columns where object_id = object_id('respondent') AND name = 'AnswerDuration')
begin
	alter table respondent add [AnswerDuration] int
end
if not exists( select 1 from sys.columns where object_id = object_id('respondent') AND name = 'InterviewDuration')
begin
	alter table respondent add [InterviewDuration] int
end", CommandType.Text);

            new Logger().Info("survey '{0}' was created.", surveyName);

            var field2TableMap = GetField2TableMap(survey.ProjectId);

            var context = new SurveyContext
                {
                    Sid = surveyId,
                    Name = surveyName,
                    ProjectId = projectId,
                    Scenario = scenario,
                    FieldToTableMap = field2TableMap,
                    Tables = field2TableMap.GroupBy(x => x.Value).Select(y => y.Key).ToArray(),
                    QuotasCache = new SurveyQuotasCache(scenario, quotaInfos),
                    AutoGroup = autoGroup,
                    SaGroup = saGroup,
                    CgGroup = cgGroup
                };

            GlobalSurveyCache.RegistrySurveyQuotas(projectId, context);

            return context;
        }

        private static Dictionary<string, string> GetField2TableMap(string projectId)
        {
            var result = new Dictionary<string, string>();
            using (var reader = DatabaseEngines.Survey(projectId).ExecuteReader(
                "select fieldname, tableid from field",
                CommandType.Text))
            {
                while (reader.Read())
                {
                    result.Add((string)reader["fieldname"], string.Format("response{0}", reader["tableid"]));
                }
            }

            return result;
        }

        public static int NewBatchId()
        {
            return Interlocked.Increment(ref _topBatchId);
        }

        internal static SurveyContext OpenSurveyContext(
            string projectId,
            SurveyScenario scenario,
            int autoGroup,
            int saGroup,
            int cgGroup)
        {
            var survey = SurveyRepository.GetByName(projectId);
            if (survey == null)
            {
                throw new Exception(String.Format("Survey {0} not found.", projectId));
            }

            var surveyName = NameMaker.SurveyName(projectId, scenario.Name);
            var quotaInfos = QuotaTools.GetQuotaInfo(survey.ProjectId, survey.SID, scenario);
            var field2TableMap = GetField2TableMap(survey.ProjectId);

            if (scenario.SchemaInfo.Project.DialingMode != DialingMode.Predictive)
            {
                AssignmentService.AssignResourceToSurvey(survey.SID, autoGroup, Program.CallCenterId);
                AssignmentService.AssignResourceToSurvey(survey.SID, cgGroup, Program.CallCenterId);
                AssignmentService.AssignResourceToSurvey(survey.SID, BackendTools.GetInterviewGroup(), Program.CallCenterId);
            }

            AssignmentService.AssignResourceToSurvey(survey.SID, saGroup, Program.CallCenterId);

            var context = new SurveyContext
            {
                Sid = survey.SID,
                Name = surveyName,
                ProjectId = projectId,
                Scenario = scenario,
                FieldToTableMap = field2TableMap,
                Tables = field2TableMap.GroupBy(x => x.Value).Select(y => y.Key).ToArray(),
                QuotasCache = new SurveyQuotasCache(scenario, quotaInfos),
                AutoGroup = autoGroup,
                SaGroup = saGroup,
                CgGroup = cgGroup
            };

            GlobalSurveyCache.RegistrySurveyQuotas(projectId, context);

            return context;
        }
    }
}
