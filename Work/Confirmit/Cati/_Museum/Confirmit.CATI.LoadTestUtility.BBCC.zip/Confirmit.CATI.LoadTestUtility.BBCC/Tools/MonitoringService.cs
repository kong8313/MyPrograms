﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Confirmit.CATI.Common.Random;
using Confirmit.CATI.LoadTestUtility.CatiInterviewerApi;
using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    public class MonitoringService
    {
        private readonly IInterviewerApiClient _interviewerApiClient;
        private readonly Logger _logger;
        
        public MonitoringService(IInterviewerApiClient interviewerApiClient, Logger logger)
        {
            _interviewerApiClient = interviewerApiClient;
            _logger = logger;
        }

        //private int _deferredRecordId;
        private readonly List<EventInfo> _events = new List<EventInfo>();

        #region Simulation
        private const int MaxKeyboardInputValue = 1000;
        private const int MinPageContentSize = 1000;
        private const int MaxPageContentSize = 10000;

        private const string ValidChars =
            @"QWERTYUIOP[]ASDFGHJKL;'\ZXCVBNM,./qwertyuiop[]asdfghjkl;'\zxcvbnm,./{}:""|<>?;`1234567890-=~!@#$%^&*()_+";

        private string CreateRandomString(int size)
        {
            if (size <= 0) return "";
            var ca = new Char[size];

            var l = ValidChars.Length-1;
            for(int i=0; i<size; i++)
            {
                int j = Randomizer.Next(0, l);
                ca[i] = ValidChars[j];
            }
            return ca.ToString();
        }

        private string GetRandomStringWithRandomSize(int maxSize)
        {
            return GetRandomStringWithRandomSize(1, maxSize);            
        }

        private string GetRandomStringWithRandomSize(int minSize, int maxSize)
        {
            int c = Randomizer.Next(minSize, maxSize);
            string s = CreateRandomString(c);
            return s;
        }

        private string GetViewKeyboardInputValue()
        {
            return GetRandomStringWithRandomSize(MaxKeyboardInputValue);
        }

        private string GetPageContent()
        {
            return GetRandomStringWithRandomSize(MinPageContentSize, MaxPageContentSize);
        }
        #endregion

        public SocketConsoleState InterviewState { get; set; }
        public int UserId { get; set; }

        private int _deferredRecordId;

        private async Task SendEventsToServer()
        {
            try
            {
                await _interviewerApiClient.SaveDeferredMonitoringEvents(_events);

                _logger.Info($"{_events.Count} monitoring events have been sent");
            }
            finally 
            {                
                _events.Clear();
            }
        }

        private static ConsoleState GetConsoleState(SocketConsoleState state)
        {
            if(state.Operation.Type == SocketOperationType.Interviewing)
                return ConsoleState.Interviewing;

            return ConsoleState.Selecting;
        }

        private void SendEvent(BaseStateData ev, MonitoringMessageTypes messageType)
        {
            var eventInfo = new EventInfo
            {
                RecordingId = _deferredRecordId,
                Type = messageType,
                State = ev,
                Time = DateTime.UtcNow
            };

            _events.Add(eventInfo);
        }
        
        public void SendInterviewingInitial()
        {
            if (!InterviewState.Operation.Recording.Started)
            {
                return;
            }

            var ev = new InterviewingInitialStateData
            {
                KeyboardInputValue = GetViewKeyboardInputValue(),
                PageContent = GetPageContent(),
                ActiveQuestionIndex = Randomizer.Next(0, 1000),
                InterviewId = InterviewState.Operation.InterviewId,
                SurveyId = InterviewState.Operation.ProjectId,
                SurveyName = InterviewState.Operation.SurveyName,
                ConsoleState = GetConsoleState(InterviewState)
            };

            SendEvent(ev, MonitoringMessageTypes.InterviewInitialMessage);
        }


        public void SendInterviewStartMessage(int deferredRecordId)
        {
            _deferredRecordId = deferredRecordId;

            if (!InterviewState.Operation.Recording.Started)
            {
                return;
            }

            var ev = new InterviewStartStateData
            {
                InterviewID = InterviewState.Operation.InterviewId
            };

            SendEvent(ev, MonitoringMessageTypes.InterviewStartMessage);
        }

        public void SendQuestionSelected(int questionIndex)
        {
            if (!InterviewState.Operation.Recording.Started)
            {
                return;
            }

            var ev = new QuestionSelectedStateData
            {
                QuestionIndex = questionIndex,
                SubQuestionIndex = -1
            };

            SendEvent(ev, MonitoringMessageTypes.InterviewPageBrowserQuestionSelectedMessage);
        }

        public void SendAnswerEntered(string element, string value)
        {
            if (!InterviewState.Operation.Recording.Started)
            {
                return;
            }

            var ev = new AnswerEnteredStateData
            {
                ControlName = GetType().Name,
                ElementId = element,
                ElementValue = value
            };

            SendEvent(ev, MonitoringMessageTypes.InterviewPageBrowserResponsiveQuestionChangedMessage);
        }

        public void SendDocumentCompleted()
        {
            if (!InterviewState.Operation.Recording.Started)
            {
                return;
            }

            var ev = new DocumentCompletedStateData
            {
                PageContent = GetPageContent()
            };

            SendEvent(ev, MonitoringMessageTypes.InterviewPageBrowserPageCompletedMessage);
        }

        public async Task SendInterviewFinish()
        {
            if (!InterviewState.Operation.Recording.Started)
            {
                return;
            }

            SendEvent(null, MonitoringMessageTypes.InterviewFinishMessage);
            await SendEventsToServer();
        }

    }
}
