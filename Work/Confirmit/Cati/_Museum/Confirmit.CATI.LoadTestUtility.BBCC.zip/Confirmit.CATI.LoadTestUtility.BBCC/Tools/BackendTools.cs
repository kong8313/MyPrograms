﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Confirmit.CATI.Common;
using Confirmit.CATI.Core.DAL.Generated.Entity.Adapter;
using Confirmit.CATI.Core.DAL.Generated.Procedure.Adapter;
using Confirmit.CATI.Core.Repositories;
using Confirmit.CATI.Core.DAL.Generated.Entity.Table;
using Confirmit.CATI.Core.Repositories.Interfaces;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Core.Services;
using Confirmit.CATI.Core.DAL.Framework;
using Confirmit.CATI.Core.Services.PersonServiceImplementation;
using Confirmit.CATI.Core.Services.Survey;
using Confirmit.CATI.LoadTestUtility.Survey;

using ConfirmitDialerInterface;

using Microsoft.SqlServer.Management.Smo;

using System.Data;
using System.Data.SqlClient;
using System.Threading;
using Confirmit.CATI.Core.SupervisorService;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    public class BackendTools
    {
        /// <summary>
        /// This method returns default interviewers group
        /// </summary>
        /// <returns></returns>
        public static int GetInterviewGroup()
        {
            return PersonGroupRepository.GetByName("CATI Interviewers").SID;
        }

        /// <summary>
        /// Creates new CATI Interviewer.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="password">The password.</param>
        /// <param name="mode">Interviewer task choice mode.</param>
        /// <param name="parentSids">SIDs of parent groups.</param>
        /// <returns>SID of created interviewer.</returns>
        public static int CreatePerson(string name, string password, AgentTaskChoiceMode mode, int[] parentSids)
        {
            var person = PersonRepository.TryGetByName(name);
            
            if( person != null)
            {
                return person.SID;
            }

            if (parentSids == null)
            {
                parentSids = new [] { GetInterviewGroup() };
            }

            var supervisorServiceClient = ServiceLocator.Resolve<ISupervisorServiceClient>();
            supervisorServiceClient.CreateOrUpdatePerson(
                Program.CallCenterId,
                0,
                name,
                "",
                password,
                mode,
                PersonAssignmentListMode.AssignedCallsOnly, 
                TaskChoicePermissions.Automatic | TaskChoicePermissions.Manual | TaskChoicePermissions.SurveyAssignment,
                parentSids.ToList(),
                0,
                0,
                "",
                DialType.Landline,
                AgentType.LiveAgent);

            person = PersonRepository.GetByName(name);
            supervisorServiceClient.SetPersonParentGroups(person.SID, parentSids);

            if (password != null)
            {
                ServiceLocator.Resolve<IPasswordSaver>().Save(person.SID, password);
            }

            return person.SID;
        }
        
        private static BvPersonGroupEntity CreatePersonGroup(string personGroupName)
        {
            var group = new BvPersonGroupEntity();
            group.Name = personGroupName;
            ServiceLocator.Resolve<IPersonGroupRepository>().Insert(group);
            return group;
        }

        public static int CreatePersonGroup(string personGroupName, int parentGroupId)
        {
            var group = PersonGroupRepository.TryGetByName(personGroupName);

            if (group == null)
            {
                group = CreatePersonGroup(personGroupName);
                PersonGroupService.SetParentGroups(group.SID, new[] { parentGroupId });
                new Logger().Info("Person group {0} was created.", personGroupName);
            }

            return group.SID;
        }

        public static int CreateSampleBatch(DatabaseEngine cfDb, SurveyInfo survey, int batchId, string path)
        {
            var logger =new Logger();
            int result = 0;
            using( var stream = File.OpenRead(path))
            using( var reader = new StreamReader(stream))
            {
                var fields = reader.ReadLine().Split('\t');

                //create data table
                var table = new DataTable("temp");
                var columns = fields.Select(x => new DataColumn(x, typeof(string))).ToArray();
                table.Columns.AddRange(columns);

                logger.Info("Sample header was read: {0}", JoinString(",", "{0}", fields));

                //load data to data table
                string line;

                while( (line = reader.ReadLine()) != null )
                {
                    var values = line.Split('\t').Select(x => x.Length > 0 ? x : null).ToArray();

                    result++;

                    try
                    {
                        table.Rows.Add(values);
                    }
                    catch (Exception)
                    {
                        logger.Error(
                            "Exception while adding line [#{0}]: [{1}], '{2}'",
                            result, JoinString(",", "{0}", values), line);

                        throw;
                    }
                }

                logger.Info("Sample DataTable with {0} rows was created.", table.Rows.Count);

                using (new ConnectionScope(cfDb.ConnectionString))
                {
                    CreateTableInDb(cfDb, table, "#SampleData");

                    logger.Info("Sample DataTable with {0} rows was uploaded to tempory db table.", table.Rows.Count);

                    //insert data to respondent table

                    foreach (var field in fields)
                    {
                        AddColumnToRespondentTable(cfDb, field);   
                    }

                    var respFields = new Dictionary<string, string>
                                         {
                                             { "sid", "d.ID" },
                                             { "RespondentName", "d.ID" },
                                             { "TelephoneNumber", "d.ID" },
                                             { "TimeZoneId", "0" },
                                             { "batchId", batchId.ToString() },
                                             { "CatiInterviewerID", "0" }
                                         };

                    foreach( var field in fields)
                    {
                        respFields[field] = "d." + field;
                    }

                    var insertFields = String.Join( ",", respFields.Select(x => x.Key).ToArray());
                    var selectFields = String.Join( ",", respFields.Select(x => x.Value).ToArray());

                    cfDb.ExecuteNonQueryWithSpecificTimeOut(@"
                        DECLARE @StartIID INT
                        SELECT @StartIID = MAX( respid )  FROM respondent
                        SET @StartIID = ISNULL( @StartIID, 0 )
                        INSERT INTO respondent({InsertFields}) SELECT {SelectFields} FROM #SampleData d"
                                                                .Replace("{InsertFields}", insertFields)
                                                                .Replace("{SelectFields}", selectFields)
                                                            , CommandType.Text, 10000);

                    logger.Info("Sample with {0} rows was uploaded to respondent table.", table.Rows.Count);
                }
            }
            return result;
        }

        private static void AddColumnToRespondentTable(DatabaseEngine cfDb, string columnName)
        {
            var columnCount = cfDb.ExecuteScalar<int>(
                string.Format("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'respondent' AND COLUMN_NAME = '{0}'", columnName), CommandType.Text);

            if (columnCount == 0)
            {
                cfDb.ExecuteNonQueryWithSpecificTimeOut(
                    string.Format("ALTER TABLE  [respondent] ADD {0} VARCHAR(255) NULL", columnName), CommandType.Text, 5000);

                new Logger().Info("Field '{0}' was added to the respondent table.", columnName);
            }
        }

        public static void CreateTableInDb(DatabaseEngine db, DataTable table, string tableName)
        {
            //create temp table
            string createTableQuery =
                String.Format(
                    "CREATE TABLE [{0}]( {1}, [Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY)",
                    tableName,
                    JoinString(",", "[{0}] NVARCHAR(20)", table.Columns.Cast<DataColumn>().Select(x => x.ColumnName)));

            db.ExecuteNonQueryWithSpecificTimeOut(createTableQuery, CommandType.Text, 10000);
            //load data to SQL
            using (var connectionScope = new ConnectionScope(db.ConnectionString))
            {
                using (var bulk = new SqlBulkCopy(connectionScope.Connection)
                {BatchSize = 10000, BulkCopyTimeout = 60*60, DestinationTableName = tableName})
                {
                    bulk.WriteToServer(table);
                }
            }
        }        

        public static string JoinString(string separator, string format, IEnumerable<string> strings)
        {
            var formatStrings = strings.Select(x => String.Format(format, x)).ToArray();
            return String.Join(separator, formatStrings);
        }

        public static Dictionary<string,string> GetInterviewFields( int surveySid, int interviewId, string[] fields )
        {
            string query = String.Format(
                "SELECT {0} FROM {1} WHERE respid = {2}", JoinString(",", "[{0}]", fields),
                NameMaker.ReplicatedDataName(surveySid), interviewId);

            using( var reader = DatabaseEngines.Backend.ExecuteReader(query, CommandType.Text))
            {
                if (!reader.Read()) 
                    throw new Exception( String.Format("Interview ( SID:{0} IID: {1} )not found.", surveySid, interviewId));

                return fields.ToDictionary(x => x, y => reader[y].ToString());
            }
        }
    }
}
