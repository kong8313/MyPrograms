﻿using System;
using System.Diagnostics;

namespace Confirmit.CATI.LoadTestUtility.Tools
{
    public class Logger
    {
        private const string Separator = ": ";

        private readonly string _prefix;

        public Logger() : this("")
        {
        }
        
        public Logger(string prefix)
        {
            _prefix = prefix;
        }

        public void Info(string format, params object[] args)
        {
            Trace.TraceInformation(Format(format, args));
            Flush();
        }
        
        public void InfoRaw(string text)
        {
            Trace.TraceInformation(FormatRaw(text));
            Flush();
        }
        
        public void Warn(string format, params object[] args)
        {
            Trace.TraceWarning(Format(format, args));
            Flush();
        }

        public void Error(string format, params object[] args)
        {
            Trace.TraceError(Format(format, args));
            Flush();
        }

        public Exception Exception(string format, params object[] args)
        {
            return new Exception(Format(format, args));
        }

        public void Flush()
        {
            Trace.Flush();
        }

        private string Format(string format, params object[] args)
        {
            return FormatRaw(string.Format(format, args));
        }

        private string FormatRaw(string text)
        {
            return _prefix + Separator + text;
        }
    }
}
