﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Confirmit.CATI.LoadTestUtility
{
    public static class DialerExtensionProvider
    {
        private static int MinExtensionNumber = 200;
        private static int MaxExtensionNumber = int.MaxValue;
        private static int CurrentExtensionNumber = 200;

        private static string StationIdMask = "Ext{0}L";

        private static Dictionary<int, string> personSid2ExtensionNumber = new Dictionary<int, string>();

        static DialerExtensionProvider()
        {
            if( string.IsNullOrEmpty(AppConfiguration.StationIdResourcesRange) ||
                string.IsNullOrEmpty(AppConfiguration.StationIdMask))
            {
                Trace.TraceWarning("The StationIdResourcesRange or StationIdMask is empty. Default settings will be used.");
                return;
            }

            var numbers = AppConfiguration.StationIdResourcesRange.Split('-');
            if (numbers.Length != 2) 
                throw new Exception(string.Format("Invalid StationIdResourcesRange range:{0}", AppConfiguration.StationIdResourcesRange));

            MinExtensionNumber = int.Parse(numbers[0]);
            MaxExtensionNumber = int.Parse(numbers[1]);

            CurrentExtensionNumber = MinExtensionNumber;

            StationIdMask = AppConfiguration.StationIdMask;
        }

        public static string GetExtensionNumber(int personSID)
        {
            lock (personSid2ExtensionNumber)
            {
                string result;
                if (personSid2ExtensionNumber.TryGetValue(personSID, out result))
                {
                    return result;
                }

                if (CurrentExtensionNumber > MaxExtensionNumber)
                {
                    throw new Exception("All extensions numbers are already used, please check settings about TotalAutoInterviewers  and TotalSAInterviewers into config.xml");
                }

                result = CurrentExtensionNumber++.ToString();
                
                personSid2ExtensionNumber.Add(personSID, result);

                return result;
            }
        }
        
        public static string GetStationId(int personSID)
        {
            return string.Format(StationIdMask, GetExtensionNumber(personSID));
        }
    }
}
