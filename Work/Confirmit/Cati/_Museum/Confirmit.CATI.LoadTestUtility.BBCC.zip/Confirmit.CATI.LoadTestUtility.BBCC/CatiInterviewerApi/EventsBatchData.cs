﻿using Confirmit.CATI.Monitoring.Common;
using Confirmit.CATI.Monitoring.Common.StateData;
using System;

namespace Confirmit.CATI.LoadTestUtility.CatiInterviewerApi
{
    public class EventInfo
    {
        public int? RecordingId { get; set; }

        public DateTime Time { get; set; }

        public MonitoringMessageTypes Type { get; set; }

        public BaseStateData State { get; set; }
    }

    public class EventsBatchData
    {
        public DateTime ClientUtcTime { get; set; }
        public EventInfo[] Events { get; set; }
    }
}
