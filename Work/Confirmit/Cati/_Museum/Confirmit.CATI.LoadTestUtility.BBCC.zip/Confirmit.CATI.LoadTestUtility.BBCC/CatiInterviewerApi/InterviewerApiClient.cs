﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.ServiceModel.Configuration;
using System.Text;
using System.Threading.Tasks;
using Confirmit.CATI.Core.Misc;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.Monitoring.Common.Contracts;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

namespace Confirmit.CATI.LoadTestUtility.CatiInterviewerApi
{
    public class InterviewerApiClient : IInterviewerApiClient
    {
        private class AuthData
        {
            public string CompanyAlias;
            public string Login;
            public string Password;
            public string StationId;
        }

        private HttpClientHandler _httpClientHandler;
        private HttpClient _httpClient;

        private string _csrfToken;
        private string _bearerToken;

        private Logger _logger = new Logger();

        public void SetLogger(Logger logger)
        {
            _logger = logger;
        }

        public async Task<string> Login(string companyAlias, string login, string password, string stationId)
        {
            var authData = new AuthData
            {
                CompanyAlias = companyAlias,
                Login = login,
                Password = password,
                StationId = stationId
            };

            Uri requestUrl = GetFullUrl("api/consoles/auth");

            CreateNewHttpClient();
            
            _csrfToken = await GetCsrfTokens();

            HttpContent httpContent = new StringContent(
                JsonConvert.SerializeObject(authData, new JsonSerializerSettings()),
                Encoding.UTF8);
            httpContent.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json; charset=utf-8");

            _httpClient.DefaultRequestHeaders.Add("CSRF-Token", _csrfToken);

            var response = await _httpClient.PostAsync(requestUrl, null, httpContent);
            var token = await response.Content.ReadAsStringAsync();
            _bearerToken = token.Trim('"');

            return _bearerToken;
        }

        public async Task SaveDeferredMonitoringEvents(List<EventInfo> events)
        {
            Uri requestUrl = GetFullUrl("api/consoles/current/events");

            SetCookieIfNeeded(requestUrl);

            var eventsBatchData = new EventsBatchData
            {
                ClientUtcTime = events.Min(x => x.Time),
                Events = events.ToArray()
            };

            var serializerSettings = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };

            HttpContent httpContent = new StringContent(
                JsonConvert.SerializeObject(eventsBatchData, serializerSettings),
                Encoding.UTF8);
            httpContent.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json; charset=utf-8");

            if (!await PutOrPostWithRetry("SaveDeferredMonitoringEvents", requestUrl, httpContent, ActionType.Post))
            {
                throw new Exception($"Could not set deferred monitoring events");
            }
        }
        
        public async Task ConfigureTelephony(ConfigureTelephonyEvent telephonyEvent)
        {
            Uri requestUrl = GetFullUrl("api/consoles/current/command?eTag=NoEtag&type=ConfigureTelephony");

            SetCookieIfNeeded(requestUrl);

            var serializedTelephonyEvent = JsonConvert.SerializeObject(telephonyEvent, new JsonSerializerSettings());
            HttpContent httpContent = new StringContent(
                serializedTelephonyEvent,
                Encoding.UTF8);
            httpContent.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json; charset=utf-8");

            if (!await PutOrPostWithRetry("ConfigureTelephony", requestUrl, httpContent))
            {
                throw new Exception($"Could not configure telephony with event {serializedTelephonyEvent}");
            }
        }

        public async Task SetPendingLogout()
        {
            Uri requestUrl = GetFullUrl("api/consoles/current/intents/logout");

            SetCookieIfNeeded(requestUrl);

            HttpContent httpContent = new StringContent(string.Empty);

            if (!await PutOrPostWithRetry("SetPendingLogout", requestUrl, httpContent))
            {
                throw new Exception("Could not set pending logout");
            }
        }

        public async Task<List<SurveysListItem>> GetSurveys()
        {
            Uri requestUrl = GetFullUrl("api/consoles/current/surveyslist");

            SetCookieIfNeeded(requestUrl);

            var response = await _httpClient.GetAsync(requestUrl);

            if (response.StatusCode != HttpStatusCode.OK)
            {
                _logger.Info($"GetSurveys action returned wrong status code: {response.StatusCode}.");
                throw new Exception("Could not get surveys");
            }

            var content = await response.Content.ReadAsStringAsync();
            var  surveys = DeserializeString<List<SurveysListItem>>(content);

            return surveys;
        }

        public async Task SelectSurvey(string projectId)
        {
            Uri requestUrl = GetFullUrl("api/consoles/current/command?eTag=NoEtag&type=SelectSurvey");

            SetCookieIfNeeded(requestUrl);

            var body = $"{{\"projectId\":\"{projectId}\"}}";
            HttpContent httpContent = new StringContent(body);
            httpContent.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json");

            if (!await PutOrPostWithRetry("SelectSurvey", requestUrl, httpContent))
            {
                throw new Exception($"Could not select survey with project ID {projectId}");
            }
        }

        public async Task CommitInterviewStart(string etag)
        {
            Uri requestUrl = GetFullUrl($"api/consoles/current/command?eTag={etag}&type=CommitInterviewStart");

            SetCookieIfNeeded(requestUrl);

            HttpContent httpContent = new StringContent("");            

            if (!await PutOrPostWithRetry("CommitInterviewStart", requestUrl, httpContent))
            {
                throw new Exception($"Could not commit interview start with etag {etag}");
            }
        }

        public async Task CompleteInterview(string its, string etag)
        {
            Uri requestUrl = GetFullUrl($"api/consoles/current/command?eTag={etag}&type=CompleteInterview");

            SetCookieIfNeeded(requestUrl);

            var body = $"{{\"its\":{its}}}";
            HttpContent httpContent = new StringContent(body);
            httpContent.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json");

            if (!await PutOrPostWithRetry("CompleteInterview", requestUrl, httpContent))
            {
                throw new Exception($"Could not complete interview with its {its}");
            }
        }

        private enum ActionType
        {
            Put, 
            Post
        }

        private async Task<bool> PutOrPostWithRetry(
            string actionName, Uri requestUrl, HttpContent httpContent, ActionType actionType = ActionType.Put, int maxRetryCount = 3)
        {
            HttpResponseMessage response = actionType == ActionType.Put 
                ? await _httpClient.PutAsync(requestUrl, httpContent)
                : await _httpClient.PostAsync(requestUrl, httpContent);
            int tryCnt = 0;
            int waitTime = 10;
            do
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    break;
                }
                
                tryCnt++;
                _logger.Info($"{actionName} action returned wrong status code: {response.StatusCode}. Try #{tryCnt}. Wait {waitTime} seconds.");
                await Task.Delay(TimeSpan.FromSeconds(waitTime));
                
                response = actionType == ActionType.Put
                    ? await _httpClient.PutAsync(requestUrl, httpContent)
                    : await _httpClient.PostAsync(requestUrl, httpContent);
            } while (tryCnt < maxRetryCount - 1);
            
            if (response.StatusCode != HttpStatusCode.OK)
            {
                _logger.Info($"{actionName} action returned wrong status code: {response.StatusCode} after {tryCnt + 1} tries. This interviewer will be hanged.");
                return false;
            }
            
            return true;
        }

        private void SetCookieIfNeeded(Uri requestUrl)
        {
            if (_httpClientHandler.CookieContainer.GetCookies(requestUrl).Count > 1)
            {
                return;
            }

            var cookieCollection = new CookieCollection { new Cookie("interviewertoken", _bearerToken) };

            _httpClientHandler.CookieContainer.Add(requestUrl, cookieCollection);
        }

        private void CreateNewHttpClient()
        {
            _httpClientHandler = new HttpClientHandler();
            _httpClientHandler.CookieContainer = new CookieContainer();

            _httpClient = new HttpClient(_httpClientHandler, false);
            _httpClient.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36");
        }

        private T DeserializeString<T>(string data)
        {
            return JsonConvert.DeserializeObject<T>(data, new StringEnumConverter());
        }

        private async Task<string> GetCsrfTokens()
        {
            string csrfToken = string.Empty;
                
            var response = await _httpClient.GetAsync(AppConfiguration.InterviewerApiBaseUrl);

            var content = await response.Content.ReadAsStringAsync();
            var values = content.Split('\n').ToList();
            var csrfStr = values.FirstOrDefault(x => x.Contains("csrf_token"));
            if (csrfStr != null) // csrf_token: 'oqYNfGPq-WFf2hNzd7wKGhgaEJr913fOx2fE',
            {
                var lines = csrfStr.Split(':');
                csrfToken = lines[1].Trim(' ', '\'', ',');
            }

            return csrfToken;
        }

        private Uri GetFullUrl(string relativeUrl)
        {
            Uri baseAddress = new Uri(AppConfiguration.InterviewerApiBaseUrl);

            return new Uri(baseAddress.AbsoluteUri.TrimEnd('/') + "/" + relativeUrl.TrimStart('/'));
        }
    }
}