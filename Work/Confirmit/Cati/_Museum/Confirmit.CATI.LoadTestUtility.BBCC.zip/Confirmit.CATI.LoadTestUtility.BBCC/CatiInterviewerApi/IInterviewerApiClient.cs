﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.CatiInterviewerApi
{
    public interface IInterviewerApiClient
    {
        Task<string> Login(string companyAlias, string login, string password, string stationId);

        Task SaveDeferredMonitoringEvents(List<EventInfo> events);

        Task<List<SurveysListItem>> GetSurveys();

        Task SelectSurvey(string projectId);

        Task CommitInterviewStart(string etag);

        Task CompleteInterview(string its, string etag);

        Task ConfigureTelephony(ConfigureTelephonyEvent telephonyEvent);

        Task SetPendingLogout();

        void SetLogger(Logger logger);
    }
}