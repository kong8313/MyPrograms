﻿namespace Confirmit.CATI.LoadTestUtility.CatiInterviewerApi
{
    public class ConfigureTelephonyEvent
    {
        public bool Disable { get; set; }
        public string ExtensionNumber { get; set; }
    }
}
