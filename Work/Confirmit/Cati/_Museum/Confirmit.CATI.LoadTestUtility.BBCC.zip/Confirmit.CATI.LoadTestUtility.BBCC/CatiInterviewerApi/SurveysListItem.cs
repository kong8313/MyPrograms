﻿namespace Confirmit.CATI.LoadTestUtility.CatiInterviewerApi
{
    public class SurveysListItem
    {
        public string ProjectId { get; set; }
        public string SurveyName { get; set; }
        public bool IsRespondentsDynamicCreationAllowed { get; set; }
    }
}
