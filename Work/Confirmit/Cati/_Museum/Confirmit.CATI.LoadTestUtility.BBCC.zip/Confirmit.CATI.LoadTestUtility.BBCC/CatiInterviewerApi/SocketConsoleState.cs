﻿using System;
using System.Collections.Generic;

namespace Confirmit.CATI.LoadTestUtility.CatiInterviewerApi
{
    public class SocketConsoleState
    {
        public string Domain { get; set; }

        public string Timestamp { get; set; }

        public bool IsTerminateActive { get; set; }

        public int UnreadMessageCount { get; set; }

        public int Etag { get; set; }

        public SocketIntents Intents { get; set; }

        public SocketPerson Person { get; set; }

        public SocketCommand[] Commands { get; set; }

        public SocketOperation Operation { get; set; }

        public SocketMonitoring Monitoring { get; set; }

        public SocketSettings Settings { get; set; }

        public SocketMessage Message { get; set; }

        public SocketTelephony Telephony  { get; set; }

        public SocketSupervisorPopupMessage SupervisorMessage { get; set; }

        public SocketSoftPhoneClient SoftphoneClient { get; set; }
    }

    public class SocketMonitoring
    {
        public bool Started { get; set; }
        public string Id { get; set; }
    }

    public class SocketSupervisorPopupMessage
    {
        public string Id { get; set; }
        public string Message { get; set; }
        public string SupervisorName { get; set; }
    }

    public class SocketMessage
    {
        public SocketSeverity Severity { get; set; }
        public string Message { get; set; }
        public Dictionary<string, string> Parameters { get; set; }
    }

    public class SocketSettings
    {
        public bool ShowRedialButton { get; set; }

        public bool ShowInternalCallTransferButton { get; set; }

        public bool ShowExternalCallTransferButton { get; set; }

        public bool EnablePreviousPageToolbarButton { get; set; }

        public bool EnableNextPageToolbarButton { get; set; }

        public bool EnableAppointmentToolbarButton { get; set; }

        public bool EnableRedoToolbarButton { get; set; }

        public bool EnableFastForwardToolbarButton { get; set; }

        public bool EnableRedialToolbarButton { get; set; }

        public bool EnableInternalCallTransferButton { get; set; }

        public bool EnableExternalCallTransferButton { get; set; }

        public bool EnableHangUpToolbarButton { get; set; }

        public bool EnableLogoutAfterFinishToolbarButton { get; set; }

        public bool EnableTerminateToolbarButton { get; set; }

        public bool EnableTakeBreakToolbarButton { get; set; }

        public bool EnableChangeTaskChoiceToolbarButton { get; set; }

        public bool EnableAppointmentsListToolbarButton { get; set; }

        public bool EnableRefreshToolbarButton { get; set; }

        public bool EnableLogoutToolbarButton { get; set; }

        public bool EnableRedialNewNumberRedialDialogAbility { get; set; }

        public bool EnableAbilityToCreateAppointmentsOutsideOfThePermittedShiftTimes { get; set; }

        public bool EnableAbilityToCancelDial { get; set; }

        public bool EnableLogoutFromErrorAndWaitingScreen { get; set; }

        public bool EnableScriptErrorsLogging { get; set; }

        public bool EnableMessaging { get; set; }

        public bool EnableTwoWayMessaging { get; set; }

        public bool EnableSoftphoneIntegration { get; set; }

        public int GoodConnectionThresholdMs { get; set; }

        public int NormalConnectionThresholdMs { get; set; }

        public IEnumerable<SocketBreakType> BreakTypes { get; set; }
    }

    public class SocketIntents
    {
        public bool Logout { get; set; }

        public int BreakTypeId { get; set; }

        public bool SelectTaskChoice { get; set; }
    }

    public class SocketPerson
    {
        public int CompanyId { get; set; }

        public int PersonId { get; set; }

        public string Name { get; set; }

        public string DialType { get; set; }

        public SocketTaskChoice TaskChoice { get; set; }

        public SocketTaskChoice[] TaskChoicePermissions { get; set; }
    }
    
    public enum SocketTaskChoice
    {
        Automatic,
        Manual,
        SurveyAssignment
    }

    public class SocketCommand
    {
        public string Name { get; set; }

        public string ETag { get; set; }
    }

    public class SocketOperation
    {
        // General
        public SocketOperationType Type { get; set; }
        public DateTime OperationStartTime { get; set; }

        // SocketSimpleOperation
        public SocketInternalOperationType InternalType { get; set; }

        // SocketnterviewingOperation
        public string ProjectId { get; set; }
        public int InterviewId { get; set; }
        public string InterviewUrl { get; set; }
        public int InterviewLanguage { get; set; }
        public DateTime StartTime { get; set; }
        public string SurveyName { get; set; }
        public IEnumerable<SocketLanguageInfo> SurveyLanguages { get; set; }
        public int TimezoneDifferenceInMinutes { get; set; }
        public string RespondentTimezoneName { get; set; }
        public SocketRecording Recording { get; set; }
        public bool Reviewing { get; set; }
        public SocketCallTypes CallType { get; set; }
        public SocketInternalTransferType? InternalTransferType { get; set; }
        public SocketExternalTransferType? ExternalTransferType { get; set; }
        public SocketAppointment Appointment { get; set; }
        public SocketSubOperation Operation { get; set; }
        public SocketDialConnectionState TelephoneConnection { get; set; }
        public bool IsLinkedInterview { get; set; }
        public string CurrentSoundFile { get; set; }

        // SocketBreakOperation
        public SocketBreakType BreakType { get; set; }

        // SocketNoCallsOperation
        public string ReasonCode { get; set; }

        // SocketConfiguringTelephonyOperation
        public string ExtensionNumber { get; set; }
        public bool IsExtensionNumberEditable { get; set; }
        public string StationId { get; set; }

        // SocketConfirmOperation (1 nad 2 are SocketErrorOperation)
        public string Incident { get; set; }
        public SocketMessageData Message { get; set; }
        public SocketConfirmOption[] Options { get; set; }
    }

    public enum SocketInternalOperationType
    {
        Login = 1,
        LookupInterview,
        DeliveryInterview,
        NoCalls,
        SelectingInterview,
        Interviewing,
        Logout,
        Break,
        SelectingTaskChoice,
        SelectingSurvey,
        ApplyingTaskChoice,
        Confirm,
        Error,
        CompleteInterview,
        PredictiveLookupInterview,
        StartLinkedInterview,

        DetectTelephonyConfiguration,
        EditTelephonyConfiguration,
        LogoutFromDialer,
        LoginToDialer,
        ChangeSurveyOnDialer,

        Dialing,
        Redialing,
        ConfirmOperationResult,
        IncomingTransfer,
        OutgoingTransfer,
        LoginToSoftphone,

        ConfigureTaskChoiceWorkflow = 1000,
        DeliveryInterviewWorkflow,
        LookupInterviewWorkflow,
        InterviewingWorkflow,
        SetupTelephonyWorkflow,
        ApplyTelephonyWorkflow,
        LogoutWorkflow
    }

    public class SocketRecording
    {
        public bool Started { get; set; }
        public int Id { get; set; }
    }

    public enum SocketExternalTransferType
    {
        Warm = 1,
        Cold = 2
    }

    public enum SocketInternalTransferType
    {
        Off = 0,
        Warm = 1,
        Cold = 2

    }

    public enum SocketCallTypes
    {
        Outbound = 0,
        Inbound = 1,
        Transfer = 2
    }

    public enum SocketDialConnectionState
    {
        NotConnectedYet,
        Connected,
        Disconnected,
        Connecting,
    }    

    public class SocketAppointment
    {
        public int Id { get; set; }
        public string ProjectId { get; set; }
        public string ProjectName { get; set; }
        public int InterviewId { get; set; }
        public int State { get; set; }
        public bool OutsideShift { get; set; }
        public DateTime? AppointmentDateTimeForRespondent { get; set; }
        public string TimezoneDisplayName { get; set; }

        // SocketNewAppointment
        public DateTime AppointmentDateTime { get; set; }
        public DateTime? ExpirationDateTime { get; set; }
    }

    public class SocketLanguageInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsDefault { get; set; }
    }


    public class SocketBreakType
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsPaid { get; set; }
        public int? YellowThresholdInSec { get; set; }
        public int? RedThresholdInSec { get; set; }
    }
  
    public class SocketMessageData
    {
        public SocketSeverity Severity { get; set; }
        public string Message { get; set; }
        public Dictionary<string, string> Parameters { get; set; }
    }

    public enum SocketSeverity
    {
        Error,
        Warning,
        Info,
    }

    public enum SocketConfirmOption
    {
        ContinueWithoutDialer,
        Retry,
        Logout,
        Cancel
    }

    public class SocketTelephony
    {
        public bool LoggedInToDialer { get; set; }
        public bool IsDialerAvailable { get; set; }
        public bool IsPauseOrResumePlaybackSupported { get; set; }
    }
  
    public enum SocketOperationType
    {
        Interviewing,
        NoCalls,
        Waiting,
        Break,
        SelectingSurvey,
        SelectingTaskChoice,
        SelectingInterview,
        Confirm,
        ConfiguringTelephony,
        Error,
        Dialing,
        Redialing,
        Transfering,
        IncomingTransfer,
        LoginToSoftphone
    }

    public enum SocketOperationStatus
    {
        Running,
        Completed,
        Failed,
        Canceled
    }

    public class SocketSubOperation
    {
        // General
        public SocketOperationType Type { get; set; }
        public SocketOperationStatus Status { get; set; }

        // SocketDialOperation
        public string PhoneNumber { get; set; }
        public string DialingText { get; set; }

        // SocketDialCompletedOperation
        public int Outcome { get; set; }
        public string OutcomeName { get; set; }

        // SocketDialFailedOperation
        public int ErrorCode { get; set; }
        public string ErrorName { get; set; }

        // SocketOutgoingTransferCompletedOperation
        public SocketTransferOptions Options { get; set; }

        // SocketBaseTransferOperation
        public SocketConnectionState ConnectionState { get; set; }
        public SocketTransferParticipant Initiator { get; set; }
        public SocketTransferParticipant Respondent { get; set; }
        public SocketTransferParticipant Target { get; set; }

        // SocketOutgoingTransferOperation (1 is SocketIncomingTransferOperation)
        public bool Initialized { get; set; }
    }

    public class SocketTransferParticipant
    {
        /// <summary>
        /// Type of participant - external or internal.
        /// </summary>
        public SocketParticipantType ParticipantType { get; set; }

        /// <summary>
        /// Contains telephone number or agentId depended by ParticipantType.
        /// </summary>
        public string Resource { get; set; }

        /// <summary>
        /// State of dialing to participant.
        /// </summary>
        public SocketDialingState DialingState { get; set; }

        /// <summary>
        /// Outcome state of dialing to participant.
        /// </summary>
        public SocketDialingStateOutcome DialingStateOutcome { get; set; }
    }

    public enum SocketDialingState
    {
        NotDefined = 0,
        Dialing = 1,
        Connected = 2,
        NotConnected = 3,
        Waiting = 4,
        Hold = 5
    }

    public enum SocketDialingStateOutcome
    {
        NotDefined = 1,
        Connected = 2,
        Busy = 3,
        NoReply = 4

    }
    public enum SocketParticipantType
    {
        /// <summary>
        /// Unspecified resource.
        /// </summary>
        NotDefined = 0,

        /// <summary>
        /// External, determinate by telephone number.
        /// </summary>
        External = 1,

        /// <summary>
        /// Agent, internal, determinate by agentId.
        /// </summary>
        Agent = 2,

        /// <summary>
        /// Agent group, internal.
        /// </summary>
        AgentGroup = 3
    }

    public enum SocketConnectionState
    {
        NotDefined = 0,
        InitiatorToRespondent = 1,
        InitiatorToTarget = 2,
        TargetToRespondent = 3,
        Conference = 4
    }

    public class SocketTransferOptions
    {
        public string Resource { get; set; }

        public SocketTransferType Type { get; set; }

        public SocketTransferInitiator Initiator { get; set; }
    }

    public enum SocketTransferType
    {
        ExternalCold = 1,
        ExternalWarm = 2,
        InternalCold = 3,
        InternalWarm = 4
    }

    public enum SocketTransferInitiator
    {
        Manual,
        Script,
        Node
    }

    public class SocketSoftPhoneClient
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public string FrontendUrl { get; set; }
    }
}