﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Web;
using Confirmit.CATI.Core.AuthoringService;
using Confirmit.CATI.Core.DAL.Framework;
using Confirmit.CATI.Core.DAL.Generated.Entity.Table;
using Confirmit.CATI.Core.Misc;
using Confirmit.CATI.Core.Misc.CP;
using Confirmit.CATI.Core.Repositories.Interfaces;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Core.ServiceRegistration;
using Confirmit.CATI.Core.Services;
using Confirmit.CATI.LoadTestUtility.Scenarios;
using Confirmit.CATI.LoadTestUtility.Tools;
using System.Text;
using Confirmit.CATI.Core.Misc.ConfirmitClientKey;
using Confirmit.CATI.Core.SupervisorService;
using Confirmit.CATI.IntegrationTests.Framework.ServiceLocatorRegistry;
using Confirmit.CATI.Supervisor.Core.CallCenters;
using Confirmit.CATI.Supervisor.Core.Surveys;
using Confirmit.Security.Crypto.Web;
using IInterviewerApiClient = Confirmit.CATI.LoadTestUtility.CatiInterviewerApi.IInterviewerApiClient;
using InterviewerApiClient = Confirmit.CATI.LoadTestUtility.CatiInterviewerApi.InterviewerApiClient;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using System.Threading;
using System.Linq;
using Confirmit.CATI.LoadTestUtility.WorkflowServices;
using Confirmit.CATI.Core.DAL.Generated.Entity.Adapter;
using System.Data.SqlClient;
using ConfirmitDialerInterface;
using Confirmit.CATI.LoadTestUtility.ActivityEvents;
using Confirmit.CATI.Core.Repositories;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;

namespace Confirmit.CATI.LoadTestUtility
{
    internal class Program
    {
        internal static int CompanyId { get; set; }
        internal static string CompanyAlias { get; set; }
        internal static int CallCenterId { get; set; }

        private static Logger _logger;
        /*
        public static async Task Main(string[] args)
        {
            InitializeServiceLocator();

            var socketConnector = ServiceLocator.Resolve<ISocketConnector>();

            System.Console.WriteLine("Start WebSocket Observation");
            
            await socketConnector.StartWebSocketObservation("Confirmit", "g1", "1", "1");

            System.Console.ReadLine();

            System.Console.WriteLine("Finish WebSocket Observation");
            await socketConnector.StopWebSocketObservation();

            System.Console.WriteLine("Press any key to exit");
            System.Console.ReadLine();
        }
        */
        
        
        public static void Main(string[] args)
        {
            try
            {
                _logger = new Logger();
                if (args.Length < 3)
                {
                    _logger.Error(@"Invalid param list");
                    ShowHelp();
                    return;
                }

                _logger.Info("Read configuration {0}...", args[0]);
                TestConfiguration config = new TestConfigurationReader(args).Load();

                var scenario = new UtilityScenarioParser(args[0], args[1]).Parse();
                ShowConfig(scenario);

                _logger.Info("Initialize perfomance counters...");
                PerformanceCounters.Initialize();

                _logger.Info("Initialize service locator...");

                InitializeServiceLocator();

                _logger.Info("Initialize core...");
                InitializeCore();

                CallCenterId = new CallCenterRepository().Default.ID;

                new StartLoadTestEvent(args[0], GetAreaDescription()).Finish();

                _logger.Info("Initialize person ...");
                var autoInterviewers = new InterviewerManager(config.AdministratorsCount, AgentTaskChoiceMode.Automatic, true, false);
                var surveyAssignInterviewers = new InterviewerManager(config.AdministratorsCount, AgentTaskChoiceMode.CampaignAssignment, false, false);
                var callGroupInterviewers = new InterviewerManager(config.AdministratorsCount, AgentTaskChoiceMode.CampaignAssignment, false, true);

                _logger.Info("Create call groups");

                CreateCallGroups(config.CallGroups);

                _logger.Info("Run data thread");
                var dataThread = new DataUpdateThread();
                dataThread.Start();
                AdministratorWorkflowService[] admins;

                if (config.Role == RoleType.Master)
                {
                    _logger.Info("Run admins threads...");
                    admins = new AdministratorWorkflowService[config.AdministratorsCount];

                    for (int index = 0; index < admins.Length; index++)
                    {
                        var surveyScenario = scenario.SurveyScenarios[index % scenario.SurveyScenarios.Count];

                        admins[index] = new AdministratorWorkflowService(
                            scenario,
                            surveyScenario,
                            autoInterviewers.InterviewersGroup[index % autoInterviewers.InterviewersGroup.Length],
                            surveyAssignInterviewers.InterviewersGroup[index % surveyAssignInterviewers.InterviewersGroup.Length],
                            callGroupInterviewers.InterviewersGroup[index % callGroupInterviewers.InterviewersGroup.Length],
                            index);
                        admins[index].Start();
                    }
                }
                else
                {
                    admins = Array.Empty<AdministratorWorkflowService>();

                    for (int index = 0; index < config.AdministratorsCount; index++)
                    {
                        var surveyScenario = scenario.SurveyScenarios[index % scenario.SurveyScenarios.Count];
                        BvSurveyEntity survey = BvSurveyAdapter.GetByCondition("[Description] = @Description\r\n", new SqlParameter("@Description", index.ToString(CultureInfo.InvariantCulture))).Single();
                        if (survey == null)
                        {
                            throw new Exception($"No survey with description '{index}' was found");
                        }

                        SurveyTools.OpenSurveyContext(
                            survey.Name,
                            surveyScenario,
                            autoInterviewers.InterviewersGroup[index % autoInterviewers.InterviewersGroup.Length],
                            surveyAssignInterviewers.InterviewersGroup[index % surveyAssignInterviewers.InterviewersGroup.Length],
                            callGroupInterviewers.InterviewersGroup[index % callGroupInterviewers.InterviewersGroup.Length]);
                    }
                }

                if (config.ExecutionMode == RunAction.Preparation)
                {
                    do
                    {
                        Thread.Sleep(TimeSpan.FromSeconds(1));
                    }
                    while (admins.Any(admin => admin.IsProcessRunning));
                }
                else
                {
                    _logger.Info("Run interviewer threads...");
                    int currentLoadScenarioId = 0;

                    do
                    {
                        TestConfiguration.LoadInterval interval = config.LoadScenario[currentLoadScenarioId];

                        _logger.Info($"Run overregulate functions for auto={interval.TotalAutoInterviewers}/SA={interval.TotalSAInterviewers}/CG={interval.TotalCGInterviewers} interviewers");
                        autoInterviewers.OverregulateActiveUserCount(interval.TotalAutoInterviewers, interval);
                        surveyAssignInterviewers.OverregulateActiveUserCount(interval.TotalSAInterviewers, interval);
                        callGroupInterviewers.OverregulateActiveUserCount(interval.TotalCGInterviewers, interval);

                        for (int i = 0; i < interval.Duration * 60; i++)
                        {
                            if (admins.Length == 0 || admins.Any(admin => admin.IsProcessRunning))
                            {
                                Thread.Sleep(TimeSpan.FromSeconds(1));
                            }
                            else
                            {
                                break;
                            }
                        }

                        currentLoadScenarioId = (currentLoadScenarioId + 1) % config.LoadScenario.Length;
                    }
                    while (admins.Length == 0 || admins.Any(admin => admin.IsProcessRunning));

                    _logger.Info($"Run overregulate functions to logout interviewers");
                    // logout all persons
                    autoInterviewers.OverregulateActiveUserCount(RandomIntParam.Zero, config.LoadScenario[currentLoadScenarioId]);
                    surveyAssignInterviewers.OverregulateActiveUserCount(RandomIntParam.Zero, config.LoadScenario[currentLoadScenarioId]);
                    callGroupInterviewers.OverregulateActiveUserCount(RandomIntParam.Zero, config.LoadScenario[currentLoadScenarioId]);
                }

                _logger.Info("End admin thread. Stop data thread");

                dataThread.Stop();
                dataThread.Wait(TimeSpan.FromSeconds(60));
            }
            catch (Exception ex)
            {
                _logger.Error("Exception: {0}", ex.ToString());
            }

            _logger.Info("End execution");
        }
        
        private static void ShowConfig(UtilityScenario config)
        {
            foreach (var scenario in config.SurveyScenarios)
            {
                _logger.Warn(
                    scenario.Enabled
                        ? $"           Scenario '{scenario.Name} is enabled"
                        : $"WARNING!!! Scenario '{scenario.Name} is disabled");

                SurveyScenarioTools.ShowScenarioInfo(scenario);
            }
        }

        private static void CreateCallGroups(Dictionary<BvCallGroupEntity, BvCallGroupConditionEntity[]> callGroups)
        {
            var service = ServiceLocator.Resolve<ICallGroupService>();
            var repository = ServiceLocator.Resolve<ICallGroupRepository>();

            foreach (var group in callGroups)
            {
                var callGroup = group.Key;
                repository.Insert(callGroup);
                service.SetListOfCondition(callGroup.Id, group.Value);
            }
        }

        private static void InitializeServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            IServicesRegistryInitializer serviceRegistryInitializer = new ServicesRegistryInitializer(serviceLocator);
            serviceRegistryInitializer.RegisterRegistries(serviceRegistryInitializer.GetRegistries());
            ServiceLocator.Register<ISupervisorNameProvider, HttpContextSupervisorNameProvider>();
            ServiceLocator.Register<ISupervisorServiceClient, SupervisorServiceClient>();
            ServiceLocator.RegisterSingleton<ICallCenterProvider, TestCallCenterProvider>();
            ServiceLocator.Register<IConfirmitClientKeyProvider, LoadTestUtilityConfirmitClientKeyProvider>();
            ServiceLocator.Register<IInterviewerApiClient, InterviewerApiClient>();            
        }

        private static string GetAreaDescription()
        {
            var sb = new StringBuilder();

            sb.AppendFormat("BE Url={0}\r\n", AppConfiguration.MultimodeWebServiceURL);
            sb.AppendFormat("BE Sql={0}\r\n", DatabaseEngines.Backend.ConnectionString);
            sb.AppendFormat("CF Sql={0}\r\n", DatabaseEngines.Confirmit.ConnectionString);

            return sb.ToString();
        }

        internal static void InitializeCore()
        {
            CompanyId = AppConfiguration.CompanyID;
            CompanyAlias = AppConfiguration.CompanyAlias;
            
            InitializeBackendInstanceCurrent();

            UpdateSystemSetting(DatabaseEngines.DefaultDatabase, "Setup.EncryptedConfirmConnectionString", EncryptionUsingMachineKey.Encrypt(DataProtection.All, AppConfiguration.ConnectionStringToConfirm));
            UpdateSystemSetting(DatabaseEngines.DefaultDatabase, "Setup.EncryptedConfirmlogConnectionString", EncryptionUsingMachineKey.Encrypt(DataProtection.All, AppConfiguration.ConnectionStringToConfirmLog));
        }

        internal static void InitializeBackendInstanceCurrent()
        {
            SimulatedHttpRequest.SetHttpContextWithSimulatedRequest("MyHost", "MyBlog");

            HttpContext.Current.User = new SupervisorPrincipal(
                    "userName",
                    "clientKey",
                    CompanyId.ToString(CultureInfo.InvariantCulture),
                    "Load test company",
                    Tabs.None,
                    false, false, false);

            var backendInstance = ServiceLocator.Resolve<IBackendInstanceFactory>().Create(
                CompanyId,
                HostType.Supervisor);
            HttpContext.Current.Items["BackendInstance"] = backendInstance;

            BackendInstance.Current.ConnectionString = DatabaseEngines.Backend.ConnectionString;
            BackendInstance.Current.ConfirmlogConnectionString = AppConfiguration.ConnectionStringToConfirmLog;
        }

        private static void UpdateSystemSetting(DatabaseEngine databaseEngine, string settingName, string value)
        {
            databaseEngine.ExecuteNonQuery($"exec BvSpSystemSetting_Update '{settingName}', '{value}'", CommandType.Text);
        }

        private static void ShowHelp()
        {
            Console.WriteLine(@"using:");
            Console.WriteLine(@"    {0} configFile action roleType", Path.GetFileName(Assembly.GetExecutingAssembly().Location));
            Console.WriteLine(@"action: Preparation or Test");
            Console.WriteLine(@"roleType: Master or Slave");
        }
    }
}
