﻿using System;
using System.Threading;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class SleepAction : BaseSurveyAction
    {
        private SleepAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action) { }

        private RandomIntParam _timeout;

        public static SleepAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new SleepAction(action)
            {
                _timeout = new RandomIntParam(action.Param)
            };
        }

        public override void Execute(SurveyContext context, Logger logger)
        {
            var timeout = _timeout.Value;
            logger.Info("Sleep to {0} minutes", timeout);

            for (int i = 0; i < timeout; i++)
            {
                Thread.Sleep(TimeSpan.FromMinutes(1));
            }

            logger.Info("Wake up after {0} minutes of sleep", timeout);
        }
    }
}
