﻿using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions
{
    public interface IInterviewAction : IScenarioAction<InterviewContext>
    {
        
    }
}
