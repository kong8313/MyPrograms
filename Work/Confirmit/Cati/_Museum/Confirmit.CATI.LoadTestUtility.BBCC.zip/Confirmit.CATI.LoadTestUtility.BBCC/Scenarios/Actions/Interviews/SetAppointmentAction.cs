﻿using System;
using Confirmit.CATI.Common.ConsoleService.Abstract;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.CatiInterviewerApi;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Interviews
{
    public class SetAppointmentAction : BaseInterviewAction
    {
        private class SetAppointmentParam : NamedParams
        {
            public RandomTimeSpanParam Time;

            public SetAppointmentParam(string param)
                : base(param)
            {
                Time = AsRandomTimeSpan("Time");
            }
        }

        private SetAppointmentParam Params { get; set; }

        private SetAppointmentAction(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action) : base(action) { }

        public static SetAppointmentAction Parse(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action, ParseContext context)
        {
            return new SetAppointmentAction(action)
                       {
                           Params = new SetAppointmentParam(action.Param)
                       };
        }

        public override void Execute(InterviewContext context, Logger logger)
        {
            var operation = context.State.Operation;
            PerformanceCounters.RateOfAppointmentPerSecondPerformanceCounter.Increment();
            var time = Params.Time.Value;
            context.ConsoleService.SetInterviewAppointmentList(
                operation.ProjectId,
                operation.InterviewId, 
                new[]{ new Appointment
                           {
                              projectID = operation.ProjectId,
                              InterviewId = operation.InterviewId,
                              contactName = "contactName",
                              expirationTime = null,
                              projectName = operation.ProjectId,
                              state = 0,
                              appointmentTimeZone = null,
                              id = 0,
                              time = DateTime.UtcNow + time
                           }},
                true );
            logger.Info("Set appointment in: {0}", time);
        }
    }
}
