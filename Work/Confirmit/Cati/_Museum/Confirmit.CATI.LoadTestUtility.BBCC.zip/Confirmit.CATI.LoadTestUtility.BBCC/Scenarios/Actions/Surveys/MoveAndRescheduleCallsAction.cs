﻿using Confirmit.CATI.Common.Random;
using Confirmit.CATI.Core.Batch;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.Supervisor.Core.Surveys;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class MoveAndRescheduleCallsAction : BaseCallManagerAction
    {
        private MoveAndRescheduleCallsAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action)
            : base(action)
        {
        }

        public static MoveAndRescheduleCallsAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new MoveAndRescheduleCallsAction(action);
        }

        protected override void Execute(SurveyContext context, BatchParameters batchParameters, Logger logger)
        {
            var randomIts = Randomizer.Next(31, 121);
            logger.Info("MoveAndRescheduleCalls parameters: randomIts = {0}", randomIts);

            var operation = CallManager.MoveAndRescheduleCalls(context.Sid, randomIts, batchParameters);
            ExecuteAsyncOperation(context, operation, logger);
        }
    }
}
