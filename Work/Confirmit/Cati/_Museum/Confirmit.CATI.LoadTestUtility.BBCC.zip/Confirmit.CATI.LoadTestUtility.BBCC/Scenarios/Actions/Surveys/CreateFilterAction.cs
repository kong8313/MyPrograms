﻿using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class CreateFilterAction : BaseSurveyAction
    {
        public CreateFilterAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action)
        {
        }

        public override void Execute(SurveyContext context, Logger logger)
        {
            Filter.Create(context.Sid, new NamedParams(Info));
        }

        public static CreateFilterAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new CreateFilterAction(action);
        }
    }
}
