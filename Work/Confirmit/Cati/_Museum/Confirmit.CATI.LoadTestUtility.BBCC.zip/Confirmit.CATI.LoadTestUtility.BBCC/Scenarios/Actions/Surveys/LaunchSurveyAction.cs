﻿using Confirmit.CATI.LoadTestUtility.ConfirmitSurveyDeployer;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    class LaunchSurveyAction : BaseSurveyAction
    {
        public LaunchSurveyAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action) { }

        public override void Execute(SurveyContext context, Logger logger)
        {
            SurveyTools.LaunchSurvey(context.ProjectId, GenerateDbOptions.Rebuild);
        }

        public static LaunchSurveyAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new LaunchSurveyAction(action);
        }
    }
}