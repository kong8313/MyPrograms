﻿using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions
{
    public interface IScenarioAction<TContext>
    {
        string Name { get;}
        string Info { get;}
        void Execute(TContext context, Logger logger);
    }
}
