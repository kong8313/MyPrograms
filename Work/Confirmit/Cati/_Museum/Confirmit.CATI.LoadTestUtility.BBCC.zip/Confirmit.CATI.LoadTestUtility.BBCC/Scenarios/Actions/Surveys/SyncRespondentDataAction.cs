﻿using System.Data;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class SyncRespondentDataAction : BaseSurveyAction
    {
        public SyncRespondentDataAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action) { }


        public static SyncRespondentDataAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new SyncRespondentDataAction(action);
        }

        public override void Execute(SurveyContext context, Logger logger)
        {
            DatabaseEngines.Survey(context.ProjectId).ExecuteNonQuery(
                @"insert into response_control( respid, ITS ) 
                        select r.respid, 16
                        from respondent r
                        left join response_control rc
                        on r.respid = rc.respid
                        where rc.respid is null",
                CommandType.Text);
        }
    }
}
