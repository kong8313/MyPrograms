using System.Linq;
using Confirmit.CATI.Core.Repositories;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions
{
    public abstract class BaseSurveyAction : ISurveyAction
    {
        public string Name { get; private set; }
        public string Info { get; private set; }
        public EnumAction Action { get; private set; }

        public BaseSurveyAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action)
        {
            Name = action.Action.ToString();
            Info = action.Param;
            Action = action.Action;
        }

        public abstract void Execute(SurveyContext context, Logger logger);

        protected int GetFilterIdByName(SurveyContext context, string filterName)
        {
            return FilterRepository.GetFiltersList(true, context.Sid).Single(x => x.Name == filterName).SID;
        }
    }
}