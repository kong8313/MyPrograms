﻿using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions
{
    public abstract class BaseInterviewAction : IInterviewAction
    {
        public string Name { get; private set; }
        public string Info { get; private set; }
        public InterviewScenarioActionType Action { get; private set; }

        public BaseInterviewAction(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action)
        {
            Name = action.Type.ToString();
            Info = action.Param;
            Action = action.Type;

        }

        public abstract void Execute(InterviewContext context, Logger logger);
    }
}
