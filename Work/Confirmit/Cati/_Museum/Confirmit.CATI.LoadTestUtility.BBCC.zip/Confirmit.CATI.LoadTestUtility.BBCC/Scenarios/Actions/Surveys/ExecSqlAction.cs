﻿using System.IO;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class ExecSqlAction : BaseSurveyAction
    {
        public ExecSqlAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action) { }

        public string SqlBatch;

        public static ExecSqlAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new ExecSqlAction(action)
            {
                SqlBatch = File.ReadAllText(context.ResolvePath(action.Param))
            };

        }

        public override  void Execute(SurveyContext context, Logger logger)
        {
            var query = SqlBatch.Replace("{DBName}", DatabaseEngines.Backend.DatabaseName);
            DatabaseEngines.Backend.ExecuteBatch(query);
        }
    }
}
