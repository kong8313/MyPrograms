﻿using Confirmit.CATI.Common;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Interviews
{
    public class SetBreakAction : BaseInterviewAction
    {
        public class SetBreakParam : NamedParams
        {
            public bool Value;

            public int BreakTypeId;

            public SetBreakParam(string param)
                : base(param)
            {
                Value = AsBool("Value");
                BreakTypeId = AsInt("BreakTypeId");
            }
        }

        public SetBreakParam Params { get; private set; }

        public SetBreakAction(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action) : base(action){}

        public static SetBreakAction Parse(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action, ParseContext context)
        {
            return new SetBreakAction(action)
                       {
                           Params = new SetBreakParam(action.Param)
                       };
        }

        public override void Execute(InterviewContext context, Logger logger)
        {
            context.ConsoleService.SetPendingBreakStatus(Params.Value ? PendingBreakStatus.Break : PendingBreakStatus.None, Params.BreakTypeId);
        }
    }
}
