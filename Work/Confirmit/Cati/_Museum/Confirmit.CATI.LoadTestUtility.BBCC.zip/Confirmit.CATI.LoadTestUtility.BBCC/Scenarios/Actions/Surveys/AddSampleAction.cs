﻿using System;
using System.Threading;
using Confirmit.CATI.Common;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Services;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class AddSampleAction : BaseSurveyAction
    {
        private AddSampleAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action) { }

        private string _path;

        public static AddSampleAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new AddSampleAction(action)
            {
                _path = context.ResolvePath(action.Param)
            };
        }

        public override void Execute(SurveyContext context, Logger logger)
        {
            logger.Info("Preparing sample batch from file '{0}' ...", _path);
            var batchId = TestDataInitializer.InitializeSampleBatch(context, _path, out var count);

            logger.Info("Adding sample batch with size {0} ...", count);
            ManagementServices.AddSample(context.ProjectId, batchId, (int)SchedulingMode.Simple, count);

            ProcessSampleAsyncResult state;
            do
            {
                state = (ProcessSampleAsyncResult)ManagementServices.AddSampleGetState(batchId);
                Thread.Sleep(TimeSpan.FromSeconds(2));
            }
            while (state == ProcessSampleAsyncResult.InProgress);

            if (state != ProcessSampleAsyncResult.Success)
            {
                logger.Exception("Add sample  failed. AddSampleAsyncResult is {0}", state);
            }

            logger.Info("Sample with {0} records was added", count);
        }
    }
}
