﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Confirmit.CATI.Core.Services.Interfaces;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Quota;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Services;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    abstract class BaseChangeCellsAction : BaseSurveyAction
    {
        protected class BaseChangeCellsParam : NamedParams
        {
            public int Count { get; protected set; }

            public TimeSpan Duration { get; protected set; }

            public BaseChangeCellsParam(string param):base(param)
            {
                Count = AsInt("Count");
                Duration = AsTimeSpan("Duration");
            }
        }

        protected BaseChangeCellsParam Params;

        protected BaseChangeCellsAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action) { }

        protected bool IsOpen { get; set; }

        public override void Execute(SurveyContext context, Logger logger)
        {
            var cells = context.QuotasCache.GetRandomCellsWithLock(Params.Count, IsOpen ? QuotaCellState.PessimisticallyClosed :  QuotaCellState.PessimisticallyOpened);

            var cellsByQuota = cells.GroupBy(x => x.QuotaId).ToArray();
            logger.Info("Following cells will be changed: {0}", 
                    cellsByQuota.Select(x =>
                        $"QuotaID={x.Key}, CellIds={String.Join(",", x.Select(y => y.CellId.ToString()))}"));
            
            if (cells.Count < Params.Count)
                logger.Warn("Count of available cells is less than need.");
            
            if (Params.Duration == TimeSpan.Zero)
            {
                foreach (var group in cellsByQuota)
                {
                    UpdateDatabaseCellStates(context, group, IsOpen);

                    var ids = group.Select(x => x.CellId).ToArray();

                    ManagementServices.OnQuotaCellsChanged(
                        context.ProjectId,
                        group.Key,
                        IsOpen ? ids : new int[] { },
                        (!IsOpen) ? ids : new int[] { },
                        new int[]{});

                    context.QuotasCache.UnlockCells(cells, IsOpen ? QuotaCellState.PessimisticallyOpened : QuotaCellState.PessimisticallyClosed);
                }
            }
            else
            {
                foreach (var cell in ArrayTools.EnumerateCollectionInTime(cells, Params.Duration) )
                {
                    logger.Info("set state = {0} for quota {1} cell = {2}", IsOpen, cell.QuotaId, cell.CellId);
                    UpdateDatabaseCellState(context, cell, IsOpen);
                    CloseCell( context, cell);
                    context.QuotasCache.UnlockCell(cell, IsOpen ? QuotaCellState.PessimisticallyOpened : QuotaCellState.PessimisticallyClosed);
                }
            }
        }

        private void CloseCell(SurveyContext context, CellStateInfo cell)
        {
            try
            {
                if (IsOpen)
                {
                    ManagementServices.OnQuotaCellsChanged(context.ProjectId, cell.QuotaId, new[] { cell.CellId }, new int[] { }, new int[] { });
                }
                else
                {
                    ManagementServices.OnQuotaCellsChanged(context.ProjectId, cell.QuotaId, new int[] { }, new[] { cell.CellId }, new int[] { });
                }
            }
            catch (Exception ex)
            {
                new Logger().Error( "Can't close cell {0} for quota {1} on survey {2}. Exception:{3}", cell.CellId, cell.QuotaId, context.Name, ex);
            }
            
        }

        private static void UpdateDatabaseCellState(SurveyContext survey, CellStateInfo cell, bool isOpen)
        {
            DatabaseEngines.Survey(survey.ProjectId).ExecuteNonQuery(
                $"UPDATE [quota_{cell.QuotaId}] SET Counter = @Counter, Limit = @Limit WHERE quotaid = @CellID",
                CommandType.Text,
                new SqlParameter("@Counter", cell.Counter),
                new SqlParameter("@Limit", isOpen ? cell.Limit : cell.Counter),
                new SqlParameter("@CellID", cell.CellId));
        }

        private static void UpdateDatabaseCellStates(SurveyContext survey, IEnumerable<CellStateInfo> cells, bool isOpen)
        {
            foreach (var cell in cells)
            {
                UpdateDatabaseCellState(survey, cell, isOpen);
            }
        }
    }
}
