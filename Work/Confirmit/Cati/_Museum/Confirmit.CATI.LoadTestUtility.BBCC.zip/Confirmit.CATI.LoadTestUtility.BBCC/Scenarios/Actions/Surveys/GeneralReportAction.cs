﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Confirmit.CATI.Core.DAL.Generated.Entity.Adapter;
using Confirmit.CATI.Core.Reports;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class GeneralReportAction : BaseSurveyAction
    {
        private GeneralReportAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action) { }

        private GeneralReportParam _param;
        
        public static GeneralReportAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new GeneralReportAction(action)
                       {
                           _param = new GeneralReportParam(action.Param)
                       };

        }

        public override void Execute(SurveyContext context, Logger logger)
        {
            DateTime startDate = DateTime.UtcNow.AddMinutes(-_param.TimeSpanMinutes);
            DateTime endDate = DateTime.UtcNow;
            List<int> surveyIds = BvSurveyAdapter.GetAll().Select(x => x.SID).ToList();

            switch (_param.ReportType)
            {
                case GeneralReportType.InterviewerProductivity:
                    const bool showDialerAttempts = true;
                    const bool hideEmpty = false;
                    IEnumerable<int> states = Enumerable.Range(1, 120);
                    logger.Info("InterviewerProductivity parameters: startDate = {0}, endDate = {1}", startDate, endDate);

                    ReportManager.GetInterviewerProductivityReportData(surveyIds, startDate, endDate, null, states, showDialerAttempts, hideEmpty, true, null, null, null);
                    logger.Info("InterviewerProductivity report was built");
                    break;
                case GeneralReportType.SurveyProductivity:
                    List<string> its = Enumerable.Range(1, 120).Select(x => x.ToString(CultureInfo.InvariantCulture)).ToList();
                    logger.Info("SurveyProductivity parameters: startDate = {0}, endDate = {1}", startDate, endDate);
                    ReportManager.GetProductivityReportData(startDate, endDate, surveyIds, null, its, null, null, null);
                    logger.Info("SurveyProductivity report was built");
                    break;
            }
        }
    }
}
