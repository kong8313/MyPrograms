﻿using Confirmit.CATI.Common.Random;
using Confirmit.CATI.Core.Batch;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.Supervisor.Core.Surveys;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class AssignCallsAction : BaseCallManagerAction
    {
        public AssignCallsAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action)
            : base(action)
        {
        }

        public static AssignCallsAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new AssignCallsAction(action);
        }

        protected override void Execute(SurveyContext context, BatchParameters batchParameters, Logger logger)
        {
            var personOrGroupIds = CallManagerTools.GetPersonOrGroupIds(context.SaGroup);
            var personOrGroupId = personOrGroupIds[Randomizer.Next(0, personOrGroupIds.Length)];
            
            logger.Info("AssignCalls parameters: personOrGroupId = {0}", personOrGroupId);

            var operation = CallManager.AssignCalls(context.Sid, new []{personOrGroupId}, batchParameters);
            
            ExecuteAsyncOperation(context, operation, logger);
        }
    }
}
