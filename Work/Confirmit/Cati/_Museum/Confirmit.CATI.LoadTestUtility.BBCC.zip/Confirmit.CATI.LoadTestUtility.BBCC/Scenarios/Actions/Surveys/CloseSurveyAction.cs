﻿using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Core.SupervisorService;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    class CloseSurveyAction : BaseSurveyAction
    {
        public CloseSurveyAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action)
            : base(action)
        {
        }

        public override void Execute(SurveyContext context, Logger logger)
        {
            var supervisorServiceClient = ServiceLocator.Resolve<ISupervisorServiceClient>();
            supervisorServiceClient.CloseSurvey(context.Sid);
        }

        public static CloseSurveyAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new CloseSurveyAction(action);
        }
    }
}
