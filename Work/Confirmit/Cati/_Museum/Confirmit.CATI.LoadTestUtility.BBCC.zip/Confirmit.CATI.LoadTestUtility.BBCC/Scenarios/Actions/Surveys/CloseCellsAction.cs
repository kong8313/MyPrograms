﻿using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    class CloseCellsAction : BaseChangeCellsAction
    {
        public CloseCellsAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action)
        {
        }

        public static CloseCellsAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new CloseCellsAction(action)
                       {
                           Params = new BaseChangeCellsParam(action.Param),
                           IsOpen = false
                       };
        }
    }
}
