﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using Confirmit.CATI.Core.Services.Interfaces;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Quota;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Services;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    class OptimisticFcdTestAction : BaseSurveyAction
    {
        public class OptimisticFcdTestParam : NamedParams
        {
            public int Count1 { get; protected set; }
            public int Count2 { get; protected set; }
            public int Count3 { get; protected set; }

            public TimeSpan Duration1 { get; protected set; }
            public TimeSpan Duration2 { get; protected set; }
            public TimeSpan Duration3 { get; protected set; }

            public OptimisticFcdTestParam(string param)
                : base(param)
            {
                Count1 = AsInt("Count1");
                Count2 = AsInt("Count2");
                Count3 = AsInt("Count3");
                Duration1 = AsTimeSpan("Duration1");
                Duration2 = AsTimeSpan("Duration2");
                Duration3 = AsTimeSpan("Duration3");
            }
        }

        public OptimisticFcdTestParam Params { get; set; }

        public OptimisticFcdTestAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action)
            : base(action)
        {
        }

        public static OptimisticFcdTestAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            return new OptimisticFcdTestAction(action)
            {
                Params = new OptimisticFcdTestParam(action.Param)
            };
        }

        public override void Execute(SurveyContext context, Logger logger)
        {
            ChangeCells(context, Params.Count1, QuotaCellState.PessimisticallyOpened, QuotaCellState.OptimisticallyClosed, logger);

            Thread.Sleep(Params.Duration1);

            ChangeCells(context, Params.Count2, QuotaCellState.OptimisticallyClosed, QuotaCellState.PessimisticallyOpened, logger);

            Thread.Sleep(Params.Duration2);

            ChangeCells(context, Params.Count3, QuotaCellState.PessimisticallyOpened, QuotaCellState.OptimisticallyClosed, logger);

            Thread.Sleep(Params.Duration3);
        }

        private void ChangeCells(SurveyContext context, int count, QuotaCellState old, QuotaCellState @new, Logger logger)
        {
            var cells = context.QuotasCache.GetRandomCellsWithLock(count, old);

            logger.Info("Following cells will be moved from {0} to {1} FCD state : {2}",
                old, @new,
                    cells.GroupBy(c => c.QuotaId)
                        .Select(
                            x =>
                                $"QuotaID={x.Key}, CellIds={String.Join(",", x.Select(y => y.CellId.ToString()))}"));

            if (cells.Count < count)
                logger.Warn("Count of available cells is less than need.");


            UpdateDatabaseCellStates(context, cells, @new);
            foreach (var cell in cells)
            {
                var toOpen = new int[]{};
                var toOptClose = new int[] { };
                var toPesClose = new int[] { };
                switch (@new)
                {
                    case QuotaCellState.PessimisticallyOpened:
                        toOpen = new[] {cell.CellId};
                        break;
                    case QuotaCellState.PessimisticallyClosed:
                        toPesClose = new[] { cell.CellId };
                        break;
                    case QuotaCellState.OptimisticallyClosed:
                        toOptClose = new[] { cell.CellId };
                        break;
                }
                ManagementServices.OnQuotaCellsChanged(context.ProjectId, cell.QuotaId, toOpen, toPesClose, toOptClose);
            }
            context.QuotasCache.UnlockCells(cells, @new);
        }

        private static void UpdateDatabaseCellState(SurveyContext survey, CellStateInfo cell, QuotaCellState state)
        {
            DatabaseEngines.Survey(survey.ProjectId).ExecuteNonQuery(
                $"UPDATE [quota_{cell.QuotaId}] SET Counter = @Counter, Limit = @Limit, live_counter=@LiveCounter, live_limit=10 WHERE quotaid = @CellID",
                CommandType.Text,
                new SqlParameter("@Counter", cell.Counter),
                new SqlParameter("@Limit", state != QuotaCellState.PessimisticallyClosed ? cell.Limit : cell.Counter),
                new SqlParameter("@LiveCounter", state != QuotaCellState.OptimisticallyClosed ? 0: cell.Limit + 10),
                new SqlParameter("@CellID", cell.CellId));
        }

        private static void UpdateDatabaseCellStates(SurveyContext survey, IEnumerable<CellStateInfo> cells, QuotaCellState state)
        {
            foreach (var cell in cells)
            {
                UpdateDatabaseCellState(survey, cell, state);
            }
        }
    }
}