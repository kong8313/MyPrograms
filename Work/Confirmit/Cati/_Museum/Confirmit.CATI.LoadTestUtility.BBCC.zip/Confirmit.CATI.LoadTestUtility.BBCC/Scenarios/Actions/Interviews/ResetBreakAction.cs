﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Confirmit.CATI.Common;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Interviews
{
    public class ResetBreakAction : BaseInterviewAction
    {

        public ResetBreakAction(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action) : base(action) { }

        public static ResetBreakAction Parse(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action, ParseContext context)
        {
            return new ResetBreakAction(action);
        }

        public override void Execute(InterviewContext context, Logger logger)
        {
            context.ConsoleService.ContinueWorkAfterBreak(0);
        }
    }
}
