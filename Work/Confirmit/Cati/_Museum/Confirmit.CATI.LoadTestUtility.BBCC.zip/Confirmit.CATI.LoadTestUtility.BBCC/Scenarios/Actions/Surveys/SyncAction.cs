﻿using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Survey;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Surveys
{
    public class SyncAction : BaseSurveyAction
    {
        public SyncAction(TestConfigurationXmlModel.SurveyScenario.SurveyAction action) : base(action) { }
        
        public UtilityScenario Scenario;

        public SyncParam Param;

        public Scenario<SurveyContext> SubScenario;

        public static SyncAction Parse(TestConfigurationXmlModel.SurveyScenario.SurveyAction action, ParseContext context)
        {
            var scenario = new Scenario<SurveyContext>("Sync");

            SurveyScenarioParser.ParseActions(scenario, action.Actions, context);

            return new SyncAction(action)
            {
               Param = new SyncParam(action.Param),
               Scenario = context.Scenario,
               SubScenario = scenario
            };
        }

        public override void Execute(SurveyContext context, Logger logger)
        {
            var maxWaiters = Param.MaxWaiters != 0 ? Param.MaxWaiters : Scenario.AdministratorsCount;

            var sync = new SyncObject(Param.Name, Param.Duration, maxWaiters);
            if (sync.Wait() || Param.Mode == SyncParam.ExecMode.Multiple)
            {
                SubScenario.Execute(context, logger);
            }
        }
    }
}
