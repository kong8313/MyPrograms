﻿using System.Threading;
using Confirmit.CATI.LoadTestUtility.ActionParameters;
using Confirmit.CATI.LoadTestUtility.Scenarios.Contexts;
using Confirmit.CATI.LoadTestUtility.Scenarios.Parsers;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Interviews
{
    public class SleepAction : BaseInterviewAction
    {
        public class SleepParam : NamedParams
        {
            public RandomTimeSpanParam Duration;

            public SleepParam(string param)
                : base(param)
            {
                Duration = AsRandomTimeSpan("Duration");
            }
        }

        private SleepParam Params { get; set; }

        private SleepAction(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action) : base(action){}

        public static SleepAction Parse(TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction action, ParseContext context)
        {
            return new SleepAction(action)
                       {
                           Params = new SleepParam(action.Param)
                       };
        }

        public override void Execute(InterviewContext context, Logger logger)
        {
            var duration = Params.Duration.Value;
            logger.Info("sleep for {0}", duration);
            Thread.Sleep(duration);

        }
    }
}
