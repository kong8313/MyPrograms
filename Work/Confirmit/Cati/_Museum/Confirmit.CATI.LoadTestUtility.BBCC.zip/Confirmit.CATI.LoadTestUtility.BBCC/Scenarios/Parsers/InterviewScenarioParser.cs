﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Confirmit.CATI.LoadTestUtility.Enums;
using Confirmit.CATI.LoadTestUtility.Scenarios.Actions;
using Confirmit.CATI.LoadTestUtility.Scenarios.Actions.Interviews;
using Confirmit.CATI.LoadTestUtility.Tools;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Parsers
{
    class InterviewScenarioParser
    {
        private TestConfigurationXmlModel.InterviewScenario Interview { get; set; }
        private readonly ParseContext _context;

        public InterviewScenarioParser(TestConfigurationXmlModel.InterviewScenario interview, ParseContext context)
        {
            Interview = interview;
            _context = context;
        }

        private static Dictionary<InterviewScenarioActionType, Func<TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction, ParseContext, BaseInterviewAction>> ActionFactories =
            new Dictionary<InterviewScenarioActionType, Func<TestConfigurationXmlModel.InterviewScenario.InterviewScenarioAction, ParseContext, BaseInterviewAction>>()
                {
                    {InterviewScenarioActionType.Interviewing, InterviewingAction.Parse},
                    {InterviewScenarioActionType.SetBreak, SetBreakAction.Parse},
                    {InterviewScenarioActionType.SetAppointment, SetAppointmentAction.Parse},
                    {InterviewScenarioActionType.Complete, CompleteAction.Parse},
                    {InterviewScenarioActionType.Sleep, SleepAction.Parse},
                    {InterviewScenarioActionType.ResetBreak, ResetBreakAction.Parse},
                };

        public InterviewScenario Parse()
        {
            if (Interview.Weight <= 0)
            {
                throw new Logger().Exception("InterviewScenario.Weight should be greater than zero.");
            }

            var scenario = new InterviewScenario(Interview.Name)
                               {
                                   Weight = Interview.Weight
                               };

            foreach (var action in Interview.Actions)
            {
                if (!ActionFactories.ContainsKey(action.Type))
                {
                    new Logger().Error("Wrong action type of action:{0}", action);
                    continue;
                }

                scenario.Add(ActionFactories[action.Type](action, _context));
            }

            return scenario;
        }
    }
}
