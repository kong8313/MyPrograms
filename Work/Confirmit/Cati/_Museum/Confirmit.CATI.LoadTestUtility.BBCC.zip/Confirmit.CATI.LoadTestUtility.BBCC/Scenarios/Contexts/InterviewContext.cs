﻿using System;
using Confirmit.CATI.Common.ConsoleService;
using Confirmit.CATI.LoadTestUtility.CatiInterviewerApi;
using Confirmit.CATI.LoadTestUtility.Survey;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.LoadTestUtility.WorkflowServices;

namespace Confirmit.CATI.LoadTestUtility.Scenarios.Contexts
{
    public class InterviewContext
    {
        public SocketConsoleState State { get; set; }

        public InterviewerWorkflowService.UserInfo User { get; set; }

        public MonitoringService MonitoringService { get; set; }

        public IConsoleService ConsoleService { get; set; }

        public SurveyInfo Survey { get; set; }

        public InterviewerWorkflowService InterviewerWorkflowService { get; set; }

        public InterviewTimingsStopwatch InterviewTimingsStopwatch;

        public TimeSpan Duration;
    }
}
