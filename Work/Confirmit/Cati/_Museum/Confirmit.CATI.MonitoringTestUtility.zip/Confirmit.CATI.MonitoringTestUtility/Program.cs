﻿using System;
using Confirmit.CATI.Core.Misc;
using Confirmit.CATI.Core.Repositories;
using Confirmit.CATI.Core.ServiceLocationExtention;
using Confirmit.CATI.MonitoringTestUtility.Properties;

namespace Confirmit.CATI.MonitoringTestUtility
{
    public class Program
    {
        public static void Main(string[] args)
        {
            WriteSalutation();
            if (!CheckConfiguration())
            {
                return;
            }

            var backendInstanceFactory = new BackendInstanceFactory();

            BackendInstance.Current = backendInstanceFactory.Create(
                Settings.Default.CompanyId,
                HostType.Supervisor);

            int surveyId = 0;
            string projectId = string.Empty;
            if (!GetSurveyIdFromCommandLine(args, ref surveyId, ref projectId))
            {
                return;
            }

            var monitorTestUtility = new MonitoringTestUtility { SurveyId = surveyId, ProjectId = projectId };

            monitorTestUtility.Start();

            System.Console.WriteLine(@"Press any key to finish the monitoring utility.");
            System.Console.ReadKey();

            System.Console.WriteLine(@"Please wait while monitoring stops.");
            monitorTestUtility.Stop();
            System.Console.WriteLine(@"Finished.");
        }

        private static void WriteSalutation()
        {
            System.Console.WriteLine(@"--- Audio monitoring testing utility ---");
            System.Console.WriteLine(@"Cyclically audio monitors all logged in persons for some time. ");
            System.Console.WriteLine(@"Use config file to set up required parameters.");
            System.Console.WriteLine(@"Run as Confirmit.CATI.MonitoringTestUtility.exe to monitor all logged in persons.");
            System.Console.WriteLine(@"Run as Confirmit.CATI.MonitoringTestUtility.exe <projectId> to monitor persons working on a concrete survey.");
            System.Console.WriteLine(@"Usage example: Confirmit.CATI.MonitoringTestUtility.exe p0000195");
            System.Console.WriteLine();
        }

        private static bool CheckConfiguration()
        {
            try
            {
                if (Settings.Default.CompanyId <= 0)
                {
                    System.Console.WriteLine(
                        @"Configuration error: Incorrect companyId '{0}', CompanyId must be positive.",
                        Settings.Default.CompanyId);
                    return false;
                }

                if (Settings.Default.MonitoringDurationInSeconds <= 0)
                {
                    System.Console.WriteLine(
                        @"Configuration error: Incorrect monitoring duration '{0}', MonitoringDurationInSeconds must be positive.",
                        Settings.Default.MonitoringDurationInSeconds);
                    return false;
                }

                if (string.IsNullOrEmpty(Settings.Default.MonitorTelephoneResource))
                {
                    System.Console.WriteLine(@"Configuration error: MonitorTelephoneResource must not be empty.");
                    return false;
                }

                if (string.IsNullOrEmpty(Settings.Default.SupervisorName))
                {
                    System.Console.WriteLine(@"Configuration error: SupervisorName must not be empty.");
                    return false;
                }

                if (Settings.Default.WaitOnStartMonitorFail <= 0)
                {
                    System.Console.WriteLine(
                        @"Configuration error: Incorrect WaitOnStartMonitorFail '{0}', must be positive.",
                        Settings.Default.WaitOnStartMonitorFail);
                    return false;
                }

            }
            catch (Exception ex)
            {
                System.Console.WriteLine(@"Error reading configuration: {0}", ex);
                return false;
            }

            return true;
        }

        private static bool GetSurveyIdFromCommandLine(string[] args, ref int surveyId, ref string projectId)
        {
            if (args.Length != 1)
            {
                surveyId = 0;
                projectId = string.Empty;
                return true;
            }

            try
            {
                var survey = SurveyRepository.GetByName(args[0]);
                projectId = args[0];
                surveyId = survey.SID;
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(@"Cannot find project with Id {0}. ///{1}", args[0], ex);
                return false;
            }

            return true;
        }
    }
}
