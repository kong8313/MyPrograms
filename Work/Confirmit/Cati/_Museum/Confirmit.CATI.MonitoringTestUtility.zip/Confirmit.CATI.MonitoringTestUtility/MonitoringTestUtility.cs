﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading;
using System.Web;

using Confirmit.CATI.Core.AuthoringService;
using Confirmit.CATI.Core.DAL.Generated.Entity.Adapter;
using Confirmit.CATI.Core.DAL.Generated.Entity.Table;
using Confirmit.CATI.Core.Misc;
using Confirmit.CATI.Core.Misc.CP;
using Confirmit.CATI.LoadTestUtility.Tools;
using Confirmit.CATI.MonitoringTestUtility.Properties;

namespace Confirmit.CATI.MonitoringTestUtility
{
    public class MonitoringTestUtility
    {
        private readonly ManualResetEvent stopMonitorPersonsEvent = new ManualResetEvent(false);
        private Thread monitorPersonsThread;

        public int SurveyId { get; set; }
        public string ProjectId { get; set; }

        public void Start()
        {
            this.stopMonitorPersonsEvent.Reset();
            this.monitorPersonsThread = new Thread(this.MonitorPersons);
            this.monitorPersonsThread.Start();
        }

        public void Stop()
        {
            this.stopMonitorPersonsEvent.Set();

            if (!this.monitorPersonsThread.Join(TimeSpan.FromSeconds(Settings.Default.MonitoringDurationInSeconds + 30)))
            {
                System.Console.WriteLine(@"Could not stop monitoring persons thread correctly.");
                this.monitorPersonsThread.Abort();

                if (!this.monitorPersonsThread.Join(TimeSpan.FromSeconds(5)))
                {
                    System.Console.WriteLine(@"Error: monitoring persons thread is not aborted.");
                }
            }

            this.monitorPersonsThread = null;
        }

        private void MonitorPersons()
        {
            try
            {
                string supervisor = Settings.Default.SupervisorName;
                string monitorTelephoneResource = Settings.Default.MonitorTelephoneResource;
                var monitoringDurationTimeoutSpan = TimeSpan.FromSeconds(Settings.Default.MonitoringDurationInSeconds);
                var waitOnStartMonitorFailSpan = TimeSpan.FromSeconds(Settings.Default.WaitOnStartMonitorFail);

                do
                {
                    var loggedInPersons = this.GetLoggedInPersons();
                    if (loggedInPersons.Count == 0)
                    {
                        string surveyStr = string.IsNullOrEmpty(this.ProjectId) ? string.Empty : string.Format(@" to survey {0}", this.ProjectId);
                        System.Console.WriteLine(@"There are no interviewers logged in" + surveyStr + @", waiting while any interviewer logs in...");
                        this.stopMonitorPersonsEvent.WaitOne(TimeSpan.FromSeconds(10));
                        continue;
                    }

                    foreach (var task in loggedInPersons)
                    {
                        try
                        {
                            SimulatedHttpRequest.SetHttpContextWithSimulatedRequest("MyHost", "MyBlog");

                            HttpContext.Current.User = new SupervisorPrincipal(
                                    "userName",
                                    "clientKey",
                                    Settings.Default.CompanyId.ToString(),
                                    "Monitoring test company",
                                    Tabs.None,
                                    false, false, false);

                            HttpContext.Current.Items["BackendInstance"] = BackendInstance.Current;

                            // TODO: Use ISupervisorServiceClient
                            //MonitoringService.StartAudioMonitoring(
                            //    supervisor, task.PersonSID, monitorTelephoneResource);
                            System.Console.WriteLine(@"Supervisor '{0}' started audio monitoring on person '{1}'.", supervisor, task.PersonSID);

                            this.stopMonitorPersonsEvent.WaitOne(monitoringDurationTimeoutSpan);
                        }
                        catch (ThreadAbortException)
                        {
                            throw;
                        }
                        catch (Exception ex)
                        {
                            System.Console.WriteLine(
                                string.Format(
                                "MonitoringTestUtility.MonitorPersons: StartAudioMonitoring failed. /// PersonId = {0}, {1}",
                                task.PersonSID,
                                ex));
                            this.stopMonitorPersonsEvent.WaitOne(waitOnStartMonitorFailSpan);
                            continue;
                        }

                        try
                        {
                            // TODO: Use ISupervisorServiceClient
                            // MonitoringService.StopAudioMonitoring(supervisor, task.PersonSID);
                            System.Console.WriteLine(@"Supervisor '{0}' stopped audio monitoring on person '{1}'.", supervisor, task.PersonSID);
                        }
                        catch (ThreadAbortException)
                        {
                            throw;
                        }
                        catch (Exception ex)
                        {
                            System.Console.WriteLine(
                                string.Format(
                                "MonitoringTestUtility.MonitorPersons: StopAudioMonitoring failed. /// PersonId = {0}, {1}",
                                task.PersonSID,
                                ex));
                        }

                        if (this.stopMonitorPersonsEvent.WaitOne(0))
                        {
                            break;
                        }
                    }
                }
                while (!this.stopMonitorPersonsEvent.WaitOne(0));

                System.Console.WriteLine(@"MonitoringTestUtility.MonitorPersons thread is finished successfully.");
            }
            catch (ThreadAbortException ex)
            {
                System.Console.WriteLine(@"MonitoringTestUtility.MonitorPersons thread is aborted. /// {0}", ex);
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(@"MonitoringTestUtility.MonitorPersons thread is terminated abnormally. /// {0}", ex);
            }
        }

        private List<BvTasksEntity> GetLoggedInPersons()
        {
            bool ignorePersonsWithNonEmptyProblemId = Settings.Default.IgnorePersonsWithNonEmptyProblemId;
            List<BvTasksEntity> loggedInPersons;

            if (this.SurveyId > 0)
            {
                string condition = "[SurveyId] = @SurveyId";
                if (ignorePersonsWithNonEmptyProblemId)
                {
                    condition += " AND ProblemId = 0";
                }

                loggedInPersons = BvTasksAdapter.GetByCondition(condition, new SqlParameter("@SurveyId", this.SurveyId));
            }
            else
            {
                loggedInPersons = ignorePersonsWithNonEmptyProblemId ? BvTasksAdapter.GetByCondition("ProblemId = 0") : BvTasksAdapter.GetAll();
            }

            return loggedInPersons;
        }
    }
}