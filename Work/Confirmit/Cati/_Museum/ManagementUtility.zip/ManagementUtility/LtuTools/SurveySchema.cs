﻿using System.Collections.Generic;
using ConfirmitDialerInterface;
using ManagementUtility.Enums;

namespace ManagementUtility.LtuTools
{
    public class SurveySchema
    {
        public class FieldInfo
        {
            public string Name;

            public FieldType Type;

            public string[] Precodes;
        }

        public class QuotaInfo
        {
            public string Name;

            public bool IsFcd;
            public bool IsCati;
            public bool IsOptimistic;

            public string[] Fields;
        }

        public class ProjectInfo
        {
            public DialingMode DialingMode;

            public bool EnableOpenedReviewRecording;

            public bool EnableInterviewRecording;
        }

        public Dictionary<string, FieldInfo> Fields;
        public List<FieldInfo> FieldsList;

        public Dictionary<string, QuotaInfo> Quotas;

        public ProjectInfo Project;
    }
}