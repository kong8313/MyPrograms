﻿using System;
using System.IO;
using System.Web;
using System.Web.Hosting;

namespace ManagementUtility.LtuTools
{
    public class SimulatedHttpRequest : SimpleWorkerRequest
    {
        private readonly string _host;

        public SimulatedHttpRequest(
            string appVirtualDir, string appPhysicalDir, string page, string query, TextWriter output, string host)
            : base(appVirtualDir, appPhysicalDir, page, query, output)
        {
            if (string.IsNullOrEmpty(host))
            {
                throw new ArgumentNullException("host", @"Host cannot be null nor empty.");
            }

            _host = host;
        }

        public static void SetHttpContextWithSimulatedRequest(string host, string application)
        {
            const string appVirtualDir = "/";
            const string appPhysicalDir = @"c:\projects\SubtextSystem\Subtext.Web\";
            string page = application.Replace("/", string.Empty) + "/default.aspx";
            string query = string.Empty;

            var workerRequest = new SimulatedHttpRequest(
                appVirtualDir, appPhysicalDir, page, query, null, host);
            HttpContext.Current = new HttpContext(workerRequest);
        }

        public override string GetServerName()
        {
            return _host;
        }

        public override string MapPath(string virtualPath)
        {
            return Path.Combine(GetAppPath() ?? string.Empty, virtualPath);
        }
    }
}