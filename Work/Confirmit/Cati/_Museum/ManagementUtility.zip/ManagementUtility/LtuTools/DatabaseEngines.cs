﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using Confirmit.CATI.Core.DAL.Framework;
using ManagementUtility.Interfaces;

namespace ManagementUtility.LtuTools
{
    public class DatabaseEngines : IDatabaseEngines
    {
        private readonly TestConfiguration _testConfiguration;

        private DatabaseEngine _backend;
        private DatabaseEngine _confirmit;
        private DatabaseEngine _confirmlog;
        private DatabaseEngine _survey;
        private DatabaseEngine _defaultDatabase;

        public DatabaseEngines(TestConfiguration testConfiguration)
        {
            _testConfiguration = testConfiguration;
        }

        public DatabaseEngine Backend
        {
            get
            {
                if (_backend == null)
                {
                    var scsb = new SqlConnectionStringBuilder(_testConfiguration.ConnectionStringToBE)
                    {
                        InitialCatalog = NameMaker.DatabaseName(_testConfiguration.CompanyId)
                    };
                    _backend = new DatabaseEngine(scsb.ToString());
                }

                return _backend;
            }
        }

        public DatabaseEngine DefaultDatabase
        {
            get
            {
                if (_defaultDatabase == null)
                {
                    _defaultDatabase = new DatabaseEngine(_testConfiguration.ConnectionStringToBE);
                }

                return _defaultDatabase;
            }
        }

        public DatabaseEngine Confirmit
        {
            get
            {
                if (_confirmit == null)
                {
                    Server server = _testConfiguration.LoadTestEnvironmentInfo.SQLServers.First(x => x.Type == ServerType.ConfirmConfirmlog);
                    _confirmit = new DatabaseEngine(server.ConnectionString);
                }

                return _confirmit;
            }
        }

        public DatabaseEngine Confirmlog
        {
            get
            {
                if (_confirmlog == null)
                {
                    Server server = _testConfiguration.LoadTestEnvironmentInfo.SQLServers.First(x => x.Type == ServerType.ConfirmConfirmlog);
                    var scsb = new SqlConnectionStringBuilder(server.ConnectionString)
                    {
                        InitialCatalog = "confirmlog"
                    };
                    _confirmlog = new DatabaseEngine(scsb.ToString());
                }

                return _confirmlog;
            }
        }

        public DatabaseEngine Survey
        {
            get
            {
                if (_survey == null)
                {
                    Server server = _testConfiguration.LoadTestEnvironmentInfo.SQLServers.First(x => x.Type == ServerType.Survey);
                    _survey = new DatabaseEngine(server.ConnectionString);
                }

                return _survey;
            }
        }

        public DatabaseEngine GetSurvey(string projectId)
        {
            Server server = _testConfiguration.LoadTestEnvironmentInfo.SQLServers.First(x => x.Type == ServerType.Survey);
            var scsb = new SqlConnectionStringBuilder(server.ConnectionString)
            {
                InitialCatalog = NameMaker.CfDatabaseName(projectId)
            };

            return new DatabaseEngine(scsb.ConnectionString);
        }

        public List<string> GetSurveyList()
        {
            return Backend.ExecuteScalarList<string>("select name from BvSurvey", CommandType.Text);
        }

        public void PrepareDatabasesForTest(string catiDbName)
        {
            if (!string.IsNullOrEmpty(_testConfiguration.DialingMode))
            {
                Backend.ExecuteNonQuery(string.Format("UPDATE {0}.dbo.BvSurvey SET [DialMode] = {1}", catiDbName, _testConfiguration.DialingMode), CommandType.Text);
            }

            if (_testConfiguration.ClearBvDialersTable == "1")
            {
                Backend.ExecuteNonQuery(string.Format("delete from {0}.dbo.BvDialers", catiDbName), CommandType.Text);
            }

            Backend.ExecuteNonQuery(string.Format("update statistics {0}.dbo.BvSvySchedule", catiDbName), CommandType.Text);
        }

        public void UpdateTestresultDatabase(TimeSpan duration, string reason, string branchName, string version)
        {
            string updateTestresultQuery = Properties.Resources.CATI_eventlog_statistics;

            updateTestresultQuery = updateTestresultQuery.Replace("{CompanyId}", _testConfiguration.CompanyId);
            updateTestresultQuery = updateTestresultQuery.Replace("{Description}", Path.GetFileNameWithoutExtension(_testConfiguration.LtuConfigPath));
            updateTestresultQuery = updateTestresultQuery.Replace(
                "{TestResultBackupPath}",
                Path.Combine(_testConfiguration.BackupFolderPathOnSqlServer, "test_result_db.bak"));
            updateTestresultQuery = updateTestresultQuery.Replace("{Duration}", ((int)duration.TotalSeconds).ToString(CultureInfo.InvariantCulture));
            updateTestresultQuery = updateTestresultQuery.Replace("{Reason}", reason);
            updateTestresultQuery = updateTestresultQuery.Replace("{Version}", branchName);
            updateTestresultQuery = updateTestresultQuery.Replace("{Branch}", version);
            updateTestresultQuery = updateTestresultQuery.Replace("{LtuLinkedServerName}", TestEnvironmentEngine.LtuLinkedServerName);
            
            Confirmlog.ExecuteBatch(updateTestresultQuery, true);

            string testResultDbSourcePath = Path.Combine(_testConfiguration.SurveyBackupServerFolderPath, "test_result_db.bak");
            string testResultDbDestinationPath = Path.Combine(_testConfiguration.PerfResultSharedPath, "_Test Result DB.bak");

            File.Copy(testResultDbSourcePath, testResultDbDestinationPath, true);
            File.Delete(testResultDbSourcePath);
        }

        // Two methods for test connection only. Can't use DatabaseEngine class from Core, because BackendInstance.Current is not initialized (and CATI databases can be absent)

        public static void ExecuteNonQuery(string connectionString, string query)
        {
            using (var cn = new SqlConnection(connectionString))
            {
                cn.Open();

                using (var sqlCommand = new SqlCommand(query, cn))
                {
                    sqlCommand.CommandTimeout = 0;                    
                    sqlCommand.ExecuteNonQuery();
                }
            }
        }

        public static T ExecuteScalar<T>(string connectionString, string query)
        {
            using (var cn = new SqlConnection(connectionString))
            {
                cn.Open();

                using (var sqlCommand = new SqlCommand(query, cn))
                {
                    sqlCommand.CommandTimeout = 0;
                    return (T)sqlCommand.ExecuteScalar();
                }
            }
        }
    }
}