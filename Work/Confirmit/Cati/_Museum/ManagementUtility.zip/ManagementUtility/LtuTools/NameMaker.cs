﻿using System;
using System.IO;
using Confirmit.CATI.Core.Misc;

namespace ManagementUtility.LtuTools
{
    public class NameMaker
    {
        public static string CfDatabaseName(string projectId)
        {
            return "survey_" + projectId;
        }

        public static string InterviewDataTableName(string scenarioName)
        {
            return String.Format("InterviewDataTable_{0}", scenarioName);
        }

        public static string ServiceName(string companyId)
        {
            return MultimodeInstanceName.CompanyIdToServiceName(Convert.ToInt32(companyId));
        }

        public static string DatabaseName(string companyId)
        {
            return MultimodeInstanceName.CompanyIdToDatabaseName(Convert.ToInt32(companyId));
        }

        public static string CatiBackupName(TestConfiguration testConfiguration)
        {
            return string.Format("{0}_CATI.bak", GetBackupPrefixFromLtuConfigPath(testConfiguration));
        }

        public static string SurveyBackupName(TestConfiguration testConfiguration, string surveyId)
        {
            return string.Format("{0}_{1}.bak", GetBackupPrefixFromLtuConfigPath(testConfiguration), surveyId);
        }

        public static string GetBackupPrefixFromLtuConfigPath(TestConfiguration testConfiguration)
        {
            string ltuConfigFileName = Path.GetFileNameWithoutExtension(testConfiguration.LtuConfigPath);
            if (string.IsNullOrEmpty(ltuConfigFileName))
            {
                throw new Exception("Wrong ltu config path: " + testConfiguration.LtuConfigPath);
            }

            int index = ltuConfigFileName.IndexOf(".", StringComparison.Ordinal);
            return index > 0 ? ltuConfigFileName.Substring(0, index) : ltuConfigFileName;
        }
    }
}