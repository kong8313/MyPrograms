﻿using System.Xml.Serialization;

namespace ManagementUtility
{
    public enum DialerType
    {
        Prots,
        TciSimulator,
        TciReal,
        GenericSimulator,
        GenericProts
    }

    public enum ServerType
    {
        Cati,
        ConfirmConfirmlog,
        Survey
    }

    [XmlType(AnonymousType = true)]
    [XmlRoot("LoadTestEnvironment", Namespace = "", IsNullable = false)]
    public class LoadTestEnvironment
    {
        public LoadTestEnvironment()
        {
            CATIServers = new CATIServers
            {
                MachineNames = new string[0]
            };

            ConfirmitServer = string.Empty;
            LoadBalancerServer = string.Empty;
            LTUServers = new LTUServers
            {
                MachineNames = new string[0]
            };

            SQLServers = new Server[0];

            Dialer = new Dialer();
        }

        [XmlElement("CATIServers")]
        public CATIServers CATIServers { get; set; }

        [XmlElement("ConfirmitServer")]
        public string ConfirmitServer { get; set; }

        [XmlElement("LoadBalancerServer")]
        public string LoadBalancerServer { get; set; }

        [XmlElement("LTUServers")]
        public LTUServers LTUServers { get; set; }

        [XmlElement("Dialer")]
        public Dialer Dialer { get; set; }

        [XmlArray("SQLServers"), XmlArrayItem("Server")]
        public Server[] SQLServers { get; set; }
    }

    [XmlType(AnonymousType = true)]
    public class CATIServers
    {
        public string[] MachineNames { get; set; }
    }

    [XmlType(AnonymousType = true)]
    public class LTUServers
    {
        public string[] MachineNames { get; set; }
    }   
    
    [XmlType(AnonymousType = true)]
    public class Dialer
    {
        [XmlElement("Type")]
        public DialerType Type { get; set; }

        [XmlElement("MachineName")]
        public string MachineName { get; set; }

        [XmlElement("WSMachineName")]
        public string WSMachineName { get; set; }

        [XmlElement("DialerConfigurationConfigName")]
        public string DialerConfigurationConfigName { get; set; }
    }

    [XmlType(AnonymousType = true)]
    public class SQLServers
    {
        [XmlElement("Server")]
        public Server[] ServerArray { get; set; }
    }

    [XmlType(AnonymousType = true)]
    public class Server
    {
        [XmlElement("Type")]
        public ServerType Type { get; set; }

        [XmlElement("ConnectionString")]
        public string ConnectionString { get; set; }

        [XmlElement("MachineName")]
        public string MachineName { get; set; }
    }    
}