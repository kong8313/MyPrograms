﻿using System;
using System.IO;

namespace ManagementUtility.Controller
{
    public class TestParams
    {
        public string EnvConfigPath { get; set; }
        public string MuConfigPath { get; set; }
        public string LtuLocalPath { get; set; }
        public string[] LtuConfigs { get; set; }
        public TimeSpan? TestDuration { get; set; }
        
        public bool DoNotCleanConfirmlog { get; set; }
        public bool RunPreparation { get; set; }
        public string Reason { get; set; }

        public string GetLtuLocalFolder()
        {
            if (LtuLocalPath != null)
            {
                return new DirectoryInfo(LtuLocalPath).Name;
            }

            return null;
        }
    }
}