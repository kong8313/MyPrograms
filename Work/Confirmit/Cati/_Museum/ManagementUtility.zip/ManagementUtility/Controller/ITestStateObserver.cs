﻿namespace ManagementUtility.Controller
{
    public interface ITestStateObserver
    {
        void ShowAction(string text);

        void OnCurrentLtuConfigChanged(string configName, int index, int count);

        void EnableAllButtons();
    }
}
