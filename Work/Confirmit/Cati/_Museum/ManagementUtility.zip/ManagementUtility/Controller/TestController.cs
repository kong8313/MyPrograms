﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Common.SideBySide;
using Confirmit.CATI.Core.SupervisorService;
using Confirmit.CATI.Core.Telephony;
using ManagementUtility.Interfaces;
using ManagementUtility.LtuTools;
using ManagementUtility.Tools;

namespace ManagementUtility.Controller
{
    public enum TestState
    {
        Stopped,
        Starting,
        Running,
        Stopping
    }

    public class TestController
    {
        public TestState State { get; private set; } = TestState.Stopped;
        private TestParams Parameters { get; set; }
        private TestConfiguration CurrentConfiguration { get; set; }
        private int currentLtuConfigIndex = 0;

        private Stopwatch _timer = new Stopwatch();

        private readonly ILogger _logger;
        private readonly IFactory _factory;
        private readonly ITestEnvironmentEngine _testEnvironmentEngine;
        private readonly ITestConfigurationReader _testConfigurationReader;
        private readonly LtuEngine _ltuEngine;
        private readonly TelephonyConfigurator _telephonyConfigurator;
        private readonly Initializer _initializer;
        private readonly PerformanceCounterEngine _performanceCounterEngine;
        private readonly IServiceEngine _serviceEngine;
        private readonly ITestStateObserver _testStateObserver;

        public TestController(ILogger logger, IFactory factory, ITestEnvironmentEngine testEnvironmentEngine,
            ITestConfigurationReader testConfigurationReader,
            IServiceEngine serviceEngine, IPsExecExecutor psExecExecutor,
            IRemoteProcessKiller remoteProcessKiller, ITestStateObserver testStateObserver)
        {
            _logger = logger;
            _factory = factory;
            _testEnvironmentEngine = testEnvironmentEngine;
            _testConfigurationReader = testConfigurationReader;
            _serviceEngine = serviceEngine;
            _testStateObserver = testStateObserver;
            _ltuEngine = new LtuEngine(_logger, psExecExecutor, remoteProcessKiller);
           
            _telephonyConfigurator = new TelephonyConfigurator(_logger, serviceEngine, psExecExecutor, remoteProcessKiller, testStateObserver);
            var _configsEngine = new ConfigsEngine(_logger);

            ICopier copier = new Copier(_logger, Application.StartupPath, factory, _configsEngine);
            _performanceCounterEngine = new PerformanceCounterEngine(_logger, copier, psExecExecutor, Application.StartupPath);
            _initializer = new Initializer(_logger, factory, copier, serviceEngine, psExecExecutor, _telephonyConfigurator, testStateObserver);

        }

        public void Start(TestParams parameters)
        {
            if (State != TestState.Stopped)
                return;

            State = TestState.Starting;
            Parameters = parameters;
            currentLtuConfigIndex = 0;

            _testStateObserver.ShowAction("A testing of parameters in progress...");
            Thread.Sleep(100);
            string message;

            try
            {
                message = _testEnvironmentEngine.TestNecessarySettings(parameters);
            }
            catch (Exception ex)
            {
                message = $"An exception has occurred: {ex.Message}. See log for details.";
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
            }

            if (!string.IsNullOrEmpty(message))
            {
                _logger.WriteLog(TraceEventType.Warning, message);
                _testStateObserver.ShowAction("The utility has found some issues. You have to fix them before continue.\r\n" +
                                            message);
                _testStateObserver.EnableAllButtons();
                State = TestState.Stopped;
                return;
            }

            try
            {
                StartExecution(parameters, currentLtuConfigIndex);
            }
            catch (StopByUserException ex)
            {
                _testStateObserver.ShowAction(ex.Message);
                _logger.WriteLog(TraceEventType.Error, ex.Message);
                State = TestState.Stopped;
            }
            catch (Exception ex)
            {
                _testStateObserver.ShowAction(string.Format("Execution has finished with error:\r\n{0}\r\nSee log for details", ex.Message));
                _logger.WriteLog(TraceEventType.Error, "An error occured during an execution:\r\n" + ex);
                State = TestState.Stopped;
            }
        }

        private void StartExecution(TestParams parameters, int ltuConfigIndex)
        {
            if (ltuConfigIndex >= parameters.LtuConfigs.Length)
            {
                _testStateObserver.OnCurrentLtuConfigChanged(null, 0, 0);
                State = TestState.Stopped;
                return;
            }
            else
            {
                State = TestState.Starting;
            }

            var currentLtuConfig = parameters.LtuConfigs[currentLtuConfigIndex];

            _testStateObserver.OnCurrentLtuConfigChanged(currentLtuConfig, ltuConfigIndex, parameters.LtuConfigs.Length);

            _logger.WriteLog("Start execution");

            _testStateObserver.ShowAction("Read config files");

            CurrentConfiguration = _testConfigurationReader.ReadConfiguration(parameters.EnvConfigPath, parameters.MuConfigPath, currentLtuConfig, parameters.GetLtuLocalFolder());

            _testStateObserver.ShowAction("Prepare LTU for start");
            _initializer.PrepareLTUForStart(CurrentConfiguration, parameters.DoNotCleanConfirmlog, Parameters.LtuLocalPath);

            RunLTU(parameters, CurrentConfiguration);

            _testStateObserver.ShowAction("Wait until LTU finishes");

            _timer = Stopwatch.StartNew();
            
        }

        private void RunLTU(TestParams parameters, TestConfiguration testConfiguration)
        {
            string catiBackupFilePath = Path.Combine(testConfiguration.CatiBackupServerFolderPath, NameMaker.CatiBackupName(testConfiguration));
            IDatabaseEngines databaseEngines = _factory.CreateDatabaseEnginesObject(testConfiguration);
            ISqlServerBackupTools sqlServerBackupTools = _factory.CreateSqlServerBackupToolsObject(
                _logger, testConfiguration, databaseEngines, _testStateObserver);
            string catiDbName = NameMaker.DatabaseName(testConfiguration.CompanyId);
            
            if (File.Exists(catiBackupFilePath))
            {
                _serviceEngine.StopCatiServices(testConfiguration);

                _testStateObserver.ShowAction(string.Format("Restore database '{0}' from '{1}'", catiDbName, catiBackupFilePath));
                sqlServerBackupTools.RestoreDatabase(Path.Combine(testConfiguration.BackupFolderPathOnSqlServer, NameMaker.CatiBackupName(testConfiguration)), catiDbName);

                List<string> surveyProjectIds = databaseEngines.GetSurveyList();

                if (IsSurveyBackupsAvailable(testConfiguration, surveyProjectIds) && surveyProjectIds.Count >= testConfiguration.LtuTestConfigurationXmlModel.TotalSurvey)
                {
                    sqlServerBackupTools.RestoreSurveyDatabases(surveyProjectIds);
                }
                else
                {
                    RunPreparation(parameters, testConfiguration, sqlServerBackupTools);
                }
            }
            else
            {
                RunPreparation(parameters, testConfiguration, sqlServerBackupTools);
            }

            _testStateObserver.ShowAction("Prepare databases for test");
            databaseEngines.PrepareDatabasesForTest(catiDbName);

            _serviceEngine.StartCatiServices(testConfiguration);

            _testStateObserver.ShowAction("Start performance counter gathering");
            _performanceCounterEngine.StartPerformanceCounterGathering(testConfiguration);
            
            _telephonyConfigurator.StartDialerSimulatorIfNeeded(testConfiguration);

            _testStateObserver.ShowAction("Run LTU on all servers in test mode");
            _ltuEngine.RunLTUOnAllServers(testConfiguration, "Test", parameters.GetLtuLocalFolder());

            State = TestState.Running;
        }

        private static bool IsSurveyBackupsAvailable(TestConfiguration testConfiguration, IEnumerable<string> surveyProjectIds)
        {
            return surveyProjectIds.All(surveyProjectId => File.Exists(Path.Combine(testConfiguration.SurveyBackupServerFolderPath, NameMaker.SurveyBackupName(testConfiguration, surveyProjectId))));
        }

        private void RunPreparation(TestParams parameters, TestConfiguration testConfiguration, ISqlServerBackupTools sqlServerBackupTools)
        {
            _testStateObserver.ShowAction("Run preparation process");
            if (!parameters.RunPreparation &&
                DialogResult.No == MessageBox.Show("Needed backups for the selected LTU config were not found. LTU will be run in preparation mode. Continue?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                throw new StopByUserException();
            }

            _initializer.ReCreateCompany(testConfiguration);

            _testStateObserver.ShowAction("Run LTU on the first server in preparation mode");
            _ltuEngine.RunLTUOnAllServers(testConfiguration, "Preparation", parameters.GetLtuLocalFolder());

            while (!_ltuEngine.IsAllProcessesStoped())
            {
                Thread.Sleep(1000);
            }

            CheckDatabaseAfterPreparationPhase(testConfiguration);

            _serviceEngine.StopCatiServices(testConfiguration);

            sqlServerBackupTools.CreateCatiAndSurveyBackups();
        }

        private void CheckDatabaseAfterPreparationPhase(TestConfiguration testConfiguration)
        {
            IDatabaseEngines databaseEngines = _factory.CreateDatabaseEnginesObject(testConfiguration);
            List<string> surveyProjectIds = databaseEngines.GetSurveyList();
            if (surveyProjectIds.Count < testConfiguration.LtuTestConfigurationXmlModel.TotalSurvey)
            {
                throw new Exception(
                    $"Prepared CATI database doesn't contain enouth count of survey({surveyProjectIds.Count} of {testConfiguration.LtuTestConfigurationXmlModel.TotalSurvey}) to execute test.");
            }
        }

        public void OnTimerTick()
        {
            if (Parameters == null || State != TestState.Running)
            {
                return;
            }

            if (_ltuEngine.IsFirstProcessStoped() || (Parameters.TestDuration != null && _timer.Elapsed >= Parameters.TestDuration))
            {
                Stop(Parameters.GetLtuLocalFolder());

                StartExecution(Parameters, ++currentLtuConfigIndex);
            }
        }

        public void Stop(string ltuLocalFolder)
        {
            if (State != TestState.Running)
                return;

            try
            {
                State = TestState.Stopping;

                IDatabaseEngines databaseEngines = _factory.CreateDatabaseEnginesObject(CurrentConfiguration);

                _testStateObserver.ShowAction("'Master' LTU process has stopped. Stop all 'Slave' LTU processes");
                _ltuEngine.StopLTUOnAllServers(CurrentConfiguration, ltuLocalFolder);

                _testStateObserver.ShowAction("Stop dialer simulator");
                _telephonyConfigurator.StopDialerSimulator(CurrentConfiguration);

                _testStateObserver.ShowAction("Collect performance counter results");
                _performanceCounterEngine.StopPerformanceCounterGathering(CurrentConfiguration);

                _testStateObserver.ShowAction("Update 'testresult' database");
                databaseEngines.UpdateTestresultDatabase(_timer.Elapsed, Parameters.Reason, new SideBySideManager().SideBySideName, GetCurrentVersion());

                _initializer.RegisterServersInConfirmitDb(CurrentConfiguration, "unregister");

                _testStateObserver.ShowAction("Execution has finished successfully!");
                _logger.WriteLog("Execution has finished successfully");
            }
            catch (Exception ex)
            {
                _testStateObserver.ShowAction(string.Format("An error occured during stopping of LTU process:\r\n{0}\r\nSee log for details", ex.Message));
                _logger.WriteLog(TraceEventType.Error, "An error occured during stopping of LTU process:\r\n" + ex);
            }

            State = TestState.Stopped;

        }

        public TimeSpan? GetRemainingTime()
        {
            if (Parameters == null || Parameters.TestDuration == null)
                return null;

            return Parameters.TestDuration - _timer.Elapsed;

        }

        private string GetCurrentVersion()
        {
            return new Version(FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).ProductVersion).ToString();
        }


        public void CheckConfiguration(TestParams parameters)
        {
            if (State != TestState.Stopped)
                return;

            State = TestState.Starting;

            _testStateObserver.ShowAction("A testing of parameters in progress...");
            var message = new StringBuilder();

            try
            {
                message.Append(_testEnvironmentEngine.TestAllSettings(parameters));

                message.Append("The test has finished!");
            }
            catch (Exception ex)
            {
                message.Append(_testEnvironmentEngine.ErrorMessage);
                message.AppendFormat("An exception has occurred: {0}. See log for details.", ex.Message);
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
            }

            _testStateObserver.ShowAction(message.ToString());

            _testStateObserver.EnableAllButtons();

            State = TestState.Stopped;
        }
    }
}
