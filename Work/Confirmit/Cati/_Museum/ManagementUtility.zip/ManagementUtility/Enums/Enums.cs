﻿using System.Xml.Serialization;

namespace ManagementUtility.Enums
{
    public enum FieldType
    {
        Normal,
        Background
    }

    public enum QuotaTargetFunc
    {
        [XmlEnum("TargetArg")]
        TargetArg,
        [XmlEnum("MaxCounterPlusTargetArg")]
        MaxCounterPlusTargetArg,
        [XmlEnum("CounterPlusTargetArg")]
        CounterPlusTargetArg
    }

    public enum EnumAction
    {
        [XmlEnum("OpenSurvey")]
        OpenSurvey,

        [XmlEnum("CloseSurvey")]
        CloseSurvey,

        [XmlEnum("AddSample")]
        AddSample,

        [XmlEnum("SyncRespondentData")]
        SyncRespondentData,

        [XmlEnum("Sleep")]
        Sleep,

        [XmlEnum("OpenCells")]
        OpenCells,

        [XmlEnum("CloseCells")]
        CloseCells,

        [XmlEnum("MoveCalls")]
        MoveCalls,

        [XmlEnum("MoveAndRescheduleCalls")]
        MoveAndRescheduleCalls,

        [XmlEnum("ActivateCalls")]
        ActivateCalls,

        [XmlEnum("ChangeCallsPriority")]
        ChangeCallsPriority,

        [XmlEnum("ChangeCallsShiftType")]
        ChangeCallsShiftType,

        [XmlEnum("AssignCalls")]
        AssignCalls,

        [XmlEnum("GeneralReport")]
        GeneralReport,

        [XmlEnum("Sync")]
        Sync,

        [XmlEnum("ExecSql")]
        ExecSql,

        [XmlEnum("SetEvent")]
        SetEvent,

        [XmlEnum("ResetEvent")]
        ResetEvent,

        [XmlEnum("GetCallsPage")]
        GetCallsPage,

        [XmlEnum("CreateFilter")]
        CreateFilter,
    }

    public enum InterviewScenarioActionType
    {
        [XmlEnum("Interviewing")]
        Interviewing,
        [XmlEnum("SetBreak")]
        SetBreak,
        [XmlEnum("SetAppointment")]
        SetAppointment,
        [XmlEnum("Complete")]
        Complete,
        [XmlEnum("Sleep")]
        Sleep,
        [XmlEnum("ResetBreak")]
        ResetBreak
    }
}