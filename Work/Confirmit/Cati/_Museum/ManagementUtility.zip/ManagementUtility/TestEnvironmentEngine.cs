﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Confirmit.Security.Crypto.Web;
using ConfirmitDialerInterface;
using ManagementUtility.Controller;
using ManagementUtility.Interfaces;
using ManagementUtility.LtuTools;
using ManagementUtility.Tools;
using Microsoft.Win32;
using ILogger = ManagementUtility.Interfaces.ILogger;

namespace ManagementUtility
{
    public class TestEnvironmentEngine : ITestEnvironmentEngine
    {
        public const string LtuLinkedServerName = "CatiLinkedServerLTU";

        private readonly ILogger _logger;
        private readonly IXmlConfigParser _xmlConfigParser;
        private readonly ISurveySchemaReader _surveySchemaReader;
        private readonly ITestConfigurationReader _testConfigurationReader;
        private readonly IServiceEngine _serviceEngine;
        private readonly IInstaller _installer;
        private readonly IRemoteProcessKiller _remoteProcessKiller;

        private DataCollectorSets _dataCollectorSets;
        private LoadTestEnvironment _loadTestEnvironment;
        private LtuTestConfigurationXmlModel _ltuTestConfigurationXmlModel;
        private TestConfiguration _testConfiguration;

        private readonly string _sideBySideName;
        private readonly string _psExecPath;

        private StringBuilder _errorMessage;

        private bool IsErrorMessageEmpty()
        {
            return string.IsNullOrEmpty(_errorMessage.ToString());
        }

        public string ErrorMessage
        {
            get
            {
                return _errorMessage.ToString();
            }
        }

        public TestEnvironmentEngine(
            ILogger logger, IXmlConfigParser xmlConfigParser, ISurveySchemaReader surveySchemaReader, ITestConfigurationReader testConfigurationReader, IServiceEngine serviceEngine,
            IInstaller installer, IRemoteProcessKiller remoteProcessKiller, string sideBySideName, string psExecPath)
        {
            _sideBySideName = sideBySideName;
            _psExecPath = psExecPath;

            _logger = logger;
            _xmlConfigParser = xmlConfigParser;
            _surveySchemaReader = surveySchemaReader;
            _testConfigurationReader = testConfigurationReader;
            _serviceEngine = serviceEngine;
            _installer = installer;
            _remoteProcessKiller = remoteProcessKiller;
            _errorMessage = new StringBuilder();
        }

        public string TestUpdatePossibility(string envConfigPath, string muConfigPath, string ltuLocalFolder)
        {
            _errorMessage = new StringBuilder();

            ValidateEnvironmentAndManagementUtilityConfig(envConfigPath, muConfigPath);
            IsFileExistAndAvailable("PsExec.exe", _psExecPath);

            _testConfiguration = new TestConfiguration(_surveySchemaReader, _dataCollectorSets, _loadTestEnvironment, null, string.Empty, ltuLocalFolder);

            IsFileExistAndAvailable("simulator kit", _installer.GetLtuSimulatorKitFilePath);
            IsFileExistAndAvailable("TciDialer WS kit", _installer.GetTciDialerWebServiceKitFilePath);

            if (!IsErrorMessageEmpty())
            {
                return _errorMessage.ToString();
            }

            if (_testConfiguration.LoadTestEnvironmentInfo.Dialer.Type == DialerType.GenericSimulator)
            {
                string remotePath = _installer.GetRemoteRootFolderPath(_testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName);
                TestRemoteLocationsAvailability(remotePath, string.Format("No full access to '{0}'. Will be problems with copying of installation kits to the '{1}' server.",
                    remotePath, _testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName));

                CheckIsProductInstalled(_testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName, _installer.GetLtuSimulatorProductName);
            }
            else if (_testConfiguration.LoadTestEnvironmentInfo.Dialer.Type == DialerType.TciReal || _testConfiguration.LoadTestEnvironmentInfo.Dialer.Type == DialerType.TciSimulator)
            {
                string remotePath = _installer.GetRemoteRootFolderPath(_testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName);
                TestRemoteLocationsAvailability(remotePath, string.Format("No full access to '{0}'. Will be problems with copying of installation kits to the '{1}' server.",
                    remotePath, _testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName));

                CheckIsProductInstalled(_testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName, _installer.GetTciDialerWebServiceProductName);
            }

            CheckSideBySideNameInFileDescription(_installer.GetLtuSimulatorKitFilePath, _installer.GetLtuSimulatorProductName + " kit has a different version of SideBySide name");
            CheckSideBySideNameInFileDescription(_installer.GetTciDialerWebServiceKitFilePath, _installer.GetTciDialerWebServiceProductName + " kit has a different version of SideBySide name");

            return _errorMessage.ToString();
        }

        private void CheckIsProductInstalled(string serverName, string productNamePart)
        {
            bool isProductFound = false;
            const string keyName = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall";
            using (var regKey = RegistryKey.OpenRemoteBaseKey(RegistryHive.LocalMachine, serverName, RegistryView.Registry64))
            using (RegistryKey uninstallKey = regKey.OpenSubKey(keyName))
            {
                if (uninstallKey == null)
                {
                    throw new Exception("Wrong registry key " + keyName);
                }

                foreach (string subkeyName in uninstallKey.GetSubKeyNames())
                {
                    using (RegistryKey subkey = uninstallKey.OpenSubKey(subkeyName))
                    {
                        if (subkey == null)
                        {
                            throw new Exception(string.Format("Wrong subkey '{0}' for registry key '{1}'", subkeyName, keyName));
                        }

                        if (subkey.GetValue("DisplayName") == null)
                        {
                            continue;
                        }

                        string productDisplayName = subkey.GetValue("DisplayName").ToString();
                        if (productDisplayName.Contains(productNamePart) && productDisplayName.Contains(_sideBySideName))
                        {
                            _logger.WriteLog("Product '{0}' was found on '{1}' server", productDisplayName, serverName);
                            isProductFound = true;
                            break;
                        }
                    }
                }
            }

            if (!isProductFound)
            {
                _errorMessage.AppendFormat("MU can't find an installed version of '{0}' on '{1}' server", productNamePart, serverName);
            }
        }

        private void CheckSideBySideNameInFileDescription(string filePath, string errorMessage)
        {
            var fvi = FileVersionInfo.GetVersionInfo(filePath);
            if (!fvi.FileDescription.StartsWith("SxS: " + _sideBySideName + "."))
            {
                _errorMessage.AppendLine(errorMessage);
            }
        }

        public string TestAllSettings(TestParams parameters)
        {
            TestNecessarySettings(parameters);

            if (IsErrorMessageEmpty())
            {
                CheckLtuLinkedServer();
                VerifyBackupAbility();
            }

            return _errorMessage.ToString();
        }

        public string TestNecessarySettings(TestParams parameters)
        {
            _errorMessage = new StringBuilder();

            if (parameters.LtuConfigs.Length == 0)
            {
                _errorMessage.AppendLine("Config for LTU isn't checked");
            }

            ValidateConfigs(parameters.LtuConfigs, parameters.EnvConfigPath, parameters.MuConfigPath, parameters.GetLtuLocalFolder());

            if (!IsErrorMessageEmpty())
            {
                return _errorMessage.ToString();
            }

            _testConfiguration = new TestConfiguration(
                _surveySchemaReader, _dataCollectorSets, _loadTestEnvironment, _ltuTestConfigurationXmlModel, parameters.LtuConfigs.First(), parameters.GetLtuLocalFolder());

            ValidateManagementConfigParameters();
            ValidateBackupFolders();
            TestRemoteLtuLocationsAvailability();
            CheckCatiServices();
            TestEncrypting();

            IsFileExistAndAvailable("PsExec.exe", _psExecPath);

            IsFileExistAndAvailable("BuildServerRegistrator.exe", Path.Combine(Application.StartupPath, @"BuildServerRegistrator\BuildServerRegistrator.exe"));
            IsFileExistAndAvailable("ServerConfiguration.xml", Path.Combine(Application.StartupPath, @"BuildServerRegistrator\Configs\ServerConfiguration.xml"));

            if (_testConfiguration.IsDialerUse)
            {
                CheckDialerConfigurationUtility();

                if (_testConfiguration.DialerSimulatorAutomaticMode)
                {
                    switch (_testConfiguration.LoadTestEnvironmentInfo.Dialer.Type)
                    {
                        case DialerType.GenericSimulator:
                            if (IsFileExistAndAvailable("simulator scenario (remote path)", _testConfiguration.SimulatorScenarioRemotePath))
                            {
                                CheckSimulatorScenarioXml();
                            }
                            break;
                        case DialerType.TciSimulator:
                            IsFileExistAndAvailable("BvTci scenario (remote path)", _testConfiguration.BvTciScenarioRemotePath);
                            IsFileExistAndAvailable("", Path.Combine(Path.GetDirectoryName(_testConfiguration.BvTciScenarioRemotePath) ?? string.Empty, "BvTciDialerSimulator.exe"));
                            break;
                        case DialerType.TciReal:
                            if (IsFileExistAndAvailable("responce sim cfg (remote path)", _testConfiguration.ResponseSimCfgRemotePath))
                            {
                                ValidateResponceSimCfgTxt();
                            }
                            break;
                    }
                }
            }

            TestRemoteWmiConnection();

            return _errorMessage.ToString();
        }

        private void TestRemoteWmiConnection()
        {
            foreach (string machineName in _testConfiguration.GetServerNames(ProductType.LTU))
            {
                try
                {
                    _remoteProcessKiller.KillProcess(machineName, "Test12321Test.exe");
                }
                catch (Exception ex)
                {
                    _logger.WriteLog(TraceEventType.Error, "An error occurred during the testing of MWI connection to the server '{0}'. Exception:\r\n{1}", machineName, ex.ToString());
                    _errorMessage.AppendFormat("No access to MWI on '{0}' server\r\n", machineName);
                }
            }

            if (_testConfiguration.IsDialerUse && _testConfiguration.DialerSimulatorAutomaticMode &&
                (_testConfiguration.LoadTestEnvironmentInfo.Dialer.Type == DialerType.TciReal ||
                 _testConfiguration.LoadTestEnvironmentInfo.Dialer.Type == DialerType.TciSimulator))
            {
                try
                {
                    _remoteProcessKiller.KillProcess(_testConfiguration.LoadTestEnvironmentInfo.Dialer.MachineName, "Test12321Test.exe");
                }
                catch (Exception ex)
                {
                    _logger.WriteLog(TraceEventType.Error, "An error occurred during the testing of MWI connection to the server '{0}'. Exception:\r\n{1}", _testConfiguration.LoadTestEnvironmentInfo.Dialer.MachineName, ex.ToString());
                    _errorMessage.AppendFormat("No access to MWI on '{0}' server\r\n", _testConfiguration.LoadTestEnvironmentInfo.Dialer.MachineName);
                }
            }
        }

        private void ValidateResponceSimCfgTxt()
        {
            string responseSimCfgContent = File.ReadAllText(_testConfiguration.ResponseSimCfgRemotePath);
            int startIndex = responseSimCfgContent.IndexOf("[RESPONSES]", StringComparison.InvariantCultureIgnoreCase);
            int endIndex = responseSimCfgContent.IndexOf("[CALIBRATEDRESPONSES]", StringComparison.InvariantCultureIgnoreCase);
            if (startIndex < 0)
            {
                _errorMessage.AppendFormat("ResponceSimCfg.txt file doesn't contain '[RESPONSES]' section. File location: '{0}'.\r\n", _testConfiguration.ResponseSimCfgRemotePath);
            }

            if (endIndex < 0)
            {
                _errorMessage.AppendFormat("ResponceSimCfg.txt file doesn't contain '[CALIBRATEDRESPONSES]' section. File location: '{0}'.\r\n", _testConfiguration.ResponseSimCfgRemotePath);
            }

            if (endIndex < startIndex)
            {
                _errorMessage.AppendFormat("ResponceSimCfg.txt file has wrong structure. '[RESPONSES]' section has to be situated before '[CALIBRATEDRESPONSES]' section. File location: '{0}'.\r\n", _testConfiguration.ResponseSimCfgRemotePath);
            }

            string responseExePath = Path.Combine(Path.GetDirectoryName(_testConfiguration.ResponseSimCfgRemotePath) ?? string.Empty, "ResponseSim.exe");
            IsFileExistAndAvailable("ResponseSim.exe", responseExePath);
        }

        private void CheckDialerConfigurationUtility()
        {
            IsFileExistAndAvailable("dialer configuration", _testConfiguration.LoadTestEnvironmentInfo.Dialer.DialerConfigurationConfigName);
            IsFileExistAndAvailable("configuration utility", _testConfiguration.DialerConfigurationUtility);
        }

        private void CheckSimulatorScenarioXml()
        {
            try
            {
                SimulatorScenario.Deserialize(_testConfiguration.SimulatorScenarioRemotePath);
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Error, "An error occurred during desearization of SimulatorScenario.xml file in location '{0}'. Exception:\r\n{1}", _testConfiguration.SimulatorScenarioRemotePath, ex.ToString());
                _errorMessage.AppendFormat("Can't deserialize SimulatorScenario.xml file in location '{0}'.\r\n", _testConfiguration.SimulatorScenarioRemotePath);
            }
        }

        private bool IsFileExistAndAvailable(string fileNameForLogging, string fileLocation)
        {
            _logger.WriteLog("Check a path to " + fileNameForLogging + " file.");

            if (!File.Exists(fileLocation))
            {
                _errorMessage.AppendLine(string.Format("File {0} is not found in the location '{1}'.", Path.GetFileName(fileLocation), Path.GetDirectoryName(fileLocation)));
                return false;
            }

            try
            {
                File.Move(fileLocation, fileLocation + ".test");
                File.Move(fileLocation + ".test", fileLocation);

                return true;
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Error, "Can't change name (move) of file '{0}'. An error occured:\r\n{1}", fileLocation, ex.ToString());
                _errorMessage.AppendLine(string.Format("MU hasn't an access to the file {0} in the location '{1}'.", Path.GetFileName(fileLocation), Path.GetDirectoryName(fileLocation)));
            }

            return false;
        }

        private void TestEncrypting()
        {
            try
            {
                EncryptionUsingMachineKey.Encrypt(DataProtection.All, "TestString");
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
                _errorMessage.AppendLine("MU can't encrypt strings. Check 'machineKey' parameter in Management Utility config.");
            }
        }

        private void CheckCatiServices()
        {
            if (!_serviceEngine.IsCatiServicesExists(_testConfiguration))
            {
                _errorMessage.AppendLine("Not all CATI services exist on CATI Backend servers. Probably, your CATI system is not configured properly, or Side By Side name of MU and CATI system are different.");
            }
            else if (!_serviceEngine.IsCatiServicesStarted(_testConfiguration))
            {
                _errorMessage.AppendLine("Not all CATI services started on CATI Backend servers");
            }
        }

        private void VerifyBackupAbility()
        {
            VerifyBackupAbility(ServerType.Cati, "CATI SQL server", _testConfiguration.CatiBackupServerFolderPath);
            VerifyBackupAbility(ServerType.Survey, "SQL server with survey databases", _testConfiguration.SurveyBackupServerFolderPath);
        }

        private void VerifyBackupAbility(ServerType serverType, string serverNameForErrorMessage, string remoteFolderPathWithBackups)
        {
            try
            {
                Server catiServer = _loadTestEnvironment.SQLServers.First(x => x.Type == serverType);
                DatabaseEngines.ExecuteNonQuery(catiServer.ConnectionString, "IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'TestMU_xxx') BEGIN CREATE DATABASE [TestMU_xxx] END");

                bool isNeedToRemoveBackupFolder = false;
                if (!Directory.Exists(remoteFolderPathWithBackups))
                {
                    Directory.CreateDirectory(remoteFolderPathWithBackups);
                    isNeedToRemoveBackupFolder = true;
                    _logger.WriteLog(TraceEventType.Information, "Create directory '{0}'.", remoteFolderPathWithBackups);
                }
                string query = string.Format(@"BACKUP DATABASE TestMU_xxx TO DISK = '{0}'", Path.Combine(_testConfiguration.BackupFolderPathOnSqlServer, "TestMU_xxx.bak"));
                DatabaseEngines.ExecuteNonQuery(catiServer.ConnectionString, query);

                File.Delete(Path.Combine(remoteFolderPathWithBackups, "TestMU_xxx.bak"));
                if (isNeedToRemoveBackupFolder)
                {
                    Directory.Delete(remoteFolderPathWithBackups);
                    _logger.WriteLog(TraceEventType.Information, "Remove directory '{0}'.", remoteFolderPathWithBackups);
                }
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
                _errorMessage.AppendFormat("Warning: Can't create backup on {0}. Add credentials to '{1}' folder or try to run SQL service with 'Local System' account.\r\n",
                    serverNameForErrorMessage, _testConfiguration.BackupFolderPathOnSqlServer);
            }
            finally
            {
                try
                {
                    Server catiServer = _loadTestEnvironment.SQLServers.First(x => x.Type == serverType);
                    DatabaseEngines.ExecuteNonQuery(catiServer.ConnectionString, "IF EXISTS (SELECT * FROM sys.databases WHERE name = 'TestMU_xxx') BEGIN DROP DATABASE [TestMU_xxx] END");
                }
                catch (Exception ex)
                {
                    _logger.WriteLog(TraceEventType.Error, ex.ToString());
                    _logger.WriteLog(TraceEventType.Warning, "TestMU_xxx database wasn't removed on SQL server with type {0}", serverType);
                }
            }
        }

        private void CheckLtuLinkedServer()
        {
            Server confirmitServer = _loadTestEnvironment.SQLServers.First(x => x.Type == ServerType.ConfirmConfirmlog);
            string query = $"select datasource from master..sysservers where srvname = '{LtuLinkedServerName}'";
            var dbSource = DatabaseEngines.ExecuteScalar<string>(confirmitServer.ConnectionString, query);
            Server catiServer = _loadTestEnvironment.SQLServers.First(x => x.Type == ServerType.Cati);

            var confirmitServerConnectionBuilder = new SqlConnectionStringBuilder(confirmitServer.ConnectionString);
            string confirmitSqlServerName = confirmitServerConnectionBuilder.DataSource;

            var catiServerConnectionBuilder = new SqlConnectionStringBuilder(catiServer.ConnectionString);
            string catiSqlServerName = catiServerConnectionBuilder.DataSource;

            if (string.IsNullOrEmpty(dbSource))
            {
                if (DialogResult.Yes == MessageBox.Show($"{LtuLinkedServerName} is not found. Do you want to create it?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                {
                    CreateLtuLinkedServer(confirmitServer.ConnectionString, catiServerConnectionBuilder);
                }
                else
                {
                    _errorMessage.AppendFormat($"Warning: {LtuLinkedServerName} isn't found. Create it on '{confirmitSqlServerName}' server. It has to point to '{catiSqlServerName}' server\r\n");
                }
            }
            else if (!string.Equals(dbSource, catiSqlServerName, StringComparison.InvariantCultureIgnoreCase))
            {
                if (DialogResult.Yes == MessageBox.Show($"{LtuLinkedServerName} point to wrong server. Do you want to recreate it?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                {
                    DropLtuLinkedServer(confirmitServer.ConnectionString);
                    CreateLtuLinkedServer(confirmitServer.ConnectionString, catiServerConnectionBuilder);
                }
                else
                {
                    _errorMessage.AppendFormat($"Warning: {LtuLinkedServerName} point to wrong server: '{dbSource}'. It has to point to '{catiSqlServerName}' server\r\n");
                }
            }
        }

        private void DropLtuLinkedServer(string confirmitServerConnectionString)
        {
            try
            {
                string query = $"EXEC sp_dropserver '{LtuLinkedServerName}', 'droplogins'";
                DatabaseEngines.ExecuteNonQuery(confirmitServerConnectionString, query);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occured during dropping {LtuLinkedServerName}:\r\n{ex.Message}\r\nSee log for details");
                _logger.WriteLog(TraceEventType.Error, $"An error occured during dropping {LtuLinkedServerName}:\r\n" + ex);
            }
        }

        private void CreateLtuLinkedServer(string confirmitServerConnectionString, SqlConnectionStringBuilder catiServerConnectionBuilder)
        {
            try
            {
                string query = $@"
EXEC sp_addlinkedserver 
	@server = N'{LtuLinkedServerName}', 
	@srvproduct=N'{LtuLinkedServerName}', 
	@provider=N'SQLNCLI11', 
	@datasrc=N'{catiServerConnectionBuilder.DataSource}'

EXEC sp_addlinkedsrvlogin @rmtsrvname=N'{LtuLinkedServerName}', @useself=N'False', @locallogin=NULL, @rmtuser=N'{catiServerConnectionBuilder.UserID}', @rmtpassword='{catiServerConnectionBuilder.Password}'

EXEC sp_serveroption @server=N'{LtuLinkedServerName}', @optname=N'rpc', @optvalue=N'true'

EXEC sp_serveroption @server=N'{LtuLinkedServerName}', @optname=N'rpc out', @optvalue=N'true'";
                DatabaseEngines.ExecuteNonQuery(confirmitServerConnectionString, query);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occured during making {LtuLinkedServerName}:\r\n{ex.Message}\r\nSee log for details");
                _logger.WriteLog(TraceEventType.Error, $"An error occured during making {LtuLinkedServerName}:\r\n" + ex);
            }
        }

        private bool DoTestSqlQuery(string connectionString, string message)
        {
            try
            {
                const string testQuery = "SELECT * FROM master..sysdatabases";
                DatabaseEngines.ExecuteNonQuery(connectionString, testQuery);
                return true;
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
                _errorMessage.AppendLine(message);
                return false;
            }
        }

        private void TestSqlConnections()
        {
            Server server = _loadTestEnvironment.SQLServers.FirstOrDefault(x => x.Type == ServerType.Cati);
            if (server == null)
            {
                _errorMessage.AppendLine("No information about CATI SQL server in Load Test Environment config");
            }
            else
            {
                var scsb = new SqlConnectionStringBuilder(server.ConnectionString)
                {
                    InitialCatalog = "master"
                };

                if (DoTestSqlQuery(scsb.ConnectionString, "Connection string to CATI SQL server in Load Test Environment config is wrong."))
                {
                    DoTestSqlQuery(server.ConnectionString, "No connection to default CATI database.");

                    scsb.InitialCatalog = NameMaker.DatabaseName(ConfigurationManager.AppSettings["CompanyID"]);
                    DoTestSqlQuery(scsb.ConnectionString, string.Format("No connection to instance CATI SQL database '{0}'.", scsb.InitialCatalog));
                }
            }

            server = _loadTestEnvironment.SQLServers.FirstOrDefault(x => x.Type == ServerType.ConfirmConfirmlog);
            if (server == null)
            {
                _errorMessage.AppendLine("No information about SQL server with Confirm/Confirmlog databases in Load Test Environment config");
            }
            else
            {
                if (DoTestSqlQuery(server.ConnectionString, "Connection string to SQL server with Confirm/Confirmlog databases in Load Test Environment config is wrong."))
                {
                    var scsb = new SqlConnectionStringBuilder(server.ConnectionString)
                    {
                        InitialCatalog = "confirmlog"
                    };
                    DoTestSqlQuery(scsb.ConnectionString, "No connection to 'confirmlog' database.");

                    scsb.InitialCatalog = "confirm";
                    DoTestSqlQuery(scsb.ConnectionString, "No connection to 'confirm' database.");
                }
            }

            server = _loadTestEnvironment.SQLServers.FirstOrDefault(x => x.Type == ServerType.Survey);
            if (server == null)
            {
                _errorMessage.AppendLine("No information about Survey SQL server in Load Test Environment config");
            }
            else
            {
                DoTestSqlQuery(server.ConnectionString, "Connection string to Survey SQL server in Load Test Environment config is wrong.");
            }
        }

        private void ValidateConfigs(string[] ltuConfigs, string envConfigPath, string muConfigPath, string ltuLocalFolder)
        {
            ValidateEnvironmentAndManagementUtilityConfig(envConfigPath, muConfigPath);

            if (_errorMessage.ToString().Contains("Can't read Management Utility config"))
            {
                return;
            }

            foreach (var ltuConfigSubPath in ltuConfigs)
            {
                string ltuConfigPath = Path.GetFullPath(ltuLocalFolder + "\\Configs\\" + ltuConfigSubPath);
                if (!File.Exists(ltuConfigPath))
                {
                    _errorMessage.AppendLine(string.Format("Load Test Utility config path '{0}' is wrong", ltuConfigPath));
                }
                else
                {
                    ValidateLTUConfig(ltuConfigPath, ltuLocalFolder);
                }
            }
        }

        private void ValidateEnvironmentAndManagementUtilityConfig(string envConfigPath, string muConfigPath)
        {
            muConfigPath = Path.GetFullPath("configs\\" + muConfigPath);
            if (!File.Exists(muConfigPath))
            {
                _errorMessage.AppendLine(string.Format("Management Utility config path '{0}' is wrong", muConfigPath));
            }
            else
            {
                ValidateManagementUtilityConfig(muConfigPath);
            }

            envConfigPath = Path.GetFullPath("configs\\" + envConfigPath);
            if (!File.Exists(envConfigPath))
            {
                _errorMessage.AppendLine(string.Format("Environment config path '{0}' is wrong", envConfigPath));
            }
            else if (IsErrorMessageEmpty())
            {
                ValidateEnvironmentConfig(envConfigPath);
            }
        }

        private void ValidateLTUConfig(string ltuConfigPath, string ltuLocalFolder)
        {
            try
            {
                _ltuTestConfigurationXmlModel = _xmlConfigParser.GetXmlConfig<LtuTestConfigurationXmlModel>(ltuConfigPath);
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
                _errorMessage.AppendFormat("Can't read LTU config. An error occured:\r\n{0}\r\n", ex.Message);
                return;
            }

            if (_ltuTestConfigurationXmlModel == null)
            {
                _errorMessage.AppendFormat("LTU config is wrong. Check '{0}' file.\r\n", ltuConfigPath);
                return;
            }

            if (_ltuTestConfigurationXmlModel.DialerScenarios.Count != 1)
            {
                _errorMessage.AppendFormat("LTU config '{0}' has to contains one and only one dialer scenario.\r\n", ltuConfigPath);
                return;
            }

            int resOfParse;
            if (!int.TryParse(_ltuTestConfigurationXmlModel.DialerScenarios[0].CallsCountPerInterviewer, out resOfParse))
            {
                _errorMessage.AppendFormat("LTU config '{0}' contains wrong parameter in dialer scenario: CallsCountPerInterviewer. It must be a number.\r\n", ltuConfigPath);
            }

            foreach (var outcomeList in _ltuTestConfigurationXmlModel.DialerScenarios[0].OutcomeLists)
            {
                CallOutcome res;
                if (!Enum.TryParse(outcomeList.CallOutcome, true, out res))
                {
                    _errorMessage.AppendFormat("LTU config '{0}' contains wrong parameter in dialer scenario: CallOutcome. {1} is unknown value.\r\n", ltuConfigPath, outcomeList.CallOutcome);
                }

                if (!int.TryParse(outcomeList.DistributionWeight, out resOfParse))
                {
                    _errorMessage.AppendFormat("LTU config '{0}' contains wrong parameter in dialer scenario: DistributionWeight. It must be a number.\r\n", ltuConfigPath);
                }

                if (!int.TryParse(outcomeList.ProcessingTime.Split('-').Last(), out resOfParse))
                {
                    _errorMessage.AppendFormat("LTU config '{0}' contains wrong parameter in dialer scenario: ProcessingTime. It must be a number or has a format 'number-number'.\r\n", ltuConfigPath);
                }
            }

            var regex = new Regex("SurveyLayoutName=(?<value>\\\"(?<layoutName>[^\\\"]*)\\\")");

            foreach (var survey in _ltuTestConfigurationXmlModel.SurveyScenarios)
            {
                var schemaPath = Path.GetFullPath(ltuLocalFolder + "\\configs\\" + survey.SchemaPath);
                var schemaText = File.ReadAllText(schemaPath);
                var result = regex.Match(schemaText);
                if (!result.Success)
                {
                    _errorMessage.AppendLine($"Survey schema: {schemaPath} doesn't contain defenition of layout");
                    continue;
                }

                var layoutName = result.Groups["layoutName"].Value;
                Server confirmitServer = _loadTestEnvironment.SQLServers.First(x => x.Type == ServerType.ConfirmConfirmlog);
                string query = $"select COUNT(*) from confirm..SurveyLayout where name='{layoutName}'";
                var count = DatabaseEngines.ExecuteScalar<int>(confirmitServer.ConnectionString, query);
                if (count == 0)
                {
                    query = $"select top(1) name from confirm..SurveyLayout where IsPublic = 1 AND Deleted = 0";
                    var existedLayoutName =
                        DatabaseEngines.ExecuteScalar<string>(confirmitServer.ConnectionString, query);
                    var res = MessageBox.Show(
                        $"Survey schema: {schemaPath} contains not existed layout with name:{layoutName}. Do you want to update layoutName to {existedLayoutName} automatically?",
                        "Warning!!", MessageBoxButtons.OKCancel);

                    if (res != DialogResult.OK)
                    {
                        _errorMessage.AppendLine(
                            $"Survey schema: {schemaPath} contains not existed layout with name:{layoutName}");
                        continue;
                    }

                    schemaText = regex.Replace(schemaText, (match) => $"SurveyLayoutName=\"{existedLayoutName}\"");
                    File.WriteAllText(schemaPath, schemaText);
                }

            }
        }

        private void ValidateManagementUtilityConfig(string muConfigPath)
        {
            try
            {
                _xmlConfigParser.LoadManagementUtilityConfig(muConfigPath);

                if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["DataCollectorSetsConfigPath"]))
                {
                    _errorMessage.AppendLine("'DataCollectorSetsConfigPath' parameter in Management Utility config isn't found.");
                }
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
                _errorMessage.AppendFormat("Can't read Management Utility config. An error occured:\r\n{0}\r\n", ex.Message);
                return;
            }

            if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["BackupFolderPathOnSqlServer"]))
            {
                _errorMessage.AppendLine("'BackupFolderPathOnSqlServer' parameter in Management Utility config isn't found.");
            }

            if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["CompanyID"]))
            {
                _errorMessage.AppendLine("'CompanyID' parameter in Management Utility config isn't found.");
            }

            if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["DialerSimulatorAutomaticMode"]))
            {
                _errorMessage.AppendLine("'DialerSimulatorAutomaticMode' parameter in Management Utility config isn't found.");
            }

            if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["DialingMode"]))
            {
                _errorMessage.AppendLine("'DialingMode' parameter in Management Utility config isn't found.");
            }

            if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["SimulatorScenarioXmlPath"]))
            {
                _errorMessage.AppendLine("'SimulatorScenarioXmlPath' parameter in Management Utility config isn't found.");
            }

            if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["ResponseSimCfgPath"]))
            {
                _errorMessage.AppendLine("'ResponseSimCfgPath' parameter in Management Utility config isn't found.");
            }

            if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["BvTciScenarioXmlPath"]))
            {
                _errorMessage.AppendLine("'BvTciScenarioXmlPath' parameter in Management Utility config isn't found.");
            }

            if (!IsErrorMessageEmpty())
            {
                return;
            }

            string dataCollectorSetsConfigPath = Path.Combine(
                Path.GetDirectoryName(muConfigPath) ?? string.Empty,
                ConfigurationManager.AppSettings["DataCollectorSetsConfigPath"]);
            if (!File.Exists(dataCollectorSetsConfigPath))
            {
                _errorMessage.AppendFormat("Data Collector Sets config path '{0}' is wrong. Check 'DataCollectorSetsConfigPath' parameter in Management Utility config.\r\n", dataCollectorSetsConfigPath);
            }
            else
            {
                VerifyDataCollectorSetTemplates(dataCollectorSetsConfigPath);
            }
        }

        private void ValidateEnvironmentConfig(string envConfigPath)
        {
            try
            {
                _loadTestEnvironment = _xmlConfigParser.GetXmlConfig<LoadTestEnvironment>(envConfigPath);
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
                _errorMessage.AppendFormat("Can't read Environment config. An error occured:\r\n{0}\r\n", ex.Message);
                return;
            }

            _testConfigurationReader.ReplaceLocalhostsToCurrentServerName(_loadTestEnvironment);

            if (_loadTestEnvironment.CATIServers.MachineNames.Length == 0)
            {
                _errorMessage.AppendLine("Environment config is wrong. It must contain alteast one Backend server name in the section 'CATIServers'");
            }

            if (string.IsNullOrEmpty(_loadTestEnvironment.ConfirmitServer))
            {
                _errorMessage.AppendLine("Environment config is wrong. It must contain Confirmit server name in the section 'ConfirmitServer'");
            }

            if (_loadTestEnvironment.LTUServers.MachineNames.Length == 0)
            {
                _errorMessage.AppendLine("Environment config is wrong. It must contain alteast one LTU server name in the section 'LTUServers'");
            }

            if (_loadTestEnvironment.SQLServers.Length != 3)
            {
                _errorMessage.AppendLine("Environment config is wrong. It must contain information about three SQL servers in the section 'SQLServers': to CATI default database, to confirm/confirmlog databases and to survey databases");
            }

            TestSqlConnections();
        }

        private void VerifyDataCollectorSetTemplates(string dataCollectorSetsConfigPath)
        {
            try
            {
                _dataCollectorSets = _xmlConfigParser.GetXmlConfig<DataCollectorSets>(dataCollectorSetsConfigPath);
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
                _errorMessage.AppendFormat("Can't read Data Collector Sets config. An error occured:\r\n{0}\r\n", ex.Message);
                return;
            }

            if (_dataCollectorSets.DataCollectorSetInfoArray == null)
            {
                _dataCollectorSets.DataCollectorSetInfoArray = new DataCollectorSetInfo[0];
            }

            foreach (var dataCollectorSetInfo in _dataCollectorSets.DataCollectorSetInfoArray)
            {
                string fullPath = Path.GetFullPath(dataCollectorSetInfo.XmlTemplate);
                if (!File.Exists(fullPath))
                {
                    _errorMessage.AppendFormat("Data Collector Sets xml template '{0}' is wrong. Check parameters in Data Collector Sets config.\r\n", fullPath);
                }

                dataCollectorSetInfo.XmlTemplate = fullPath;
            }
        }

        private void TestRemoteLtuLocationsAvailability()
        {
            foreach (string machineName in _testConfiguration.LoadTestEnvironmentInfo.LTUServers.MachineNames)
            {
                string remotePath = string.Format(@"\\{0}\c$\{1}", machineName, TestConfiguration.RootLtuFolderName);
                TestRemoteLocationsAvailability(remotePath, string.Format("No full access to '{0}'. Will be problems with copying of LTU to the '{1}' server.", remotePath, machineName));
            }
        }

        private void TestRemoteLocationsAvailability(string remotePath, string errorMessage)
        {
            try
            {
                if (Directory.Exists(remotePath))
                {
                    Directory.Move(remotePath, remotePath + "_test");
                    Directory.Move(remotePath + "_test", remotePath);
                }
                else
                {
                    Directory.CreateDirectory(remotePath);
                    Directory.Delete(remotePath);
                }
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
                _errorMessage.AppendLine(errorMessage);
            }
        }

        private void ValidateManagementConfigParameters()
        {
            TestNotEmpty(_testConfiguration.CompanyId, "Parameter CompanyId is not specified in the management config");
            TestNotEmpty(_testConfiguration.CompanyAlias, "Parameter CompanyAlias is not specified in the management config");
            TestNotEmpty(_testConfiguration.BackupFolderPathOnSqlServer, "Parameter BackupFolderPathOnSqlServer is not specified in the management config");
        }

        private void TestNotEmpty(string value, string errorMessage)
        {
            if (string.IsNullOrEmpty(value))
            {
                _errorMessage.AppendLine(errorMessage);
            }
        }


        private void ValidateBackupFolders()
        {
            try
            {
                ValidateDirectoryAccess(_testConfiguration.CatiBackupServerFolderPath);
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
                _errorMessage.AppendFormat("Wrong parameter BackupFolderPathOnSqlServer. Program hasn't a full access to CATI SQL server shared folder: {0}.\r\n", _testConfiguration.CatiBackupServerFolderPath);
            }

            try
            {
                ValidateDirectoryAccess(_testConfiguration.SurveyBackupServerFolderPath);
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
                _errorMessage.AppendFormat("Wrong parameter BackupFolderPathOnSqlServer. Program hasn't a full access to Survey SQL server shared folder: {0}.\r\n", _testConfiguration.SurveyBackupServerFolderPath);
            }
        }

        private void ValidateDirectoryAccess(string backupServerFolderPath)
        {
            if (!Directory.Exists(backupServerFolderPath))
            {
                Directory.CreateDirectory(backupServerFolderPath);
            }

            string testFilePath = Path.Combine(backupServerFolderPath, "t1e2s3t4.txt");
            File.WriteAllText(testFilePath, "test");
            File.Delete(testFilePath);
        }
    }
}