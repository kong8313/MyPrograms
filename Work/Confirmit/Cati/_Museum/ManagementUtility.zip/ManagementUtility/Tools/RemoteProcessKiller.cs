﻿using System.Management;
using ManagementUtility.Interfaces;

namespace ManagementUtility.Tools
{
    public class RemoteProcessKiller : IRemoteProcessKiller
    {
        private readonly ILogger _logger;

        public RemoteProcessKiller(ILogger logger)
        {
            _logger = logger;
        }

        public void KillProcess(string machineName, string processName)
        {
            var scope = new ManagementScope(string.Format(@"\\{0}\root\cimv2", machineName));
            scope.Connect();

            var query = new ObjectQuery("SELECT * FROM Win32_Process WHERE Name='" + processName + "'");
            var searcher = new ManagementObjectSearcher(scope, query);
            ManagementObjectCollection objectCollection = searcher.Get();

            foreach (ManagementObject managementObject in objectCollection)
            {
                _logger.WriteLog("Try to stop process '{0}' on server '{1}'", processName, machineName);
                managementObject.InvokeMethod("Terminate", null);
            }
        }
    }
}