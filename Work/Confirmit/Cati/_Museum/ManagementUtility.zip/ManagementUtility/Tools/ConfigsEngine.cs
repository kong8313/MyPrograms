﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Xml;
using ManagementUtility.Interfaces;

namespace ManagementUtility.Tools
{
    public class ConfigsEngine : IConfigsEngine
    {
        private readonly ILogger _logger;

        public ConfigsEngine(ILogger logger)
        {
            _logger = logger;
        }


        public void ConfigureBsrConfig(string bsrLocalPath, TestConfiguration testConfiguration)
        {
            try
            {
                _logger.WriteLog("Begin ConfigureBsrConfig");

                var serverConfigurationPath = Path.Combine(bsrLocalPath, @"Configs\ServerConfiguration.xml");

                var xmlDocument = new XmlDocument();
                xmlDocument.Load(serverConfigurationPath);

                var serverConfigurationNode = xmlDocument.SelectSingleNode($"//ServerConfigurations/ServerConfiguration[@name='ltu']");

                var configrmLogConnectionString = testConfiguration.LoadTestEnvironmentInfo.SQLServers.First(x => x.Type == ServerType.ConfirmConfirmlog).ConnectionString;
                var sb = new SqlConnectionStringBuilder(configrmLogConnectionString);

                serverConfigurationNode.SelectSingleNode("SqlServerName").InnerText = sb.DataSource;
                serverConfigurationNode.SelectSingleNode("SqlLoginName").InnerText = sb.UserID;
                serverConfigurationNode.SelectSingleNode("SqlPassword").InnerText = sb.Password;

                xmlDocument.Save(serverConfigurationPath);
            }
            finally
            {
                _logger.WriteLog("End ConfigureBsrConfig");
            }
        }

        private void SetAttribute(XmlDocument xmlDocument, string xpath, string attributeName, string attributeValue, XmlNamespaceManager nsmgr)
        {
            _logger.WriteLog("Add attribute {0} with value {1} to node {2}", attributeName, attributeValue, xpath);

            var selectedNode = (XmlElement)xmlDocument.SelectSingleNode(xpath, nsmgr);

            if (selectedNode != null)
            {
                selectedNode.SetAttribute(attributeName, attributeValue);
                _logger.WriteLog("Succeded");
            }
        }


        private void AddTextToNode(XmlDocument xmlDocument, string xpath, string value, XmlNamespaceManager nsmgr)
        {
            _logger.WriteLog("Add text {0} to node {1}", value, xpath);

            XmlNode selectedNode = xmlDocument.SelectSingleNode(xpath, nsmgr);

            if (selectedNode != null)
            {
                selectedNode.InnerText = value;
                _logger.WriteLog("Succeded");
            }
        }

        public void ConfigureLtuConfig(string backendMachineName, string ltuLocation, TestConfiguration testConfiguration, string ltuLoggingPath)
        {
            _logger.WriteLog("Begin ConfigureLtuConfig");

            try
            {
                var ltuFolderName = new DirectoryInfo(ltuLocation).Name;
                string configPath = Path.Combine(ltuLocation, ltuFolderName + ".exe.config");

                var xmlDocument = new XmlDocument
                {
                    PreserveWhitespace = true
                };
                xmlDocument.Load(configPath);

                var nsMgr = new XmlNamespaceManager(xmlDocument.NameTable);

                SetAttribute(xmlDocument, "//configuration/system.serviceModel/client/endpoint[@name='CatiConsoleServiceEndpoint']", "address",
                    string.Format("https://{0}/MultimodeInstance", backendMachineName), nsMgr);

                SetAttribute(xmlDocument, "//configuration/system.serviceModel/client/endpoint[@name='MonitoringServiceEndpoint']", "address",
                    string.Format("https://{0}/MonitoringInterviewerMultimodeInstance", backendMachineName), nsMgr);

                SetAttribute(xmlDocument, "//configuration/system.serviceModel/client/endpoint[@name='CatiConsoleStateServiceEndpoint']", "address",
                    string.Format("https://{0}/ConsoleStateMultimodeInstance", backendMachineName), nsMgr);

                SetAttribute(xmlDocument, "//configuration/system.serviceModel/client/endpoint[@name='CatiConsoleStateServiceEndpointHttp']", "address",
                    string.Format("http://{0}/ConsoleStateMultimodeInstanceHttp", backendMachineName), nsMgr);

                SetAttribute(xmlDocument, "//configuration/system.serviceModel/client/endpoint[@name='SupervisorServiceEndpoint']", "address",
                    string.Format("http://{0}/SupervisorMultimodeInstance", backendMachineName), nsMgr);

                SetAttribute(xmlDocument, "//configuration/system.serviceModel/client/endpoint[@name='ErrorReportingServiceEndpoint']", "address",
                    string.Format("https://{0}/ErrorReportingMultimodeInstance", backendMachineName), nsMgr);
                
                SetAttribute(xmlDocument, "//configuration/system.serviceModel/client/endpoint[@name='ConsoleAuthorizationServiceEndpoint']", "address",
                    string.Format("https://{0}/ConsoleAuthorizationMultimodeInstance", backendMachineName), nsMgr);

                SetAttribute(xmlDocument, "//configuration/appSettings/add[@key='MultimodeWebServiceURL']", "value",
                   string.Format("http://{0}/ManagementMultimodeInstance", backendMachineName), nsMgr);

                SetAttribute(xmlDocument, "//configuration/appSettings/add[@key='InterviewerApiBaseUrl']", "value",
                   $"{GetInterviewerApiBaseUrlScheme(backendMachineName)}://{backendMachineName}/catiinterviewer", nsMgr);

                SetAttribute(xmlDocument, "//configuration/appSettings/add[@key='ConnectionStringToBE']", "value",
                    testConfiguration.ConnectionStringToBE, nsMgr);

                SetAttribute(xmlDocument, "//configuration/appSettings/add[@key='ConnectionStringToCF']", "value",
                    testConfiguration.ConnectionStringToCF, nsMgr);

                SetAttribute(xmlDocument, "//configuration/appSettings/add[@key='CompanyID']", "value",
                    testConfiguration.CompanyId, nsMgr);
                SetAttribute(xmlDocument, "//configuration/appSettings/add[@key='CompanyAlias']", "value",
                    testConfiguration.CompanyAlias, nsMgr);
                 
                AddTextToNode(xmlDocument, "//configuration/applicationSettings/Confirmit.CATI.LoadTestUtility.Properties.Settings/setting[@name='Confirmit_CATI_LoadTestUtility_ConfirmitAuthoring_Authoring']/value",
                   string.Format("http://{0}/confirmit/WebServices/18.0/Authoring.asmx", testConfiguration.LoadTestEnvironmentInfo.ConfirmitServer), nsMgr);

                AddTextToNode(xmlDocument, "//configuration/applicationSettings/Confirmit.CATI.LoadTestUtility.Properties.Settings/setting[@name='Confirmit_CATI_LoadTestUtility_ConfirmitLogOn_LogOn']/value",
                    string.Format("http://{0}/confirmit/WebServices/18.0/LogOn.asmx", testConfiguration.LoadTestEnvironmentInfo.ConfirmitServer), nsMgr);

                AddTextToNode(xmlDocument, "//configuration/applicationSettings/Confirmit.CATI.LoadTestUtility.Properties.Settings/setting[@name='Confirmit_CATI_LoadTestUtility_ConfirmitSurveyDeployer_SurveyDeployer']/value",
                    string.Format("http://{0}/confirmit/WebServices/18.0/SurveyDeployer.asmx", testConfiguration.LoadTestEnvironmentInfo.ConfirmitServer), nsMgr);

                SetAttribute(xmlDocument, "//configuration/system.diagnostics/trace/listeners/add[@name='TextWriterTraceListener']", "LoggingPath",
                    ltuLoggingPath, nsMgr);

                xmlDocument.PreserveWhitespace = false;
                xmlDocument.Save(configPath);
            }
            finally
            {
                _logger.WriteLog("End ConfigureLtuConfig");
            }
        }

        private string GetInterviewerApiBaseUrlScheme(string backendMachineName)
        {
            if (backendMachineName.ToLowerInvariant() == "localhost" || backendMachineName.ToLowerInvariant() == Environment.MachineName.ToLowerInvariant())
            {
                return "http";
            }

            return "https";
        }
    }
}