﻿using System.Collections.Generic;
using System.Data;
using System.IO;
using ManagementUtility.Controller;
using ManagementUtility.Interfaces;
using ManagementUtility.LtuTools;

namespace ManagementUtility.Tools
{
    public class SqlServerBackupTools : ISqlServerBackupTools
    {
        private readonly ILogger _logger;
        private readonly TestConfiguration _testConfiguration;
        private readonly IDatabaseEngines _databaseEngines;
        private readonly ITestStateObserver _testStateObserver;
        
        public SqlServerBackupTools(
            ILogger logger, TestConfiguration testConfiguration, IDatabaseEngines databaseEngines, ITestStateObserver testStateObserver)
        {
            _logger = logger;
            _testConfiguration = testConfiguration;
            _databaseEngines = databaseEngines;
            _testStateObserver = testStateObserver;
        }

        public void RestoreDatabase(string serverPath, string dbName)
        {
            // GO command must be the only one on a row. Do not add spaces before or after GO
            var query = string.Format(@"USE master

ALTER DATABASE {0} SET SINGLE_USER WITH ROLLBACK IMMEDIATE

RESTORE DATABASE {0}
	FROM DISK = '{1}' WITH REPLACE, NEW_BROKER;

ALTER DATABASE {0} SET MULTI_USER

ALTER DATABASE {0} SET ENABLE_BROKER", dbName, serverPath);

            _databaseEngines.Backend.ExecuteBatch(query);
        }

        private void RestoreSurveyDatabase(string serverPath, string surveyProjectId)
        {
            var query = string.Format(@"USE master;
                                        
                                        IF DB_ID('survey_{0}') IS NOT NULL
                                            ALTER DATABASE survey_{0} SET SINGLE_USER WITH ROLLBACK IMMEDIATE;

                                        RESTORE DATABASE survey_{0}
	                                        FROM DISK = '{1}' WITH REPLACE;

                                        ALTER DATABASE survey_{0} SET MULTI_USER", surveyProjectId, serverPath);

            _databaseEngines.Survey.ExecuteNonQuery(query, CommandType.Text);
        }

        public void RestoreSurveyDatabases(List<string> surveyProjectIds)
        {
            foreach (string surveyProjectId in surveyProjectIds)
            {
                string surveyDbpath = Path.Combine(_testConfiguration.BackupFolderPathOnSqlServer, NameMaker.SurveyBackupName(_testConfiguration, surveyProjectId));

                _testStateObserver.ShowAction(string.Format("Restore database '{0}' from '{1}'", surveyProjectId, surveyDbpath));
                
                RestoreSurveyDatabase(surveyDbpath, surveyProjectId);
            }
        }

        public void CreateCatiAndSurveyBackups()
        {
            _databaseEngines.Survey.ExecuteNonQuery($@"
                declare @companyId int = {_testConfiguration.CompanyId}
                declare @BackUpPathFolder NVARCHAR(MAX) = '{_testConfiguration.BackupFolderPathOnSqlServer}'

                IF OBJECT_ID ( 'tempdb..#survey' ) IS NOT NULL
                 DROP TABLE #survey
                IF OBJECT_ID ( 'tempdb..#databases' ) IS NOT NULL
                 DROP TABLE #databases
 
                CREATE TABLE #survey
                (
                 ProjectId NVARCHAR(100)
                )

                declare @query nvarchar(max) = 'insert into #survey select SUBSTRING( name , 1, 10000 ) from {TestEnvironmentEngine.LtuLinkedServerName}.ConfirmitCATIV15_' + CAST( @CompanyID AS NVARCHAR(MAX)) + '.dbo.BvSurvey'
                exec( @query )

                select name, projectId into #databases from sys.databases d inner join #survey s
                ON d.name = 'survey_' + s.ProjectId

                DECLARE @dbName NVARCHAR(1000)
                DECLARE @projId NVARCHAR(1000)
                SELECT TOP(1) @dbName = name, @projId = projectId from #databases

                DECLARE @SurveyList NVARCHAR(MAX) = ''
                WHILE @dbName IS NOT NULL
                BEGIN
 
                 DELETE FROM #databases WHERE @dbName = name
 
                 DECLARE @Path NVARCHAR(MAX) = @BackUpPathFolder + '\{NameMaker.GetBackupPrefixFromLtuConfigPath(_testConfiguration)}_' + @projId + '.bak'
 
                 BACKUP DATABASE @dbName TO DISK = @Path
 
                 SET @SurveyList = @SurveyList + ';' + @projId
 
                 PRINT @dbName
 
                 SET @dbName = NULL
                 SELECT TOP(1) @dbName = name, @projId = projectId from #databases
                END

                SELECT @SurveyList", CommandType.Text);

            _databaseEngines.DefaultDatabase.ExecuteNonQuery(string.Format(@"BACKUP DATABASE ConfirmitCATIV15_{0} TO DISK = '{1}' WITH INIT", 
                _testConfiguration.CompanyId,
                Path.Combine(_testConfiguration.BackupFolderPathOnSqlServer, NameMaker.CatiBackupName(_testConfiguration))), CommandType.Text);
        }
    }
}