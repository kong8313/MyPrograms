﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using ManagementUtility.Interfaces;

namespace ManagementUtility.Tools
{
    public class LtuEngine : ILtuEngine
    {
        private readonly ILogger _logger;
        private readonly IPsExecExecutor _psExecExecutor;
        private readonly IRemoteProcessKiller _remoteProcessKiller;

        private Process[] _processes;
        private Stopwatch testTimer = new Stopwatch();

        public LtuEngine(ILogger logger, IPsExecExecutor psExecExecutor, IRemoteProcessKiller remoteProcessKiller)
        {
            _logger = logger;
            _psExecExecutor = psExecExecutor;
            _remoteProcessKiller = remoteProcessKiller;
        }

        public void RunLTUOnAllServers(TestConfiguration testConfiguration, string executionMode, string ltuLocalFolder)
        {
            _processes = executionMode == "Preparation" ? new Process[1] : new Process[testConfiguration.LoadTestEnvironmentInfo.LTUServers.MachineNames.Length];
            testTimer = Stopwatch.StartNew();
            int i = 0;
            string role = "Master";
            foreach (string machineName in testConfiguration.GetServerNames(ProductType.LTU))
            {
                string ltuConfigFileName = Path.GetFileName(testConfiguration.LtuConfigPath);

                string arguments = string.Format(
                    "/i {0} \\\\{1} \"{2}\" \"{3}\" {4} {5}",
                    TestConfiguration.PsExecCredentials,
                    machineName,
                    $@"c:\{TestConfiguration.RootLtuFolderName}\{ltuLocalFolder}.exe",
                    $@"c:\{TestConfiguration.RootLtuFolderName}\Configs\{ltuConfigFileName}",
                    executionMode,
                    role);

                role = "Slave";
                _processes[i++] = _psExecExecutor.InvokeProcess(arguments);

                if (executionMode == "Preparation")
                {
                    return;
                }
                
                Thread.Sleep(TimeSpan.FromSeconds(30));
            }
        }

        public void StopLTUOnAllServers(TestConfiguration testConfiguration, string ltuLocalFolder)
        {            
            if (testTimer.IsRunning)
                testTimer.Stop();

            foreach (string machineName in testConfiguration.GetServerNames(ProductType.LTU))
            {
                _remoteProcessKiller.KillProcess(machineName, ltuLocalFolder + ".exe");
            }

            Thread.Sleep(3000);
            _logger.WriteLog("All LTU processes was stopped successfully");
        }

        public TimeSpan GetExecutionTime()
        {
            return testTimer.Elapsed;
        }

        public bool IsAllProcessesStoped()
        {
            if (_processes == null)
            {
                return true;
            }

            return _processes.All(process => process == null || process.HasExited);
        }

        public bool IsFirstProcessStoped()
        {
            if (_processes == null)
            {
                return true;
            }

            return _processes[0] == null || _processes[0].HasExited;
        }
    }
}
