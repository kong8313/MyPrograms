﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Core.DAL.Generated.Entity.Adapter;
using Confirmit.CATI.Core.Repositories;
using Confirmit.CATI.Core.SupervisorService;
using Confirmit.CATI.Core.Telephony;
using ConfirmitDialerInterface;
using ManagementUtility.Controller;
using ManagementUtility.Interfaces;
using ILogger = ManagementUtility.Interfaces.ILogger;

namespace ManagementUtility.Tools
{
    public class TelephonyConfigurator : ITelephonyConfigurator
    {
        private readonly ILogger _logger;
        private readonly IServiceEngine _serviceEngine;
        private readonly IRemoteProcessKiller _remoteProcessKiller;
        private readonly ITestStateObserver _testStateObserver;
        private readonly IPsExecExecutor _psExecExecutor;

        public bool IsSimulatorStarted { get; private set; }

        public TelephonyConfigurator(
            ILogger logger, 
            IServiceEngine serviceEngine, 
            IPsExecExecutor psExecExecutor, 
            IRemoteProcessKiller remoteProcessKiller, 
            ITestStateObserver testStateObserver)
        {
            _logger = logger;
            _serviceEngine = serviceEngine;
            _remoteProcessKiller = remoteProcessKiller;
            _testStateObserver = testStateObserver;
            _psExecExecutor = psExecExecutor;

            IsSimulatorStarted = false;
        }

        public void InitializeBackendTelephone(TestConfiguration testConfiguration)
        {
            _logger.WriteLog("Configuring dialer...");

            if (!testConfiguration.IsDialerUse)
            {
                _logger.WriteLog("Start without dialer configuration");
                return;
            }

            string args = $"/cs \"{testConfiguration.ConnectionStringToBE}\" /ccs \"{testConfiguration.ConnectionStringToCF}\" \"{testConfiguration.LoadTestEnvironmentInfo.Dialer.DialerConfigurationConfigName}\" \"{testConfiguration.CompanyId}\" /add 1 /yes";
            _logger.WriteLog($"Path: {testConfiguration.DialerConfigurationUtility}\r\nArguments: {args}");

            using (var processCfg = Process.Start(
                new ProcessStartInfo(testConfiguration.DialerConfigurationUtility, args)
                {
                    UseShellExecute = false,
                    RedirectStandardError = true,
                    RedirectStandardOutput = true
                }))
            {
                if (processCfg == null)
                {
                    throw new Exception("Execution of dialer configuration utility was failed. 'processCfg' is null");
                }

                processCfg.WaitForExit();
                _logger.WriteLog("StandardOutput:\r\n" + processCfg.StandardOutput.ReadToEnd());
                _logger.WriteLog("StandardError:\r\n" + processCfg.StandardError.ReadToEnd());
                if (processCfg.ExitCode != 0)
                {
                    throw new Exception(string.Format("Execution of dialer configuration utility was failed. Exit code {0}", processCfg.ExitCode));
                }
            }

            // We have to restart backend service for now in order to update dialer caches. We may not need it later.
            _logger.WriteLog("Restarting service ...");

            _serviceEngine.StopCatiServices(testConfiguration);

            var dialer = new DialersRepository().GetById(1);
            dialer.DialerOperationalStateNotification = true;
            BvDialersAdapter.Update(dialer);

            _serviceEngine.StartCatiServices(testConfiguration);
        }
        
        public void PutDialerSettingsToResponseSimCfgTxt(TestConfiguration testConfiguration)
        {
            if (!testConfiguration.IsDialerUse || !testConfiguration.DialerSimulatorAutomaticMode)
            {
                _logger.WriteLog("Don't configure ScenarioXmlFile");
                return;
            }

            var outcomesString = new StringBuilder();
            outcomesString.AppendLine("\r\n[RESPONSES]\r\n; post connect responses for CAS and ISDN\r\n; this section was generated automatically by Management Utility for load testing");

            int connectedDistributionWeight = 0;
            int busyDistributionWeight = 0;
            int connectedProcessingTime = 0;
            int busyProcessingTime = 0;

            foreach (var outcomeList in testConfiguration.LtuTestConfigurationXmlModel.DialerScenarios[0].OutcomeLists)
            {
                switch ((CallOutcome)Enum.Parse(typeof(CallOutcome), outcomeList.CallOutcome))
                {
                    case CallOutcome.Connected:
                        connectedDistributionWeight = Convert.ToInt32(outcomeList.DistributionWeight);
                        connectedProcessingTime = Convert.ToInt32(outcomeList.ProcessingTime.Split('-').Last()) * 1000;
                        break;
                    case CallOutcome.Busy:
                        busyDistributionWeight = Convert.ToInt32(outcomeList.DistributionWeight);
                        busyProcessingTime = Convert.ToInt32(outcomeList.ProcessingTime.Split('-').Last()) * 1000;
                        break;
                }
            }

            int distributionWeight = connectedDistributionWeight + busyDistributionWeight;
            var weights = new int[distributionWeight][];
            var random = new Random();
            for (int i = 0; i < connectedDistributionWeight; i++)
            {
                weights[i] = new[]
                {
                    random.Next(100000),
                    1
                };
            }
            for (int i = connectedDistributionWeight; i < distributionWeight; i++)
            {
                weights[i] = new[]
                {
                    random.Next(100000),
                    0
                };
            }

            Array.Sort(weights, (value1, value2) => value1[0].CompareTo(value2[0]));

            for (int i = 0; i < distributionWeight; i++)
            {
                if (weights[i][1] == 1)
                {
                    outcomesString.AppendFormat("2101\t\t{0}\t\t0\t\t1\t\t{1}\t\t0\r\n", connectedProcessingTime, GetRandomAudioFileName(random));
                }
                else
                {
                    outcomesString.AppendFormat("2101\t\t{0}\t\t0\t\t0\t\tGC_USER_BUSY\t\t0\r\n", busyProcessingTime);
                }
            }

            string responseSimCfgContent = File.ReadAllText(testConfiguration.ResponseSimCfgRemotePath);
            int startIndex = responseSimCfgContent.IndexOf("[RESPONSES]", StringComparison.InvariantCultureIgnoreCase);
            int endIndex = responseSimCfgContent.IndexOf("[CALIBRATEDRESPONSES]", StringComparison.InvariantCultureIgnoreCase);

            responseSimCfgContent = responseSimCfgContent.Substring(0, startIndex) + outcomesString.AppendLine() + responseSimCfgContent.Substring(endIndex);

            File.WriteAllText(testConfiguration.ResponseSimCfgRemotePath, responseSimCfgContent);

            _logger.WriteLog("responseSimCfgContent:\r\n" + responseSimCfgContent);
        }

        private string GetRandomAudioFileName(Random random)
        {
            if (random.Next(100) < 50)
            {
                return "ThankYou.vox";
            }

            return "Hello.vox ";
        }

        public void PutDialerSettingsToSimulatorScenarioXml(TestConfiguration testConfiguration)
        {
            PutDialerSettingsToScenarioXmlFile(testConfiguration, testConfiguration.SimulatorScenarioRemotePath);
        }

        public void PutDialerSettingsToBvTciScenarioXml(TestConfiguration testConfiguration)
        {
            PutDialerSettingsToScenarioXmlFile(testConfiguration, testConfiguration.BvTciScenarioRemotePath);
        }

        private void PutDialerSettingsToScenarioXmlFile(TestConfiguration testConfiguration, string xmlFilePath)
        {
            if (!testConfiguration.IsDialerUse || !testConfiguration.DialerSimulatorAutomaticMode)
            {
                _logger.WriteLog("Don't configure ScenarioXmlFile");
                return;
            }

            SimulatorScenario scenario = SimulatorScenario.Deserialize(xmlFilePath);

            scenario.CallsCountPerInterviewer = Convert.ToInt32(testConfiguration.LtuTestConfigurationXmlModel.DialerScenarios[0].CallsCountPerInterviewer);

            if (scenario.CallOutcomeDistributionScenarioObject.OutcomeList == null)
            {
                scenario.CallOutcomeDistributionScenarioObject.OutcomeList = new List<SimulatorScenario.CallOutcomeDistributionScenario.CallOutcomeDistributionData>();
            }
            else
            {
                scenario.CallOutcomeDistributionScenarioObject.OutcomeList.Clear();
            }

            foreach (var outcomeList in testConfiguration.LtuTestConfigurationXmlModel.DialerScenarios[0].OutcomeLists)
            {
                scenario.CallOutcomeDistributionScenarioObject.OutcomeList.Add(new SimulatorScenario.CallOutcomeDistributionScenario.CallOutcomeDistributionData
                {
                    CallOutcome = (CallOutcome)Enum.Parse(typeof(CallOutcome), outcomeList.CallOutcome),
                    DistributionWeight = Convert.ToInt32(outcomeList.DistributionWeight),
                    ProcessingTime = outcomeList.ProcessingTime
                });
            }
                
            scenario.Serialize(xmlFilePath);
        }

        public void StartDialerSimulatorIfNeeded(TestConfiguration testConfiguration)
        {
            if (!testConfiguration.IsDialerUse || !testConfiguration.DialerSimulatorAutomaticMode)
            {
                _logger.WriteLog("Don't run  simulator");
                return;
            }

            if (IsSimulatorStarted)
            {
                _logger.WriteLog("Simulator is already started");
                return;
            }

            switch (testConfiguration.LoadTestEnvironmentInfo.Dialer.Type)
            {
                case DialerType.TciReal:
                    _logger.WriteLog("Run IsdnNetwork simulator");
                    RunIsdnNetworkSimulator(testConfiguration);
                    break;
                case DialerType.TciSimulator:
                    _logger.WriteLog("Run BvTciDialer simulator");
                    RunBvTciDialerSimulator(testConfiguration);
                    break;
            }

            ConnectAndActivateDialer();

            IsSimulatorStarted = true;
        }

        private void ConnectAndActivateDialer()
        {
            try
            {  
                _logger.WriteLog("Connect and activate dialer");
                
                IDialerCollection dialerCollection = ServiceLocator.Resolve<DialerCollection>();
                dialerCollection.InitializeCollection();
                
                IDialerAvailabilityManager dialerAvailabilityManager = ServiceLocator.Resolve<DialerAvailabilityManager>();
                IDialerCampaignInitializer dialerCampaignInitializer = ServiceLocator.Resolve<DialerCampaignInitializer>();

                var result = dialerAvailabilityManager.EnableDialer(1);
                if (!result)
                {
                    throw new Exception("EnableDialer method returned false");
                }

                dialerCampaignInitializer.InitializeAllCampaigns();

                result = dialerAvailabilityManager.ActivateDialer(1);
                if (!result)
                {
                    throw new Exception("ActivateDialer method returned false");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Cannot connect and enable dialer with id=1. Error: {ex.Message}", ex);
            }
        }

        private void RunBvTciDialerSimulator(TestConfiguration testConfiguration)
        {
            _testStateObserver.ShowAction("Start BvTci Dialer Simulator");
            string arguments = string.Format(
                    "/d {0} \\\\{1} \"{2}\" \"{3}\"",
                    TestConfiguration.PsExecCredentials,
                    testConfiguration.LoadTestEnvironmentInfo.Dialer.MachineName,
                    Path.Combine(Path.GetDirectoryName(testConfiguration.BvTciScenarioPath) ?? string.Empty, "BvTciDialerSimulator.exe"),
                    testConfiguration.BvTciScenarioRemotePath);

            _psExecExecutor.InvokeProcess(arguments);
        }

        private void RunIsdnNetworkSimulator(TestConfiguration testConfiguration)
        {
            _testStateObserver.ShowAction("Start IsdnNetwork Simulator");
 	         string arguments = string.Format(
                    "/d {0} \\\\{1} \"{2}\" ",
                    TestConfiguration.PsExecCredentials,
                    testConfiguration.LoadTestEnvironmentInfo.Dialer.MachineName,
                    Path.Combine(Path.GetDirectoryName(testConfiguration.ResponseSimCfgPath) ?? string.Empty, "ResponseSim.exe"));

            _psExecExecutor.InvokeProcess(arguments);
        }

        public void StopDialerSimulator(TestConfiguration testConfiguration)
        {
            if (!testConfiguration.IsDialerUse || !testConfiguration.DialerSimulatorAutomaticMode)
            {                
                return;
            }

            if (!IsSimulatorStarted)
            {
                return;
            }

            string processToKill = string.Empty;
            switch (testConfiguration.LoadTestEnvironmentInfo.Dialer.Type)
            {
                case DialerType.TciReal:
                    processToKill = "ResponseSim.exe";
                    break;
                case DialerType.TciSimulator:
                    processToKill = "BvTciDialerSimulator.exe";
                    break;
            }

            if (!string.IsNullOrEmpty(processToKill))
            {
                _logger.WriteLog("Stopping simulator process " + processToKill);
                _remoteProcessKiller.KillProcess(testConfiguration.LoadTestEnvironmentInfo.Dialer.MachineName, processToKill);
            }

            IsSimulatorStarted = false;
        }


        
    }
}