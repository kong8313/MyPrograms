﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using ManagementUtility.Interfaces;
using PlaLibrary;

namespace ManagementUtility.Tools
{
    public class PerformanceCounterEngine : IPerformanceCounterEngine
    {
        private const string DataCollectorSetName = @"LTU Automatic ";
        private const string RootFolderName = @"__LTU Automatic Results__";

        private readonly string _startupPath;

        private readonly ILogger _logger;
        private readonly ICopier _copier;
        private readonly IPsExecExecutor _psExecExecutor;

        public PerformanceCounterEngine(ILogger logger, ICopier copier, IPsExecExecutor psExecExecutor, string startupPath)
        {
            _logger = logger;
            _copier = copier;
            _psExecExecutor = psExecExecutor;
            _startupPath = startupPath;
        }

        public void StartPerformanceCounterGathering(TestConfiguration testConfiguration)
        {
            foreach (var dataCollectorSetInfo in testConfiguration.DataCollectorSetsInfo.DataCollectorSetInfoArray)
            {
                IEnumerable<string> serverNames = testConfiguration.GetServerNames(dataCollectorSetInfo.Type);
                string xmlTemplateFileName = Path.GetFileNameWithoutExtension(dataCollectorSetInfo.XmlTemplate);

                foreach (var serverName in serverNames)
                {
                    string serverNameOrNull = GetRemoteServerNameOrNull(serverName); 
                    
                    _logger.WriteLog("Run performace counters on {0}", serverName);
                    Stop(serverNameOrNull, xmlTemplateFileName);
                    Create(serverNameOrNull, dataCollectorSetInfo.XmlTemplate);
                    Start(serverNameOrNull, xmlTemplateFileName);
                }
            }
        }

        public void StopPerformanceCounterGathering(TestConfiguration testConfiguration)
        {
            DataCollectorSets dataCollectorSets = testConfiguration.DataCollectorSetsInfo;

            string performanceResultFolderPath = Path.Combine(_startupPath, "PerformaceResults_" + DateTime.Now.ToString("yyyy.MM.dd_HH.mm.ss"));
            foreach (var dataCollectorSetInfo in dataCollectorSets.DataCollectorSetInfoArray)
            {
                IEnumerable<string> serverNames = testConfiguration.GetServerNames(dataCollectorSetInfo.Type);
                string xmlTemplateFileName = Path.GetFileNameWithoutExtension(dataCollectorSetInfo.XmlTemplate);

                foreach (var serverName in serverNames)
                {
                    string serverNameOrNull = GetRemoteServerNameOrNull(serverName);

                    string destinationFolderPath = Path.Combine(performanceResultFolderPath, serverName + "_" + xmlTemplateFileName);
                    _logger.WriteLog("Collect performace counters result from {0}", serverName);
                    Stop(serverNameOrNull, xmlTemplateFileName);
                    MoveResults(serverNameOrNull, destinationFolderPath, xmlTemplateFileName);
                    Remove(serverNameOrNull, xmlTemplateFileName);
                }
            }

            if (!string.IsNullOrEmpty(testConfiguration.PerfResultSharedPath))
            {
                PackResults(testConfiguration.PerfResultSharedPath, performanceResultFolderPath);
            }
        }

        private void PackResults(string perfResultSharedPath, string performanceResultFolderPath)
        {
            string sevenZipExePath = Path.Combine(_startupPath, "7z", "7z.exe");
            string destinationPath = GetDestinationPath(perfResultSharedPath);
            performanceResultFolderPath = Path.Combine(performanceResultFolderPath, "*");

            string args = string.Format("\"{0}\" a -tzip \"{1}\" \"{2}\"", sevenZipExePath, destinationPath, performanceResultFolderPath);
            Process process = _psExecExecutor.InvokeProcess(args);
            process.WaitForExit();            
        }

        private string GetDestinationPath(string perfResultSharedPath)
        {
            string destinationPath;
            string underline = string.Empty;
            do
            {
                destinationPath = Path.Combine(perfResultSharedPath, "PerformaceResults_" + DateTime.Now.ToString("yyyy.MM.dd_HH.mm") + underline + ".zip");
                underline += "_";
            } while (File.Exists(destinationPath));

            return destinationPath;
        }   

        private void Create(string serverName, string xmlTemplatepath)
        {
            string xmlTemplateFileName = Path.GetFileNameWithoutExtension(xmlTemplatepath);
            string xmlFormat = File.ReadAllText(xmlTemplatepath);

            IDataCollectorSet collectorSet = new DataCollectorSet();
            collectorSet.SetXml(xmlFormat);
            string rootFolderPath = GetRootFolderPath(serverName, xmlTemplateFileName);
            collectorSet.RootPath = @"c:\" + GetRootFolderName(xmlTemplateFileName);

            if (Directory.Exists(rootFolderPath))
            {
                Directory.Delete(rootFolderPath, true);
            }

            Directory.CreateDirectory(rootFolderPath);
            collectorSet.Commit(GetDataCollectorSetName(xmlTemplateFileName), serverName, CommitMode.plaCreateOrModify);
        }

        private string GetRootFolderName(string xmlTemplateFileName)
        {
            return RootFolderName + xmlTemplateFileName;
        }

        private void Start(string serverName, string xmlTemplateFileName)
        {
            IDataCollectorSet collectorSet = new DataCollectorSet();
            collectorSet.Query(GetDataCollectorSetName(xmlTemplateFileName), serverName);
            collectorSet.start(true);
        }

        private string GetDataCollectorSetName(string xmlTemplateFileName)
        {
            return DataCollectorSetName + xmlTemplateFileName;
        }

        private string GetRemoteServerNameOrNull(string serverName)
        {
            return serverName.ToLowerInvariant() == "localhost" || 
                serverName.ToLowerInvariant() == Environment.MachineName.ToLowerInvariant() ||
                serverName.ToLowerInvariant().StartsWith(Environment.MachineName.ToLowerInvariant() + ".") ? null : serverName;
        }

        private void Stop(string serverName, string xmlTemplateFileName)
        {
            try
            {
                IDataCollectorSet collectorSet = new DataCollectorSet();
                collectorSet.Query(GetDataCollectorSetName(xmlTemplateFileName), serverName);
                collectorSet.Stop(true);
            }
            catch (Exception ex)
            {
                _logger.WriteLog(TraceEventType.Warning, "An error occured during stopping of a data collector set '{0}' on a server '{1}'\r\n{2}", GetDataCollectorSetName(xmlTemplateFileName), serverName, ex);
            }
        }

        private void Remove(string serverName, string xmlTemplateFileName)
        {
            IDataCollectorSet collectorSet = new DataCollectorSet();
            collectorSet.Query(GetDataCollectorSetName(xmlTemplateFileName), serverName);
            collectorSet.Delete();
        }

        private string GetRootFolderPath(string serverName, string xmlTemplateFileName)
        {
            string path = string.IsNullOrEmpty(serverName) || serverName.ToLowerInvariant() == "localhost"
                ? @"c:\" + GetRootFolderName(xmlTemplateFileName)
                : string.Format(@"\\{0}\c$\{1}", serverName, GetRootFolderName(xmlTemplateFileName));
      
            return path;
        }

        private void MoveResults(string server, string destinationFolderPath, string xmlTemplateFileName)
        {
            string sourceFolderPath = GetRootFolderPath(server, xmlTemplateFileName);

            _copier.CopyDirectory(sourceFolderPath, destinationFolderPath);

            Directory.Delete(sourceFolderPath, true);
        }

        
    }
}
