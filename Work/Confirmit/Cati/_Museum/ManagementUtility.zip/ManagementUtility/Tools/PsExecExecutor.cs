﻿using System.Diagnostics;
using ManagementUtility.Interfaces;

namespace ManagementUtility.Tools
{
    public class PsExecExecutor : IPsExecExecutor
    {
        private readonly object _lock = new object();

        private readonly ILogger _logger;
        private readonly string _psExecPath;

        public PsExecExecutor(ILogger logger, string psExecPath)
        {
            _logger = logger;
            _psExecPath = psExecPath;            
        }

        /// <summary>
        /// Invoke script with mstest
        /// </summary>
        /// <param name="args">Program arguments</param>
        /// <returns></returns>
        public Process InvokeProcess(string args)
        {
            _logger.WriteLog("Path: " + _psExecPath + "\r\nArguments: " + args);

            var scriptProcess = new Process();

            var pinfo = new ProcessStartInfo(_psExecPath, args)
            {
                CreateNoWindow = false,
                UseShellExecute = false,
                RedirectStandardError = true,
                RedirectStandardOutput = true
            };

            scriptProcess.StartInfo = pinfo;

            scriptProcess.OutputDataReceived += ScriptProcessOutputDataReceived;
            scriptProcess.ErrorDataReceived += ScriptProcessErrorDataReceived;

            scriptProcess.Start();

            scriptProcess.BeginOutputReadLine();
            scriptProcess.BeginErrorReadLine();

            return scriptProcess;
        }

        private void ScriptProcessOutputDataReceived(object sender, DataReceivedEventArgs args)
        {
            lock (_lock)
            {
                string argsData = args.Data;
                if (string.IsNullOrEmpty(argsData))
                {
                    return;
                }

                _logger.WriteLog(argsData);
            }
        }


        private void ScriptProcessErrorDataReceived(object sender, DataReceivedEventArgs args)
        {
            lock (_lock)
            {
                string argsData = args.Data;
                if (string.IsNullOrEmpty(argsData) || argsData.Trim(new[] { '\r', '\n', ' ' }).Length == 0)
                {
                    return;
                }

                _logger.WriteLog(TraceEventType.Error, argsData);
            }
        }        
    }
}