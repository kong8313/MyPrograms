﻿using System;
using System.ServiceModel;
using Confirmit.CATI.Common.SideBySide;
using Confirmit.CATI.Core.ManagementService;
using Confirmit.CATI.Common.ServiceLocation;
using ManagementUtility.Interfaces;

namespace ManagementUtility.Tools
{
    public class ManagementServices : IManagementServices
    {
        private readonly TestConfiguration _testConfiguration;

        public ManagementServices(TestConfiguration testConfiguration)
        {
            _testConfiguration = testConfiguration;
        }

        public IInstanceManagementService MultimodeInstance
        {
            get
            {
                var binding = new BasicHttpBinding
                {
                    CloseTimeout = TimeSpan.FromMinutes(30),
                    ReceiveTimeout = TimeSpan.FromMinutes(30),
                    SendTimeout = TimeSpan.FromMinutes(30),
                    OpenTimeout = TimeSpan.FromMinutes(30)
                };

                var endpointAddress = new EndpointAddress(ServiceLocator.Resolve<ISideBySideManager>().AddSideBySideNameToBackendWCFServiceUrl(_testConfiguration.MultimodeWebServiceURL));

                var factory = new ChannelFactory<IInstanceManagementService>(binding, endpointAddress);
                return factory.CreateChannel();
            }
        }
    }
}
