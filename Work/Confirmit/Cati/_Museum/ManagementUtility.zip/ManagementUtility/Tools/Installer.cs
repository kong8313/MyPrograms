﻿using System;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using ManagementUtility.Interfaces;

namespace ManagementUtility.Tools
{
    public class Installer : IInstaller
    {
        private const string RootFolderPath = @"c:\__KITS__";
        private const string LtuSimulatorKitFileName = "Confirmit CATI LTU Simulator (G) Dialer Web Service.exe";
        private const string TciDialerWebServiceKitFileName = "Confirmit CATI TCI Dialer Web Service.exe";

        private const string LtuSimulatorKitProductName = "Confirmit CATI LTU Simulator (G) Dialer Web Service";
        private const string TciDialerWebServiceKitProductName = "Confirmit CATI TCI Dialer Web Service";

        private readonly string _localKitFolderPath;

        private readonly ILogger _logger;
        private readonly IPsExecExecutor _psExecExecutor;
        private readonly ShowActionDelegate _showActionDelegate;

        public Installer(ILogger logger, IPsExecExecutor psExecExecutor, ShowActionDelegate showActionDelegate)
        {
            _logger = logger;
            _psExecExecutor = psExecExecutor;
            _showActionDelegate = showActionDelegate;

            _localKitFolderPath = Path.GetFullPath("Installations");
        }

        public string GetLtuSimulatorKitFilePath
        {
            get
            {
                return Path.Combine(_localKitFolderPath, LtuSimulatorKitFileName);
            }
        }

        public string GetTciDialerWebServiceKitFilePath
        {
            get
            {
                return Path.Combine(_localKitFolderPath, TciDialerWebServiceKitFileName);
            }
        }

        public string GetLtuSimulatorProductName
        {
            get
            {
                return LtuSimulatorKitProductName;
            }
        }

        public string GetTciDialerWebServiceProductName
        {
            get
            {
                return TciDialerWebServiceKitProductName;
            }
        }

        public string GetRemoteRootFolderPath(string serverName)
        {
            return string.Format(@"\\{0}\{1}", serverName, RootFolderPath.Replace(":", "$"));
        }

        public void Install(TestConfiguration testConfiguration)
        {
            var installationArguments = "/update /ignoreVersion";
            if (testConfiguration.LoadTestEnvironmentInfo.Dialer.Type == DialerType.GenericSimulator)
            {
                _showActionDelegate(string.Format("Updating Confirmit CATI LTU Simulator Generic Web Service on '{0}' server", testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName));
                StartUpdate(testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName, LtuSimulatorKitFileName, installationArguments);
            }
            else if (testConfiguration.LoadTestEnvironmentInfo.Dialer.Type == DialerType.TciReal || testConfiguration.LoadTestEnvironmentInfo.Dialer.Type == DialerType.TciSimulator)
            {
                _showActionDelegate(string.Format("Updating Confirmit CATI TCI Dialer Web Service on '{0}' server", testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName));
                StartUpdate(testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName, TciDialerWebServiceKitFileName, installationArguments);
            }
        }

        private void StartUpdate(string serverName, string kitFileName, string installationArguments)
        {
            string sourceFilePath = Path.Combine(_localKitFolderPath, kitFileName);
            string remoteFilePath = string.Format(@"\\{0}\{1}\{2}", serverName, RootFolderPath.Replace(":", "$"), kitFileName);
            string remoteFolderPath = Path.GetDirectoryName(remoteFilePath) ?? string.Empty;
            if (!Directory.Exists(remoteFolderPath))
            {
                Directory.CreateDirectory(remoteFolderPath);
            }

            File.Copy(sourceFilePath, remoteFilePath, true);

            string arguments = string.Format(
                "/i {0} \\\\{1} \"{2}\" /q {3}",
                TestConfiguration.PsExecCredentials,
                serverName,
                Path.Combine(RootFolderPath, kitFileName),
                installationArguments);

            _logger.WriteLog("arguments={0}", arguments);
            Process process = _psExecExecutor.InvokeProcess(arguments);

            process.WaitForExit(300000);
            if (process.ExitCode != 0)
            {
                throw new Exception(string.Format("Update failed for '{0}' product on '{1}' server. Exit code: {2}", kitFileName, serverName, process.ExitCode));
            }
        }
    }
}