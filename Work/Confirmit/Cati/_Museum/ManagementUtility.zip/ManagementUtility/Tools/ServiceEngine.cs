﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.ServiceProcess;
using System.Threading;
using Confirmit.CATI.Core.DAL.Framework;
using Confirmit.CATI.Core.Misc;
using ManagementUtility.Interfaces;
using ManagementUtility.LtuTools;

namespace ManagementUtility.Tools
{
    public class ServiceEngine : IServiceEngine
    {
        private readonly ILogger _logger;
        private readonly ShowActionDelegate _showActionDelegate;

        public ServiceEngine(ILogger logger, ShowActionDelegate showActionDelegate)
        {
            _logger = logger;
            _showActionDelegate = showActionDelegate;
        }

        public void StopCatiServices(TestConfiguration testConfiguration)
        {
            foreach (string machineName in testConfiguration.GetServerNames(ProductType.Backend))
            {
                string defaultServiceName = MultimodeInstanceName.GetDefaultServiceName();
                _showActionDelegate(string.Format("Stop service '{0}' on server '{1}'", defaultServiceName, machineName));
                StopService(defaultServiceName, machineName);

                Thread.Sleep(500);

                string serviceName = NameMaker.ServiceName(testConfiguration.CompanyId);
                _showActionDelegate(string.Format("Stop service '{0}' on server '{1}'", serviceName, machineName));
                StopService(serviceName, machineName);
            }

            _showActionDelegate("Wait 5 sec");
            Thread.Sleep(5000);
        }

        public void StartCatiServices(TestConfiguration testConfiguration)
        {
            foreach (string machineName in testConfiguration.GetServerNames(ProductType.Backend))
            {
                string serviceName = NameMaker.ServiceName(testConfiguration.CompanyId);
                _showActionDelegate(string.Format("Start service '{0}' on server '{1}'", serviceName, machineName));
                StartService(serviceName, machineName);

                Thread.Sleep(500);

                string defaultServiceName = MultimodeInstanceName.GetDefaultServiceName();
                _showActionDelegate(string.Format("Start service '{0}' on server '{1}'", defaultServiceName, machineName));
                StartService(defaultServiceName, machineName);
            }

            _showActionDelegate("Wait 5 sec");
            Thread.Sleep(5000);
        }

        public bool IsCatiServicesStarted(TestConfiguration testConfiguration)
        {
            foreach (string machineName in testConfiguration.GetServerNames(ProductType.Backend))
            {
                string serviceName = NameMaker.ServiceName(testConfiguration.CompanyId);

                if (!IsServiceStarted(serviceName, machineName))
                {
                    return false;
                }

                string defaultServiceName = MultimodeInstanceName.GetDefaultServiceName();

                if (!IsServiceStarted(defaultServiceName, machineName))
                {
                    return false;
                }
            }

            return true;
        }

        public bool IsCatiServicesExists(TestConfiguration testConfiguration)
        {
            foreach (string machineName in testConfiguration.GetServerNames(ProductType.Backend))
            {
                string serviceName = NameMaker.ServiceName(testConfiguration.CompanyId);

                if (!IsServiceExist(serviceName, machineName))
                {
                    return false;
                }

                string defaultServiceName = MultimodeInstanceName.GetDefaultServiceName();

                if (!IsServiceExist(defaultServiceName, machineName))
                {
                    return false;
                }
            }

            return true;
        }

        public void RestartCatiAndConfirmitSqlServers(TestConfiguration testConfiguration)
        {
            var restartedSqlServerNames = new List<string>();
            foreach (Server server in testConfiguration.LoadTestEnvironmentInfo.SQLServers)
            {
                if (!restartedSqlServerNames.Contains(server.MachineName))
                {
                    string serviceName = string.Format("SQL Server ({0})", new DatabaseEngine(server.ConnectionString).ExecuteScalar<string>("select @@SERVICENAME", CommandType.Text));
                    StopService(serviceName, server.MachineName);
                    Thread.Sleep(5000);
                    StartService(serviceName, server.MachineName);

                    restartedSqlServerNames.Add(server.MachineName);
                }
            }

            _showActionDelegate("Wait 5 sec");
            Thread.Sleep(5000);

            _showActionDelegate("Wait until all databases are available");
            const string sqlQuery = @"WHILE EXISTS(select 1 from sys.databases WHERE state_desc <> 'ONLINE') BEGIN WAITFOR DELAY '00:00:00.5' END";
            foreach (var server in testConfiguration.LoadTestEnvironmentInfo.SQLServers)
            {
                var scsb = new SqlConnectionStringBuilder(server.ConnectionString)
                {
                    InitialCatalog = "master"
                };
                _logger.WriteLog("Wait on " + server.MachineName);
                new DatabaseEngine(scsb.ConnectionString).ExecuteNonQuery(sqlQuery, CommandType.Text);
            }
        }

        private void StopService(string serviceName, string machineName)
        {
            _logger.WriteLog(string.Format("Stop service '{0}' on server '{1}'", serviceName, machineName));
            if (ServiceController.GetServices(machineName).All(x => x.DisplayName != serviceName))
            {
                return;
            }

            using (var serviceController = new ServiceController(serviceName, machineName))
            {
                if (serviceController.Status == ServiceControllerStatus.Running)
                {
                    serviceController.Stop();
                    serviceController.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromMinutes(5));
                }
            }
        }

        private void StartService(string serviceName, string machineName)
        {
            _logger.WriteLog(string.Format("Start service '{0}' on server '{1}'", serviceName, machineName));
            if (ServiceController.GetServices(machineName).All(x => x.DisplayName != serviceName))
            {
                return;
            }

            using (var serviceController = new ServiceController(serviceName, machineName))
            {
                if (serviceController.Status == ServiceControllerStatus.Stopped)
                {
                    serviceController.Start();
                    serviceController.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromMinutes(5));
                }
            }
        }

        private bool IsServiceStarted(string serviceName, string machineName)
        {
            if (ServiceController.GetServices(machineName).All(x => x.DisplayName != serviceName))
            {
                return false;
            }

            using (var serviceController = new ServiceController(serviceName, machineName))
            {
                if (serviceController.Status != ServiceControllerStatus.Running)
                {
                    return false;
                }
            }

            return true;
        }

        private bool IsServiceExist(string serviceName, string machineName)
        {
            if (ServiceController.GetServices(machineName).All(x => x.DisplayName != serviceName))
            {
                return false;
            }

            return true;
        }
        
    }
}