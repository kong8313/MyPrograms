﻿using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using ManagementUtility.Interfaces;

namespace ManagementUtility.Tools
{    
    public class XmlConfigParser : IXmlConfigParser
    {
        private readonly ILogger _logger;

        public XmlConfigParser(ILogger logger)
        {
            _logger = logger;
        }

        public T GetXmlConfig<T>(string xmlConfigPath)
        {
            _logger.WriteLog("GetXmlConfig");
            var serializer = new XmlSerializer(typeof(T));
            using (var streamReader = new StreamReader(xmlConfigPath, Encoding.UTF8))
            using (var textReader = new XmlTextReader(streamReader))
            {
                return (T)serializer.Deserialize(textReader);
            }
        }

        public void LoadManagementUtilityConfig(string muConfigPath)
        {
            AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", muConfigPath);

            typeof(ConfigurationManager).GetField("s_initState", BindingFlags.NonPublic | BindingFlags.Static).SetValue(null, 0);

            typeof(ConfigurationManager).GetField("s_configSystem", BindingFlags.NonPublic | BindingFlags.Static).SetValue(null, null);

            typeof(ConfigurationManager).GetField("s_initError", BindingFlags.NonPublic | BindingFlags.Static).SetValue(null, null);
            
            typeof(ConfigurationManager).Assembly.GetTypes()
                .Where(x => x.FullName == "System.Configuration.ClientConfigPaths")
                .First()
                .GetField("s_current", BindingFlags.NonPublic | BindingFlags.Static)
                .SetValue(null, null);
        }
    }
}