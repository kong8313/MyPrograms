﻿using ManagementUtility.Controller;
using ManagementUtility.Interfaces;
using ManagementUtility.LtuTools;

namespace ManagementUtility.Tools
{
    public class Factory : IFactory
    {
        public DatabaseEngines CreateDatabaseEnginesObject(TestConfiguration testConfiguration)
        {
            return new DatabaseEngines(testConfiguration);
        }

        public SqlServerBackupTools CreateSqlServerBackupToolsObject(
            ILogger logger, TestConfiguration testConfiguration, IDatabaseEngines databaseEngines, ITestStateObserver testStateObserver)
        {
            return new SqlServerBackupTools(logger, testConfiguration, databaseEngines, testStateObserver);
        }

        public ManagementServices CreateManagementServices(TestConfiguration testConfiguration)
        {
            return new ManagementServices(testConfiguration);
        }

        public BackendServerNameGetter CreateBackendServerNameGetter(TestConfiguration testConfiguration)
        {
            return new BackendServerNameGetter(testConfiguration);
        }
    }
}