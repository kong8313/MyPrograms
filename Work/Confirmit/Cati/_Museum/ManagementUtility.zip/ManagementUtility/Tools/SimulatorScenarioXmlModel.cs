﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using ConfirmitDialerInterface;

namespace ManagementUtility.Tools
{
    public class SimulatorScenario
    {
        public enum CallOutcomeGenerationMethod
        {
            Sequence,
            Random
        };

        [Serializable]
        public class CallOutcomeDistributionScenario
        {
            public class CallOutcomeDistributionData
            {
                [XmlAttribute]
                public CallOutcome CallOutcome { get; set; }

                [XmlAttribute]
                public string ProcessingTime { get; set; }
                
                [XmlAttribute]
                public int DistributionWeight { get; set; }
            }

            [XmlElement]
            public List<CallOutcomeDistributionData> OutcomeList;

            [XmlElement]
            public CallOutcomeGenerationMethod GenerationMethod { get; set; }
        }

        [XmlElement("CallOutcomeDistributionScenario")]
        public CallOutcomeDistributionScenario CallOutcomeDistributionScenarioObject { get; set; }

        [XmlIgnore]
        public TimeSpan RequestFrequency
        {
            get { return TimeSpan.Parse(XmlRequestFrequency); }
        }

        [XmlElement("RequestFrequency")]
        public string XmlRequestFrequency { get; set; }

        [XmlIgnore]
        public TimeSpan MaxRequestTime
        {
            get { return TimeSpan.Parse(XmlMaxRequestTime); }
        }

        [XmlElement("MaxRequestTime")]
        public string XmlMaxRequestTime { get; set; }

        [XmlElement]
        public int CallsCountPerInterviewer { get; set; }

        [XmlElement]
        public DialerErrorCode LoginResultCode { get; set; }

        [XmlElement]
        public DialerErrorCode SetCampaignResultCode { get; set; }

        [XmlElement]
        public int GoNotReadyNotificationDelay { get; set; }

        [XmlElement]
        public bool SendNotReadyNotificationOnLogin { get; set; }

        public static SimulatorScenario Deserialize(string scenarioXmlFileName)
        {
            var xmlSerializer = new XmlSerializer(typeof(SimulatorScenario));
            using (var streamReader = File.OpenText(scenarioXmlFileName))
            {
                return (SimulatorScenario)xmlSerializer.Deserialize(streamReader);
            }
        }

        public void Serialize(string scenarioXmlFileName)
        {
            var xmlSerializer = new XmlSerializer(typeof(SimulatorScenario));
            using (var streamWriter = File.CreateText(scenarioXmlFileName))
            {
                xmlSerializer.Serialize(streamWriter, this);
            }
        }
    }
}