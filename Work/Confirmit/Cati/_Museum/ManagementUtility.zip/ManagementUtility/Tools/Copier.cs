﻿using System.IO;
using ManagementUtility.Interfaces;

namespace ManagementUtility.Tools
{
    public class Copier : ICopier
    {
        private readonly ILogger _logger;
        private readonly IFactory _factory;
        private readonly IConfigsEngine _configEngine;
        private readonly string _startupPath;

        public Copier(ILogger logger, string startupPath, IFactory factory, IConfigsEngine configEngine)
        {
            _logger = logger;
            _factory = factory;
            _configEngine = configEngine;
            _startupPath = startupPath;
        }

        public void CopyLtuToRemoteServers(TestConfiguration testConfiguration, string ltuLocalPath)
        {
            BackendServerNameGetter backendServerNameGetter = _factory.CreateBackendServerNameGetter(testConfiguration);

            foreach (string machineName in testConfiguration.LoadTestEnvironmentInfo.LTUServers.MachineNames)
            {
                string remotePath = string.Format(@"\\{0}\c$\{1}", machineName, TestConfiguration.RootLtuFolderName);
                if (Directory.Exists(remotePath))
                {
                    Directory.Delete(remotePath, true);
                }               

                _configEngine.ConfigureLtuConfig(backendServerNameGetter.GetNext(), ltuLocalPath, testConfiguration, Path.Combine(@"c:\", TestConfiguration.RootLtuFolderName, "Logs"));

                CopyDirectory(ltuLocalPath, remotePath);

                string bsrLocalPath = Path.Combine(_startupPath, "BuildServerRegistrator");

                _configEngine.ConfigureBsrConfig(bsrLocalPath, testConfiguration);

                CopyDirectory(bsrLocalPath, Path.Combine(remotePath, "BuildServerRegistrator"));
            }
        }

        public void CopyDirectory(string sourceFolderPath, string destinationFolderPath)
        {
            var directoryInfo = new DirectoryInfo(sourceFolderPath);
            foreach (DirectoryInfo subDirectoryInfo in directoryInfo.GetDirectories())
            {
                CopyDirectory(subDirectoryInfo.FullName, Path.Combine(destinationFolderPath, subDirectoryInfo.Name));
            }

            if (!Directory.Exists(destinationFolderPath))
            {
                Directory.CreateDirectory(destinationFolderPath);
            }

            foreach (FileInfo fileInfo in directoryInfo.GetFiles())
            {
                fileInfo.CopyTo(Path.Combine(destinationFolderPath, fileInfo.Name));
            }
        }
    }
}