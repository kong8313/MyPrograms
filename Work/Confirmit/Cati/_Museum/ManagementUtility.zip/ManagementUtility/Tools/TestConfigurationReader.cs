﻿using System;
using System.Configuration;
using System.IO;
using System.Net.NetworkInformation;
using ManagementUtility.Interfaces;
using ManagementUtility.LtuTools;

namespace ManagementUtility.Tools
{
    public class TestConfigurationReader : ITestConfigurationReader
    {
        private readonly ILogger _logger;
        private readonly IXmlConfigParser _xmlConfigParser;
        private readonly ISurveySchemaReader _surveySchemaReader;
        private readonly string _currentMachineFullName;
        private readonly string _currentHostName;

        public TestConfigurationReader(ILogger logger, IXmlConfigParser xmlConfigParser, ISurveySchemaReader surveySchemaReader)
        {
            _logger = logger;
            _xmlConfigParser = xmlConfigParser;
            _surveySchemaReader = surveySchemaReader;
            var ipProperties = IPGlobalProperties.GetIPGlobalProperties();
            _currentMachineFullName = string.IsNullOrEmpty(ipProperties.DomainName) 
                ? ipProperties.HostName 
                : string.Format("{0}.{1}", ipProperties.HostName, ipProperties.DomainName);
            _currentHostName = ipProperties.HostName;
        }   

        public TestConfiguration ReadConfiguration(string envConfigPath, string muConfigPath, string ltuConfigPath, string ltuLocalFolder)
        {
            _logger.WriteLog("Verify config paths");

            envConfigPath = Path.GetFullPath("configs\\" + envConfigPath);
            muConfigPath = Path.GetFullPath("configs\\" + muConfigPath);
            
            _xmlConfigParser.LoadManagementUtilityConfig(muConfigPath);
            string dataCollectorSetsConfigPath = Path.Combine(
                Path.GetDirectoryName(muConfigPath) ?? string.Empty,
                ConfigurationManager.AppSettings["DataCollectorSetsConfigPath"]);

            var loadTestEnvironment = _xmlConfigParser.GetXmlConfig<LoadTestEnvironment>(envConfigPath);
            ReplaceLocalhostsToCurrentServerName(loadTestEnvironment);

            var dataCollectorSets = _xmlConfigParser.GetXmlConfig<DataCollectorSets>(dataCollectorSetsConfigPath);
            if (dataCollectorSets.DataCollectorSetInfoArray == null)
            {
                dataCollectorSets.DataCollectorSetInfoArray = new DataCollectorSetInfo[0];
            }

            LtuTestConfigurationXmlModel testConfigurationXmlModel = null;
            if (!string.IsNullOrEmpty(ltuConfigPath))
            {
                ltuConfigPath = Path.GetFullPath(ltuLocalFolder + "\\Configs\\" + ltuConfigPath);
                testConfigurationXmlModel = _xmlConfigParser.GetXmlConfig<LtuTestConfigurationXmlModel>(ltuConfigPath);            
            }

            return new TestConfiguration(_surveySchemaReader, dataCollectorSets, loadTestEnvironment, testConfigurationXmlModel, ltuConfigPath, ltuLocalFolder);
        }        

        public void ReplaceLocalhostsToCurrentServerName(LoadTestEnvironment loadTestEnvironment)
        {
            const string localMachineName = "localmachinename";
            for (int i = 0; i < loadTestEnvironment.CATIServers.MachineNames.Length; i++)
            {
                if (loadTestEnvironment.CATIServers.MachineNames[i].ToLower().Contains(localMachineName))
                {
                    loadTestEnvironment.CATIServers.MachineNames[i] = loadTestEnvironment.CATIServers.MachineNames[i].ToLower().Replace(localMachineName, _currentMachineFullName);
                }
            }

            for (int i = 0; i < loadTestEnvironment.LTUServers.MachineNames.Length; i++)
            {
                if (loadTestEnvironment.LTUServers.MachineNames[i].ToLower().Contains(localMachineName))
                {
                    loadTestEnvironment.LTUServers.MachineNames[i] = loadTestEnvironment.LTUServers.MachineNames[i].ToLower().Replace(localMachineName, _currentMachineFullName);
                }
            }

            if (loadTestEnvironment.ConfirmitServer.ToLower().Contains(localMachineName))
            {
                loadTestEnvironment.ConfirmitServer = loadTestEnvironment.ConfirmitServer.ToLower().Replace(localMachineName, _currentMachineFullName);
            }

            if (loadTestEnvironment.LoadBalancerServer.ToLower().Contains(localMachineName))
            {
                loadTestEnvironment.LoadBalancerServer = loadTestEnvironment.LoadBalancerServer.ToLower().Replace(localMachineName, _currentMachineFullName);
            }
            
            foreach (var server in loadTestEnvironment.SQLServers)
            {
                if (server.MachineName.ToLower().Contains(localMachineName))
                {
                    server.MachineName = server.MachineName.ToLower().Replace(localMachineName, _currentMachineFullName);
                    server.ConnectionString = server.ConnectionString.ToLower().Replace(localMachineName, _currentHostName);
                }
            }

            if (!String.IsNullOrEmpty(loadTestEnvironment.Dialer.MachineName) &&
                loadTestEnvironment.Dialer.MachineName.ToLower().Contains(localMachineName))
            {
                loadTestEnvironment.Dialer.MachineName = loadTestEnvironment.Dialer.MachineName.ToLower().Replace(localMachineName, _currentMachineFullName);
            }

            if (!String.IsNullOrEmpty(loadTestEnvironment.Dialer.WSMachineName) && 
                loadTestEnvironment.Dialer.WSMachineName.ToLower().Contains(localMachineName))
            {
                loadTestEnvironment.Dialer.WSMachineName = loadTestEnvironment.Dialer.WSMachineName.ToLower().Replace(localMachineName, _currentMachineFullName);
            }
        }
    }
}