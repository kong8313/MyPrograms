﻿using ManagementUtility.Interfaces;

namespace ManagementUtility.Tools
{
    public class BackendServerNameGetter : IBackendServerNameGetter
    {
        private readonly string[] _catiMachineNames;
        private readonly string _loadBalancerServerName;
        private int _cur;

        public BackendServerNameGetter(TestConfiguration testConfiguration)
        {
            _loadBalancerServerName = testConfiguration.LoadTestEnvironmentInfo.LoadBalancerServer;
            _catiMachineNames = testConfiguration.LoadTestEnvironmentInfo.CATIServers.MachineNames;
            _cur = 0; 
        }

        public string GetNext()
        {
            if (!string.IsNullOrEmpty(_loadBalancerServerName))
            {
                return _loadBalancerServerName;
            }

            try
            {
                return _catiMachineNames[_cur++];
            }
            finally
            {
                if (_cur >= _catiMachineNames.Length)
                {
                    _cur = 0;
                }
            }
        }
    }
}