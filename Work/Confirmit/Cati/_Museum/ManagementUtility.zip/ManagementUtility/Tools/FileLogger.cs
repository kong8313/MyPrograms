﻿using System;
using System.Diagnostics;
using System.IO;
using ManagementUtility.Interfaces;

namespace ManagementUtility.Tools
{
    public class FileLogger : ILogger
    {
        private readonly string _logFilePath;
        private readonly object _lock;

        public FileLogger(string logFilePath)
        {
            _lock = new object();
            _logFilePath = logFilePath;
            CreateLogDirectoryAndRemoveOldLogFile();
        }

        private void CreateLogDirectoryAndRemoveOldLogFile()
        {
            string logDirectory = Path.GetDirectoryName(_logFilePath);
            if (logDirectory == null)
            {
                throw new Exception("Wrong log file path");
            }

            if (File.Exists(_logFilePath))
            {
                File.Delete(_logFilePath);
            }
            else if (!Directory.Exists(logDirectory))
            {
                Directory.CreateDirectory(logDirectory);
            }
        }

        public void WriteLog(string message, params object[] parameters)
        {
            WriteLog(TraceEventType.Information, message, parameters);
        }

        public void WriteLog(TraceEventType traceType, string message, params object[] parameters)
        {
            lock (_lock)
            {
                if (parameters.Length > 0)
                {
                    message = string.Format(message, parameters);
                }

                using (var sw = new StreamWriter(_logFilePath, true))
                {
                    DateTime nowTime = DateTime.Now;
                    sw.WriteLine(nowTime.ToLongTimeString() + "." + nowTime.Millisecond + ": " + traceType + ": " + message);
                }
            }
        }
    }
}
