﻿namespace ManagementUtility
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonStart = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxDoNotCleanConfirmlog = new System.Windows.Forms.CheckBox();
            this.textBoxReason = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonTest = new System.Windows.Forms.Button();
            this.checkBoxRunPreparation = new System.Windows.Forms.CheckBox();
            this.dateTimePickerTestDuration = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonStop = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.richTextBoxAction = new System.Windows.Forms.TextBox();
            this.comboBoxEnvConfigPath = new System.Windows.Forms.ComboBox();
            this.textBoxMUConfigPath = new System.Windows.Forms.ComboBox();
            this.buttonStopServices = new System.Windows.Forms.Button();
            this.buttonStartServices = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonExpand = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.checkedListBoxLTUConfigPath = new System.Windows.Forms.CheckedListBox();
            this.labelCurrentLTUConfig = new System.Windows.Forms.Label();
            this.labelConfigSubPath = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonUpdateInstallations = new System.Windows.Forms.Button();
            this.buttonBuildReport = new System.Windows.Forms.Button();
            this.labelState = new System.Windows.Forms.Label();
            this.comboBoxLtuVersion = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Environment XML Config Name ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Management Utility Config Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "LTU Config Name";
            // 
            // buttonStart
            // 
            this.buttonStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStart.Location = new System.Drawing.Point(119, 85);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(157, 27);
            this.buttonStart.TabIndex = 13;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.ButtonStartClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBoxDoNotCleanConfirmlog);
            this.groupBox1.Controls.Add(this.textBoxReason);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.buttonTest);
            this.groupBox1.Controls.Add(this.buttonStart);
            this.groupBox1.Controls.Add(this.checkBoxRunPreparation);
            this.groupBox1.Controls.Add(this.dateTimePickerTestDuration);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.buttonStop);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(7, 325);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(395, 121);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Run test";
            // 
            // checkBoxDoNotCleanConfirmlog
            // 
            this.checkBoxDoNotCleanConfirmlog.AutoSize = true;
            this.checkBoxDoNotCleanConfirmlog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxDoNotCleanConfirmlog.Location = new System.Drawing.Point(6, 35);
            this.checkBoxDoNotCleanConfirmlog.Name = "checkBoxDoNotCleanConfirmlog";
            this.checkBoxDoNotCleanConfirmlog.Size = new System.Drawing.Size(300, 17);
            this.checkBoxDoNotCleanConfirmlog.TabIndex = 33;
            this.checkBoxDoNotCleanConfirmlog.Text = "Do not clean \'confirmlog\' database, before start a new test";
            this.checkBoxDoNotCleanConfirmlog.UseVisualStyleBackColor = true;
            // 
            // textBoxReason
            // 
            this.textBoxReason.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxReason.Location = new System.Drawing.Point(51, 59);
            this.textBoxReason.Name = "textBoxReason";
            this.textBoxReason.Size = new System.Drawing.Size(338, 20);
            this.textBoxReason.TabIndex = 34;
            this.textBoxReason.Text = "Why did you decide to run a test? Type your reason.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(2, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 33;
            this.label4.Text = "Reason:";
            // 
            // buttonTest
            // 
            this.buttonTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTest.Location = new System.Drawing.Point(5, 85);
            this.buttonTest.Name = "buttonTest";
            this.buttonTest.Size = new System.Drawing.Size(103, 27);
            this.buttonTest.TabIndex = 16;
            this.buttonTest.Text = "Test Settings";
            this.buttonTest.UseVisualStyleBackColor = true;
            this.buttonTest.Click += new System.EventHandler(this.ButtonTestClick);
            // 
            // checkBoxRunPreparation
            // 
            this.checkBoxRunPreparation.AutoSize = true;
            this.checkBoxRunPreparation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxRunPreparation.Location = new System.Drawing.Point(6, 15);
            this.checkBoxRunPreparation.Name = "checkBoxRunPreparation";
            this.checkBoxRunPreparation.Size = new System.Drawing.Size(277, 17);
            this.checkBoxRunPreparation.TabIndex = 7;
            this.checkBoxRunPreparation.Text = "Run LTU in preparation mode automatically if needed";
            this.checkBoxRunPreparation.UseVisualStyleBackColor = true;
            // 
            // dateTimePickerTestDuration
            // 
            this.dateTimePickerTestDuration.CustomFormat = "HH:mm:ss";
            this.dateTimePickerTestDuration.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerTestDuration.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerTestDuration.Location = new System.Drawing.Point(307, 26);
            this.dateTimePickerTestDuration.Name = "dateTimePickerTestDuration";
            this.dateTimePickerTestDuration.ShowCheckBox = true;
            this.dateTimePickerTestDuration.ShowUpDown = true;
            this.dateTimePickerTestDuration.Size = new System.Drawing.Size(83, 20);
            this.dateTimePickerTestDuration.TabIndex = 11;
            this.dateTimePickerTestDuration.Value = new System.DateTime(2013, 10, 25, 5, 0, 0, 0);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(307, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Test limit:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonStop
            // 
            this.buttonStop.Enabled = false;
            this.buttonStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStop.Location = new System.Drawing.Point(286, 85);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(103, 27);
            this.buttonStop.TabIndex = 15;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.ButtonStopClick);
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.TimerTick);
            // 
            // richTextBoxAction
            // 
            this.richTextBoxAction.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBoxAction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBoxAction.Location = new System.Drawing.Point(7, 477);
            this.richTextBoxAction.MaxLength = 200000;
            this.richTextBoxAction.Multiline = true;
            this.richTextBoxAction.Name = "richTextBoxAction";
            this.richTextBoxAction.ReadOnly = true;
            this.richTextBoxAction.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.richTextBoxAction.Size = new System.Drawing.Size(395, 87);
            this.richTextBoxAction.TabIndex = 19;
            this.richTextBoxAction.TabStop = false;
            // 
            // comboBoxEnvConfigPath
            // 
            this.comboBoxEnvConfigPath.FormattingEnabled = true;
            this.comboBoxEnvConfigPath.Location = new System.Drawing.Point(58, 45);
            this.comboBoxEnvConfigPath.Name = "comboBoxEnvConfigPath";
            this.comboBoxEnvConfigPath.Size = new System.Drawing.Size(338, 21);
            this.comboBoxEnvConfigPath.TabIndex = 1;
            // 
            // textBoxMUConfigPath
            // 
            this.textBoxMUConfigPath.FormattingEnabled = true;
            this.textBoxMUConfigPath.Location = new System.Drawing.Point(58, 96);
            this.textBoxMUConfigPath.Name = "textBoxMUConfigPath";
            this.textBoxMUConfigPath.Size = new System.Drawing.Size(338, 21);
            this.textBoxMUConfigPath.TabIndex = 3;
            // 
            // buttonStopServices
            // 
            this.buttonStopServices.Location = new System.Drawing.Point(416, 39);
            this.buttonStopServices.Name = "buttonStopServices";
            this.buttonStopServices.Size = new System.Drawing.Size(131, 23);
            this.buttonStopServices.TabIndex = 22;
            this.buttonStopServices.Text = "Stop all services";
            this.buttonStopServices.UseVisualStyleBackColor = true;
            this.buttonStopServices.Click += new System.EventHandler(this.ButtonStopServicesClick);
            // 
            // buttonStartServices
            // 
            this.buttonStartServices.Location = new System.Drawing.Point(416, 9);
            this.buttonStartServices.Name = "buttonStartServices";
            this.buttonStartServices.Size = new System.Drawing.Size(131, 23);
            this.buttonStartServices.TabIndex = 21;
            this.buttonStartServices.Text = "Start all services";
            this.buttonStartServices.UseVisualStyleBackColor = true;
            this.buttonStartServices.Click += new System.EventHandler(this.ButtonStartServicesClick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(417, 108);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 23);
            this.button1.TabIndex = 23;
            this.button1.Text = "Do something";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1Click);
            // 
            // buttonExpand
            // 
            this.buttonExpand.Location = new System.Drawing.Point(368, 3);
            this.buttonExpand.Name = "buttonExpand";
            this.buttonExpand.Size = new System.Drawing.Size(30, 19);
            this.buttonExpand.TabIndex = 30;
            this.buttonExpand.Text = "->";
            this.buttonExpand.UseVisualStyleBackColor = true;
            this.buttonExpand.Click += new System.EventHandler(this.ButtonExpandClick);
            this.buttonExpand.MouseEnter += new System.EventHandler(this.ButtonExpandMouseEnter);
            this.buttonExpand.MouseLeave += new System.EventHandler(this.ButtonExpandMouseLeave);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(417, 137);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(130, 23);
            this.buttonExit.TabIndex = 26;
            this.buttonExit.Text = "Кнопочка \"Exit\"";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.ButtonExitClick);
            // 
            // checkedListBoxLTUConfigPath
            // 
            this.checkedListBoxLTUConfigPath.FormattingEnabled = true;
            this.checkedListBoxLTUConfigPath.Location = new System.Drawing.Point(7, 151);
            this.checkedListBoxLTUConfigPath.Name = "checkedListBoxLTUConfigPath";
            this.checkedListBoxLTUConfigPath.Size = new System.Drawing.Size(389, 124);
            this.checkedListBoxLTUConfigPath.TabIndex = 5;
            // 
            // labelCurrentLTUConfig
            // 
            this.labelCurrentLTUConfig.AutoSize = true;
            this.labelCurrentLTUConfig.Location = new System.Drawing.Point(4, 447);
            this.labelCurrentLTUConfig.Name = "labelCurrentLTUConfig";
            this.labelCurrentLTUConfig.Size = new System.Drawing.Size(103, 13);
            this.labelCurrentLTUConfig.TabIndex = 27;
            this.labelCurrentLTUConfig.Text = "Current LTU config: ";
            this.labelCurrentLTUConfig.Visible = false;
            // 
            // labelConfigSubPath
            // 
            this.labelConfigSubPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelConfigSubPath.Location = new System.Drawing.Point(126, 130);
            this.labelConfigSubPath.Name = "labelConfigSubPath";
            this.labelConfigSubPath.Size = new System.Drawing.Size(271, 13);
            this.labelConfigSubPath.TabIndex = 28;
            this.labelConfigSubPath.Text = "Confirmit.CATI.LoadTestUtility\\Configs";
            this.labelConfigSubPath.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(4, 99);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 29;
            this.label6.Text = "configs\\";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(4, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 13);
            this.label8.TabIndex = 30;
            this.label8.Text = "configs\\";
            // 
            // buttonUpdateInstallations
            // 
            this.buttonUpdateInstallations.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUpdateInstallations.Location = new System.Drawing.Point(109, 287);
            this.buttonUpdateInstallations.Name = "buttonUpdateInstallations";
            this.buttonUpdateInstallations.Size = new System.Drawing.Size(186, 27);
            this.buttonUpdateInstallations.TabIndex = 32;
            this.buttonUpdateInstallations.Text = "Update Dialer Web Service";
            this.buttonUpdateInstallations.UseVisualStyleBackColor = true;
            this.buttonUpdateInstallations.Click += new System.EventHandler(this.ButtonUpdateInstallationsClick);
            // 
            // buttonBuildReport
            // 
            this.buttonBuildReport.Location = new System.Drawing.Point(416, 68);
            this.buttonBuildReport.Name = "buttonBuildReport";
            this.buttonBuildReport.Size = new System.Drawing.Size(131, 33);
            this.buttonBuildReport.TabIndex = 0;
            this.buttonBuildReport.Text = "Build report for last test run";
            this.buttonBuildReport.UseVisualStyleBackColor = true;
            this.buttonBuildReport.Click += new System.EventHandler(this.buttonBuildReport_Click);
            // 
            // labelState
            // 
            this.labelState.AutoSize = true;
            this.labelState.Location = new System.Drawing.Point(4, 461);
            this.labelState.Name = "labelState";
            this.labelState.Size = new System.Drawing.Size(35, 13);
            this.labelState.TabIndex = 33;
            this.labelState.Text = "State:";
            // 
            // comboBoxLtuVersion
            // 
            this.comboBoxLtuVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxLtuVersion.FormattingEnabled = true;
            this.comboBoxLtuVersion.Items.AddRange(new object[] {
            "Confirmit.CATI.LoadTestUtility.BBCC",
            "Confirmit.CATI.LoadTestUtility"});
            this.comboBoxLtuVersion.Location = new System.Drawing.Point(121, 3);
            this.comboBoxLtuVersion.Name = "comboBoxLtuVersion";
            this.comboBoxLtuVersion.Size = new System.Drawing.Size(241, 21);
            this.comboBoxLtuVersion.TabIndex = 34;
            this.comboBoxLtuVersion.SelectedIndexChanged += new System.EventHandler(this.comboBoxLtuVersion_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(4, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 13);
            this.label9.TabIndex = 35;
            this.label9.Text = "Select LTU version";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 569);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.comboBoxLtuVersion);
            this.Controls.Add(this.labelState);
            this.Controls.Add(this.buttonBuildReport);
            this.Controls.Add(this.buttonUpdateInstallations);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.labelConfigSubPath);
            this.Controls.Add(this.labelCurrentLTUConfig);
            this.Controls.Add(this.checkedListBoxLTUConfigPath);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonExpand);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonStopServices);
            this.Controls.Add(this.buttonStartServices);
            this.Controls.Add(this.textBoxMUConfigPath);
            this.Controls.Add(this.comboBoxEnvConfigPath);
            this.Controls.Add(this.richTextBoxAction);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(420, 800);
            this.MinimumSize = new System.Drawing.Size(420, 520);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Management Utility";
            this.Shown += new System.EventHandler(this.MainFormShown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.TextBox richTextBoxAction;
        private System.Windows.Forms.ComboBox comboBoxEnvConfigPath;
        private System.Windows.Forms.ComboBox textBoxMUConfigPath;
        private System.Windows.Forms.DateTimePicker dateTimePickerTestDuration;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonStopServices;
        private System.Windows.Forms.Button buttonStartServices;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonExpand;
        private System.Windows.Forms.CheckBox checkBoxRunPreparation;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.CheckedListBox checkedListBoxLTUConfigPath;
        private System.Windows.Forms.Label labelCurrentLTUConfig;
        private System.Windows.Forms.Label labelConfigSubPath;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonTest;
        private System.Windows.Forms.Button buttonUpdateInstallations;
        private System.Windows.Forms.TextBox textBoxReason;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBoxDoNotCleanConfirmlog;
        private System.Windows.Forms.Button buttonBuildReport;
        private System.Windows.Forms.Label labelState;
        private System.Windows.Forms.ComboBox comboBoxLtuVersion;
        private System.Windows.Forms.Label label9;
    }
}

