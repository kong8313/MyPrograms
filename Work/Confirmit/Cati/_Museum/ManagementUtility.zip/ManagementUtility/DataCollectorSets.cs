﻿using System.Xml.Serialization;

namespace ManagementUtility
{
    public enum ProductType
    {
        Backend,
        CatiSQL,
        DialerWS,
        Dialer,
        LTU,
        ConfirmConfirmlogSQL,
        SurveySQL
    }

    [XmlType(AnonymousType = true)]
    [XmlRoot(Namespace = "", IsNullable = false)]
    public class DataCollectorSets
    {
        [XmlElement("DataCollectorSet")]
        public DataCollectorSetInfo[] DataCollectorSetInfoArray { get; set; }
    }

    [XmlType(AnonymousType = true)]
    public class DataCollectorSetInfo
    {
        public ProductType Type { get; set; }
        public string XmlTemplate { get; set; }
    }
}
