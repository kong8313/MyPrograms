﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using ManagementUtility.Interfaces;
using ManagementUtility.LtuTools;

namespace ManagementUtility
{
    public class TestConfiguration
    {
        public const string RootLtuFolderName = @"__LTU__";

        private const string DialerConfigurationUtilityName = @"DialerConfigurationUtility.exe";
        public string DialerConfigurationUtility
        {
            get
            {
                return DialerConfigurationUtilityName;
            }
        }

        public DataCollectorSets DataCollectorSetsInfo { get; private set; }
        public LoadTestEnvironment LoadTestEnvironmentInfo { get; private set; }
        public LtuTestConfigurationXmlModel LtuTestConfigurationXmlModel { get; private set; }
        public string LtuConfigPath { get; private set; }

        public const string PsExecCredentials = "/accepteula /s"; // /e /u firm\\TestlabInstaller /p ve3YEJbQ

        public bool IsDialerUse { get; private set; }
        public string DialingMode { get; private set; }
        public string ClearBvDialersTable { get; private set; }
        public bool DialerSimulatorAutomaticMode { get; private set; }
        public bool ClearConfirmlogTable { get; private set; }

        /// <summary>
        /// Local path on SQL servers to backups folder. Get from config
        /// </summary>
        public string BackupFolderPathOnSqlServer { get; private set; }

        /// <summary>
        /// Remote path to backup folder on CATI SQL server
        /// </summary>
        public string CatiBackupServerFolderPath { get; private set; }

        /// <summary>
        /// Remote path to backup folder on Survey SQL server
        /// </summary>
        public string SurveyBackupServerFolderPath { get; private set; }

        public string CompanyId { get; private set; }
        public string CompanyAlias { get; private set; }
        public string MultimodeWebServiceURL { get; private set; }

        public string SimulatorScenarioPath { get; private set; }
        public string ResponseSimCfgPath { get; private set; }
        public string BvTciScenarioPath { get; private set; }

        public string SimulatorScenarioRemotePath { get; private set; }
        public string ResponseSimCfgRemotePath { get; private set; }
        public string BvTciScenarioRemotePath { get; private set; }
         
        public string PerfResultSharedPath { get; private set; }

        public TestConfiguration(
            ISurveySchemaReader schemaReader,
            DataCollectorSets dataCollectorSets, 
            LoadTestEnvironment loadTestEnvironment, 
            LtuTestConfigurationXmlModel ltuTestConfigurationXmlModel, 
            string ltuConfigPath,
            string localLtuFolder)
        {
            DataCollectorSetsInfo = dataCollectorSets;
            LoadTestEnvironmentInfo = loadTestEnvironment;
            LtuTestConfigurationXmlModel = ltuTestConfigurationXmlModel;
            LtuConfigPath = ltuConfigPath;

            IsDialerUse = LoadTestEnvironmentInfo.Dialer.WSMachineName != null;

            if (ltuTestConfigurationXmlModel != null)
            {
                foreach (var surveyScenario in LtuTestConfigurationXmlModel.SurveyScenarios)
                {
                    var schemaPath = Path.GetFullPath(localLtuFolder + "\\Configs\\" + surveyScenario.SchemaPath);
                    surveyScenario.Schema = schemaReader.Load(schemaPath);
                }
            }

            DialingMode = ConfigurationManager.AppSettings["DialingMode"];
            ClearBvDialersTable = ConfigurationManager.AppSettings["ClearBvDialersTable"];
            DialerSimulatorAutomaticMode = ConfigurationManager.AppSettings["DialerSimulatorAutomaticMode"].ToLower() == "true";

            SpecifySqlServerBackupParameters();

            CompanyId = ConfigurationManager.AppSettings["CompanyID"];
            CompanyAlias = ConfigurationManager.AppSettings["CompanyAlias"];

            if (IsDialerUse)
            {
                SimulatorScenarioPath = ConfigurationManager.AppSettings["SimulatorScenarioXmlPath"];
                ResponseSimCfgPath = ConfigurationManager.AppSettings["ResponseSimCfgPath"];
                BvTciScenarioPath = ConfigurationManager.AppSettings["BvTciScenarioXmlPath"];

                SimulatorScenarioRemotePath = GetRemotePathOnServerWithDilaer(ConfigurationManager.AppSettings["SimulatorScenarioXmlPath"]);
                ResponseSimCfgRemotePath = GetRemotePathOnServerWithDilaer(ConfigurationManager.AppSettings["ResponseSimCfgPath"]);
                BvTciScenarioRemotePath = GetRemotePathOnServerWithDilaer(ConfigurationManager.AppSettings["BvTciScenarioXmlPath"]);
            }

            MultimodeWebServiceURL = string.Format("http://{0}/ManagementMultimodeInstance",
                string.IsNullOrEmpty(loadTestEnvironment.LoadBalancerServer)
                    ? loadTestEnvironment.CATIServers.MachineNames.First()
                    : loadTestEnvironment.LoadBalancerServer);

            PerfResultSharedPath = ConfigurationManager.AppSettings["PerfResultSharedPath"];
        }

        private string GetRemotePathOnServerWithDilaer(string localPath)
        {
            return string.Format(@"\\{0}\{1}", LoadTestEnvironmentInfo.Dialer.MachineName, localPath.Replace(':', '$'));
        }

        private void SpecifySqlServerBackupParameters()
        {
            BackupFolderPathOnSqlServer = ConfigurationManager.AppSettings["BackupFolderPathOnSqlServer"];
            CatiBackupServerFolderPath = string.Format(@"\\{0}\{1}", SQLCatiMachineName, BackupFolderPathOnSqlServer.Replace(':', '$'));
            SurveyBackupServerFolderPath = string.Format(@"\\{0}\{1}", SQLSurveyMachineName, BackupFolderPathOnSqlServer.Replace(':', '$'));
        }

        public string ConnectionStringToBE
        {
            get
            {
                Server server = LoadTestEnvironmentInfo.SQLServers.First(x => x.Type == ServerType.Cati);
                return server.ConnectionString;
            }
        }

        public string ConnectionStringToCF
        {
            get
            {
                Server server = LoadTestEnvironmentInfo.SQLServers.First(x => x.Type == ServerType.ConfirmConfirmlog);
                var scsb = new SqlConnectionStringBuilder(server.ConnectionString)
                {
                    InitialCatalog = "master"
                };
                return scsb.ConnectionString;
            }
        }

        public string ConnectionStringToConfirmDB
        {
            get
            {
                Server server = LoadTestEnvironmentInfo.SQLServers.First(x => x.Type == ServerType.ConfirmConfirmlog);
                var scsb = new SqlConnectionStringBuilder(server.ConnectionString)
                {
                    InitialCatalog = "confirm"
                };
                return scsb.ConnectionString;
            }
        }

        public string ConnectionStringToConfirmlogDB
        {
            get
            {
                Server server = LoadTestEnvironmentInfo.SQLServers.First(x => x.Type == ServerType.ConfirmConfirmlog);
                var scsb = new SqlConnectionStringBuilder(server.ConnectionString)
                {
                    InitialCatalog = "confirmlog"
                };
                return scsb.ConnectionString;
            }
        }

        public string FirstBackendMachineName
        {
            get
            {
                return LoadTestEnvironmentInfo.CATIServers.MachineNames[0];
            }
        }

        public string SQLCatiMachineName
        {
            get
            {
                Server server = LoadTestEnvironmentInfo.SQLServers.First(x => x.Type == ServerType.Cati);
                return server.MachineName;
            }
        }

        public string SQLSurveyMachineName
        {
            get
            {
                Server server = LoadTestEnvironmentInfo.SQLServers.First(x => x.Type == ServerType.Survey);
                return server.MachineName;
            }
        }

        public LtuTestConfigurationXmlModel.SurveyScenario[] SurveyScenarios
        {
            get
            {
                return LtuTestConfigurationXmlModel.SurveyScenarios.ToArray();
            }
        }

        public IEnumerable<string> GetServerNames(ProductType productType)
        {
            switch (productType)
            {
                case ProductType.Backend:
                    return LoadTestEnvironmentInfo.CATIServers.MachineNames;
                case ProductType.CatiSQL:
                    return LoadTestEnvironmentInfo.SQLServers.Where(x => x.Type == ServerType.Cati).Select(x => x.MachineName).ToArray();
                case ProductType.ConfirmConfirmlogSQL:
                    return LoadTestEnvironmentInfo.SQLServers.Where(x => x.Type == ServerType.ConfirmConfirmlog).Select(x => x.MachineName).ToArray();
                case ProductType.SurveySQL:
                    return LoadTestEnvironmentInfo.SQLServers.Where(x => x.Type == ServerType.Survey).Select(x => x.MachineName).ToArray();
                case ProductType.Dialer:
                    return LoadTestEnvironmentInfo.Dialer.MachineName != null ? new[] { LoadTestEnvironmentInfo.Dialer.MachineName } : new string[]{};
                case ProductType.DialerWS:
                    return LoadTestEnvironmentInfo.Dialer.WSMachineName != null ? new[] { LoadTestEnvironmentInfo.Dialer.WSMachineName } : new string[]{};
                case ProductType.LTU:
                    return LoadTestEnvironmentInfo.LTUServers.MachineNames;
                default:
                    throw new Exception(string.Format("Unsupported type: '{0}'", productType));
            }
        }
    }
}