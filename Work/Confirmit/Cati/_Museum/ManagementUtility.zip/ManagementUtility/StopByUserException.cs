﻿using System;

namespace ManagementUtility
{
    public class StopByUserException : Exception
    {
        public StopByUserException()
            : base("Execution was stopped by user")
        {
        }
    }
}
