﻿using ManagementUtility.Controller;

namespace ManagementUtility
{
    public class TestStateObserver : ITestStateObserver
    {
        public TestStateObserver(MainForm form)
        {
            Form = form;
        }

        private MainForm Form { get; set; }

        public void ShowAction(string text)
        {
            Form.InvokeAsync(() => Form.ShowAction(text));
        }

        public void EnableAllButtons()
        {
            Form.InvokeAsync(() => Form.SetEnableStatusForAllButtons(true));
        }

        public void OnCurrentLtuConfigChanged(string configName, int index, int count)
        {
            Form.InvokeAsync(() => Form.OnCurrentLtuConfigChanged(configName, index, count));
        }
    }
}
