﻿using System;
using System.Collections.Generic;
using Confirmit.CATI.Core.DAL.Framework;

namespace ManagementUtility.Interfaces
{
    public interface IDatabaseEngines
    {
        DatabaseEngine Backend { get; }
        DatabaseEngine DefaultDatabase { get; }
        DatabaseEngine Confirmit { get; }
        DatabaseEngine Confirmlog { get; }
        DatabaseEngine Survey { get; }

        DatabaseEngine GetSurvey(string projectId);
        List<string> GetSurveyList();
        void PrepareDatabasesForTest(string catiDbName);
        void UpdateTestresultDatabase(TimeSpan duration, string reason, string branchName, string version);
    }
}