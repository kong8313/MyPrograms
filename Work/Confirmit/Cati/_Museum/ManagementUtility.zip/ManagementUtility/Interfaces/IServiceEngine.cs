﻿namespace ManagementUtility.Interfaces
{
    public interface IServiceEngine
    {
        bool IsCatiServicesStarted(TestConfiguration testConfiguration);

        bool IsCatiServicesExists(TestConfiguration testConfiguration);

        void StopCatiServices(TestConfiguration testConfiguration);

        void StartCatiServices(TestConfiguration testConfiguration);

        void RestartCatiAndConfirmitSqlServers(TestConfiguration testConfiguration);
    }
}
