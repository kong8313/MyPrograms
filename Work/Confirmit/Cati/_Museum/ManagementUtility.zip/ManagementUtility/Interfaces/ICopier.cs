﻿namespace ManagementUtility.Interfaces
{
    public interface ICopier
    {
        void CopyLtuToRemoteServers(TestConfiguration testConfiguration, string ltuLocalPath);

        void CopyDirectory(string sourceFolderPath, string destinationFolderPath);
    }
}