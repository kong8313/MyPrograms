﻿using Confirmit.CATI.Core.ManagementService;

namespace ManagementUtility.Interfaces
{
    public interface IManagementServices
    {
        IInstanceManagementService MultimodeInstance { get; }
    }
}