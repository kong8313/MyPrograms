﻿namespace ManagementUtility.Interfaces
{
    public interface IConfigsEngine
    {
        void ConfigureLtuConfig(string backendMachineName, string ltuLocation, TestConfiguration testConfiguration, string ltuLoggingPath);
        void ConfigureBsrConfig(string bsrLocalPath, TestConfiguration testConfiguration);
    }
}