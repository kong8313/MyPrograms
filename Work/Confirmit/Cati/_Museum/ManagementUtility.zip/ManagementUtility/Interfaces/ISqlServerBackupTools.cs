﻿using System.Collections.Generic;

namespace ManagementUtility.Interfaces
{
    public interface ISqlServerBackupTools
    {
        void RestoreDatabase(string serverPath, string dbName);        

        void CreateCatiAndSurveyBackups();

        void RestoreSurveyDatabases(List<string> surveyProjectIds);
    }
}