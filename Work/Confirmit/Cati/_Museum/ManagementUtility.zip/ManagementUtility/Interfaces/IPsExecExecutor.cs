﻿using System.Diagnostics;

namespace ManagementUtility.Interfaces
{
    public interface IPsExecExecutor
    {
        Process InvokeProcess(string args); 
    }
}