﻿using ManagementUtility.Controller;
using ManagementUtility.LtuTools;
using ManagementUtility.Tools;

namespace ManagementUtility.Interfaces
{
    public interface IFactory
    {
        DatabaseEngines CreateDatabaseEnginesObject(TestConfiguration testConfiguration);
        SqlServerBackupTools CreateSqlServerBackupToolsObject(
            ILogger logger, TestConfiguration testConfiguration, IDatabaseEngines databaseEngines, ITestStateObserver testStateObserver);
        ManagementServices CreateManagementServices(TestConfiguration testConfiguration);
        BackendServerNameGetter CreateBackendServerNameGetter(TestConfiguration testConfiguration);
    }
}