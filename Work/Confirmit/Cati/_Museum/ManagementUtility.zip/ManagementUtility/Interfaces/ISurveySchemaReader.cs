﻿using ManagementUtility.LtuTools;

namespace ManagementUtility.Interfaces
{
    public interface ISurveySchemaReader
    {
        SurveySchema Load(string path); 
    }
}