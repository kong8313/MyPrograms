﻿namespace ManagementUtility.Interfaces
{
    public interface IXmlConfigParser
    {
        T GetXmlConfig<T>(string xmlConfigPath);        

        void LoadManagementUtilityConfig(string muConfigPath);
    }
}