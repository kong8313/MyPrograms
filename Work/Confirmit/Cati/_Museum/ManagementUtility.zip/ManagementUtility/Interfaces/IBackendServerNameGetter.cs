﻿namespace ManagementUtility.Interfaces
{
    public interface IBackendServerNameGetter
    {
        string GetNext(); 
    }
}