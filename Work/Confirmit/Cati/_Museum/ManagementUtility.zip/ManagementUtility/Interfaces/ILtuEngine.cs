﻿using System;

namespace ManagementUtility.Interfaces
{
    public interface ILtuEngine
    {
        void RunLTUOnAllServers(TestConfiguration testConfiguration, string executionMode, string ltuLocalFolder);

        void StopLTUOnAllServers(TestConfiguration testConfiguration, string ltuLocalFolder);

        bool IsAllProcessesStoped();
             
        bool IsFirstProcessStoped();

        TimeSpan GetExecutionTime();
    }
}