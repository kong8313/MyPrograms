﻿namespace ManagementUtility.Interfaces
{
    public interface IRemoteProcessKiller
    {
         void KillProcess(string machineName, string processName);
    }
}