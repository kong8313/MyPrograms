﻿namespace ManagementUtility.Interfaces
{
    public interface IPerformanceCounterEngine
    {
        void StartPerformanceCounterGathering(TestConfiguration testConfiguration);
        void StopPerformanceCounterGathering(TestConfiguration testConfiguration);
    }
}