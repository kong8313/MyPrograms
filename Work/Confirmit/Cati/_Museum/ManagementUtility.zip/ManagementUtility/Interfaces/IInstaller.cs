﻿namespace ManagementUtility.Interfaces
{
    public interface IInstaller
    {
        string GetLtuSimulatorKitFilePath { get; }
        string GetLtuSimulatorProductName { get; }
        string GetTciDialerWebServiceProductName { get; }
        string GetTciDialerWebServiceKitFilePath { get; }
            
        string GetRemoteRootFolderPath(string serverName);

        void Install(TestConfiguration testConfiguration);
    }
}