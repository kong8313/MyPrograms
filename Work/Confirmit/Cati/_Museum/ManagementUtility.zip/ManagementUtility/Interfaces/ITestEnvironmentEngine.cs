﻿using System.Windows.Forms;
using ManagementUtility.Controller;

namespace ManagementUtility.Interfaces
{
    public interface ITestEnvironmentEngine
    {
        string ErrorMessage { get; }
        
        string TestAllSettings(TestParams parameters);

        string TestNecessarySettings(TestParams parameters);

        string TestUpdatePossibility(string envConfigPath, string muConfigPath, string ltuLocalFolder);
    }
}