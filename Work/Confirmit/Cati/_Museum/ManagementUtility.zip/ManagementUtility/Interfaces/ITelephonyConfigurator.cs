﻿namespace ManagementUtility.Interfaces
{
    public interface ITelephonyConfigurator
    {
        bool IsSimulatorStarted { get; }

        void InitializeBackendTelephone(TestConfiguration testConfiguration);

        void PutDialerSettingsToSimulatorScenarioXml(TestConfiguration testConfiguration);

        void PutDialerSettingsToResponseSimCfgTxt(TestConfiguration testConfiguration);

        void PutDialerSettingsToBvTciScenarioXml(TestConfiguration testConfiguration);

        void StartDialerSimulatorIfNeeded(TestConfiguration testConfiguration);

        void StopDialerSimulator(TestConfiguration testConfiguration);
    }
}