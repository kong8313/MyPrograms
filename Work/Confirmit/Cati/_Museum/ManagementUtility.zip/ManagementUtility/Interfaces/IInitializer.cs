﻿namespace ManagementUtility.Interfaces
{
    public interface IInitializer
    {
        void PrepareLTUForStart(TestConfiguration testConfiguration, bool doNotCleanConfirmLog, string ltuLocalPath);

        void ReCreateCompany(TestConfiguration testConfiguration);

        void RegisterServersInConfirmitDb(TestConfiguration testConfiguration, string action);
    }
}