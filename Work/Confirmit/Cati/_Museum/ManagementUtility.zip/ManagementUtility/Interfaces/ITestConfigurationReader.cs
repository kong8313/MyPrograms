﻿namespace ManagementUtility.Interfaces
{
    public interface ITestConfigurationReader
    {
        TestConfiguration ReadConfiguration(string envConfigPath, string muConfigPath, string ltuConfigPath, string ltuLocalFolder);

        void ReplaceLocalhostsToCurrentServerName(LoadTestEnvironment loadTestEnvironment);
    }
}