﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Confirmit.CATI.Common.SideBySide;
using Confirmit.CATI.Core.SupervisorService;
using ManagementUtility.Controller;
using ManagementUtility.Interfaces;
using ManagementUtility.LtuTools;
using ManagementUtility.Tools;

namespace ManagementUtility
{
    public delegate void ShowActionDelegate(string text);

    public partial class MainForm : Form
    {
        private readonly IInstaller _installer;
        private readonly ILogger _logger;
        private readonly IXmlConfigParser _xmlConfigParser;
        private readonly IFactory _factory;
        private readonly IPsExecExecutor _psExecExecutor;
        private readonly ISurveySchemaReader _surveySchemaReader;
        private readonly IRemoteProcessKiller _remoteProcessKiller;
        private readonly IServiceEngine _serviceEngine;
        private readonly ITestConfigurationReader _testConfigurationReader;
        private readonly ITestEnvironmentEngine _testEnvironmentEngine;

        private readonly TestController _testController;

        public MainForm()
        {
            InitializeComponent();

            var psExecPath = Path.Combine(Application.StartupPath, "PsExec", "PsExec.exe");

            _factory = new Factory();
            _logger = new FileLogger(Path.Combine(Application.StartupPath, "ManagementUtilityLog.txt"));
            
            _remoteProcessKiller = new RemoteProcessKiller(_logger);
            _surveySchemaReader = new SurveySchemaReader();
            _xmlConfigParser = new XmlConfigParser(_logger);
            _psExecExecutor = new PsExecExecutor(_logger, psExecPath);
            _serviceEngine = new ServiceEngine(_logger, ShowAction);
            _testConfigurationReader = new TestConfigurationReader(_logger, _xmlConfigParser, _surveySchemaReader);
            _installer = new Installer(_logger, _psExecExecutor, ShowAction);
            _testEnvironmentEngine = new TestEnvironmentEngine(
                _logger, _xmlConfigParser, _surveySchemaReader, _testConfigurationReader, _serviceEngine, _installer, _remoteProcessKiller, new SideBySideManager().SideBySideName, psExecPath);
            
            _testController = new TestController(_logger, _factory, _testEnvironmentEngine, _testConfigurationReader, _serviceEngine, _psExecExecutor, _remoteProcessKiller, new TestStateObserver(this));
        }

        private void MainFormShown(object sender, EventArgs e)
        {
            Text = "Management Utility: " + new SideBySideManager().SideBySideName;

            string configPath = string.Empty;
            try
            {
                configPath = Path.Combine(Application.StartupPath, "configs");
                FillComboBox(comboBoxEnvConfigPath, configPath, "LoadTestEnvironment.xml");
                FillComboBox(textBoxMUConfigPath, configPath, "ManagementUtility.xml");

                comboBoxLtuVersion.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                buttonStart.Enabled = false;
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
                MessageBox.Show(string.Format("Path '{0}' isn't found. Execution not possible.", configPath), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBoxLtuVersion_SelectedIndexChanged(object sender, EventArgs e)
        {
            string configPath = string.Empty;
            try
            {
                configPath = Path.Combine(Application.StartupPath, comboBoxLtuVersion.Text, "configs");
                FillCheckedListBox(checkedListBoxLTUConfigPath, configPath, "10 min test.xml");

                labelConfigSubPath.Text = comboBoxLtuVersion.Text + "\\Configs";
            }
            catch (Exception ex)
            {
                buttonStart.Enabled = false;
                _logger.WriteLog(TraceEventType.Error, ex.ToString());
                MessageBox.Show(string.Format("Path '{0}' isn't found. Execution not possible.", configPath), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void FillCheckedListBox(CheckedListBox checkedListBox, string folderPath, string defaultValue)
        {
            checkedListBox.Items.Clear();
            foreach (string filePath in Directory.GetFiles(folderPath).OrderBy(x => x))
            {
                if (Path.GetExtension(filePath) == ".xml")
                {
                    checkedListBox.Items.Add(Path.GetFileName(filePath) ?? string.Empty);
                    if (Path.GetFileName(filePath) == defaultValue)
                    {
                        checkedListBox.SetItemCheckState(checkedListBox.Items.Count - 1, CheckState.Checked);
                    }
                }
            }
        }

        private void FillComboBox(ComboBox comboBox, string folderPath, string defaultValue)
        {
            comboBox.Items.Clear();
            comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            foreach (string filePath in Directory.GetFiles(folderPath))
            {
                if (Path.GetExtension(filePath) == ".xml")
                {
                    comboBox.Items.Add(Path.GetFileName(filePath) ?? string.Empty);
                }
            }

            comboBox.Text = defaultValue;
        }

        public void ShowAction(string text)
        {
            InvokeAsync( () => richTextBoxAction.Text = text );
            _logger.WriteLog(text);
        }

        public void InvokeAsync(Action action)
        {
            Invoke(action);
        }

        public void SetEnableStatusForAllButtons(bool value)
        {
            buttonStart.Enabled = buttonExpand.Enabled = buttonTest.Enabled = buttonStop.Enabled =
            buttonUpdateInstallations.Enabled = buttonExit.Enabled =
            buttonBuildReport.Enabled = buttonStartServices.Enabled = buttonStopServices.Enabled = 
            comboBoxEnvConfigPath.Enabled = textBoxMUConfigPath.Enabled = checkedListBoxLTUConfigPath.Enabled =
            checkBoxRunPreparation.Enabled = checkBoxDoNotCleanConfirmlog.Enabled = dateTimePickerTestDuration.Enabled =
            textBoxReason.Enabled = value;
        }

        public void OnCurrentLtuConfigChanged(string configName, int index, int count)
        {
            if (string.IsNullOrEmpty(configName))
            {
                labelCurrentLTUConfig.Visible = false;
            }
            else
            {
                labelCurrentLTUConfig.Text = string.Format("Current LTU config: {0} (#{1} of {2})",
                    configName,
                    index + 1,
                    count);
                labelCurrentLTUConfig.Visible = true;

            }
        }

        public TestParams GetTestParameters()
        {
            return new TestParams()
            {
                EnvConfigPath = comboBoxEnvConfigPath.Text,
                MuConfigPath = textBoxMUConfigPath.Text,
                LtuLocalPath = Path.Combine(Application.StartupPath, comboBoxLtuVersion.Text),
                LtuConfigs = checkedListBoxLTUConfigPath.CheckedItems.Cast<string>().ToArray(),
                DoNotCleanConfirmlog = checkBoxDoNotCleanConfirmlog.Checked,
                RunPreparation = checkBoxRunPreparation.Checked,
                TestDuration = GetTimespanFromDateTimePicker(),
                Reason = textBoxReason.Text,
            };
        }

        private async void ButtonTestClick(object sender, EventArgs e)
        {
            try
            {
                SetEnableStatusForAllButtons(false);

                var parameters = GetTestParameters();

                await Task.Factory.StartNew(() =>
                {
                    _testController.CheckConfiguration(parameters);
                });
            }
            catch (Exception ex)
            {
                SetEnableStatusForAllButtons(true);
                MessageBox.Show(ex.ToString());
            }
        }

        private void ButtonStartClick(object sender, EventArgs e)
        {
            try
            {
                SetEnableStatusForAllButtons(false);

                var parameters = GetTestParameters();

                Task.Factory.StartNew(() =>
                {
                    _testController.Start(parameters);
                });
            }
            catch (Exception ex)
            {
                SetEnableStatusForAllButtons(true);
                MessageBox.Show(ex.ToString());
            }
        }

        private string GetStopButtonText()
        {
            var remainingTime = _testController.GetRemainingTime();
            if (remainingTime != null)
            {
                return $"Stop: {remainingTime.Value.Hours.ToString("D2")}:{remainingTime.Value.Minutes.ToString("D2")}:{remainingTime.Value.Seconds.ToString("D2")}";
            }

            return "Stop";
        }

        private void TimerTick(object sender, EventArgs e)
        {
            try
            {
                Task.Factory.StartNew(() =>
                {
                    _testController.OnTimerTick();
                });

                labelState.Text = $"State: {_testController.State}";

                switch (_testController.State)
                {
                    case TestState.Stopped:
                        SetEnableStatusForAllButtons(true);
                        buttonStop.Text = "Stop";
                        buttonStop.Enabled = false;
                        break;
                    case TestState.Running:
                        buttonStop.Enabled = true;
                        buttonStop.Text = GetStopButtonText();
                        break;
                    case TestState.Stopping:
                    case TestState.Starting:
                        buttonStop.Text = "Stop";
                        SetEnableStatusForAllButtons(false);
                        break;
                }
            }
            catch (Exception ex)
            {
                SetEnableStatusForAllButtons(true);
                ShowAction(string.Format("Execution has finished with error:\r\n{0}\r\nSee log for details", ex.Message));
                _logger.WriteLog(TraceEventType.Error, "An error occured during an execution:\r\n" + ex);
            }
        }

        private TimeSpan? GetTimespanFromDateTimePicker()
        {
            if (dateTimePickerTestDuration.Checked)
            {
                return TimeSpan.FromHours(dateTimePickerTestDuration.Value.Hour) + TimeSpan.FromMinutes(dateTimePickerTestDuration.Value.Minute);
            }

            return null;
        }

        private TimeSpan GetDirectTimespanFromDateTimePicker()
        {
            return TimeSpan.FromHours(dateTimePickerTestDuration.Value.Hour) + TimeSpan.FromMinutes(dateTimePickerTestDuration.Value.Minute);
        }

        private void ButtonUpdateInstallationsClick(object sender, EventArgs e)
        {
            SetEnableStatusForAllButtons(false);
            ShowAction("A testing of parameters in progress...");
            Thread.Sleep(100);
            string message = _testEnvironmentEngine.TestUpdatePossibility(comboBoxEnvConfigPath.Text, textBoxMUConfigPath.Text, comboBoxLtuVersion.Text);

            if (!string.IsNullOrEmpty(message))
            {
                _logger.WriteLog(TraceEventType.Warning, message);
                ShowAction("The utility has found some issues. You have to fix them before continue.\r\n" + message);
                SetEnableStatusForAllButtons(true);
                return;
            }

            try
            {
                ShowAction("Read config files");
                var testConfiguration = _testConfigurationReader.ReadConfiguration(comboBoxEnvConfigPath.Text, textBoxMUConfigPath.Text, string.Empty, comboBoxLtuVersion.Text);

                ShowAction("Stop CATI services");
                _serviceEngine.StopCatiServices(testConfiguration);

                _installer.Install(testConfiguration);

                ShowAction("Confirmit CATI and Confirmit CATI LTU Simulator (G) Dialer Web Service were updates successfully!");
            }
            catch (Exception ex)
            {
                ShowAction(string.Format("An unexpected error:\r\n{0}\r\nSee log for details", ex.Message));
                _logger.WriteLog(TraceEventType.Error, "An unexpected error:\r\n" + ex);
            }

            SetEnableStatusForAllButtons(true);
        }

        private async void ButtonStopClick(object sender, EventArgs e)
        {
            var ltuLocalFolder = comboBoxLtuVersion.Text;
            await Task.Factory.StartNew(() =>
            {
                _testController.Stop(ltuLocalFolder);
            });
        }

        private void ButtonStartServicesClick(object sender, EventArgs e)
        {
            try
            {
                ShowAction("Read config files");
                var testConfiguration = _testConfigurationReader.ReadConfiguration(comboBoxEnvConfigPath.Text, textBoxMUConfigPath.Text, String.Empty, comboBoxLtuVersion.Text);

                ShowAction("Start CATI services");
                _serviceEngine.StartCatiServices(testConfiguration);

                ShowAction("Execution has finished successfully!");
            }
            catch (Exception ex)
            {
                ShowAction(string.Format("Execution has finished with error:\r\n{0}\r\nSee log for details", ex.Message));
                _logger.WriteLog(TraceEventType.Error, "An error occured during an execution:\r\n" + ex);
            }
        }

        private void ButtonStopServicesClick(object sender, EventArgs e)
        {
            try
            {
                ShowAction("Read config files");
                var testConfiguration = _testConfigurationReader.ReadConfiguration(comboBoxEnvConfigPath.Text, textBoxMUConfigPath.Text, String.Empty, comboBoxLtuVersion.Text);

                ShowAction("Stop CATI services");
                _serviceEngine.StopCatiServices(testConfiguration);

                ShowAction("Execution has finished successfully!");
            }
            catch (Exception ex)
            {
                ShowAction(string.Format("Execution has finished with error:\r\n{0}\r\nSee log for details", ex.Message));
                _logger.WriteLog(TraceEventType.Error, "An error occured during an execution:\r\n" + ex);
            }
        }

        private void Button1Click(object sender, EventArgs e)
        {
            try
            {
                MessageBox.Show("Nothing to do now");
            }
            catch (Exception ex)
            {
                ShowAction(string.Format("Execution has finished with error:\r\n{0}\r\nSee log for details", ex.Message));
                _logger.WriteLog(TraceEventType.Error, "An error occured during an execution:\r\n" + ex);
            }
        }

        private void ButtonExpandClick(object sender, EventArgs e)
        {
            if (buttonExpand.Text == "->")
            {
                buttonExpand.Text = "<-";
                MaximumSize = new Size(565, 800);
                MinimumSize = new Size(565, 475);
            }
            else
            {
                buttonExpand.Text = "->";
                MinimumSize = new Size(420, 475);
                MaximumSize = new Size(420, 800);
            }
        }

        private void ButtonExitClick(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void ButtonExpandMouseEnter(object sender, EventArgs e)
        {
            if (buttonExpand.Text == "->")
            {
                toolTip.Show("Don't open, if you are not an expert!", buttonExpand, -15, -20);
            }
            else
            {
                toolTip.Show("You are right. Close it quickly :)", buttonExpand, -15, -20);
            }
        }

        private void ButtonExpandMouseLeave(object sender, EventArgs e)
        {
            toolTip.Hide(buttonExpand);
        }

        private async void buttonBuildReport_Click(object sender, EventArgs e)
        {
            SetEnableStatusForAllButtons(false);
            try
            {
                var currentLtuConfig = checkedListBoxLTUConfigPath.CheckedItems.Cast<string>().FirstOrDefault();
                ShowAction("Read config files");
                var testConfiguration = _testConfigurationReader.ReadConfiguration(comboBoxEnvConfigPath.Text, textBoxMUConfigPath.Text, currentLtuConfig, comboBoxLtuVersion.Text);

                ShowAction("Start build report");
                IDatabaseEngines databaseEngines = _factory.CreateDatabaseEnginesObject(testConfiguration);

                await Task.Factory.StartNew( () => databaseEngines.UpdateTestresultDatabase(GetDirectTimespanFromDateTimePicker(), textBoxReason.Text, new SideBySideManager().SideBySideName, GetCurrentVersion()));

                ShowAction("Report was built");
            }
            catch (Exception ex)
            {
                ShowAction($"Build report operation was failed. Exception:{ex}");
            }
            SetEnableStatusForAllButtons(true);
        }

        private string GetCurrentVersion()
        {
            return new Version(FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).ProductVersion).ToString();
        }
    }
}
