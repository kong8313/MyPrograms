﻿using System;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using Confirmit.CATI.Core.AuthoringService;
using Confirmit.CATI.Core.DAL.Framework;
using Confirmit.CATI.Core.ManagementService;
using Confirmit.CATI.Core.Misc;
using Confirmit.CATI.Core.Misc.CP;
using Confirmit.CATI.Common.ServiceLocation;
using Confirmit.CATI.Core.ServiceRegistration;
using Confirmit.CATI.Core.SystemSettings;
using ManagementUtility.Controller;
using ManagementUtility.Enums;
using ManagementUtility.Interfaces;
using ManagementUtility.LtuTools;
using ILogger = ManagementUtility.Interfaces.ILogger;
using SurveySchema = ManagementUtility.LtuTools.SurveySchema;
using Confirmit.Security.Crypto.Web;
using System.Data.SqlClient;

namespace ManagementUtility
{
    public class Initializer : IInitializer
    {
        private readonly ILogger _logger;
        private readonly IFactory _factory;
        private readonly ICopier _copier;
        private readonly IServiceEngine _serviceEngine;
        private readonly IPsExecExecutor _psExecExecutor;
        private readonly ITelephonyConfigurator _telephonyConfigurator;
        private readonly ITestStateObserver _testStateObserver;

        public Initializer(ILogger logger, IFactory factory, ICopier copier, IServiceEngine serviceEngine, 
            IPsExecExecutor psExecExecutor, ITelephonyConfigurator telephonyConfigurator, ITestStateObserver testStateObserver)
        {
            _logger = logger;
            _factory = factory;
            _copier = copier;
            _serviceEngine = serviceEngine;
            _psExecExecutor = psExecExecutor;
            _telephonyConfigurator = telephonyConfigurator;
            _testStateObserver = testStateObserver;

            InitializeServiceLocator();
        }

        public void PrepareLTUForStart(TestConfiguration testConfiguration, bool doNotCleanConfirmLog, string ltuLocalPath)
        {
            if (testConfiguration.IsDialerUse)
            {
                _testStateObserver.ShowAction("Run IISReset and clean event logs on dialer WS servers");
                RunIisResetAndCleanEventLogsOnDialerWSServers(testConfiguration);
            }

            _testStateObserver.ShowAction("Copy LTU to remote servers");            
            _copier.CopyLtuToRemoteServers(testConfiguration, ltuLocalPath);

            if (testConfiguration.IsDialerUse && testConfiguration.DialerSimulatorAutomaticMode)
            {
                _testStateObserver.ShowAction("Configure outcomes for dialer");

                switch (testConfiguration.LoadTestEnvironmentInfo.Dialer.Type)
                {
                    case DialerType.GenericSimulator:                        
                        _telephonyConfigurator.PutDialerSettingsToSimulatorScenarioXml(testConfiguration);
                        break;

                    case DialerType.TciReal:
                        _telephonyConfigurator.PutDialerSettingsToResponseSimCfgTxt(testConfiguration);
                        break;
                    case DialerType.TciSimulator:
                        _telephonyConfigurator.PutDialerSettingsToBvTciScenarioXml(testConfiguration);
                        break;
                }                
            }
            
            _testStateObserver.ShowAction("Initialize Core");
            InitializeCore(testConfiguration);
            
            _testStateObserver.ShowAction("Add current IP to allowed ip addresses list");
            AddCurrentIpToAllowedIpList(testConfiguration);

            _testStateObserver.ShowAction("Restart SQL services");
            _serviceEngine.RestartCatiAndConfirmitSqlServers(testConfiguration);

            if (!doNotCleanConfirmLog)
            {
                _testStateObserver.ShowAction("Clean confirmlog");
                CleanConfirmLog(testConfiguration);
            }

            RegisterServersInConfirmitDb(testConfiguration, "register");
        }

        public void RegisterServersInConfirmitDb(TestConfiguration testConfiguration, string action)
        {
            _logger.WriteLog("Register ltu servers in confirmit system");

            foreach (string machineName in testConfiguration.GetServerNames(ProductType.LTU))
            {
                string arguments = string.Format(
                    "/i {0} \\\\{1} \"{2}\" /Branch ltu /Action {3} /Config \"{4}\"",
                    TestConfiguration.PsExecCredentials,
                    machineName,
                    string.Format(@"c:\{0}\BuildServerRegistrator\BuildServerRegistrator.exe", TestConfiguration.RootLtuFolderName),
                    action,
                    string.Format(@"c:\{0}\BuildServerRegistrator\Configs\ServerConfiguration.xml", TestConfiguration.RootLtuFolderName));

                var process =_psExecExecutor.InvokeProcess(arguments);
                process.WaitForExit();
            }
        }

        private void AddCurrentIpToAllowedIpList(TestConfiguration testConfiguration)
        {
            IDatabaseEngines databaseEngines = _factory.CreateDatabaseEnginesObject(testConfiguration);

            string myHost = Dns.GetHostName();
            string myIP = Dns.GetHostEntry(myHost).AddressList.Aggregate(string.Empty, (current, ipAddress) => current + (";" + ipAddress));
            _logger.WriteLog("Current ip address is '{0}'", myIP);
            _logger.WriteLog("Allowed ip addresses list is '{0}'", ServiceLocator.Resolve<ISystemSettings>().Server.AccessAllowedIPAddresses);

            if (!ServiceLocator.Resolve<ISystemSettings>().Server.AccessAllowedIPAddresses.Contains(myIP.TrimStart(';')))
            {
                UpdateSystemSetting(databaseEngines.DefaultDatabase, "Server.AccessAllowedIPAddresses", ServiceLocator.Resolve<ISystemSettings>().Server.AccessAllowedIPAddresses + myIP);
                _logger.WriteLog("Allowed ip addresses was updated");
                _logger.WriteLog("Allowed ip addresses list is '{0}'", ServiceLocator.Resolve<ISystemSettings>().Server.AccessAllowedIPAddresses);
            }
            else
            {
                _logger.WriteLog("Allowed ip addresses updating was skipped");
            }
        }

        private void CleanConfirmLog(TestConfiguration testConfiguration)
        {
            var databaseEngine = new DatabaseEngine(testConfiguration.ConnectionStringToConfirmlogDB);

            var queries = new[] 
            {
                "truncate table CatiEventLog",
                "truncate table CatiManagementActivity",
                "truncate table CatiInterviewerActivity",
                "truncate table CatiInterviewerSessionHistory",
                "DBCC SHRINKFILE(confirmlog_log)"
            };

            foreach (var query in queries)
            {
                try
                {
                    _logger.WriteLog("Execute: {0}", query);
                    databaseEngine.ExecuteNonQuery(query, CommandType.Text);
                }
                catch (Exception ex)
                {
                    _logger.WriteLog("Exception: {0}", ex);
                }
            }
        }

        private void RunIisResetAndCleanEventLogsOnDialerWSServers(TestConfiguration testConfiguration)
        {
            if (!testConfiguration.DialerSimulatorAutomaticMode)
            {
                _logger.WriteLog("Don't reset iis on dialer WS machinen name and don't clean an event log");
                return;
            }

            _logger.WriteLog("Run IISReset on '{0}'", testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName);
            string arguments = string.Format(
                "{0} \\\\{1} IISReset",
                TestConfiguration.PsExecCredentials,
                testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName);

            Process process = _psExecExecutor.InvokeProcess(arguments);
            process.WaitForExit();

            EventLog[] dialerLogs = EventLog.GetEventLogs(testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName);
            foreach (EventLog eventLog in dialerLogs.Where(x => x.Log.Contains("DialerWS")))
            {
                _logger.WriteLog("Clean '{0}' event log on '{1}'", eventLog.Log, testConfiguration.LoadTestEnvironmentInfo.Dialer.WSMachineName);
                eventLog.Clear();
            }
        }

        public void ReCreateCompany(TestConfiguration testConfiguration)
        {
            _serviceEngine.StartCatiServices(testConfiguration);

            IManagementServices managementServices = _factory.CreateManagementServices(testConfiguration);
            IDatabaseEngines databaseEngines = _factory.CreateDatabaseEnginesObject(testConfiguration);

            _testStateObserver.ShowAction("Recreate company");
            IInstanceManagementService ims = managementServices.MultimodeInstance;

            _logger.WriteLog("Delete {0} instance...", testConfiguration.CompanyId);
            ims.UnregisterSchedulingServiceInstance(testConfiguration.CompanyId);
            
            RemoveCatiDatabase(testConfiguration);

            _logger.WriteLog("Create {0} instance...", testConfiguration.CompanyId);
            ims.RegisterSchedulingServiceInstance(testConfiguration.CompanyId);

            _testStateObserver.ShowAction("Initialize backend telephony");
            _telephonyConfigurator.InitializeBackendTelephone(testConfiguration);

            _testStateObserver.ShowAction("Initialize test data");
            InitializeDataTables(testConfiguration, databaseEngines);
        }

        private void RemoveCatiDatabase(TestConfiguration testConfiguration)
        {
            var scsb = new SqlConnectionStringBuilder(testConfiguration.ConnectionStringToBE);
            string defaulCatiName = scsb.InitialCatalog;
            scsb.InitialCatalog = "master";
            
            var databaseTools = new DatabaseTools(scsb.ToString());
            databaseTools.DropDatabase($"{defaulCatiName}_{testConfiguration.CompanyId}");
        }

        private void InitializeServiceLocator()
        {
            var serviceLocator = new ServiceLocator();
            serviceLocator.Initialize();

            IServicesRegistryInitializer serviceRegistryInitializer = new ServicesRegistryInitializer(serviceLocator);
            serviceRegistryInitializer.RegisterRegistries(serviceRegistryInitializer.GetRegistries());
        }        

        private void InitializeDataTables(TestConfiguration testConfiguration, IDatabaseEngines databaseEngines)
        {
            foreach (var scenario in testConfiguration.SurveyScenarios)
            {
                var interviewDataTableName = NameMaker.InterviewDataTableName(scenario.Name);

                CreateInterviewDataTable(
                    databaseEngines.Backend,
                    interviewDataTableName,
                    scenario.Schema.Fields.Where(x => x.Value.Type == FieldType.Background).Select(y => y.Value).ToArray());
            }
            //BackendTools.CreateInterviewTelepthoneNumberTable(DatabaseEngines.Backend, TelephoneNumberTableName);
        }

        private void CreateInterviewDataTable(DatabaseEngine db, string tableName, SurveySchema.FieldInfo[] fields)
        {
            //string values[][] = new string[CountValues.Length];
            var selects = new string[fields.Length];

            for (int index = 0; index < fields.Length; index++)
            {
                var sb = new StringBuilder();
                foreach (var precode in fields[index].Precodes)
                {
                    sb.AppendFormat("SELECT '{0}' as [{1}]\n\rUNION\r\n", precode, fields[index].Name);
                }
                sb.Append("SELECT NULL");

                selects[index] = sb.ToString();
            }

            var query = new StringBuilder();
            query.AppendFormat("IF EXISTS( SELECT 1 FROM sys.tables WHERE name = '{0}' )\nDROP TABLE [{0}]\n", tableName);
            
            //generate create table statement
            query.AppendFormat("CREATE TABLE [{0}]( DataId INT NOT NULL", tableName);
            foreach (var field in fields)
            {
                query.AppendFormat(",\r\n [{0}] NVARCHAR(MAX)", field.Name);
            }
            query.Append("\r\n)");

            //generate create index statement 
            query.AppendFormat(
                "ALTER TABLE [{0}] ADD CONSTRAINT [Pk_{0}] PRIMARY KEY CLUSTERED ([DataId] ASC) WITH (ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF)\n", tableName);

            if (fields.Length > 0)
            {
                query.AppendFormat(" INSERT INTO [{0}] SELECT ( ROW_NUMBER() OVER(ORDER BY {1}) ) - 1, * FROM(\n{2}) as [{3}]",
                    tableName,
                    String.Join(",", fields.Select(x => x.Name).ToArray()),
                    selects[0],
                    fields[0].Name);
            }

            for (int index = 1; index < selects.Length; index++)
            {
                query.AppendFormat("\nJOIN ({0}) as [{1}] ON 1 = 1", selects[index], fields[index].Name);
            }

            db.ExecuteBatch(query.ToString());
        }

        private void InitializeCore(TestConfiguration testConfiguration)
        {
            IDatabaseEngines databaseEngines = _factory.CreateDatabaseEnginesObject(testConfiguration);

            SimulatedHttpRequest.SetHttpContextWithSimulatedRequest("MyHost", "MyBlog");

            HttpContext.Current.User = new SupervisorPrincipal(
                    "userName",
                    "clientKey",
                    testConfiguration.CompanyId,
                    "Load test company",
                    Tabs.None,
                    false, false, false);

            var dbLibProviderStub = RegistryStub<IDbLibProvider, StubIDbLibProvider>();
            dbLibProviderStub.CatiDefaultConnectionString = testConfiguration.ConnectionStringToBE;
            dbLibProviderStub.ConfirmConnectionString = testConfiguration.ConnectionStringToConfirmDB;
            dbLibProviderStub.ConfirmlogConnectionString = testConfiguration.ConnectionStringToConfirmlogDB;

            var backendInstance = ServiceLocator.Resolve<IBackendInstanceFactory>().Create(
                Convert.ToInt32(testConfiguration.CompanyId),
                HostType.Supervisor);
            HttpContext.Current.Items["BackendInstance"] = backendInstance;

            BackendInstance.Current.ConnectionString = databaseEngines.Backend.ConnectionString;
            BackendInstance.Current.ConfirmlogConnectionString = databaseEngines.Confirmlog.ConnectionString;

            UpdateSystemSetting(databaseEngines.DefaultDatabase, "Setup.EncryptedConfirmConnectionString", EncryptionUsingMachineKey.Encrypt(DataProtection.All, testConfiguration.ConnectionStringToConfirmDB));
            UpdateSystemSetting(databaseEngines.DefaultDatabase, "Setup.EncryptedConfirmlogConnectionString", EncryptionUsingMachineKey.Encrypt(DataProtection.All, testConfiguration.ConnectionStringToConfirmlogDB));
        }

        private class StubIDbLibProvider : IDbLibProvider
        {            
            public string CatiDefaultConnectionString { get; set; }
            public string ConfirmConnectionString { get; set; }
            public string ConfirmlogConnectionString { get; set; }

            public string ConfirmAdminConnectionString(string projectId)
            {
                throw new NotImplementedException();
            }
        }

        private T RegistryStub<I, T>() where T : I
        {
            ServiceLocator.Resolve<IServiceRegistrator>().RegisterSingleton<I, T>();
            return (T)ServiceLocator.Resolve<I>();
        }

        private void UpdateSystemSetting(DatabaseEngine databaseEngine, string settingName, string value)
        {
            databaseEngine.ExecuteNonQuery(string.Format("exec BvSpSystemSetting_Update '{0}', '{1}'", settingName, value), CommandType.Text);
        }
    }
}

